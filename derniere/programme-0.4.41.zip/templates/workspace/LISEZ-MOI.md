# Ton studio IA

Tout ce que tu fais avec le studio est ici, rangé :

- `Projets/` : la fiche de chaque projet (contexte pour les agents). Les fichiers du projet restent dans son propre dossier.
- `Sujets/` : un dossier par sujet (idées, recherches, images…) avec son contexte et ses résultats rangés par type : `Images/`, `Documents/`, `3D/`, `Sons/`, `Videos/`, `Code/`.
- `Taches/` : un dossier par tâche, « date + titre ». Le compte rendu est `RESULTAT.md` ; `details/` contient le technique.
- `Skills/` : les savoir-faire de tes agents, un dossier par skill.
- `Regles/` : les règles et fichiers .md communs à toutes tes IA.
- `Sauvegardes/` : une sauvegarde par jour (7 jours + 4 semaines gardées).
- `Archives/` : ce que tu retires du studio (rien n'est jamais effacé).
- `Studio/` : technique (réglages, agents, mémoire). Pas besoin d'y toucher.

Le studio fait son ménage seul : vieilles sauvegardes, copies de travail des tâches finies, caches. Jamais tes projets, tes sujets ni leurs résultats.
