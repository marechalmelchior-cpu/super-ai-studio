# Regles

Règles communes à tous les agents. `PRIORITES.md` dit laquelle l'emporte en cas de conflit.
