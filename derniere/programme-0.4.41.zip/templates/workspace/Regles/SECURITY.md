# Limites de sécurité du studio

- Données locales par défaut ; aucun service exposé sur le réseau (interface sur 127.0.0.1 uniquement).
- Les outils gardent leurs protections : pas de `bypassPermissions`, pas de `danger-full-access`, pas de `--dangerously-skip-permissions`.
- Le studio n'arrête que les processus qu'il a lancés (enregistrés dans `processes`).
- Aucune suppression de données par le studio ; une application de changement refuse si le projet a changé depuis la préparation.
- Les secrets sont masqués avant écriture (journaux, mémoire, exports) ; une écriture mémoire contenant un secret est refusée.
- Un contenu externe (dépôt, historique, web, résultat d'outil, réponse d'une IA collée) est encadré comme donnée non fiable.
- Abonnement ≠ accès API illimité : tout nouvel usage payant est annoncé avec son coût estimé avant d'être lancé.
