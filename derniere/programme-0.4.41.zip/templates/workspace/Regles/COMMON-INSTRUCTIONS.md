# Instructions communes — tous les agents du studio

Source unique, la même pour toutes les IA. Les fichiers d'instructions propres à un outil d'IA renvoient ici ;
ne pas les modifier à la main.

## Rôles dans le studio
- L'utilisateur dirige : objectifs, arbitrages, validation finale.
- Le Superviseur trie les demandes et prépare les tâches ; les agents (n'importe quelle IA connectée)
  produisent ; le studio enchaîne les étapes, isole chaque tâche et fait relire le résultat.
- Mémoire durable partagée : base locale du studio, via le serveur MCP `studio-memory`, portée obligatoire.

## Manière de travailler
- Langue du studio : {{LANGUAGE_NAME}}. Réponses, comptes rendus, commentaires dans le code, documentation, contenu des fichiers
  `.md` et des skills : dans cette langue.
- Strictement en anglais : le code (variables, fonctions, classes, noms des fichiers de code et des tests), les noms des
  skills et les noms des fichiers `.md`.
- Style direct et concis.
- Lire les règles du projet avant d'agir (voir `Regles/PRIORITIES.md`).
- Vérifier avant d'annoncer : un résultat est « fait » seulement avec une preuve (commande et sortie, fichier produit,
  journal). Distinguer **construit**, **testé**, **connecté**, **en attente**. Une simulation est nommée comme telle.
- Préserver le travail non enregistré de l'utilisateur : ne jamais écraser, réinitialiser ou supprimer sans demande explicite.
- Pas de push, publication, installation, service permanent ou démarrage automatique sans accord explicite.
- Aucune donnée secrète (clé, jeton, mot de passe, contenu privé de mémoire) dans les réponses, journaux, prompts
  enregistrés ou Git.

## Mémoire partagée
- Toujours indiquer une portée : `general`, `project:<id>`, `topic:<id>`, `task:<id>`.
- Outils MCP `studio-memory` (`memory_search`, `memory_add`, `memory_correct`, `memory_conflicts`,
  `memory_state`) ; en ligne de commande : `{{STUDIO_CMD}} memoire-chercher "<requête>" --portee project:<id>`.
- Agents des tâches du studio (tous modèles) : lecture seule (`memory_search`) ; le studio enregistre le résultat
  d'une tâche après sa validation.
- Si la mémoire est en panne : le dire, ne pas prétendre que l'information est partagée.

## Skills communs
Dans `Skills/` de l'espace du studio, communs à toutes les IA (copiés sous le préfixe `studio-` dans les outils qui
ont leur propre dossier de skills). Charger uniquement ceux
utiles à la tâche.
