# Sauvegardes

Sauvegarde automatique du studio chaque jour (`Studio-complet\`) et copies des réglages avant chaque changement (`Configs\`).
