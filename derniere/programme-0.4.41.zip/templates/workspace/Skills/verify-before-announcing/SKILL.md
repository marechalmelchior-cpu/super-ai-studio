---
name: verify-before-announcing
description: Règles de preuve avant d'annoncer un résultat (construit, testé, connecté, en attente).
---

# verification-avant-annonce

- **Domaine** : tous

## Objectif
Ne jamais présenter comme fonctionnel ce qui est seulement écrit, configuré ou simulé.

## Quand l'utiliser
À la fin de toute tâche, avant le compte rendu.

## Prérequis
Aucun.

## Étapes
1. Lister ce qui a été produit.
2. Pour chaque point : commande exécutée + sortie, fichier + empreinte, ou journal.
3. Classer : construit / testé / connecté / en attente / simulé.
4. Indiquer explicitement ce qui demande une action manuelle (PIE, interface graphique).

## Vérifications
- Aucune affirmation de réussite sans preuve citée.
- Toute simulation est nommée « SIMULATION ».
