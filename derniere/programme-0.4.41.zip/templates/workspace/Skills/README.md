# Skills communs

Source unique pour les agents du studio. Le bouton **Synchroniser** (Gestion › Skills) les copie pour Claude Code et
Codex sous le préfixe `studio-`, sans jamais écraser un skill qui n'a pas été créé par le studio.

## Socle (fourni avec le studio)
- `supervisor` : méthode du Superviseur (réservé au Superviseur)
- `shared-memory` : lire et écrire la mémoire avec la bonne portée
- `git-isolation` : travailler sur une copie, pas de push sans accord
- `verify-before-announcing` : pas de « c'est fait » sans preuve
- `review-loop` : gros changements par lots, chaque lot relu
- `add-project-or-topic` : brancher un projet existant ou en créer un
- `end-of-session-tidy` : ranger un projet proprement
- `backup-restore` : sauvegarder le studio et vérifier la restauration
- `audit-skills`, `audit-memories` : audits lancés depuis Gestion › Entretien

## Packs (ajoutés au premier lancement ou plus tard)
Jeu vidéo Unreal, 3D / Blender, Concept art, Avancé. Les skills d'un pack arrivent ici, ses rôles dans `Studio/roles/`.

## Skills d'un projet
Un projet garde ses propres skills dans `<projet>/.claude/skills/` (suivis par Git). Les skills déjà installés dans
Claude Code (`~/.claude/skills`) ou Codex restent utilisés tels quels : le studio ne les copie ni ne les modifie.
