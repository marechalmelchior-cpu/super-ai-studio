---
name: shared-memory
description: Lire ou écrire la mémoire partagée du studio avec une portée garantie (général, projet, sujet, tâche).
---

# memoire-partagee

- **Domaine** : tous projets et sujets

## Objectif
Retrouver et enregistrer des informations durables entre toutes les IA du studio sans mélanger les projets.

## Quand l'utiliser
Avant une tâche qui dépend de décisions passées ; après une décision ou un fait durable validé par l'utilisateur.

## Prérequis
Serveur MCP `studio-memory` disponible (vérifier avec `memory_state` ; base SQLite locale, sans serveur à démarrer). 

## Étapes
0. Si ton outil a accès aux serveurs MCP, utiliser de préférence les outils MCP `studio-memory` (mêmes opérations, portée obligatoire). Les commandes ci-dessous sont l'équivalent en ligne de commande.
1. Lire : `{{STUDIO_CMD}} memoire-chercher "<mots>" --portee project:<id>` (le général est inclus ; `--sans-general` pour l'exclure).
2. Écrire un fait : `{{STUDIO_CMD}} memoire-ajouter "<fait>" --portee <portée> --outil <ton-outil> --sujet <clé-stable>`.
3. Corriger : `{{STUDIO_CMD}} memoire-corriger --portee <portée> --cle <clé> "<nouveau texte>"`.
4. Contradictions : `{{STUDIO_CMD}} memoire-conflits --portee <portée>` → signaler à l'utilisateur, ne pas trancher seul.
5. Ne jamais écrire de secret, d'historique brut ou d'information personnelle non demandée.

## Vérifications
- Code 0 et `"partage": true` = partagé. Code 3 = **non partagé** (mis en attente). Code 2 = mémoire en panne.
