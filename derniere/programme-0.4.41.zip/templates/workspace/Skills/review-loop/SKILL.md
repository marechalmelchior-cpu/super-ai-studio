---
name: review-loop
description: Exécuter une modification non triviale par lots, chaque lot relu par un relecteur indépendant en lecture seule, avec preuves et deux reprises maximum pour toute la tâche. Pour code, données ou assets ; pas pour une lecture, une correction triviale, un rangement ou une opération Git seule.
disable-model-invocation: true
---

# boucle-legere

- **Domaine** : tous les projets
- **Réglages du projet** : lus dans ses fichiers d'instructions des agents (commandes de vérification autorisées, contrats à
  ne pas casser, document de stratégie de tests). Un projet peut garder une skill locale qui renvoie ici avec ses réglages.
- **Priorité au projet** : si le projet a une skill `<projet>-boucle-legere`, c'est **elle** qu'il faut
  charger : elle renvoie ici et ajoute ses réglages, qui prévalent.

## Objectif
Avancer vite sans rien casser : petits lots vérifiés, relecture indépendante ciblée, arrêt net au lieu de corriger en boucle.

## Quand l'utiliser
Sur demande seulement (`/boucle-legere`, `$boucle-legere`), dans une session directe hors du studio. Dans une tâche du
studio, ne pas l'utiliser : le studio relit déjà chaque tâche (relecture indépendante, deux reprises au plus).
Toute modification non triviale. Pas pour : lecture, prompt, correction d'une ligne, rangement, Git seul.

## 1. Avant de modifier
- Lire la demande complète et ses corrections. Découper en lots fonctionnels, chacun avec ses vérifications autorisées.
- Relever l'état Git initial. Pour tout fichier **déjà modifié** que le lot va écrire, garder un instantané hors dépôt :
  le diff Git seul ne dit pas qui a changé quoi.

## 2. Exécuter un lot
Modifier, puis vérifier en proportion du risque. Un lot sensible ou touchant plusieurs fichiers reçoit une relecture ;
les corrections documentaires simples sont regroupées à la fin.

## 3. Relecteur indépendant (lecture seule)
Lancer un relecteur dans un **contexte séparé** : sous-agent ou session séparée en lecture seule,
selon ce que permet ton outil. Lui fournir : la demande, le périmètre, les preuves, le diff propre au lot
(instantané → état courant pour les fichiers déjà modifiés). Jamais le raisonnement du producteur.

Contrat du relecteur :
- Chercher : exigence manquante, erreur de comportement, régression, doublon, changement hors périmètre, preuve trompeuse.
- **BLOCKING** : violation prouvée d'une exigence, défaut fonctionnel, risque de perte, contradiction d'architecture,
  preuve obligatoire absente. **NON_BLOCKING** : préférence, amélioration facultative, limite déclarée. Dans le doute : NON_BLOCKING.
- N'imputer un changement au lot que si son diff le prouve ; sinon le déclarer en limite.
- Ne rien écrire ; ne lancer ni build, ni test, ni éditeur, ni écriture Git. Douze lectures/recherches maximum par passage.
- Sortie :
  ```text
  VERDICT: ACCEPTED | CORRECTION_REQUIRED | USER_NEEDED
  FINDINGS:
  - [BLOCKING ou NON_BLOCKING] chemin:ligne — fait, conséquence, correction minimale
  CHECKS:
  - exigence — preuve
  LIMITS:
  - élément non vérifié
  ```

## 4. Verdict et reprises
- ACCEPTED : lot suivant. CORRECTION_REQUIRED : corriger **seulement** les BLOCKING prouvés, puis contre-relecture de la
  correction et de ses effets directs. USER_NEEDED : arrêter et demander l'arbitrage.
- **Deux reprises pour toute la tâche**, pas par lot. Au plafond : exposer défauts restants, preuves et décision attendue.
- Les NON_BLOCKING vont au rapport, sans reprise.

## 5. Fin
Revue finale de cohérence avec la demande, sans rouvrir les lots acceptés ni le travail préexistant.
Supprimer les instantanés temporaires une fois l'attribution terminée.

## Vérifications
- Chaque lot a ses preuves (commande + sortie) et son verdict.
- Le rapport distingue : accepté, corrigé, limites, décisions attendues de l'utilisateur (voir `verify-before-announcing`).
