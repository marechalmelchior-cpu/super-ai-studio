---
name: end-of-session-tidy
description: Ranger un projet à la demande en fin de séance — contrôler les fichiers touchés, corriger la documentation autorisée, sauvegarder la mémoire, puis préparer ou publier un lot Git ciblé après relecture. Jamais automatiquement.
---

# rangement-fin-de-seance

- **Domaine** : tous les projets
- **Réglages du projet** (dans ses fichiers d'instructions des agents, à lire d'abord) : script de sauvegarde de la mémoire
 , règle Git (commit/push autorisés ou non), dossier d'archives, index des tâches terminées.
  Sans règle Git explicite : préparer le lot et **demander** avant tout commit ou push.
- **Priorité au projet** : si le projet a une skill `<projet>-rangement-fin-de-seance`, c'est **elle** qu'il faut
  charger : elle renvoie ici et ajoute ses réglages, qui prévalent.

## Objectif
Laisser le projet propre et cohérent après une séance, sans toucher au travail des autres ni décider à la place de l'utilisateur.

## Quand l'utiliser
Seulement sur demande (« range », « fin de séance »). Pas après chaque réponse, pas pendant une autre exécution, pas si
rien n'a changé, jamais branché sur un hook.

## Limites
- Rangement documentaire : ne touche ni aux assets, ni au gameplay, ni au code de production ; aucune action d'éditeur.
- Préserver les modifications d'autres tâches et les incidents utiles. Une décision de produit nouvelle revient à l'utilisateur.

## Étapes
1. **Périmètre** : relever l'état Git initial ; instantané hors dépôt de tout fichier déjà modifié.
2. **Audit courant** : comparer les fichiers de la séance (et leurs index directs) au code et aux sources qui font foi :
   noms, liens, propriétaires, consignes contradictoires. Pas d'inventaire recopié.
   Audit complet seulement si la demande le couvre (voir le skill global `audit-memories`).
3. **Mémoire** : corriger dans la **source** (pas dans un miroir), garder les connaissances uniques — surtout les pièges
   (« X n'existe pas en Python UE 5.8 ») — puis une seule synchronisation par le script du projet.
   Mémoire partagée du studio : faits durables via `shared-memory`.
4. **Corrections** : appliquer les seules corrections autorisées, relire le diff propre au lot ; archives au dossier
   d'archives du projet, tâches terminées selon son index.
5. **Rapport** : corrigé / historique conservé / non vérifié. Une hypothèse n'est pas un fait.
6. **Git** : selon la règle du projet. Ajout ciblé (jamais `git add -A`), aucun fichier inattendu ou d'une autre session.
   Si le lot ne peut pas être isolé et relu : faire les corrections sûres et signaler le blocage.

## Vérifications
- `git status` avant/après cité ; liste des fichiers du lot ; sortie du script de sauvegarde de la mémoire.
- Aucun fichier hors périmètre dans le lot.
