# Projets

Un dossier par projet déclaré dans le studio (`<id>/project.toml`) : le projet lui-même reste à son emplacement,
le studio y pointe. Ajouter un projet : bouton « + » à côté des onglets de projets.
