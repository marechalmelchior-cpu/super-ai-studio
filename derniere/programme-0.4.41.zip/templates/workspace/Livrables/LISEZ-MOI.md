# Livrables

Les fichiers produits pour tes sujets arrivent ici, rangés par sujet puis par type :
`<Sujet>\Images\`, `Documents\`, `3D\`, `Sons\`, `Videos\`, `Code\`, `Autres\`.
Rien n'est écrasé : une nouvelle version s'appelle « nom v2 ». Les sorties d'un projet restent dans le projet.
