# Taches

Un dossier par tâche (« 2026-10-25 Titre ») : compte rendu `RESULTAT.md`, images de vérification dans `captures\`. Le technique est dans `details\`.
