# Décisions

Décisions validées du studio : `ADR-NNNN-titre.md` avec date, portée, statut (proposée / validée / remplacée) et
justification. Prioritaires sur les règles communes dans leur portée.
