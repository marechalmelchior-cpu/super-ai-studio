---
name: unreal-headless
description: Exécuter des tests d'automatisation ou commandlets Unreal sans interface, avec preuve dans le journal.
---

# unreal-sans-interface

- **Domaine** : projets Unreal

## Objectif
Vérifier du code ou des données Unreal sans ouvrir l'éditeur, quand c'est possible.

## Quand l'utiliser
Tests d'automatisation, validation de données, commandlets. Pas pour PIE ou contrôles visuels (manuels).

## Prérequis
Version d'UE installée identique à `EngineAssociation` du .uproject (vérifiée par `Test-Environment.ps1`). Éditeur du projet fermé.

## Étapes
1. Lire les règles du projet (fichiers d'instructions des agents).
2. `UnrealEditor-Cmd.exe <projet>.uproject -ExecCmds="Automation RunTests <filtre>;Quit" -unattended -nullrhi -nosplash -nopause -abslog=<journal>`.
3. Analyser le journal : lignes `Result={Success}` / `Result={Fail}`.

## Vérifications
- Au moins un résultat de test dans le journal ; sinon « non prouvé ».
- PIE : demander un test manuel à l'utilisateur avec la liste des contrôles.
