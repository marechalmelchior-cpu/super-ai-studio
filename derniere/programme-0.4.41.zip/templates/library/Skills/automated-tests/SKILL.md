---
name: automated-tests
description: Écrire et faire passer des tests automatisés — unitaires, intégration, bout en bout — avec l'outil déjà utilisé par le projet (pytest, Jest, Vitest, Playwright, tests Unreal, GUT pour Godot). À utiliser pour couvrir une fonctionnalité, reproduire un bug par un test ou fiabiliser un module.
---

# Tests automatisés

## Méthode
1. **Repérer l'outil du projet** (fichiers de config, dossier tests, scripts du package). Ne pas en ajouter un nouveau sans accord.
2. **Bug** : d'abord un test qui échoue et reproduit le bug, ensuite la correction, puis le test passe.
3. **Fonctionnalité** : tester le comportement attendu, pas l'implémentation : cas normal, cas limites, cas d'erreur.
4. **Isolation** : pas de réseau ni de vrais fichiers utilisateur ; données de test dans des dossiers temporaires ; horloge et hasard maîtrisés.
5. **Lancer toute la suite**, pas seulement le nouveau test ; rapporter le nombre de tests passés et échoués.

## Règles
- Un test = une raison d'échouer, un nom qui dit ce qu'il vérifie (en anglais).
- Pas de test qui dépend de l'ordre d'exécution.
- Ne jamais désactiver un test qui échoue pour « faire passer » : le signaler.
