---
name: game-design-document
description: Écrire ou mettre à jour le document de game design (GDD) d'un jeu — vision, boucle de jeu, mécaniques, progression, contenu, technique. À utiliser quand on demande un GDD, une fiche de mécanique, un pitch de jeu ou de clarifier « comment le jeu fonctionne ».
---

# Document de game design

## But
Un GDD court, vivant et utilisable : chaque section répond à une question que l'équipe se pose vraiment. Pas de roman.

## Méthode
1. **Lire l'existant** : instructions des agents, docs du projet, code des systèmes déjà faits. Ne jamais contredire ce qui existe sans le signaler.
2. **Poser la vision en 5 lignes** : genre, fantasme du joueur (« tu es… qui… »), plateforme, public, trois piliers (ce qui ne se négocie pas).
3. **Boucle de jeu** : boucle de 30 secondes, de 5 minutes, de la session. Un schéma texte suffit : action → récompense → choix.
4. **Mécaniques** : une fiche par mécanique — intention, règles précises (chiffres), contrôles, retours (son, image), cas limites, dépendances.
5. **Progression et économie** : ce que le joueur gagne, dépense, débloque ; courbe de difficulté ; renvoie vers la skill d'équilibrage pour les chiffres.
6. **Contenu** : liste des niveaux / zones / ennemis / objets, avec statut (idée, maquette, fait).
7. **Technique** : moteur, contraintes de performance, systèmes à créer, risques.
8. **Questions ouvertes** : ce qui n'est pas décidé, avec la personne qui décide.

## Règles
- Chiffres concrets plutôt qu'adjectifs (« sprint 620 cm/s pendant 3 s », pas « sprint rapide »).
- Marquer clairement ce qui est **décidé** et ce qui est **proposé**.
- Une page par sujet, des titres courts, des listes ; un sommaire en tête.
- Noms de fichiers clairs (« GDD - Combat.md »). Identifiants techniques et noms de variables en anglais.
