---
name: data-analysis
description: Analyser des données (CSV, Excel, JSON, bases) — nettoyage, calculs, graphiques, conclusions chiffrées — avec un script reproductible et un rapport clair. À utiliser pour explorer un fichier de données, répondre à une question chiffrée ou produire un tableau de bord.
---

# Analyse de données

## Méthode
1. **Charger et décrire** : colonnes, types, nombre de lignes, valeurs manquantes, doublons, valeurs aberrantes.
2. **Nettoyer** en gardant l'original intact : copie de travail, chaque transformation écrite dans le script.
3. **Répondre à la question posée** : calculs groupés, évolutions, comparaisons ; toujours avec les effectifs.
4. **Graphiques** : un message par graphique, axes titrés avec unités, pas de 3D ni de camembert à 10 parts.
5. **Rapport** : la réponse en 3 phrases d'abord, puis les chiffres clés, les graphiques, les limites (données manquantes, biais).
6. **Livrer** le script (Python, code en anglais), les graphiques (PNG) et le tableau résultat (CSV ou Excel).

## Règles
- Jamais de chiffre recopié à la main : tout sort du script.
- Dire quand l'échantillon est trop petit pour conclure.
- Données personnelles : ne garder que le nécessaire.
