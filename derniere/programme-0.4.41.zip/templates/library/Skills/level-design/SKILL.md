---
name: level-design
description: Concevoir un niveau ou une zone de jeu — intention, parcours, rythme, blocage (blockout), points d'intérêt, rencontres, tests. À utiliser pour dessiner un niveau, critiquer un niveau existant ou préparer un blockout dans un moteur.
---

# Level design

## Méthode
1. **Intention** : ce que le joueur doit ressentir et apprendre ici (une mécanique enseignée, une tension, une récompense). Une phrase.
2. **Carte du flux** : début → objectifs → fin, en texte ou schéma ASCII. Indiquer chemin principal, détours, raccourcis, points de non-retour.
3. **Rythme** : alterner tension et repos. Courbe en 5 à 8 temps (exploration, combat, énigme, récompense, pause, climax…).
4. **Lisibilité** : repères visibles de loin (landmarks), lumière qui guide, couleur des éléments interactifs, ligne de vue avant chaque danger.
5. **Rencontres** : pour chaque combat ou énigme — position, ennemis, couverture, solution prévue, solution alternative.
6. **Blockout** : formes simples aux bonnes dimensions (taille du personnage, hauteur de saut, largeur de couloir). Mesurer d'après les valeurs du projet, jamais à l'œil.
7. **Test** : parcours chronométré, endroits où l'on se perd, morts injustes, zones mortes. Corriger avant d'habiller.

## Règles
- Toujours partir des métriques du personnage (vitesse, saut, portée) lues dans le projet.
- Pas d'impasse sans récompense ; pas de récompense sans signal.
- Dans Unreal ou Godot : nommer les acteurs et dossiers clairement, en anglais (« BP_Door_Main », « LVL_Forest_01 »).
- Rendre compte avec captures et liste des changements.
