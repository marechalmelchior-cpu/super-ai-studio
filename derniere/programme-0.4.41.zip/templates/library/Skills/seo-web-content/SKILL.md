---
name: seo-web-content
description: Améliorer le référencement et les contenus d'un site — mots-clés, titres, méta-descriptions, structure, maillage interne, données structurées, performance — et rédiger des pages qui répondent aux recherches. À utiliser pour un audit SEO, une page à optimiser ou un plan de contenus.
---

# SEO et contenus web

## Audit rapide
- Une balise title unique par page (50–60 caractères), une méta-description (140–160), un seul H1.
- Structure H2/H3 logique, URL courtes et lisibles, images avec attribut alt et poids réduit.
- Pages lentes, liens cassés, contenu dupliqué, pages orphelines (sans lien interne).
- Données structurées adaptées (LocalBusiness, Restaurant, Product, Article, FAQ).
- Mobile : lisible sans zoom, boutons assez grands.

## Méthode
1. Lister les pages et leur intention (informer, vendre, réserver, contacter).
2. Pour chaque page : requête principale + 3 à 5 requêtes proches, en langage des clients.
3. Réécrire title, description, H1 et introduction pour répondre clairement à la requête.
4. Ajouter les liens internes utiles et un appel à l'action visible.
5. Livrer un tableau avant/après et les modifications de code (balises en anglais, textes dans la langue du site).

## Règles
- Écrire pour les humains d'abord ; pas de bourrage de mots-clés.
- Ne promettre aucun classement : mesurer avec la Search Console.
