---
name: research-digest
description: Faire une recherche ou une veille sur un sujet — sources fiables, comparaison, synthèse courte et citée, points à surveiller. À utiliser pour se renseigner, comparer des outils ou des solutions, suivre les nouveautés d'un domaine ou préparer une décision.
---

# Veille et synthèse

## Méthode
1. **Cadrer** : question précise, période, ce qui compte pour la décision.
2. **Chercher large puis trier** : sources primaires d'abord (documentation officielle, annonces, études), puis presse spécialisée ; noter la date de chaque source.
3. **Comparer** : tableau des options avec les mêmes critères (prix, limites, maturité, licence, compatibilité).
4. **Synthèse** : la réponse en 5 lignes, puis le détail, puis « ce qui reste incertain ».
5. **Citer** chaque affirmation importante avec son lien et sa date.

## Règles
- Distinguer fait vérifié, annonce et opinion.
- Dire quand une information est ancienne ou contradictoire.
- Pour une veille récurrente : même format à chaque fois, avec « nouveau depuis la dernière fois ».
