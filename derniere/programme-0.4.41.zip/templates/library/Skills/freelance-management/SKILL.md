---
name: freelance-management
description: Préparer les documents d'un indépendant — devis, factures, relances, suivi des clients et des projets, proposition commerciale — clairs et complets. À utiliser pour rédiger un devis ou une facture, préparer une relance ou tenir un tableau de suivi.
---

# Gestion freelance

## Devis
- Identité du prestataire et du client, date, numéro, durée de validité.
- Prestations détaillées (quantité, prix unitaire, total), acompte, délais, conditions de paiement, ce qui n'est pas compris.
- Mentions légales du pays et du statut (en France : SIRET, TVA ou mention d'exonération, pénalités de retard). Les vérifier, ne pas les inventer.

## Facture
- Numérotation continue, reprise du devis, date de prestation, échéance, moyens de paiement.

## Relance
- Trois niveaux : rappel aimable, relance ferme avec échéance, mise en demeure. Toujours factuelle et polie.

## Suivi
- Tableau : client, projet, statut, montant, payé / à payer, prochaine action, date.

## Règles
- Ne jamais inventer un numéro légal, un taux ou une mention : demander ou laisser un champ à remplir.
- Livrer en Word/PDF pour les documents, Excel pour le suivi.
- Pour une question juridique ou fiscale précise : le dire et renvoyer vers un comptable.
