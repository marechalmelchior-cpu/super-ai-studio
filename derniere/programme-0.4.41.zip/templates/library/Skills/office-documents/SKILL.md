---
name: office-documents
description: Lire, créer et modifier des documents Word (.docx), Excel (.xlsx), PowerPoint (.pptx) et PDF par script Python, avec preuve du fichier produit. Pour toute demande de document bureautique, tableur, présentation ou PDF.
---

# Documents bureautiques (Word, Excel, PowerPoint, PDF)

Fonctionne avec n'importe quelle IA capable d'écrire et de lancer un script Python.

## Outils
- Word : `python-docx` · Excel : `openpyxl` · PowerPoint : `python-pptx` · PDF : `pypdf` (lire, fusionner, découper) et
  `reportlab` (créer). Vérifier s'ils sont présents (`python -c "import docx"`…). S'il en manque un : le dire et demander
  l'accord avant d'installer quoi que ce soit.
- LibreOffice en ligne de commande (`soffice --headless --convert-to pdf`) s'il est installé, pour convertir et vérifier le rendu.

## Méthode
1. **Jamais l'original** : travailler sur une copie, écrire le résultat dans un nouveau fichier au nom clair
   (`devis-client-2026-10.docx`, pas `output.docx`). Ne rien écraser.
2. **Structure d'abord** : titres et styles du document (Titre 1, Titre 2…), pas de mise en forme à la main ligne à ligne ;
   Excel : en-têtes figés, formats de nombres et de dates, formules plutôt que valeurs recopiées ; PowerPoint : une idée par diapo,
   texte court, gabarit du fichier existant s'il y en a un.
3. **Données réelles** : ne jamais inventer un chiffre, un nom ou une date ; une donnée absente reste un champ à compléter, signalé.
4. **Vérifier avant d'annoncer** : rouvrir le fichier produit par script (nombre de pages, de feuilles, de diapos, cellules clés,
   formules sans erreur) ; si LibreOffice est là, exporter en PDF et regarder une page en image.
5. **Compte rendu** : chemin du fichier, ce qu'il contient (sections, feuilles, diapos), ce qui reste à compléter.

## Pièges
- Excel : `openpyxl` ne calcule pas les formules ; les valeurs apparaissent à l'ouverture dans le tableur. Pour vérifier un
  résultat, recalculer en Python ou via LibreOffice.
- Word : les champs (table des matières, numéros de page) se mettent à jour à l'ouverture ; le dire à l'utilisateur.
- PDF : un PDF scanné n'a pas de texte ; il faut une reconnaissance de caractères (OCR), à proposer, pas à imposer.
- Polices : utiliser des polices courantes (Calibri, Arial, Liberation) pour un rendu identique sur tous les PC.
