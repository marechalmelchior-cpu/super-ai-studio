---
name: brand-guidelines
description: Créer ou appliquer une charte graphique — couleurs, typographies, logo, iconographie, ton visuel — et la décliner sur des supports (site, affiche, réseaux, interface de jeu). À utiliser pour définir une identité visuelle ou rendre des visuels cohérents.
---

# Charte graphique

## Méthode
1. **Comprendre** : public, valeurs, trois mots qui décrivent l'image voulue, références aimées et détestées.
2. **Couleurs** : 1 couleur principale, 1 secondaire, 1 d'accent, des neutres. Codes HEX/RGB, contrastes vérifiés (texte lisible : contraste ≥ 4,5:1).
3. **Typographies** : 1 pour les titres, 1 pour le texte ; tailles et graisses ; licences vérifiées (Google Fonts ou licence achetée).
4. **Logo** : versions (couleur, monochrome, petite taille), zone de protection, interdits.
5. **Éléments** : icônes, formes, trames, style des images (photo, illustration, 3D).
6. **Déclinaisons** : montrer la charte sur 3 supports réels du projet.
7. **Livrer** : un document court (PDF ou page) + un fichier de variables (CSS ou JSON) réutilisable.

## Règles
- Toujours vérifier les contrastes et la lisibilité en petit.
- Pas de police ou d'image sans licence claire.
- Variables techniques nommées en anglais (--color-primary).
