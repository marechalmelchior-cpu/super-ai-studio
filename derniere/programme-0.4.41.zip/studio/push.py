"""Phone notifications (Web Push): a task awaits your validation or is blocked → notification, with
« Valider » right inside it when the review found nothing.

- Web Push standard with a VAPID key (ECDSA P-256, signed here in pure Python: nothing to install).
- Notification WITHOUT content: the phone's push service (the browser vendor's) sees neither title nor project; the
  phone fetches the details from the studio, over the VPN, with its paired device.
- Only known push services are contacted (those of the major browser vendors).
- data/push.json: VAPID private key (never displayed), phone subscriptions, tasks already notified.
"""
from __future__ import annotations

import base64
import hashlib
from .migrations import compatibility as json
import os
import secrets
import threading
import time
import urllib.error
import urllib.request
from .migrations.compatibility import TechnicalPath as Path
from urllib.parse import urlparse

TO_REPORT = {"awaiting_approval": "à valider", "awaiting_approval_with_defects": "à valider (défauts relevés)", "blocked": "bloquée",
              "failed": "en échec"}
SERVICES = ("fcm.googleapis.com", "updates.push.services.mozilla.com", "push.services.mozilla.com", "web.push.apple.com",
            ".notify.windows.com")
CONTACT = "https://github.com/marechalmelchior-cpu/super-ai-studio"
_lock = threading.Lock()

# ------------------------------------------------------------------ P-256 (ECDSA) in pure Python
P = 0xFFFFFFFF00000001000000000000000000000000FFFFFFFFFFFFFFFFFFFFFFFF
A = P - 3
N = 0xFFFFFFFF00000000FFFFFFFFFFFFFFFFBCE6FAADA7179E84F3B9CAC2FC632551
G = (0x6B17D1F2E12C4247F8BCE6E563A440F277037D812DEB33A0F4A13945D898C296,
     0x4FE342E2FE1A7F9B8EE7EB4A7C0F9E162BCE33576B315ECECBB6406837BF51F5)


def _add(p1, p2):
    if p1 is None:
        return p2
    if p2 is None:
        return p1
    (x1, y1), (x2, y2) = p1, p2
    if x1 == x2 and (y1 + y2) % P == 0:
        return None
    if p1 == p2:
        l = (3 * x1 * x1 + A) * pow(2 * y1, P - 2, P) % P
    else:
        l = (y2 - y1) * pow(x2 - x1, P - 2, P) % P
    x3 = (l * l - x1 - x2) % P
    return x3, (l * (x1 - x3) - y1) % P


def _multiply(k: int, pt=G):
    r = None
    while k:
        if k & 1:
            r = _add(r, pt)
        pt = _add(pt, pt)
        k >>= 1
    return r


def _b64(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode()


def public_key(d: int) -> bytes:
    x, y = _multiply(d)
    return b"\x04" + x.to_bytes(32, "big") + y.to_bytes(32, "big")


def sign(d: int, message: bytes) -> bytes:
    z = int.from_bytes(hashlib.sha256(message).digest(), "big")
    while True:
        k = secrets.randbelow(N - 1) + 1
        r = _multiply(k)[0] % N
        s = pow(k, N - 2, N) * (z + r * d) % N
        if r and s:
            return r.to_bytes(32, "big") + s.to_bytes(32, "big")


def check(pub: bytes, message: bytes, sig: bytes) -> bool:
    r, s = int.from_bytes(sig[:32], "big"), int.from_bytes(sig[32:], "big")
    if not (0 < r < N and 0 < s < N):
        return False
    z = int.from_bytes(hashlib.sha256(message).digest(), "big")
    w = pow(s, N - 2, N)
    q = (int.from_bytes(pub[1:33], "big"), int.from_bytes(pub[33:], "big"))
    pt = _add(_multiply(z * w % N), _multiply(r * w % N, q))
    return pt is not None and pt[0] % N == r


def vapid_token(d: int, endpoint: str, current_time: float | None = None) -> str:
    u = urlparse(endpoint)
    head = _b64(json.dumps({"typ": "JWT", "alg": "ES256"}, separators=(",", ":")).encode())
    content_body = _b64(json.dumps({"aud": f"{u.scheme}://{u.netloc}", "exp": int((current_time or time.time()) + 12 * 3600),
                             "sub": CONTACT}, separators=(",", ":")).encode())
    return f"{head}.{content_body}.{_b64(sign(d, f'{head}.{content_body}'.encode()))}"


# ------------------------------------------------------------------ state: key, subscriptions, notified tasks
def _file(data: Path) -> Path:
    return Path(data) / "push.json"


def read_file(data: Path) -> dict:
    try:
        d = json.loads(_file(data).read_text(encoding="utf-8"))
        if isinstance(d, dict) and d.get("vapid"):
            d.setdefault("subscriptions", [])
            d.setdefault("reported", {})
            return d
    except (OSError, ValueError):
        pass
    return {"vapid": "", "subscriptions": [], "reported": {}}


def _write(data: Path, d: dict) -> None:
    f = _file(data)
    f.parent.mkdir(parents=True, exist_ok=True)
    t = f.with_suffix(".tmp")
    t.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
    os.replace(t, f)


def _key(data: Path) -> int:
    with _lock:
        d = read_file(data)
        if not d["vapid"]:
            d["vapid"] = format(secrets.randbelow(N - 1) + 1, "064x")
            _write(data, d)
        return int(d["vapid"], 16)


def server_key(data: Path) -> str:
    """VAPID public key to give the browser (applicationServerKey)."""
    return _b64(public_key(_key(data)))


def known_service(endpoint: str) -> bool:
    u = urlparse(endpoint or "")
    h = (u.hostname or "").lower()
    return u.scheme == "https" and any(h == s.lstrip(".") or (s.startswith(".") and h.endswith(s)) for s in SERVICES)


def subscribe(data: Path, subscription: dict, device: str = "") -> dict:
    ep = str((subscription or {}).get("endpoint", ""))
    if not known_service(ep):
        raise ValueError("Service de notification inconnu : abonnement refusé.")
    _key(data)
    with _lock:
        d = read_file(data)
        d["subscriptions"] = [a for a in d["subscriptions"] if a["endpoint"] != ep] + [
            {"endpoint": ep, "device": device[:40], "added": time.strftime("%Y-%m-%d %H:%M")}]
        _write(data, d)
    return {"ok": True, "subscribers": len(d["subscriptions"])}


def unsubscribe(data: Path, endpoint: str) -> dict:
    with _lock:
        d = read_file(data)
        d["subscriptions"] = [a for a in d["subscriptions"] if a["endpoint"] != endpoint]
        _write(data, d)
    return {"ok": True}


def send(data: Path, sending=None) -> int:
    """Wakes each subscribed phone (content-free notification). Expired subscription (404/410): removed."""
    d = read_file(data)
    if not d["subscriptions"]:
        return 0
    key = _key(data)
    pub = server_key(data)
    ok, dead = 0, []
    for a in d["subscriptions"]:
        if not known_service(a["endpoint"]):
            dead.append(a["endpoint"])
            continue
        req = urllib.request.Request(a["endpoint"], data=b"", method="POST", headers={
            "Authorization": f"vapid t={vapid_token(key, a['endpoint'])}, k={pub}", "TTL": "86400", "Urgency": "high",
            "Content-Length": "0"})
        try:
            code = sending(req) if sending else urllib.request.urlopen(req, timeout=15).status
            ok += 1 if 200 <= code < 300 else 0
        except urllib.error.HTTPError as e:
            if e.code in (404, 410):
                dead.append(a["endpoint"])
        except OSError:
            pass
    if dead:
        with _lock:
            d = read_file(data)
            d["subscriptions"] = [a for a in d["subscriptions"] if a["endpoint"] not in dead]
            _write(data, d)
    return ok


def pending(studio, since_h: float = 48) -> list[dict]:
    """What the phone displays: tasks to validate or blocked (title, project, fingerprint for « Valider »)."""
    out = []
    limit = time.time() - since_h * 3600
    for t in studio.store.list(200):
        if t["status"] not in TO_REPORT:
            continue
        try:
            from datetime import datetime
            update_info = datetime.fromisoformat(str(t.get("updated_at", ""))).timestamp()
        except ValueError:
            update_info = time.time()
        if update_info < limit:
            continue
        e = {"tid": t["id"], "title": (t.get("title") or t["request"])[:90], "state": TO_REPORT[t["status"]],
             "status": t["status"], "target": t["target"]}
        if t["status"] == "awaiting_approval":
            try:
                s = studio.status(t["id"])
                if s.get("awaiting_decision") and s.get("fingerprint"):
                    e["fingerprint"] = s["fingerprint"]
            except Exception:                            # noqa: BLE001 — without fingerprint: « Ouvrir » only
                pass
        out.append(e)
    return out[:10]


def tick(studio, sending=None) -> int:
    """New tasks to notify since the last pass → one wake-up per phone. Returns the number of wake-ups."""
    d = read_file(studio.paths.data)
    if not d["subscriptions"]:
        return 0
    current = {t["id"]: t["status"] for t in studio.store.list(200) if t["status"] in TO_REPORT}
    new_items = [tid for tid, s in current.items() if d["reported"].get(tid) != s]
    with _lock:
        d = read_file(studio.paths.data)
        d["reported"] = current
        _write(studio.paths.data, d)
    return send(studio.paths.data, sending) if new_items else 0
