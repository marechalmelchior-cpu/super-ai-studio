"""Live transcript of an agent's session (the conversation file its AI tool writes while it works).

Gives the studio three things, read-only and without any extra call to the AI:
- the exact model really used (« Opus 4.7 », « GPT-5.5 »), not only the one asked for;
- a detailed journal: messages of the agent, files read or changed, searches, commands and their failures;
- the time of the last activity (an agent that works is never cut off; a silent one is).

Where the files are: Claude Code ~/.claude/projects/<dossier>/<session>.jsonl (session id chosen by the studio),
Codex ~/.codex/sessions/AAAA/MM/JJ/rollout-*.jsonl (found by working folder and start time).
The executor writes details/session-agent.json ({outil, session, dossier, debut}) before launching.
"""
from __future__ import annotations

from .migrations import compatibility as json
import os
import re
from datetime import datetime
from .migrations.compatibility import TechnicalPath as Path

from .security import redact

INFO = "session-agent.json"
REVIEW_INFO = "review-session.json"     # the reviewer's session, kept apart from the agent's
_MAX_READ = 4_000_000          # last 4 MB of a transcript at most


def write_info(details: Path, tool: str, session: str, folder: Path, begin: float, name: str = INFO) -> None:
    try:
        (details / name).write_text(json.dumps({"tool": tool, "session": session, "folder": str(folder),
                                                "begin": begin}), encoding="utf-8")
    except OSError:
        pass


def read_info(details: Path, name: str = INFO) -> dict:
    try:
        return json.loads((details / name).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def _secondary_cli_file(folder: str, begin: float, home: Path | None = None) -> Path | None:
    base = Path(os.environ.get("CODEX_HOME") or Path(home or Path.home()) / ".codex") / "sessions"
    target = os.path.normcase(os.path.abspath(folder))
    best = None
    for f in base.glob("*/*/*/rollout-*.jsonl"):
        try:
            if f.stat().st_mtime < begin - 60:
                continue
            with f.open(encoding="utf-8", errors="replace") as h:
                meta = json.loads(h.readline() or "{}").get("payload") or {}
        except (OSError, ValueError, AttributeError):
            continue
        if os.path.normcase(os.path.abspath(str(meta.get("cwd") or ""))) != target:
            continue
        if best is None or f.stat().st_mtime > best.stat().st_mtime:
            best = f
    return best


def locate(info: dict, home: Path | None = None) -> Path | None:
    """The transcript file of the session described by ``info``, or None while it does not exist yet."""
    if not info:
        return None
    if info.get("tool") == "claude" and re.fullmatch(r"[0-9a-f-]{36}", str(info.get("session") or "")):
        base = Path(home or Path.home()) / ".claude" / "projects"
        return next(iter(base.glob(f"*/{info['session']}.jsonl")), None)
    if info.get("tool") == "codex" and info.get("folder"):
        return _secondary_cli_file(info["folder"], float(info.get("begin") or 0), home)
    return None


def last_activity(details: Path, home: Path | None = None, name: str = INFO) -> float:
    """Most recent sign of life: the transcript or the studio's own logs of the task (commands, activity)."""
    paths = [details / n for n in ("activity.log", "commands.log", "unreal-actions.log")]
    t = locate(read_info(details, name), home)
    if t:
        paths.append(t)
    times = []
    for p in paths:
        try:
            times.append(p.stat().st_mtime)
        except OSError:
            continue
    return max(times, default=0.0)


def model_name(raw: str) -> str:
    """« claude-opus-4-7-20260101 » → « Opus 4.7 » ; « gpt-5.5-codex » → « GPT-5.5 Codex » ; otherwise as given."""
    r = (raw or "").strip()
    m = re.fullmatch(r"(?:claude-)?(opus|sonnet|haiku|fable|mythos)-(\d+)(?:[-.](\d{1,2}))?(?:-\d{8})?(?:\[.*\])?", r, re.I)
    if m:
        return f"{m.group(1).capitalize()} {m.group(2)}{'.' + m.group(3) if m.group(3) else ''}"
    m = re.fullmatch(r"(?:claude-)?(\d+)(?:-(\d+))?-(opus|sonnet|haiku)(?:-\d{8})?", r, re.I)     # older style claude-3-5-sonnet
    if m:
        return f"{m.group(3).capitalize()} {m.group(1)}{'.' + m.group(2) if m.group(2) else ''}"
    m = re.fullmatch(r"gpt-([\w.]+?)(-codex)?(-mini|-max)?", r, re.I)
    if m:
        return f"GPT-{m.group(1)}{' Codex' if m.group(2) else ''}{' ' + m.group(3)[1:].capitalize() if m.group(3) else ''}"
    return r


def _time(ts) -> float:
    """Epoch seconds of an ISO date (« Z » or offset = UTC; no offset = this PC's local time). 0 if unreadable."""
    try:
        return datetime.fromisoformat(str(ts).replace("Z", "+00:00")).timestamp()
    except ValueError:
        return 0.0


def _short(text: str, n: int = 280) -> str:
    t = " ".join(redact(str(text or "")).split())
    return t if len(t) <= n else t[: n - 1] + "…"


def _name(p) -> str:
    return Path(str(p or "").replace("\\", "/")).name or str(p or "")


def _tool(name: str, inp: dict) -> tuple[str, str, str]:
    """(kind, sentence, detail) for one tool call."""
    inp = inp if isinstance(inp, dict) else {}
    n = name or ""
    if n in ("Read", "NotebookRead"):
        return "file", f"Lit {_name(inp.get('file_path') or inp.get('notebook_path'))}", _short(inp.get("file_path"))
    if n in ("Edit", "MultiEdit", "NotebookEdit"):
        return "file", f"Modifie {_name(inp.get('file_path') or inp.get('notebook_path'))}", _short(inp.get("file_path"))
    if n == "Write":
        return "file", f"Écrit {_name(inp.get('file_path'))}", _short(inp.get("file_path"))
    if n in ("Grep", "Glob"):
        return "file", f"Cherche « {_short(inp.get('pattern'), 60)} »", _short(inp.get("path") or "")
    if n in ("Bash", "PowerShell"):
        desc = inp.get("description") or ""
        return "command", desc and _short(desc, 120) or "Lance une commande", _short(inp.get("command"), 400)
    if n == "Skill":
        name = inp.get("skill") or inp.get("name") or inp.get("command") or ""
        return "tool", f"Utilise la skill « {_short(name, 60)} »", _short(inp.get("args") or "", 200)
    if n == "WebSearch":
        return "tool", f"Cherche sur le web « {_short(inp.get('query'), 80)} »", ""
    if n == "WebFetch":
        return "tool", "Lit une page web", _short(inp.get("url"), 300)
    if n in ("Task", "Agent"):
        return "tool", f"Confie une partie du travail à un sous-agent : {_short(inp.get('description') or inp.get('prompt'), 80)}", ""
    if n.startswith("mcp__"):
        parts = n.split("__")
        return "tool", f"Outil {parts[1] if len(parts) > 1 else n} : {parts[-1].replace('_', ' ')}", _short(json.dumps(inp, ensure_ascii=False), 300)
    if n == "TodoWrite":
        return "message", "Organise son travail (liste d'étapes)", ""
    return "tool", f"Outil {n}", _short(json.dumps(inp, ensure_ascii=False), 300)


SEARCH_PROGRAMS = {"grep", "egrep", "fgrep", "rg", "findstr", "select-string", "diff", "cmp", "test", "["}


def _search_miss(entry: dict, content) -> int:
    """Exit code 1 of a search or comparison (grep found nothing, files differ): normal, not a failure.
    Returns 1 in that case, 0 otherwise."""
    if entry.get("category_kind") != "command":
        return 0
    text = content if isinstance(content, str) else " ".join(
        str(x.get("text") or "") for x in content or [] if isinstance(x, dict))
    m = re.match(r"\s*Exit code (\d+)", text or "")
    if not m or m.group(1) != "1":
        return 0
    last = re.split(r"\|\||&&|[;|\n]", entry.get("detail") or "")
    words = [w for w in (last[-1] if last else "").split() if not re.match(r"^[A-Za-z_]\w*=", w)]
    if not words and len(last) > 1:
        words = last[-2].split()
    prog = re.sub(r"\.(exe|cmd)$", "", words[0].replace("\\", "/").rsplit("/", 1)[-1].lower()) if words else ""
    return 1 if prog in SEARCH_PROGRAMS or prog in {"head", "wc", "sort"} and re.search(r"\b(grep|rg|findstr)\b", entry.get("detail") or "") else 0


def _primary_cli(lines: list[str]) -> tuple[str, list[dict]]:
    model, out, pending = "", [], {}
    for line in lines:
        try:
            ev = json.loads(line)
        except ValueError:
            continue
        msg = ev.get("message") if isinstance(ev.get("message"), dict) else {}
        h = _time(ev.get("timestamp"))
        if ev.get("type") == "assistant":
            if msg.get("model") and not str(msg["model"]).startswith("<"):
                model = msg["model"]
            for c in msg.get("content") or []:
                if not isinstance(c, dict):
                    continue
                if c.get("type") == "text" and str(c.get("text") or "").strip():
                    out.append({"t": h, "category_kind": "message", "text": _short(c["text"]), "detail": ""})
                elif c.get("type") == "tool_use":
                    kind, text, detail = _tool(c.get("name", ""), c.get("input") or {})
                    out.append({"t": h, "category_kind": kind, "text": text, "detail": detail, "tool": c.get("name", ""),
                                **({"skill": str((c.get("input") or {}).get("skill") or "")} if c.get("name") == "Skill" else {})})
                    pending[c.get("id")] = len(out) - 1
        elif ev.get("type") == "user":
            for c in msg.get("content") or [] if isinstance(msg.get("content"), list) else []:
                if isinstance(c, dict) and c.get("type") == "tool_result" and c.get("is_error"):
                    i = pending.get(c.get("tool_use_id"))
                    if i is not None:
                        code = _search_miss(out[i], c.get("content"))
                        out[i].update({"code_output": code} if code else {"failed": True})
    return model, out


def _secondary_cli(lines: list[str]) -> tuple[str, list[dict]]:
    model, out = "", []
    for line in lines:
        try:
            ev = json.loads(line)
        except ValueError:
            continue
        p = ev.get("payload") if isinstance(ev.get("payload"), dict) else {}
        h = _time(ev.get("timestamp"))
        typ = ev.get("type")
        if typ == "turn_context" and p.get("model"):
            model = p["model"]
        elif typ == "session_meta" and p.get("model") and not model:
            model = p["model"]
        elif typ == "response_item":
            if p.get("type") == "message" and p.get("role") == "assistant":
                text = " ".join(str(c.get("text") or "") for c in p.get("content") or [] if isinstance(c, dict))
                if text.strip():
                    out.append({"t": h, "category_kind": "message", "text": _short(text), "detail": ""})
            elif p.get("type") in ("function_call", "local_shell_call", "custom_tool_call"):
                try:
                    args = json.loads(p.get("arguments") or "{}") if isinstance(p.get("arguments"), str) else (p.get("arguments") or {})
                except ValueError:
                    args = {}
                cmd = args.get("command") or (p.get("action") or {}).get("command") or args.get("cmd") or ""
                if isinstance(cmd, list):
                    cmd = " ".join(map(str, cmd))
                name = p.get("name") or "shell"
                server = p.get("server") or (name.split("__")[1] if name.startswith("mcp__") and "__" in name[5:] else "")
                if server:
                    out.append({"t": h, "category_kind": "tool", "text": f"Outil {server} : {name.split('__')[-1].replace('_', ' ')}",
                                "detail": _short(json.dumps(args, ensure_ascii=False), 300), "tool": f"mcp__{server}__{name.split('__')[-1]}"})
                elif name in ("shell", "exec_command", "local_shell") or cmd:
                    out.append({"t": h, "category_kind": "command", "text": "Lance une commande", "detail": _short(cmd, 400), "tool": "Bash"})
                elif name == "apply_patch":
                    files = re.findall(r"\*\*\* (?:Update|Add) File: (.+)", str(p.get("input") or args.get("input") or ""))
                    out.append({"t": h, "category_kind": "file", "text": "Modifie " + ", ".join(_name(f) for f in files[:3]) if files
                                else "Modifie des fichiers", "detail": ""})
                else:
                    out.append({"t": h, "category_kind": "tool", "text": f"Outil {name}", "detail": _short(json.dumps(args, ensure_ascii=False), 300)})
    return model, out


_CACHE: dict = {}


def read(details: Path, home: Path | None = None, name: str = INFO) -> dict:
    """{"modele": "Opus 4.7" | "", "modele_id": raw id, "entrees": [{t, genre, texte, detail, echec?}…]}"""
    info = read_info(details, name)
    f = locate(info, home)
    if not f:
        return {"model": "", "model_id": "", "inputs": []}
    try:
        st = f.stat()
        key = (str(f), st.st_size, st.st_mtime_ns)
        if key in _CACHE:                        # read again only when the conversation grew
            return _CACHE[key]
        size = st.st_size
        with f.open("rb") as h:
            if size > _MAX_READ:
                h.seek(size - _MAX_READ)
                h.readline()
            lines = h.read().decode("utf-8", errors="replace").splitlines()
    except OSError:
        return {"model": "", "model_id": "", "inputs": []}
    model, entries = (_primary_cli if info.get("tool") == "claude" else _secondary_cli)(lines)
    out = {"model": model_name(model), "model_id": model, "inputs": entries}
    if len(_CACHE) > 32:
        _CACHE.clear()
    _CACHE[key] = out
    return out
