import sys
from pathlib import Path

from .python_env import relaunch_if_needed

# After an update that brought new Python components: run with the prepared (and checked) environment.
code = relaunch_if_needed(Path(__file__).resolve().parents[1], sys.argv[1:])
if code is not None:
    sys.exit(code)

from .cli import main  # noqa: E402

sys.exit(main())
