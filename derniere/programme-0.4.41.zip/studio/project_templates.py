"""Project templates: « Créer un site », « Créer un jeu »… in one click, the agent team, the mode and the starting context.

A template only configures the project (active roles, mode, starting CONTEXTE.md): everything stays editable afterwards
in the Équipe tab and the project record. Nothing is downloaded, nothing is deleted.
"""
from __future__ import annotations

MODELS = {
    "site": {
        "name": "Site web", "type": "web", "profile": "normal",
        "roles": ["web-developer", "ui-designer", "ui-ux", "seo-content", "accessibility", "qa", "producer", "build-publication"],
        "context": "Site web. À préciser : public visé, pages principales, style souhaité, hébergement prévu.\n"
                    "Par défaut : HTML/CSS/JS simples, rapides et accessibles, qui marchent sur téléphone.",
    },
    "game": {
        "name": "Jeu vidéo", "type": "code", "profile": "performance",
        "roles": ["game-designer", "programmer", "level-designer", "art-director", "illustrator", "sound-designer",
                  "writer", "balancing", "qa", "producer"],
        "context": "Jeu vidéo. À préciser : moteur (Godot, Unity, Unreal, web…), genre, plateforme, ambiance.\n"
                    "Par défaut : une petite version jouable d'abord, puis on enrichit.",
    },
    "app": {
        "name": "Application ou logiciel", "type": "code", "profile": "normal",
        "roles": ["programmer", "web-developer", "ui-designer", "ui-ux", "qa", "data-security", "documentation", "producer",
                  "build-publication"],
        "context": "Application ou logiciel. À préciser : ce qu'elle doit faire, pour qui, sur quel appareil, langage souhaité.\n"
                    "Par défaut : code simple et testé, un README pour l'installer et s'en servir.",
    },
    "document": {
        "name": "Document ou étude", "type": "doc", "profile": "normal",
        "roles": ["researcher", "documentation", "writer", "localization", "producer"],
        "context": "Document, étude ou recherche. À préciser : sujet, public, longueur, format attendu (Word, PDF, page web…).\n"
                    "Par défaut : sources citées, faits vérifiés, texte clair.",
    },
    "visuals": {
        "name": "Images et visuels", "type": "art", "profile": "normal",
        "roles": ["art-director", "illustrator", "technical-artist", "technical-artist", "ui-designer", "producer"],
        "context": "Images et visuels (illustrations, logos, concept arts, affiches). À préciser : usage, style, formats.\n"
                    "Par défaut : plusieurs pistes proposées avant de finaliser.",
    },
}


def entries() -> list[dict]:
    return [{"id": k, "name": v["name"]} for k, v in MODELS.items()]


def apply(studio, target: str, model: str) -> dict:
    """Configures a freshly created project from the template: active roles, mode, starting context."""
    from . import teams
    m = MODELS.get(model)
    if not m:
        raise ValueError("Modèle de projet inconnu.")
    t = studio.registry.get(target)
    key = f"{t.kind}:{t.id}"
    keep = set(m["roles"])
    d = teams.read_file(studio.paths.data)
    roles = d.setdefault(key, {}).setdefault("roles", {})
    for r in studio.roles.values():
        if r.id == "reviewer" or (r.projects_list and key not in r.projects_list):
            continue
        if r.id in keep:
            if roles.get(r.id) == {"active": False}:
                roles.pop(r.id)
        else:
            roles[r.id] = {**roles.get(r.id, {}), "active": False}
    teams._write(studio.paths.data, d)
    studio.set_project_profile(key, m["profile"])
    ctx = t.file.parent / "CONTEXTE.md" if t.file else None
    if ctx is not None and ctx.exists() and "À compléter par l'utilisateur" in ctx.read_text(encoding="utf-8"):
        ctx.write_text(f"# {t.name}\n\n{m['context']}\n", encoding="utf-8")       # only the starting text, freshly created
    return {"model": model, "roles": sorted(keep & set(studio.roles)), "profile": m["profile"]}
