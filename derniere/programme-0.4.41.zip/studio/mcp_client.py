"""Studio MCP client: the MCP servers from Extensions also serve API-key and local agents (Ollama…).

The subscription tools start their own servers (the studio passes them the task's list). For other
models, this client talks to the servers and presents their tools to the model (« mcp__serveur__outil »).

Performance:
- each server's tool list is cached in data/mcp-outils.json (keyed by its configuration): a task
  starts no server just to learn what it offers;
- a server starts only on the first call to one of its tools, stays open during the task, then is closed;
- descriptions truncated, tool count capped: the mission stays light for small local models.

Security: only servers installed by the user (data/mcp.json) and enabled for the project; keys come
from data/mcp-secrets.json (encrypted), never written elsewhere; what a server returns is data, not an order.
"""
from __future__ import annotations

import hashlib
from .migrations import compatibility as json
import os
import queue
import re
import shutil
import subprocess
import sys
import threading
import urllib.request
from .migrations.compatibility import TechnicalPath as Path

PROTOCOL = "2025-06-18"
MAX_TOOLS = 60
MAX_DESC = 300
MAX_RESULT = 20_000
_VAR = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)\}")


def _expand(v, env: dict):
    if isinstance(v, str):
        return _VAR.sub(lambda m: env.get(m.group(1), ""), v)
    if isinstance(v, list):
        return [_expand(x, env) for x in v]
    if isinstance(v, dict):
        return {k: _expand(x, env) for k, x in v.items()}
    return v


def tool_name(srv: str, tool: str) -> str:
    """Name accepted by every provider (letters, digits, _ and -, 64 at most)."""
    n = re.sub(r"[^A-Za-z0-9_-]", "_", f"mcp__{srv}__{tool}")
    return n if len(n) <= 64 else n[:55] + "_" + hashlib.sha1(n.encode()).hexdigest()[:8]


def fingerprint(conf: dict) -> str:
    return hashlib.sha256(json.dumps(conf, sort_keys=True).encode()).hexdigest()[:16]


class McpServer:
    """An MCP server: local (stdio) or remote (« streamable » HTTP)."""

    def __init__(self, name: str, conf: dict, env: dict, delay: float = 60):
        self.name, self.conf, self.delay = name, conf, delay
        from .security import agent_env
        self.env = {**agent_env(), **env}            # the PC's environment without its secrets, plus this server's own keys
        self.proc = None
        self.file: queue.Queue = queue.Queue()
        self.n = 0
        self.session = ""
        self.mutex = threading.Lock()

    # -- transport
    def _http(self, msg: dict, wait_for: bool = True) -> dict | None:
        url = _expand(self.conf.get("url", ""), self.env)
        if not url.startswith(("https://", "http://127.0.0.1", "http://localhost")):
            raise RuntimeError("adresse refusée (https seulement, ou ce PC)")
        h = {"Content-Type": "application/json", "Accept": "application/json, text/event-stream",
             **{k: v for k, v in _expand(self.conf.get("headers", {}), self.env).items() if v}}
        if self.session:
            h["Mcp-Session-Id"] = self.session
        req = urllib.request.Request(url, data=json.dumps(msg).encode(), headers=h, method="POST")
        with urllib.request.urlopen(req, timeout=self.delay) as r:
            self.session = r.headers.get("Mcp-Session-Id") or self.session
            content_body = r.read().decode("utf-8", "replace")
            if not wait_for or not content_body.strip():
                return None
            if "text/event-stream" in (r.headers.get("Content-Type") or ""):
                for line in content_body.splitlines():
                    if line.startswith("data:"):
                        d = json.raw_loads(line[5:].strip())
                        if d.get("id") == msg.get("id"):
                            return d
                return None
            return json.raw_loads(content_body)

    def _read(self):
        for line in self.proc.stdout:
            self.file.put(line)
        self.file.put(None)

    def _start(self) -> None:
        cmd = [_expand(self.conf.get("command", ""), self.env), *[str(x) for x in _expand(self.conf.get("args", []), self.env)]]
        exe = shutil.which(cmd[0]) or cmd[0]              # npx → npx.cmd on Windows
        env = {**self.env, **{k: str(v) for k, v in _expand(self.conf.get("env", {}), self.env).items()}}
        opts = {"creationflags": 0x08000000} if sys.platform == "win32" else {}
        self.proc = subprocess.Popen([exe, *cmd[1:]], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                                     env=env, text=True, encoding="utf-8", errors="replace", bufsize=1, **opts)
        threading.Thread(target=self._read, daemon=True).start()

    def _send_rpc(self, rpc_method: str, params: dict | None = None, notification: bool = False) -> dict | None:
        msg = {"jsonrpc": "2.0", "method": rpc_method, **({"params": params} if params is not None else {})}
        if not notification:
            self.n += 1
            msg["id"] = self.n
        if self.conf.get("url"):
            r = self._http(msg, not notification)
        else:
            self.proc.stdin.write(json.dumps(msg) + "\n")
            self.proc.stdin.flush()
            if notification:
                return None
            r = None
            while True:
                try:
                    line = self.file.get(timeout=self.delay)
                except queue.Empty:
                    raise RuntimeError(f"le serveur {self.name} ne répond pas") from None
                if line is None:
                    raise RuntimeError(f"le serveur {self.name} s'est arrêté")
                try:
                    d = json.raw_loads(line)
                except ValueError:
                    continue                                 # server log on stdout: ignored
                if d.get("id") == msg["id"]:
                    r = d
                    break
        if r and r.get("error"):
            raise RuntimeError(str(r["error"].get("message", r["error"]))[:300])
        return (r or {}).get("result")

    # -- protocol
    def open_(self) -> None:
        with self.mutex:
            if self.proc is not None or self.session:
                return
            if not self.conf.get("url"):
                self._start()
            self._send_rpc("initialize", {"protocolVersion": PROTOCOL, "capabilities": {},
                                         "clientInfo": {"name": "super-ai-studio", "version": "1"}})
            self._send_rpc("notifications/initialized", notification=True)

    def allowed_tools(self) -> list[dict]:
        self.open_()
        out, cursor = [], None
        for _ in range(10):
            r = self._send_rpc("tools/list", {"cursor": cursor} if cursor else {}) or {}
            out += r.get("tools", [])
            cursor = r.get("nextCursor")
            if not cursor:
                break
        return out

    def call_out(self, tool: str, args: dict) -> str:
        self.open_()
        r = self._send_rpc("tools/call", {"name": tool, "arguments": args or {}}) or {}
        chunks = []
        for b in r.get("content", []):
            if b.get("type") == "text":
                chunks.append(b.get("text", ""))
            elif b.get("type") == "resource":
                chunks.append(str((b.get("resource") or {}).get("text", ""))[:4000])
            else:
                chunks.append(f"[{b.get('type', 'content')} non affichable ici]")
        t = "\n".join(chunks) or ("(aucun résultat)" if not r.get("isError") else "Erreur sans détail.")
        t = ("ERREUR : " if r.get("isError") else "") + t
        return t[:MAX_RESULT] + ("\n… (tronqué)" if len(t) > MAX_RESULT else "")

    def shut(self) -> None:
        p, self.proc = self.proc, None
        if p is not None:
            try:
                p.stdin.close()
                p.terminate()
                p.wait(timeout=5)
            except Exception:                              # noqa: BLE001
                try:
                    p.kill()
                except Exception:                          # noqa: BLE001
                    pass


class McpToolbox:
    """MCP servers of a task for an API model: tool definitions (cached) and calls (started on demand)."""

    def __init__(self, data: Path, active_items: list[str] | None = None, startup=McpServer):
        from .library import env_mcp, installed_mcp
        self.data = Path(data)
        all_items = installed_mcp(self.data)
        self.confs = {n: c for n, c in all_items.items() if active_items is None or n in active_items}
        self.env = env_mcp(self.data) if self.confs else {}
        self.startup = startup
        self.open_items: dict[str, McpServer] = {}
        self.card: dict[str, tuple[str, str]] = {}
        self.error_list: list[str] = []

    def _server(self, name: str) -> McpServer:
        if name not in self.open_items:
            self.open_items[name] = self.startup(name, self.confs[name], self.env)
        return self.open_items[name]

    def _cache(self) -> dict:
        try:
            d = json.normalize_mcp_cache(json.raw_loads((self.data / "mcp-tools.json").read_text(encoding="utf-8")))
            return d if isinstance(d, dict) else {}
        except (OSError, ValueError):
            return {}

    def definitions(self) -> list[dict]:
        """Tools in « function » format (OpenAI/Ollama/OpenRouter). List read from the cache; a server not yet
        known is queried once, then remembered."""
        if not self.confs:
            return []
        cache, change, defs = self._cache(), False, []
        for name, conf in sorted(self.confs.items()):
            e = fingerprint(conf)
            allowed_tools = (cache.get(name) or {}).get("tools") if (cache.get(name) or {}).get("fingerprint") == e else None
            if allowed_tools is None:
                try:
                    allowed_tools = [{"name": o.get("name", ""), "description": str(o.get("description", ""))[:MAX_DESC],
                               "inputSchema": o.get("inputSchema") or {"type": "object", "properties": {}}}
                              for o in self._server(name).allowed_tools() if o.get("name")]
                    cache[name] = {"fingerprint": e, "tools": allowed_tools}
                    change = True
                except Exception as ex:                    # noqa: BLE001 — server missing: the task continues without it
                    self.error_list.append(f"{name} : {str(ex)[:160]}")
                    continue
            for o in allowed_tools:
                n = tool_name(name, o["name"])
                self.card[n] = (name, o["name"])
                schema = o["inputSchema"] if isinstance(o.get("inputSchema"), dict) else {"type": "object", "properties": {}}
                schema.setdefault("type", "object")
                schema.setdefault("properties", {})
                defs.append({"type": "function", "function": {"name": n, "description": f"[{name}] {o['description']}",
                                                              "parameters": schema}})
        if change:
            try:
                t = self.data / "mcp-tools.tmp"
                t.write_text(json.dumps(cache, ensure_ascii=False), encoding="utf-8")
                t.replace(self.data / "mcp-tools.json")
            except OSError:
                pass
        return defs[:MAX_TOOLS]

    def knows(self, name: str) -> bool:
        return name in self.card

    def call_out(self, name: str, args: dict) -> str:
        srv, tool = self.card[name]
        try:
            return self._server(srv).call_out(tool, args)
        except Exception as ex:                            # noqa: BLE001 — the agent sees the error and adapts
            return f"Échec du serveur {srv} : {str(ex)[:300]}"

    def shut(self) -> None:
        for s in self.open_items.values():
            s.shut()
        self.open_items.clear()


# ------------------------------------------------------------------ command-line tool: servers passed on the command
def _toml(v) -> str:
    return json.dumps(v, ensure_ascii=False)              # JSON strings and lists = valid TOML values


def options_secondary_cli(confs: dict, mem: dict | None = None) -> tuple[list[str], list[str]]:
    """« -c mcp_servers.<name>.… » for one run of the command-line tool (nothing is written to its configuration).
    Keys are never on the command line: only the NAME of the variables (env_vars, bearer_token_env_var);
    their values go through the process environment. Returns (options, server names)."""
    opts, names = [], []
    everything = {**confs, **({"studio-memory": mem} if mem else {})}
    for name, c in sorted(everything.items()):
        if not re.fullmatch(r"[A-Za-z0-9_-]{1,40}", name):
            continue
        base = f"mcp_servers.{name}"
        if c.get("url"):
            opts += ["-c", f"{base}.url={_toml(c['url'])}"]
            auth = str((c.get("headers") or {}).get("Authorization", ""))
            m = re.fullmatch(r"Bearer \$\{([A-Za-z_][A-Za-z0-9_]*)\}", auth)
            if m:
                opts += ["-c", f"{base}.bearer_token_env_var={_toml(m.group(1))}"]
        elif c.get("command"):
            opts += ["-c", f"{base}.command={_toml(c['command'])}", "-c", f"{base}.args={_toml([str(a) for a in c.get('args', [])])}"]
            env = c.get("env") or {}
            fixes = {k: v for k, v in env.items() if not _VAR.search(str(v))}
            variables = sorted({m for v in env.values() for m in _VAR.findall(str(v))} | {k for k, v in env.items() if _VAR.search(str(v))})
            if fixes:
                opts += ["-c", f"{base}.env={{{', '.join(f'{json.dumps(k)} = {_toml(str(v))}' for k, v in fixes.items())}}}"]
            if variables:
                opts += ["-c", f"{base}.env_vars={_toml(variables)}"]
        else:
            continue
        opts += ["-c", f'{base}.default_tools_approval_mode="approve"', "-c", f"{base}.startup_timeout_sec=60"]
        if name == "studio-memory":
            opts += ["-c", f'{base}.enabled_tools=["memory_search", "memory_conflicts", "memory_state", "create_image", "create_voice"]']
        names.append(name)
    return opts, names


def memory_server() -> dict:
    """« studio-memoire » server (read-only for agents): the studio's Python, no download."""
    code = str(Path(__file__).resolve().parents[1])
    return {"command": sys.executable, "args": ["-m", "studio.mcp_server"],
            "env": {"PYTHONPATH": code, "STUDIO_MCP_CLIENT": "agent", "PYTHONUTF8": "1"}}
