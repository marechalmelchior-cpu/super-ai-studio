"""Everything that differs between operating systems (Windows, Mac, Linux), in one place."""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
from .migrations.compatibility import TechnicalPath as Path


def open_(path_value: Path | str) -> None:
    """Opens a file or folder with the system application (Explorer, Finder, file manager)."""
    if sys.platform == "win32":
        os.startfile(str(path_value))  # noqa: S606 — paths checked by the caller
    elif sys.platform == "darwin":
        subprocess.Popen(["open", str(path_value)], start_new_session=True)
    elif shutil.which("xdg-open"):
        subprocess.Popen(["xdg-open", str(path_value)], start_new_session=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    else:
        raise OSError("Aucune application pour ouvrir ce fichier (xdg-open absent).")


def browser_app() -> str | None:
    """Browser able to open the studio as an app window (--app): Edge, Chrome, Chromium, Brave."""
    if sys.platform == "win32":
        for base in (os.environ.get("ProgramFiles(x86)"), os.environ.get("ProgramFiles"), os.environ.get("LOCALAPPDATA")):
            for rel in ("Microsoft/Edge/Application/msedge.exe", "Google/Chrome/Application/chrome.exe"):
                if base and (Path(base) / rel).is_file():
                    return str(Path(base) / rel)
        return shutil.which("msedge") or shutil.which("chrome")
    if sys.platform == "darwin":
        for app in ("Microsoft Edge", "Google Chrome", "Chromium", "Brave Browser"):
            p = Path("/Applications") / f"{app}.app" / "Contents" / "MacOS" / app
            if p.is_file():
                return str(p)
        return None
    for name in ("microsoft-edge", "microsoft-edge-stable", "google-chrome", "google-chrome-stable", "chromium", "chromium-browser", "brave-browser"):
        if shutil.which(name):
            return shutil.which(name)
    return None


def complete_path() -> None:
    """Mac and Linux: when launched from the Finder or a menu, the studio does not always inherit the terminal's PATH.
    Adds the folders where the AI command-line tools, Node, Ollama and Homebrew install (removing nothing)."""
    if sys.platform == "win32":
        return
    home = Path.home()
    extra_paths = [home / ".local/bin", home / ".npm-global/bin", home / ".claude/local", Path("/opt/homebrew/bin"),
               Path("/usr/local/bin"), home / ".volta/bin", home / ".bun/bin"]
    current = os.environ.get("PATH", "").split(os.pathsep)
    addition = [str(p) for p in extra_paths if p.is_dir() and str(p) not in current]
    if addition:
        os.environ["PATH"] = os.pathsep.join(current + addition)
