"""Shared agent toolbox: skills, shared memory and MCP servers for ALL models.

- The subscription tools read their skills from their own folders (« studio-* » copies, kept up to date
  automatically: see ``skills_a_jour``). Other models (API key, aggregators, local models…) get them here: the short
  list (name and description) in the mission, and the ``lire_skill`` tool to open the one needed (on-demand loading:
  the mission stays light, even for a small local model).
- Memory: each one gets the relevant memories in its mission and can search for more during the task
  (read-only; writes are still made by the studio after validation).
- Single source: Studio/Skills (and the project's .claude/skills). Nothing is ever deleted or overwritten outside the
  « studio-* » copies marked by the studio.
"""
from __future__ import annotations

import hashlib
import re
from .migrations.compatibility import TechnicalPath as Path

RESERVED = "supervisor"                     # Supervisor's method: never given to agents
MAX_SKILL = 60_000
_cache: dict[str, tuple[float, dict]] = {}


def _header(md: Path) -> dict:
    """name / description from SKILL.md (cached by file date)."""
    try:
        mt = md.stat().st_mtime
    except OSError:
        return {}
    c = _cache.get(str(md))
    if c and c[0] == mt:
        return c[1]
    t = md.read_text(encoding="utf-8", errors="replace")[:4000]
    m = re.match(r"(?s)^---\s*\n(.*?)\n---", t)
    block = m.group(1) if m else ""
    read_file = lambda k: (re.search(rf"(?m)^{k}:\s*(.+)$", block) or [None, ""])[1].strip().strip("\"'")   # noqa: E731
    d = {"name": read_file("name") or md.parent.name, "description": read_file("description")}
    _cache[str(md)] = (mt, d)
    return d


def available_skills(studio_root: Path, project_folder: Path | None = None) -> list[dict]:
    """Studio skills, then project skills (project ones take precedence on equal names)."""
    views: dict[str, dict] = {}
    sources = [(Path(studio_root) / "Skills", "studio")]
    if project_folder:
        sources.append((Path(project_folder) / ".claude" / "skills", "project"))
    for base, origin in sources:
        if not base.is_dir():
            continue
        for d in sorted(base.iterdir()):
            md = d / "SKILL.md"
            if d.name == RESERVED or not md.is_file():
                continue
            e = _header(md)
            views[d.name] = {"id": d.name, "name": e.get("name") or d.name, "description": e.get("description", ""),
                            "folder": d, "origin": origin}
    return list(views.values())


def skills_summary(skills: list[dict], max_chars: int = 3000) -> str:
    """Short list for the mission: one line per skill, truncated to stay light."""
    rows, total = [], 0
    for s in skills:
        l = f"- {s['id']} : {(s['description'] or s['name'])[:170]}"
        if total + len(l) > max_chars:
            rows.append(f"- … et {len(skills) - len(rows)} autre(s) : lire_skill avec le nom exact.")
            break
        rows.append(l)
        total += len(l)
    return "\n".join(rows)


def read_skill(skills: list[dict], name: str, file: str = "") -> str:
    """SKILL.md (or a skill file: references, templates); never outside the skill folder."""
    s = next((x for x in skills if x["id"] == name or x["name"] == name), None)
    if not s:
        return "Skill inconnue. Skills disponibles : " + ", ".join(x["id"] for x in skills[:60])
    rel = (file or "SKILL.md").replace("\\", "/").strip().lstrip("/")
    if ".." in Path(rel).parts or re.match(r"^[A-Za-z]:", rel):
        return "Refusé : chemin hors de la skill."
    p = (s["folder"] / rel).resolve()
    try:
        p.relative_to(s["folder"].resolve())
    except ValueError:
        return "Refusé : chemin hors de la skill."
    if p.is_dir():
        return "\n".join(sorted(x.relative_to(s["folder"]).as_posix() + ("/" if x.is_dir() else "")
                                for x in p.rglob("*") if "__pycache__" not in x.parts)[:300]) or "(vide)"
    if not p.is_file():
        return "Fichier introuvable dans la skill. Fichiers : " + read_skill(skills, name, ".")[:1500]
    t = p.read_text(encoding="utf-8", errors="replace")
    return t[:MAX_SKILL] + ("\n… (tronqué)" if len(t) > MAX_SKILL else "")


def search_memory(memory, query: str, scope_list: list[str], limit: int = 10) -> str:
    """Memories from shared memory (task scopes + general), read-only."""
    from .memory import Scope
    try:
        recs = memory.recall(str(query or "")[:300], [Scope.parse(p) for p in scope_list if p], True, max(1, min(int(limit), 20)))
    except Exception as e:                               # noqa: BLE001 — memory down: the agent says so and continues
        return f"Mémoire indisponible : {str(e)[:200]}"
    if not recs:
        return "Aucun souvenir pour cette recherche."
    return "\n".join(f"- [{r.scope.label}] {r.content}" for r in recs)


# ------------------------------------------------------------------ copies for the subscription tools: automatic
def signature_skills(studio_root: Path) -> str:
    """Quick fingerprint of the Skills folder (names, sizes, dates): a few milliseconds, without reading the files."""
    h = hashlib.sha256()
    base = Path(studio_root) / "Skills"
    if base.is_dir():
        for p in sorted(base.rglob("*")):
            if p.is_file() and "__pycache__" not in p.parts and p.name != ".import.json":
                try:
                    st = p.stat()
                except OSError:
                    continue
                h.update(f"{p.relative_to(base).as_posix()}|{st.st_size}|{int(st.st_mtime)}\n".encode())
    return h.hexdigest()[:24]


def skills_up_to_date(studio_root: Path, data: Path, home: Path | None = None, force: bool = False) -> list[str]:
    """Copy the studio skills to the subscription tools ONLY if the Skills folder has changed since last
    time (fingerprint kept in data/skills-signature.txt). Same guarantees as the manual copy: only
    « studio-* » folders marked by the studio are written; nothing is deleted or overwritten elsewhere."""
    from .initial_import import track
    from .supervisor import sync_skills
    tracking = []
    try:                                                  # skills and .md taken from the PC: modified outside the studio?
        s = track(studio_root, data, home)
        tracking = [f"{n} modifiée dans ton dossier : mise à jour proposée (Gestion › Skills et documents)" for n in s["proposals"]]
    except OSError:
        pass
    sig = signature_skills(studio_root)
    f = Path(data) / "skills-signature.txt"
    try:
        if not force and f.read_text(encoding="utf-8").strip() == sig:
            return tracking
    except OSError:
        pass
    report = sync_skills(Path(studio_root), home)
    try:
        f.parent.mkdir(parents=True, exist_ok=True)
        t = f.with_suffix(".tmp")
        t.write_text(sig, encoding="utf-8")
        t.replace(f)
    except OSError:
        pass
    return tracking + [x for x in report if x != "Déjà à jour."]


# ------------------------------------------------------------------ instruction files (.md): one per project
INSTRUCTION_NAMES = ("CLAUDE.md", "AGENTS.md")
_IGNORED = {".git", "node_modules", ".venv", "venv", "__pycache__", "Library", "Intermediate", "Binaries", "DerivedDataCache",
            "Saved", "build", "dist", ".godot", ".import", ".claude", ".agents"}
MAX_INSTRUCTIONS = 12_000


def instruction_files(folder: Path, depth: int = 3, maximum: int = 40) -> list[Path]:
    """The project's CLAUDE.md and AGENTS.md (root and nearby subfolders), without walking heavy folders."""
    out: list[Path] = []
    folder = Path(folder)

    def visit(d: Path, n: int):
        if len(out) >= maximum:
            return
        for name in INSTRUCTION_NAMES:
            if (d / name).is_file():
                out.append(d / name)
        if n >= depth:
            return
        try:
            subdir = sorted(x for x in d.iterdir() if x.is_dir() and x.name not in _IGNORED and not x.name.startswith("."))
        except OSError:
            return
        for x in subdir:
            visit(x, n + 1)
    if folder.is_dir():
        visit(folder, 0)
    return out


def instructions_for(executor: str, folder: Path | None) -> tuple[str, list[str]]:
    """What the executor does not read on its own. Each subscription tool reads its own file (CLAUDE.md, or AGENTS.md
    with CLAUDE.md as fallback, set at launch): it only gets what is missing. Other models get the root file.
    Returns (text to attach to the mission, subfolders to read when the agent works there). No file is copied."""
    if not folder:
        return "", []
    folder = Path(folder)
    task_files = instruction_files(folder)
    root_dir = {f.name: f for f in task_files if f.parent == folder}
    native = {"claude-code": "CLAUDE.md", "codex": "AGENTS.md"}.get(executor)
    to_attach: list[Path] = []
    if native == "CLAUDE.md":
        if "CLAUDE.md" not in root_dir and "AGENTS.md" in root_dir:
            to_attach = [root_dir["AGENTS.md"]]
    elif native == "AGENTS.md":
        to_attach = []                                   # AGENTS.md read; otherwise CLAUDE.md as fallback (launch setting)
    else:
        seen_items = set()
        for name in INSTRUCTION_NAMES:
            if name in root_dir:
                t = root_dir[name].read_text(encoding="utf-8", errors="replace").strip()
                if t and t not in seen_items:
                    seen_items.add(t)
                    to_attach.append(root_dir[name])
    text, leftover = [], MAX_INSTRUCTIONS
    for f in to_attach:
        t = f.read_text(encoding="utf-8", errors="replace").strip()
        if not t or leftover <= 0:
            continue
        text.append(f"### {f.name} (racine du projet)\n{t[:leftover]}" + ("\n… (tronqué : lis la suite dans le fichier)" if len(t) > leftover else ""))
        leftover -= len(t)
    subdir = []
    for f in task_files:
        if f.parent == folder:
            continue
        parsed = (native == "CLAUDE.md" and (f.parent / "CLAUDE.md").is_file()) or (native == "AGENTS.md")
        if not parsed and f.parent.relative_to(folder).as_posix() not in subdir:
            subdir.append(f.parent.relative_to(folder).as_posix())
    return "\n\n".join(text), subdir


def is_rules_copy(text: str) -> bool:
    """An imported instruction file that only repeats the studio's common rules (a copy generated by the studio, or
    lines that just point to the rule files): nothing new, so it is never given or listed twice."""
    if "genere-par-ai-workspace" in text:
        return True
    lines = [l.strip() for l in text.splitlines() if l.strip() and not l.strip().startswith("#")]
    return bool(lines) and all(l.startswith("@") and re.search(r"[\\/](Regles|Rules|Global)[\\/]", l) for l in lines)


def global_instructions(rules_folder: Path, executor: str, home: Path | None = None, max_chars: int = 8000) -> str:
    """Global CLAUDE.md / AGENTS.md imported into Regles/importes: given to every model, except the tool that already
    reads the original (~/.claude/CLAUDE.md or ~/.codex/AGENTS.md) as long as it exists."""
    home = Path(home or Path.home())
    natives = {"CLAUDE (Claude Code).md": ("claude-code", home / ".claude" / "CLAUDE.md"),
              "AGENTS (Codex).md": ("codex", home / ".codex" / "AGENTS.md")}
    d = next((Path(rules_folder) / x for x in ("importes", "imported") if (Path(rules_folder) / x).is_dir()),
             Path(rules_folder) / "importes")
    if not d.is_dir():
        return ""
    parts, seen_items = [], set()
    for f in sorted(d.glob("*.md")):
        ex, original = natives.get(f.name, ("", None))
        if ex == executor and original is not None and original.exists():
            continue
        t = f.read_text(encoding="utf-8", errors="replace").strip()
        if t and t not in seen_items and not is_rules_copy(t):
            seen_items.add(t)
            parts.append(f"### {f.stem} (instructions générales de l'utilisateur)\n{t}")
    return "\n\n".join(parts)[:max_chars]


def native_rules(executor: str, home: Path | None = None) -> bool:
    """True if the tool already loads the common rules on its own (its global CLAUDE.md / AGENTS.md points to them)."""
    home = Path(home or Path.home())
    f = {"claude-code": home / ".claude" / "CLAUDE.md", "codex": home / ".codex" / "AGENTS.md"}.get(executor)
    try:
        t = f.read_text(encoding="utf-8", errors="replace") if f else ""
        return "COMMON-INSTRUCTIONS" in t or "INSTRUCTIONS-COMMUNES" in t
    except OSError:
        return False


def studio_rules(rules_folder: Path, max_chars: int = 6000) -> str:
    """Common studio rules (instructions, security, conventions): short, given to ALL agents."""
    parts = []
    from .renames import rule_file
    for key in ("instructions", "security", "conventions"):
        f = rule_file(Path(rules_folder), key)
        if f.is_file():
            parts.append(f.read_text(encoding="utf-8", errors="replace").strip())
    t = "\n\n".join(parts)
    return t[:max_chars]
