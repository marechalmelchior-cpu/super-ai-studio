"""Task chains: several steps (one role + one request each) on the same target, run one after another.

Each step is an ordinary task: it waits for the user's validation. If the project works on a branch (worktree) and the
validated step is not merged yet, the next step starts from that step's branch (branch on branch): the chain goes on to the
end, and merging the last step also brings the earlier ones. If the project is applied by hand, it waits for the user to
confirm it was applied (« Continuer ») — it always starts from validated work, with the previous step's report. A cancelled or failed step pauses
the chain: the user resumes it (the step is relaunched) or stops it. Nothing starts without a user click at the outset, and each step
stays subject to validation.
"""
from __future__ import annotations

import threading
import uuid
from datetime import datetime

_lock = threading.Lock()
MAX_STEPS = 8


def create_new(studio, target: str, title: str, stages: list[dict], options: dict | None = None) -> tuple[str, str]:
    """Saves the chain and creates the task for step 1 (to be launched by the caller). Returns (chain, task)."""
    own = []
    for e in stages or []:
        request = str((e or {}).get("request", "")).strip()
        role = str((e or {}).get("role", "")).strip()
        if not request:
            continue
        if role and (role not in studio.roles or role == "reviewer"):
            raise ValueError(f"Rôle inconnu pour une étape : {role}")
        own.append({"role": role, "request": request[:4000]})
    if len(own) < 2:
        raise ValueError("Une chaîne demande au moins deux étapes.")
    if len(own) > MAX_STEPS:
        raise ValueError(f"{MAX_STEPS} étapes au plus par chaîne.")
    t = studio.registry.get(target)
    target = f"{t.kind}:{t.id}"
    title = (str(title or "").strip() or own[0]["request"].splitlines()[0])[:120]
    opts = {k: v for k, v in (options or {}).items() if k in ("model", "mode", "effort", "attachments") and v}   # attachments: step 1
    cid = "C" + datetime.now().strftime("%Y%m%d-%H%M%S-") + uuid.uuid4().hex[:4]
    studio.store.create_chain(cid, target, title, own, opts)
    return cid, _launch_step(studio, cid, 0, "")


def _launch_step(studio, cid: str, i: int, previous: str, start_commit: str = "", start_task: str = "") -> str:
    ch = studio.store.chain(cid)
    e = ch["stages"][i]
    text = (e["request"] + f"\n\n---\nÉtape {i + 1}/{len(ch['stages'])} de la chaîne « {ch['title']} »."
             + (f"\nÉtape précédente, validée par l'utilisateur :\n{previous}" if previous else ""))
    opts = {**{k: v for k, v in ch["options"].items() if k != "attachments" or i == 0}, "chain": cid, "stage": i,
            **({"role": e["role"]} if e["role"] else {}),
            **({"start_commit": start_commit, "start_task": start_task} if start_commit else {})}
    tid = studio.create(ch["target"], text, **opts)
    ch["stages"][i]["task"] = tid
    ch["stages"][i]["context"] = previous              # kept: a resumed step restarts with the same context
    ch["stages"][i]["start"] = {"commit": start_commit, "task": start_task} if start_commit else {}
    studio.store.update_chain(cid, stages=ch["stages"], current=i, status="running", note="")
    studio.store.event(tid, f"Chaîne {cid} — étape {i + 1}/{len(ch['stages'])}")
    return tid


def _report(studio, tid: str) -> str:
    """What the step really produced: the runner's summary (last attempt) and files touched."""
    from .migrations import compatibility as json
    import re
    t = studio.store.get(tid)
    rd = studio.details_dir(tid)
    summary = ""
    execs = sorted(rd.glob("execution-*.json"), key=lambda p: int(re.sub(r"\D", "", p.stem) or 0))
    if execs:
        try:
            summary = json.loads(execs[-1].read_text(encoding="utf-8")).get("summary", "")
        except (OSError, ValueError):
            summary = ""
    task_files = []
    try:
        task_files = [a.get("path") or a.get("path_value") or "" for a in studio.store.artifacts(tid)][:30]
    except Exception:                              # noqa: BLE001 — optional
        task_files = []
    role = studio.roles.get((t.get("options") or {}).get("role", ""))
    rows = [f"- Rôle : {role.name if role else 'choisi par le studio'} ; tâche {tid} ; statut : {t['status']}"]
    if any(task_files):
        rows.append("- Fichiers produits ou modifiés : " + ", ".join(f for f in task_files if f))
    rows.append("- Compte rendu de l'exécutant :\n" + (" ".join(summary.split())[:2500] or "(vide)"))
    return "\n".join(rows)


def _announce(studio, ch: dict, text: str, proposal: dict | None = None) -> None:
    """The Supervisor says where the chain stands, in its project's conversation (no AI call): step done, what to do."""
    try:
        t = studio.registry.get(ch["target"])
        project = f"{t.kind}:{t.id}"
    except (KeyError, ValueError):
        project = ""
    try:
        studio.store.message("supervisor", text, proposal={**({"project": project} if project else {}), **(proposal or {})})
    except Exception:                                   # noqa: BLE001 — a missing announcement never blocks the chain
        pass


def _validated_commit(studio, tid: str) -> str:
    """Commit validated for a worktree step (branche.json), "" if unknown."""
    from .migrations import compatibility as json
    try:
        return str(json.loads((studio.details_dir(tid) / "branch.json").read_text(encoding="utf-8")).get("commit") or "")
    except (OSError, ValueError, AttributeError):
        return ""


def _next_step(studio, ch: dict, tid: str, start_commit: str = "") -> str | None:
    """Étape validée et appliquée, ou départ de son commit validé : lance la suite ou termine la chaîne."""
    next_item = ch["current"] + 1
    if next_item >= len(ch["stages"]):
        studio.store.update_chain(ch["id"], status="completed", note="")
        _announce(studio, ch, f"✔ Chaîne « {ch.get('title', '')} » terminée : les {len(ch['stages'])} étapes sont faites.",
                  {"state": "chain_finished", "chain": ch["id"], "task": tid})
        return None
    launched_task = _launch_step(studio, ch["id"], next_item, _report(studio, tid),
                                 start_commit=start_commit, start_task=tid)
    if not start_commit:
        _announce(studio, ch, f"▶ Étape {next_item + 1}/{len(ch['stages'])} lancée, à partir du travail de l'étape {next_item}.",
                  {"state": "chain_stage", "chain": ch["id"], "task": launched_task, "previous_task": tid})
    return launched_task


def advance(studio, tid: str) -> str | None:
    """After a decision, cancellation, resume or merge: creates the next step's task if everything is
    ready. Returns its id (to be launched by the caller), else None. No effect outside a chain or when called twice."""
    t = studio.store.get(tid)
    o = t.get("options") or {}
    cid = o.get("chain")
    if not cid:
        return None
    with _lock:
        ch = studio.store.chain(cid)
        if not ch or ch["status"] in ("completed", "stopped") or ch["current"] != o.get("stage"):
            return None
        task_status = t["status"]
        if task_status in ("cancelled", "failed"):
            studio.store.update_chain(cid, status="paused", note=f"Étape {ch['current'] + 1} {'annulée' if task_status == 'cancelled' else 'en échec'} : relance-la ou arrête la chaîne.")
            return None
        if task_status not in ("approved", "applied"):
            return None
        if (studio.details_dir(tid) / "nothing-to-apply.json").exists():    # report with no files: nothing to merge
            return _next_step(studio, ch, tid)
        information = studio._branch_info(tid, t)
        if information.get("worktree") and not information.get("merge"):
            n = ch["current"] + 1
            commit = _validated_commit(studio, tid)
            if n < len(ch["stages"]) and commit:          # branch on branch: the chain goes on without waiting for the merge
                launched_task = _next_step(studio, ch, tid, start_commit=commit)
                _announce(studio, ch, f"✔ Étape {n}/{len(ch['stages'])} validée. Pas encore fusionnée : l'étape {n + 1} part de "
                                      "sa branche. Fusionne quand tu veux : la dernière étape fusionnée apporte aussi les précédentes.",
                          {"state": "chain_stacked", "chain": cid, "task": tid, "next": n + 1,
                           "launched_task": launched_task})
                return launched_task
            studio.store.update_chain(cid, status="awaiting_merge",
                                    note="Fusionne cette étape : la suivante partira de son travail. Rien à fusionner, ou fusionnée par toi-même ? Clique « Continuer ».")
            next_steps = f" : l'étape {n + 1} partira toute seule de ce travail" if n < len(ch["stages"]) else " : c'était la dernière étape"
            _announce(studio, ch, f"✔ Étape {n}/{len(ch['stages'])} validée. Fusionne-la dans la branche de départ{next_steps}.",
                      {"state": "chain_merge", "chain": cid, "task": tid, "next": n + 1 if n < len(ch["stages"]) else 0})
            return None
        if not information.get("worktree") and task_status == "approved" and studio.registry.get(ch["target"]).has_path:
            studio.store.update_chain(cid, status="awaiting_application",
                                    note="Ce projet s'applique à la main : applique le résultat de cette étape dans le projet, puis clique « Continuer ».")
            _announce(studio, ch, f"✔ Étape {ch['current'] + 1}/{len(ch['stages'])} validée. Applique son résultat dans le projet, "
                                  "puis clique « Continuer ».", {"state": "chain_application", "chain": cid, "task": tid})
            return None
        return _next_step(studio, ch, tid)


def proceed(studio, cid: str) -> str | None:
    """The user confirms the current step's work is in place (merged, applied, or nothing to carry over)."""
    with _lock:
        ch = studio.store.chain(cid)
        if not ch:
            raise KeyError(f"Chaîne inconnue : {cid}")
        if ch["status"] not in ("running", "awaiting_merge", "awaiting_application"):
            raise RuntimeError("Cette chaîne ne peut pas continuer (en pause, terminée ou arrêtée).")
        tid = ch["stages"][ch["current"]].get("task", "")
        if not tid or studio.store.get(tid)["status"] not in ("approved", "applied"):
            raise RuntimeError(f"Valide d'abord l'étape {ch['current'] + 1}.")
        return _next_step(studio, ch, tid)


def resume_run(studio, cid: str) -> str:
    """Paused chain: relaunch the current step (new task, same request, same context)."""
    with _lock:
        ch = studio.store.chain(cid)
        if not ch:
            raise KeyError(f"Chaîne inconnue : {cid}")
        if ch["status"] != "paused":
            raise RuntimeError("Cette chaîne n'est pas en pause.")
        e = ch["stages"][ch["current"]]
        start = e.get("start") if "start" in e else e.get("start")
        start = start or {}
        return _launch_step(studio, cid, ch["current"], e.get("context", ""),
                            start_commit=start.get("commit", ""), start_task=start.get("task", start.get("task", "")))


def halt(studio, cid: str) -> None:
    with _lock:                                         # never overwritten by a next step that is starting
        if not studio.store.chain(cid):
            raise KeyError(f"Chaîne inconnue : {cid}")
        studio.store.update_chain(cid, status="stopped", note="Arrêtée par l'utilisateur.")


def summary(studio, cid: str) -> dict | None:
    """For the interface: title, status, steps (readable role, request, task, state)."""
    ch = studio.store.chain(cid)
    if not ch:
        return None
    stages = []
    for e in ch["stages"]:
        r = studio.roles.get(e["role"])
        state = ""
        if e.get("task"):
            try:
                state = studio.store.get(e["task"])["status"]
            except KeyError:
                state = ""
        stages.append({"role": e["role"], "role_name": r.name if r else "choisi par le studio", "request": e["request"],
                       "task": e.get("task", ""), "state": state})
    selected = stages[ch["current"]] if ch["current"] < len(stages) else {}
    return {"id": ch["id"], "title": ch["title"], "status": ch["status"], "current": ch["current"], "note": ch["note"],
            "stages": stages, "can_continue": ch["status"] in ("running", "awaiting_merge", "awaiting_application")
            and selected.get("state") in ("approved", "applied")}
