"""Preuves d'activité du Superviseur et classement des travaux réellement exécutés."""
from __future__ import annotations

import hashlib
import json
import re


def delegation_request(text):
    return bool(re.search(r'\b(?:lanc\w*|crée\w*|cree\w*|démarr\w*|demarr\w*|launch|start|create)\b[^\n.!?]{0,100}\b(?:tâches?|taches?|tasks?)\b', text, re.I))


def activity(jsonl):
    """Uniquement les événements structurés de l'outil ; jamais une affirmation du texte de l'IA."""
    names, model = [], ''
    for line in jsonl.splitlines():
        try:
            event = json.loads(line)
        except (ValueError, TypeError):
            continue
        if not isinstance(event, dict):
            continue
        if event.get('type') == 'assistant':
            message = event.get('message') or {}
            model = message.get('model') or model
            for block in message.get('content') or []:
                if isinstance(block, dict) and block.get('type') == 'tool_use':
                    names.append(str(block.get('name', 'outil')))
        if event.get('type') == 'item.completed':
            item = event.get('item') or {}
            if item.get('type') in ('command_execution', 'file_change', 'mcp_tool_call', 'web_search'):
                names.append(item['type'])
            model = item.get('model') or model
        if event.get('type') == 'turn.started':
            model = event.get('model') or model
    # Noms seuls : aucun argument, chemin de fichier, résultat d'outil ou secret.
    names = [n for n in names if re.fullmatch(r'[A-Za-z_][A-Za-z0-9_.-]{0,100}', n)]
    return {'tools': names[:500], 'model': model}


def record(studio, rid, project, request, result, info, duration):
    tools = info.get('activity', {}).get('tools') or []
    if not tools:
        return ''
    # Une relance du classement ne duplique ni le dossier ni la consommation.
    for task in studio.store.list(100000):
        if studio.store.get(task['id'])['options'].get('supervisor_message') == rid:
            return task['id']
    from .security import redact
    from .titles import short_title
    from . import ai
    actor, connection = ai.choice(studio, 'supervisor')
    actual_actor = info.get('actor') or actor
    actual_connection = info.get('connection') if 'connection' in info else (connection or {}).get('id', '')
    family = info.get('family') or info.get('cli') or actor or 'IA non relevée'
    model = info.get('model') or info.get('activity', {}).get('model') or ''
    target = project
    if not target:
        target = 'topic:supervisor-work'
        try:
            studio.registry.get(target)
        except KeyError:
            studio.registry.add('topic', 'supervisor-work', 'Travaux du Superviseur')
    execution = {'executor': actual_actor, 'connection': actual_connection,
                 'family': family, 'exact_model': model, 'model': model, 'tools': tools}
    tid = studio.create(target, request, title=short_title(request), supervisor_message=rid,
                        supervisor_execution=execution)
    content = '# Travail du Superviseur\n\n' + redact(result) + '\n\n## Exécution relevée\n\n'
    content += f'IA : {redact(family)}\n\nModèle : {redact(model) or "non communiqué par l’outil"}\n\n'
    content += 'Outils observés : ' + ', '.join(tools) + '\n'
    file = studio.run_dir(tid) / 'RESULTAT.md'
    file.write_text(content, encoding='utf-8', newline='\n')
    studio.store.artifact(tid, 'RESULTAT.md', hashlib.sha256(file.read_bytes()).hexdigest(), 'Superviseur')
    studio.store.step(tid, 'execution', 'running', 'Travail du Superviseur')
    studio.store.step(tid, 'execution', 'ok', ', '.join(tools))
    studio.store.log_outcome(tid, family, model, 'Superviseur', duration, info.get('cost_usd'))
    studio.store.set_status(tid, 'approved' if info.get('ok', True) else 'failed',
                            'Faite par le Superviseur' if info.get('ok', True) else 'Travail du Superviseur en échec')
    return tid
