"""Git and GitHub for projects — Gestion tab and status line of the project page.

Everything goes through git directly (instant, no agent, no tokens used):
- reading: current branch, modified files, ahead / behind GitHub, local branches (merged or not,
  linked studio task, working copy), remote repo address without credentials;
- actions, each on a user click (the click is the consent): refresh (fetch), pull (pull --ff-only),
  push the current branch, create a pull request (if the gh tool is installed), delete an ALREADY
  merged branch (git branch -d, never -D: nothing is lost).
- LOCAL commit of the files checked by the user (never a push), merge of a task branch.
Never: force push, reset, rebase, deleting an unmerged branch, switching branches.
"""
from __future__ import annotations

import re
import shutil
from .migrations.compatibility import TechnicalPath as Path

from .connectors import workspace as ws
from .orchestrator.store import TERMINAL
from .security import redact


def _git_exe(studio) -> str:
    return studio.cfg["tools"].get("git", "git")


def repositories(studio) -> list:
    """Projects whose folder is a git repository."""
    return [c for c in studio.registry.all()
            if c.kind == "project" and c.has_path and c.path().is_dir() and (c.path() / ".git").exists()]


def _target(studio, key: str):
    for c in repositories(studio):
        if f"{c.kind}:{c.id}" == key:
            return c
    raise ValueError("Ce projet n'est pas un dépôt git.")


def _check_task_target(studio, target, tid):
    task = studio.store.get(tid)
    actual = studio.registry.get(task["target"])
    if (actual.kind, actual.id) != (target.kind, target.id):
        raise ValueError("La tâche appartient à un autre projet.")


def public_address(url: str) -> str:
    """Remote repo address without identifier or token; https link for GitHub."""
    url = re.sub(r"//[^/@]+@", "//", url.strip())
    m = re.match(r"^(?:git@github\.com:|https://github\.com/)([^/]+/[^/]+?)(?:\.git)?/?$", url)
    return f"https://github.com/{m.group(1)}" if m else redact(url)


def _tracking(text: str) -> tuple[int, int]:
    a = re.search(r"ahead (\d+)", text or ""); b = re.search(r"behind (\d+)", text or "")
    return (int(a.group(1)) if a else 0, int(b.group(1)) if b else 0)


def state(studio, target) -> dict:
    git, d = _git_exe(studio), target.path()
    out = {"target": f"{target.kind}:{target.id}", "name": target.name, "branch": "", "detached": False, "modified": [],
           "ahead": 0, "behind": 0, "upstream": "", "distant": "", "error": ""}
    try:
        st = ws._git(git, d, "status", "--porcelain=v1", "--branch", "--untracked-files=normal", timeout=60)
    except ws.WorktreeError as e:
        out["error"] = redact(str(e))[:300]
        return out
    rows = st.splitlines()
    head = rows[0][3:] if rows and rows[0].startswith("## ") else ""
    if head.startswith("HEAD (no branch)") or head.startswith("HEAD détachée"):
        out["detached"] = True
    else:
        name = head.split("...")[0].split(" ")[0]
        out["branch"] = name.replace("No commits yet on ", "")
        if "..." in head:
            out["upstream"] = head.split("...")[1].split(" ")[0]
        out["ahead"], out["behind"] = _tracking(head)
    out["modified"] = [l[3:] for l in rows[1:] if l.strip()][:200]
    try:
        out["distant"] = public_address(ws._git(git, d, "remote", "get-url", "origin", timeout=20).strip())
    except ws.WorktreeError:
        pass
    return out


def _branch_origins(studio, git: str, repo: Path, branches: list[dict], base: str) -> None:
    """Départ réel de chaque branche ; les champs historiques du graphe restent inchangés."""
    names = {branch["name"] for branch in branches}
    for branch in branches:
        name = branch["name"]
        branch.update(parent_branch=base if name != base else "", fork_commit="",
                      own_commits=0, parent_commits_after_fork=0)
        try:
            branch["fork_commit"] = ws._git(git, repo, "merge-base", base, name, timeout=30).strip()
            task = branch.get("task")
            if task:
                try:
                    options = studio.store.get(task["id"]).get("options") or {}
                except KeyError:
                    options = {}
                start = options.get("start_commit") or options.get("start_commit")
                previous = options.get("start_task") or options.get("start_task")
                parent = f"studio/{previous}" if previous else ""
                if start and parent in names and parent != name and not ws._succeeds(
                        git, repo, "merge-base", "--is-ancestor", parent, base):
                    commit = ws._git(git, repo, "rev-parse", "--verify", f"{start}^{{commit}}").strip()
                    if ws._succeeds(git, repo, "merge-base", "--is-ancestor", commit, parent) and ws._succeeds(
                            git, repo, "merge-base", "--is-ancestor", commit, name):
                        branch["parent_branch"], branch["fork_commit"] = parent, commit
                        branch["parent_commits_after_fork"] = int(ws._git(
                            git, repo, "rev-list", "--count", f"{commit}..{parent}").strip())
            if branch["fork_commit"]:
                branch["own_commits"] = int(ws._git(
                    git, repo, "rev-list", "--count", f"{branch['fork_commit']}..{name}").strip())
        except (ws.WorktreeError, ValueError):
            # Une branche disparue pendant la lecture n'empêche pas l'affichage des autres.
            continue


def detail(studio, key: str) -> dict:
    c = _target(studio, key)
    git, d = _git_exe(studio), c.path()
    e = state(studio, c)
    merged_branches = set()
    try:
        merged_branches = {l.strip(" *+") for l in ws._git(git, d, "branch", "--merged", "HEAD", timeout=60).splitlines()}
    except ws.WorktreeError:
        pass
    from . import actions
    copies = {x["task"]: x for x in actions.workspaces(studio) if x["project"] == c.name}
    branches = []
    fmt = "%(refname:short)%09%(objectname:short)%09%(committerdate:iso8601)%09%(upstream:short)%09%(upstream:track)%09%(subject)"
    try:
        refs = ws._git(git, d, "for-each-ref", "--sort=-committerdate", f"--format={fmt}", "refs/heads", timeout=60)
    except ws.WorktreeError:
        refs = ""
    for l in refs.splitlines():
        p = (l.split("\t") + [""] * 6)[:6]
        name = p[0]
        task = None
        if name.startswith("studio/"):
            tid = name[len("studio/"):]
            try:
                t = studio.store.get(tid)
                task = {"id": tid, "status": t["status"], "title": ((t.get("options") or {}).get("title") or t["request"] or "")[:120]}
            except KeyError:
                task = {"id": tid, "status": "unknown", "title": ""}
        av, re_ = _tracking(p[4])
        branches.append({"name": name, "commit": p[1], "date": p[2][:16], "upstream": p[3], "ahead": av, "behind": re_,
                         "topic": redact(p[5])[:160], "current": name == e["branch"],
                         "merged": name in merged_branches and name != e["branch"], "task": task,
                         "copy": copies.get(task["id"]) if task else None})
    base = "main" if any(branch["name"] == "main" for branch in branches) else (e["branch"] or "HEAD")
    _branch_origins(studio, git, d, branches, base)
    branches.sort(key=lambda b: (not b["current"], b["merged"]))   # current, then in progress, then merged (stable: most recent first)
    for b in branches:                          # graph: commits specific to the branch, and lead taken by the current branch
        if b["current"] or b["merged"]:
            continue
        try:
            g = ws._git(git, d, "rev-list", "--left-right", "--count", f"HEAD...{b['name']}", timeout=30).split()
            b["behind"], b["ahead"] = int(g[0]), int(g[1])
        except (ws.WorktreeError, ValueError, IndexError):
            pass
    history_items = []
    try:
        for l in ws._git(git, d, "log", "-40", "--format=%h%x09%cs%x09%s", timeout=30).splitlines():
            h, date, topic = (l.split("\t") + ["", ""])[:3]
            history_items.append({"commit": h, "date": date, "topic": redact(topic)[:120]})
    except ws.WorktreeError:
        pass
    to_push = None                            # commits not yet on GitHub (the merge squares disappear after Push)
    if e.get("upstream"):
        try:
            to_push = []
            for l in ws._git(git, d, "log", "--format=%h%x09%cs%x09%s", "@{upstream}..HEAD", timeout=30).splitlines():
                h, date, topic = (l.split("\t") + ["", ""])[:3]
                to_push.append({"commit": h, "date": date, "topic": redact(topic)[:120]})
            to_push.reverse()
        except ws.WorktreeError:
            to_push = None
    return {**e, "branches": branches, "history": history_items[::-1], "to_push": to_push, "gh": bool(shutil.which("gh"))}


def entries(studio) -> list[dict]:
    return [state(studio, c) for c in repositories(studio)]


# ---------------------------------------------------------------- actions (a user click = their consent)
NETWORK = {"refresh": "Actualiser depuis GitHub", "retrieve": "Récupérer les nouveautés", "push": "Pousser vers GitHub",
          "pr": "Créer une pull request"}


def launch(studio, jobs, key: str, action: str) -> dict:
    """Network actions: in the background, visible in « Travaux ». Credentials stay Windows' own (never read)."""
    c = _target(studio, key)
    git, d = _git_exe(studio), c.path()
    e = state(studio, c)
    if action not in NETWORK:
        raise ValueError("Action inconnue.")
    if action != "refresh" and (e["detached"] or not e["branch"]):
        raise ValueError("Le dépôt n'est pas sur une branche : rien n'est fait.")
    if action == "refresh":
        cmd = [git, "fetch", "--prune", "origin"]
    elif action == "retrieve":
        if not e["upstream"]:
            raise ValueError(f"La branche {e['branch']} ne suit aucune branche GitHub.")
        cmd = [git, "pull", "--ff-only"]                  # never a hidden merge or rebase
    elif action == "push":
        if e["behind"]:
            raise ValueError("GitHub a des commits que tu n'as pas : récupère d'abord (jamais de push forcé).")
        cmd = [git, "push"] if e["upstream"] else [git, "push", "-u", "origin", e["branch"]]
    else:
        gh = shutil.which("gh")
        if not gh:
            raise ValueError("L'outil gh (GitHub CLI) n'est pas installé.")
        if not e["upstream"] or e["ahead"]:
            raise ValueError("Pousse d'abord la branche sur GitHub.")
        cmd = [gh, "pr", "create", "--fill", "--head", e["branch"]]
    name = f"git:{c.id}:{action}"
    jobs.launch(name, f"{NETWORK[action]} — {c.name} ({e['branch'] or 'origin'})", cmd, d, timeout_s=600)
    return {"work": name, "message": f"{NETWORK[action]} : lancé."}


FAILED_STATUSES = ("cancelled", "failed", "blocked", "interrupted")


def erase_branch(studio, key: str, branch: str) -> dict:
    """Delete button of a red branch (task blocked, interrupted, failed or cancelled), on the user's click: the task is
    cancelled if needed, its working copy removed, then the branch deleted (git branch -D). Its unmerged work is
    lost: the interface says so beforehand. The Taches\\<tâche> folder (result, log) stays."""
    c = _target(studio, key)
    git, d = _git_exe(studio), c.path()
    if not re.fullmatch(r"studio/[A-Za-z0-9._-]{1,120}", branch or ""):
        raise ValueError("Seules les branches des tâches du studio peuvent être effacées ici.")
    tid = branch[len("studio/"):]
    t = studio.store.get(tid)
    _check_task_target(studio, c, tid)
    if t["status"] not in FAILED_STATUSES:
        raise ValueError("Seule une tâche bloquée, interrompue, en échec ou annulée peut être effacée.")
    if t["status"] in ("blocked", "interrupted"):
        studio.cancel(tid)
    user_workspace = studio.run_dir(tid) / ws.WORKSPACE
    if (user_workspace / ".git").is_file():
        ws._git(git, d, "worktree", "remove", "--force", str(user_workspace), timeout=600)
        (studio.run_dir(tid) / ws.READY_MARKER).unlink(missing_ok=True)
    if ws._git(git, d, "branch", "--list", branch).strip():
        ws._git(git, d, "branch", "-D", "--", branch, timeout=60)
    studio.store.event(tid, f"Branche {branch} effacée et copie retirée (par l'utilisateur depuis l'onglet Branches)")
    return {"message": f"Branche {branch} effacée ; la tâche reste dans l'historique (annulée)."}


def delete_branch(studio, key: str, branch: str) -> dict:
    """Only a local branch already merged into the current branch (git branch -d): no commit lost."""
    c = _target(studio, key)
    git, d = _git_exe(studio), c.path()
    if not re.fullmatch(r"[A-Za-z0-9._/-]{1,200}", branch or "") or branch.startswith("-"):
        raise ValueError("Nom de branche invalide.")
    e = state(studio, c)
    if branch == e["branch"]:
        raise ValueError("C'est la branche courante.")
    if not ws._succeeds(git, d, "merge-base", "--is-ancestor", branch, "HEAD"):
        raise ValueError(f"{branch} n'est pas fusionnée : elle reste.")
    if branch.startswith("studio/"):
        tid = branch[len("studio/"):]
        try:
            t = studio.store.get(tid)
            _check_task_target(studio, c, tid)
            if t["status"] not in TERMINAL:
                raise ValueError("La tâche de cette branche n'est pas terminée.")
            if (studio.run_dir(tid) / ws.WORKSPACE / ".git").is_file():
                from . import actions
                warning = actions.cleanup_merged_worktree(studio, tid)
                if warning:
                    raise ValueError(warning)
        except KeyError:
            pass
    ws._git(git, d, "branch", "-d", "--", branch, timeout=60)
    return {"message": f"Branche {branch} supprimée (elle était fusionnée : aucun commit perdu)."}


def delete_merged(studio, key: str) -> dict:
    """All local branches already merged into the current branch, at once (git branch -d, never -D).
    A task branch with its working copy: the copy is removed along with it. A refused branch is left and reported."""
    d = detail(studio, key)
    completed, left_over = [], []
    for b in d["branches"]:
        if not b["merged"] or b["current"]:
            continue
        try:
            delete_branch(studio, key, b["name"])
            completed.append(b["name"])
        except (ValueError, ws.WorktreeError) as e:
            left_over.append(f"{b['name']} ({str(e)[:120]})")
    msg = (f"{len(completed)} branche{'s' if len(completed) > 1 else ''} fusionnée{'s' if len(completed) > 1 else ''} supprimée{'s' if len(completed) > 1 else ''}"
           if completed else "Aucune branche fusionnée à supprimer")
    if left_over:
        msg += " ; laissées : " + ", ".join(left_over)
    return {"message": msg + ". Aucun commit perdu.", "deleted": completed, "laissees": left_over}


# ---------------------------------------------------------------- commit and merge from the Branches tab
LARGE_FILE_DEFAULT = 50 * 1024 * 1024          # above this: unchecked by default (GitHub rejects files over 100 MB)
GITHUB_LIMIT = 100 * 1024 * 1024
_STATES = {"M": "modifié", "A": "ajouté", "D": "supprimé", "R": "renommé", "C": "copié", "?": "new", "T": "modifié", "U": "en conflit"}


def to_commit(studio, key: str) -> dict:
    """Modified or new files of the current branch, each with its size and a checked or unchecked box."""
    c = _target(studio, key)
    git, d = _git_exe(studio), c.path()
    e = state(studio, c)
    raw_text = ws._git(git, d, "status", "--porcelain=v1", "-z", "--untracked-files=all", timeout=120)
    chunks, task_files, i = raw_text.split("\0"), [], 0
    while i < len(chunks):
        m = chunks[i]
        i += 1
        if len(m) < 4:
            continue
        xy, path_value = m[:2], m[3:]
        if xy[0] in "RC":
            i += 1                                       # -z: the old name follows the new one
        code = (xy[1] if xy[1] not in " ?" else xy[0]) if xy != "??" else "?"
        p = d / path_value
        size_bytes = p.stat().st_size if p.is_file() else 0
        checked, reason = True, ""
        if size_bytes > LARGE_FILE_DEFAULT:
            checked, reason = False, (f"{size_bytes // (1024 * 1024)} Mo : " + ("trop gros pour GitHub (100 Mo max)"
                                                                          if size_bytes > GITHUB_LIMIT else "très gros, à confirmer"))
        if "U" in xy:
            checked, reason = False, "en conflit : à régler d'abord"
        task_files.append({"path_value": path_value, "state": _STATES.get(code, code), "bytes": size_bytes, "checked": checked, "reason": reason})
        if len(task_files) >= 500:
            break
    return {"branch": e["branch"], "detached": e["detached"], "files": task_files}


def do_commit(studio, key: str, paths: list[str], message: str = "") -> dict:
    """LOCAL commit of the files checked by the user on the current branch (never a push, never any other file)."""
    c = _target(studio, key)
    git, d = _git_exe(studio), c.path()
    info = to_commit(studio, key)
    if info["detached"] or not info["branch"]:
        raise ValueError("Le dépôt n'est pas sur une branche : rien n'est commité.")
    known = {f["path_value"]: f for f in info["files"]}
    paths = [x for x in dict.fromkeys(paths or []) if x]
    if not paths:
        raise ValueError("Coche au moins un fichier.")
    unknown = [x for x in paths if x not in known]
    if unknown:
        raise ValueError("Fichiers qui ne sont plus modifiés (rafraîchis la liste) : " + ", ".join(unknown[:5]))
    too_big = [x for x in paths if known[x]["bytes"] > GITHUB_LIMIT]
    if too_big:
        raise ValueError("Trop gros pour GitHub (plus de 100 Mo), décoche-les : " + ", ".join(too_big[:5]))
    message = " ".join((message or "").split())[:200] or (
        f"Studio : {len(paths)} fichier{'s' if len(paths) > 1 else ''} — " + ", ".join(Path(x).stem for x in paths[:3])
        + ("…" if len(paths) > 3 else ""))
    entries = "\0".join(paths) + "\0"
    ws.check_result_files(d, paths)
    ws._git(git, d, "add", "--pathspec-from-file=-", "--pathspec-file-nul", entry=entries, timeout=600)
    ws._git(git, d, "commit", "--no-verify", "-m", message, "--pathspec-from-file=-", "--pathspec-file-nul",
            entry=entries, timeout=600)
    sha = ws._git(git, d, "rev-parse", "--short", "HEAD").strip()
    return {"message": f"Commité sur {info['branch']} : {sha} — {message}. Rien n'est poussé vers GitHub.", "commit": sha}


def merge_branch(studio, key: str, branch: str) -> dict:
    """Merge of a task branch (studio/…) into the current branch: same path as the task's button."""
    target = _target(studio, key)
    if not re.fullmatch(r"studio/T\d{8}-\d{6}-[0-9a-f]{6}", branch or ""):
        raise ValueError("Seules les branches des tâches du studio se fusionnent ici.")
    from . import actions
    _check_task_target(studio, target, branch[len("studio/"):])
    return actions.merge(studio, branch[len("studio/"):])
