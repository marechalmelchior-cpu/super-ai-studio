"""First launch: a short guide (an AI for the Supervisor, a project, ready), each screen with « Passer »; and the guided tour.

The current screen is recorded in welcome.json: a studio stopped halfway resumes at the same screen. Everything skipped
stays available later (Réglages › IA for the AI and GitHub, the « ＋ » button for projects).

Nothing installs without a user click: each installation opens a visible window on the PC
(Windows: winget or the official installer; Mac and Linux: the official command in a terminal, or to copy).
"""
from __future__ import annotations

from .migrations import compatibility as json
import re
import shutil
import subprocess
import sys
from .migrations.compatibility import TechnicalPath as Path

LINKS = {
    "ollama": "https://ollama.com/download",
    "git": "https://git-scm.com/downloads",
    "claude": "https://claude.com/product/claude-code",
    "codex": "https://developers.openai.com/codex/cli",
    "node": "https://nodejs.org",
}

# Official commands, per platform. Windows: winget (shipped with Windows 10/11) or official script.
_WIN = {
    "ollama": "winget install --id Ollama.Ollama -e",
    "git": "winget install --id Git.Git -e",
    "claude": "powershell -NoProfile -ExecutionPolicy Bypass -Command \"irm https://claude.ai/install.ps1 | iex\"",
    "codex": "winget install --id OpenJS.NodeJS.LTS -e",          # Node.js first; the CLI on the next click
}
_MAC = {
    "ollama": "brew install ollama",
    "git": "xcode-select --install",
    "claude": "curl -fsSL https://claude.ai/install.sh | bash",
    "codex": "brew install --cask codex",
}
_LINUX = {
    "ollama": "curl -fsSL https://ollama.com/install.sh | sh",
    "git": "sudo apt install -y git || sudo dnf install -y git",
    "claude": "curl -fsSL https://claude.ai/install.sh | bash",
    "codex": "npm install -g @openai/codex",
}


def os_support() -> str:
    return "windows" if sys.platform == "win32" else "mac" if sys.platform == "darwin" else "linux"


def command(tool: str) -> str:
    table = {"windows": _WIN, "mac": _MAC, "linux": _LINUX}[os_support()]
    if tool == "codex" and os_support() == "windows" and shutil.which("npm"):
        return "npm install -g @openai/codex"
    if tool == "claude" and os_support() == "windows" and not shutil.which("git"):
        return "winget install --id Git.Git -e && " + _WIN["claude"]       # the subscription tool on Windows needs Git
    if tool == "codex" and os_support() == "mac" and not shutil.which("brew") and shutil.which("npm"):
        return "npm install -g @openai/codex"
    return table.get(tool, "")


GUIDE_STEPS = ("ai", "project", "ready")


def _file(data: Path) -> Path:
    return Path(data) / "welcome.json"


def read_file(data: Path) -> dict:
    try:
        d = json.loads(_file(data).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    if not isinstance(d, dict):
        return {}
    if d.get("step") not in GUIDE_STEPS:
        d.pop("step", None)
    skipped = d.get("skipped")
    if skipped is not None:
        d["skipped"] = [x for x in skipped if x in GUIDE_STEPS] if isinstance(skipped, list) else []
    return d


def jot(data: Path, **value_map) -> dict:
    """Records the guide's progress: finished, visit, current step, a skipped step or a completed one (unknown values ignored)."""
    d = read_file(data)
    for k in ("finished", "visit"):
        if k in value_map:
            d[k] = bool(value_map[k])
    if value_map.get("step") in GUIDE_STEPS:
        d["step"] = value_map["step"]
    skipped = set(d.get("skipped") or [])
    if value_map.get("skipped") in GUIDE_STEPS:
        skipped.add(value_map["skipped"])
    if value_map.get("done") in GUIDE_STEPS:
        skipped.discard(value_map["done"])
    if skipped or "skipped" in d:
        d["skipped"] = [x for x in GUIDE_STEPS if x in skipped]
    f = _file(data)
    tmp = f.with_name(f.name + ".tmp")
    tmp.write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(f)                                  # never a half-written file if the studio stops here
    return d


def guide(studio, d: dict) -> dict:
    """Whether the first-launch guide opens, and where. Never for a studio already in use (finished, toured, or with tasks)."""
    used = False
    try:
        used = bool(studio.store.list(limit=1))
    except Exception:                               # unreadable base: the guide stays closed rather than block the studio
        used = True
    show = not d.get("finished") and not d.get("visit") and (bool(d.get("step")) or not used)
    return {"show": show, "step": d.get("step") or GUIDE_STEPS[0], "skipped": d.get("skipped") or []}


def _memory_go(note: str) -> float | None:
    m = re.search(r"≈\s*(\d+(?:[.,]\d+)?)\s*Go", note or "")
    return float(m.group(1).replace(",", ".")) if m else None


def recommended_models(catalog: list[dict], ram_gb: float | None, vram_gb: float | None) -> list[dict]:
    """Local models from the catalog with what they require and whether they fit on this PC.
    "fast" = fits in the graphics card; "possible" = fits in memory (slower); otherwise too big."""
    seen_items, output = set(), []
    for m in sorted((m for m in catalog if m.get("local") and m.get("category") == "global"), key=lambda m: -(m.get("score") or 0)):
        name = m.get("ollama") or m.get("key")
        if not name or name in seen_items:
            continue
        seen_items.add(name)
        go = _memory_go(m.get("note", ""))
        if go is None:
            fits = "unknown"
        elif vram_gb and go <= vram_gb:
            fits = "fast"
        elif ram_gb and go <= ram_gb * 0.75:
            fits = "possible"
        else:
            fits = "too_big"
        output.append({"name": name, "title": m.get("name", name), "score": m.get("score"), "memory_gb": go, "fits": fits,
                       "note": (m.get("note", "").split("—", 1)[1].strip() if "—" in m.get("note", "") else "")})
    rank = {"fast": 0, "possible": 1, "unknown": 2, "too_big": 3}
    best = min(output, key=lambda x: (rank[x["fits"]], -(x["score"] or 0)), default=None)
    for x in output:
        x["recommended"] = x is best and x["fits"] in ("fast", "possible")
    return output


def _vram_windows() -> float | None:
    """Graphics card memory (any brand) read from the Windows registry; None elsewhere or if missing."""
    if sys.platform != "win32":
        return None
    try:
        import winreg
        base = r"SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}"
        best = 0
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, base) as k:
            for i in range(32):
                try:
                    with winreg.OpenKey(k, f"{i:04d}") as s:
                        v, _ = winreg.QueryValueEx(s, "HardwareInformation.qwMemorySize")
                        best = max(best, int(v if isinstance(v, int) else int.from_bytes(v, "little")))
                except OSError:
                    continue
        return round(best / 2**30, 1) or None
    except (OSError, ImportError, ValueError):
        return None


def _execute(cmd: list[str], delay: float = 6) -> tuple[int, str]:
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=delay,
                           **({"creationflags": 0x08000000} if sys.platform == "win32" else {}))
        return r.returncode, (r.stdout or "") + (r.stderr or "")
    except (OSError, subprocess.SubprocessError):
        return -1, ""


def github_connected() -> bool | None:
    """True if a GitHub account is registered (gh or Git's credential manager). None: impossible to tell."""
    if shutil.which("gh"):
        return _execute(["gh", "auth", "status"])[0] == 0
    if shutil.which("git"):
        code, output = _execute(["git", "credential-manager", "github", "list"])
        if code == 0:
            return bool(output.strip())
    return None


def state(studio, home: Path | None = None) -> dict:
    """What the welcome screen shows: AIs already ready, Ollama, Git/GitHub, models suited to the PC."""
    from . import agents, ai, local_models, system
    from .connectors.base import find_exe
    from .connectors.primary_cli import WIN_CANDIDATES
    home = home or Path.home()
    data = studio.paths.data
    primary_cli = bool(find_exe(studio.cfg["tools"].get("primary_cli", "claude"), WIN_CANDIDATES))
    secondary_cli = bool(find_exe(studio.cfg["tools"].get("secondary_cli", "codex")))
    connections = [c for c in ai.public(data).get("connections", [])]
    primary_cli_ok = primary_cli and ((home / ".claude" / ".credentials.json").is_file() or sys.platform == "darwin")
    secondary_cli_ok = secondary_cli and (home / ".codex" / "auth.json").is_file()
    installed = local_models.installed()
    r = system.survey()
    gpu = r.get("gpu") or {}
    ram_gb = (r.get("ram") or {}).get("total_gb")
    vram = gpu.get("total_vram_gb") or _vram_windows()
    if not vram and sys.platform == "darwin" and ram_gb:
        import platform
        if platform.machine() == "arm64":
            vram = round(ram_gb * 0.66, 1)            # Apple Silicon Mac: unified memory, two thirds for the AI
    git = bool(shutil.which("git"))
    ready = bool(connections) or primary_cli_ok or secondary_cli_ok
    d = read_file(data)
    targets = [{"key": f"{t.kind}:{t.id}", "name": t.name, "kind": t.kind} for t in studio.registry.all()]
    return {
        "finished": bool(d.get("finished")), "visit": bool(d.get("visit")), "ready": ready, "plateforme": os_support(),
        "guide": guide(studio, d), "targets": targets,
        "winget": bool(shutil.which("winget")) if os_support() == "windows" else False,
        "claude": {"installed": primary_cli, "connected": primary_cli_ok, "command": command("claude")},
        "codex": {"installed": secondary_cli, "connected": secondary_cli_ok, "command": command("codex")},
        "connections": [{"provider": c.get("provider"), "name": c.get("name"), "model": c.get("model")} for c in connections],
        "ollama": {"installed": bool(local_models.local_runner_executable()), "open": installed is not None,
                   "models": installed or [], "command": command("ollama"), "link": LINKS["ollama"]},
        "pc": {"ram_gb": ram_gb, "vram_gb": vram, "gpu": gpu.get("name", "")},
        "recommended": recommended_models(agents.benchmarks(data)["models"], ram_gb, vram),
        "git": {"installed": git, "github": github_connected() if git else False, "command": command("git"), "link": LINKS["git"]},
    }


def _console(title: str, cmd: str) -> None:
    """Opens a visible window that runs the command; the user sees everything and can close it."""
    if sys.platform == "win32":
        subprocess.Popen(["cmd", "/c", "start", title, "cmd", "/k", cmd], creationflags=0x00000010)
    elif sys.platform == "darwin":
        script = cmd.replace("\\", "\\\\").replace('"', '\\"')
        subprocess.Popen(["osascript", "-e", f'tell application "Terminal" to do script "{script}"'], start_new_session=True)
    else:
        for t in (["x-terminal-emulator", "-e"], ["gnome-terminal", "--"], ["konsole", "-e"], ["xfce4-terminal", "-x"], ["xterm", "-e"]):
            if shutil.which(t[0]):
                subprocess.Popen([*t, "bash", "-c", cmd + "; exec bash"], start_new_session=True)
                return
        raise ValueError("Aucun terminal trouvé : copie la commande dans un terminal.")


def install(tool: str) -> dict:
    """Installs a tool on click (visible window). Without winget or a terminal: returns the command and the link."""
    if tool not in ("ollama", "git", "claude", "codex"):
        raise ValueError("Outil inconnu.")
    cmd = command(tool)
    names = {"ollama": "Ollama", "git": "Git", "claude": "Claude Code", "codex": "Codex"}
    if os_support() == "windows" and cmd.startswith("winget") and not shutil.which("winget"):
        return {"ok": False, "link": LINKS[tool], "info": f"Installe {names[tool]} depuis son site, puis reviens ici."}
    if os_support() == "mac" and cmd.startswith("brew") and not shutil.which("brew"):
        return {"ok": False, "link": LINKS[tool], "command": cmd, "info": f"Installe {names[tool]} depuis son site, puis reviens ici."}
    try:
        _console(f"Installation de {names[tool]}", cmd)
    except (OSError, ValueError) as e:
        return {"ok": False, "command": cmd, "link": LINKS[tool], "info": str(e)}
    if tool == "codex" and "NodeJS" in cmd:
        return {"ok": True, "info": "Codex a besoin de Node.js : une fenêtre l'installe. Ensuite, reclique « Installer » pour Codex."}
    return {"ok": True, "info": f"Une fenêtre d'installation de {names[tool]} s'est ouverte : suis-la, puis clique « Vérifier »."}


def connect_github() -> dict:
    """GitHub sign-in in the browser (gh or the credential manager shipped with Git)."""
    if shutil.which("gh"):
        cmd = "gh auth login --web --git-protocol https"
    elif shutil.which("git"):
        cmd = "git credential-manager github login"
    else:
        raise ValueError("Installe d'abord Git.")
    _console("Connexion GitHub", cmd)
    return {"ok": True, "info": "Une fenêtre de connexion GitHub s'est ouverte : suis-la (le navigateur s'ouvre), puis clique « Vérifier »."}
