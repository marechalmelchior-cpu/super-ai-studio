"""Resolves the studio's locations.

Root (the "workspace"): see ``studio/user_workspace.py`` — STUDIO_HOME, else the user's pointer, else the parent folder
of ``Studio`` (historical layout). The program (``code``) may be installed somewhere other than the workspace.
No project path is inferred here: projects are declared in the registry.
"""
from __future__ import annotations

import os
import re
from dataclasses import dataclass
from functools import lru_cache
from .migrations.compatibility import TechnicalPath as Path

# User-facing folder names follow the language chosen when the workspace was created ([utilisateur] dossiers in
# Studio/studio.config.toml). Code is always English; only these names are localized. Existing workspaces: French.
FOLDERS = {
    "fr": {"rules": "Regles", "projects": "Projets", "topics": "Sujets", "tasks": "Taches", "backups": "Sauvegardes",
           "full_backups": "Studio-complet", "updates": "Mises-a-jour", "archives": "Archives", "deliverables": "Livrables",
           "imported": "importes", "readme": "LISEZ-MOI.md"},
    "en": {"rules": "Rules", "projects": "Projects", "topics": "Topics", "tasks": "Tasks", "backups": "Backups",
           "full_backups": "Full", "updates": "Updates", "archives": "Archives", "deliverables": "Deliverables",
           "imported": "imported", "readme": "README.md"},
}


# Result folders of a topic, by kind of file (canonical key -> folder name per language)
RESULT_FOLDERS = {
    "fr": {"images": "Images", "documents": "Documents", "3d": "3D", "sounds": "Sons", "videos": "Videos", "code": "Code", "other": "Autres"},
    "en": {"images": "Images", "documents": "Documents", "3d": "3D", "sounds": "Sounds", "videos": "Videos", "code": "Code", "other": "Other"},
}


@lru_cache(maxsize=64)
def folder_language(root: str) -> str:
    """'en' when the workspace was created with English folder names, else 'fr'."""
    try:
        text = (Path(root) / "Studio" / "studio.config.toml").read_text(encoding="utf-8")
    except OSError:
        return "fr"
    m = re.search(r"(?m)^\s*folders\s*=\s*['\"](\w+)['\"]", text)
    return m.group(1) if m and m.group(1) in FOLDERS else "fr"


@dataclass(frozen=True)
class StudioPaths:
    root: Path

    def __post_init__(self):
        object.__setattr__(self, "root", Path(self.root))

    @property
    def lang(self) -> str: return folder_language(str(self.root))
    @property
    def names(self) -> dict: return FOLDERS[self.lang]
    @property
    def result_folders(self) -> dict: return RESULT_FOLDERS[self.lang]

    # Readable localized names; technical files live in Studio\, old ones in Archives\.
    @property
    def global_dir(self) -> Path: return self.root / self.names["rules"]
    @property
    def skills(self) -> Path: return self.root / "Skills"          # name kept: the coding agents read it
    @property
    def projects(self) -> Path: return self.root / self.names["projects"]
    @property
    def topics(self) -> Path: return self.root / self.names["topics"]
    @property
    def studio(self) -> Path: return self.root / "Studio"
    @property
    def decisions(self) -> Path: return self.studio / "Decisions"
    @property
    def roles(self) -> Path: return self.studio / "roles"
    @property
    def runs(self) -> Path: return self.root / self.names["tasks"]   # one task = « 2026-10-24 Short title »
    @property
    def backup_root(self) -> Path: return self.root / self.names["backups"]
    @property
    def backups(self) -> Path: return self.backup_root / self.names["full_backups"]
    @property
    def config_backups(self) -> Path: return self.backup_root / "Configs"
    @property
    def updates(self) -> Path: return self.backup_root / self.names["updates"]
    @property
    def archives(self) -> Path: return self.root / self.names["archives"]
    @property
    def deliverables(self) -> Path: return self.root / self.names["deliverables"]   # former location of topic results (before 0.4.18)
    @property
    def imported_rules(self) -> Path: return self.global_dir / self.names["imported"]   # instruction files copied from the PC
    @property
    def data(self) -> Path: return self.studio / "data"
    @property
    def code(self) -> Path: return Path(__file__).resolve().parents[1]    # program: studio/, scripts/, templates/
    @property
    def attachments(self) -> Path: return self.data / "attachments"   # files dropped into the Supervisor window
    @property
    def logs(self) -> Path: return self.data / "logs"
    @property
    def restores(self) -> Path: return self.data / "test-restores"
    @property
    def db(self) -> Path: return self.data / "studio.db"
    @property
    def checkpoints(self) -> Path: return self.data / "checkpoints.db"
    @property
    def config_file(self) -> Path: return self.studio / "studio.config.toml"

    def ensure(self) -> "StudioPaths":
        for d in (self.runs, self.data, self.backups, self.projects, self.topics, self.logs):
            d.mkdir(parents=True, exist_ok=True)
        return self


def default_paths(root: str | os.PathLike | None = None) -> StudioPaths:
    if root is None:
        from .user_workspace import configured_root
        root = configured_root() or Path(__file__).resolve().parents[2]
    return StudioPaths(Path(root).resolve())
