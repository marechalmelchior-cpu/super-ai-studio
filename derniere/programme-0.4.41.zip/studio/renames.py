"""English names for the workspace's technical files (skills, shared rules), with a one-time migration.

Names that agents and code rely on are English and never change with the interface language; their content stays in
the user's language. Only the folders the user browses (Projets/Projects…) and the documents written for them are
localized (see paths.FOLDERS).

``migrate_workspace(root)`` runs at every launch and does nothing once done:
- a skill folder with an old name is renamed (the ``name:`` line of its SKILL.md follows), unless the new one exists;
- references to the old names inside the skills (``studio-<old>``, ``Skills/<old>``) are updated;
- shared rule files are renamed (SECURITE.md → SECURITY.md…).
Nothing is deleted: when both names exist, the old one is left in place for the user to check.
"""
from __future__ import annotations

import re
from .migrations.compatibility import TechnicalPath as Path

SKILL_RENAMES = {
    "ajouter-projet-ou-sujet": "add-project-or-topic",
    "audit-memoires": "audit-memories",
    "blender-arriere-plan": "blender-background",
    "boucle-legere": "review-loop",
    "chatgpt-aller-retour": "copy-paste",
    "copier-coller": "copy-paste",
    "isolation-git": "git-isolation",
    "memoire-partagee": "shared-memory",
    "rangement-fin-de-seance": "end-of-session-tidy",
    "retro-ingenierie": "reverse-engineering",
    "sauvegarde-restauration": "backup-restore",
    "superviseur": "supervisor",
    "unreal-sans-interface": "unreal-headless",
    "verification-avant-annonce": "verify-before-announcing",
    # skills of the studio's library (Extensions)
    "analyse-de-donnees": "data-analysis",
    "charte-graphique": "brand-guidelines",
    "equilibrage-jeu": "game-balancing",
    "gestion-freelance": "freelance-management",
    "montage-video-ffmpeg": "video-editing-ffmpeg",
    "pipeline-assets-3d": "3d-asset-pipeline",
    "quetes-et-dialogues": "quests-and-dialogues",
    "relecture-francais": "french-proofreading",
    "reseaux-sociaux": "social-media",
    "revue-de-code": "code-review",
    "seo-contenu-web": "seo-web-content",
    "sons-et-musique": "sound-and-music",
    "tests-automatises": "automated-tests",
    "veille-et-synthese": "research-digest",
}
RULE_RENAMES = {
    "INSTRUCTIONS-COMMUNES.md": "COMMON-INSTRUCTIONS.md",
    "PRIORITES.md": "PRIORITIES.md",
    "SECURITE.md": "SECURITY.md",
}
RULES = {"instructions": "COMMON-INSTRUCTIONS.md", "priorities": "PRIORITIES.md", "security": "SECURITY.md",
         "conventions": "CONVENTIONS.md"}


def rule_file(rules_dir: Path, key: str) -> Path:
    """A shared rule file by role; the older French name is still read until the migration has run."""
    new = Path(rules_dir) / RULES[key]
    if new.is_file():
        return new
    old = next((o for o, n in RULE_RENAMES.items() if n == RULES[key]), "")
    return Path(rules_dir) / old if old and (Path(rules_dir) / old).is_file() else new


def skill_dir(skills: Path, name: str) -> Path:
    """Skills/<name>, or its older French name if the workspace has not been migrated yet."""
    p = Path(skills) / name
    if p.is_dir():
        return p
    old = next((o for o, n in SKILL_RENAMES.items() if n == name and (Path(skills) / o).is_dir()), "")
    return Path(skills) / old if old else p


def _refs(text: str) -> str:
    for old, new in SKILL_RENAMES.items():
        text = re.sub(rf"(?<![\w-])(studio-|Skills/|skill «? ?){re.escape(old)}(?![\w-])", rf"\g<1>{new}", text)
    return text


def migrate_workspace(root: Path, home: Path | None = None) -> list[str]:
    root = Path(root)
    done: list[str] = []
    skills = root / "Skills"
    if skills.is_dir():
        for old, new in SKILL_RENAMES.items():
            o, n = skills / old, skills / new
            if o.is_dir() and not n.exists():
                o.rename(n)
                done.append(f"Skills/{old} → Skills/{new}")
        for md in skills.glob("*/SKILL.md"):
            try:
                text = md.read_text(encoding="utf-8")
            except (OSError, UnicodeDecodeError):
                continue
            fixed = _refs(text)
            folder = md.parent.name
            fixed = re.sub(r"(?m)^name:[ \t]*(\S+)[ \t]*$",
                           lambda m: f"name: {folder}" if SKILL_RENAMES.get(m.group(1)) == folder else m.group(0), fixed, count=1)
            if fixed != text:
                md.write_text(fixed, encoding="utf-8", newline="")
    from .paths import StudioPaths
    rules = StudioPaths(root).global_dir
    if rules.is_dir():
        for old, new in RULE_RENAMES.items():
            o, n = rules / old, rules / new
            if o.is_file() and not n.exists():
                o.rename(n)
                done.append(f"{rules.name}/{old} → {rules.name}/{new}")
        for f in rules.glob("*.md"):                   # cross references between the rule files
            try:
                text = f.read_text(encoding="utf-8")
            except (OSError, UnicodeDecodeError):
                continue
            fixed = text
            for old, new in RULE_RENAMES.items():
                fixed = fixed.replace(old, new)
            if fixed != text:
                f.write_text(fixed, encoding="utf-8", newline="")
    for f in (root / "Studio" / "roles").glob("*.toml"):  # the roles' instructions name the rule files and skills
        _rewrite(f)
    done += _tool_references(root, rules, Path(home or Path.home()))
    return done


def _tool_references(root: Path, rules: Path, home: Path) -> list[str]:
    """Instruction files of the user's AI tools that point to a renamed rule file (« @…/Regles/PRIORITES.md »):
    the path is updated so the tools keep reading the rules. A copy is kept first in Studio/data/config-avant/."""
    import shutil
    from datetime import datetime
    out = []
    for f in (home / ".claude" / "CLAUDE.md", home / ".codex" / "AGENTS.md"):
        try:
            text = f.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            continue
        fixed = text
        for old, new in RULE_RENAMES.items():
            if not (rules / new).is_file():
                continue
            fixed = re.sub(rf"((?:{re.escape(rules.name)})[\\/]){re.escape(old)}\b", rf"\g<1>{new}", fixed)
        if fixed != text:
            backup = root / "Studio" / "data" / "previous-config" / f"{f.parent.name.lstrip('.')}-{f.name}-{datetime.now():%Y%m%d-%H%M%S}"
            backup.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(f, backup)
            f.write_text(fixed, encoding="utf-8", newline="")
            try:                                            # the studio's copy follows: no « changed outside » alert
                from .initial_import import refresh_copy
                refresh_copy(root, root / "Studio" / "data", f)
            except Exception:                               # noqa: BLE001
                pass
            out.append(f"{f.name} de ton outil : chemins des règles mis à jour (copie gardée)")
    return out


def _rewrite(f: Path) -> None:
    try:
        text = f.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        return
    fixed = _refs(text)
    for old, new in RULE_RENAMES.items():
        fixed = fixed.replace(old, new)
    if fixed != text:
        f.write_text(fixed, encoding="utf-8", newline="")
