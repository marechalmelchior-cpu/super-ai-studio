"""Registry of projects and topics.

A project = ``Projets/<id>/project.toml``; a topic = ``Sujets/<id>/topic.toml``.
Adding a project or a topic requires no code change:
create the folder and its file (or ``python -m studio projet-ajouter``).
Projects stay at their real location: the registry points to them.
"""
from __future__ import annotations

import re
import tomllib
from .migrations import compatibility as _compat
from dataclasses import dataclass, field
from .migrations.compatibility import TechnicalPath as Path
from typing import Any

from .memory.models import Scope

_ID = re.compile(r"^[a-z0-9][a-z0-9._-]{0,63}$")
STUDIO_ID = "_studio"            # built-in target: the studio's own skills and shared rules (audits). Never a valid user id.
APPLICATIONS = ("manual", "auto_after_approval")


@dataclass
class Target:
    kind: str                       # "project" | "topic"
    id: str
    name: str
    type: str = "doc"
    path_value: str = ""                # empty for a topic without a repository
    repository: str = ""
    allowed_tools: list[str] = field(default_factory=list)
    rules: list[str] = field(default_factory=list)
    documents: list[str] = field(default_factory=list)
    checks: list[str] = field(default_factory=list)
    application: str = "manual"
    description: str = ""
    extra: dict[str, Any] = field(default_factory=dict)
    file: Path | None = None

    @property
    def scope(self) -> Scope:
        if self.id == STUDIO_ID:                # the studio itself: its memory is the general one
            return Scope("general")
        return Scope(self.kind, self.id)  # type: ignore[arg-type]

    @property
    def has_path(self) -> bool:
        return bool(self.path_value)

    def path(self) -> Path | None:
        if not self.path_value:
            return None
        if re.match(r"^[A-Za-z]:[\\/]", self.path_value):      # absolute Windows path
            return Path(self.path_value)
        p = Path(self.path_value)
        if not p.is_absolute() and self.file is not None:   # path relative to the toml file
            p = (self.file.parent / p).resolve()
        return p

    def to_public(self) -> dict:
        return {"kind": self.kind, "id": self.id, "name": self.name, "type": self.type, "path_value": self.path_value,
                "repository": self.repository, "tools": self.allowed_tools, "application": self.application,
                "description": self.description, "memory": self.scope.label}


KNOWN = {"id", "name", "type", "path_value", "repository", "tools", "rules", "documents", "checks",
         "application", "description"}


def _load(kind: str, f: Path) -> Target:
    with open(f, "rb") as fh:
        d = _compat.toml_load(fh)
    tid = d.get("id", f.parent.name)
    if not _ID.match(tid):
        raise ValueError(f"Identifiant invalide dans {f}")
    if d.get("application", "manual") not in APPLICATIONS:
        raise ValueError(f"Politique d'application inconnue dans {f}")
    return Target(kind=kind, id=tid, name=d.get("name", tid), type=d.get("type", "doc"),
                  path_value=d.get("path_value", ""), repository=d.get("repository", ""), allowed_tools=list(d.get("tools", [])),
                  rules=list(d.get("rules", [])), documents=list(d.get("documents", [])),
                  checks=list(d.get("checks", [])), application=d.get("application", "manual"),
                  description=d.get("description", ""), extra={k: v for k, v in d.items() if k not in KNOWN},
                  file=f)


class Registry:
    def __init__(self, projects_dir: Path, topics_dir: Path, archives_dir: Path | None = None):
        self.projects_dir, self.topics_dir = Path(projects_dir), Path(topics_dir)
        self.archives_dir = Path(archives_dir) if archives_dir else None

    def all(self) -> list[Target]:
        out = []
        for kind, d, name in (("project", self.projects_dir, "project.toml"), ("topic", self.topics_dir, "topic.toml")):
            if d.exists():
                for f in sorted(d.glob(f"*/{name}")):
                    out.append(_load(kind, f))
        return out

    def studio_target(self) -> Target:
        """The studio itself as a project: only its Skills and shared rules are copied for a task, everything else
        (projects, tasks, backups, technical files) is excluded. Not listed with the user's projects."""
        from .paths import StudioPaths
        root = self.projects_dir.parent
        keep = {"Skills", StudioPaths(root).names["rules"]}
        exclude = sorted(p.name for p in root.iterdir() if p.name not in keep) if root.is_dir() else []
        return Target(kind="project", id=STUDIO_ID, name="Le studio (skills et règles communes)", type="doc",
                      path_value=str(root), description="Skills et règles communes à toutes les IA",
                      application="auto_after_approval",     # no Git here: the approved result is copied back
                      extra={"exclude": exclude, "internal": True})

    def get(self, ref: str) -> Target:
        """``rpg3d``, ``project:rpg3d`` ou ``topic:veille-ia``."""
        kind, _, ident = ref.partition(":") if ":" in ref else ("", "", ref)
        kind = {"projet": "project", "sujet": "topic"}.get(kind, kind)
        if ident == STUDIO_ID and kind in ("", "project"):
            return self.studio_target()
        matches = [t for t in self.all() if t.id == ident and (not kind or t.kind == kind)]
        if not matches:
            raise KeyError(f"Projet ou sujet inconnu : {ref}")
        if len(matches) > 1:
            raise KeyError(f"Référence ambiguë : {ref} (préciser project: ou topic:)")
        return matches[0]

    def removed(self, ref: str) -> Path:
        """Removes a project or topic from the studio WITHOUT deleting anything: its card (folder Projets/<id> or Sujets/<id>,
        with project.toml, CONTEXTE.md, lore…) is moved to Archives/projets-retires/ or Archives/sujets-retires/<id> <date>. The real
        project folder (path) is never touched. To restore it: move the folder back."""
        import shutil
        from datetime import datetime
        t = self.get(ref)
        if t.file is None:
            raise FileNotFoundError(f"Fiche introuvable : {ref}")
        src = t.file.parent
        base = self.projects_dir if t.kind == "project" else self.topics_dir
        if src.parent.resolve() != base.resolve():
            raise ValueError(f"Fiche hors de {base.name} : rien n'est déplacé.")
        if self.archives_dir:
            dest = self.archives_dir / ("projets-retires" if t.kind == "project" else "sujets-retires") / \
                f"{t.id} {datetime.now().strftime('%Y-%m-%d %Hh%M')}"
        else:
            dest = base / "_retires" / f"{t.id}-{datetime.now().strftime('%Y%m%d-%H%M%S')}"
        if dest.exists():
            raise FileExistsError(f"{dest} existe déjà : rien n'est écrasé.")
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(src), str(dest))
        return dest

    def add(self, kind: str, tid: str, name: str, **fields) -> Target:
        if not _ID.match(tid):
            raise ValueError("Identifiant : minuscules, chiffres, . _ - (64 max).")
        base = self.projects_dir if kind == "project" else self.topics_dir
        d = base / tid
        f = d / ("project.toml" if kind == "project" else "topic.toml")
        if f.exists():
            raise FileExistsError(f"{f} existe déjà : rien n'est écrasé.")
        if kind == "project" and not fields.get("path_value"):
            raise ValueError("Un projet doit indiquer son chemin réel.")
        d.mkdir(parents=True, exist_ok=True)
        from datetime import datetime
        data = {"id": tid, "name": name, **{k: v for k, v in fields.items() if v not in (None, "", [])},
                "created": datetime.now().isoformat(timespec="seconds")}          # home page order: most recent first
        f.write_text(dump_toml(data), encoding="utf-8")
        (d / "CONTEXTE.md").exists() or (d / "CONTEXTE.md").write_text(
            f"# {name}\n\nContexte validé du {('project' if kind == 'project' else 'topic')}. "
            "À compléter par l'utilisateur ; les agents le lisent avant toute tâche.\n", encoding="utf-8")
        return _load(kind, f)


def _toml_value(v) -> str:
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, (int, float)):
        return str(v)
    if isinstance(v, list):
        return "[" + ", ".join(_toml_value(x) for x in v) + "]"
    s = str(v)
    if "'" not in s and "\n" not in s:
        return f"'{s}'"                       # raw string: Windows \ not escaped
    return '"' + s.replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n") + '"'


def dump_toml(d: dict) -> str:
    return "".join(f"{k} = {_toml_value(v)}\n" for k, v in d.items() if not isinstance(v, dict))
