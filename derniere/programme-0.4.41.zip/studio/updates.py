"""Program updates from published releases (public GitHub repo, derniere/ folder).

- Check at startup then once a day, plus the « Rechercher une mise à jour » button (Gestion › Outils).
- Minor update (manifest « mineure »: true): installed on its own, then the studio offers to restart. Major update:
  the studio shows what's new and waits for « Installer ».
- Signature (Ed25519): active only once a public key is shipped in the studio (studio/update-public-key.txt). Without a
  key (« no_key »), behaviour is exactly the 0.4.39 one (SHA-256 checked, no confirmation). With a key: a minor update
  installs on its own only if its signature is valid; an unsigned one asks for a confirmation; a wrong one is refused.
- Only program files change (studio/, templates/, scripts/, docs/, installeur/, studio.cmd, component
  lists). Never the data, settings, roles or memory; new Python components go to a new environment
  (studio/python_env.py), the one in service is kept for rollback. Before writing, the
  current version is backed up (anciennes-versions/<version>.zip); the archive is verified (SHA-256).
"""
from __future__ import annotations

import hashlib
import io
from .migrations import compatibility as json
import os
import re
import tempfile
import threading
import time
import urllib.request
import zipfile
from .migrations.compatibility import TechnicalPath as Path

from .user_workspace import CODE

ALLOWED = ("studio/", "templates/", "modeles/", "scripts/", "docs/", "installeur/", "installer/", "wheels/")   # modeles/: archives 0.4.38 et avant
ROOT_FILES = {"studio.cmd", "VERSION", "requirements.lock.txt", "requirements-attachments.lock.txt", "requirements-pieces.lock.txt",
              "requirements-retro.lock.txt"}
_state: dict = {"checked": 0.0, "available": None, "installed": "", "error": "", "running": False}
_lock = threading.Lock()


def current_version(code: Path = CODE) -> str:
    try:
        return (code / "VERSION").read_text(encoding="utf-8").strip() or "0.0.0"
    except OSError:
        return "0.0.0"


def repository() -> str:
    try:
        d = (CODE / "DEPOT").read_text(encoding="utf-8").strip()
        return d if re.fullmatch(r"[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+", d) else ""
    except OSError:
        return ""


def _v(t: str) -> tuple[int, ...]:
    return tuple(int(x) for x in re.findall(r"\d+", t)[:3]) or (0,)


def _get(url: str, delay: float = 30) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": "SuperAIStudio", "Accept": "application/octet-stream, application/json"})
    with urllib.request.urlopen(req, timeout=delay) as r:
        return r.read()


def check(force: bool = False) -> dict:
    """Latest published version: {"version", "mineure", "notes"} if it is newer, otherwise None."""
    d = repository()
    if not d:
        return {"current": current_version(), "available": None, "info": "Mises à jour non configurées."}
    with _lock:
        if not force and time.time() - _state["checked"] < 3600:
            return {"current": current_version(), "available": _state["available"], "installed": _state["installed"]}
    try:
        # latest version: « derniere/ » folder of the public repo (manifest.json + program archive)
        base = f"https://raw.githubusercontent.com/{d}/main/derniere/"     # nom publié, ne pas renommer
        man = json.loads(_get(base + "manifest.json"))
        usable = None
        file = str(man.get("file") or man.get("fichier", ""))     # manifeste publié : « fichier »
        if man.get("version") and _v(man["version"]) > _v(current_version()) and re.fullmatch(r"[A-Za-z0-9_.-]+\.zip", file):
            _require_hash(man.get("sha256"))
            from .update_signature import manifest_state, read_public_key
            usable = {"version": man["version"], 'minor': bool(man.get('minor', man.get('mineure'))), "notes": str(man.get("notes", ""))[:2000],
                     "url": base + file, "sha256": man.get("sha256", ""), "signature": manifest_state(man, read_public_key())}
        with _lock:
            _state.update(checked=time.time(), available=usable, error="")
    except Exception as e:                                 # noqa: BLE001 — offline: try again later
        with _lock:
            _state.update(checked=time.time(), available=None, error=type(e).__name__)
    return {"current": current_version(), "available": _state["available"], "installed": _state["installed"], "error": _state["error"]}


def _safe_members(z: zipfile.ZipFile) -> list[zipfile.ZipInfo]:
    out = []
    seen = set()
    for m in z.infolist():
        n = m.filename.replace("\\", "/")
        if m.is_dir():
            continue
        parts = n.split("/")
        if (n.startswith("/") or any(p in {"", ".", ".."} or p.endswith((".", " ")) for p in parts)
                or ":" in n or "\x00" in n or (m.external_attr >> 16) & 0o170000 == 0o120000):
            raise ValueError(f"chemin refusé dans l'archive : {n}")
        if not (n.startswith(ALLOWED) or n in ROOT_FILES):
            raise ValueError(f"fichier hors du programme dans l'archive : {n}")
        if n.casefold() in seen:
            raise ValueError(f"fichier en double dans l'archive : {n}")
        seen.add(n.casefold())
        out.append(m)
    return out


def _require_hash(expected: str) -> str:
    if not isinstance(expected, str) or not re.fullmatch(r"[0-9a-fA-F]{64}", expected):
        raise ValueError("empreinte SHA-256 du manifeste obligatoire (64 caractères hexadécimaux)")
    return expected.lower()


def _stage_file(target: Path, content: bytes, suffix: str = ".update") -> Path:
    """Écrit et vérifie un fichier temporaire adjacent avant tout remplacement."""
    fd, name = tempfile.mkstemp(prefix=f".{target.name}-", suffix=suffix, dir=target.parent)
    staged = Path(name)
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(content)
            stream.flush()
            os.fsync(stream.fileno())
        if hashlib.sha256(staged.read_bytes()).digest() != hashlib.sha256(content).digest():
            raise ValueError("fichier temporaire de mise à jour altéré")
        return staged
    except BaseException:
        staged.unlink(missing_ok=True)
        raise


def _restore_previous(backup: Path, changed: list[tuple[str, Path]], hashes: dict[str, str]) -> None:
    errors = []
    with zipfile.ZipFile(backup) as saved:
        for name, target in reversed(changed):
            staged = None
            try:
                if name in hashes:
                    # Un remplacement refusé peut avoir laissé le fichier initial intact et verrouillé.
                    if target.is_file() and hashlib.sha256(target.read_bytes()).hexdigest() == hashes[name]:
                        continue
                    content = saved.read(name)
                    if hashlib.sha256(content).hexdigest() != hashes[name]:
                        raise ValueError("sauvegarde de mise à jour altérée")
                    staged = _stage_file(target, content, ".rollback")
                    os.replace(staged, target)
                else:
                    target.unlink(missing_ok=True)
            except Exception as error:
                errors.append(type(error).__name__)
            finally:
                if staged is not None:
                    staged.unlink(missing_ok=True)
    if errors:
        raise RuntimeError(f"retour arrière incomplet ({', '.join(errors)}) ; sauvegarde : {backup}")


def apply(archive: bytes, expected: str, target: Path = CODE) -> dict:
    """Verifies then installs a program archive; backs up the replaced files first."""
    expected = _require_hash(expected)
    if hashlib.sha256(archive).hexdigest() != expected:
        raise ValueError("archive altérée (empreinte différente) : rien n'est installé")
    installation_root = Path(target).resolve()
    with zipfile.ZipFile(io.BytesIO(archive)) as z:
        members = _safe_members(z)
        # Lecture complète (CRC compris) avant de créer une sauvegarde ou un temporaire.
        contents = {m.filename.replace("\\", "/"): z.read(m) for m in members}
    targets = {name: installation_root.joinpath(*name.split("/")) for name in contents}
    for target in targets.values():
        if installation_root not in target.resolve().parents or target.is_symlink() or (target.exists() and not target.is_file()):
            raise ValueError("destination de mise à jour refusée")
        parent = target.parent
        while parent != installation_root:
            if parent.is_symlink() or parent.is_junction():
                raise ValueError("lien dans une destination de mise à jour")
            parent = parent.parent
    previous = current_version(installation_root)
    backup_root = installation_root.parent / "anciennes-versions" if installation_root.name == "app" else installation_root / "data" / "anciennes-versions"
    backup_root.mkdir(parents=True, exist_ok=True)
    version_name = re.sub(r"[^A-Za-z0-9_.-]", "_", previous)
    fd, name = tempfile.mkstemp(prefix=f"{version_name}-", suffix=".partiel", dir=backup_root)
    os.close(fd)
    partial = Path(name)
    copy_dir = partial.with_suffix(".zip")
    hashes = {}
    try:
        with zipfile.ZipFile(partial, "w", zipfile.ZIP_DEFLATED) as saved:
            for name, target in targets.items():
                if target.is_file():
                    content = target.read_bytes()
                    hashes[name] = hashlib.sha256(content).hexdigest()
                    saved.writestr(name, content)
        with zipfile.ZipFile(partial) as saved:
            for name, digest in hashes.items():
                if hashlib.sha256(saved.read(name)).hexdigest() != digest:
                    raise ValueError("sauvegarde de mise à jour altérée")
        partial.replace(copy_dir)
    finally:
        partial.unlink(missing_ok=True)

    staged = {}
    changed = []
    created_dirs = []
    try:
        for name, target in targets.items():
            missing = []
            parent = target.parent
            while not parent.exists():
                missing.append(parent)
                parent = parent.parent
            for parent in reversed(missing):
                parent.mkdir()
                created_dirs.append(parent)
            staged[name] = _stage_file(target, contents[name])
        for name, target in targets.items():
            # Répertorier avant replace : même une erreur après son effet reste annulable.
            changed.append((name, target))
            staged[name].replace(target)
        if any(name.startswith("wheels/") for name in contents):
            _install_components(installation_root)
    except BaseException:
        _restore_previous(copy_dir, changed, hashes)
        raise
    finally:
        for temporary in staged.values():
            temporary.unlink(missing_ok=True)
        for directory in reversed(created_dirs):
            try:
                directory.rmdir()
            except OSError:
                pass

    try:                                                # Ne retirer d'anciennes versions qu'après réussite.
        from .cleanup import cap, cleanup_enabled
        if cleanup_enabled(installation_root / "studio.config.toml") if (installation_root / "studio.config.toml").exists() else True:
            cap(backup_root, "*.zip", 3)
    except Exception:                                   # noqa: BLE001 — cleanup never blocks an update
        pass
    return {"ok": True, "old": previous, "new": current_version(installation_root), "backup": str(copy_dir), "files": len(members)}


def _install_components(target: Path) -> None:
    """New Python components shipped with the update (offline, from wheels/): installed in a NEW environment, checked,
    then chosen for the next start; the environment in service is never modified and stays the rollback target."""
    from . import python_env
    new = python_env.prepare(target, current_version(target))
    python_env.activate(target, new)


SIGNATURE_TEXT = {"valid": "signée", "missing": "non signée", "no_key": "non vérifiable (pas de clé dans ce studio)",
                  "invalid": "signature invalide"}


def install(note=lambda m: None, unsigned_ok: bool = False) -> dict:
    """``unsigned_ok``: the user confirmed installing an update that is not signed (never one with a wrong signature)."""
    with _lock:
        usable = _state["available"]
        if _state["running"]:
            raise RuntimeError("Une mise à jour est déjà en cours.")
        _state["running"] = True
    try:
        if not usable:
            raise ValueError("Aucune mise à jour disponible.")
        expected = _require_hash(usable.get("sha256"))
        signature = usable.get("signature", "missing")
        if signature == "invalid":                       # only possible when a key is shipped
            raise ValueError("Signature de la mise à jour invalide : rien n'est installé. Ne l'installe pas à la main.")
        if signature not in ("valid", "no_key") and not unsigned_ok:
            raise PermissionError(f"Mise à jour {SIGNATURE_TEXT.get(signature, signature)} : confirme pour l'installer quand même.")
        r = apply(_get(usable["url"], 600), expected)
        with _lock:
            _state.update(installed=r["new"], available=None)
        note(f"mise à jour installée : {r['old']} → {r['new']}")
        return r
    finally:
        with _lock:
            _state["running"] = False


def automatic(note=lambda m: None) -> None:
    """At startup then daily: checks; a minor update installs itself."""
    v = check(force=True)
    d = v.get("available")
    if d and d.get('minor') and d.get("signature") not in ("valid", "no_key"):
        with _lock:                                        # key shipped: never on its own without a valid signature
            _state["error"] = (f"Mise à jour {d['version']} {SIGNATURE_TEXT.get(d.get('signature'), 'non signée')} : "
                               "pas d'installation automatique.")
        return
    if d and d.get('minor'):
        try:
            install(note)
        except Exception as e:                             # noqa: BLE001 — shown in Gestion › Outils
            with _lock:
                _state["error"] = str(e)[:300]


def state() -> dict:
    with _lock:
        return {"current": current_version(), "repository": repository(), "available": _state["available"],
                "installed": _state["installed"], "error": _state["error"], "running": _state["running"]}


def restart_later() -> None:
    """Restarts the studio a few seconds after it stops (same program, same workspace)."""
    import subprocess
    import sys
    code = ("import time, subprocess, sys; time.sleep(5); "
            f"subprocess.Popen([sys.executable, '-m', 'studio', 'lanceur'], cwd={str(CODE)!r})")
    subprocess.Popen([sys.executable, "-c", code], cwd=str(CODE), stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                     stderr=subprocess.DEVNULL, close_fds=True,
                     **({"creationflags": 0x00000008 | 0x00000200} if sys.platform == "win32" else {"start_new_session": True}))
