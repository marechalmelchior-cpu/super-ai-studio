"""Specialized roles (``Studio/roles/*.toml`` files).

A role receives a bounded mission: allowed context, tools, deliverables,
success criteria, limits. Selection only engages the useful producer role
+ the auditor; other roles are not launched without a concrete benefit.
"""
from __future__ import annotations

import re
import tomllib
from ..migrations import compatibility as _compat
from dataclasses import dataclass, field
from ..migrations.compatibility import TechnicalPath as Path


@dataclass
class Role:
    id: str
    name: str
    domains: list[str]
    keywords: list[str]
    executor: str
    allowed_tools: list[str]
    deliverables: list[str]
    criteria: list[str]
    limits: list[str]
    enabled: bool = True
    guidance: str = ""
    read_only: bool = False
    model: str = ""          # role's default model (tool alias), tuned for efficiency and speed
    effort: str = ""          # default effort: low | medium | high | xhigh | max
    extra: dict = field(default_factory=dict)
    connection: str = ""       # role-specific connected AI (API key or local); empty = the agents' one
    api_model: str = ""      # this AI's model for the role
    category: str = ""       # text | code | image | video | voice (roles created by the assistant)
    projects_list: list[str] = field(default_factory=list)   # agent specific to these projects (« project:rpg3d »); empty = all


def load_roles(d: Path) -> dict[str, Role]:
    roles = {}
    for f in sorted(Path(d).glob("*.toml")):
        with open(f, "rb") as fh:
            x = _compat.toml_load(fh)
        r = Role(id=_compat.ROLE_ALIASES.get(x["id"], x["id"]), name=x["name"], domains=x.get("domains", []), keywords=x.get("keywords", []),
                 executor=x.get("executor", "claude-code"), allowed_tools=x.get("tools", []),
                 deliverables=x.get("deliverables", []), criteria=x.get("criteria", []), limits=x.get("limits", []),
                 enabled=x.get("enabled", True) is not False,
                 guidance=x.get("instructions", ""), read_only=x.get("read_only", False),
                 model=str(x.get("model", "")),
                 effort=str(x.get("effort", "")) if x.get("effort") in ("low", "medium", "high", "xhigh", "max") else "",
                 connection=str(x.get("connection", "")), api_model=str(x.get("api_model", "")), category=str(x.get("category", "")),
                 projects_list=[str(v) for v in x.get("projects", []) if isinstance(v, str)])
        roles[r.id] = r
    if "reviewer" not in roles:
        raise ValueError("Le rôle « auditeur » est obligatoire.")
    return roles


def select_producer(roles: dict[str, Role], target_type: str, request: str, forced: str = "") -> Role:
    if forced:
        if forced not in roles or forced == "reviewer":
            raise ValueError(f"Rôle producteur invalide : {forced}")
        return roles[forced]
    words = set(re.findall(r"[\wÀ-ÿ+#]+", request.lower()))
    best, best_score = None, -1.0
    for r in roles.values():
        if r.id == "reviewer":
            continue
        score = 2.0 * sum(1 for k in r.keywords if k.lower() in words or (" " in k and k.lower() in request.lower()))
        score += 1.5 if target_type in r.domains else 0.0
        if score > best_score:
            best, best_score = r, score
    return best  # type: ignore[return-value]
