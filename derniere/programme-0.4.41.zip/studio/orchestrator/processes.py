"""Registry of processes launched by the studio.

The studio stops ONLY the processes it launched itself (direct child and
its tree), never another open application. Cancellation goes through a
database flag: the process running the task reads it and stops its children.
"""
from __future__ import annotations

import os
import signal
import subprocess
import sys
import time
from dataclasses import dataclass
from ..migrations.compatibility import TechnicalPath as Path

from ..security import redact
from .store import TaskStore, now


@dataclass
class ProcResult:
    returncode: int | None
    stdout: str
    stderr: str
    status: str            # termine | delai_depasse | annule | introuvable
    duration_s: float


class Cancelled(RuntimeError):
    pass


def _kill_tree(p: subprocess.Popen) -> None:
    if p.poll() is not None:
        return
    if sys.platform == "win32":
        subprocess.run(["taskkill", "/PID", str(p.pid), "/T", "/F"], capture_output=True, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    else:
        try:
            os.killpg(os.getpgid(p.pid), signal.SIGTERM)
            time.sleep(0.5)
            if p.poll() is None:
                os.killpg(os.getpgid(p.pid), signal.SIGKILL)
        except ProcessLookupError:
            pass


def run_process(store: TaskStore, task_id: str, cmd: list[str], cwd: Path, timeout_s: float,
                env: dict | None = None, stdin_text: str | None = None, activity=None, hard_s: float | None = None) -> ProcResult:
    """``activity``: callable giving the time of the agent's last sign of life. With it, ``timeout_s`` is a silence limit
    (an agent that keeps working is not cut off) and ``hard_s`` the total limit; without it, ``timeout_s`` is the total."""
    shown = redact(" ".join(cmd))[:1000]
    kwargs: dict = {}
    if sys.platform == "win32":
        kwargs["creationflags"] = subprocess.CREATE_NEW_PROCESS_GROUP | getattr(subprocess, "CREATE_NO_WINDOW", 0)
    else:
        kwargs["start_new_session"] = True
    t0 = time.time()
    try:
        p = subprocess.Popen(cmd, cwd=str(cwd), env=env, stdin=subprocess.PIPE if stdin_text is not None else subprocess.DEVNULL,
                             stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, encoding="utf-8",
                             errors="replace", **kwargs)
    except FileNotFoundError:
        with store.db() as c:
            c.execute("INSERT INTO processes(task_id,pid,command,started_at,ended_at,status) VALUES (?,?,?,?,?,?)",
                      (task_id, None, shown, now(), now(), "missing"))
        return ProcResult(None, "", f"Programme introuvable : {cmd[0]}", "missing", 0.0)
    with store.db() as c:
        rid = c.execute("INSERT INTO processes(task_id,pid,command,started_at,status) VALUES (?,?,?,?,?)",
                        (task_id, p.pid, shown, now(), "running")).lastrowid
    status = "completed"
    last_seen = t0
    try:
        out, err = p.communicate(input=stdin_text, timeout=0.5) if stdin_text is not None else (None, None)
    except subprocess.TimeoutExpired:
        out = err = None
    while out is None and p.poll() is None:
        if store.cancel_requested(task_id):
            status = "cancelled"
            _kill_tree(p)
            break
        elapsed = time.time() - t0
        if activity is not None:
            if time.time() - last_seen > timeout_s:      # the probe is only asked when the silence limit could be reached
                try:
                    last_seen = max(last_seen, float(activity() or 0))
                except Exception:                   # noqa: BLE001 — a broken probe falls back to the total limit
                    pass
            if time.time() - last_seen > timeout_s or (hard_s and elapsed > hard_s):
                status = "timed_out"
                _kill_tree(p)
                break
        elif elapsed > timeout_s:
            status = "timed_out"
            _kill_tree(p)
            break
        try:
            out, err = p.communicate(timeout=0.5)
        except subprocess.TimeoutExpired:
            continue
    if out is None:
        try:
            out, err = p.communicate(timeout=10)
        except subprocess.TimeoutExpired:
            _kill_tree(p)
            out, err = "", ""
    with store.db() as c:
        c.execute("UPDATE processes SET ended_at=?,status=?,exit_code=? WHERE id=?", (now(), status, p.returncode, rid))
    res = ProcResult(p.returncode, out or "", err or "", status, time.time() - t0)
    if status == "cancelled":
        raise Cancelled("Tâche annulée : processus du studio arrêté.")
    return res


def processes(store: TaskStore, task_id: str | None = None) -> list[dict]:
    with store.db() as c:
        q = "SELECT task_id,pid,command,started_at,ended_at,status,exit_code FROM processes"
        rows = c.execute(q + (" WHERE task_id=?" if task_id else "") + " ORDER BY id DESC LIMIT 200",
                         ((task_id,) if task_id else ())).fetchall()
        return [dict(r) for r in rows]
