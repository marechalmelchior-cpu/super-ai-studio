"""Persistent task storage (SQLite, WAL mode).

Separate from:
- LangGraph checkpoints (``checkpoints.db``): where the graph is at;
- shared durable memory (AgentMemory): what must be remembered.
This file keeps the readable record: steps, produced files and versions,
errors and attempts, effects already applied, launched processes, approvals.
"""
from __future__ import annotations

from ..migrations import compatibility as json
from ..user_workspace import custom
import os
import sqlite3
import sys
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone
from ..migrations.compatibility import TechnicalPath as Path

SCHEMA = """
CREATE TABLE IF NOT EXISTS schema_migrations (version INTEGER PRIMARY KEY, applied_at TEXT NOT NULL);
INSERT OR IGNORE INTO schema_migrations VALUES (1, strftime('%Y-%m-%dT%H:%M:%SZ','now'));
CREATE TABLE IF NOT EXISTS tasks (
  id TEXT PRIMARY KEY, target TEXT NOT NULL, request TEXT NOT NULL, status TEXT NOT NULL,
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL, summary TEXT NOT NULL DEFAULT '',
  result_hash TEXT NOT NULL DEFAULT '', cancel_requested INTEGER NOT NULL DEFAULT 0,
  options TEXT NOT NULL DEFAULT '{}');
CREATE TABLE IF NOT EXISTS steps (
  task_id TEXT NOT NULL, name TEXT NOT NULL, status TEXT NOT NULL, detail TEXT NOT NULL DEFAULT '',
  started_at TEXT, ended_at TEXT, attempt INTEGER NOT NULL DEFAULT 1,
  PRIMARY KEY(task_id, name, attempt));
CREATE TABLE IF NOT EXISTS artifacts (
  task_id TEXT NOT NULL, path TEXT NOT NULL, version INTEGER NOT NULL, sha256 TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL, PRIMARY KEY(task_id, path, version));
CREATE TABLE IF NOT EXISTS errors (
  task_id TEXT NOT NULL, step TEXT NOT NULL, attempt INTEGER NOT NULL, message TEXT NOT NULL, at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS effects (
  key TEXT PRIMARY KEY, task_id TEXT NOT NULL, kind TEXT NOT NULL, status TEXT NOT NULL,
  result TEXT NOT NULL DEFAULT '', started_at TEXT NOT NULL, ended_at TEXT);
CREATE TABLE IF NOT EXISTS processes (
  id INTEGER PRIMARY KEY AUTOINCREMENT, task_id TEXT NOT NULL, pid INTEGER, command TEXT NOT NULL,
  started_at TEXT NOT NULL, ended_at TEXT, status TEXT NOT NULL, exit_code INTEGER);
CREATE TABLE IF NOT EXISTS approvals (
  task_id TEXT NOT NULL, decision TEXT NOT NULL, result_hash TEXT NOT NULL, comment TEXT NOT NULL DEFAULT '',
  at TEXT NOT NULL, valid INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS slots (slot INTEGER PRIMARY KEY, task_id TEXT, since TEXT, pid INTEGER);
CREATE TABLE IF NOT EXISTS events (
  id INTEGER PRIMARY KEY AUTOINCREMENT, task_id TEXT NOT NULL, at TEXT NOT NULL, message TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS usage (day TEXT NOT NULL, tool TEXT NOT NULL, calls INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (day, tool));
CREATE TABLE IF NOT EXISTS calls (
  id INTEGER PRIMARY KEY AUTOINCREMENT, at TEXT NOT NULL, day TEXT NOT NULL, family TEXT NOT NULL, usage TEXT NOT NULL,
  target TEXT, role TEXT, model TEXT, duration_s REAL, input_tokens INTEGER, output_tokens INTEGER, cache_tokens INTEGER,
  cost_usd REAL, ok INTEGER);
CREATE INDEX IF NOT EXISTS calls_at ON calls(at);
CREATE TABLE IF NOT EXISTS chains (
  id TEXT PRIMARY KEY, target TEXT NOT NULL, title TEXT NOT NULL, stages TEXT NOT NULL, current INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL, options TEXT NOT NULL DEFAULT '{}', note TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS requests (
  id INTEGER PRIMARY KEY AUTOINCREMENT, target TEXT NOT NULL, title TEXT NOT NULL, request TEXT NOT NULL,
  options TEXT NOT NULL DEFAULT '{}', retired INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS conversation (
  id INTEGER PRIMARY KEY AUTOINCREMENT, at TEXT NOT NULL, author TEXT NOT NULL, text TEXT NOT NULL,
  state TEXT NOT NULL DEFAULT 'ok', proposal TEXT NOT NULL DEFAULT '{}');
"""

TERMINAL = ("approved", "cancelled", "failed", "applied")

# Additive migrations: new nullable columns only, never a rewrite of existing rows (old calls keep NULL = unknown).
CALL_COLUMNS = (("task_id", "TEXT"), ("attempt", "INTEGER"), ("stage", "TEXT"))
USAGE_PER_TASK = 2                           # schema_migrations version of the per-task usage columns


def pid_alive(pid) -> bool:
    if not pid:
        return False
    if pid == os.getpid():
        return True
    if sys.platform == "win32":
        import ctypes
        h = ctypes.windll.kernel32.OpenProcess(0x1000, False, int(pid))   # PROCESS_QUERY_LIMITED_INFORMATION
        if not h:
            return False
        code = ctypes.c_ulong()
        ctypes.windll.kernel32.GetExitCodeProcess(h, ctypes.byref(code))
        ctypes.windll.kernel32.CloseHandle(h)
        return code.value == 259                                           # STILL_ACTIVE
    try:
        os.kill(int(pid), 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        return True


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


class TaskStore:
    def __init__(self, path: Path):
        self.path = Path(path)
        if self.path.name == "studio.db" and self.path.parent.name == "data" and self.path.parent.parent.name == "Studio":
            from ..migrations import migrate
            migrate(self.path.parents[2])
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.db() as c:
            c.executescript(SCHEMA)
            self._add_call_columns(c)

    @staticmethod
    def _add_call_columns(c) -> None:
        present = {r["name"] for r in c.execute("PRAGMA table_info(calls)")}
        for name, kind in CALL_COLUMNS:
            if name not in present:
                c.execute(f"ALTER TABLE calls ADD COLUMN {name} {kind}")
        c.execute("CREATE INDEX IF NOT EXISTS calls_task ON calls(task_id)")
        c.execute("INSERT OR IGNORE INTO schema_migrations VALUES (?, strftime('%Y-%m-%dT%H:%M:%SZ','now'))", (USAGE_PER_TASK,))

    @contextmanager
    def db(self):
        c = sqlite3.connect(self.path, timeout=30, isolation_level=None)
        c.row_factory = sqlite3.Row
        c.execute("PRAGMA journal_mode=WAL")
        c.execute("PRAGMA busy_timeout=30000")
        try:
            yield c
        finally:
            c.close()

    # -- usage (tool calls, to track subscription limits) ------
    def count_usage(self, tool: str) -> None:
        day = datetime.now().strftime("%Y-%m-%d")
        with self.db() as c:
            c.execute("INSERT INTO usage(day,tool,calls) VALUES (?,?,1) ON CONFLICT(day,tool) DO UPDATE SET calls=calls+1",
                      (day, tool))

    def log_call(self, family: str, usage: str, *, target: str = "", role: str = "", model: str = "",
                    duration_s: float = 0.0, tokens: dict | None = None, cost_usd: float | None = None, ok: bool = True,
                    task_id: str = "", attempt: int | None = None, stage: str = "") -> None:
        """A real call to an AI tool (never a simulation): enough to read usage in time, tokens and
        API-equivalent cost — subscriptions limit usage per window of a few hours and per week.
        task_id / attempt / stage: which task, which attempt and which step paid for it (empty outside a task)."""
        j = tokens or {}
        n = datetime.now()
        with self.db() as c:
            c.execute("INSERT INTO calls(at,day,family,usage,target,role,model,duration_s,input_tokens,output_tokens,"
                      "cache_tokens,cost_usd,ok,task_id,attempt,stage) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                      (n.isoformat(timespec="seconds"), n.strftime("%Y-%m-%d"), family, usage, target, role, model,
                       round(float(duration_s or 0), 1), j.get("input"), j.get("output"), j.get("cache"), cost_usd, int(bool(ok)),
                       task_id or None, attempt, stage or None))

    def task_usage(self, tid: str) -> dict:
        """Calls paid by one task, per attempt and step, with totals. A missing counter stays unknown (None), never 0."""
        with self.db() as c:
            rows = [dict(r) for r in c.execute(
                "SELECT at, attempt, stage, family, role, model, duration_s, input_tokens, cache_tokens, output_tokens, cost_usd, ok "
                "FROM calls WHERE task_id = ? ORDER BY id", (tid,))]
        total = {}
        for k in ("input_tokens", "cache_tokens", "output_tokens", "cost_usd"):
            known = [r[k] for r in rows if r[k] is not None]
            total[k] = (round(sum(known), 5) if k == "cost_usd" else sum(known)) if known else None
        total["unknown"] = sum(1 for r in rows if r["input_tokens"] is None and r["output_tokens"] is None)
        return {"calls": rows, "total": {**total, "calls": len(rows)}}

    # -- task chains -----------------------------------------------------
    def create_chain(self, cid: str, target: str, title: str, stages: list, options: dict) -> None:
        stages, options = json.normalize(stages), json.normalize(options)
        with self.db() as c:
            c.execute("INSERT INTO chains(id,target,title,stages,current,status,options,created_at,updated_at) "
                      "VALUES (?,?,?,?,0,'running',?,?,?)", (cid, target, title, json.dumps(stages, ensure_ascii=False),
                                                           json.dumps(options, ensure_ascii=False), now(), now()))

    def chain(self, cid: str) -> dict | None:
        with self.db() as c:
            r = c.execute("SELECT * FROM chains WHERE id=?", (cid,)).fetchone()
        if r is None:
            return None
        d = json.normalize(dict(r))
        d["stages"], d["options"] = json.loads(d["stages"]), json.loads(d["options"])
        return d

    def update_chain(self, cid: str, **field_values) -> None:
        field_values = json.normalize(field_values)
        if "stages" in field_values:
            field_values["stages"] = json.dumps(field_values["stages"], ensure_ascii=False)
        cols = ",".join(f"{k}=?" for k in field_values)
        with self.db() as c:
            c.execute(f"UPDATE chains SET {cols},updated_at=? WHERE id=?", (*field_values.values(), now(), cid))

    def chains(self, target: str = "") -> list[dict]:
        with self.db() as c:
            ids = [r[0] for r in c.execute("SELECT id FROM chains WHERE ?='' OR target=? ORDER BY created_at DESC LIMIT 50",
                                           (target, target))]
        return [self.chain(i) for i in ids]

    # saved requests: buttons removed (maj91); the « demandes » table stays in the database, nothing is deleted.

    def api_calls(self, since: str) -> list[dict]:
        """Detailed calls since ``depuis`` (local ISO timestamp), newest first."""
        with self.db() as c:
            return [json.normalize(dict(r)) for r in c.execute("SELECT * FROM calls WHERE at >= ? ORDER BY at DESC", (since,))]

    def usage(self, days: int = 7) -> list[dict]:
        with self.db() as c:
            return [json.normalize(dict(r)) for r in c.execute("SELECT day,tool,calls FROM usage ORDER BY day DESC, tool LIMIT ?", (days * 4,))]

    # -- conversation with the Supervisor -------------------------------------
    def message(self, author: str, text: str, state: str = "ok", proposal: dict | None = None) -> int:
        proposal = json.normalize(proposal or {})
        state = json.canonical(state)
        text = custom(text) if author != "mel" else text
        with self.db() as c:
            cur = c.execute("INSERT INTO conversation(at,author,text,state,proposal) VALUES (?,?,?,?,?)",
                            (now(), author, text, state, json.dumps(proposal or {}, ensure_ascii=False)))
            return int(cur.lastrowid)

    def update_message(self, mid: int, **fields) -> None:
        fields = json.normalize(fields)
        if "text" in fields:
            fields["text"] = custom(fields["text"])
        if "proposal" in fields:
            fields["proposal"] = json.dumps(fields["proposal"], ensure_ascii=False)
        cols = ",".join(f"{k}=?" for k in fields)
        with self.db() as c:
            c.execute(f"UPDATE conversation SET {cols} WHERE id=?", (*fields.values(), mid))

    def messages(self, limit: int = 60) -> list[dict]:
        with self.db() as c:
            rows = [json.normalize(dict(r)) for r in c.execute("SELECT * FROM conversation ORDER BY id DESC LIMIT ?", (limit,))]
        for r in rows:
            r["proposal"] = json.loads(r["proposal"] or "{}")
        return rows[::-1]

    def chain_merge_messages(self, tid: str | None = None) -> list[dict]:
        """Annonces de fusion encore actives, filtrées en SQL sans charger la conversation."""
        query = """SELECT id, proposal FROM conversation
                   WHERE json_extract(proposal, '$.state') IN (?, ?, ?)"""
        params = ["chain_merge", "chain_stacked", "chain_stacked"]
        if tid is not None:
            query += " AND json_extract(proposal, '$.task') = ?"
            params.append(tid)
        with self.db() as c:
            rows = [json.normalize(dict(r)) for r in c.execute(query + " ORDER BY id", params)]
        for row in rows:
            row["proposal"] = json.loads(row["proposal"])
        return rows

    # -- tasks -------------------------------------------------------------
    def create(self, target: str, request: str, options: dict | None = None) -> str:
        options = json.normalize(options or {})
        tid = datetime.now(timezone.utc).strftime("T%Y%m%d-%H%M%S-") + uuid.uuid4().hex[:6]
        with self.db() as c:
            c.execute("INSERT INTO tasks(id,target,request,status,created_at,updated_at,options) VALUES (?,?,?,?,?,?,?)",
                      (tid, target, request, "created", now(), now(), json.dumps(options or {}, ensure_ascii=False)))
        self.event(tid, "Tâche créée")
        return tid

    def get(self, tid: str) -> dict:
        with self.db() as c:
            row = c.execute("SELECT * FROM tasks WHERE id=?", (tid,)).fetchone()
        if row is None:
            raise KeyError(f"Tâche inconnue : {tid}")
        d = json.normalize(dict(row))
        d["options"] = json.loads(d["options"])
        return d

    def list(self, limit: int = 50) -> list[dict]:
        with self.db() as c:
            return [json.normalize(dict(r)) for r in c.execute(
                "SELECT id,target,status,created_at,updated_at,summary,request,json_extract(options,'$.title') AS title,"
                " json_extract(options,'$.chain') AS chain, json_extract(options,'$.stage') AS stage,"
                # actual working time = sum of finished steps (waiting for the user's decision is not included)
                " (SELECT ROUND(SUM((julianday(s.ended_at)-julianday(s.started_at))*86400)) FROM steps s"
                "   WHERE s.task_id=tasks.id AND s.ended_at IS NOT NULL AND s.name<>'approval') AS duration_s,"
                " (SELECT s.started_at FROM steps s WHERE s.task_id=tasks.id AND s.status='en_cours'"
                "   AND s.name<>'approval' ORDER BY s.rowid DESC LIMIT 1) AS stage_since,"
                " (SELECT s.name FROM steps s WHERE s.task_id=tasks.id AND s.status='en_cours'"
                "   ORDER BY s.rowid DESC LIMIT 1) AS stage_name,"
                " (SELECT MAX(s.attempt) FROM steps s WHERE s.task_id=tasks.id) AS essai,"
                " json_extract(options,'$.outcome.cost_usd') AS cost_usd"
                " FROM tasks ORDER BY created_at DESC LIMIT ?", (limit,))]

    def log_outcome(self, tid: str, family: str, model: str, role: str, duration_s: float, cost_usd: float | None) -> None:
        """What a task cost (AI, model, role, time, cost summed over its attempts): basis of « Tes résultats »."""
        with self.db() as c:
            row = c.execute("SELECT options FROM tasks WHERE id=?", (tid,)).fetchone()
            if row is None:
                return
            o = json.loads(row["options"] or "{}")
            b = o.get("outcome") if isinstance(o.get("outcome"), dict) else {}
            b.update(family=family, model=model or b.get("model", ""), role=role,
                     duration_s=round(float(b.get("duration_s") or 0) + float(duration_s or 0), 1), executions=int(b.get("executions") or 0) + 1)
            if cost_usd is not None:
                b["cost_usd"] = round(float(b.get("cost_usd") or 0) + float(cost_usd), 4)
            o["outcome"] = b
            c.execute("UPDATE tasks SET options=? WHERE id=?", (json.dumps(o, ensure_ascii=False), tid))

    def set_status(self, tid: str, status: str, summary: str | None = None) -> None:
        status = json.canonical_value(status, "status")
        summary = custom(summary)
        with self.db() as c:
            if summary is None:
                c.execute("UPDATE tasks SET status=?,updated_at=? WHERE id=?", (status, now(), tid))
            else:
                c.execute("UPDATE tasks SET status=?,summary=?,updated_at=? WHERE id=?", (status, summary, now(), tid))
        self.event(tid, f"Statut : {status}")

    def set_hash(self, tid: str, h: str) -> None:
        with self.db() as c:
            c.execute("UPDATE tasks SET result_hash=?,updated_at=? WHERE id=?", (h, now(), tid))

    def request_cancel(self, tid: str) -> None:
        with self.db() as c:
            c.execute("UPDATE tasks SET cancel_requested=1,updated_at=? WHERE id=?", (now(), tid))
        self.event(tid, "Annulation demandée")

    def request_pause(self, tid: str) -> None:
        """« Stop »: stops the current work without cancelling the task (« Reprendre » restarts it)."""
        with self.db() as c:
            c.execute("UPDATE tasks SET cancel_requested=2,updated_at=? WHERE id=? AND cancel_requested=0", (now(), tid))
        self.event(tid, "Arrêt demandé par l'utilisateur")

    def pause_requested(self, tid: str) -> bool:
        with self.db() as c:
            r = c.execute("SELECT cancel_requested FROM tasks WHERE id=?", (tid,)).fetchone()
        return bool(r and r[0] == 2)

    def clear_pause(self, tid: str) -> None:
        with self.db() as c:
            c.execute("UPDATE tasks SET cancel_requested=0 WHERE id=? AND cancel_requested=2", (tid,))

    def cancel_requested(self, tid: str) -> bool:
        with self.db() as c:
            r = c.execute("SELECT cancel_requested FROM tasks WHERE id=?", (tid,)).fetchone()
        return bool(r and r[0])

    def event(self, tid: str, msg: str) -> None:
        msg = custom(msg)
        with self.db() as c:
            c.execute("INSERT INTO events(task_id,at,message) VALUES (?,?,?)", (tid, now(), msg[:2000]))

    def events(self, tid: str) -> list[dict]:
        with self.db() as c:
            return [json.normalize(dict(r)) for r in c.execute("SELECT at,message FROM events WHERE task_id=? ORDER BY id", (tid,))]

    # -- steps, errors, files -------------------------------------------
    def step(self, tid: str, name: str, status: str, detail: str = "", attempt: int = 1) -> None:
        name, status = json.canonical_value(name, "stage_name"), json.canonical_value(status, "status")
        with self.db() as c:
            if status == "running":
                c.execute("INSERT OR REPLACE INTO steps(task_id,name,status,detail,started_at,attempt) VALUES (?,?,?,?,?,?)",
                          (tid, name, status, detail, now(), attempt))
            else:
                c.execute("INSERT OR IGNORE INTO steps(task_id,name,status,started_at,attempt) VALUES (?,?,?,?,?)",
                          (tid, name, status, now(), attempt))
                c.execute("UPDATE steps SET status=?,detail=?,ended_at=? WHERE task_id=? AND name=? AND attempt=?",
                          (status, detail[:4000], now(), tid, name, attempt))

    def steps(self, tid: str) -> list[dict]:
        with self.db() as c:
            return [json.normalize(dict(r)) for r in c.execute(
                "SELECT name,status,detail,attempt,started_at,ended_at FROM steps WHERE task_id=? ORDER BY attempt, rowid",
                (tid,))]

    def error(self, tid: str, step: str, attempt: int, msg: str) -> None:
        with self.db() as c:
            c.execute("INSERT INTO errors VALUES (?,?,?,?,?)", (tid, step, attempt, msg[:4000], now()))

    def errors(self, tid: str) -> list[dict]:
        with self.db() as c:
            return [json.normalize(dict(r)) for r in c.execute("SELECT step,attempt,message,at FROM errors WHERE task_id=?", (tid,))]

    def artifact(self, tid: str, path: str, sha: str, role: str = "") -> int:
        with self.db() as c:
            last = c.execute("SELECT version, sha256 FROM artifacts WHERE task_id=? AND path=? ORDER BY version DESC LIMIT 1",
                             (tid, path)).fetchone()
            if last and last["sha256"] == sha:
                return last["version"]
            v = (last["version"] + 1) if last else 1
            c.execute("INSERT INTO artifacts VALUES (?,?,?,?,?,?)", (tid, path, v, sha, role, now()))
            return v

    def artifacts(self, tid: str) -> list[dict]:
        with self.db() as c:
            return [json.normalize(dict(r)) for r in c.execute(
                "SELECT path,version,sha256,role,created_at FROM artifacts WHERE task_id=? ORDER BY path,version", (tid,))]

    # -- approvals --------------------------------------------------------
    def approve(self, tid: str, decision: str, h: str, comment: str = "") -> None:
        with self.db() as c:
            c.execute("UPDATE approvals SET valid=0 WHERE task_id=?", (tid,))
            c.execute("INSERT INTO approvals VALUES (?,?,?,?,?,1)", (tid, decision, h, comment[:2000], now()))

    def invalidate_approvals(self, tid: str, reason: str) -> None:
        with self.db() as c:
            n = c.execute("UPDATE approvals SET valid=0 WHERE task_id=? AND valid=1", (tid,)).rowcount
        if n:
            self.event(tid, f"Approbation invalidée : {reason}")

    def approvals(self, tid: str) -> list[dict]:
        with self.db() as c:
            return [json.normalize(dict(r)) for r in c.execute("SELECT * FROM approvals WHERE task_id=? ORDER BY at", (tid,))]

    # -- concurrency slots ---------------------------------------------
    def acquire_slot(self, tid: str, max_slots: int):
        """Concurrency slot. Returns True, False (limit reached) or "deja_en_cours".
        Slots of a vanished process (interruption, forced stop) are reclaimed."""
        with self.db() as c:
            c.execute("BEGIN IMMEDIATE")
            try:
                rows = c.execute("SELECT slot, task_id, pid FROM slots").fetchall()
                for r in rows:
                    if r["task_id"] and not pid_alive(r["pid"]):
                        c.execute("DELETE FROM slots WHERE slot=?", (r["slot"],))
                rows = c.execute("SELECT slot, task_id, pid FROM slots").fetchall()
                if any(r["task_id"] == tid for r in rows):
                    c.execute("COMMIT")
                    return "already_running"
                busy = {r["slot"] for r in rows if r["task_id"]}
                free = [i for i in range(max_slots) if i not in busy]
                if not free:
                    c.execute("COMMIT")
                    return False
                c.execute("INSERT OR REPLACE INTO slots VALUES (?,?,?,?)", (free[0], tid, now(), os.getpid()))
                c.execute("COMMIT")
                return True
            except Exception:
                c.execute("ROLLBACK")
                raise

    def holds_slot(self, tid: str) -> bool:
        """The task is being run right now by a living process (its graph holds a concurrency slot)."""
        with self.db() as c:
            r = c.execute("SELECT pid FROM slots WHERE task_id=?", (tid,)).fetchone()
        return bool(r) and pid_alive(r["pid"])

    def release_slot(self, tid: str) -> None:
        with self.db() as c:
            c.execute("DELETE FROM slots WHERE task_id=?", (tid,))
