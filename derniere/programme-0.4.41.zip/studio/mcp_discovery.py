"""Inventaire MCP en lecture seule ; aucune configuration détectée n'est importée ni exécutée."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path, PureWindowsPath
import re
import tomllib

from .security import contains_secret


def _label(value, fallback):
    value = str(value or '')
    if not re.fullmatch(r'[\w .()\-]{1,100}', value) or contains_secret(value):
        return fallback
    return value


def _command(conf):
    # Ne jamais exposer args, env, headers, URL, ni le chemin contenant des identifiants.
    raw = conf.get('command', '')
    if isinstance(raw, list):
        raw = raw[0] if raw else ''
    raw = str(raw).strip()
    match = re.match(r'^"([^"]+)"|^\'([^\']+)\'|^([^\s]+)', raw)
    exe = next((v for v in match.groups() if v), '') if match else ''
    # Dans une configuration MCP, un exécutable Windows peut contenir des espaces sans guillemets.
    if re.match(r'^(?:[A-Za-z]:[\\/]|\\\\)', raw):
        program = re.match(r'^(.+?\.(?:exe|cmd|bat|com))(?:\s|$)', raw, re.I)
        if program:
            exe = program[1]
    name = PureWindowsPath(exe).name
    return _label(name, 'Commande masquée') if name else 'Connexion distante'


def configuration_files(studio, home=None):
    """Emplacements bornés : studio, dossiers des outils et fiches des projets, sans parcourir les projets."""
    home = Path(home) if home is not None else Path.home()
    roots = [(studio.paths.root, 'Studio')]
    for folder in sorted(home.glob('.*')):
        if folder.is_dir() and not folder.is_symlink():
            roots.append((folder, 'Configuration utilisateur'))
    config = home / '.config'
    if config.is_dir():
        roots += [(f, 'Configuration utilisateur') for f in sorted(config.iterdir()) if f.is_dir() and not f.is_symlink()]
    for target in studio.registry.all():
        if target.has_path:
            roots.append((Path(target.path()), 'Configuration de projet'))
    names = ('.mcp.json', 'mcp.json', 'config.json', 'config.toml', 'settings.json', 'settings.toml', 'mcp-config.json')
    seen = set()
    for folder, origin in roots:
        for name in names:
            file = folder / name
            if file not in seen:
                seen.add(file)
                yield file, origin + ' · ' + name
    for file in sorted(home.glob('.*.json')):
        yield file, 'Configuration utilisateur · ' + _label(file.name, 'JSON')


def _servers(doc, depth=0):
    if not isinstance(doc, dict) or depth > 5:
        return
    for key, value in doc.items():
        if key in ('mcpServers', 'mcp_servers', 'servers') and isinstance(value, dict):
            for name, conf in value.items():
                if isinstance(conf, dict) and any(k in conf for k in ('command', 'url', 'serverUrl')):
                    yield name, conf
        elif isinstance(value, dict) and key not in ('env', 'headers', 'args'):
            yield from _servers(value, depth + 1)


def detected(studio, home=None):
    from .mcp_client import memory_server
    entries = [('studio-memory', memory_server(), 'Studio · mémoire partagée')]
    for file, origin in configuration_files(studio, home):
        try:
            if file.is_symlink() or not file.is_file() or file.stat().st_size > 2 * 1024 * 1024:
                continue
            text = file.read_text(encoding='utf-8-sig')
            doc = tomllib.loads(text) if file.suffix == '.toml' else json.loads(text)
            entries += [(name, conf, origin) for name, conf in _servers(doc)]
        except (OSError, ValueError, RecursionError):
            continue
    result, seen = [], set()
    for name, conf, origin in entries:
        label, command = _label(name, 'Serveur MCP'), _command(conf)
        key = (label, command, origin)
        if key in seen:
            continue
        seen.add(key)
        ident = 'detected-' + hashlib.sha256(repr(key).encode()).hexdigest()[:16]
        result.append({'id': ident, 'name': label, 'command': command, 'origin': origin,
                       'type': 'mcp', 'kind': 'mcp', 'installed': True, 'detected': True,
                       'auto': True, 'core': True, 'domain': 'custom', 'state': 'detected',
                       'description': command + ' · ' + origin, 'author': 'Configuration détectée', 'used_by': None})
    return result
