"""« Tes résultats »: the studio learns from your own tasks which model does each type of work best.

For each finished task: the trade (type of work), the AI and model that did it, whether it was validated on the
first try (no « corriger » from you nor resume after audit), the time and the cost. Nothing leaves the PC.
"""
from __future__ import annotations

from .migrations import compatibility as json

FINISHED = ("approved", "applied", "cancelled", "failed")
MIN_TASKS = 3                      # below this, not enough hindsight to advise


def _tasks(store) -> list[dict]:
    with store.db() as c:
        rows = c.execute("SELECT t.id, t.status, t.options, "
                           "(SELECT COUNT(*) FROM approvals a WHERE a.task_id=t.id AND a.decision='correct') AS corrections, "
                           "(SELECT MAX(attempt) FROM steps s WHERE s.task_id=t.id) AS attempts "
                           "FROM tasks t WHERE t.status IN (?,?,?,?) AND json_extract(t.options,'$.outcome') IS NOT NULL",
                           FINISHED).fetchall()
    out = []
    for r in rows:
        b = (json.loads(r["options"] or "{}").get("outcome") or {})
        if not b.get("family"):
            continue
        succeeded = r["status"] in ("approved", "applied")
        out.append({"role": b.get("role", ""), "ai": b["family"] + (f" · {b['model']}" if b.get("model") else ""),
                    "succeeded": succeeded, "first_attempt": succeeded and not r["corrections"] and (r["attempts"] or 1) <= 1,
                    "duration_s": float(b.get("duration_s") or 0), "cost_usd": b.get("cost_usd")})
    return out


def results(studio) -> dict:
    """Per type of work then per model: count, first-try success, final success, average time and cost."""
    groups: dict[tuple[str, str], list[dict]] = {}
    for t in _tasks(studio.store):
        groups.setdefault((t["role"], t["ai"]), []).append(t)
    names = {r.id: r.name for r in studio.roles.values()}
    rows = []
    for (role, ai), ts in groups.items():
        costs = [t["cost_usd"] for t in ts if t["cost_usd"] is not None]
        rows.append({"role": role, "work": names.get(role, role or "—"), "ai": ai, "tasks": len(ts),
                       "first_attempt": sum(t["first_attempt"] for t in ts), "succeeded": sum(t["succeeded"] for t in ts),
                       "average_duration_s": round(sum(t["duration_s"] for t in ts) / len(ts)),
                       "average_cost_usd": round(sum(costs) / len(costs), 4) if costs else None})
    rows.sort(key=lambda x: (x["work"].lower(), -x["first_attempt"] / x["tasks"], -x["tasks"]))
    return {"rows": rows, "total": sum(x["tasks"] for x in rows), "min": MIN_TASKS}


def advice(studio, role: str) -> dict | None:
    """Best model for this type of work based on your tasks (at least MIN_TACHES), otherwise None."""
    if not role:
        return None
    cands = [x for x in results(studio)["rows"] if x["role"] == role and x["tasks"] >= MIN_TASKS]
    if not cands:
        return None
    best = max(cands, key=lambda x: (x["first_attempt"] / x["tasks"], x["succeeded"] / x["tasks"],
                                      -(x["average_cost_usd"] or 0), -x["average_duration_s"]))
    return {"ai": best["ai"], "first_attempt": best["first_attempt"], "tasks": best["tasks"],
            "text": f"D'après tes tâches : {best['ai']} réussit ce travail du premier coup {best['first_attempt']} fois sur {best['tasks']}."}
