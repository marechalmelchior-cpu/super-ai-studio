"""Claude and Codex subscription limits, as percentages (5-hour window and week).

- **Codex**: every Codex session (CLI, app, studio tasks) writes its limits to
  ``~/.codex/sessions/YYYY/MM/DD/rollout-*.jsonl`` (``token_count`` event → ``rate_limits``). The last value is read,
  without network. It dates from the last Codex use: if its reset time has passed, the window is at 0 %.
- **Claude**: the same figures as Claude Code's ``/usage`` command, requested from Anthropic with the login already
  saved by Claude Code (``~/.claude/.credentials.json``). Undocumented endpoint: it may change; on failure, the
  studio shows « indisponible » and nothing else breaks. The token is never displayed, written or logged.

Nothing is installed, nothing is modified: read-only. Can be disabled in studio.config.toml, [usage] limites_claude /
secondary_limits = false.
"""
from __future__ import annotations

from .migrations import compatibility as json
import threading
import time
import urllib.error
import urllib.request
from datetime import datetime
from .migrations.compatibility import TechnicalPath as Path

PRIMARY_USAGE_URL = "https://api.anthropic.com/api/oauth/usage"
_cache: dict[str, tuple[float, dict]] = {}
_lock = threading.Lock()


def _epoch(v) -> float | None:
    """Timestamp in seconds since 1970: number (s or ms) or ISO 8601 text."""
    if v is None or v == "":
        return None
    if isinstance(v, (int, float)):
        return float(v) / (1000 if v > 1e12 else 1)
    try:
        return datetime.fromisoformat(str(v).replace("Z", "+00:00")).timestamp()
    except ValueError:
        return None


def _window_name(minutes: float | None, fallback: str) -> str:
    if not minutes:
        return fallback
    return "5 h" if minutes <= 6 * 60 else "Semaine" if minutes >= 6 * 24 * 60 else f"{round(minutes / 60)} h"


def _window(name: str, pct, reset, current_time: float) -> dict:
    pct = max(0.0, min(100.0, float(pct or 0)))
    r = _epoch(reset)
    passe = r is not None and r <= current_time
    return {"name": name, "pct": 0.0 if passe else round(pct, 1), "reset": r, "reset_detected": passe}


# ---------------------------------------------------------------- Codex
def _last_rate_limits(file: Path) -> tuple[dict | None, str]:
    """Last non-empty ``rate_limits`` block of a Codex session log (read from the end, chunk by chunk)."""
    try:
        with file.open("rb") as f:
            f.seek(0, 2)
            finish = f.tell()
            leftover = b""
            pos = finish
            while pos > 0:
                step = min(256 * 1024, pos)
                pos -= step
                f.seek(pos)
                block = f.read(step) + leftover
                rows = block.split(b"\n")
                leftover = rows[0] if pos > 0 else b""
                for line in reversed(rows[1:] if pos > 0 else rows):
                    if b'"rate_limits"' not in line:
                        continue
                    try:
                        d = json.loads(line)
                    except ValueError:
                        continue
                    p = d.get("payload") if isinstance(d.get("payload"), dict) else d
                    rl = p.get("rate_limits") or (p.get("info") or {}).get("rate_limits") if isinstance(p, dict) else None
                    if isinstance(rl, dict) and (rl.get("primary") or rl.get("secondary")):
                        return rl, str(d.get("timestamp") or "")
                if finish - pos > 64 * 1024 * 1024:          # huge log: don't spend all day on it
                    break
    except OSError:
        pass
    return None, ""


def secondary_cli_limits(home: Path | None = None, current_time: float | None = None) -> dict:
    current_time = current_time or time.time()
    root_dir = Path(home or Path.home()) / ".codex" / "sessions"
    if not root_dir.is_dir():
        return {"ok": False, "info": "Aucune session Codex trouvée sur ce PC."}
    kept_days = sorted((d for a in root_dir.iterdir() if a.is_dir() and a.name.isdigit()
                    for m in a.iterdir() if m.is_dir() for d in m.iterdir() if d.is_dir()), reverse=True)
    for d in kept_days[:14]:                                  # two weeks at most: nothing useful beyond that
        for f in sorted(d.glob("rollout-*.jsonl"), key=lambda p: p.stat().st_mtime, reverse=True)[:20]:
            rl, when = _last_rate_limits(f)
            if not rl:
                continue
            seen = _epoch(when) or f.stat().st_mtime
            wins = []
            for key, fallback in (("primary", "5 h"), ("secondary", "Semaine")):
                w = rl.get(key)
                if not isinstance(w, dict):
                    continue
                reset = w.get("resets_at")
                if reset is None and w.get("resets_in_seconds") is not None:
                    reset = seen + float(w["resets_in_seconds"])
                wins.append(_window(_window_name(w.get("window_minutes"), fallback), w.get("used_percent"), reset, current_time))
            wins.sort(key=lambda x: x["name"] != "5 h")
            if wins:
                return {"ok": True, "windows": wins, "seen": seen, "offer": str(rl.get("plan_type") or ""),
                        "info": "Dernière valeur relevée par Codex (mise à jour à chaque utilisation de Codex)."}
    return {"ok": False, "info": "Codex n'a encore enregistré aucune limite (utilise-le une fois)."}


# ---------------------------------------------------------------- Claude
def _primary_cli_token(home: Path) -> tuple[str, str]:
    f = home / ".claude" / ".credentials.json"
    try:
        d = json.loads(f.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return "", "Connexion de Claude Code introuvable sur ce PC."
    o = d.get("claudeAiOauth") if isinstance(d, dict) else None
    if not isinstance(o, dict) or not o.get("accessToken"):
        return "", "Claude Code n'est pas connecté avec un abonnement."
    exp = _epoch(o.get("expiresAt"))
    if exp and exp < time.time():
        return "", EXPIRED
    return str(o["accessToken"]), ""


EXPIRED = "Reconnexion de Claude Code en cours…"
_reconnection = {"t": 0.0, "running": False}


def reconnect_primary_cli(cfg: dict, home: Path | None = None, launch=None) -> dict:
    """Claude Code login expired (token valid a few hours): Claude Code renews it itself.
    1) « claude auth status » (no model call); 2) if needed, a one-word reply from Haiku (negligible cost).
    The studio never reads, writes or displays the token. Returns {"ok", "info", "connexion"}."""
    import subprocess
    from .connectors.base import NO_WINDOW, find_exe
    from .connectors.primary_cli import WIN_CANDIDATES
    home = Path(home or Path.home())
    exe = find_exe(cfg.get("tools", {}).get("primary_cli", "claude"), WIN_CANDIDATES)
    if not exe:
        return {"ok": False, "info": "Claude Code n'est pas installé sur ce PC.", "connection": False}
    launch = launch or (lambda cmd, delay: subprocess.run(cmd, capture_output=True, text=True, timeout=delay, cwd=str(home),
                                                          stdin=subprocess.DEVNULL, **NO_WINDOW))
    for cmd, delay in (([exe, "auth", "status"], 30),
                       ([exe, "-p", "Réponds seulement : ok", "--model", "haiku", "--max-turns", "1"], 120)):
        try:
            launch(cmd, delay)
        except (OSError, subprocess.TimeoutExpired):
            continue
        token, reason = _primary_cli_token(home)
        if token:
            with _lock:
                _cache.pop("claude", None)
            return {"ok": True, "info": "Claude Code reconnecté.", "connection": True}
    token, reason = _primary_cli_token(home)
    return {"ok": False, "info": "Claude Code demande de te reconnecter : clique « Se connecter ».", "connection": True}


def primary_cli_connection(cfg: dict) -> dict:
    """Opens « claude auth login » in a window on the PC (browser to sign you in). Nothing else."""
    import subprocess
    import sys
    from .connectors.base import find_exe
    from .connectors.primary_cli import WIN_CANDIDATES
    exe = find_exe(cfg.get("tools", {}).get("primary_cli", "claude"), WIN_CANDIDATES)
    if not exe:
        raise ValueError("Claude Code n'est pas installé sur ce PC.")
    if sys.platform == "win32":
        subprocess.Popen(["cmd", "/c", "start", "Connexion Claude Code", "cmd", "/k", exe, "auth", "login"],
                         creationflags=0x00000010)                    # new visible console
    else:
        subprocess.Popen([exe, "auth", "login"], start_new_session=True)
    with _lock:
        _cache.pop("claude", None)
    return {"ok": True, "info": "Une fenêtre de connexion Claude Code s'est ouverte sur le PC : suis-la, puis reviens ici."}


def secondary_cli_connection(cfg: dict) -> dict:
    """Opens « codex login » in a window on the PC (sign-in with the ChatGPT subscription). Nothing else."""
    import subprocess
    import sys
    from .connectors.base import find_exe
    exe = find_exe(cfg.get("tools", {}).get("secondary_cli", "codex"))
    if not exe:
        raise ValueError("Codex n'est pas installé sur ce PC.")
    if sys.platform == "win32":
        subprocess.Popen(["cmd", "/c", "start", "Connexion Codex", "cmd", "/k", exe, "login"], creationflags=0x00000010)
    else:
        subprocess.Popen([exe, "login"], start_new_session=True)
    with _lock:
        _cache.pop("codex", None)
    return {"ok": True, "info": "Une fenêtre de connexion Codex s'est ouverte sur le PC : suis-la, puis reviens ici."}


def _reconnect_in_background(cfg: dict, home: Path | None) -> None:
    """At most one automatic attempt every 30 min, never two at once."""
    with _lock:
        if _reconnection["running"] or time.monotonic() - _reconnection["t"] < 1800 and _reconnection["t"]:
            return
        _reconnection.update(running=True, t=time.monotonic())

    def run():
        try:
            reconnect_primary_cli(cfg, home)
        finally:
            with _lock:
                _reconnection["running"] = False
                _cache.pop("claude", None)
    threading.Thread(target=run, daemon=True).start()


def read_primary_cli_answer(d: dict, current_time: float | None = None) -> list[dict]:
    """Two known shapes: ``{"five_hour": {"utilization", "resets_at"}, "seven_day": …}`` and
    ``{"limits": [{"kind", "percent", "resets_at", "scope": {"model": {"display_name"}}}]}``."""
    current_time = current_time or time.time()
    wins = []
    if isinstance(d.get("limits"), list):
        names = {"session": "5 h", "five_hour": "5 h", "weekly_all": "Semaine", "seven_day": "Semaine"}
        for x in d["limits"]:
            if not isinstance(x, dict) or x.get("percent") is None:
                continue
            model = ((x.get("scope") or {}).get("model") or {}).get("display_name") if isinstance(x.get("scope"), dict) else None
            name = f"Sem. {model}" if model else names.get(str(x.get("kind")), str(x.get("kind") or "?"))
            wins.append(_window(name, x["percent"], x.get("resets_at"), current_time))
    else:
        for key, name in (("five_hour", "5 h"), ("seven_day", "Semaine"), ("seven_day_opus", "Sem. Opus"),
                         ("seven_day_sonnet", "Sem. Sonnet")):
            w = d.get(key)
            if isinstance(w, dict) and w.get("utilization") is not None:
                wins.append(_window(name, w["utilization"], w.get("resets_at"), current_time))
        if not wins:                                     # other shape: any window {utilization | percent | used_percentage}
            for key, w in d.items():
                if isinstance(w, dict):
                    v = next((w[k] for k in ("utilization", "percent", "used_percentage") if w.get(k) is not None), None)
                    if v is not None:
                        wins.append(_window(str(key).replace("_", " "), v, w.get("resets_at"), current_time))
    return wins


def primary_cli_limits(home: Path | None = None, delay_s: float = 8, open_=urllib.request.urlopen) -> dict:
    token, reason = _primary_cli_token(Path(home or Path.home()))
    if not token:
        return {"ok": False, "info": reason}
    req = urllib.request.Request(PRIMARY_USAGE_URL, headers={"Authorization": f"Bearer {token}", "anthropic-beta": "oauth-2025-04-20",
                                                      "Accept": "application/json", "User-Agent": "super-ai-agent-pro-station"})
    del token
    try:
        with open_(req, timeout=delay_s) as r:
            d = json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:                  # message without headers or token
        return {"ok": False, "info": "Connexion refusée : relance Claude Code une fois." if e.code in (401, 403)
                else f"Anthropic ne donne pas les limites pour l'instant (code {e.code})."}
    except (urllib.error.URLError, TimeoutError, OSError, ValueError) as e:
        return {"ok": False, "info": f"Limites Claude indisponibles ({type(e).__name__})."}
    wins = read_primary_cli_answer(d if isinstance(d, dict) else {})
    if not wins:
        return {"ok": False, "info": "Réponse d'Anthropic sans limites lisibles (format changé ?)."}
    return {"ok": True, "windows": wins, "seen": time.time(), "info": "Mêmes chiffres que /usage dans Claude Code."}


def _window_duration(name: str) -> float | None:
    if name.startswith("Sem"):
        return 7 * 86400.0
    m = __import__("re").match(r"(\d+) h", name)
    return float(m.group(1)) * 3600 if m else None


def alerts(lim: dict, thresholds: dict, current_time: float | None = None) -> list[dict]:
    """Alerts when, at the current rate, the limit will be reached in less than ``seuil`` minutes (and before its reset).

    Rate = percentage used since the window started (reset − duration). Nothing if the limits are
    unavailable: better no alert than a meaningless one."""
    current_time = current_time or time.time()
    out = []
    for tool in ("Claude", "Codex"):
        threshold = int(thresholds.get(tool, 0) or 0)
        l = lim.get(tool) or {}
        if not threshold or not l.get("ok"):
            continue
        for f in l.get("windows", []):
            pct, reset, length_s = f.get("pct") or 0, f.get("reset"), _window_duration(f.get("name", ""))
            if not reset or not length_s or f.get("reset_detected") or reset <= current_time:
                continue
            base = {"tool": tool, "window": f["name"], "pct": pct, "reset": reset, "threshold": threshold}
            if pct >= 100:
                out.append({**base, "minutes": 0})
                continue
            elapsed = current_time - (reset - length_s)
            if pct <= 0 or elapsed < 600:                  # less than 10 min of history: rate not reliable
                continue
            remaining = (100 - pct) / (pct / elapsed)
            if remaining <= threshold * 60 and current_time + remaining < reset:
                out.append({**base, "minutes": max(1, round(remaining / 60))})
    return out


def limits(cfg: dict, home: Path | None = None, cache_s: float = 60) -> dict:
    """Limits of both tools; Claude is cached for 60 s (at most one request per minute)."""
    u = cfg.get("usage", {})
    out = {}
    if u.get("primary_limits", True):
        with _lock:
            t, v = _cache.get("claude", (0.0, {}))
            if time.monotonic() - t > cache_s or not v:
                v = primary_cli_limits(home)
                _cache["claude"] = (time.monotonic(), v)
        if not v.get("ok") and v.get("info") == EXPIRED and u.get("reconnection_auto", True):
            _reconnect_in_background(cfg, home)               # login expired: renewed on its own, in the background
            v = {**v, "reconnection": "running" if _reconnection["running"] else 'button'}
            if not _reconnection["running"]:
                v["info"] = "Connexion de Claude Code expirée."
        elif not v.get("ok") and ("refusée" in v.get("info", "") or "pas connecté" in v.get("info", "")):
            v = {**v, "reconnection": 'button'}
        out["Claude"] = v
    else:
        out["Claude"] = {"ok": False, "info": "Désactivé ([usage] limites_claude)."}
    out["Codex"] = secondary_cli_limits(home) if u.get("secondary_limits", True) else {"ok": False, "info": "Désactivé ([usage] limites_codex)."}
    out['current_time'] = time.time()
    return out
