"""Single memory connector of the studio.

Responsibilities:
- enforce the scope on write (one write = one explicit scope) and on
  read (every result is re-checked, whatever the engine returns);
- guarantee idempotence (stable key, local lock per scope);
- handle corrections and contradictions (computed at read time, nothing is deleted);
- make an outage visible: MemoryUnavailable, writes queued locally
  marked « non partagées », EN_PANNE state.
It never switches from one backend to another on its own.
"""
from __future__ import annotations
from ..migrations.compatibility import legacy_path, shared_database

from ..migrations import compatibility as json
import re
import sqlite3
import time
import uuid
from contextlib import contextmanager
from ..migrations.compatibility import TechnicalPath as Path
from typing import Iterable

from ..security import assert_no_secret
from .models import (GENERAL, Health, MemoryRecord, MemoryUnavailable, Provenance, Scope,
                     WriteResult, content_key, normalize, utcnow)

OUTBOX_SCHEMA = """
CREATE TABLE IF NOT EXISTS outbox (
  label TEXT NOT NULL, key TEXT NOT NULL, payload TEXT NOT NULL,
  created_at TEXT NOT NULL, attempts INTEGER NOT NULL DEFAULT 0, last_error TEXT NOT NULL DEFAULT '',
  PRIMARY KEY(label, key));
CREATE TABLE IF NOT EXISTS write_locks (label TEXT PRIMARY KEY, holder TEXT, since REAL);
"""


class MemoryConnector:
    def __init__(self, backend, state_db: Path, task_ttl_days: int = 14):
        self.backend = backend
        self.state_db = Path(state_db)
        self.state_db.parent.mkdir(parents=True, exist_ok=True)
        self.task_ttl_days = task_ttl_days
        with self._db() as c:
            c.executescript(OUTBOX_SCHEMA)
        self.last_error = ""

    @contextmanager
    def _db(self):
        c = sqlite3.connect(legacy_path(self.state_db), timeout=30, isolation_level=None)
        c.execute("PRAGMA journal_mode=WAL")
        c.execute("PRAGMA busy_timeout=30000")
        try:
            yield c
        finally:
            c.close()

    @contextmanager
    def _scope_lock(self, scope: Scope, timeout: float = 30.0):
        """Inter-process lock (studio, CLI called by the subscription tools)."""
        deadline = time.time() + timeout
        holder = uuid.uuid4().hex
        with self._db() as c:
            while True:
                try:
                    c.execute("BEGIN IMMEDIATE")
                    row = c.execute("SELECT since FROM write_locks WHERE label=?", (scope.label,)).fetchone()
                    if row is None or time.time() - row[0] > 120:   # abandoned lock
                        c.execute("INSERT OR REPLACE INTO write_locks VALUES (?,?,?)", (scope.label, holder, time.time()))
                        c.execute("COMMIT")
                        break
                    c.execute("COMMIT")
                except sqlite3.OperationalError:
                    try:
                        c.execute("ROLLBACK")
                    except sqlite3.OperationalError:
                        pass
                if time.time() > deadline:
                    raise TimeoutError(f"Portée {scope.label} verrouillée par une autre écriture.")
                time.sleep(0.05)
            try:
                yield
            finally:
                c.execute("DELETE FROM write_locks WHERE label=? AND holder=?", (scope.label, holder))

    # ------------------------------------------------------------------ health
    def health(self) -> Health:
        pending = self.pending_count()
        try:
            info = self.backend.ping()
        except MemoryUnavailable as e:
            self.last_error = str(e)
            return Health("EN_PANNE", self.backend.name, str(e), pending)
        state = "DEGRADE" if pending else "OK"
        detail = info.get("detail", "")
        if pending:
            detail += f" — {pending} écriture(s) locale(s) pas encore partagée(s)"
        return Health(state, self.backend.name, detail, pending)

    def pending_count(self) -> int:
        with self._db() as c:
            return c.execute("SELECT COUNT(*) FROM outbox").fetchone()[0]

    # --------------------------------------------------------------- writing
    def remember(self, scope: Scope, content: str, provenance: Provenance, *, key: str | None = None,
                 subject: str = "", type: str = "fact", supersedes: str = "") -> WriteResult:
        if not isinstance(scope, Scope):
            raise TypeError("Une portée explicite (Scope) est obligatoire.")
        content = content.strip()
        if not content:
            raise ValueError("Souvenir vide.")
        assert_no_secret(content, "mémoire")
        rec = MemoryRecord(scope=scope, content=content, key=key or content_key(scope, content),
                           provenance=provenance, type=type, subject=subject.strip(), supersedes=supersedes)
        try:
            with self._scope_lock(scope):
                existing = self.backend.list(scope)
                known = {r.key for r in existing}
                if supersedes and not set(supersedes.split(",")) <= known:
                    raise ValueError("Le souvenir à corriger n'existe pas dans cette portée.")
                backend_id, created = self.backend.put(rec)
        except MemoryUnavailable as e:
            self.last_error = str(e)
            self._enqueue(rec, str(e))
            return WriteResult("pending_unshared", rec,
                               "Mémoire centrale en panne : écriture conservée localement, NON partagée.")
        rec.backend_id = backend_id
        status = "created" if created else "already_present"
        if created and subject and not supersedes:
            rivals = [r for r in existing if r.subject == subject and normalize(r.content) != normalize(content)
                      and r.key not in self._superseded_keys(existing)]
            if rivals:
                status = "disputed"
        return WriteResult(status, rec)

    def correct(self, scope: Scope, old_key: str, new_content: str, provenance: Provenance) -> WriteResult:
        """New version: replaces the old memory and, if it has a topic, all
        still-active variants of that topic. History is kept."""
        recs = self.visible(scope, include_replaced=True)
        old = next((r for r in recs if r.key == old_key), None)
        if old is None:
            raise ValueError("Souvenir introuvable dans cette portée.")
        keys = {old_key} | {r.key for r in recs if old.subject and r.subject == old.subject and r.status != "remplace"}
        return self.remember(scope, new_content, provenance, subject=old.subject, type=old.type,
                             supersedes=",".join(sorted(keys)),
                             key=content_key(scope, f"corrige:{old_key}:{new_content}"))

    def resolve(self, scope: Scope, subject: str, keep_key: str, provenance: Provenance) -> list[WriteResult]:
        """Settles a contradiction: the variants not kept are marked as replaced."""
        recs = self.visible(scope, include_replaced=False)
        keep = next((r for r in recs if r.key == keep_key), None)
        if keep is None or keep.subject != subject:
            raise ValueError("Variante à conserver introuvable.")
        keys = sorted(r.key for r in recs if r.subject == subject)
        return [self.remember(scope, keep.content, provenance, subject=subject, type=keep.type,
                              supersedes=",".join(keys), key=content_key(scope, f"arbitrage:{','.join(keys)}->{keep_key}"))]

    def _enqueue(self, rec: MemoryRecord, err: str) -> None:
        payload = json.dumps(rec.to_dict(), ensure_ascii=False)
        with self._db() as c:
            c.execute("INSERT OR IGNORE INTO outbox(label,key,payload,created_at,last_error) VALUES (?,?,?,?,?)",
                      (rec.scope.label, rec.key, payload, utcnow(), err[:300]))

    def flush_outbox(self) -> dict:
        sent, failed = 0, 0
        with self._db() as c:
            rows = c.execute("SELECT label,key,payload FROM outbox ORDER BY created_at").fetchall()
        for label, key, payload in rows:
            d = json.loads(payload)
            rec = MemoryRecord(scope=Scope.parse(d["scope"]), content=d["content"], key=d["key"],
                               provenance=Provenance(**d["provenance"]), type=d["type"], subject=d["subject"],
                               supersedes=d["supersedes"], created_at=d["created_at"])
            try:
                with self._scope_lock(rec.scope):
                    self.backend.put(rec)          # idempotent: the key is checked
            except MemoryUnavailable as e:
                failed += 1
                with self._db() as c:
                    c.execute("UPDATE outbox SET attempts=attempts+1,last_error=? WHERE label=? AND key=?",
                              (str(e)[:300], label, key))
                break
            with self._db() as c:
                c.execute("DELETE FROM outbox WHERE label=? AND key=?", (label, key))
            sent += 1
        return {"sent": sent, "failures": failed, "remaining": self.pending_count()}

    # ---------------------------------------------------------------- reading
    @staticmethod
    def _superseded_keys(recs: Iterable[MemoryRecord]) -> set[str]:
        return {k for r in recs if r.supersedes for k in r.supersedes.split(",")}

    def visible(self, scope: Scope, include_replaced: bool = False) -> list[MemoryRecord]:
        recs = self.backend.list(scope)
        seen, uniq = set(), []
        for r in recs:                       # possible duplicates: keep the oldest
            if r.scope != scope or r.key in seen:
                continue
            seen.add(r.key)
            uniq.append(r)
        replaced = self._superseded_keys(uniq)
        by_subject: dict[str, set[str]] = {}
        for r in uniq:
            if r.key in replaced:
                r.status = "remplace"
            elif r.subject:
                by_subject.setdefault(r.subject, set()).add(normalize(r.content))
        for r in uniq:
            if r.status == "active" and r.subject and len(by_subject.get(r.subject, ())) > 1:
                r.status = "disputed"
        return uniq if include_replaced else [r for r in uniq if r.status != "remplace"]

    def recall(self, query: str = "", scopes: Iterable[Scope] = (), include_general: bool = True,
               limit: int = 20) -> list[MemoryRecord]:
        wanted = list(dict.fromkeys(([GENERAL] if include_general else []) + list(scopes)))
        if not wanted:
            raise ValueError("Aucune portée demandée.")
        words = [w for w in re.findall(r"\w{3,}", normalize(query))] if query else []
        results: list[tuple[float, MemoryRecord]] = []
        for scope in wanted:
            for r in self.visible(scope):
                if r.scope not in wanted:
                    continue
                text = normalize(r.content + " " + r.subject)
                score = sum(text.count(w) for w in words) if words else 1.0
                if score > 0:
                    results.append((score, r))
        results.sort(key=lambda t: (-t[0], t[1].created_at))
        return [r for _, r in results[:limit]]

    def conflicts(self, scope: Scope) -> dict[str, list[MemoryRecord]]:
        out: dict[str, list[MemoryRecord]] = {}
        for r in self.visible(scope):
            if r.status == "disputed":
                out.setdefault(r.subject, []).append(r)
        return out


def build_connector(cfg: dict, data_dir: Path, backend_override=None) -> MemoryConnector:
    m = cfg["memory"]
    if backend_override is not None:
        backend = backend_override
    elif m["backend"] == "agentmemory":
        from .backend_agentmemory import AgentMemoryBackend
        backend = AgentMemoryBackend(m["url"], float(m["timeout_s"]), task_ttl_days=int(m.get("task_ttl_days", 14)))
    elif m["backend"] == "sqlite":
        from .backend_sqlite import SqliteBackend
        backend = SqliteBackend(shared_database(data_dir, "memory-alternative.db", "memoire-alternative.db"))
    else:
        raise ValueError(f"Backend mémoire inconnu : {m['backend']}")
    return MemoryConnector(backend, shared_database(data_dir, "memory-status.db", "memoire-etat.db"), int(m.get("task_ttl_days", 14)))
