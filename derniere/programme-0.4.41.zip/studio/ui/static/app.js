"use strict";
const $ = (s) => document.querySelector(s);
const $$ = (s) => document.querySelectorAll(s);
const esc = (t) => String(t ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

let view = "projects", projectChat = null, targets = [], currentProject = null, selection = null, lastView = "";

async function api(path, body) {
  const opt = body === undefined ? {} : { method: "POST", headers: { "Content-Type": "application/json", "X-Studio": "1" }, body: JSON.stringify(body) };
  const r = await fetch(path, opt);
  const j = await r.json().catch(() => ({}));
  if (!r.ok) { const e = new Error(j.error || r.status); e.code = r.status; e.data = j; throw e; }
  if (j && j.warning) setTimeout(() => infoBubble(j.warning), 0);     // e.g. a local AI chosen while it is closed
  return j;
}

const LABELS = {
  created: "en cours", running: "en cours", awaiting_approval: "à valider", awaiting_approval_with_defects: "à valider · défauts",
  approved: "validée", applied: "appliquée", cancelled: "annulée", blocked: "bloquée", interrupted: "interrompue",
  awaiting_slot: "en attente", failed: "échec",
};
const TOOL_LABELS = { "claude-code": "Claude Code", codex: "Codex", simulation: "simulation" };
const taskLabel = (t) => t.status === "approved" && (t.summary || "").startsWith("Faite") ? "terminée" : (LABELS[t.status] || t.status);
const TO_APPROVE = ["awaiting_approval", "awaiting_approval_with_defects"];
const IN_PROGRESS = ["created", "running", "awaiting_slot", "interrupted", "blocked"];
let MODELS = [["", "Auto"], ["opus", "Opus"], ["sonnet", "Sonnet"], ["haiku", "Haiku"]];   // replaced by [choix] modeles_claude
const EFFORTS = [["", "Auto"], ["low", "Bas"], ["medium", "Moyen"], ["high", "Élevé"], ["xhigh", "Très élevé"], ["max", "Max"]];
const EFFORT_LABELS = Object.fromEntries(EFFORTS);
const MODES = [["fast", "Rapide"], ["", "Normal"], ["max", "Max"]];
let SUPERVISOR_MODELS = [["", "Auto"], ["haiku", "Haiku"], ["sonnet", "Sonnet"], ["opus", "Opus"]];
let SECONDARY_MODELS = [["", "Auto"]];                          // models of the second subscription CLI (its own list)
let supFamily = "claude-code";
const supModel = () => (supFamily === "codex" ? secondary_cliModel : supFamily === "claude-code" ? supervisorModel : "");
const readSup = (k) => { try { return storedValue(k) || ""; } catch { return ""; } };
const keepSup = (k, v) => { try { localStorage.setItem(k, v); } catch {} };
let supervisorModel = readSup("sup-model"), supervisorEffort = readSup("sup-effort"), secondary_cliModel = readSup("sup-secondary-model");   // Supervisor setting kept from one session to the next
const modelName = (m) => m.charAt(0).toUpperCase() + m.slice(1);
// Status colors: running = blue, awaiting approval = yellow, approved = green, cancelled / failed / blocked = red
const state_color = (s) => (["approved", "applied"].includes(s) ? "ok"
  : ["created", "running", "awaiting_slot"].includes(s) ? "info"
  : ["awaiting_approval", "awaiting_approval_with_defects"].includes(s) ? "warn" : "bad");
const targetName = (target) => { const c = targets.find((x) => `${x.kind}:${x.id}` === target || x.id === String(target).split(":").pop()) || projectList.find((p) => p.key === target); return c ? c.name : target; };

/* Minimal Markdown, applied AFTER escaping: no HTML from a document is ever interpreted. */
function md(text) {
  let header = "";
  const fm = String(text).match(/^---\r?\n([\s\S]*?)\r?\n---\r?\n?/);
  if (fm) {
    text = text.slice(fm[0].length);
    const desc = (fm[1].match(/^description:\s*(.*)$/m) || [])[1];
    if (desc) header = `<p class="empty">${esc(desc)}</p>`;
  }
  const rows = esc(text).replace(/\r/g, "").split("\n");
  let html = "", entries = false, code = false;
  const inline = (l) => l.replace(/`([^`]+)`/g, "<code>$1</code>").replace(/\*\*([^*]+)\*\*/g, "<b>$1</b>");
  const cells = (l) => l.trim().replace(/^\||\|$/g, "").split("|").map((c) => c.trim());
  for (let i = 0; i < rows.length; i++) {
    const l = rows[i];
    if (l.startsWith("```")) { html += code ? "</pre>" : "<pre>"; code = !code; continue; }
    if (code) { html += l + "\n"; continue; }
    if (/^\s*\|.*\|\s*$/.test(l) && /^\s*\|?\s*:?-{2,}/.test(rows[i + 1] || "")) {   // Markdown table
      if (entries) { html += "</ul>"; entries = false; }
      let t = `<div class="table-md"><table><thead><tr>${cells(l).map((c) => `<th>${inline(c)}</th>`).join("")}</tr></thead><tbody>`;
      i += 2;
      while (i < rows.length && /^\s*\|.*\|\s*$/.test(rows[i])) { t += `<tr>${cells(rows[i]).map((c) => `<td>${inline(c)}</td>`).join("")}</tr>`; i++; }
      i--; html += t + "</tbody></table></div>"; continue;
    }
    const m = l.match(/^(#{1,4})\s+(.*)$/);
    const li = l.match(/^\s*(?:[-*]|\d+\.)\s+(.*)$/);
    if (!li && entries) { html += "</ul>"; entries = false; }
    if (/^-{3,}$/.test(l.trim())) { html += "<hr>"; continue; }
    if (m) html += `<h${m[1].length + 1}>${inline(m[2])}</h${m[1].length + 1}>`;
    else if (li) { if (!entries) { html += "<ul>"; entries = true; } html += `<li>${inline(li[1])}</li>`; }
    else if (l.trim()) html += `<p>${inline(l)}</p>`;
  }
  return `<div class="content">${header}${html}${entries ? "</ul>" : ""}${code ? "</pre>" : ""}</div>`;
}

/* Durations: « 42 s », « 3 min 05 s », « 1 h 12 min ». */
function formatDuration(s) {
  s = Math.max(0, Math.round(+s || 0));
  if (s < 60) return `${s} s`;
  if (s < 3600) return `${Math.floor(s / 60)} min ${String(s % 60).padStart(2, "0")} s`;
  return `${Math.floor(s / 3600)} h ${String(Math.floor((s % 3600) / 60)).padStart(2, "0")} min`;
}
const seconds = (a, b) => (Date.parse(b || new Date().toISOString()) - Date.parse(a)) / 1000;
/* Live timer: base (seconds already counted) + time elapsed since data-depuis. */
const timer = (since, base = 0) => `<span class="timer" data-since="${esc(since)}" data-base="${Math.round(base || 0)}">${formatDuration((base || 0) + seconds(since))}</span>`;

function chipList(el, items, active, onclick) {
  el.innerHTML = items.map(([v, t]) => `<button class="chip ${v === active ?"sel" : ""}" data-v="${esc(v)}">${esc(t)}</button>`).join("");
  el.querySelectorAll(".chip").forEach((b) => (b.onclick = () => { el.querySelectorAll(".chip").forEach((x) => x.classList.remove("sel")); b.classList.add("sel"); onclick(b.dataset.v); }));
}

function showView(v) {
  view = v;
  document.body.dataset.view = v;
  document.body.classList.add("static");
  $$(".view").forEach((el) => (el.hidden = el.id !== `view-${v}`));
  renderTabs();
  if (v === "projects") (currentProject ? openProject(currentProject) : loadProjects());
  if (v === "management") showManagement();
  if (v === "custom") showCustom(!library || Date.now() - libraryLoadedAt > 120000);   // catalog cached for 2 min: instant tabs
}
/* Header: Projets / Gestion. In Projets: tabs « Tous », one per project, « + »; then two blocks. */
let projectList = [], currentBlock = "ensemble";
const ALL_BLOCKS = ["ensemble"], PROJECT_BLOCKS = ["tasks", "detail", "team", "branches", "files", "knowledge", "project"];
let projectGit = {};                                         // project key → git repo? (Branches tab)
/* Tab order: order of addition (a new project goes last), kept between sessions */
function projectOrder(entries) {
  let order = [];
  try { order = JSON.parse(storedValue("order-projects") || "[]"); } catch (e) { order = []; }
  if (!Array.isArray(order)) order = [];
  const keys = entries.map((x) => x.key);
  if (!order.length) order = [...entries].sort((a, b) => (a.kind === b.kind ? 0 : a.kind === "project" ? -1 : 1)).map((x) => x.key);
  order = order.filter((c) => keys.includes(c));
  keys.forEach((c) => { if (!order.includes(c)) order.push(c); });
  try { localStorage.setItem("order-projects", JSON.stringify(order)); } catch (e) { /* optional */ }
  return order.map((c) => entries.find((x) => x.key === c));
}
function renderTabs() {
  $$("nav button[data-view]").forEach((b) => b.classList.toggle("active", b.dataset.view === view));
  const el = $("#tabs-p");
  if (!el) return;
  $("#btn-sup").classList.toggle("active", view === "projects" && !currentProject);
  const entries = projectList.length ? projectList : targets.map((c) => ({ key: `${c.kind}:${c.id}`, name: c.name, kind: c.kind, counters: {} }));
  const order = projectOrder(entries.filter((x) => !x.internal));             // the studio itself (audits): no tab
  const badge = (n) => n ? `<span class="badge-tab" title="${n} à valider">${n}</span>` : "";
  el.innerHTML = order.map((x) => `<button role="tab" data-p="${esc(x.key)}" aria-selected="${currentProject === x.key}" title="${esc(x.name)}${x.kind === "topic" ? " (sujet)" : ""}">${esc(x.name)}${badge((x.counters || {}).awaiting_validation)}</button>`).join("")
;
  // selected tab made visible by scrolling ONLY the tab row (never the page: on phones,
  // scrollIntoView jumped the page to the top on every refresh), and only when the selection changes
  const a = el.querySelector('[aria-selected="true"]');
  if (a && el.dataset.seen !== currentProject) {
    el.dataset.seen = currentProject || "";
    const ra = a.getBoundingClientRect(), re = el.getBoundingClientRect();
    if (ra.left < re.left || ra.right > re.right) el.scrollLeft += ra.left - re.left - (re.width - ra.width) / 2;
  }
  tabEdges();
}
function tabEdges() {                                     // left / right fade when tabs are hidden
  const el = $("#tabs-p");
  if (!el) return;
  el.classList.toggle("scroll-left", el.scrollLeft > 2);
  el.classList.toggle("scroll-right", el.scrollLeft + el.clientWidth < el.scrollWidth - 2);
}
$("#tabs-p").addEventListener("scroll", tabEdges);
window.addEventListener("resize", tabEdges);
$("#tabs-p").addEventListener("wheel", (e) => {                // many projects: the mouse wheel scrolls the tabs
  const el = e.currentTarget; if (el.scrollWidth <= el.clientWidth) return;
  e.preventDefault(); el.scrollLeft += e.deltaY || e.deltaX;
}, { passive: false });
$("#tabs-p").onclick = (e) => {
  const b = e.target.closest("button");
  if (!b) return;
  const key = b.dataset.p || null;
  if (key !== currentProject) selection = null;
  if (key) openProject(key);
};
$("#plus-p").onclick = () => newProject();
$("#btn-sup").onclick = () => { selection = null; openSupervisor(); };
/* Home button: general conversation on the right, ongoing work of all projects on the left */
async function openSupervisor() {
  currentProject = null; currentBlock = "ensemble";
  try { localStorage.setItem("project-current", ""); } catch (e) { /* optional */ }
  renderTabs(); renderTabsBlock();
  placeSupervisor(null);
  const ps = await api("/api/projects");
  projectList = ps; renderTabs(); renderTabsBlock();
  workSummary(ps);
}
/* Large screens: tasks | task detail | Supervisor. The detail block moves into its own column, and back. */
const wideScreen = matchMedia("(min-width:2560px)");
const threeColumns = () => wideScreen.matches && !!currentProject;
function placeDetail() {
  const d = $("#detail"), col = $("#column-detail"), three = threeColumns();
  if (!d || !col) return;
  if (three && d.parentElement !== col) col.appendChild(d);
  if (!three && d.parentElement === col) $("#block-work").insertBefore(d, $("#block-work .panel[data-b='team']"));
  col.hidden = !three;
  document.querySelector(".p-projects").classList.toggle("three", three);
  if (three) {
    d.hidden = false; d.classList.remove("panel");
    $("#close-column").hidden = !selection;
    if (!selection) { d.dataset.tid = ""; d.innerHTML = "<div class=\"welcome\"><p class=\"empty\">Choisis une tâche à gauche : son avancement et sa validation s'affichent ici.</p></div>"; }
  } else d.classList.add("panel");
}
wideScreen.addEventListener("change", () => { placeDetail(); renderTabsBlock(); if (selection) { lastView = ""; show(); } });
$("#close-column").onclick = () => { selection = null; lastView = ""; renderTabsBlock(); taskLists(projectTasks); };
/* Work block: its tabs change depending on « Tous » or a single project */
function renderTabsBlock() {
  const el = $("#tabs-block");
  const p = projectList.find((x) => x.key === currentProject) || {};
  const c = p.counters || {};
  const toApproveTotal = projectList.reduce((n, x) => n + ((x.counters || {}).awaiting_validation || 0), 0);
  const items = !currentProject
    ? [["ensemble", `Tâches${toApproveTotal ? `<span class="badge-tab">${toApproveTotal}</span>` : ""}`], ["sup-settings", "Réglages"]]
    : [["tasks", `Tâches${c.awaiting_validation ? `<span class="badge-tab">${c.awaiting_validation}</span>` : ""}`],
       ...(selection && !threeColumns() ? [["detail", `Détail<span class="close-b" data-close-detail="1" role="button" title="Fermer la tâche" aria-label="Fermer la tâche">×</span>`]] : []),
       ["team", "Équipe"], ["files", "Résultats"], ...(projectGit[currentProject] ? [["branches", "Branches"]] : []), ...(p.kind === "project" ? [["knowledge", "Skills et mémoire"]] : []), ["project", "Réglages"]];
  if (!items.some(([k]) => k === currentBlock)) currentBlock = items[0][0];
  el.innerHTML = items.map(([k, t]) => `<button role="tab" data-b="${k}" aria-selected="${k === currentBlock}">${t}</button>`).join("");
  placeDetail();
  if (!currentProject) $("#p-header").hidden = true;
  $$("#block-work .panel").forEach((v) => (v.hidden = v.dataset.b !== currentBlock));
}
function chooseBlock(b) {
  currentBlock = b; renderTabsBlock();
  if (b === "branches" && currentProject) { gitRepository = currentProject; gitDetail(); }
  if (b === "files" && currentProject) projectFiles();
  if (b === "knowledge" && currentProject) loadProjectKnowledge();
  if (b === "project" && currentProject) loadProjectSettings();
  if (b === "team" && currentProject) teamSettings();
  if (b === "sup-settings") gSettings().catch((e) => GB("settings", `<div class="alert">${esc(e.message)}</div>`));
  if (b === "sup-settings") gPhone().catch((e) => GB("phone", `<div class="alert">${esc(e.message)}</div>`));
  if (b === "sup-settings") gAI().catch((e) => GB("ai", `<div class="alert">${esc(e.message)}</div>`));
}
$("#tabs-block").onclick = (e) => {
  if (e.target.closest("[data-close-detail]")) { selection = null; lastView = ""; currentBlock = "tasks"; renderTabsBlock(); taskLists(projectTasks); return; }
  const b = e.target.closest("button[data-b]");
  if (b) chooseBlock(b.dataset.b);
};
$("nav").onclick = (e) => {
  const b = e.target.closest("button[data-view]");
  if (!b) return;
  showView(b.dataset.view);
};
async function openPath(path) { if (sessionInfo.distant) { alert("Ça s'ouvre sur le PC : fais-le depuis le PC."); return; } try { await api("/api/open", { path_value: path }); } catch (e) { alert(e.message); } }

/* ================================================================ REQUEST */
let threadSignature = "";
async function loadConversation(scroll) {
  const scope = projectChat;
  const msgs = await api("/api/conversation" + (scope ? `?project=${encodeURIComponent(scope)}` : ""));
  if (scope !== projectChat) return;                      // the page changed during the request
  const sig = (scope || "") + "#" + userName + "#" + (aiState ? (aiState.active || "aucune") : "") + "#" + msgs.map((m) => `${m.id}:${m.state}:${m.proposal.state || ""}:${JSON.stringify(m.proposal.actions || [])}:${m.proposal.error || ""}:${m.proposal.tracking ? m.proposal.tracking.status + m.proposal.tracking.stage_name + m.proposal.tracking.cost_usd : ""}`).join("|");
  if (sig === threadSignature && !scroll) return;
  const thread = $("#thread");
  const atBottom = thread.scrollHeight - thread.scrollTop - thread.clientHeight < 40;
  threadSignature = sig;
  lastUser = (msgs.filter((m) => m.author === "mel").pop() || {}).id;
  const finish = msgs[msgs.length - 1];
  lastSupervisorId = finish && finish.author !== "mel" ? finish.id : 0;   // the user already answered: no more buttons
  const noAi = aiState && !aiState.active;
  thread.innerHTML = msgs.length ? msgs.map(bubble).join("") : (scope
    ? `<div class="empty-chat"><p class="empty">Pose une question sur ce projet ou décris un travail :<br>le Superviseur répond ou propose une tâche ici.</p>${noAi ? "" : startingPoints(scope)}</div>`
    : `<div class="empty-chat"><div class="welcome"><div class="large">Salut${userName ? " " + esc(userName) : ""}.</div>
      <p class="empty">Demande-moi où en est un projet, pose une question, ou décris un travail :<br>je réponds ou je le confie à la bonne équipe.</p>${noAi ? `<div class="cta-ai"><p class="warn">Aucune IA connectée pour l'instant.</p><button class="btn main" data-connecter-ai>Connecter une IA</button></div>` : startingPoints("")}</div></div>`);
  $$("[data-connecter-ai]").forEach((b) => (b.onclick = standard_apiSettings));
  $$("#thread [data-suggestion]").forEach((b) => (b.onclick = () => {
    $("#message").value = b.dataset.suggestion; adjustInputField();
    if (b.dataset.send) $("#send").click(); else { const m = $("#message"); m.focus(); m.setSelectionRange(m.value.length, m.value.length); }
  }));
  msgs.filter((m) => m.proposal.state === "proposed").forEach((m) => bindProposal(m).catch((error) => infoBubble(error.message)));
  $$("#thread [data-action-ai]").forEach((s) => { const m = msgs.find((x) => x.id === Number(s.dataset.rid)); const item = m?.proposal.actions[Number(s.dataset.actionAi)]; fillTaskAI(s, item?.params.ai || "").catch((error) => infoBubble(error.message)); s.disabled = item?.state !== "pending"; });
  $$("#thread [data-edit]").forEach((b) => (b.onclick = async () => {
    try {
      const r = await api(`/api/conversation/${b.dataset.edit}/edit`, {});
      if (r.launched) infoBubble("La tâche déjà lancée continue");
      $("#message").value = r.text; adjustInputField(); $("#message").focus(); threadSignature = ""; loadConversation(true);
    } catch (e) { alert(e.message); }
  }));
  $$("#thread [data-stop]").forEach((b) => (b.onclick = async () => {
    b.disabled = true;
    try { await api(`/api/conversation/${b.dataset.stop}/stop`, {}); threadSignature = ""; loadConversation(); } catch (e) { alert(e.message); }
  }));
  if (scroll || atBottom) thread.scrollTop = thread.scrollHeight;  // scrolls INSIDE the block, never the page
}
/* Starting points of an empty conversation, by kind of project. « … » = to complete before sending. */
const SUGGESTIONS = {
  home: ["Où en sont mes projets ?", "Qu'est-ce qui attend ma validation ?", "Que peux-tu faire pour moi ?", "Crée un nouveau sujet sur …"],
  code: ["Où en est ce projet ?", "Relis le code et liste les bugs probables", "Propose les 3 prochaines étapes", "Ajoute la fonctionnalité suivante : …"],
  web: ["Où en est ce site ?", "Vérifie l'accessibilité et le référencement", "Améliore la page d'accueil", "Ajoute une page : …"],
  doc: ["Résume ce qui existe déjà", "Fais un plan détaillé", "Relis et corrige le style", "Rédige la partie : …"],
  art: ["Propose 3 directions visuelles", "Fais une planche de références", "Crée une image de …", "Range et renomme les images"],
  topic: ["Résume ce qu'on sait sur ce sujet", "Cherche des références et des sources", "Propose les prochaines étapes", "Fais une recherche sur …"],
};
function startingPoints(scope) {
  const p = scope ? projectList.find((x) => x.key === scope) || {} : null;
  const kind = !p ? "home" : p.kind === "topic" ? (p.type === "art" ? "art" : "topic") : SUGGESTIONS[p.type] ? p.type : "code";
  const list = SUGGESTIONS[kind];
  return `<div class="suggestions" aria-label="Suggestions">${list.map((s) => {
    const open = s.endsWith("…");
    return `<button class="suggestion" data-suggestion="${esc(open ? s.slice(0, -1) : s)}"${open ? "" : " data-send=\"1\""}>${esc(s)}</button>`;
  }).join("")}</div>`;
}
function placeSupervisor(key) {
  projectChat = key || null;
  if ($("#wide-scope-label")) { $("#wide-scope-label").hidden = !projectChat; $("#wide-scope").checked = false; }   // narrow by default
  $("#sup-scope").textContent = key ? "conversation de ce projet" : "conversation générale";
  $("#message").placeholder = key ? "Question ou travail pour ce projet · @ fichier · / raccourci" : "Pose une question ou décris un travail · @ fichier · / raccourci";
  threadSignature = "";
  loadConversation(true);
}

let lastUser = null, userName = "";
function bubble(m) {
  if (m.author === "mel") {
    const atts = (m.proposal && m.proposal.attachments) || [];
    const views = atts.map((c) => /\.(png|jpe?g|gif|webp)$/i.test(c) ? `<img src="/api/attachment?chemin=${encodeURIComponent(c)}" alt="">` : `<span>${esc(c.split("/").slice(3).join("/"))}</span>`).join("");
    return `<div class="bubble mel"><span class="hour-msg">${msgTime(m.at)}</span>${esc(m.text)}${atts.length ? `<div class="pj">${views}</div>` : ""}${m.id === lastUser ? `<button class="link edit-msg" data-edit="${m.id}" title="Arrête la réponse si elle est en cours et remet ton texte dans la zone de saisie">Modifier</button>` : ""}</div>`;
  }
  if (m.state === "running") return `<div class="bubble sup waiting"><div class="who">Superviseur</div>réfléchit… <span class="timer" data-since="${esc(m.at)}"></span> <button class="link stop-msg" data-stop="${m.id}">Arrêter</button></div>`;
  if (m.state === "cancelled") return `<div class="bubble sup waiting"><div class="who">Superviseur</div>${esc(m.text)}</div>`;
  const p = m.proposal || {};
  let prop = "";
  if (p.state === "actions") {
    prop = renderSupervisorActions(m);
  } else if (p.state === "proposed") {
    prop = `<div class="proposal" data-id="${m.id}">
      ${p.title ? `<div class="title-prop"><b>${esc(p.title)}</b></div>` : ""}<small>Je propose de confier à</small> <b>${esc(p.target_name || p.target)}</b>${p.new_target ? " <span class=\"state warn\">nouveau sujet, créé au lancement</span>" : ""}${p.role ? ` <small>· rôle ${esc(p.role)}</small>` : ""}
      ${p.error ? `<div class="alert">${esc(p.error)}</div>` : ""}${p.advice ? `<div class="subtle advice-prop">${esc(p.advice)}</div>` : ""}
      <div class="request-prop">${md(p.request)}</div>
      <textarea class="request-edit" hidden>${esc(p.request)}</textarea>
      ${p.stages ? `<div class="chain-block"><b>Chaîne de ${p.stages.length} étapes</b> <small class="subtle">— chacune attend ta validation avant la suivante</small><ol>${p.stages.map((e) => `<li><b>${esc(e.role || "rôle choisi par le studio")}</b> — ${esc(e.request)}</li>`).join("")}</ol></div>` : ""}
      <div class="bottom-prop"><label>IA pour cette tâche <select class="p-ai"></select></label><label>Modèle <select class="p-mod"></select></label><label>Effort <select class="p-eff"></select></label><label>Mode <select class="p-mode"></select></label>
        <span class="buttons-prop"><button class="link edit-request">Modifier la demande</button><button class="btn subtle ignore">Ignorer</button><button class="btn subtle night-b" title="En file : part pendant la nuit, rapport le matin">Cette nuit</button><button class="btn main launch">Lancer</button></span></div>
      <span class="warn msg"></span></div>`;
  } else if (p.state === "launched") {
    prop = `<div class="proposal tracking-prop"><span class="ok">Lancé</span> dans <b>${esc(p.target_name || p.target)}</b> — <button class="link" data-open-task="${esc(p.task)}" data-target="${esc(p.target)}">voir la tâche</button>${liveTracking(p.tracking)}</div>`;
  } else if (p.state === "night") {
    prop = `<div class="proposal"><span class="info">Prévue cette nuit</span> dans <b>${esc(p.target_name || p.target)}</b> — part à ${esc(nightWindow[0])}, rapport le matin. Laisse le PC allumé. <button class="link" data-night-remove="${esc(p.night)}">Ne pas la faire</button></div>`;
  } else if (p.state === "team_proposed") {                // team composed by the Supervisor: one click applies it
    const e = p.team || {};
    prop = `<div class="proposal proposal-team" data-team="${m.id}"><div class="title-prop"><b>Équipe proposée pour ${esc(p.target_name || p.target || "")}</b></div>
      ${p.error ? `<div class="alert">${esc(p.error)}</div>` : ""}
      ${(e.enable || []).length ? `<p class="sub-title-g">Au travail</p><ul class="list_items-team">${e.enable.map((x) => `<li><b>${esc(x.name)}</b>${x.effort ? ` <small class="subtle">effort ${esc(x.effort)}</small>` : ""}${x.instructions ? `<br><small>${esc(x.instructions)}</small>` : ""}</li>`).join("")}</ul>` : ""}
      ${(e.disable || []).length ? `<p class="sub-title-g">Mis de côté</p><p class="subtle">${e.disable.map((x) => esc(x.name)).join(" · ")}</p>` : ""}
      ${Array.isArray(e.mcp) ? `<p class="sub-title-g">Serveurs MCP</p><p class="subtle">${e.mcp.length ? e.mcp.map(esc).join(" · ") : "aucun"}</p>` : ""}
      <div class="bottom-prop"><span class="buttons-prop"><button class="btn subtle" data-team-ignore="${m.id}">Ignorer</button><button class="btn main" data-team-apply="${m.id}"${p.error ? " disabled" : ""}>Appliquer</button></span></div>
      <span class="warn msg"></span></div>`;
  } else if (p.state === "team_applied") {
    prop = `<div class="proposal"><span class="ok">Équipe appliquée</span> à <b>${esc(p.target_name || p.target)}</b> — <button class="link" data-open-team="${esc(p.target)}">voir l'équipe</button></div>`;
  } else if (p.state === "chain_merge") {               // chain step validated: one click merges, the next step starts
    prop = `<div class="proposal"><span class="buttons-prop"><button class="btn main" data-chain-merge="${esc(p.task)}" data-rid="${m.id}">${p.next ? `Fusionner et lancer l'étape ${p.next}` : "Fusionner"}</button>
      <button class="link" data-open-task="${esc(p.task)}" data-target="${esc(p.project || "")}">voir la tâche</button></span><span class="warn msg"></span></div>`;
  } else if (p.state === "chain_stacked" || p.state === "chain_stacked") { // Étape validée : la suivante part de sa branche.
    prop = `<div class="proposal"><span class="buttons-prop"><button class="btn subtle" data-chain-merge="${esc(p.task)}" data-rid="${m.id}" data-without-next_steps="1">Fusionner maintenant</button>
      <button class="link" data-open-task="${esc(p.task)}" data-target="${esc(p.project || "")}">voir la tâche</button>
      ${p.launched_task ? `<button class="link" data-open-task="${esc(p.launched_task)}" data-target="${esc(p.project || "")}">voir l'étape lancée</button>` : ""}</span><span class="warn msg"></span></div>`;
  } else if (p.state === "chain_stage") {
    prop = `<div class="proposal"><button class="link" data-open-task="${esc(p.task)}" data-target="${esc(p.project || "")}">voir la tâche</button></div>`;
  } else if (p.state === "chain_application") {
    prop = `<div class="proposal"><span class="buttons-prop"><button class="btn main" data-chain-continue="${esc(p.chain)}" data-rid="${m.id}">Continuer</button>
      <button class="link" data-open-task="${esc(p.task)}" data-target="${esc(p.project || "")}">voir la tâche</button></span><span class="warn msg"></span></div>`;
  } else if (p.state === "chain_done") {
    prop = `<div class="subtle" style="margin-top:8px">✔ Fusionnée. <button class="link" data-open-task="${esc(p.task)}" data-target="${esc(p.project || "")}">voir la tâche</button></div>`;
  } else if (p.state === "ignoree") {
    prop = `<div class="subtle" style="margin-top:8px">Proposition ignorée.</div>`;
  }
  if ((p.install || []).length) {                        // extensions suggested by the Supervisor: one click each
    const TYPE_NAMES = { skill: "skill", mcp: "connecteur", software: "logiciel", pack: "pack" };
    prop += `<div class="proposal install-prop"><div class="title-prop"><b>À installer</b> <small class="subtle">vérifié avant installation, rien ne part sans ton clic</small></div>
      <ul class="list_items-team">${p.install.map((x) => `<li><b>${esc(x.name)}</b> <small class="subtle">${TYPE_NAMES[x.type] || esc(x.type)}</small>${x.why ? `<br><small>${esc(x.why)}</small>` : ""}
        <span class="buttons-prop">${x.installed ? '<span class="ok">installé</span>'
          : x.url ? `<button class="btn small" data-install-url="${esc(x.url)}">Voir et ajouter</button>`
          : x.key ? `<button class="btn small" data-install-card="${esc(x.id)}" title="Une clé ou un prérequis est nécessaire">Configurer</button>`
          : `<button class="btn main small" data-install-supervisor="${esc(x.id)}" data-rid="${m.id}">Installer</button>`}</span></li>`).join("")}</ul>
      <span class="warn msg"></span></div>`;
  }
  if (p.question && m.id === lastSupervisorId && !p.replied) {         // Supervisor question: one-click answer
    const q = p.question;
    const fileName = (o) => o.split(/[\\/]/).pop();
    prop += `<div class="quick-responses" data-q="${m.id}">${q.type === "text"
      ? `<input class="field" placeholder="Ta réponse…" maxlength="500"><button class="btn main small" data-text-folder="1">Répondre</button>`
      : q.options.map((o) => `<button class="btn${/^oui$/i.test(o) ?" main" : ""} small" data-rep="${esc(o)}" title="${esc(o)}">${esc(q.type === "file" ? "📄 " + fileName(o) : o)}</button>`).join("")
        + (q.type === "file" ? `<button class="btn subtle small" data-attachment-folder="1">Autre fichier…</button>` : "")}</div>`;
  }
  return `<div class="bubble sup ${m.state ==="error" ? "error" : ""}"><div class="who">Superviseur<span class="hour-msg">${msgTime(m.at, p.duration_s)}</span>${p.outcome ? ` · <button class="link" data-open-task="${esc(p.outcome)}" data-target="${esc(p.project || "")}">bilan de « ${esc(p.outcome_title || "la tâche")} »</button>` : ""}${p.duration_s != null ? `<span class="time">répondu en ${formatDuration(p.duration_s)}${p.supervisor_model ? " · " + esc(p.supervisor_model) : ""}</span>` : ""}</div>${m.state === "error" ? esc(m.text) : md(m.text)}${p.work_task ? `<p><button class="link" data-open-task="${esc(p.work_task)}" data-target="${esc(p.project || "")}">Voir le travail du Superviseur</button></p>` : ""}${prop}${p.night_report && p.night_report.length ? `<div class="report-night">${p.night_report.map((x) => `<button class="btn subtle small" data-open-task="${esc(x.tid)}" data-target="${esc(x.target)}">${esc(x.title.slice(0, 40))} · ${esc(x.state)}</button>`).join("")}</div>` : ""}</div>`;
}

/* Time of a message in the conversation (« 02:14 »; with the date when it is not today); a reply: asked + answer time */
function msgTime(iso, plusS) {
  try {
    const d = new Date(new Date(iso).getTime() + (+plusS || 0) * 1000);
    if (isNaN(d)) return "";
    const today = d.toDateString() === new Date().toDateString();
    return (today ? "" : d.toLocaleDateString("fr-FR", { day: "2-digit", month: "2-digit" }) + " ") + d.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" });
  } catch { return ""; }
}
/* Launched task, followed from the conversation: stage, working time, cost (when known) */
const TRACK_STAGES = ["Plan", "Agent", "Vérif", "Relecture", "Fin"];            // same five names everywhere: Plan · Agent · Vérif · Relecture · Fin
function liveTracking(s) {
  if (!s) return "";
  const active = ACTIVE_STATUSES.includes(s.status), waiting = TO_APPROVE.includes(s.status);
  const i = waiting ? 4 : Math.max(0, PHASES.findIndex(([, names]) => names.includes(s.stage_name)));
  const done = !active && !waiting;
  const time = active ? timer(s.stage_since || s.updated_at, s.duration_s) : s.duration_s ? formatDuration(s.duration_s) : "";
  const cost = s.cost_usd ? `${(+s.cost_usd).toFixed(2)} $` : "";
  const stages = done ? `<span class="state ${state_color(s.status)}">${esc(LABELS[s.status] || s.status)}</span>`
    : `<div class="phases phases-tracking" role="img" aria-label="Étape : ${TRACK_STAGES[i]}">${TRACK_STAGES.map((n, k) => `<span class="${k < i ?"faite" : k === i ? "active" : ""}">${n}</span>`).join("")}</div>`;
  return `<div class="tracking">${stages}<small class="subtle">${[time && `⏱ ${time}`, cost].filter(Boolean).join(" · ")}</small></div>`;
}
async function bindProposal(m) {
  const el = document.querySelector(`.proposal[data-id="${m.id}"]`);
  if (!el) return;
  const aiChoice = el.querySelector(".p-ai");
  await fillTaskAI(aiChoice, m.proposal.ai || "");
  const proposedAi = AI_ROLES[m.proposal.role] || defaultAi();   // the proposed agent's AI: its models and effort levels
  const modelsP = modelsFor(proposedAi), proposedEfforts = effortsFor(proposedAi.family);
  let model = m.proposal.ai ? (m.proposal.model || "") : modelsP.some(([v]) => v === m.proposal.model) ? m.proposal.model : "";
  if (model && !modelsP.some(([value]) => value === model)) modelsP.push([model, model]);
  listChoice(el.querySelector(".p-mod"), modelsP, model, (v) => (model = v));
  el.querySelector(".p-mod").disabled = modelsP.length < 2;
  const updateTaskModels = async () => {
    const c = aiState?.connections?.find((x) => x.id === (aiChoice.value || proposedAi.connection));
    const select = el.querySelector(".p-mod");
    if (c) await loadRoleModels(select, c.id);
    else { select.disabled = false; listChoice(select, aiChoice.value === "codex" || proposedAi.tool === "codex" ? SECONDARY_MODELS : modelsP, "", (v) => (model = v)); }
    const refreshEffort = async () => {
      model = select.value;
      const input = el.querySelector(".p-eff");
      await loadEffortChoices(input, aiChoice.value, model, m.proposal.role || "", m.proposal.target || projectChat || "");
      effort = input.value;
    };
    select.onchange = refreshEffort;
    await refreshEffort();
  };
  aiChoice.onchange = updateTaskModels;
  let mode = m.proposal.mode || "";
  listChoice(el.querySelector(".p-mode"), MODES, mode, (v) => (mode = v));
  let effort = proposedEfforts.some(([v]) => v === m.proposal.effort) ? m.proposal.effort : "";
  listChoice(el.querySelector(".p-eff"), proposedEfforts, effort, (v) => (effort = v));
  el.querySelector(".p-eff").disabled = proposedEfforts.length < 2;
  await updateTaskModels();
  const area = el.querySelector(".request-edit");
  const adjust = () => { area.style.height = "auto"; area.style.height = area.scrollHeight + 4 + "px"; };
  el.querySelector(".edit-request").onclick = (ev) => {
    area.hidden = !area.hidden; el.querySelector(".request-prop").hidden = !area.hidden;
    ev.currentTarget.textContent = area.hidden ? "Modifier la demande" : "Voir la demande";
    if (!area.hidden) { adjust(); area.focus(); }
  };
  area.oninput = adjust;
  el.querySelector(".launch").onclick = async (ev) => {
    if (ev.currentTarget.disabled || el.querySelector(".p-eff").dataset.loadingEffort || el.querySelector(".p-mod").disabled) return;
    const b = ev.currentTarget; b.disabled = true;
    try {
      const r = await api(`/api/conversation/${m.id}/launch`, { request: area.value, model: model, mode, effort, ai: aiChoice.value });
      threadSignature = ""; loadConversation(); updateBadge(); targets = await api("/api/targets");
      el.querySelector(".msg").textContent = `Lancé : ${r.tid}`;
    } catch (e) { el.querySelector(".msg").textContent = e.message; b.disabled = false; }
  };
  el.querySelector(".night-b").onclick = async (ev) => {
    if (el.querySelector(".p-eff").dataset.loadingEffort || el.querySelector(".p-mod").disabled) return;
    const b = ev.currentTarget; b.disabled = true;
    try {
      await api(`/api/conversation/${m.id}/night`, { request: area.value, model: model, mode, effort, ai: aiChoice.value });
      threadSignature = ""; loadConversation();
    } catch (e) { el.querySelector(".msg").textContent = e.message; b.disabled = false; }
  };
  el.querySelector(".ignore").onclick = async () => { await api(`/api/conversation/${m.id}/ignorer`, {}); threadSignature = ""; loadConversation(); };
}

document.addEventListener("click", async (ev) => {          // team proposals: apply / ignore / open the Équipe tab
  const a = ev.target.closest("[data-team-apply]"), i = ev.target.closest("[data-team-ignore]"), o = ev.target.closest("[data-open-team]");
  if (!a && !i && !o) return;
  ev.preventDefault();
  if (o) { $("#custom-card").hidden = true; currentProject = o.dataset.openTeam; currentBlock = "team"; showView("projects"); setTimeout(() => chooseBlock("team"), 300); return; }
  const b = a || i; b.disabled = true;
  try {
    if (a) {
      const r = await api(`/api/conversation/${a.dataset.teamApply}/team`, {}); infoBubble(r.message); if (currentBlock === "team") teamSettings();
      if (r.next_steps) await api("/api/conversation", { text: "Équipe appliquée. Propose maintenant le travail prévu (tâche ou chaîne).",   // work was asked too: go on
        project: projectChat || "", model: supModel(), effort: supervisorEffort });
    }
    else await api(`/api/conversation/${i.dataset.teamIgnore}/ignorer`, {});
    threadSignature = ""; loadConversation();
  } catch (e) { const msg = b.closest(".proposal")?.querySelector(".msg"); if (msg) msg.textContent = e.message; b.disabled = false; }
});
document.addEventListener("click", async (ev) => {          // chain announcements: merge / continue in one click
  const f = ev.target.closest("[data-chain-merge]"), c = ev.target.closest("[data-chain-continue]");
  if (!f && !c) return;
  ev.preventDefault();
  const b = f || c; b.disabled = true;
  try {
    if (f) await api(`/api/tasks/${f.dataset.chainMerge}/merge`, {});
    else await api(`/api/chains/${c.dataset.chainContinue}/continue`, {});
    await api(`/api/conversation/${b.dataset.rid}/done`, {});
    threadSignature = ""; loadConversation(); updateJobs();
  } catch (e) { const msg = b.closest(".proposal")?.querySelector(".msg"); if (msg) msg.textContent = e.message; b.disabled = false; }
});
document.addEventListener("click", async (ev) => {          // extensions suggested in the conversation
  const s = ev.target.closest("[data-install-supervisor]"), u = ev.target.closest("[data-install-url]"), f = ev.target.closest("[data-install-card]");
  if (!s && !u && !f) return;
  ev.preventDefault();
  if (u) { showView("custom"); setTimeout(() => { skillFromUrl(); $("#su-url").value = u.dataset.installUrl; $("#su-view").click(); }, 600); return; }
  if (f) { showView("custom"); await showCustom(true).catch(() => {}); elementSheet(f.dataset.installCard); return; }
  s.disabled = true; s.textContent = "Installation…";
  try { const r = await api(`/api/conversation/${s.dataset.rid}/install`, { id: s.dataset.installSupervisor }); infoBubble(r.message); }
  catch (e) { const msg = s.closest(".proposal")?.querySelector(".msg"); if (msg) msg.textContent = e.message; s.disabled = false; s.textContent = "Installer"; }
  threadSignature = ""; loadConversation();
});
let nightWindow = ["01:00", "07:00"];
api("/api/night").then((n) => (nightWindow = n.range_value)).catch(() => {});
document.addEventListener("click", async (ev) => {
  const n = ev.target.closest("[data-night-remove]");
  if (!n) return;
  try { await api("/api/night/remove", { id: n.dataset.nightRemove }); threadSignature = ""; loadConversation(); } catch (e) { alert(e.message); }
});
document.addEventListener("click", async (ev) => {
  const b = ev.target.closest("[data-open-task]");
  if (!b) return;
  ev.preventDefault();
  let target = b.dataset.target;
  if (!target || !target.includes(":")) {                    // link without a project (old message): use the task's
    try {
      const t = (await api(`/api/tasks/${b.dataset.openTask}`)).task.target;
      const c = (targets || []).find((k) => k.id === String(t).split(":").pop() && (!String(t).includes(":") || `${k.kind}:${k.id}` === t));
      target = c ? `${c.kind}:${c.id}` : target;
    } catch { /* the task will still open if the project is known */ }
  }
  selection = b.dataset.openTask; lastView = ""; currentBlock = "detail"; currentProject = target || currentProject; showView("projects");
  if (document.body.dataset.mob === "sup") mobileView("work");   // phone: leave the Supervisor for the task
  if (window.innerWidth <= 900) window.scrollTo({ top: 0 });
});

/* Attachments: drag and drop (files and folders), paste an image, ＋ button. Sent on « Envoyer ». */
let attached = [];                       // { fichier, rel, apercu }
const MAX_FILES = 200, MAX_TOTAL = 300 * 1024 * 1024;
function addAttachment(file, rel) {
  if (attached.length >= MAX_FILES) return;
  if (attached.reduce((s, j) => s + j.file.size, 0) + file.size > MAX_TOTAL) { alert("Trop lourd : 300 Mo au total par message."); return; }
  const preview = /^image\//.test(file.type) ? URL.createObjectURL(file) : "";
  attached.push({ file: file, rel: rel || file.name, preview: preview });
  renderAttachments();
}
function renderAttachments() {
  $("#attached").innerHTML = attached.map((j, i) => `<div class="attached">${j.preview ? `<img src="${j.preview}" alt="">` : "📄"}<span>${esc(j.rel)}</span><button class="x" data-i="${i}">✕</button></div>`).join("");
  $$("#attached .x").forEach((b) => (b.onclick = () => { attached.splice(+b.dataset.i, 1); renderAttachments(); }));
}
async function readEntry(entry, path) {
  if (entry.isFile) return new Promise((ok) => entry.file((f) => { addAttachment(f, path + f.name); ok(); }, ok));
  if (!entry.isDirectory) return;
  const reader = entry.createReader();
  let batch;
  do {
    batch = await new Promise((ok) => reader.readEntries(ok, () => ok([])));
    for (const e of batch) await readEntry(e, path + entry.name + "/");
  } while (batch.length);
}
let repoCounter = 0;
document.addEventListener("dragenter", (e) => { if (view !== "projects") return; e.preventDefault(); if (repoCounter++ === 0) { const d = document.createElement("div"); d.className = "repository"; d.id = "repository"; d.textContent = "Dépose tes fichiers ici"; document.body.appendChild(d); } });
document.addEventListener("dragleave", () => { if (--repoCounter <= 0) { repoCounter = 0; $("#repository")?.remove(); } });
document.addEventListener("dragover", (e) => { if (view === "projects") e.preventDefault(); });
document.addEventListener("drop", async (e) => {
  if (view !== "projects") return;
  e.preventDefault(); repoCounter = 0; $("#repository")?.remove();
  const items = [...(e.dataTransfer.items || [])];
  if (items.length && items[0].webkitGetAsEntry) { for (const it of items) { const en = it.webkitGetAsEntry(); if (en) await readEntry(en, ""); } }
  else [...e.dataTransfer.files].forEach((f) => addAttachment(f));
});
$("#message").addEventListener("paste", (e) => {
  let n = 0;
  for (const it of e.clipboardData.items) {
    if (it.kind === "file") { const f = it.getAsFile(); if (f) { n++; addAttachment(f, f.name && f.name !== "image.png" ? f.name : `image-collee-${Date.now()}-${n}.png`); } }
  }
  if (n) e.preventDefault();
});
/* Like a terminal: selecting with the mouse copies; right-click pastes (or copies if there is a selection).
   Shift + right-click keeps the usual menu. Pasting text asks the browser for permission once. */
function infoBubble(text) {
  let b = $("#bubble-info");
  if (!b) { b = document.createElement("div"); b.id = "bubble-info"; b.setAttribute("role", "status"); document.body.appendChild(b); }
  b.textContent = text; b.classList.add("visible");
  clearTimeout(infoBubble.t); infoBubble.t = setTimeout(() => b.classList.remove("visible"), 1200);
}
const textField = (el) => el && ((el.tagName === "TEXTAREA") || (el.tagName === "INPUT" && /^(text|search|url|email|)$/i.test(el.type || ""))) && !el.readOnly && !el.disabled;
function currentSelection() {
  const a = document.activeElement;
  if (textField(a) && a.selectionStart !== a.selectionEnd) return a.value.slice(a.selectionStart, a.selectionEnd);
  return String(window.getSelection() || "");
}
async function copyText(text) {
  try { await navigator.clipboard.writeText(text); return true; }
  catch { try { return document.execCommand("copy"); } catch { return false; } }
}
document.addEventListener("mouseup", async (e) => {
  if (e.button !== 0) return;
  const t = currentSelection();
  if (t.trim() && await copyText(t)) infoBubble("Copié");
});
function insertText(field, text) {
  field.focus();
  if (!document.execCommand("insertText", false, text)) field.setRangeText(text, field.selectionStart, field.selectionEnd, "end");
  field.dispatchEvent(new Event("input", { bubbles: true }));
}
document.addEventListener("contextmenu", async (e) => {
  if (e.shiftKey) return;                                       // Shift + right-click: usual menu
  e.preventDefault();
  const t = currentSelection();
  if (t.trim()) {                                               // a selection: right-click copies it
    if (await copyText(t)) infoBubble("Copié");
    const a = document.activeElement; if (textField(a)) a.setSelectionRange(a.selectionEnd, a.selectionEnd); else window.getSelection().removeAllRanges();
    return;
  }
  const field = textField(e.target) ? e.target : (view === "projects" && $("#message") && $("#message").offsetParent ? $("#message") : null);
  if (!field) { infoBubble("Rien où coller ici"); return; }
  try {                                                         // copied images → Supervisor attachments
    if (field.id === "message" && navigator.clipboard.read) {
      let n = 0;
      for (const it of await navigator.clipboard.read()) {
        const type = it.types.find((x) => x.startsWith("image/"));
        if (type) { const blob = await it.getType(type); n++; addAttachment(new File([blob], `image-collee-${Date.now()}-${n}.png`, { type }), `image-collee-${Date.now()}-${n}.png`); }
      }
      if (n) { infoBubble(n > 1 ? `${n} images jointes` : "Image jointe"); return; }
    }
  } catch { /* no image or read refused: try text instead */ }
  try {
    const text = await navigator.clipboard.readText();
    if (text) { insertText(field, text); infoBubble("Collé"); } else infoBubble("Presse-papiers vide");
  } catch { infoBubble("Autorise le presse-papiers (ou Ctrl+V)"); field.focus(); }
});
$("#attach").onclick = () => ($("#menu-attach").hidden = !$("#menu-attach").hidden);
$("#j-files").onclick = () => $("#files").click();
$("#j-folder").onclick = () => $("#folder").click();
$("#files").onchange = (e) => { [...e.target.files].forEach((f) => addAttachment(f)); e.target.value = ""; $("#menu-attach").hidden = true; };
$("#folder").onchange = (e) => { [...e.target.files].forEach((f) => addAttachment(f, f.webkitRelativePath || f.name)); e.target.value = ""; $("#menu-attach").hidden = true; };

let lastSupervisorId = 0;                                 // only the Supervisor's last question keeps its buttons
document.addEventListener("click", (e) => {
  const area = e.target.closest(".quick-responses"); if (!area) return;
  const b = e.target.closest("button"); if (!b) return;
  if (b.dataset.attachmentFolder) { $("#attach").click(); return; }
  const text = b.dataset.textFolder ? area.querySelector("input").value.trim() : b.dataset.rep;
  if (!text) return;
  area.querySelectorAll("button").forEach((x) => (x.disabled = true));
  $("#message").value = text; send();
});
document.addEventListener("keydown", (e) => {
  if (e.key === "Enter" && e.target.closest(".quick-responses input")) { e.preventDefault(); e.target.parentElement.querySelector("[data-text-folder]").click(); }
});
async function send() {
  const t = $("#message").value.trim();
  if (!t && !attached.length) return;
  if ($("#sup-effort").dataset.loadingEffort || $("#sup-model").disabled) { infoBubble("Attends le chargement du modèle et de son effort ou réessaie."); return; }
  try {
    const check = await api("/api/supervisor/preflight", {});
    const banner = ensureSupervisorStatus();
    if (!check.ok) {
      banner.innerHTML = `${esc(check.error)}${check.fallback ? ' <button class="btn small" data-restore-ai>Revenir à la dernière IA qui marchait</button>' : ""}`;
      banner.hidden = false;
      const restore = banner.querySelector("[data-restore-ai]");
      if (restore) restore.onclick = async () => { await api("/api/ai/choose", { supervisor: check.fallback, id: check.fallback, model: check.fallback_model || "" }); modelLists.delete(check.fallback); await supervisorChoices(); banner.hidden = true; };
      return;
    }
    banner.hidden = true;
  } catch (error) { infoBubble(error.message); return; }
  let batch = "";
  try {
    if (attached.length) {
      batch = "L" + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
      $("#send").textContent = "Envoi…";
      for (const j of attached) {
        const r = await fetch(`/api/attachments?lot=${batch}&rel=${encodeURIComponent(j.rel)}`, { method: "POST", headers: { "X-Studio": "1", "Content-Type": "application/octet-stream" }, body: j.file });
        if (!r.ok) throw new Error((await r.json().catch(() => ({}))).error || `envoi de ${j.rel} refusé`);
      }
    }
    await api("/api/conversation", { text: t, lot: batch, project: projectChat || "", model: supModel(), effort: supervisorEffort,
      wide: !!(projectChat && $("#wide-scope") && $("#wide-scope").checked) });
    $("#message").value = ""; adjustInputField(); attached = []; renderAttachments();
    threadSignature = ""; await loadConversation(true);
  } catch (e) { alert(e.message); }
  finally { $("#send").textContent = "Envoyer"; }
}
$("#send").onclick = send;
/* Dictation (mic left of Envoyer): browser speech recognition, text typed live into the input;
   otherwise a recording transcribed on the PC (faster-whisper). Nothing is sent before « Envoyer ». */
const Reco = window.SpeechRecognition || window.webkitSpeechRecognition;
let dictation = null, recorder = null;
function micState(state) {                                  // "" | "ecoute" | "attente"
  const b = $("#micro");
  b.classList.toggle("active", state === "listening"); b.classList.toggle("waiting", state === "waiting");
  b.setAttribute("aria-pressed", String(state === "listening"));
  b.title = state === "listening" ? "J'écoute… clique pour arrêter" : state === "waiting" ? "Transcription…" : "Dicter à la voix";
}
function writeDictation(base, text) { const t = $("#message"); t.value = base + text; adjustInputField(); t.scrollTop = t.scrollHeight; }
async function saveForPC(base) {
  if (!navigator.mediaDevices || !window.MediaRecorder) { infoBubble("Dictée indisponible sur cet appareil."); return; }
  let stream;
  try { stream = await navigator.mediaDevices.getUserMedia({ audio: true }); }
  catch { infoBubble("Autorise le micro pour dicter."); return; }
  const chunks = [], rec = new MediaRecorder(stream);
  rec.ondataavailable = (e) => e.data.size && chunks.push(e.data);
  rec.onstop = async () => {
    stream.getTracks().forEach((x) => x.stop()); recorder = null; micState("waiting");
    try {
      const blob = new Blob(chunks, { type: rec.mimeType || "audio/webm" });
      const r = await fetch("/api/dictate", { method: "POST", headers: { "X-Studio": "1", "Content-Type": blob.type }, body: blob });
      const j = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(j.error || "dictée impossible");
      if (j.text) writeDictation(base, j.text); else infoBubble("Rien entendu.");
    } catch (e) { infoBubble(e.message); }
    micState(""); $("#message").focus();
  };
  recorder = rec; rec.start(); micState("listening");
}
$("#micro").onclick = () => {
  if (dictation) { dictation.stop(); return; }
  if (recorder) { recorder.stop(); return; }
  if ($("#micro").classList.contains("waiting")) return;
  const v = $("#message").value, base = v && !/\s$/.test(v) ? v + " " : v;
  if (!Reco) return saveForPC(base);
  const r = new Reco(), android = /Android/i.test(navigator.userAgent);
  r.lang = navigator.language || "fr-FR"; r.interimResults = true; r.continuous = !android;   // Android: one sentence at a time (otherwise duplicates)
  let final = "", fallbackValue = false;
  r.onresult = (e) => {
    let temporary = "";
    for (let i = e.resultIndex; i < e.results.length; i++) { const x = e.results[i]; if (x.isFinal) final += x[0].transcript; else temporary += x[0].transcript; }
    writeDictation(base, (final + temporary).replace(/^\s+/, ""));
  };
  r.onerror = (e) => {
    if (e.error === "not-allowed" || e.error === "service-not-allowed") infoBubble("Autorise le micro pour dicter.");
    else if (e.error === "network" || e.error === "language-not-supported") fallbackValue = true;   // browser service unreachable: the PC transcribes
    else if (e.error !== "no-speech" && e.error !== "aborted") infoBubble("Dictée interrompue.");
  };
  r.onend = () => { dictation = null; micState(""); if (fallbackValue) saveForPC(base); else $("#message").focus(); };
  dictation = r;
  try { r.start(); micState("listening"); } catch { dictation = null; saveForPC(base); }
};

/* « @ »: mention a project file or function; its content is sent with the message */
let mentionEntries = [], mentionsIndex = 0, mentionsTimer = null, mentionsRequest = 0;
function mentionsBox() {
  let b = $("#mentions");
  if (!b) { b = document.createElement("ul"); b.id = "mentions"; b.className = "mentions"; b.hidden = true; b.setAttribute("role", "listbox"); $(".input_area").appendChild(b); }
  return b;
}
function closeMentions() { mentionEntries = []; mentionsBox().hidden = true; }
function currentToken() {
  const t = $("#message"), before = t.value.slice(0, t.selectionStart);
  const r = before.match(/^\/([a-z0-9-]*)$/i);                // « / » at the very start of a message: shortcuts
  if (r) return { q: r[1], begin: 0, shortcut: true };
  const m = before.match(/(?:^|\s)@("?)([^\s"@]*)$/);
  return m ? { q: m[2], begin: before.length - m[2].length - 1 - m[1].length } : null;
}
let shortcutsCache = null;
async function searchShortcuts(q) {
  if (!shortcutsCache) shortcutsCache = await api("/api/shortcuts");
  q = q.toLowerCase();
  return shortcutsCache.filter((r) => !q || r.name.includes(q) || r.title.toLowerCase().includes(q))
    .map((r) => ({ type: "shortcut", token: r.text, label: "/" + r.name, detail: r.title }));
}
function renderMentions() {
  const b = mentionsBox();
  if (!mentionEntries.length) { b.hidden = true; return; }
  b.innerHTML = mentionEntries.map((m, i) => `<li role="option" data-mention="${i}" class="${i === mentionsIndex ?"active" : ""}"><span class="type-m">${m.type === "function_name" ? "ƒ" : m.type === "shortcut" ? "⚡" : "📄"}</span><b>${esc(m.label)}</b><small>${esc(m.detail)}</small></li>`).join("")
    + (mentionEntries[0].type === "shortcut" ? "<li class=\"help-m discret\">↑ ↓ pour choisir · Entrée : la demande s'écrit, tu peux la modifier avant d'envoyer</li>"
      : "<li class=\"help-m discret\">↑ ↓ pour choisir · Entrée pour ajouter · le contenu part avec ton message</li>");
  b.hidden = false;
}
function chooseMention(i) {
  const m = mentionEntries[i], j = currentToken();
  if (!m || !j) return closeMentions();
  const t = $("#message"), finish = t.selectionStart;
  const addition = m.type === "shortcut" ? m.token : m.token + " ";
  t.value = t.value.slice(0, j.begin) + addition + t.value.slice(finish);
  const bracket = m.type === "shortcut" ? addition.indexOf("[") : -1;      // « [décris…] »: selected, ready to be replaced
  const pos = j.begin + addition.length;
  if (bracket >= 0) { t.setSelectionRange(j.begin + bracket, j.begin + addition.indexOf("]", bracket) + 1); t.focus(); closeMentions(); adjustInputField(); return; }
  t.setSelectionRange(pos, pos); t.focus(); closeMentions(); adjustInputField();
}
$("#message").addEventListener("input", () => {
  clearTimeout(mentionsTimer);
  const j = currentToken();
  if (!j) return closeMentions();
  mentionsTimer = setTimeout(async () => {
    const n = ++mentionsRequest;
    let l = [];
    try { l = j.shortcut ? await searchShortcuts(j.q) : await api(`/api/mentions?project=${encodeURIComponent(projectChat || "")}&q=${encodeURIComponent(j.q)}`); } catch { return; }
    if (n !== mentionsRequest || !currentToken()) return;
    mentionEntries = l; mentionsIndex = 0; renderMentions();
  }, 150);
});
document.addEventListener("mousedown", (e) => {
  const li = e.target.closest("[data-mention]");
  if (li) { e.preventDefault(); chooseMention(+li.dataset.mention); }
  else if (!e.target.closest("#mentions, #message")) closeMentions();
});
$("#message").addEventListener("keydown", (e) => {
  if (mentionEntries.length && !mentionsBox().hidden) {
    if (e.key === "ArrowDown" || e.key === "ArrowUp") { e.preventDefault(); mentionsIndex = (mentionsIndex + (e.key === "ArrowDown" ? 1 : -1) + mentionEntries.length) % mentionEntries.length; renderMentions(); return; }
    if (e.key === "Enter" || e.key === "Tab") { e.preventDefault(); chooseMention(mentionsIndex); return; }
    if (e.key === "Escape") { e.preventDefault(); closeMentions(); return; }
  }
  if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); }
});
function adjustInputField() { const t = $("#message"); t.style.height = "auto"; t.style.height = Math.min(t.scrollHeight, 200) + "px"; }
$("#message").addEventListener("input", adjustInputField);

/* ================================================================ PROJECTS */
async function loadProjects() {
  const ps = await api("/api/projects");
  projectList = ps;
  let key = null;
  try { key = storedValue("project-current"); } catch (e) { /* storage unavailable */ }
  if (key === "") return openSupervisor();                // last screen opened: the Supervisor
  const order = projectOrder(ps);
  if (!ps.some((x) => x.key === key)) key = order.length ? order[0].key : null;
  if (key) return openProject(key);
  currentProject = null; currentBlock = "ensemble";            // no project: prompt to add one
  renderTabs(); renderTabsBlock();
  placeSupervisor(null);
  allTasks = { t: [], ps: [] }; overviewLists();
}
/* Home, center: what is running or awaiting approval, project by project, then the latest finished tasks */
async function workSummary(ps) {
  let t = [];
  try { t = await api("/api/tasks"); } catch { return; }
  if (currentProject) return;
  ps = ps || await api("/api/projects");
  allTasks = { t, ps };
  overviewLists();
}
let allTasks = { t: [], ps: [] }, overviewSearch = "", statusE = "";
function overviewLists() {
  const { t, ps } = allTasks;
  const keyOf = (x) => { const c = (targets || []).find((k) => k.id === String(x.target).split(":").pop() && (!String(x.target).includes(":") || `${k.kind}:${k.id}` === x.target)); return c ? `${c.kind}:${c.id}` : x.target; };
  const nameOf = (x) => (ps.find((p) => p.key === keyOf(x)) || {}).name || targetName(x.target);
  const item = (x) => `<li data-open-task="${esc(x.id)}" data-target="${esc(keyOf(x))}">
    <div class="line1"><span class="state ${state_color(x.status)}">${esc(taskLabel(x))}</span><small class="time">${taskTime(x)}</small></div>
    <small title="${esc(withoutChain(x.request || ""))}"><b>${esc(nameOf(x))}</b> · ${x.chain ? "⛓ " : ""}${esc(taskName(x))}</small>${phaseBar(x)}${previews(x)}${quickActions(x)}</li>`;
  const validate = t.filter((x) => TO_APPROVE.includes(x.status)), running = t.filter((x) => IN_PROGRESS.includes(x.status));
  const allEntries = t.filter((x) => !TO_APPROVE.includes(x.status) && !IN_PROGRESS.includes(x.status));
  const stripAccents = (x) => (x || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  const q = stripAccents(overviewSearch.trim());
  const filtered = allEntries.filter((x) => (!statusE || (statusE === "ok" ? ["approved", "applied"].includes(x.status) : x.status === statusE))
    && (!q || stripAccents(`${nameOf(x)} ${taskName(x)} ${x.request} ${x.summary}`).includes(q)));
  $("#e-validate").innerHTML = validate.map(item).join("") || "<li class=\"empty\" style=\"cursor:default\">Rien à valider.</li>";
  $("#e-running").innerHTML = running.map(item).join("") || `<li class="empty" style="cursor:default">${ps.length ? "Rien en cours." : "Aucun projet pour l'instant : ajoute-en un avec ＋."}</li>`;
  $("#e-finished").innerHTML = filtered.slice(0, 50).map(item).join("") || (allEntries.length ? "<li class=\"empty\" style=\"cursor:default\">Aucune tâche ne correspond.</li>" : "");
  $("#e-t-finished").textContent = `Terminées (${allEntries.length})`;
  $("#e-count").textContent = (q || statusE) && allEntries.length ? `${filtered.length} sur ${allEntries.length}` : "";
  if (!$("#e-status").childElementCount) chipList($("#e-status"), FINISHED_STATUSES, statusE, (v) => { statusE = v; overviewLists(); });
}
$("#e-search").oninput = () => { overviewSearch = $("#e-search").value; overviewLists(); };

/* Home, left: agent presets, shortcuts to internal settings, studio status */
function readableReset(t) {
  if (!t) return "";
  const s = t - Date.now() / 1000;
  if (s <= 0) return "remis à zéro";
  if (s < 3600) return `remise à zéro dans ${Math.max(1, Math.round(s / 60))} min`;
  if (s < 86400) return `remise à zéro dans ${Math.floor(s / 3600)} h ${String(Math.round((s % 3600) / 60)).padStart(2, "0")}`;
  return "remise à zéro " + new Date(t * 1000).toLocaleString("fr-FR", { weekday: "short", hour: "2-digit", minute: "2-digit" });
}
async function homeLimits() {
  const el = $("#limits");
  if (!el) return;
  const l = await api("/api/limits").catch(() => null);
  if (!l) { el.innerHTML = '<p class="lim-info">Limites indisponibles.</p>'; return; }
  el.innerHTML = ["Claude", "Codex"].map((name) => {
    const x = l[name] || {};
    if (!x.ok && x.reconnection === "running") { setTimeout(homeLimits, 8000); return `<div class="lim-tool"><div class="lim-header">${name}</div><p class="lim-info">Reconnexion de Claude Code…</p></div>`; }
    if (!x.ok && x.reconnection === "button") return `<div class="lim-tool"><div class="lim-header">${name}</div><p class="lim-info">${esc(x.info || "Connexion expirée.")} <button class="btn small" data-primary-recommendation="1">Reconnecter</button></p></div>`;
    if (!x.ok) return `<div class="lim-tool"><div class="lim-header">${name}</div><p class="lim-info">${esc(x.info || "Indisponible.")}</p></div>`;
    const seen = x.seen && Date.now() / 1000 - x.seen > 600 ? `relevé ${new Date(x.seen * 1000).toLocaleString("fr-FR", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" })}` : "à l'instant";
    return `<div class="lim-tool" title="${esc(x.info || "")}"><div class="lim-header">${name}<small>${esc(seen)}</small></div>` + x.windows.map((f) => {
      const c = f.pct >= 85 ? "top" : f.pct >= 60 ? "moyen" : "";
      return `<div class="lim-row"><span>${esc(f.name)}</span><span class="lim-bar"><i class="${c}" style="width:${Math.max(f.pct, 1.5)}%"></i></span><b>${Math.round(f.pct)} %</b>`
        + (f.reset ? `<span class="lim-reset">${esc(readableReset(f.reset))}</span>` : "") + "</div>";
    }).join("") + "</div>";
  }).join("");
}
document.addEventListener("click", async (ev) => {      // Usage: reconnect the subscription tool (only if it asks)
  const b = ev.target.closest("[data-primary-recommendation]");
  if (!b) return;
  b.disabled = true; b.textContent = "Reconnexion…";
  try {
    const r = await api(b.dataset.primaryRecommendation === "login" ? "/api/claude/connection" : "/api/claude/reconnecter", {});
    if (r.ok) { infoBubble(r.info); homeLimits(); updateAlerts && updateAlerts(); return; }
    b.closest(".lim-info").innerHTML = `${esc(r.info)} <button class="btn small" data-primary-recommendation="login">Se connecter</button>`;
  } catch (e) { b.closest(".lim-info").textContent = e.message; }
});
async function removeProject(key, name) {
  if (!confirm(`Retirer « ${name} » du studio ?\n\nRien n'est supprimé : sa fiche est rangée dans Archives\\${key.startsWith("project:") ? "projets" : "sujets"}-retires, ses fichiers, ses tâches passées et sa mémoire restent intacts.`)) return;
  try { const r = await api(`/api/targets/${encodeURIComponent(key)}/remove`, {}); targets = await api("/api/targets"); selection = null; loadProjects(); alert(r.message); }
  catch (e) { alert(e.message); }
}
function newProject() {
  const d = $("#dlg-new");
  newForm($("#dlg-body"));
  if (!d.open) d.showModal();
  $("#nv-name").focus();
}
$("#dlg-new").addEventListener("click", (e) => { if (e.target === e.currentTarget) e.currentTarget.close(); });   // click outside the window
$("#dlg-new").addEventListener("close", () => { onProjectAdded = null; });          // closed without adding: the guide stays where it is
function newForm(nv) {
  nv.innerHTML = `<p class="title" style="margin:0 0 10px">Ajouter un projet ou un sujet</p><div class="chips" id="nv-kind"></div>
    <p class="sub-title-g" style="margin:10px 0 6px">Partir de</p><div class="chips small" id="nv-model"></div><small class="subtle" id="nv-model-help"></small>
    <input class="field" id="nv-name" placeholder="Nom (ex. Mon site web)"><input class="field" id="nv-path_value" placeholder="Dossier du projet (C:\\…)" hidden>
    <div class="actions" style="margin:0"><button class="btn main" id="nv-ok">Ajouter</button><button class="btn subtle" id="nv-cancel">Annuler</button></div><small id="nv-msg" class="warn"></small>`;
  let kind = "project";
  chipList($("#nv-kind"), [["project", "Projet (avec dossier)"], ["topic", "Sujet (sans dossier)"]], kind, (v) => { kind = v; $("#nv-path_value").hidden = v !== "project"; });
  $("#nv-path_value").hidden = false;
  let model = "";
  const helpTexts = { "": "Aucune équipe imposée : tous les agents restent disponibles.", site: "Développeur web, designer, SEO, accessibilité, tests…",
    game: "Game designer, programmeur, level designer, direction artistique, son, scénario, tests… (mode Performance)",
    app: "Programmeur, interface, tests, sécurité, documentation…", document: "Recherche, rédaction, traduction…",
    visuals: "Direction artistique, illustration, art technique…" };
  chipList($("#nv-model"), [["", "Vide"], ["site", "Site web"], ["game", "Jeu vidéo"], ["app", "Application"], ["document", "Document"], ["visuals", "Images"]], model,
    (v) => { model = v; $("#nv-model-help").textContent = helpTexts[v]; });
  $("#nv-model-help").textContent = helpTexts[""];
  $("#nv-name").focus();
  $("#nv-cancel").onclick = (ev) => { ev.stopPropagation(); $("#dlg-new").close(); };
  $("#nv-ok").onclick = async (ev) => {
    ev.stopPropagation();
    const name = $("#nv-name").value.trim();
    const id = name.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
    if (!id) { $("#nv-msg").textContent = "Donne un nom."; return; }
    if (kind === "project" && !$("#nv-path_value").value.trim()) { $("#nv-msg").textContent = "Indique le dossier du projet."; return; }
    try { await api("/api/targets", { kind, id, name: name, path_value: kind === "project" ? $("#nv-path_value").value.trim() : "", model: model }); targets = await api("/api/targets"); projectList = await api("/api/projects"); const added = onProjectAdded; onProjectAdded = null;
      $("#dlg-new").close(); selection = null; openProject(`${kind}:${id}`); if (added) added(`${kind}:${id}`, name); }
    catch (e) { $("#nv-msg").textContent = e.message; }
  };
}

let projectTasks = [];
async function openProject(key) {
  const change = currentProject !== key;
  currentProject = key;
  try { localStorage.setItem("project-current", key); } catch (e) { /* optional */ }
  if (selection && (change || !PROJECT_BLOCKS.includes(currentBlock))) currentBlock = "detail";
  else if (change || !PROJECT_BLOCKS.includes(currentBlock)) currentBlock = "tasks";
  renderTabs(); renderTabsBlock();
  if (projectChat !== key) placeSupervisor(key);
  const p = await api(`/api/projects/${encodeURIComponent(key)}`);
  if (currentProject !== key) return;
  $("#p-remove").onclick = () => removeProject(key, p.name);
  $("#p-name").textContent = p.name;
  $("#p-info").textContent = `${p.kind === "project" ? "projet" : "sujet"}${p.folder ? " · " + p.folder : " · sans dossier"} · mémoire ${p.memory.replace(/^studio:/, "")}`;
  $("#p-context").innerHTML = p.context ? md(p.context) : "<p class=\"empty\">Pas encore de contexte.</p>";
  renderProjectProfile(key, p.profile || "", p.welcome_profile || "normal");
  $("#p-edit-ctx").hidden = !p.context_path_value;
  $("#p-edit-ctx").onclick = () => openPath(p.context_path_value);
  $("#project-legacy-mode").hidden = p.kind === "project";
  if (projectPageKey !== key) {
    projectPageKey = key;
    projectSettingsKey = ""; projectKnowledgeKey = "";
    $("#project-settings").innerHTML = "";
    $("#project-preview").hidden = true;
    $("#project-memory-query").value = "";
  }
  if (currentBlock === "project" && p.kind === "project") loadProjectSettings();
  if (currentBlock === "knowledge") loadProjectKnowledge();
  buildInfo(p);
  taskLists(p.tasks);
  projectTeam(p.team);
  projectHeader(p);
  renderTabsBlock();
  if (selection) show();
}
/* Project header: the name and the agents' mode, switchable right here (applies to the next tasks) */
function projectHeader(p) {
  const el = $("#p-header");
  if (!el) return;
  const current = p.profile || p.welcome_profile || "normal";
  el.innerHTML = `<b class="name-header">${esc(p.name)}</b><label class="mode-header" title="Mode des agents pour ce projet : pris en compte dès la prochaine tâche">Mode
    <select id="p-header-mode">${PROFILES.map(([v, t]) => `<option value="${v}"${v === current ? " selected" : ""}>${t}</option>`).join("")}</select></label>`;
  el.hidden = false;
  $("#p-header-mode").onchange = async (e) => {
    try {
      const r = await api("/api/profile", { target: p.key, profile: e.target.value });
      p.profile = r.profile; renderProjectProfile(p.key, r.profile, p.welcome_profile || "normal");
      const modeField = document.querySelector('[data-project-setting="agent_mode"]');
      if (modeField) modeField.value = r.profile || "";
      infoBubble(`Mode ${e.target.selectedOptions[0].textContent}`);
    } catch (er) { infoBubble(er.message); e.target.value = current; }
  };
}


// Les aperçus réutilisent le rendu Markdown échappé du studio.
let projectPageKey = "", projectSettingsKey = "", projectKnowledgeKey = "", projectMemoryRequest = 0;
function projectEndpoint(key, action) {
  const [kind, id] = key.split(":");
  if (kind !== "project" || !id) throw new Error("Réglages disponibles pour les projets avec une fiche.");
  return `/api/projects/${encodeURIComponent(id)}/${action}`;
}
const PROJECT_SETTING_GROUPS = [
  ["Agents", [
    ["agent_mode", "Mode des agents", "choice", "Rapide, Normal ou Performance : s’applique aux prochaines tâches.", [["", "Hériter"], ["fast", "Rapide"], ["normal", "Normal"], ["performance", "Performance"]]],
    ["default_effort", "Effort par défaut", "choice", "Utilisé si la tâche, le mode ponctuel et les réglages du rôle ne choisissent pas déjà un effort.", EFFORTS],
    ["task_timeout_seconds", "Durée maximale d’une tâche (secondes)", "number", "De 30 à 86400 secondes par exécution, sans compter l’attente de validation."]]],
  ["Git et application", [
    ["application", "Application des changements", "choice", "Manuelle, ou automatique après approbation et vérifications.", [["manual", "Manuelle"], ["auto_after_approval", "Automatique après approbation"]]],
    ["isolation", "Isolation", "choice", "Copie séparée, ou worktree Git. Le worktree nécessite aussi l’autorisation enregistrée dans la fiche.", [["copy", "Copie"], ["worktree", "Worktree"]]],
    ["worktree_folders", "Dossiers du worktree", "list", "Un chemin relatif par ligne. Liste vide : tout le dépôt."],
    ["exclude", "Dossiers ou fichiers exclus", "list", "Un chemin relatif par ligne, jamais de chemin extérieur au projet."]]],
  ["Vérifications et compilation", [
    ["checks", "Commandes de vérification", "list", "Une commande par ligne, lancée dans la copie de travail de chaque tâche. Le studio te les montre avant de les enregistrer."],
    ["build", "Commande de compilation", "list", "Un argument par ligne, le programme en premier. {uproject} désigne le fichier du projet ; {dossier} désigne le dossier visé. Lancée dans la copie de la tâche (mode Max) ou dans ton dossier de projet (bouton « Compiler »)."],
    ["uproject", "Fichier du projet Unreal", "text", "Chemin relatif d’un fichier .uproject ; laisser vide pour les autres projets."]]],
  ["Règles et documents", [
    ["rules", "Règles et dossiers de skills", "list", "Un chemin relatif par ligne : fichiers de règles et dossiers de skills à consulter."],
    ["documents", "Dossiers de documents", "list", "Un chemin relatif par ligne. Leurs fichiers Markdown apparaissent dans Skills et mémoire."]]],
  ["Identité", [
    ["name", "Nom affiché", "text", "Nom du projet dans le studio, de 1 à 120 caractères."],
    ["repository", "Dépôt", "text", "Adresse du dépôt, sans identifiant ni secret. Le studio ne pousse rien en enregistrant."]]]
];
/* Security settings and the sheet's commands: shown with their execution folder before saving or running. */
function commandsList(c) {
  const rows = [...(c.checks || []).map((x) => `vérification : ${x}`), ...((c.build || []).length ? [`compilation : ${(c.build || []).join(" ")}`] : [])];
  return rows.length ? rows : ["(aucune commande)"];
}
function commandsConfirmation(p) {
  const changes = Object.entries(p.changes || {}).map(([k, v]) => `• ${k} : ${JSON.stringify(v.before ?? "")} → ${JSON.stringify(v.after ?? "")}`);
  const c = p.commands || {};
  return ["Réglages de sécurité modifiés :", ...changes, "", "Commandes que le studio lancera :", ...commandsList(c).map((x) => "• " + x),
    "", `Vérifications : dans ${c.folders ? c.folders.checks : "la copie de la tâche"}.`, `Compilation : dans ${c.folders ? c.folders.build : "la copie de la tâche"}.`,
    "", "Ces commandes s'exécutent avec tes droits Windows. Enregistrer ?"].join("\n");
}
function commandsBanner(s) {
  if (!s.commands || s.commands_approved) return "";
  return `<div class="alert"><b>Commandes de la fiche modifiées hors de cette page</b> : elles ne seront pas lancées tant que tu ne les valides pas.
    <ul>${commandsList(s.commands).map((x) => `<li><code>${esc(x)}</code></li>`).join("")}</ul>
    <small>Vérifications : dans ${esc(s.commands.folders.checks)}. Compilation : dans ${esc(s.commands.folders.build)}.</small>
    <div class="actions"><button type="button" class="btn" id="approve-commands"${s.read_only ? " disabled" : ""}>Valider ces commandes</button></div></div>`;
}
function projectSettingField(field, settings) {
  const [key, label, type, help, choices] = field, value = settings.values[key];
  const disabled = settings.read_only || settings.masked_fields.includes(key);
  const attributes = `data-project-setting="${key}" data-value-type="${type}"${disabled ? " disabled" : ""}`;
  const control = type === "choice" ? `<select ${attributes}>${choices.map(([v, name]) => `<option value="${esc(v)}"${v === value ? " selected" : ""}>${esc(name)}</option>`).join("")}</select>`
    : type === "list" ? `<textarea class="area-text" ${attributes}>${esc(Array.isArray(value) ? value.join("\n") : "")}</textarea>`
    : `<input class="field" type="${type === "number" ? "number" : "text"}" ${type === "number" ? 'min="30" max="86400" step="1"' : ""} ${attributes} value="${esc(value)}">`;
  return `<label class="project-setting"><span>${esc(label)}</span>${control}<small class="subtle">${esc(help)}${settings.masked_fields.includes(key) ? " Valeur masquée : modification désactivée pour préserver le secret existant." : ""}</small></label>`;
}
async function loadProjectSettings(force = false) {
  const key = currentProject;
  if (!key?.startsWith("project:") || (!force && projectSettingsKey === key)) return;
  projectSettingsKey = key;
  $("#project-settings").innerHTML = "<p class=\"empty\">Chargement des réglages…</p>";
  try {
    const settings = await api(projectEndpoint(key, "settings"));
    if (currentProject !== key) return;
    $("#project-settings").innerHTML = `<form id="project-settings-form">${PROJECT_SETTING_GROUPS.map(([name, fields]) => `<fieldset class="project-settings-group"><legend>${esc(name)}</legend>${fields.map((f) => projectSettingField(f, settings)).join("")}
      ${name === "Agents" ? `<p class="subtle">Mode autonome : ${settings.autonomous ? "oui" : "non"}. Validation et fusion automatiques se règlent pour tout le studio dans Gestion › Réglages › Exécution des tâches.</p>` : ""}
      ${name === "Git et application" ? `<p>Branche de départ (branche actuelle) : <b>${esc(settings.base_branch || "Indisponible ou sans Git")}</b></p>` : ""}
      ${name === "Vérifications et compilation" ? `<p class="subtle">Accès Unreal MCP : ${settings.mcp_access === "read" ? "lecture seule" : "tout"}. Réglage global dans studio.config.toml, section outils, clé mcp_unreal.</p>` : ""}
      ${name === "Identité" ? `<p>Identifiant : <b>${esc(settings.id)}</b> (lecture seule)</p><p>Chemin : <code>${esc(settings.path)}</code> (lecture seule)</p>` : ""}</fieldset>`).join("")}
      ${commandsBanner(settings)}
      <div class="actions"><button class="btn main"${settings.read_only ? " disabled" : ""}>Enregistrer les réglages</button><button type="button" class="btn" id="project-settings-reload">Annuler les modifications</button></div>
      <p id="project-settings-message" role="status">${settings.read_only ? "Lecture seule depuis l’accès distant. Enregistrement depuis le PC." : "Une sauvegarde de l’ancienne fiche précède chaque enregistrement."}</p></form>`;
    $("#project-settings-reload").onclick = () => loadProjectSettings(true);
    if ($("#approve-commands")) $("#approve-commands").onclick = async () => {
      try { const r = await api(projectEndpoint(key, "approve-commands"), { fingerprint: settings.commands.fingerprint }); await loadProjectSettings(true); $("#project-settings-message").textContent = r.message; }
      catch (error) { $("#project-settings-message").textContent = error.message; }
    };
    $("#project-settings-form").onsubmit = async (event) => {
      event.preventDefault();
      const form = event.currentTarget, button = form.querySelector("button[type=\"submit\"], button.main");
      const values = {};
      form.querySelectorAll("[data-project-setting]:not(:disabled)").forEach((el) => {
        values[el.dataset.projectSetting] = el.dataset.valueType === "list" ? el.value.split(/\r?\n/).map((v) => v.trim()).filter(Boolean)
          : el.dataset.valueType === "number" ? Number(el.value) : el.value;
      });
      button.disabled = true;
      try {
        let result;
        try { result = await api(projectEndpoint(key, "settings"), { values }); }
        catch (error) {
          if (!(error.data && error.data.confirm) || !confirm(commandsConfirmation(error.data.confirm))) throw error;
          result = await api(projectEndpoint(key, "settings"), { values, confirmed: true });   // seen and confirmed
        }
        if (currentProject !== key) return;
        await loadProjectSettings(true);
        $("#project-settings-message").textContent = result.message;
        projectKnowledgeKey = "";
        renderProjectProfile(key, values.agent_mode || "", "normal");
      } catch (error) {
        if (currentProject === key) $("#project-settings-message").textContent = error.message;
      } finally { if (button.isConnected) button.disabled = settings.read_only; }
    };
  } catch (error) {
    if (currentProject === key) $("#project-settings").innerHTML = `<div class="alert">${esc(error.message)}</div><button class="btn" id="project-settings-retry">Réessayer</button>`;
    if ($("#project-settings-retry")) $("#project-settings-retry").onclick = () => loadProjectSettings(true);
  }
}
function projectResourceActions(path, kind) {
  return `<div class="actions"><button class="btn small" data-project-read="${esc(path)}" data-resource-kind="${kind}">Voir</button><button class="btn small" data-project-folder="${esc(path)}" data-resource-kind="${kind}">Ouvrir le dossier</button></div>`;
}
function projectSkillList(result) {
  return (result.limited ? "<p class=\"alert\">Liste limitée : précise les dossiers de règles dans Réglages.</p>" : "") + (result.items.map((item) => `<article class="project-resource"><b>${esc(item.name)}</b><p>${esc(item.description)}</p>
    ${item.different ? '<p class="warn">Les copies diffèrent.</p>' : ""}${item.unverified ? '<p class="warn">Comparaison incomplète : un fichier est trop gros.</p>' : ""}
    ${item.missing.length ? `<p class="warn">Copie manquante dans : ${item.missing.map(esc).join(", ")}</p>` : ""}
    ${item.copies.map((copy) => `<div><code>${esc(copy.folder)}</code>${copy.error ? `<p class="warn">${esc(copy.error)}</p>` : ""}${projectResourceActions(copy.path, "skill")}</div>`).join("")}</article>`).join("") || "<p class=\"empty\">Aucune skill dans les dossiers déclarés par la fiche.</p>");
}
function projectDocumentTree(items) {
  const root = { folders: new Map(), files: [], date: "" };
  for (const item of items) {
    let node = root;
    for (const part of item.path.split("/").slice(0, -1)) {
      if (!node.folders.has(part)) node.folders.set(part, { folders: new Map(), files: [], date: "" });
      node = node.folders.get(part);
      if (item.modified_at > node.date) node.date = item.modified_at;
    }
    node.files.push(item);
  }
  const render = (node) => [...node.folders.entries()].sort((a, b) => b[1].date.localeCompare(a[1].date)).map(([name, child]) => `<details class="project-folder"><summary>${esc(name)}</summary>${render(child)}</details>`).join("")
    + node.files.sort((a, b) => b.modified_at.localeCompare(a.modified_at)).map((file) => `<article class="project-resource"><b>${esc(file.path.split("/").pop())}</b> <small>${esc(file.modified_at.slice(0, 10))} · ${file.size} octets</small>${projectResourceActions(file.path, "document")}</article>`).join("");
  return render(root) || "<p class=\"empty\">Aucun document Markdown déclaré.</p>";
}
async function loadProjectKnowledge() {
  const key = currentProject;
  if (!key?.startsWith("project:") || projectKnowledgeKey === key) return;
  projectKnowledgeKey = key;
  for (const id of ["skills", "documents"]) $("#project-" + id).textContent = "Chargement…";
  $("#project-memory-search").onsubmit = (event) => { event.preventDefault(); loadProjectMemory(key); };
  loadProjectMemory(key);
  await Promise.all(["skills", "documents"].map(async (action) => {
    try {
      const result = await api(projectEndpoint(key, action));
      if (currentProject !== key) return;
      $("#project-" + action).innerHTML = action === "skills" ? projectSkillList(result)
        : (result.limited ? "<p class=\"alert\">Liste limitée : précise les dossiers de documents dans Réglages.</p>" : "") + projectDocumentTree(result.items);
    } catch (error) {
      if (currentProject === key) $("#project-" + action).innerHTML = `<div class="alert">${esc(error.message)}</div>`;
    }
  }));
}
async function loadProjectMemory(key) {
  const request = ++projectMemoryRequest;
  $("#project-memory").textContent = "Recherche…";
  try {
    const result = await api(projectEndpoint(key, "memory") + "?" + new URLSearchParams({ q: $("#project-memory-query").value }));
    if (currentProject !== key || request !== projectMemoryRequest) return;
    $("#project-memory").innerHTML = (result.pending ? `<p class="alert">${result.pending} écriture(s) du studio pas encore partagée(s).</p>` : "")
      + (result.items.length >= result.limit ? '<p class="subtle">500 souvenirs affichés au maximum. Affine la recherche.</p>' : "")
      + (result.items.map((item) => `<article class="project-resource">${md(item.content)}<small>${esc(item.created_at)} · ${esc(item.provenance?.tool || "?")} · ${esc(item.provenance?.source || item.provenance?.agent || "")}</small></article>`).join("") || "<p class=\"empty\">Aucun souvenir pour cette recherche.</p>");
  } catch (error) {
    if (currentProject === key && request === projectMemoryRequest) $("#project-memory").innerHTML = `<div class="alert">${esc(error.message)}</div>`;
  }
}
document.addEventListener("click", async (event) => {
  const read = event.target.closest("[data-project-read]"), folder = event.target.closest("[data-project-folder]");
  if (!read && !folder) return;
  const button = read || folder, key = currentProject, kind = button.dataset.resourceKind;
  button.disabled = true;
  try {
    if (folder) {
      await api(projectEndpoint(key, "open-folder"), { path: button.dataset.projectFolder, kind });
    } else {
      const path = button.dataset.projectRead;
      const result = await api(projectEndpoint(key, kind === "skill" ? "skills" : "documents") + "?" + new URLSearchParams({ path }));
      if (currentProject !== key) return;
      $("#project-preview-title").textContent = result.path + " · lecture seule";
      $("#project-preview-text").innerHTML = md(result.text);
      $("#project-preview").hidden = false; $("#project-preview").open = true;
      $("#project-preview").scrollIntoView({ block: "nearest" });
    }
  } catch (error) { infoBubble(error.message); }
  finally { button.disabled = false; }
});

const CHAIN_STATE = { running: "en cours", awaiting_merge: "attend ta fusion", awaiting_application: "attend que tu appliques le résultat", paused: "en pause", completed: "terminée", stopped: "arrêtée" };
function chainBlock(c) {
  if (!c) return "";
  return `<div class="chain-block"><b>⛓ Chaîne « ${esc(c.title)} »</b> · <span class="${c.status ==="paused" ? "warn" : c.status === "completed" ? "ok" : ""}">${CHAIN_STATE[c.status] || esc(c.status)}</span>
    ${c.note ? `<div class="subtle">${esc(c.note)}</div>` : ""}
    <ol>${c.stages.map((e, i) => `<li class="${i === c.current ?"current" : ""}">${esc(e.role_name)} — ${esc(e.request.slice(0, 120))}${e.state ? ` <span class="state ${state_color(e.state)}">${LABELS[e.state] || esc(e.state)}</span>` : ""}${e.task && e.task !== selection ? ` <button class="link" data-open-task="${esc(e.task)}" data-target="${esc(currentProject || "")}">voir</button>` : ""}</li>`).join("")}</ol>
    ${["running", "awaiting_merge", "awaiting_application", "paused"].includes(c.status) ? `<div class="actions">${c.status === "paused" ? `<button class="btn" data-chain-resume="${esc(c.id)}">Relancer l'étape ${c.current + 1}</button>` : ""}${c.can_continue ? `<button class="btn main" data-chain-continue="${esc(c.id)}">Continuer : lancer l'étape ${c.current + 2 > c.stages.length ? "finale" : c.current + 2}</button>` : ""}<button class="btn subtle danger" data-chain-stop="${esc(c.id)}">Arrêter la chaîne</button></div>` : ""}</div>`;
}
document.addEventListener("click", async (ev) => {
  const r = ev.target.closest("[data-chain-resume]"), a = ev.target.closest("[data-chain-stop]"), c = ev.target.closest("[data-chain-continue]");
  if (!r && !a && !c) return;
  const button = r || a || c;
  if (button.disabled) return;
  button.disabled = true;
  try {
    if (c) { if (!confirm("Le travail de cette étape est-il en place (fusionné, appliqué, ou rien à reporter) ? L'étape suivante va partir.")) { button.disabled = false; return; } const x = await api(`/api/chains/${c.dataset.chainContinue}/continue`, {}); if (x.tid) selection = x.tid; }
    else if (a) { if (!confirm("Arrêter cette chaîne ? Les étapes déjà faites restent ; les suivantes ne partiront pas.")) return; await api(`/api/chains/${a.dataset.chainStop}/stop`, {}); }
    else { const x = await api(`/api/chains/${r.dataset.chainResume}/resume`, {}); selection = x.tid; }
    lastView = ""; setTimeout(() => openProject(currentProject), 300);
  } catch (e) { alert(e.message); button.disabled = false; }
});

/* « Retirer » a file from the changes before approving: it goes back to its original state */
document.addEventListener("click", async (ev) => {
  const b = ev.target.closest("[data-remove]");
  if (!b) return;
  ev.preventDefault(); ev.stopPropagation();
  const name = b.dataset.remove;
  if (!confirm(`Retirer « ${name.split("/").pop()} » ?\nCe changement ne sera pas appliqué. La version de l'agent reste gardée dans le dossier de la tâche.`)) return;
  b.disabled = true; b.textContent = "Retrait…";
  try {
    await api(`/api/tasks/${selection}/decision`, { decision: "remove", files: [name] });
    setTimeout(() => { lastView = ""; openProject(currentProject); }, 700);
  } catch (e) { alert(e.message); b.disabled = false; b.textContent = "Retirer"; }
}, true);

/* Readable diff: file by file, additions in green, deletions in red, line numbers */
function renderDiff(text, removable = false) {
  if (!text || !text.trim()) return "";
  const rows = text.split("\n"), taskFiles = [];
  let f = null, a = 0, b = 0;
  for (let i = 0; i < rows.length; i++) {
    const l = rows[i];
    if (l.startsWith("--- ") && (rows[i + 1] || "").startsWith("+++ ")) {
      const plus = rows[i + 1].slice(4).trim(), minus = l.slice(4).trim();
      const name = (plus === "/dev/null" ? minus.replace(/^a\//, "") : plus.replace(/^b\//, "")).replace(/\t.*$/, "");
      f = { name: name, plus: 0, less: 0, rankings: [], new: false, deleted: false, functions: [] }; taskFiles.push(f); i++; continue;
    }
    if (!f || l.startsWith("diff --git") || l.startsWith("index ")) continue;
    const h = l.match(/^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@/);
    if (h) {
      a = +h[1]; b = +h[3]; if (h[1] === "0" && h[2] === "0") f.new = true; if (h[3] === "0" && h[4] === "0") f.deleted = true;
      const ctx = l.replace(/^@@[^@]*@@\s*/, "").trim();          // function or class containing the change
      const fn = (ctx.match(/([A-Za-z_][\w:~]*)\s*\(/) || ctx.match(/(?:class|struct|def|function)\s+([\w:]+)/) || [])[1];
      if (fn && !f.functions.includes(fn)) f.functions.push(fn);
      f.rankings.push(["hunk", "", "", l]); continue;
    }
    if (l.startsWith("+")) { f.plus++; f.rankings.push(["add", "", b++, l.slice(1)]); }
    else if (l.startsWith("-")) { f.less++; f.rankings.push(["del", a++, "", l.slice(1)]); }
    else if (l.startsWith(" ")) { f.rankings.push(["ctx", a++, b++, l.slice(1)]); }
  }
  if (!taskFiles.length) return "";
  let budget = 4000;
  const tp = taskFiles.reduce((n, x) => n + x.plus, 0), tm = taskFiles.reduce((n, x) => n + x.less, 0);
  const fnCount = new Set(taskFiles.flatMap((x) => x.functions.map((fn) => x.name + fn))).size;
  return `<section class="report changes"><p class="title">Changements · ${taskFiles.length} fichier${taskFiles.length > 1 ? "s" : ""}${fnCount ? ` · ${fnCount} fonction${fnCount > 1 ? "s" : ""}` : ""} · <span class="ok">+${tp}</span> <span class="bad">−${tm}</span></p>
    <p class="subtle help-diff">Clique sur un fichier pour voir ce qui a changé.${removable ? " « Retirer » : le fichier n'est pas gardé (la version de l'agent reste dans le dossier de la tâche)." : ""}</p>
    ${taskFiles.map((x) => {
      const ranks = x.rankings.slice(0, Math.max(0, budget)); budget -= ranks.length;
      return `<details class="file-diff"><summary><span class="name-f">${esc(x.name)}</span>${x.new ? '<span class="type">nouveau</span>' : x.deleted ? '<span class="type">supprimé</span>' : ""}<span class="plus">+${x.plus}</span><span class="less">−${x.less}</span>${x.functions.length ? `<small class="functions">${x.functions.slice(0, 6).map(esc).join(" · ")}${x.functions.length > 6 ? ` · +${x.functions.length - 6}` : ""}</small>` : ""}${removable ? `<button type="button" class="remove-f" data-remove="${esc(x.name)}" title="Ne pas garder ce changement">Retirer</button>` : ""}</summary>
        <div class="diff-rows"><table>${ranks.map(([k, n1, n2, t]) => `<tr class="${k}"><td class="n">${n1}</td><td class="n">${n2}</td><td class="t">${esc(t) || " "}</td></tr>`).join("")}</table>
        ${ranks.length < x.rankings.length ? `<p class="subtle" style="padding:4px 8px">… ${x.rankings.length - ranks.length} lignes de plus : « Ouvrir le dossier » pour le diff complet.</p>` : ""}</div></details>`;
    }).join("")}</section>`;
}

const ROLE_STATES = { working: "travaille", awaiting_user: "attend ton accord", paused: "en pause", elsewhere: "occupé ailleurs", free: "libre" };
function showDetail() {
  const d = $("#detail");
  if (!d) return;
  if (currentProject && !threeColumns()) chooseBlock("detail");
  else if (threeColumns()) renderTabsBlock();
  d.scrollTop = 0;                                          // the selected task is shown from its start, inside its block
  if (window.innerWidth <= 900) d.scrollIntoView({ behavior: matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth", block: "start" });
}
async function projectTeam(eq) {
  if (!eq) return;
  await preloadRoleModels(eq);
  const targetName = (c) => c.replace(/^(project|topic):/, "");
  const card = (r) => {
    const here = r.here[0], elsewhere = r.elsewhere[0];
    const what = here ? `<a href="#" data-task="${esc(here.task)}" title="${esc(withoutChain(here.request))}">${esc(here.title || short(here.request))}</a>${here.stage ? `<small>étape : ${esc(here.stage)}</small>` : ""}`
      : elsewhere ? `<small>sur ${esc(targetName(elsewhere.target))}</small>` : "";
    return `<div class="agent ${r.state}${r.adapted ?"" : " on-demand"}" data-edit-role="${esc(r.id)}" data-team-scope="project" tabindex="0" role="button" aria-haspopup="dialog" aria-label="Régler ${esc(r.name)}" title="${esc(r.name)}${r.adapted ? "" : " — sur demande pour ce projet"}">
      <div class="header"><span class="point ${r.state}"></span><b>${esc(r.name)}</b></div>
      <small>${esc(TOOL_LABELS[r.tool] || r.tool)}${r.model ? " · " + esc(r.model) : ""}${r.adapted ? "" : " · sur demande"}</small>
      ${what}
      <div class="agent-model-effort"><select data-card-model aria-label="Modèle de ${esc(r.name)}" data-connection="${esc(r.connection || "")}">${roleOptions(r, "model", true).map(([v, t]) => `<option value="${esc(v)}"${v === (r.model || "") ? " selected" : ""}>${esc(t)}</option>`).join("")}</select>
      <select data-card-effort aria-label="Effort de ${esc(r.name)}"><option value="${esc(r.effort || "")}">Chargement des efforts…</option></select></div>
      <span class="state-a ${r.state ==="free" ? "ok" : r.state === "paused" ? "bad" : "warn"}">${ROLE_STATES[r.state]}</span></div>`;
  };
  const n = eq.filter((r) => r.state === "working").length;
  const rank = { working: 0, awaiting_user: 1, paused: 2, elsewhere: 3, free: 4 };
  const order = [...eq].sort((x, y) => (rank[x.state] - rank[y.state]) || (y.adapted - x.adapted));   // who works first
  const row = $("#p-team");
  const focusedRole = row.contains(document.activeElement) ? document.activeElement.dataset.editRole : "";
  row.innerHTML = order.map(card).join("");
  for (const card of row.querySelectorAll("[data-edit-role]")) {
    const role = eq.find((r) => r.id === card.dataset.editRole), model = card.querySelector("[data-card-model]"), effort = card.querySelector("[data-card-effort]");
    if (role.connection) await loadRoleModels(model, role.connection);
    bindRoleEffort(model, effort, role, currentProject);
    model.onchange = () => saveRoleSettings(role.id, { model: model.value, effort: "auto" }, currentProject).then(() => refreshTeam(currentProject)).catch((e) => alert(e.message));
    effort.onchange = () => saveRoleSettings(role.id, { effort: effort.value }, currentProject).then(() => refreshTeam(currentProject)).catch((e) => alert(e.message));
  }
  if (focusedRole) [...row.querySelectorAll("[data-edit-role]")].find((card) => card.dataset.editRole === focusedRole)?.focus({ preventScroll: true });
  $$("#p-team a[data-task]").forEach((a) => (a.onclick = (ev) => { ev.preventDefault(); selection = a.dataset.task; lastView = ""; show(); showDetail(); }));
}

/* Même source de choix et mêmes écritures pour les cartes et les réglages en ligne. */
function roleOptions(role, field, project = false) {
  const selected = field === "ai" ? role.ai : role[field] || "";
  const list = field === "ai" ? [["", project ? "Commun (IA du métier)" : "Auto · meilleure IA disponible"], ...(role.ai_options || [])]
    : field === "model" ? [["", `${project ? "Commun" : "Auto"} (${project ? role.shared_model_label : role.model_label})`], ...(role.model_options || [])]
    : [["", project ? "Commun (effort de l’agent)" : "Selon le mode"], ["auto", "Auto"], ...(role.effort_options || [])];
  if (selected && !list.some(([value]) => value === selected)) list.push([selected, selected]);
  return list;
}
async function saveRoleSettings(role, fields, target = "") {
  if (target) return api("/api/teams/role", { target: target, role, ...fields });
  if ("ai" in fields) await api("/api/ai-role", { role, ai: fields.ai });
  if ("model" in fields) await api("/api/models", { role, model: fields.model });
  if ("effort" in fields) await api("/api/efforts", { role, effort: fields.effort });
  if ("active" in fields || "instructions" in fields) return api("/api/teams/common-role", { role, ...("active" in fields ? { active: fields.active } : {}), ...("instructions" in fields ? { instructions: fields.instructions } : {}) });
}
async function refreshTeam(target = "") {
  if (target && currentProject === target) {
    const project = await api(`/api/projects/${encodeURIComponent(target)}`);
    if (currentProject === target) { projectTeam(project.team); await teamSettings(); }
  } else if (!target) {
    await gTeam();
    if (currentProject) await refreshTeam(currentProject);
  }
}
async function loadEffortChoices(input, id, model = "", role = "", target = "", inherit = false) {
  if (!input) return;
  const revision = String(Number(input.dataset.effortRevision || 0) + 1);
  input.dataset.effortRevision = revision;
  const selected = input.value;
  input.disabled = true;
  input.dataset.loadingEffort = "1";
  input.innerHTML = '<option value="">Chargement des efforts…</option>';
  try {
    const cap = await api("/api/ai/efforts", { id, model, role, target });
    if (!input.isConnected || input.dataset.effortRevision !== revision) return;
    const entries = cap.adjustable ? [...(inherit ? [["", target ? "Commun (effort de l’agent)" : "Selon le mode"]] : []),
      ["auto", "Auto"], ...cap.options] : [["auto", cap.message || "Non réglable pour ce modèle"]];
    input.innerHTML = entries.map(([value, label]) => `<option value="${esc(value)}">${esc(label)}</option>`).join("");
    input.value = entries.some(([value]) => value === selected) ? selected : inherit && cap.adjustable ? "" : "auto";
    input.disabled = !cap.adjustable;
    input.title = cap.message || "Effort du modèle choisi";
    input.dataset.loadingEffort = "";
    input.dispatchEvent(new Event("effortloaded"));
    return cap;
  } catch (error) {
    if (input.dataset.effortRevision !== revision) return;
    input.dataset.loadingEffort = "error";
    input.innerHTML = '<option value="auto">Capacités indisponibles</option>';
    input.title = error.message;
  }
}
function bindRoleEffort(model, effort, role, target = "", id = "") {
  const refresh = () => loadEffortChoices(effort, id || model.dataset.connection || role.connection || role.ai || role.effective_tool || role.tool,
    model.value || role.effective_model || "", role.id, target, true);
  model.addEventListener("change", refresh);
  return refresh();
}
const modelLists = new Map();
async function modelList(connection, force = false) {
  const previous = modelLists.get(connection);
  if (previous && !force && Date.now() - previous.at < 15000) return previous.promise;
  const promise = api("/api/ai/models", { id: connection });
  modelLists.set(connection, { at: Date.now(), promise });
  return promise;
}
function modelCaption(name, list) {
  return name + (list?.local && list.available && !list.models.some((m) => m === name || m === name + ":latest") ? " · plus installé" : "");
}
function ensureSupervisorStatus() {
  let el = $("#supervisor-status");
  if (!el) { el = document.createElement("p"); el.id = "supervisor-status"; el.className = "warn"; el.setAttribute("role", "status"); $("#sup-model").closest(".sup-header").after(el); }
  return el;
}
async function loadRoleModels(input, connection) {
  if (!input || !connection) return;
  input.dataset.connection = connection;
  input.disabled = true;
  const value = input.value;
  try {
    const list = await modelList(connection);
    if (!input.isConnected || input.dataset.connection !== connection) return;
    const entries = [["", "Auto"], ...list.models.map((model) => [model, model + (model === list.recommended ? " · conseillé par les classements" : "")])];
    if (value && !entries.some(([m]) => m === value)) entries.push([value, modelCaption(value, list)]);
    input.innerHTML = entries.map(([model, label]) => `<option value="${esc(model)}"${model === value ? " selected" : ""}${model && label.endsWith("plus installé") ? " disabled" : ""}>${esc(label)}</option>`).join("");
    input.title = list.error || "Modèles disponibles";
    input.disabled = !list.available;
    let note = input.parentElement.querySelector("[data-model-note]");
    if (!note) { note = document.createElement("small"); note.dataset.modelNote = "1"; note.className = "warn"; input.after(note); }
    note.textContent = list.error || (list.missing ? "Modèle enregistré plus installé : choisis un modèle disponible." : "");
    if (list.local && (list.error || list.missing)) {
      const start = document.createElement("button"); start.type = "button"; start.className = "btn small"; start.textContent = "Démarrer l’IA locale";
      start.onclick = async () => { try { start.disabled = true; await api("/api/ai/start", { id: connection }); modelLists.delete(connection); await loadRoleModels(input, connection); } catch (error) { note.textContent = error.message; } finally { start.disabled = false; } };
      note.append(" ", start);
    }
  } catch (error) {
    input.title = "Liste indisponible : " + error.message;
    const note = document.createElement("small"); note.className = "warn"; note.textContent = input.title; input.after(note);
  }
}
async function preloadRoleModels(roles) {
  await Promise.all([...new Set(roles.map((r) => r.connection).filter(Boolean))].map((id) => modelList(id).catch(() => null)));
  for (const role of roles) {
    if (!role.connection) continue;
    try { const list = await modelList(role.connection); role.model_label = modelCaption(role.effective_model || role.model || list.current, list); } catch { /* L'erreur sera affichée près du menu. */ }
  }
}
async function openRoleEditor(roleId, target = "") {
  const dialog = $("#team-editor"), opener = document.activeElement;
  try {
    const data = await api(target ? `/api/teams/project?target=${encodeURIComponent(target)}` : "/api/organization");
    await preloadRoleModels(data.roles || data.team);
    const role = (data.roles || data.team).find((item) => item.id === roleId);
    if (!role) return;
    const tasks = target ? (await api(`/api/projects/${encodeURIComponent(target)}`)).team.find((item) => item.id === roleId) : null;
    const busy = tasks ? ["working", "elsewhere"].includes(tasks.state) : (role.tasks || []).some((task) => ACTIVE_STATUSES.includes(task.status));
    const opt = (field) => roleOptions(role, field, !!target).map(([value, label]) => `<option value="${esc(value)}"${value === (field === "ai" ? role.ai : role[field] || "") ? " selected" : ""}>${esc(label)}</option>`).join("");
    dialog.innerHTML = `<form class="dialog-card card team-editor-form" aria-labelledby="team-editor-title">
      <h2 id="team-editor-title">${esc(role.name)}</h2><p class="subtle">${target ? "Réglages propres à ce projet" : "Réglages communs, utilisés par défaut dans les projets"}</p>
      ${busy ? '<p class="warn">Ces réglages s’appliquent aux prochaines tâches, pas à celle en cours.</p>' : ""}
      <label><input type="checkbox" name="active" ${(target ? role.active : role.enabled) ? "checked" : ""} ${role.locked_active ? "disabled" : ""}> ${target ? "Actif sur ce projet" : "Actif par défaut dans les projets"}</label>
      <label>IA / outil<select name="ai">${opt("ai")}</select></label>
      <div class="task-model-effort"><label>Modèle<select name="model" data-connection="${esc(role.connection)}">${opt("model")}</select></label>
      <label>Effort<select name="effort">${opt("effort")}</select></label></div>
      <label>Consignes<textarea name="instructions" rows="7" maxlength="4000">${esc(role.instructions || "")}</textarea></label>
      <p class="warn" data-editor-error role="alert"></p><div class="bottom"><button type="button" class="btn subtle" data-editor-cancel>Annuler</button><button type="submit" class="btn main">Enregistrer</button></div></form>`;
    const form = dialog.querySelector("form"), controls = form.elements;
    const close = () => { dialog.hidden = true; dialog.onkeydown = null; const card = [...$$("[data-edit-role]")].find((item) => item.dataset.editRole === roleId && item.dataset.teamScope === (target ? "project" : "common")); (opener?.isConnected ? opener : card)?.focus({ preventScroll: true }); };
    if (role.connection) await loadRoleModels(controls.model, role.connection);
    await loadEffortChoices(controls.effort, controls.ai.value || controls.model.dataset.connection || role.effective_tool, controls.model.value || role.effective_model, role.id, target, true);
    dialog.hidden = false;
    form.querySelector("[data-editor-cancel]").onclick = close;
    dialog.onkeydown = (event) => {
      if (event.key === "Escape") { event.preventDefault(); close(); }
      if (event.key === "Tab") {
        const items = [...form.querySelectorAll("input, select, textarea, button")].filter((item) => !item.disabled);
        if (event.shiftKey && document.activeElement === items[0]) { event.preventDefault(); items.at(-1).focus(); }
        else if (!event.shiftKey && document.activeElement === items.at(-1)) { event.preventDefault(); items[0].focus(); }
      }
    };
    controls.ai.onchange = async () => {
      const choice = role.source_options[controls.ai.value] || role.default_source_options;
      for (const [field, entries] of [["model", choice?.models || role.model_options], ["effort", choice?.efforts || role.effort_options]]) {
        controls[field].innerHTML = [["", target ? "Commun (automatique)" : "Auto"], ...(entries || [])].map(([value, label]) => `<option value="${esc(value)}">${esc(label)}</option>`).join("");
      }
      controls.model.dataset.connection = choice?.connection || "";
      if (controls.model.dataset.connection) await loadRoleModels(controls.model, controls.model.dataset.connection);
      controls.effort.value = "auto";
      await loadEffortChoices(controls.effort, controls.ai.value || choice?.id || controls.model.dataset.connection || role.effective_tool,
        controls.model.value, role.id, target, true);
    };
    controls.model.addEventListener("change", () => loadEffortChoices(controls.effort,
      controls.ai.value || controls.model.dataset.connection || role.effective_tool, controls.model.value, role.id, target, true));

    form.onsubmit = async (event) => {
      event.preventDefault();
      if (controls.effort.dataset.loadingEffort || controls.model.disabled) { form.querySelector('[data-editor-error]').textContent = "Attends le chargement des efforts ou réessaie."; return; }
      const submit = form.querySelector('[type="submit"]'); submit.disabled = true;
      const fields = { model: controls.model.value, effort: controls.effort.value, instructions: controls.instructions.value };
      if (!role.locked_active) fields.active = controls.active.checked;
      if (controls.ai.value !== role.ai) fields.ai = controls.ai.value;
      try { await saveRoleSettings(roleId, fields, target); await refreshTeam(target); close(); }
      catch (error) { form.querySelector("[data-editor-error]").textContent = error.message; submit.disabled = false; }
    };
    (role.locked_active ? controls.ai : controls.active).focus();
  } catch (error) { infoBubble(error.message); }
}
function editRoleCard(event) {
  const card = event.target.closest("[data-edit-role]");
  if (!card || event.target.closest("a, select, input, textarea, button")) return;
  if (event.type === "keydown" && (event.key !== "Enter" || event.target !== card)) return;
  event.preventDefault();
  openRoleEditor(card.dataset.editRole, card.dataset.teamScope === "project" ? currentProject : "");
}
document.addEventListener("click", editRoleCard);
document.addEventListener("keydown", editRoleCard);

/* Project team: the shared roles, tuned for this project (active, model, effort, instructions) + its MCP servers */
async function teamSettings() {
  const el = $("#p-team-settings"), key = currentProject;
  if (!el || !key) return;
  let v;
  try { v = await api(`/api/teams/project?target=${encodeURIComponent(key)}`); } catch (e) { el.innerHTML = `<p class="warn">${esc(e.message)}</p>`; return; }
  await preloadRoleModels(v.roles);
  if (currentProject !== key) return;
  const opt = (items, sel) => items.map(([k, t]) => `<option value="${esc(k)}"${k === sel ? " selected" : ""}>${esc(t)}</option>`).join("");
  const rows = v.roles.map((r) => `<tr class="${r.active ?"" : "inactif"}" data-role="${esc(r.id)}">
      <td><label style="display:flex;gap:8px;align-items:center"><input type="checkbox" data-eq="active" ${r.active ? "checked" : ""} ${r.locked_active ? "disabled" : ""}><span><b>${esc(r.name)}</b>${r.clean ? "<span class=\"dot\">propre au projet</span>" : ""}${r.custom ? "<span class=\"dot custom\">réglé ici</span>" : ""}</span></label></td>
      <td><select data-eq="ai" aria-label="IA de ${esc(r.name)}">${opt(roleOptions(r, "ai", true), r.ai)}</select></td>
      <td><select data-eq="model" data-connection="${esc(r.connection)}" aria-label="Modèle de ${esc(r.name)}">${opt(roleOptions(r, "model", true), r.model)}</select></td>
      <td class="col-effort"><select data-eq="effort" aria-label="Effort de ${esc(r.name)}">${opt(roleOptions(r, "effort", true), r.effort)}</select></td>
      <td><button class="btn subtle small" data-eq-instructions="1" title="${esc(r.instructions || "Consignes propres à ce projet")}">${r.instructions ? "Consignes ●" : "Consignes"}</button></td></tr>`).join("");
  const mcp = v.mcp.length ? `<p class="sub-title-g" style="margin-top:14px">Serveurs MCP de ce projet</p><div class="chips small">${v.mcp.map((m) => `<label class="chip${m.active ?" sel" : ""}" style="cursor:pointer"><input type="checkbox" data-mcp-p="${esc(m.name)}" ${m.active ? "checked" : ""} hidden>${esc(m.name)}</label>`).join("")}</div>
      <small class="subtle">${v.mcp_rule ? "Choix propre à ce projet." : "Tous actifs (aucun choix propre)."} Ajoute des serveurs dans Extensions › + Ajouter.</small>` : "";
  el.innerHTML = `<p class="sub-title-g" style="margin-top:16px">Réglages de l'équipe pour ce projet</p>
    <p class="management-help subtle">Les métiers sont communs à tous les projets. Ici, tu choisis ceux qui servent à ce projet, leur modèle, leur effort et des consignes propres. Une demande précise passe toujours avant.</p>
    <div class="matrix-scroll"><table class="team-settings"><thead><tr><th>Métier</th><th>IA / outil</th><th>Modèle</th><th class="col-effort">Effort</th><th></th></tr></thead><tbody>${rows}</tbody></table></div>
    <div class="actions" style="margin:10px 0 0"><button class="btn main" id="eq-optimize" title="Remet chaque métier de ce projet sur Auto : meilleur modèle selon les classements, effort selon le mode">Optimiser selon les classements</button><button class="btn" id="eq-create">Créer un agent pour ce projet</button></div>${mcp}`;
  const configure = async (role, fieldValues) => { try { await saveRoleSettings(role, fieldValues, key); await refreshTeam(key); } catch (e) { alert(e.message); } };
  $$("#p-team-settings tr[data-role]").forEach((tr) => {
    const role = tr.dataset.role;
    tr.querySelector("[data-eq=\"active\"]").onchange = (ev) => configure(role, { active: ev.target.checked });
    tr.querySelector('[data-eq="ai"]').onchange = (ev) => configure(role, { ai: ev.target.value, model: "", effort: "" });
    const m = tr.querySelector("[data-eq=\"model\"]");
    if (m) {
      m.onchange = (ev) => configure(role, { model: ev.target.value });
      if (m.dataset.connection) loadRoleModels(m, m.dataset.connection);
    }
    bindRoleEffort(m, tr.querySelector('[data-eq="effort"]'), v.roles.find((r) => r.id === role), key);
    tr.querySelector('[data-eq="effort"]').onchange = (ev) => configure(role, { effort: ev.target.value });
    tr.querySelector("[data-eq-instructions]").onclick = () => openRoleEditor(role, key);

  });
  $$("#p-team-settings [data-mcp-p]").forEach((c) => (c.onchange = async () => {
    const names = [...$$("#p-team-settings [data-mcp-p]")].filter((x) => x.checked).map((x) => x.dataset.mcpP);
    try { await api("/api/teams/mcp", { target: key, names: names }); teamSettings(); } catch (e) { alert(e.message); }
  }));
  $("#eq-create").onclick = () => { projectAgent = key; $("#create-agent").onclick(); };
  $("#eq-optimize").onclick = () => optimizeAgents(key);
}
/* « Optimiser selon les classements »: everything back to Auto (best AI and model per trade in the rankings) */
async function optimizeAgents(key) {
  const where = key ? "de ce projet" : "de tous les projets";
  if (!confirm(`Optimiser les agents ${where} ?\n\nChaque métier repasse sur Auto : la meilleure IA et le meilleur modèle pour ce métier selon les classements, parmi tes IA connectées ; l'effort suit le mode du projet.\nTes réglages actuels sont gardés dans une copie.`)) return;
  try {
    const r = await api("/api/agents/optimize", key ? { target: key } : {});
    const lines = r.plan.slice(0, 8).map((x) => `${x.role} : ${x.ai} · ${x.model}`).join(" ; ");
    infoBubble(`${r.modified ? r.modified + " réglage(s) remis sur Auto" : "Déjà optimisé"}. ${lines}${r.plan.length > 8 ? " …" : ""}`);
    if (key) teamSettings(); else gTeam();
    shortcutsCache = null;
  } catch (e) { alert(e.message); }
}
let projectAgent = "";
document.addEventListener("click", (ev) => { if (ev.target.closest("[data-close-card]") && view !== "custom") $("#custom-card").hidden = true; });

const ACTIVE_STATUSES = ["created", "running", "awaiting_slot"];
function taskTime(x) {
  if (ACTIVE_STATUSES.includes(x.status) && x.stage_since) return `⏱ ${timer(x.stage_since, x.duration_s)}`;
  return x.duration_s ? `⏱ ${formatDuration(x.duration_s)}` : "";
}
const withoutChain = (t) => String(t || "").split("\n\n---\nÉtape ")[0];
/* Short task name (same rule as studio/titles.py): the given title, else the first sentence of the request, 60 chars. */
function short(request, maxLength = 60) {
  let t = withoutChain(request).replace(/[`*#>]+/g, "").replace(/(?<!\w)_+|_+(?!\w)/g, "");   // keeps L_Exploration
  const a = /[$[]audit-(skills|memories)\s+(audit|fix|clean)\b/.exec(t);
  if (a) return (a[2] === "audit" ? "Audit des " : "Appliquer l'audit des ") + (a[1] === "skills" ? "skills" : "mémoires");
  t = t.split(/\s+/).join(" ").replace(/^(objectif|but|tâche|tache|demande|mission|contexte|résumé|resume|titre|todo|à faire|a faire)\s*[:：\-–—]\s*/i, "");
  t = t.split(/(?<=[.!?])\s|\s(?:où|ou|contexte|lis|lire|cible|livrable|critères?|périmètre)\s*:\s/i)[0].replace(/^[\s.;:\-–—]+|[\s.;:\-–—]+$/g, "");
  if (t.length > maxLength) { const v = t.lastIndexOf(", ", maxLength); if (v >= 25) t = t.slice(0, v); }
  if (t.length > maxLength) t = (t.slice(0, maxLength).replace(/\s+\S*$/, "").replace(/[\s,;:\-–—(]+$/, "") || t.slice(0, maxLength)) + "…";
  return t ? t[0].toUpperCase() + t.slice(1) : "Tâche";
}
/* The project name is useless in the title: the tab already shows it (« … sur RPG3D » → « … ») */
function withoutProject(t, names) {
  for (const n of [...new Set(names.filter((x) => x && x.length >= 2))].sort((a, b) => b.length - a.length)) {
    const e = n.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    t = t.replace(new RegExp(`\\s*\\b(sur|dans|de|du|pour|à|au)\\s+(le\\s+projet\\s+|le\\s+)?${e}(?![\\w-])`, "gi"), "")
      .replace(new RegExp(`^\\s*${e}\\s*[:：\\-–—]\\s*`, "i"), "").replace(new RegExp(`\\s*\\(\\s*${e}\\s*\\)`, "gi"), "");
  }
  return t.split(/\s+/).join(" ").replace(/^[\s,;:\-–—]+|[\s,;:\-–—]+$/g, "");
}
const taskName = (x) => {
  const target = String(x.target || ""), id = target.split(":").pop();
  const t = x.title || (x.options && x.options.title) || short(x.request || x.summary || "", 400);
  return short(withoutProject(t, [targetName(target), id]) || t, 50);
};   // the chaining reminder stays for the agent, not for the list
/* Task card: progress bar (Plan → Agent → Check → Review → Done) and latest action while running,
   direct buttons when it waits for the user (Valider, Corriger, Reprendre): a one-click decision, without opening the details. */
const PHASES = [["Plan", ["request", "choices_target", "context", "plan", "unreal"]], ["Agent", ["execution"]], ["Vérif", ["verification"]],
  ["Relecture", ["audit"]], ["Fin", ["presentation", "approval", "application", "merge", "finalization", "memory"]]];
/* Same bar at the top of the task: where it is now (Plan · Agent · Vérif · Relecture · Fin) */
function taskStepper(t, s) {
  const waiting = TO_APPROVE.includes(t.status), active = ACTIVE_STATUSES.includes(t.status);
  const failed = ["blocked", "interrupted", "failed", "cancelled"].includes(t.status);
  const ordered = [...s.stages].sort((a, b) => (a.started_at < b.started_at ? -1 : 1));
  const current = ordered.filter((e) => e.status === "running" && !e.ended_at).pop() || ordered.filter((e) => e.ended_at).pop();   // same rule as the card
  const at = current ? Math.max(0, PHASES.findIndex(([, names]) => names.includes(current.name))) : 0;
  const i = waiting ? 4 : active || failed ? at : 5;                  // 5 = everything done
  const last = waiting ? "À valider" : failed ? (LABELS[t.status] || t.status) : "";
  return `<div class="phases phases-task${failed ?" stopped" : ""}" role="img" aria-label="Étape : ${i < 5 ? PHASES[Math.min(i, 4)][0] : "Fin"}">${PHASES.map(([n], k) =>
    `<span class="${k < i ?"faite" : k === i ? (failed ? "stop" : "active") : ""}">${k === i && last ? esc(last) : n}</span>`).join("")}</div>`;
}
function phaseBar(x) {
  if (!["created", "running"].includes(x.status)) return "";
  if (x.id === selection && $("#detail") && $("#detail").dataset.tid === x.id && !$("#detail").closest("[hidden]")) return "";   // already at the top of the open task
  const i = Math.max(0, PHASES.findIndex(([, names]) => names.includes(x.stage_name)));
  return `<div class="phases" role="img" aria-label="Étape : ${PHASES[i][0]}">${PHASES.map(([n], k) => `<span class="${k < i ?"faite" : k === i ? "active" : ""}">${n}</span>`).join("")}</div>
    ${x.last_action ? `<small class="action-running">${esc(x.last_action)}${(+x.attempt || 1) > 1 ? ` · essai ${x.attempt}` : ""}</small>` : ""}`;
}
function quickActions(x) {
  if (TO_APPROVE.includes(x.status)) return `<div class="quick"><button class="btn main small" data-fast="validate" data-tid="${esc(x.id)}" title="Valider sans ouvrir la tâche">Valider</button><button class="btn small" data-fast="correct" data-tid="${esc(x.id)}">Corriger</button></div>`;
  if (["blocked", "interrupted", "failed"].includes(x.status)) return `<div class="quick">${x.summary ? `<small class="blocking-reason">${esc(String(x.summary).split("\n")[0].slice(0, 120))}</small>` : ""}<button class="btn main small" data-fast="resume" data-tid="${esc(x.id)}">Reprendre</button></div>`;
  return "";
}
/* What a task awaiting approval produced, right on its card: first images (click = full size) and file count */
function previews(x) {
  if (!TO_APPROVE.includes(x.status)) return "";
  const imgs = x.previews || [], more = (+x.count_files || 0) - imgs.length;
  if (!imgs.length && more <= 0) return "";
  return `<div class="previews">${imgs.map((p) => `<button class="preview" data-preview="${esc(p)}" data-tid="${esc(x.id)}" title="${esc(p.split("/").pop())}"><img src="${fileUrl({ tid: x.id, path_value: p })}" alt="" loading="lazy"></button>`).join("")}${more > 0 ? `<span class="plus-f">${imgs.length ? "+ " : ""}${more} fichier${more > 1 ? "s" : ""}</span>` : ""}</div>`;
}
document.addEventListener("click", (e) => {               // thumbnail: opens the image, without opening the task
  const b = e.target.closest("[data-preview]");
  if (!b) return;
  e.stopPropagation(); e.preventDefault();
  const path_value = b.dataset.preview;
  showFile({ tid: b.dataset.tid, path_value, name: path_value.split("/").pop(), category_kind: "image", task: "" });
}, true);
function renderSupervisorActions(message) {
  const proposal = message.proposal;
  const describeTarget = (key) => typeof targetName === "function" ? targetName(key) : key;
  const describeAI = (id) => (typeof aiState !== "undefined" ? aiState?.connections?.find((c) => c.id === id)?.name : "")
    || (typeof TOOL_LABELS !== "undefined" ? TOOL_LABELS[id] : "") || (id ? "IA demandée" : "Celle de l’agent");
  const busy = (proposal.actions || []).some((item) => ["running", "executing"].includes(item.state));
  return `<div class="proposal" data-supervisor-actions="${message.id}">
    ${proposal.error ? `<div class="warn">${esc(proposal.error)}</div>` : ""}
    ${(proposal.actions || []).map((item, index) => `<div data-action-name="${esc(item.action)}">
      ${item.state === "done" ? `<span class="ok">✔ Fait : ${esc(item.label)}</span>`
        : item.state === "error" ? `<span class="warn">${esc(item.label)} : ${esc(item.error)}</span>`
        : item.state === "ignored" ? `<span class="subtle">Ignorée : ${esc(item.label)}</span>`
        : item.state !== "pending" ? `<span class="subtle">En cours : ${esc(item.label)}</span>`
        : `<button class="btn main" data-supervisor-action="${index}" data-rid="${message.id}"${busy ? " disabled" : ""}>${esc(item.label)}</button>`}
      <small class="subtle">${esc(item.why)}</small>
      ${["express_task", "create_task"].includes(item.action) ? `<p><b title="${esc(item.params.target)}">${esc(describeTarget(item.params.target))}</b> · ${esc(item.params.request)}</p>` : `<small class="subtle">Action : ${esc(item.action)} · Paramètres : ${esc(JSON.stringify(item.params || {}))}</small>`}
      ${["express_task", "create_task"].includes(item.action) ? `<label>IA pour cette tâche <select data-action-ai="${index}" data-rid="${message.id}"><option value="${esc(item.params.ai || "")}">${esc(describeAI(item.params.ai))}</option></select></label><small>${item.action === "express_task" ? "Tâche express" : "Tâche"} · Modèle : ${esc(item.params.model || "choix de l’agent")}</small>` : ""}
      ${item.result?.tid ? `<button class="link" data-open-task="${esc(item.result.tid)}" data-target="${esc(item.params.target || "")}">Voir la tâche</button>` : ""}
    </div>`).join("")}
    ${(proposal.actions || []).some((item) => item.state === "pending") ? `<button class="btn subtle" data-supervisor-ignore="${message.id}"${busy ? " disabled" : ""}>Ignorer</button>` : ""}
    <span class="warn msg"></span></div>`;
}

document.addEventListener("click", async (event) => {
  const button = event.target.closest("[data-supervisor-action], [data-supervisor-ignore]");
  if (!button || button.disabled) return;
  const box = button.closest("[data-supervisor-actions]");
  const buttons = [...box.querySelectorAll("button")];
  buttons.forEach((item) => { item.disabled = true; });
  try {
    if (button.dataset.supervisorIgnore !== undefined) {
      await api(`/api/conversation/${button.dataset.supervisorIgnore}/ignorer`, {});
    } else {
      const rid = Number(button.dataset.rid), index = Number(button.dataset.supervisorAction);
      const messages = await api(`/api/conversation${projectChat ? "?project=" + encodeURIComponent(projectChat) : ""}`);
      const item = messages.find((message) => message.id === rid)?.proposal.actions[index];
      if (!item) throw new Error("Proposition introuvable.");
      if (item.action === "request_correction") {
        await requestCorrection(item.params.tid, item.params.comment, (comment) =>
          api(`/api/conversation/${rid}/action`, { index, comment }));
      } else {
        await api(`/api/conversation/${rid}/action`, { index, ...(box.querySelector(`[data-action-ai="${index}"]`) ? { ai: box.querySelector(`[data-action-ai="${index}"]`).value } : {}) });
      }
    }
    threadSignature = "";
    await loadConversation();
  } catch (error) {
    box.querySelector(".msg").textContent = error.message;
  } finally {
    buttons.forEach((item) => { item.disabled = false; });
  }
});

async function requestCorrection(tid, draft, submit) {
  const dialog = $("#correction-dialog");
  if (dialog.open) return false;
  const state = await api(`/api/tasks/${tid}`);
  if (dialog.open) return false;
  const form = $("#correction-form"), text = $("#correction-text"), send = $("#correction-send");
  const cancel = $("#correction-cancel"), error = $("#correction-error");
  text.value = draft === undefined ? state.correction_draft || "" : draft;
  error.textContent = "";
  send.disabled = cancel.disabled = false;
  return new Promise((resolve) => {
    let sent = false, pending = false;
    dialog.oncancel = (event) => { if (pending) event.preventDefault(); };
    dialog.onclose = () => {
      form.onsubmit = text.onkeydown = cancel.onclick = dialog.oncancel = dialog.onclose = null;
      resolve(sent);
    };
    cancel.onclick = () => dialog.close();
    form.onsubmit = async (event) => {
      event.preventDefault();
      const comment = text.value;
      if (!comment.trim() || pending) { if (!comment.trim()) text.focus(); return; }
      pending = true;
      send.disabled = cancel.disabled = true;
      error.textContent = "";
      try {
        if (submit) await submit(comment);
        else await api(`/api/tasks/${tid}/decision`, { decision: "correct", comment: comment });
        sent = true;
        dialog.close();
      } catch (failure) {
        error.textContent = failure.message;
      } finally {
        pending = false;
        send.disabled = cancel.disabled = false;
      }
    };
    text.onkeydown = (event) => {
      if (event.ctrlKey && event.key === "Enter") {
        event.preventDefault();
        form.requestSubmit();
      }
    };
    dialog.showModal();
    text.focus();
    text.setSelectionRange(0, 0);
  });
}

function taskItem(x) {
  return `<li data-id="${x.id}" class="${x.id === selection ?"sel" : ""}">
    <div class="line1"><span class="state ${state_color(x.status)}">${esc(taskLabel(x))}${x.chain ? `</span><span class="badge-chain" title="Étape d'une chaîne">⛓ ${(+x.stage || 0) + 1}` : ""}</span><small class="time">${taskTime(x)}</small></div>
    <small title="${esc(withoutChain(x.request || ""))}">${esc(taskName(x))}</small>${phaseBar(x)}${previews(x)}${quickActions(x)}</li>`;
}
document.addEventListener("click", async (e) => {         // cards' direct buttons: before the click that opens the task
  const b = e.target.closest("[data-fast]");
  if (!b) return;
  e.stopPropagation(); e.preventDefault();
  const tid = b.dataset.tid, a = b.dataset.fast;
  try {
    if (a === "validate") {
      const s = await api(`/api/tasks/${tid}`);
      await api(`/api/tasks/${tid}/decision`, { decision: "approve", fingerprint: s.fingerprint });
      infoBubble("Validée");
    } else if (a === "correct") {
      if (!await requestCorrection(tid)) return;
      infoBubble("Correction demandée");
    } else if (a === "cancel") {
      if (!confirm("Annuler cette tâche ?")) return;
      await api(`/api/tasks/${tid}/cancel`, {}); infoBubble("Tâche annulée");
    } else if (a === "stop") {
      b.disabled = true; b.textContent = "Arrêt…";
      await api(`/api/tasks/${tid}/stop`, {}); infoBubble("Arrêtée : « Reprendre » la relance là où elle en était");
    } else if (a === "resume") {
      b.disabled = true; b.textContent = "Reprise…";
      await api(`/api/tasks/${tid}/resume`, {});
      setTimeout(async () => { const x = await api(`/api/tasks/${tid}`).catch(() => null); if (x && x.task.status === "blocked") infoBubble("Toujours bloquée : " + (x.task.summary || "").split("\n")[0].slice(0, 120)); }, 1500);
    }
  } catch (er) { infoBubble(er.message); }
  setTimeout(() => { lastView = ""; if (currentProject) openProject(currentProject); else workSummary(); updateBadge(); if (currentBlock === "branches") gitDetail(); }, 600);
}, true);
let finishedSearch = "", finishedStatus = "";
const FINISHED_STATUSES = [["", "Toutes"], ["ok", "Validées"], ["cancelled", "Annulées"]];
function taskLists(t) {
  projectTasks = t;
  const validate = t.filter((x) => TO_APPROVE.includes(x.status)), running = t.filter((x) => IN_PROGRESS.includes(x.status));
  const allEntries = t.filter((x) => !TO_APPROVE.includes(x.status) && !IN_PROGRESS.includes(x.status));
  const q = finishedSearch.trim().toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  const stripAccents = (x) => (x || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  const filtered = allEntries.filter((x) => (!finishedStatus || (finishedStatus === "ok" ? ["approved", "applied"].includes(x.status) : x.status === finishedStatus))
    && (!q || stripAccents(`${x.request} ${x.summary} ${x.id}`).includes(q)));
  const finishedItems = filtered.slice(0, 50);
  $("#l-validate").innerHTML = validate.map(taskItem).join("") || "<li class=\"empty\" style=\"cursor:default\">Rien à valider.</li>";
  $("#l-running").innerHTML = running.map(taskItem).join("") || "<li class=\"empty\" style=\"cursor:default\">Rien en cours.</li>";
  $("#l-finished").innerHTML = finishedItems.map(taskItem).join("") || (allEntries.length ? "<li class=\"empty\" style=\"cursor:default\">Aucune tâche ne correspond.</li>" : "");
  $("#t-finished").textContent = `Terminées (${allEntries.length})`;
  $("#f-count").textContent = filtered.length > finishedItems.length ? `${finishedItems.length} affichées sur ${filtered.length} : précise la recherche.` : (q || finishedStatus) && allEntries.length ? `${filtered.length} sur ${allEntries.length}` : "";
  if (!$("#f-status").childElementCount) chipList($("#f-status"), FINISHED_STATUSES, finishedStatus, (v) => { finishedStatus = v; taskLists(projectTasks); });
  $$("#panel-tasks li[data-id]").forEach((li) => (li.onclick = () => { selection = li.dataset.id; lastView = ""; show(); taskLists(t); showDetail(); }));
  renderTabsBlock();
}
$("#f-search").oninput = () => { finishedSearch = $("#f-search").value; taskLists(projectTasks); };

$(".logo").onclick = (e) => { e.preventDefault(); showView("projects"); };

/* Tokens paid by the task, per attempt and step (agent, review, report), exact model as recorded. "?" = the tool
   returned no counter: never shown as 0. */
const USAGE_STAGES = { execution: "Agent", review: "Relecture", outcome: "Bilan" };
function usageBlock(u) {
  if (!u || !u.calls || !u.calls.length) return "";
  const n = (x) => (x == null ? "?" : Number(x).toLocaleString("fr-FR"));
  const tot = u.total || {};
  const rows = u.calls.map((c) => `<tr><td>${esc(USAGE_STAGES[c.stage] || c.stage || "—")}${c.attempt ? ` <small class="subtle">(essai ${c.attempt})</small>` : ""}</td>
    <td>${esc(c.model || c.family || "?")}</td><td class="nowrap">${n(c.input_tokens)}</td><td class="nowrap">${n(c.cache_tokens)}</td><td class="nowrap">${n(c.output_tokens)}</td></tr>`).join("");
  return `<details class="fold usage-task"><summary>Consommation : ${n(tot.input_tokens)} jetons en entrée · ${n(tot.cache_tokens)} en cache · ${n(tot.output_tokens)} en sortie</summary>
    <table class="usage-table"><thead><tr><th>Étape</th><th>Modèle exact</th><th>Entrée</th><th>Cache</th><th>Sortie</th></tr></thead><tbody>${rows}</tbody></table>
    ${tot.unknown ? `<small class="subtle">${tot.unknown} appel${tot.unknown > 1 ? "s" : ""} sans compteur renvoyé par l'outil.</small>` : ""}</details>`;
}

function taskAssessment(s) {
  const audit = s.audit || {};
  const review = audit.review || { state: "not_reviewed", defects: [] };
  const validationDefects = audit.validation_defects || [];
  const warnings = [];
  if (s.verification && s.verification.ok === false) warnings.push("Les vérifications ont échoué.");
  else if (validationDefects.length) warnings.push("Les règles du livrable ont relevé des défauts.");
  if (audit.validation_proposed) warnings.push("Il ne reste que des défauts mineurs ou historiques : tu peux valider si ça te va.");
  else if (review.state === "defects") warnings.push("La dernière relecture a relevé des défauts.");
  else if (review.state === "unavailable") warnings.push("La dernière relecture est indisponible ou son verdict est illisible.");
  return { review, validationDefects, warning: warnings.join(" ") };
}

const TRIAGE_LABELS = { blocking: "bloquant", security: "sécurité", missing_proof: "preuve manquante", minor: "mineur", historical: "historique" };
function triageLabel(audit) {
  const c = (audit && audit.triage && audit.triage.counts) || {};
  const parts = Object.keys(TRIAGE_LABELS).filter((k) => c[k]).map((k) => `${c[k]} ${TRIAGE_LABELS[k]}`);
  return parts.length ? ` · ${parts.join(", ")}` : "";
}

/* Real isolation of the task, said honestly: never « sandboxed » when the agent keeps the user's Windows rights. */
function isolationLine(i) {
  if (!i) return "";
  return `<details class="fold isolation-task"><summary>Isolation : ${esc(i.place)} · ${esc(i.guard)} — partielle</summary>
    <ul><li>${esc(i.environment)}</li><li>${esc(i.sentinels)}</li><li><b>${esc(i.limit)}</b></li></ul></details>`;
}

function taskResultLayout(active, stepLine, summary, log, attempt, verdict) {
  if (active) return `${stepLine}${log}${summary ? `<details class="fold previous-attempt"><summary>Résumé de la tentative précédente (${attempt})</summary>${summary}</details>` : ""}`;
  return `${verdict}${summary}${log}`;
}

async function show() {
  if (!selection) return;
  const s = await api(`/api/tasks/${selection}`);
  const t = s.task;
  if (ACTIVE_STATUSES.includes(t.status)) s.awaiting_decision = false;
  const key = `${t.id}|${t.status}|${t.updated_at}|${s.stages.length}|${s.awaiting_decision}|${s.chain ? s.chain.status + s.chain.current + s.chain.note : ""}|${JSON.stringify([s.audit && s.audit.review, s.audit && s.audit.validation_defects, s.verification])}`;
  if (key === lastView) return;
  lastView = key;
  const [res, dif] = await Promise.all([api(`/api/tasks/${selection}/result`),
    ACTIVE_STATUSES.includes(t.status) ? Promise.resolve({ text: "" }) : api(`/api/tasks/${selection}/diff`).catch(() => ({ text: "" }))]);
  const eq = s.team || {};
  // who works, with the exact model really used (read in the AI's own output; live while it works)
  const actor = eq.producer ? `${esc(eq.producer.role)} via ${esc(TOOL_LABELS[eq.producer.tool] || eq.producer.tool)}<span id="model-direct">${eq.producer.model ? " · " + esc(eq.producer.model) : ""}</span>`
    + ` · relu par ${esc(TOOL_LABELS[eq.reviewer.tool] || eq.reviewer.tool)}${eq.reviewer.model ? " · " + esc(eq.reviewer.model) : ""}` : "";
  const inProgress = IN_PROGRESS.includes(t.status);
  // The result (RESULTAT.md) is split: report up front, the rest collapsed
  const SECTIONS = ["Résumé de l'exécutant", "Fichiers", "Vérifications", "Audit", "Actions dans l'éditeur Unreal", "Commandes lancées", "Tentatives précédentes"];
  const sec = { _header: "" };
  let selected = "_header";
  (res.text || "").replace(/\r\n/g, "\n").split("\n").forEach((l) => {
    const m = /^## (.+)$/.exec(l);
    if (m && SECTIONS.some((k) => m[1].trim() === k || m[1].startsWith(k + " ") || m[1].startsWith(k + " —"))) { selected = m[1].trim(); sec[selected] = ""; }
    else sec[selected] += l + "\n";
  });
  Object.keys(sec).forEach((k) => (sec[k] = sec[k].trim()));
  const lowerTitles = (txt) => txt.replace(/^#{1,3}(?=[ \t])/gm, "####");   // agent headings: never at studio heading level
  const reportKey = Object.keys(sec).find((k) => k.startsWith("Résumé de l'exécutant"));
  const report = reportKey ? lowerTitles(sec[reportKey]) : "";
  const taskFiles = (sec["Fichiers"] || "").split("\n").filter((l) => l.startsWith("- ")).map((l) => l.slice(2).split(" : ")).filter(([, v]) => v && v !== "—");
  const fileCount = taskFiles.reduce((n, [, v]) => n + v.split(", ").length, 0);
  const assessment = taskAssessment(s);
  const checks = (s.verification && s.verification.checks) || [];
  const defects = assessment.review.defects;
  const checkOk = s.verification && s.verification.ok === true;
  const ueActions = (sec["Actions dans l'éditeur Unreal"] || "").split("\n").filter((l) => l.startsWith("- ")).map((l) => l.slice(2));
  const ueWrites = ueActions.filter((l) => l.startsWith("écriture")).length;
  const nothingToApply = !fileCount;
  const chip = (ok, text) => `<span class="chip-state ${ok ?"ok" : "bad"}">${ok ? "✔" : "✘"} ${esc(text)}</span>`;
  const verdict = res.text ? `<div class="verdict-task"><span class="chip-state">${nothingToApply ? "aucun fichier modifié" : `${fileCount} fichier${fileCount > 1 ? "s" : ""} modifié${fileCount > 1 ? "s" : ""}`}</span>
      ${ueActions.length ? `<span class="chip-state${ueWrites ?" ue" : ""}">Unreal : ${ueActions.length} action${ueActions.length > 1 ? "s" : ""}${ueWrites ? ` dont ${ueWrites} modification${ueWrites > 1 ? "s" : ""}` : ", lecture"}</span>` : ""}
      ${checks.length ? chip(checkOk, checkOk ? "vérifications OK" : "vérifications en échec") : ""}${assessment.review.state === "not_reviewed" ? "<span class=\"chip-state\">relecture non faite</span>"
        : chip(assessment.review.state === "ok", assessment.review.state === "unavailable" ? "relecture indisponible"
          : defects.length ? `${defects.length} défaut${defects.length > 1 ? "s" : ""} à la dernière relecture` : "relecture OK")}</div>` : "";
  const BTN_FOLDER = `<button class="btn subtle folder-bottom" id="folder" title="Ouvre le dossier de la tâche dans l'Explorateur">Ouvrir le dossier</button>`;
  const decision = s.awaiting_decision
    ? `<div class="decision-bottom decision-top"><p class="help-decision">${nothingToApply
        ? (ueWrites ? `Aucun fichier du dépôt modifié, mais ${ueWrites} modification${ueWrites > 1 ? "s" : ""} faite${ueWrites > 1 ? "s" : ""} directement dans l'éditeur Unreal (voir Détails). Classe la tâche, ou demande une correction.`
          : "Rien à appliquer : ce compte rendu ne modifie aucun fichier. Classe-le, ou demande une correction.")
        : fileCount > 1 ? `Valider applique exactement ces ${fileCount} fichiers au projet.` : "Valider applique exactement ce fichier au projet."}${assessment.warning ? ` <b class="warn">${esc(assessment.warning)}</b>` : ""}</p>
       <div class="decision"><button class="btn main" id="ok">${nothingToApply ? "Classer" : "Valider"}</button><button class="btn" id="corr">Demander une correction</button><button class="btn subtle danger" id="ann">Annuler</button></div></div>`
    : ACTIVE_STATUSES.includes(t.status) ? `<div class="decision-bottom"><div class="decision"><button class="btn" id="stop" title="Arrête l'agent ; « Reprendre » le relance là où il en était (même conversation, rien n'est refait)">Stop</button><button class="btn subtle danger" id="ann">Annuler</button></div></div>`
    : inProgress ? `<div class="decision-bottom">${["blocked", "interrupted", "failed"].includes(t.status) && t.summary ? `<p class="blocking-reason">${esc(t.status === "blocked" ? "Bloquée : " : "")}${esc(t.summary.split("\n")[0].slice(0, 220))}</p>` : ""}<div class="decision"><button class="btn main" id="rep">Reprendre</button><button class="btn subtle danger" id="ann">Annuler</button></div></div>`
    : "";
  const request = withoutChain(t.request || "");
  const shortTitle = taskName(t);
  const active = ACTIVE_STATUSES.includes(t.status);
  const stepDuration = (e) => e.ended_at ? formatDuration(seconds(e.started_at, e.ended_at)) : (active && e.status === "running" ? timer(e.started_at) : "—");
  const work = s.stages.filter((e) => e.ended_at).reduce((n, e) => n + seconds(e.started_at, e.ended_at), 0);
  const activeStep = s.stages.find((e) => !e.ended_at && e.status === "running");
  const byType = {};
  s.stages.filter((e) => e.ended_at).forEach((e) => (byType[e.name] = (byType[e.name] || 0) + seconds(e.started_at, e.ended_at)));
  const timeDetail = ["execution", "audit", "verification"].filter((k) => byType[k] >= 1).map((k) => `${k} ${formatDuration(byType[k])}`).join(" · ");
  const elapsed = `<small class="task-duration">⏱ Temps de travail : <b>${active && activeStep ? timer(activeStep.started_at, work) : formatDuration(work)}</b>${timeDetail ? ` (${timeDetail})` : ""}</small>`;
  // Steps and log in plain French: what happened, in order, without jargon
  const STEP_NAME = { request: "Demande reçue", choices_target: "Projet choisi", context: "Contexte et mémoire lus", plan: "Plan préparé",
    unreal: "Unreal ouvert", execution: "L'agent travaille", verification: "Vérifications", audit: "Relecture par un 2e agent",
    approval: "En attente de ta décision", application: "Résultat appliqué", merge: "Fusion", graph: "Studio" };
  const STEP_STATE = { completed: "✔ fini", running: "en cours…", failed: "✘ échec", error: "✘ erreur", cancelled: "annulé" };
  const plaintext = (t) => String(t || "").replace("serveur unreal-mcp déjà en ligne", "déjà connecté").replace("unreal-mcp prêt", "connexion prête")
    .replace("unreal-mcp injoignable", "connexion impossible").replace(/serveur unreal-mcp|unreal-mcp/g, "connexion à Unreal").replace(/\bMCP\b/g, "connection")
    .replace(/worktree/gi, "copie de travail").replace(/\bcommit\b/g, "commit");
  const STEP_DETAIL = (e) => plaintext( e.name === "choices_target" ? targetName(e.detail) : e.name === "plan" ? "" : e.name === "context" ? (e.detail.includes("OK") ? "OK" : e.detail) : e.detail);
  const stepOrder = [...s.stages].sort((a, b) => (a.started_at < b.started_at ? -1 : 1));
  const stages = stepOrder.map((e) => `<tr><td>${esc(STEP_NAME[e.name] || e.name)}${e.attempt > 1 ? ` <small class="subtle">(essai ${e.attempt})</small>` : ""}</td>
    <td class="nowrap ${e.status ==="completed" ? "ok" : e.status === "running" ? "info" : "bad"}">${esc(STEP_STATE[e.status] || e.status)}</td>
    <td class="nowrap">${stepDuration(e)}</td><td>${esc(STEP_DETAIL(e)).slice(0, 140)}</td></tr>`).join("");
  const hour = (iso) => { try { return new Date(iso).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit", second: "2-digit" }); } catch { return iso; } };
  const log = s.events.map((e) => `<li><span class="hour">${esc(hour(e.at))}</span>${esc(plaintext(e.message.replace(/^Statut : (\w+)/, (m, x) => "Statut : " + (LABELS[x] || x))))}</li>`).join("");
  // Refreshing the same task: the page keeps its height and its separately loaded parts (live view, screenshots,
  // expanded files) while they reload, otherwise the phone scrolls back up on its own.
  const dEl = $("#detail"), sameTask = dEl.dataset.tid === t.id;
  const oldDirectElement = sameTask ? $("#direct-task") : null;
  const oldDirect = oldDirectElement ? oldDirectElement.innerHTML : "";
  const oldStepText = sameTask ? $("#stage-text")?.textContent : "";
  const oldCaptures = sameTask && $("#captures-task") ? $("#captures-task").innerHTML : "";
  const openItems = sameTask ? [...$$("#detail details[open]")].map((x) => x.querySelector("summary") && x.querySelector("summary").textContent) : [];
  if (sameTask) { dEl.style.minHeight = dEl.offsetHeight + "px"; clearTimeout(dEl._free); dEl._free = setTimeout(() => (dEl.style.minHeight = ""), 3000); }
  else dEl.style.minHeight = "";
  dEl.dataset.tid = t.id;
  const summary = report ? `<section class="report"><p class="title">Résumé</p>${md(report.replace(/^\s*[*_]*En bref[*_]*\s*:?[*_]*\s*/i, ""))}</section>`
    : res.text ? md(res.text) : "";
  const previousAttempt = Number(/tentative finale \((\d+)\)/.exec(reportKey || "")?.[1] || /tentative\(s\) : (\d+)/.exec(res.text || "")?.[1]) || 1;
  const stepLine = `<p class="stage-running"><span class="point working"></span><span id="stage-text">${esc(oldStepText || (activeStep ? STEP_NAME[activeStep.name] || activeStep.name : LABELS[t.status]))}</span> — ${activeStep ? timer(activeStep.started_at) : elapsed}<span class="stage-buttons"><button class="btn small" id="stop">Stop</button><button class="btn subtle danger small" id="ann">Annuler</button></span></p>`;
  const journalBlock = `<section class="direct-task" id="direct-task"${oldDirect ? "" : " hidden"}>${oldDirect}</section>`;
  $("#detail").innerHTML = `<div class="header-task"><span class="state ${state_color(t.status)}">${taskLabel(t)}</span>
      <div class="title-task"><h2 title="${esc(request)}">${esc(shortTitle)}</h2>${BTN_FOLDER}</div>${request.trim() !== shortTitle ? `<details class="fold request-complete"><summary>Demande complète</summary><p>${esc(request)}</p></details>` : ""}
      ${s.execution?.family || s.execution?.connection ? `<small>IA lancée : ${esc(s.execution.family || s.execution.connection)} · modèle : ${esc(s.execution.exact_model || s.execution.model || "non communiqué par l’outil")}</small>` : ""}
      ${actor ? `<small>${actor}${t.options && t.options.model && !eq.producer.model ? " · modèle demandé " + esc(t.options.model) : ""}${t.options && t.options.effort ? " · effort " + esc(EFFORT_LABELS[t.options.effort] || t.options.effort) : ""}</small>` : ""}${elapsed}</div>
    ${taskStepper(t, s)}
    ${s.awaiting_decision ? decision : ""}
    ${s.simulation ? "<div class=\"alert\">Simulation : aucun modèle n'a été appelé. Ce résultat montre le parcours, pas une capacité réelle.</div>" : ""}
    ${s.memory && s.memory !== "OK" ? `<div class="alert">Mémoire partagée : ${esc(s.memory)}</div>` : ""}
    ${(s.sentinels || []).length ? `<div class="alert">⚠ Fichiers sensibles du studio changés pendant la tâche (rien n'a été annulé) : ${esc(s.sentinels.slice(0, 5).join(", "))}${s.sentinels.length > 5 ? " …" : ""}</div>` : ""}
    ${isolationLine(s.isolation)}
    ${branchActions(s, t)}
    ${["blocked", "interrupted", "failed"].includes(t.status) && t.summary ? `<div class="alert">${esc(t.summary)}</div>` : ""}
    ${taskResultLayout(active, stepLine, summary, journalBlock, previousAttempt, verdict)}
    ${!active && !summary ? `<p class="empty">${inProgress ? "En attente de reprise." : "Pas de résultat."}</p>` : ""}
    ${auditButton(t)}
    ${chainBlock(s.chain)}
    ${usageBlock(s.usage)}
    <div id="captures-task">${oldCaptures}</div>
    ${!active && defects.length ? `<details class="fold defects-fold"><summary>Défauts de la dernière relecture (${defects.length})${triageLabel(s.audit)}</summary><ul>${defects.map((issue) => `<li>${esc(issue).slice(0, 1600)}</li>`).join("")}</ul></details>` : ""}
    ${!active && assessment.validationDefects.length ? `<details class="fold defects-fold"><summary>Défauts de vérification ou du livrable (${assessment.validationDefects.length})</summary><ul>${assessment.validationDefects.map((issue) => `<li>${esc(issue).slice(0, 400)}</li>`).join("")}</ul></details>` : ""}
    ${renderDiff(dif.text, ["awaiting_approval", "awaiting_approval_with_defects"].includes(t.status))}
    <div id="cancel-app"></div>
    ${!active && !s.awaiting_decision ? decision : ""}`;
  if (openItems.length) $$("#detail details").forEach((x) => { const su = x.querySelector("summary"); if (su && openItems.includes(su.textContent)) x.open = true; });
  if (oldDirectElement) $("#direct-task").replaceWith(oldDirectElement);
  taskActivity(t.id, ACTIVE_STATUSES.includes(t.status));
  if (["applied", "approved"].includes(t.status)) api(`/api/tasks/${t.id}/cancellable`).then((a) => {
    const el = $("#cancel-app");
    if (!el || !a.possible || selection !== t.id) return;
    el.innerHTML = `<div class="cancel-app"><button class="btn subtle danger" id="undo">Annuler ce qui a été appliqué</button><small class="subtle">${esc(a.text)}</small></div>`;
    $("#undo").onclick = async (ev) => {
      if (!confirm(`Annuler ce que cette tâche a appliqué à ton projet ?\n\n${a.text}`)) return;
      ev.currentTarget.disabled = true;
      try { const r = await api(`/api/tasks/${t.id}/undo`, {}); infoBubble(r.message); lastView = ""; show(); }
      catch (e) { alert(e.message); ev.currentTarget.disabled = false; }
    };
  }).catch(() => {});
  api(`/api/tasks/${t.id}/captures`).then((l) => {
    const el = $("#captures-task");
    if (!el || !l.length) return;
    el.innerHTML = `<details class="fold captures"${l.length <= 6 ? " open" : ""}><summary>Captures (${l.length})</summary><div class="grid-captures">${l.map((n) => `<a href="/api/tasks/${esc(t.id)}/captures/${encodeURIComponent(n)}" target="_blank" rel="noopener" title="${esc(n)} — ouvrir en grand"><img src="/api/tasks/${esc(t.id)}/captures/${encodeURIComponent(n)}" alt="${esc(n)}" loading="lazy"><small>${esc(n)}</small></a>`).join("")}</div></details>`;
  }).catch(() => {});
  const act = (sel, fn) => { const b = $(sel); if (b) b.onclick = fn; };
  const after = () => setTimeout(() => { lastView = ""; openProject(currentProject); updateBadge(); }, 400);
  act("#ok", () => api(`/api/tasks/${selection}/decision`, { decision: "approve", fingerprint: s.fingerprint }).then(after));
  act("#corr", () => requestCorrection(selection).then((sent) => { if (sent) after(); }).catch((error) => infoBubble(error.message)));
  act("#ann", () => confirm("Annuler cette tâche ?") && api(`/api/tasks/${selection}/cancel`, {}).then(after));
  act("#rep", () => { $("#rep").disabled = true; $("#rep").textContent = "Reprise…";
    api(`/api/tasks/${selection}/resume`, {}).then(() => setTimeout(async () => {
      const x = await api(`/api/tasks/${selection}`).catch(() => null);
      if (x && x.task.status === "blocked") infoBubble("Toujours bloquée : " + (x.task.summary || "").split("\n")[0].slice(0, 120));
      after();
    }, 1500)).catch((e) => { infoBubble(e.message); after(); }); });
  act("#stop", () => { $("#stop").disabled = true; $("#stop").textContent = "Arrêt…"; api(`/api/tasks/${selection}/stop`, {}).then(after).catch((e) => alert(e.message)); });
  act("#folder", () => openPath(t.id));
  const mergeTask = async (choice) => {
    $("#f-msg").textContent = "Fusion…";
    try { const r = await api(`/api/tasks/${selection}/merge`, choice ? { report_choice: choice } : {}); $("#f-msg").textContent = r.message; lastView = ""; setTimeout(show, 600); }
    catch (e) {
      $("#f-msg").textContent = e.message;
      if (e.code === 409 && /^Conflit sur /.test(e.message)) {     // reports only: keep one version, never deleted silently
        $("#f-msg").insertAdjacentHTML("beforeend", ` <button class="btn small" id="keep-task">Garder la version de la tâche</button>
          <button class="btn subtle small" id="keep-project">Garder la version du projet</button>`);
        $("#keep-task").onclick = () => mergeTask("task");
        $("#keep-project").onclick = () => mergeTask("project");
      }
    }
  };
  act("#merge", () => mergeTask(""));
  act("#compile-t", () => compileProject(t.target, "#f-msg"));
  act("#commit-d", () => chooseBlock("branches"));
  act("#apply-audit", () => confirm("Appliquer les corrections de cet audit ? Rien n'est supprimé : ce qui part va en archive, dans la copie du projet.")
    && launchAudit({ target: t.target, what: $("#apply-audit").dataset.what, mode: "apply", since: t.id }));

}

/* Finished audit (report): button to apply its fixes in a new task */
function auditButton(t) {
  const m = /^(?:\$|\[)audit-(skills|memories) audit/.exec(t.request || "");     // « [audit-skills audit] » (older: « $audit-skills audit »)
  if (!m || !["approved", "applied"].includes(t.status)) return "";
  const what = m[1] === "skills" ? "skills" : "memories";
  return `<div class="actions-branch"><button class="btn main" id="apply-audit" data-what="${what}">Appliquer les corrections</button>
    <span class="subtle">${what === "skills" ? "Corrections sûres dans le projet ; les skills globaux restent listés pour toi." : "Dans la copie du projet ; rien n'est supprimé (archives)."}</span></div>`;
}

/* Merge and build (tasks done in a branch, projects with a « build » command) */
function branchActions(s, t) {
  if (!s.worktree || s.nothing_to_apply || !["approved", "applied"].includes(t.status)) return "";
  const f = s.merge;
  const dirty = !f && s.repository_modified;                // merge impossible while tracked files are modified
  const merge = f ? `<span class="ok">✔ Fusionnée dans ${esc(f.branch)} (${esc(f.commit)})</span>`
    : dirty ? `<button class="btn main" id="commit-d" title="Ouvre l'onglet Branches : coche les fichiers, clique Commit, puis reviens fusionner">Commit d'abord (${s.repository_modified} fichier${s.repository_modified > 1 ? "s" : ""})</button><button class="btn" id="merge" disabled title="Possible après le commit">Fusionner dans ${esc(s.branch_start || "la branche de départ")}</button>`
    : `<button class="btn main" id="merge">Fusionner dans ${esc(s.branch_start || "la branche de départ")}</button>`;
  const comp = s.buildable ? `<button class="btn" id="compile-t">Compiler</button>` : "";
  return `<div class="actions-branch">${merge}${comp}<span id="f-msg" class="subtle">${f ? "Rien n'est poussé vers GitHub." : "Fusion locale, rien n'est poussé vers GitHub."}</span></div>`;
}
async function gitLine(key) {
  const el = $("#p-git");
  if (!el) return;
  el.innerHTML = "";
  if (!key.startsWith("project:")) return;
  try {
    const d = await api(`/api/git/${encodeURIComponent(key)}`);
    if (currentProject !== key) return;
    el.innerHTML = `${gitSummary(d)} · <button class="link" id="p-branches">${d.branches.length} branche${d.branches.length > 1 ? "s" : ""} →</button>`;
    $("#p-branches").onclick = () => chooseBlock("branches");
    if (!projectGit[key]) { projectGit[key] = true; renderTabsBlock(); }
  } catch { projectGit[key] = false; if (currentBlock === "branches") chooseBlock("tasks"); else renderTabsBlock(); }
}
function buildInfo(p) {
  $("#p-build").innerHTML = p.buildable ? `<div class="actions-branch" style="margin:10px 0 0"><button class="btn" id="compile-p">Compiler</button><span id="p-build-msg" class="subtle"></span></div>` : "";
  if (p.buildable) { $("#compile-p").onclick = () => compileProject(p.key, "#p-build-msg"); updateJobs(); }
  gitLine(p.key);
}
async function compileProject(target, sel) {
  try { await api("/api/compile", { target: target }); $(sel).textContent = "Compilation lancée…"; $(sel).dataset.compile = "1"; updateJobs(); }
  catch (e) { $(sel).textContent = e.message; }
}

/* Background jobs (build, tests, install): indicator in the header */
let jobsState = {}, seenJobs = {};
const activeJobs = () => Object.values(jobsState || {}).some((j) => j.state === "running");
async function updateJobs() {
  try { jobsState = await api("/api/jobs"); } catch { return; }
  const entries = Object.entries(jobsState);
  const inProgress = entries.filter(([, j]) => j.state === "running");
  const b = $("#jobs");
  if (inProgress.length) {
    const [, j] = inProgress[0];
    b.hidden = false; b.className = "link";
    b.innerHTML = `⚙ ${esc(j.title)} ${timer(j.begin)}${inProgress.length > 1 ? ` (+${inProgress.length - 1})` : ""}`;
  } else {
    const finished = entries.filter(([k, j]) => j.end && seenJobs[k] !== j.end).sort((a, c) => (a[1].end < c[1].end ? 1 : -1))[0];
    if (finished) {
      const [k, j] = finished; seenJobs[k] = j.end;
      b.hidden = false; b.className = "link " + (j.state === "ok" ? "ok" : "failed");
      b.textContent = `${j.state === "ok" ? "✔" : "✖"} ${j.title} : ${j.state === "ok" ? "réussi" : "échec"} (voir)`;
    }
  }
  const jp = currentProject && jobsState[`compile:${currentProject}`];
  const text = jp && (jp.state === "running" ? `compilation en cours… ${timer(jp.begin)}` : `<span class="${jp.state ==="ok" ? "ok" : "bad"}">${jp.state === "ok" ? "✔ compilé" : "✖ échec de compilation (Gestion › Outils)"}</span> · ${formatDuration(seconds(jp.begin, jp.end))}`);
  if (text) ["#p-build-msg", "#f-msg"].forEach((sel) => { const el = $(sel); if (el && (sel === "#p-build-msg" || el.dataset.compile)) el.innerHTML = text; });
}
$("#jobs").onclick = () => openManagement("tools");
$("#state-memory").onclick = () => openManagement("tools");

/* Limit gauges (header): one ring per tool, % of the 5 h window (same numbers as /usage). Blue, yellow, red;
   it pulses when the limit will be hit before the reset at the current pace. A click opens Gestion › Usage. */
async function updateAlerts() {
  let l, a = [];
  try { [l, a] = await Promise.all([api("/api/limits"), api("/api/alerts").catch(() => [])]); } catch { return; }
  const h = (t) => new Date(t * 1000).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" });
  const when = (t) => (t - Date.now() / 1000 > 86400 ? new Date(t * 1000).toLocaleDateString("fr-FR", { weekday: "long" }) + " " : "") + h(t);
  const gauges = ["Claude", "Codex"].filter((o) => l[o] && l[o].ok && (l[o].windows || []).length).map((o) => {
    const fs = l[o].windows, f = fs.find((x) => x.name === "5 h") || fs[0], pct = Math.round(f.pct || 0);
    const al = a.find((x) => x.tool === o);
    const hue = al || pct >= 85 ? "rouge" : pct >= 60 ? "jaune" : "bleu";
    const R = 9, C = 2 * Math.PI * R;
    const title = fs.map((x) => `${x.name} : ${Math.round(x.pct)} %${x.reset ? " · remise à zéro " + when(x.reset) : ""}`).join("\n")
      + (al ? `\n${al.minutes === 0 ? "Limite atteinte" : `Au rythme actuel : limite dans ~${minutes(al.minutes * 60)}`}` : "");
    return `<button class="gauge ${hue}${al ?" alarming" : ""}" data-gauge="1" title="${esc(o)}\n${esc(title)}" aria-label="${esc(o)} : ${pct} % de la limite de 5 h">
      <svg width="22" height="22" viewBox="0 0 22 22" aria-hidden="true"><circle cx="11" cy="11" r="${R}" class="background"/><circle cx="11" cy="11" r="${R}" class="full" stroke-dasharray="${(C * Math.min(pct, 100) / 100).toFixed(1)} ${C.toFixed(1)}" transform="rotate(-90 11 11)"/></svg>
      <span>${esc(o)} ${pct} %${al ? ` · ${al.minutes === 0 ? "atteinte" : "~" + minutes(al.minutes * 60)}` : ""}</span></button>`;
  });
  $("#alerts").hidden = !gauges.length;
  $("#alerts").innerHTML = gauges.join("");
}
$("#alerts").onclick = (e) => { if (e.target.closest("[data-gauge]")) openManagement("usage"); };

/* ================================================================ MANAGEMENT */
/* Gestion: a dashboard. Each internal setting has its block, everything is visible and editable in place. */
const BLOCKS_G = { team: "agents", tools: "tools", usage: "usage", memory: "memory", maintenance: "maintenance", skills: "docs", documents: "docs", audits: "audits", };
let managementTab = "team";
try { managementTab = storedValue("tab-management") || "team"; } catch (e) { /* storage unavailable */ }
function chooseManagementTab(og) {
  if (!$(`#view-management .panel-g[data-og="${og}"]`)) og = "team";      // tab gone (e.g. « Modèles et benchmarks »): the first one
  managementTab = og;
  if (view === "management") loadManagementTab(og);
  try { localStorage.setItem("tab-management", og); } catch (e) { /* same */ }
  $$("#view-management .tabs-g [data-og]").forEach((b) => b.setAttribute("aria-selected", String(b.dataset.og === og)));
  $$("#view-management .panel-g").forEach((x) => (x.hidden = x.dataset.og !== og));
}
$$("#view-management .tabs-g [data-og]").forEach((b) => (b.onclick = () => chooseManagementTab(b.dataset.og)));
chooseManagementTab(managementTab);
const GB = (id, html) => { const el = $(`#g-${id}`); if (el) el.innerHTML = html; };
/* Gestion: only the displayed tab loads (the other on first click), then on every return to the page. */
const TAB_BLOCKS_G = { team: { team: gTeam, bench: gBench, usage: gUsage, settings: gSettings, tools: gTools, maintenance: gMaintenance },
  know: { memory: gMemory, docs: gDocs, audits: gAudits } };
let loadedTabs = new Set();
async function loadManagementTab(og) {
  if (loadedTabs.has(og)) return;
  loadedTabs.add(og);
  if (og === "team") homeLimits();
  await Promise.all(Object.entries(TAB_BLOCKS_G[og] || {}).map(([k, f]) => f().catch((e) => GB(k, `<div class="alert">${esc(e.message)}</div>`))));
  if (og === "team") setTimeout(adjustUsage, 300);
}
async function showManagement() {
  loadedTabs = new Set();
  await loadManagementTab(managementTab);
}
function openManagement(section) {
  showView("management");
  const z = $(`#area-${BLOCKS_G[section] || section}`);
  if (z && z.closest(".panel-g")) chooseManagementTab(z.closest(".panel-g").dataset.og);
  if (z) { z.scrollIntoView({ behavior: matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth", block: "start" }); z.classList.add("repere"); setTimeout(() => z.classList.remove("repere"), 1600); }
}

/* --- Agents: model and effort of each role, at a glance */
/* Each agent's AI: any connected AI; models and efforts offered according to THAT AI (its own names). */
let AI_EFFORTS = {}, AI_ROLES = {}, AI_INFO = { connections: [] };
const shortAiName = (n) => String(n || "").split(" (")[0];
const effortsFor = (family) => [["", "Auto"], ...(AI_EFFORTS[family] || [])];
const modelsFor = (eff) => eff && eff.tool === "claude-code" ? MODELS
  : [["", `Auto${eff && eff.tool === "api" && eff.name.includes(" · ") ? " · " + eff.name.split(" · ").slice(1).join(" · ") : ""}`]];
const defaultAi = () => AI_ROLES.producer || Object.values(AI_ROLES)[0] || { tool: "claude-code", family: "claude-code", name: "" };
async function loadAiRoles(o) {
  try { o = o || await api("/api/organization"); AI_ROLES = Object.fromEntries(o.team.map((r) => [r.id, r.effective_ai])); } catch { /* later */ }
}
async function gTeam() {
  const o = await api("/api/organization");
  await preloadRoleModels(o.team);
  loadAiRoles(o);
  const opt = (items, selected) => items.map(([value, label]) => `<option value="${esc(value)}"${value === selected ? " selected" : ""}>${esc(label)}</option>`).join("");
  const rank = { working: 0, awaiting_user: 1, free: 2 };
  const tiles = o.team.map((r) => ({ r, state: r.tasks.some((task) => ACTIVE_STATUSES.includes(task.status)) ? "working" : r.tasks.length ? "awaiting_user" : "free" }))
    .sort((a, b) => rank[a.state] - rank[b.state] || a.r.name.localeCompare(b.r.name)).map(({ r, state }) =>
    `<div class="agent-g${r.ai || r.model || r.effort ?" regle" : ""}" data-edit-role="${esc(r.id)}" data-team-scope="common" tabindex="0" role="button" aria-haspopup="dialog" aria-label="Régler ${esc(r.name)}">
      <div class="header-g"><span class="point ${state}" title="${ROLE_STATES[state]}"></span><span class="name"><b>${esc(r.name)}</b><small>${esc(r.effective_ai.name || r.tool)} · ${esc(r.model_label)} · ${ROLE_STATES[state]}</small></span></div>
      <div class="settings-g"><select data-common-role="${esc(r.id)}" data-field="ai" aria-label="IA de ${esc(r.name)}">${opt(roleOptions(r, "ai"), r.ai)}</select>
      <select data-common-role="${esc(r.id)}" data-field="model" data-connection="${esc(r.connection)}" aria-label="Modèle de ${esc(r.name)}">${opt(roleOptions(r, "model"), r.model || "")}</select>
      <select data-common-role="${esc(r.id)}" data-field="effort" aria-label="Effort de ${esc(r.name)}">${opt(roleOptions(r, "effort"), r.effort || "")}</select>
      <button class="btn subtle small" data-common-instructions="${esc(r.id)}">Consignes${r.instructions ? " ●" : ""}</button></div></div>`).join("");
  GB("team", `<div class="agents-g">${tiles}</div><details class="fold" id="fold-matrix"><summary>Agents par projet</summary><div id="g-matrix"><p class="empty">…</p></div></details>`);
  $("#fold-matrix").addEventListener("toggle", () => { if ($("#fold-matrix").open) teamMatrix(); });
  $("#help-team").textContent = "Les réglages communs servent de base aux projets. Clique sur une carte pour régler son activation, son IA, son modèle, son effort et ses consignes.";
  $$("#g-team [data-common-role]").forEach((input) => {
    input.onchange = () => saveRoleSettings(input.dataset.commonRole, { [input.dataset.field]: input.value, ...(["ai", "model"].includes(input.dataset.field) ? { effort: "auto" } : {}) }).then(() => refreshTeam()).catch((error) => alert(error.message));
    if (input.dataset.connection) loadRoleModels(input, input.dataset.connection);
  });
  for (const card of $$("#g-team [data-edit-role]")) {
    const role = o.team.find((r) => r.id === card.dataset.editRole);
    bindRoleEffort(card.querySelector('[data-field="model"]'), card.querySelector('[data-field="effort"]'), role);
  }
  $$("#g-team [data-common-instructions]").forEach((button) => (button.onclick = () => openRoleEditor(button.dataset.commonInstructions)));
}

/* --- Tools and updates */
const INSTALLATIONS = {
  read: { label: "Lecture des PDF et images (~140 Mo)", question: "Installer PyMuPDF et Pillow (~140 Mo) dans l'environnement du studio ?" },
  speech: { label: "Lecture des sons et vidéos (~550 Mo + modèle ~480 Mo)", question: "Installer faster-whisper et PyAV (~550 Mo) ? Le modèle de parole (~480 Mo) se téléchargera à la première pièce sonore." },
  retro: { label: "Outils de rétro-ingénierie (~25 Mo)", question: "Installer pefile, capstone, lief et kaitaistruct (~25 Mo) dans l'environnement du studio ? Ils servent au Rétro-ingénieur (lecture de binaires et de formats)." },
};
const HEALTH_NAMES = { memory: "mémoire", attachments_attached: "pièces jointes" };   // libellés affichés
async function gTools() {
  const e = await api("/api/state");
  const pt = (v) => v.state === "OK" ? "free" : v.state === "MANUEL" || v.state === "PARTIEL" ? "awaiting_user" : "paused";
  GB("tools", `<p class="sub-title-g">Studio</p><div class="setting"><span id="o-studio">Version…</span><button class="btn subtle" id="o-update">Rechercher une mise à jour</button></div>
    <p class="sub-title-g">Versions</p><div id="o-versions"><p class="empty">Vérification des versions…</p></div>
    <p class="sub-title-g">Connexions</p>
    <div class="states-g">${Object.entries(e).map(([k, v]) => `<span class="state-g" title="${esc(v.state)} — ${esc(v.detail)}"><span class="point ${pt(v)}"></span>${esc(HEALTH_NAMES[k] || k)}</span>`).join("")}</div>
    <p class="subtle management-help" style="margin-top:8px">Survole une pastille pour le détail.</p>`);
  toolVersions();
  const studioVersion = (m) => { const x = $("#o-studio"); if (x && m) x.textContent = `Version ${m.current}` + (m.available ? ` · ${m.available.version} disponible` : m.installed ? ` · ${m.installed} installée (redémarrer)` : m.repository ? " · à jour" : "") + (m.error ? ` · ${m.error}` : ""); };
  updateVersion().then(studioVersion);
  $("#o-update").onclick = async () => { $("#o-update").disabled = true; try { await api("/api/update/verify", {}); hiddenUpdate = ""; studioVersion(await updateVersion()); } catch (x) { alert(x.message); } $("#o-update").disabled = false; };
}

async function teamMatrix() {
  const el = $("#g-matrix");
  if (!el) return;
  const m = await api("/api/teams").catch(() => null);
  if (!m) { el.innerHTML = '<p class="warn">Indisponible.</p>'; return; }
  const cell = (p, r) => { const x = p.roles[r.id];
    if (!x) return '<td class="subtle">·</td>';
    const k = x.state === "working" ? "working" : !x.active ? "off" : x.custom ? "custom" : "on";
    const t = { working: "▶", off: "—", custom: "◆", on: "●" }[k];
    return `<td class="c ${k}" data-grid-p="${esc(p.key)}" title="${esc(p.name)} · ${esc(r.name)}${x.state ? " · " + (ROLE_STATES[x.state] || x.state) : ""}${x.custom ? " · réglé pour ce projet" : ""}${x.clean ? " · propre au projet" : ""}">${t}</td>`; };
  el.innerHTML = `<p class="management-help subtle">● actif · ◆ réglé pour ce projet · ▶ au travail · — pas utilisé. Clique une case pour régler l'équipe du projet, ou un mode pour le changer.</p>
    <div class="matrix-scroll"><table class="matrix"><thead><tr><th>Métier</th>${m.projects.map((p) => `<th>${esc(p.name.slice(0, 18))}</th>`).join("")}</tr></thead>
    <tbody><tr class="row-mode"><td>Mode</td>${m.projects.map((p) => `<td class="c" data-mode-p="${esc(p.key)}" title="Se règle dans Projets › ${esc(p.name)} › Réglages"><span class="mode-p ${esc(p.profile)}">${esc((PROFILES.find(([v]) => v === p.profile) || ["", "Normal"])[1])}</span></td>`).join("")}</tr>
    ${m.roles.map((r) => `<tr><td>${esc(r.name)}</td>${m.projects.map((p) => cell(p, r)).join("")}</tr>`).join("")}</tbody></table></div>`;
  $$("#g-matrix [data-mode-p]").forEach((c) => (c.onclick = () => { currentProject = c.dataset.modeP; currentBlock = "project"; showView("projects"); setTimeout(() => chooseBlock("project"), 500); }));
  $$("#g-matrix [data-grid-p]").forEach((c) => (c.onclick = () => { currentProject = c.dataset.gridP; currentBlock = "team"; showView("projects"); setTimeout(() => chooseBlock("team"), 500); }));
}

/* --- Maintenance (Réglages column): studio tests, optional features, background jobs */
async function gMaintenance() {
  const [inst, tr] = await Promise.all([api("/api/tools/installed"), api("/api/jobs")]);
  const leftover = Object.keys(INSTALLATIONS).filter((q) => !inst[q]);       // a completed install is no longer offered
  const inProgress = (q) => (tr[`install:${q}`] || {}).state === "running";
  const jobs = Object.values(tr).sort((a, b) => (a.begin < b.begin ? 1 : -1));
  const cleanup = await api("/api/cleanup").catch(() => ({}));
  const mo = (o) => `${Math.round((o || 0) / 2 ** 20)} Mo`;
  GB("maintenance", `<div class="cleanup-g"><b>Ménage automatique</b> <span class="${cleanup.active ?"ok" : "warn"}">${cleanup.active ? "activé" : "coupé"}</span>
      <p class="subtle management-help">Au fil de l'eau : à la fin de chaque tâche, sa copie de travail part ; après la sauvegarde du jour, les anciennes (7 jours + 4 semaines gardés) ; après une mise à jour, les vieilles versions (3 gardées). Jamais tes projets, sujets, résultats, skills ni mémoire.${cleanup.day ? ` Dernier rattrapage : ${esc(cleanup.day)} — ${esc(cleanup.text)}` : ""}${cleanup.total && cleanup.total.bytes ? ` Depuis le début : ${mo(cleanup.total.bytes)} libérés.` : ""}</p>
      <button class="btn" id="o-cleanup">Faire le ménage maintenant</button></div>
    <div class="actions column" style="margin:10px 0 0"><button class="btn" id="o-tests">Lancer les tests du studio</button></div>
    ${leftover.length ? `<p class="sub-title-g">Fonctions en option</p><div class="actions column" style="margin:0">${leftover.map((q) => inProgress(q) ? `<button class="btn" disabled>Installation en cours…</button>` : `<button class="btn" data-install="${q}">Installer : ${INSTALLATIONS[q].label}</button>`).join("")}</div>` : ""}
    ${jobs.length ? `<details class="fold" style="margin-top:10px"${jobs.some((j) => j.state === "running") ? " open" : ""}><summary>Travaux depuis l'ouverture (${jobs.length})</summary>${jobs.map((j) => `<details class="fold"><summary>${j.state === "running" ? "⚙" : j.state === "ok" ? "✔" : "✖"} ${esc(j.title)} · ${j.end ? formatDuration(seconds(j.begin, j.end)) : timer(j.begin)}</summary><pre class="output">${esc(j.output || "…")}</pre></details>`).join("")}</details>` : ""}`);
  const launch = async (url, requestBody) => { try { await api(url, requestBody); updateJobs(); setTimeout(gMaintenance, 800); } catch (x) { alert(x.message); } };
  $("#o-tests").onclick = () => launch("/api/tools/tests", {});
  $("#o-cleanup").onclick = async (ev) => { ev.currentTarget.disabled = true; try { const r = await api("/api/cleanup", {}); infoBubble(r.text); } catch (x) { infoBubble(x.message); } gMaintenance(); };
  $$("#g-maintenance [data-install]").forEach((b) => (b.onclick = () => confirm(INSTALLATIONS[b.dataset.install].question) && launch("/api/tools/install", { what: b.dataset.install })));
  if (jobs.some((j) => j.state === "running")) setTimeout(() => { if (view === "management") gMaintenance(); }, 4000);
}

/* --- Audits of agent skills and memories (global skills audit-skills / audit-memories, run by a connected AI) */
async function gAudits() {
  const aud = await api("/api/audits").catch(() => []);
  GB("audits", auditsBlock(aud));
  const selA = $("#a-target");
  if (selA) {
    try { const m = storedValue("audit-target"); if (m && aud.some((p) => p.target === m)) selA.value = m; } catch (e) { /* storage unavailable */ }
    const updateAudit = () => { const p = aud.find((x) => x.target === selA.value) || {}; $$("#g-audits [data-audit]").forEach((b) => { const d = p[`${b.dataset.audit}_audit`]; b.nextElementSibling.textContent = d ? `dernier : ${timeAgo(d.date)}${ACTIVE_STATUSES.includes(d.status) ? " (en cours)" : ""}` : "jamais lancé"; }); };
    selA.onchange = () => { try { localStorage.setItem("audit-target", selA.value); } catch (e) { /* same */ } updateAudit(); };
    updateAudit();
    $$("#g-audits [data-audit]").forEach((b) => (b.onclick = () => launchAudit({ target: selA.value, what: b.dataset.audit, mode: "audit" })));
  }
}

function auditsBlock(aud) {
  if (!aud.length) return "<p class=\"empty\">Aucun projet avec un dossier.</p>";
  return `<p class="explanation-g">Relit les skills ou les fichiers d'instructions des agents (règles, instructions, plans) et dit ce qui est faux, en double ou chargé pour rien. Choisis un projet ou le studio lui-même (ses skills et ses règles communes). Rapport d'abord ; « Appliquer » ensuite, depuis le rapport.</p>
    <select id="a-target" class="field" style="width:100%;margin-bottom:6px">${aud.map((p) => `<option value="${esc(p.target)}">${esc(p.name)}</option>`).join("")}</select>
    <div class="audits-g">
      <button class="btn" data-audit="skills" title="Quels skills servent, lesquels se chevauchent ou chargent du texte pour rien">Auditer les skills</button><small class="subtle"></small>
      <button class="btn" data-audit="memories" title="CLAUDE.md, règles, plans : ce qui est faux, en double ou périmé">Auditer les mémoires</button><small class="subtle"></small>
    </div>`;
}
function timeAgo(d) {
  const j = Math.floor((Date.now() - new Date(d.replace(" ", "T") + (/[zZ+]/.test(d.slice(10)) ? "" : "Z")).getTime()) / 864e5);
  return j <= 0 ? "aujourd'hui" : j === 1 ? "hier" : `il y a ${j} jours`;
}
async function launchAudit(requestBody) {
  try { const r = await api("/api/audits", requestBody); selection = r.tid; lastView = ""; currentProject = requestBody.target; showView("projects"); }
  catch (e) { alert(e.message); }
}

/* --- Studio settings: closed list, saved in studio.config.toml (a copy of the previous one is kept) */
let settingMsg = { t: "↻ = pris en compte au prochain démarrage du studio.", c: "discret" };
/* --- Updates: banner when a version is installed (restart) or available (install) */
let hiddenUpdate = "";
async function updateVersion() {
  let e;
  try { e = await api("/api/update"); } catch { return; }
  const b = $("#banner-update");
  const key = e.installed || (e.available && e.available.version) || "";
  if (!key || key === hiddenUpdate || sessionInfo.distant) { b.hidden = true; return e; }
  if (e.installed) {
    $("#update-text").textContent = `Mise à jour ${e.installed} installée.`;
    $("#update-action").textContent = "Redémarrer le studio";
    $("#update-action").onclick = async () => {
      try { await api("/api/update/redemarrer", {}); document.body.innerHTML = "<div class=\"closed\"><h1>Mise à jour</h1><p class=\"empty\">Le studio redémarre…</p></div>"; }
      catch (x) { alert(x.message); }
    };
  } else {
    const signed = e.available.signature === "valid";
    $("#update-text").textContent = `Nouvelle version ${e.available.version} disponible${signed ? " (signée)" : e.available.signature === "invalid" ? " — SIGNATURE INVALIDE, ne l'installe pas" : e.available.signature === "no_key" ? "" : " (non signée)"}${e.available.notes ? " : " + e.available.notes.split("\n")[0].slice(0, 120) : ""}`;
    $("#update-action").textContent = "Installer";
    $("#update-action").onclick = async () => {
      $("#update-action").disabled = true; $("#update-action").textContent = "Installation…";
      try { await api("/api/update/install", {}); }
      catch (x) {
        if (x.data && x.data.unsigned && confirm(`${x.message}\n\nLa signature prouve que la mise à jour vient bien de son auteur. Installer quand même ?`)) {
          try { await api("/api/update/install", { unsigned_ok: true }); } catch (y) { alert(y.message); }
        } else if (!(x.data && x.data.unsigned)) alert(x.message);
      }
      $("#update-action").disabled = false; updateVersion();
    };
  }
  $("#update-close").onclick = () => { hiddenUpdate = key; b.hidden = true; };
  b.hidden = false;
  return e;
}
setTimeout(updateVersion, 4000);
setInterval(updateVersion, 30 * 60 * 1000);

/* --- Connectors: PC software added by the user (empty by default) */
/* --- Create an agent: domain → suggested role → settings and recommended model → creation */
let agentCatalog = null;
const CATEGORY_NAMES = { text: "texte", code: "code", image: "images", video: "vidéo", voice: "voix" };
function closeAgentAssistant() { $("#assistant-agent").hidden = true; }
$("#aa-close").onclick = () => { projectAgent = ""; closeAgentAssistant(); };
$("#assistant-agent").onclick = (e) => { if (e.target.id === "assistant-agent") closeAgentAssistant(); };
document.addEventListener("keydown", (e) => { if (e.key === "Escape" && !$("#assistant-agent").hidden) closeAgentAssistant(); });
$("#optimize-agents").onclick = () => optimizeAgents("");
$("#create-agent").onclick = async () => {
  $("#assistant-agent").hidden = false;
  $("#aa-body").innerHTML = "<p class=\"empty\">…</p>";
  try { agentCatalog = await api("/api/agents/catalog"); domainStep(); }
  catch (e) { $("#aa-body").innerHTML = `<p class="warn">${esc(e.message)}</p>`; }
};
function domainStep() {
  $("#aa-title").textContent = "Créer un agent · 1/3 · ton domaine";
  $("#aa-body").innerHTML = `<div class="domain-grid">${agentCatalog.domains.map((d) => `<button data-dom="${esc(d.id)}"><b>${esc(d.name)}</b><br><small class="subtle">${d.roles.length} rôles proposés</small></button>`).join("")}<button data-dom=""><b>Autre</b><br><small class="subtle">partir de zéro</small></button></div>`;
  $$("[data-dom]").forEach((b) => (b.onclick = () => (b.dataset.dom ? roleStep(b.dataset.dom) : settingsStep(null, ""))));
}
function roleStep(dom) {
  const d = agentCatalog.domains.find((x) => x.id === dom);
  $("#aa-title").textContent = `Créer un agent · 2/3 · ${d.name}`;
  $("#aa-body").innerHTML = `<div class="domain-grid">${d.roles.map((r, i) => `<div class="card-role" role="button" tabindex="0" data-role="${i}"><b>${esc(r.name)}</b><small>${esc(r.mission)}</small><br><small class="subtle">type : ${CATEGORY_NAMES[r.category] || r.category}</small></div>`).join("")}
    <div class="card-role" role="button" tabindex="0" data-role="-1"><b>Partir de zéro</b><small>Un rôle à toi, dans ce domaine.</small></div></div>
    <div class="actions" style="margin-top:12px"><button class="btn subtle" id="aa-return_value">Retour</button></div>`;
  $("#aa-return_value").onclick = domainStep;
  $$("[data-role]").forEach((c) => (c.onclick = c.onkeydown = (e) => { if (e.type === "keydown" && e.key !== "Enter") return; settingsStep(+c.dataset.role >= 0 ? d.roles[+c.dataset.role] : null, dom); }));
}
function settingsStep(r, dom) {
  const cat = (r && r.category) || "text";
  $("#aa-title").textContent = "Créer un agent · 3/3 · réglages";
  const rows = (l) => esc((l || []).join("\n"));
  const sources = agentCatalog.sources;
  const reco = () => agentCatalog.recommendations[$("#aa-cat").value] || {};
  $("#aa-body").innerHTML = `<div class="form-agent">
    <label for="aa-name">Nom</label><input class="field" id="aa-name" maxlength="60" value="${esc(r ? r.name : "")}">
    <label for="aa-mission">Mission (ce qu'il fait)</label><textarea id="aa-mission">${esc(r ? r.mission : "")}</textarea>
    <label for="aa-deliverables">Ce qu'il livre (une ligne par livrable)</label><textarea id="aa-deliverables">${rows(r && r.deliverables)}</textarea>
    <label for="aa-limits">Ce qu'il ne doit jamais faire (une ligne par règle)</label><textarea id="aa-limits">${rows(r && r.limits)}</textarea>
    <label for="aa-cat">Type de travail</label><select id="aa-cat">${Object.entries(CATEGORY_NAMES).map(([k, t]) => `<option value="${k}"${k === cat ? " selected" : ""}>${t}</option>`).join("")}</select>
    <div class="reco" id="aa-reco"></div>
    <label for="aa-source">IA de cet agent</label><select id="aa-source">${sources.length ? sources.map((x) => `<option value="${esc(x.id)}">${esc(x.name)}${x.model ? " · " + esc(x.model_label || x.model) : ""}</option>`).join("") : '<option value="">Aucune IA connectée</option>'}</select>
    <p class="warn management-help" id="aa-msg"></p>
    <div class="actions" style="margin-top:12px;justify-content:space-between"><button class="btn subtle" id="aa-return_value">Retour</button><button class="btn main" id="aa-create">Créer l'agent</button></div></div>`;
  const updateReco = () => {
    const x = reco();
    const m = (o) => o ? `${esc(o.name)} (${esc(o.provider)}${o.score ? ", " + o.score + " " + esc(o.unit) : ""}${o.price ? ", " + o.price + " $" : ""})` : "—";
    $("#aa-reco").innerHTML = `${x.connected ? `<div><b>Recommandé avec tes IA :</b> ${esc(x.connected.name)}${x.connected.recommended_model ? " → " + m(x.connected.recommended_model) : ""}</div>` : "<div><b>Aucune de tes IA ne convient encore.</b></div>"}
      <div><b>Meilleur du marché :</b> ${m(x.works)}</div>${x.remark ? `<div class="subtle" style="margin-top:4px">${esc(x.remark)}</div>` : ""}`;
    if (x.connected && $("#aa-source").querySelector(`option[value="${x.connected.id}"]`)) $("#aa-source").value = x.connected.id;
  };
  $("#aa-cat").onchange = updateReco; updateReco();
  $("#aa-return_value").onclick = () => (dom ? roleStep(dom) : domainStep());
  $("#aa-create").onclick = async () => {
    const entries = (id) => $(id).value.split("\n").map((x) => x.trim()).filter(Boolean);
    try {
      const res = await api("/api/agents/create", { name: $("#aa-name").value, mission: $("#aa-mission").value, deliverables: entries("#aa-deliverables"),
        limits: entries("#aa-limits"), category: $("#aa-cat").value, source: $("#aa-source").value, domain: dom,
        keywords: r ? r.keywords : [], tools: r ? r.tools : undefined, criteria: r ? r.criteria : [], id: r ? r.id : "", project: projectAgent });
      if (projectAgent) { projectAgent = ""; setTimeout(teamSettings, 300); }
      $("#aa-title").textContent = "Agent créé";
      $("#aa-body").innerHTML = `<p class="ok">« ${esc($("#aa-name") ? $("#aa-name").value : "")} » rejoint l'équipe. Le Superviseur peut maintenant lui confier des tâches.</p><div class="actions"><button class="btn main" id="aa-ok">OK</button></div>`;
      $("#aa-ok").onclick = closeAgentAssistant;
      gTeam();
    } catch (e) { $("#aa-msg").textContent = e.message; }
  };
}

/* --- Benchmarks: global ranking then rankings by use (cloud and local mixed), updated daily */
let benchSort = { cat: "global", col: "score", location: "tous" };
let benchTimer = null, benchCache = null;
/* Models and benchmarks: cloud and local in the same table, plus « Installés ». Data loaded once, the
   tabs show immediately (reload only during a download or after an action). */
async function gBench(reload = true) {
  clearTimeout(benchTimer);
  if (reload || !benchCache) {
    const [b, loc, inst, ai] = await Promise.all([api("/api/benchmarks"), api("/api/local-models").catch(() => null), api("/api/local-models/details").catch(() => []),
      api("/api/ai").catch(() => ({ connections: [] }))]);
    benchCache = { b, loc, inst, ai: ai };
  }
  renderBench();
}
function renderBench() {
  const { b, loc, inst, ai: ai } = benchCache;
  const cats = Object.entries(b.categories).filter(([k]) => k !== "local");
  const co = new Set(b.connected);
  const isConnected = (m) => m.local ? co.has("local") : co.has(m.provider) || (m.provider === "openai" && co.has("codex"))
    || (co.has("openrouter") && !DIRECT_CLOUD.includes(m.provider) && CLOUD_TEXT.includes(m.category));
  const installed = benchSort.cat === "installed";
  if (!installed && !cats.some(([k]) => k === benchSort.cat)) benchSort.cat = cats[0][0];
  const inverse = (b.inverses || []).includes(benchSort.cat);              // transcription: error rate, lower = better
  const byScore = (x, y) => x.score == null ? 1 : y.score == null ? -1 : inverse ? x.score - y.score : y.score - x.score;
  const sorter = (l) => [...l].sort((x, y) => benchSort.col === "price" ? (x.local ? 0 : x.price ?? 1e9) - (y.local ? 0 : y.price ?? 1e9) || byScore(x, y)
    : benchSort.col === "speed" ? (y.speed || 0) - (x.speed || 0) || byScore(x, y) : byScore(x, y));
  const allItems = b.models.filter((m) => m.category === benchSort.cat);
  const rows = sorter(allItems.filter((m) => benchSort.location === "tous" || (benchSort.location === "local") === !!m.local));
  const rank = new Map([...allItems].sort(byScore).map((m, i) => [m, m.score == null ? "" : i + 1]));   // ranking position, cloud and local together
  const hasLocal = allItems.some((m) => m.local);
  let hidden = ""; try { hidden = storedValue("local-runner-later") || ""; } catch {}
  let note = "";
  if (loc && (hasLocal || installed)) {
    if (!loc.installed) note = `<div class="note-local-runner">Modèles locaux : installe <a href="${esc(loc.download)}" target="_blank" rel="noopener">Ollama</a> (gratuit) pour les installer en un clic ici.</div>`;
    else if (!co.has("local") && !hidden) note = `<div class="note-local-runner">Connecter Ollama pour que le Superviseur ou les agents utilisent tes modèles locaux ? <button class="btn small main" id="local-runner-connect">Connecter</button><button class="link" id="local-runner-later">Plus tard</button></div>`;
  }
  const access = (m) => m.local ? (loc ? localCell(m, loc) : "—") : isConnected(m) ? `<span class="ok">● connecté${co.has(m.provider) || m.provider === "openai" ? "" : " (OpenRouter)"}</span>`
    : connectable(m) ? `<button class="btn small" data-connect-cloud-account="${esc(m.provider)}" data-model-label="${esc(m.name)}">Connecter</button>` : '<small class="subtle">sur son site</small>';
  const line = (m) => `<tr class="${isConnected(m) ?"connected" : ""}"><td class="rank">${rank.get(m) || "—"}</td><td>${esc(m.name)}<span class="badge-lc ${m.local ?"local" : "cloud"}">${m.local ? "LOCAL" : "CLOUD"}</span></td>
    <td><b>${m.score ?? "—"}</b></td><td class="nowrap">${access(m)}</td><td>${m.local ? '<span class="ok">Gratuit</span>' : m.price != null ? m.price + " $" : "—"}</td>
    <td>${m.speed ? m.speed + " t/s" : m.local ? '<small class="subtle">selon le PC</small>' : "—"}</td><td>${esc(m.provider)}</td><td><small class="subtle">${esc(m.note || "")}</small></td></tr>`;
  const unit = ((allItems[0] || {}).unit || "score").replace(/^./, (c) => c.toUpperCase());
  let requestBody;
  if (installed) {
    // Connected and installed: the real usable models, cloud (subscription or key) and local (Ollama)
    const PROVIDER_NAMES = { anthropic: "Anthropic", openai: "OpenAI", gemini: "Google Gemini", mistral: "Mistral", deepseek: "DeepSeek", openrouter: "OpenRouter", groq: "Groq" };
    const viaKey = (f) => (ai.connections || []).find((c) => c.provider === f);
    const cloudAccess = (m) => m.provider === "anthropic" && co.has("anthropic") && !viaKey("anthropic") ? "Abonnement Claude (Claude Code)"
      : m.provider === "openai" && co.has("codex") && !viaKey("openai") ? "Abonnement ChatGPT (Codex)"
      : viaKey(m.provider) ? `Clé API ${PROVIDER_NAMES[m.provider] || m.provider}` : viaKey("openrouter") ? "Clé API OpenRouter" : "Abonnement";
    const seenItems = new Set();
    const cloud = b.models.filter((m) => m.category === "global" && !m.local && isConnected(m) && !seenItems.has(m.name) && seenItems.add(m.name)).sort(byScore);
    const keys = (ai.connections || []).filter((c) => !["ollama", "lmstudio"].includes(c.provider));
    const scoreLocal = (name) => (b.models.find((m) => m.local && m.category === "global" && (name === (m.ollama || m.key) || name.startsWith((m.ollama || m.key) + ":"))) || {}).score;
    requestBody = `${note}<p class="sub-title-g">Modèles cloud connectés (${cloud.length})</p>${cloud.length ? `<div class="bench-scroll"><table class="table-bench"><thead><tr><th>Modèle</th><th>Indice global</th><th>Accès</th><th>Vitesse</th><th>Prix</th></tr></thead><tbody>${cloud.map((m) =>
        `<tr><td>${esc(m.name)}<span class="badge-lc cloud">CLOUD</span></td><td><b>${m.score ?? "—"}</b></td><td>${esc(cloudAccess(m))}</td><td>${m.speed ? m.speed + " t/s" : "—"}</td><td>${m.price != null ? m.price + " $" : "—"}</td></tr>`).join("")}</tbody></table></div>`
        : '<p class="subtle">Aucun : clique « Connecter » sur un modèle du classement.</p>'}
      ${keys.length ? `<p class="management-help subtle">Clés API enregistrées : ${keys.map((c) => `${esc(PROVIDER_NAMES[c.provider] || c.provider)}${c.model ? ` (${esc(c.model)})` : ""} <button class="link" data-ai-decoration="${esc(c.id)}">déconnecter</button>`).join(" · ")}. Abonnements : ils se gèrent dans Claude Code ou Codex.</p>` : ""}
      <p class="sub-title-g" style="margin-top:14px">Modèles locaux installés (${inst.length})</p>${inst.length ? `<div class="bench-scroll"><table class="table-bench"><thead><tr><th>Modèle</th><th>Indice global</th><th>Taille</th><th>Installé le</th><th></th></tr></thead><tbody>${inst.map((m) =>
        `<tr><td>${esc(m.name)}<span class="badge-lc local">LOCAL</span></td><td><b>${scoreLocal(m.name) ?? "—"}</b></td><td>${m.size_go} Go</td><td>${esc(m.modified)}</td><td class="nowrap"><button class="btn subtle small" data-update-local="${esc(m.name)}">Mettre à jour</button><button class="btn subtle small danger" data-uninstall-local="${esc(m.name)}">Désinstaller</button></td></tr>`).join("")}</tbody></table></div>
      <div class="setting"><small class="subtle">Ollama ne télécharge que ce qui a changé. « — » : modèle absent des classements publics.</small><button class="btn subtle" id="update-local">Tout mettre à jour</button></div>` : '<p class="subtle">Aucun pour l\'instant : choisis-en un dans le classement (lignes LOCAL, bouton Installer).</p>'}`;
  } else {
    const helpText = (b.help_items || {})[benchSort.cat] || "";
    requestBody = `${helpText ? `<p class="help-bench subtle">${esc(helpText)}${hasLocal ? "" : " Aucun modèle local mesuré par cette source."}</p>` : ""}${note}<div class="bench-scroll"><table class="table-bench"><thead><tr><th>#</th><th>Modèle</th><th data-bcol="score" title="${esc((allItems[0] || {}).unit || "")}">${esc(unit)} ${inverse ? "▴" : "▾"}</th><th>Accès</th><th data-bcol="price">Prix</th><th data-bcol="speed">Vitesse</th><th>Fournisseur</th><th>Remarque</th></tr></thead><tbody>
      ${rows.length ? rows.map(line).join("") : '<tr><td colspan="8" class="subtle">Aucun modèle ici.</td></tr>'}</tbody></table></div>`;
  }
  GB("bench", `<div class="bench-modes"><div class="chips small" id="bench-cats">${cats.map(([k, t]) => `<button class="chip${k === benchSort.cat ?" sel" : ""}" data-bcat="${k}">${esc(t)}</button>`).join("")}<button class="chip${installed ?" sel" : ""}" data-bcat="installed">Connectés et installés</button></div>
      ${installed ? "" : `<div class="seg" id="bench-location">${[["tous", "Tous"], ["cloud", "Cloud"], ["local", "Local"]].map(([k, t]) => `<button data-location-block="${k}" class="${benchSort.location === k ?"sel" : ""}">${t}</button>`).join("")}</div>`}</div>
    ${requestBody}
    <p class="management-help subtle" style="margin-top:6px">● = utilisable avec tes IA. Prix cloud : $ par million de jetons d'entrée (images : par image). ${esc(b.note)}<br>Classements du ${esc(b.date)}${b.refreshed ? ` · vérifiés le ${esc(b.refreshed.slice(0, 10))}` : ""} (mise à jour automatique une fois par jour) · ${b.sources.map((x) => `<a href="${esc(x.url)}" target="_blank" rel="noopener">${esc(x.name)}</a>`).join(" · ")}</p>`);
  $$("[data-location-block]").forEach((x) => (x.onclick = () => { benchSort.location = x.dataset.locationBlock; renderBench(); }));
  $$("[data-bcat]").forEach((x) => (x.onclick = () => {
    benchSort.cat = x.dataset.bcat; renderBench();
  }));
  $$("[data-bcol]").forEach((x) => (x.onclick = () => { benchSort.col = x.dataset.bcol; renderBench(); }));
  $$("[data-connect-cloud-account]").forEach((x) => (x.onclick = () => connectCloud(x.dataset.connectCloudAccount, x.dataset.modelLabel)));
  $$("[data-install-model]").forEach((x) => (x.onclick = async () => {
    const name = x.dataset.installModel, m = b.models.find((y) => (y.ollama || y.key) === name);
    if (!confirm(`Installer ${m ? m.name : name} sur ce PC avec Ollama ?\n${m && m.note ? m.note + "\n" : ""}Le téléchargement peut prendre du temps (plusieurs Go).`)) return;
    x.disabled = true;
    try { await api("/api/local-models/install", { name: name }); } catch (e) { alert(e.message); }
    gBench();
  }));
  $$("#g-bench [data-update-local]").forEach((x) => (x.onclick = async () => { x.disabled = true; try { await api("/api/local-models/install", { name: x.dataset.updateLocal }); infoBubble("Mise à jour lancée."); } catch (e) { alert(e.message); } }));
  $$("#g-bench [data-uninstall-local]").forEach((x) => (x.onclick = async () => {
    const name = x.dataset.uninstallLocal;
    if (!confirm(`Désinstaller ${name} ? Le modèle est retiré d'Ollama et libère sa place sur le disque (il se réinstalle en un clic).`)) return;
    x.disabled = true;
    try { infoBubble((await api("/api/local-models/uninstall", { name: name })).message); } catch (e) { alert(e.message); }
    gBench();
  }));
  $$("#g-bench [data-ai-decoration]").forEach((x) => (x.onclick = async () => {
    if (!confirm("Déconnecter cette clé API ? Elle est effacée de ce PC (tu pourras la recoller).")) return;
    try { await api("/api/ai/remove", { id: x.dataset.aiDecoration }); } catch (e) { alert(e.message); }
    gBench();
  }));
  if ($("#update-local")) $("#update-local").onclick = async (ev) => { ev.currentTarget.disabled = true;
    for (const m of inst) { try { await api("/api/local-models/install", { name: m.name }); } catch (e) { alert(`${m.name} : ${e.message}`); } }
    infoBubble("Mise à jour lancée."); };
  if ($("#local-runner-connect")) $("#local-runner-connect").onclick = async (ev) => { ev.currentTarget.disabled = true; try { await api("/api/ai/add", { provider: "ollama" }); infoBubble("Ollama connecté."); } catch (e) { alert(e.message); } gBench(); };
  if ($("#local-runner-later")) $("#local-runner-later").onclick = () => { try { localStorage.setItem("local-runner-later", "1"); } catch {} renderBench(); };
  if (loc && Object.values(loc.models).some((x) => x.progress && x.progress.state === "downloading"))
    benchTimer = setTimeout(() => { if (view === "management") gBench().catch(() => {}); }, 2000);
}
/* Connecting a cloud model from the benchmarks: as simple as installing a local model. Subscription (the subscription
   tools) when available, else the provider's API key; other models go through OpenRouter (one key, all models). */
const DIRECT_CLOUD = ["anthropic", "openai", "gemini", "mistral", "deepseek", "xai", "moonshot"];
const CLOUD_TEXT = ["global", "agents", "code", "web", "reasoning", "knowledge", "conversation", "vision"];
const CLOUD_KEYS = {
  anthropic: ["Anthropic (Claude)", "https://console.anthropic.com/settings/keys"], openai: ["OpenAI", "https://platform.openai.com/api-keys"],
  gemini: ["Google Gemini", "https://aistudio.google.com/apikey"], mistral: ["Mistral", "https://console.mistral.ai/api-keys"],
  deepseek: ["DeepSeek", "https://platform.deepseek.com/api_keys"], openrouter: ["OpenRouter", "https://openrouter.ai/keys"],
  xai: ["xAI (Grok)", "https://console.x.ai"], moonshot: ["Moonshot (Kimi)", "https://platform.moonshot.ai/console/api-keys"],
  groq: ["Groq", "https://console.groq.com/keys"], elevenlabs: ["ElevenLabs (voix)", "https://elevenlabs.io/app/settings/api-keys"],
};
const connectable = (m) => CLOUD_TEXT.includes(m.category) || (m.category === "image" && ["openai", "gemini"].includes(m.provider));
async function connectCloud(provider, modelName, after) {
  const f = CLOUD_KEYS[provider] ? provider : "openrouter";
  const [name, keyLink] = CLOUD_KEYS[f];
  const el = $("#custom-card-body");
  el.innerHTML = "<p class=\"empty\">…</p>"; $("#custom-card").hidden = false;
  let d = {};
  try { d = await api("/api/ai"); } catch (e) { /* no details: key only */ }
  if (d.distant) { el.innerHTML = `<h2>Connecter ${esc(name)}</h2><p class="management-help">La connexion se fait sur le PC (la clé ne passe jamais par le téléphone).</p><div class="bottom"><button class="btn subtle" data-close-card="1">Fermer</button></div>`; return; }
  const subscription = f === "anthropic" ? (d.claude ? `<button class="btn main" id="cc-abo">Se connecter avec mon abonnement Claude</button>`
      : `<p class="management-help">Abonnement Claude (Pro ou Max) : il faut d'abord Claude Code.</p><button class="btn" data-install-tool="claude">Installer Claude Code</button>`)
    : f === "openai" ? (d.codex ? `<button class="btn main" id="cc-abo">Se connecter avec mon abonnement ChatGPT</button>`
      : `<p class="management-help">Abonnement ChatGPT : il faut d'abord Codex.</p><button class="btn" data-install-tool="codex">Installer Codex</button>`) : "";
  el.innerHTML = `<h2>Connecter ${esc(name)}</h2><div class="meta">${modelName ? `pour utiliser ${esc(modelName)}${f === "openrouter" ? " et des centaines d'autres modèles avec une seule clé" : ""}` : f === "openrouter" ? "des centaines de modèles (dont des gratuits) avec une seule clé" : ""}</div>
    ${subscription ? `<p class="sub-title-g">Avec ton abonnement</p>${subscription}<p class="sub-title-g" style="margin-top:16px">Ou avec une clé API (paiement à l'usage)</p>` : `<p class="sub-title-g">Clé API</p>`}
    <p class="management-help">1. <a href="${esc(keyLink)}" target="_blank" rel="noopener">Crée une clé sur le site de ${esc(name)}</a> · 2. colle-la ici. Elle est vérifiée puis chiffrée sur ce PC, jamais affichée.</p>
    <label for="cc-key">Clé API</label><input id="cc-key" type="password" autocomplete="off" spellcheck="false">
    <p class="warn" id="card-msg"></p><div class="bottom"><button class="btn subtle" data-close-card="1">Annuler</button><button class="btn" id="cc-ok">Connecter avec la clé</button></div>`;
  if ($("#cc-abo")) $("#cc-abo").onclick = async (ev) => {
    ev.currentTarget.disabled = true;
    try { const r = await api(f === "anthropic" ? "/api/claude/connection" : "/api/codex/connection", {}); infoBubble(r.info); $("#custom-card").hidden = true; if (after) after(); }
    catch (e) { $("#card-msg").textContent = e.message; ev.currentTarget.disabled = false; }
  };
  $("#cc-ok").onclick = async (ev) => {
    const b = ev.currentTarget; b.disabled = true; b.textContent = "Vérification…";
    try { await api("/api/ai/add", { provider: f, key: $("#cc-key").value }); infoBubble(`${name} connecté.`); $("#custom-card").hidden = true; (after || gBench)(); }
    catch (e) { $("#card-msg").textContent = e.message; b.disabled = false; b.textContent = "Connecter avec la clé"; }
  };
  $("#cc-key").onkeydown = (e) => { if (e.key === "Enter") $("#cc-ok").click(); };
}
function localCell(m, loc) {
  const name = m.ollama || m.key, e = loc.models[name];
  if (!e) return "—";
  const p = e.progress;
  if (p && p.state === "downloading") return `<span class="info" title="${esc(p.message)}">${p.pct} %</span>`;
  if (e.installed) return '<span class="ok">Installé</span>';
  if (p && p.state === "error") return `<span class="bad">Échec</span> <button class="btn subtle small" data-install-model="${esc(name)}">Réessayer</button><small class="error-local">${esc(p.message)}</small>`;
  return loc.installed ? `<button class="btn small" data-install-model="${esc(name)}">Installer</button>` : '<small class="subtle">Ollama requis</small>';
}

/* --- AI: subscription tool, API key or local AI; one for the Supervisor, one for the agents */
let aiState = null, aiMsg = "";
function standard_apiSettings() {
  if (currentProject) openSupervisor();
  if (document.body.dataset.mob) mobileView("work");
  chooseBlock("sup-settings");
  setTimeout(() => $("#g-ai") && $("#g-ai").scrollIntoView({ block: "start" }), 300);
}
async function gAI() {
  const d = (aiState = await api("/api/ai"));
  await Promise.all(d.connections.map(async (c) => { try { c.inventory = await modelList(c.id); } catch { /* Affiché dans le menu. */ } }));
  if (d.distant) { GB("ai", `<p class="management-help subtle">Les IA se connectent depuis le PC.</p>`); return; }
  const options = (audience) => {
    const items = audience === "supervisor" ? [] : [["", "Auto : la meilleure IA disponible pour chaque rôle (benchmarks)"]];
    if (d.claude) items.push(["claude-code", "Claude Code (abonnement)"]);
    if (d.codex) items.push(["codex", "Codex (abonnement ChatGPT)"]);
    d.connections.filter((c) => c.provider !== "elevenlabs").forEach((c) => items.push([c.id, `${c.name} · ${modelCaption(c.model || "?", c.inventory)}`]));   // voice only: never Supervisor or agent
    const current = d[audience] || (audience === "supervisor" ? (d.active === "claude-code" ? "claude-code" : (d.connections[0] || {}).id || "") : "");
    return items.length ? items.map(([v, t]) => `<option value="${esc(v)}"${v === current ? " selected" : ""}>${esc(t)}</option>`).join("") : '<option value="">Aucune IA</option>';
  };
  const local_items = d.local_items.filter((l) => !d.connections.some((c) => c.provider === l));
  const state = d.active ? `<p class="ok management-help">Prêt : le Superviseur répond avec ${d.active === "claude-code" ? "Claude Code" : d.active === "codex" ? "Codex" : "l'IA connectée"}.</p>`
    : `<p class="warn management-help">Aucune IA : connecte-en une ci-dessous (clé API, ou IA locale comme Ollama).</p>`;
  GB("ai", `${state}${aiMsg ? `<p class="warn management-help">${esc(aiMsg)}</p>` : ""}
    <div class="setting"><span>Superviseur</span><select data-ai-for="supervisor">${options("supervisor")}</select></div>
    <div class="setting"><span>Agents</span><select data-ai-for="agents">${options("agents")}</select></div>
    ${d.connections.map((c) => { const local = ["ollama", "lmstudio"].includes(c.provider), off = local && !d.local_items.includes(c.provider);
      const fix = !off ? "" : c.provider === "ollama" ? (d.local_runner_installed ? `<button class="btn main small" data-ai-launch="ollama">Lancer</button>` : `<button class="btn main small" data-install-tool="ollama">Installer</button>`)
        : `<small class="subtle">ouvre LM Studio et démarre son serveur</small>`;
      return `<div class="ai-row"><b>${esc(c.name)}${off ? ' <span class="warn">· ne répond pas</span>' : ""}</b>${fix}<select data-ai-model="${esc(c.id)}"><option>${esc(modelCaption(c.model || "?", c.inventory))}</option></select><button class="btn subtle" data-ai-remove="${esc(c.id)}">Retirer</button></div>`; }).join("")}
    <div class="ai-row"><b class="subtle">${d.claude || d.codex || d.connections.length ? "Autre IA : abonnement, IA locale ou clé" : "Aucune IA connectée"}</b><button class="btn${d.claude || d.codex || d.connections.length ?"" : " main"}" data-ai-assistant="1">Connecter une IA</button></div>
    <div class="ai-row"><b class="subtle">Git et GitHub (facultatif)</b><button class="btn" data-github-assistant="1">Connecter GitHub</button></div>
    <div class="ai-row"><b class="subtle">Guide de démarrage</b><button class="btn subtle" data-guide-restart="1">Rouvrir</button></div>
    ${local_items.map((l) => `<div class="ai-row"><b>${esc((d.providers.find((f) => f.id === l) || {}).name || l)} — détectée sur ce PC</b><button class="btn" data-local-ai="${esc(l)}">Connecter</button></div>`).join("")}
    <div class="ai-new"><select id="ai-provider">${d.providers.map((f) => `<option value="${esc(f.id)}" data-key="${f.key}">${esc(f.name)}</option>`).join("")}</select>
      <input class="field" id="ai-key" type="password" autocomplete="off" placeholder="Clé API (gardée chiffrée sur ce PC)" spellcheck="false">
      <button class="btn main" id="ai-add">Connecter</button></div>
    <p class="management-help subtle" style="margin-top:8px">La clé est vérifiée puis chiffrée sur ce PC ; elle n'est jamais affichée ni envoyée ailleurs qu'au fournisseur choisi. IA locale : lance Ollama ou LM Studio, elle apparaît ici. Un abonnement (ChatGPT, Claude…) passe par son outil en ligne de commande : une fois installé et connecté, il apparaît dans les listes Superviseur et Agents, sans clé.</p>`);
  const provider = $("#ai-provider");
  if (!$("#ai-url")) $("#ai-key").insertAdjacentHTML("beforebegin", "<input class=\"field\" id=\"ai-url\" placeholder=\"Adresse de l'IA (https://…/v1)\" spellcheck=\"false\" hidden>");
  const updateKey = () => { const o = provider.selectedOptions[0], other = o && o.value === "other";
    $("#ai-key").hidden = o && o.dataset.key === "false" && !other; $("#ai-url").hidden = !other;
    $("#ai-key").placeholder = other ? "Clé API (si l'IA en demande une)" : "Clé API (gardée chiffrée sur ce PC)"; };
  provider.onchange = updateKey; updateKey();
  const addItem = async (f, key, url = "") => {
    aiMsg = "";
    try { await api("/api/ai/add", { provider: f, key: key, url }); } catch (e) { aiMsg = e.message; }
    gAI(); loadConversation(false);
  };
  $("#ai-add").onclick = (e) => { e.target.disabled = true; e.target.textContent = "Vérification…"; addItem(provider.value, $("#ai-key").value, provider.value === "other" ? $("#ai-url").value : ""); };
  $$("[data-local-ai]").forEach((b) => (b.onclick = () => { b.disabled = true; addItem(b.dataset.localAi, ""); }));
  $$("[data-ai-for]").forEach((s) => (s.onchange = async () => { try { await api("/api/ai/choose", { [s.dataset.aiFor]: s.value }); } catch (e) { aiMsg = e.message; } gAI(); supervisorChoices(); }));
  $$("[data-ai-remove]").forEach((b) => (b.onclick = async () => { await api("/api/ai/remove", { id: b.dataset.aiRemove }); gAI(); }));
  $$("[data-ai-launch]").forEach((b) => (b.onclick = async () => {        // local AI installed but closed: open it on click
    b.disabled = true; b.textContent = "Lancement…";
    try { const r = await api("/api/local-models/start", {}); infoBubble(r.message); } catch (e) { aiMsg = e.message; }
    setTimeout(() => { gAI(); supervisorChoices(); }, 1500);
  }));
  $$("[data-ai-assistant]").forEach((b) => (b.onclick = () => openWelcome("ai", false)));      // subscriptions, local AIs, keys: one screen
  $$("[data-github-assistant]").forEach((b) => (b.onclick = () => openWelcome("github", false)));
  $$("[data-guide-restart]").forEach((b) => (b.onclick = () => openGuide("ai")));
  await Promise.all([...$$("[data-ai-model]")].map((s) => loadRoleModels(s, s.dataset.aiModel)));
  $$("[data-ai-model]").forEach((s) => (s.onchange = () => api("/api/ai/choose", { id: s.dataset.aiModel, model: s.value }).then(gAI)));
}

/* --- Phone: Tailscale relay (stops with the studio) and devices paired with a 6-digit code */
let phoneCode = null, phoneMsg = "";
/* Notifications on this phone: task awaiting approval or blocked → notification, « Valider » inside if the review is OK */
async function notifsBlock(msg = "") {
  const el = $("#phone-notifications");
  if (!el) return;
  if (location.protocol !== "https:" || !("serviceWorker" in navigator) || !("PushManager" in window)) {
    el.innerHTML = "<p class=\"management-help discret\">Notifications : ouvre le studio dans Chrome, à l'adresse https du PC, puis « Ajouter à l'écran d'accueil ».</p>"; return;
  }
  const reg = await navigator.serviceWorker.ready;
  const subscription = await reg.pushManager.getSubscription();
  const denied = Notification.permission === "denied";
  el.innerHTML = `<div class="setting"><span>Notifications sur ce téléphone<br><small class="subtle">Tâche à valider ou bloquée. « Valider » directement depuis la notification quand la relecture est OK.</small></span>
    <div class="chips small" id="notif-choices">${[[true, "Activées"], [false, "Coupées"]].map(([v, t]) => `<button class="chip${!!subscription === v ?" sel" : ""}" data-v="${v}">${t}</button>`).join("")}</div></div>
    ${subscription ? "<div class=\"setting\"><span></span><button class=\"btn discret\" id=\"notification-test\">Envoyer une notification de test</button></div>" : ""}
    ${denied ? "<p class=\"warn management-help\">Notifications bloquées pour ce site : autorise-les dans les réglages de Chrome (cadenas à gauche de l'adresse).</p>" : ""}
    ${msg ? `<p class="management-help">${esc(msg)}</p>` : ""}`;
  $$("#notif-choices .chip").forEach((b) => (b.onclick = async () => {
    b.disabled = true;
    try {
      if (b.dataset.v === "true") {
        if ((await Notification.requestPermission()) !== "granted") return notifsBlock("Autorise les notifications pour les recevoir.");
        const { key: key } = await api("/api/push");
        const rawText = atob(key.replace(/-/g, "+").replace(/_/g, "/") + "===".slice((key.length + 3) % 4));
        const s = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: Uint8Array.from(rawText, (c) => c.charCodeAt(0)) });
        await api("/api/push/subscribe", { subscription: s.toJSON(), device: /Android/i.test(navigator.userAgent) ? "Android" : "Téléphone" });
        notifsBlock("Activées : tu seras prévenu dès qu'une tâche t'attend.");
      } else {
        const s = await reg.pushManager.getSubscription();
        if (s) { await api("/api/push/unsubscribe", { endpoint: s.endpoint }).catch(() => {}); await s.unsubscribe(); }
        notifsBlock("Coupées.");
      }
    } catch (e) { notifsBlock(e.message); }
  }));
  if ($("#notification-test")) $("#notification-test").onclick = async () => {
    try { const r = await api("/api/push/test", {}); notifsBlock(r.sent ? "Envoyée : elle arrive dans quelques secondes." : "Pas envoyée : le PC n'a pas pu joindre le service de notification."); }
    catch (e) { notifsBlock(e.message); }
  };
}
async function gPhone() {
  const m = await api("/api/mobile");
  const ts = m.tailscale || {};
  const date = (d) => (d ? new Date(d).toLocaleString("fr-FR", { dateStyle: "short", timeStyle: "short" }) : "jamais");
  if (m.distant) { GB("phone", `<p class="management-help subtle">Ce téléphone est associé. Les réglages d'accès se font depuis le PC.</p><div id="phone-notifications"></div>`); notifsBlock(); return; }
  let state;
  if (!ts.ok) state = `<p class="warn management-help">${esc(ts.info || "Tailscale indisponible.")}</p>`;
  else if (m.active) state = `<p class="ok management-help">Accessible sur le téléphone : <b>https://${esc(m.address || ts.dns)}</b></p>`;
  else state = `<p class="management-help subtle">Tailscale est prêt (${esc(ts.dns)}). Accès coupé.</p>`;
  if (m.allow) state += `<p class="warn management-help">Tailscale demande d'autoriser « Serve » une fois : <a href="${esc(m.allow)}" target="_blank" rel="noopener">ouvrir le lien</a>, puis Couper / Activer.</p>`;
  else if (m.setting && !m.active && m.error) state += `<p class="warn management-help">${esc(m.error)}</p>`;
  const code = phoneCode && phoneCode.end > Date.now()
    ? `<p class="management-help">Sur le téléphone, ouvre <b>https://${esc(m.address || ts.dns)}</b> et tape :</p><div class="phone-pairing-code">${phoneCode.code.replace(/(\d{3})(\d{3})/, "$1 $2")}</div><p class="management-help subtle">Valable 10 minutes, une seule fois.</p>` : "";
  const apps = (m.devices || []).map((a) => `<div class="phone-app"><span><b>${esc(a.name)}</b><br><small class="subtle">associé le ${date(a.created)} · vu ${date(a.seen)}</small></span><button class="btn subtle" data-revoke="${esc(a.id)}">Révoquer</button></div>`).join("");
  if (phoneMsg && phoneMsg !== ts.info) state += `<p class="warn management-help">${esc(phoneMsg)}</p>`;
  GB("phone", `${state}
    <div class="setting"><span>Accès depuis le téléphone</span><div class="chips small" id="phone-access">${[[true, "Activé"], [false, "Coupé"]].map(([v, t]) => `<button class="chip${!!m.setting === v ?" sel" : ""}" data-v="${v}">${t}</button>`).join("")}</div></div>
    ${m.active ? `<div class="setting"><span>Nouveau téléphone</span><button class="btn" id="phone-code">Associer un téléphone</button></div>` : ""}
    ${code}${apps ? `<p class="sub-title-g" style="margin-top:12px">Appareils associés</p>${apps}` : ""}
    <p class="management-help subtle" style="margin-top:10px">Seuls tes appareils connectés à ton compte Tailscale voient cette adresse, et chacun doit être associé ici.${m.active ? " Tant que l'accès est activé, fermer la fenêtre ne ferme plus le studio (le téléphone reste connecté) : pour l'arrêter, bouton « Fermer le studio »." : ""}</p>`);
  $$("#phone-access .chip").forEach((b) => (b.onclick = async () => {
    b.disabled = true;
    if (b.dataset.v === "true") b.textContent = "Connexion…";
    try { const r = await api("/api/mobile/access", { yes: b.dataset.v === "true" }); phoneMsg = !r.ok && r.info ? r.info : ""; }
    catch (e) { phoneMsg = e.message; }
    gPhone();
  }));
  const bc = $("#phone-code");
  if (bc) bc.onclick = async () => { const r = await api("/api/mobile/code", { name: "Téléphone" }); phoneCode = { code: r.code, end: Date.now() + r.minutes * 60000 }; gPhone(); };
  $$("[data-revoke]").forEach((b) => (b.onclick = async () => { await api("/api/mobile/revoke", { id: b.dataset.revoke }); gPhone(); }));
}
async function gSettings() {
  const l = await api("/api/settings");
  const groups = [...new Set(l.map((r) => r.group))];
  const field = (r) => {
    const id = `${r.section}.${r.key}`;
    if (r.type === "bool") return `<div class="chips small" data-r="${id}">${[[true, "Oui"], [false, "Non"]].map(([v, t]) => `<button class="chip${r.value === v ?" sel" : ""}" data-v="${v}">${t}</button>`).join("")}</div>`;
    if (r.choices) return `<select data-r="${id}">${r.choices.map((v) => `<option value="${esc(v)}"${String(v) === String(r.value) ? " selected" : ""}>${r.unit && v === 0 ? "Aucune" : esc((r.labels || {})[v] ?? v)}${r.unit && v ? " " + r.unit : ""}</option>`).join("")}</select>`;
    return `<div class="row-path_value"><input class="field" data-r="${id}" value="${esc(r.value || "")}" placeholder="${esc(r.placeholder || (r.type === "text" ? "Ton prénom" : "C:\\…"))}" spellcheck="false"><button class="btn subtle" data-recording="${id}" title="Enregistrer">OK</button></div>`;
  };
  const group = (g) => `<div class="group-r"><p class="sub-title-g">${esc(g)}</p>` + l.filter((r) => r.group === g).map((r) =>
    `<div class="setting${r.type ==="path_value" ? " large" : ""}"><span>${esc(r.label)}${r.restart ? ' <small class="subtle" title="Pris en compte au prochain démarrage du studio">↻</small>' : ""}</span>${field(r)}</div>`).join("") + "</div>";
  const place = (g) => /chemin/i.test(g) ? 4 : /limite|alerte/i.test(g) ? 2 : /entretien|technique/i.test(g) ? 3 : 1;   // Home: workflow only; Gestion: limits, upkeep, technical
  const without = (h) => h.replace(/<p class="sub-title-g">[^<]*<\/p>/, "");          // the block title is enough
  GB("settings", groups.filter((g) => place(g) === 1).map(group).join("") + `<p class="${settingMsg.c} management-help" id="r-msg" style="margin-top:10px">${esc(settingMsg.t)}</p>`);
  GB("settings_secondary", groups.filter((g) => place(g) === 2).map((g) => without(group(g))).join("") || "<p class=\"empty\">Rien ici.</p>");
  if ($("#g-settings_tertiary")) $("#g-settings_tertiary").innerHTML = groups.filter((g) => place(g) === 3).map(group).join("");
  const save = async (id, value) => {
    const [section, key] = id.split(".");
    try { const r = await api("/api/settings", { section, key: key, value: value }); settingMsg = { t: r.message, c: "ok" }; if (key === "language") return location.reload(); gSettings(); if (section === "usage") homeLimits(); }
    catch (e) { settingMsg = { t: e.message, c: "warn" }; gSettings(); }
  };
  const Z = (q) => $$(`#g-settings ${q}, #g-settings_secondary ${q}, #g-settings_tertiary ${q}`);   // Settings (Home), Limits (Usage), Upkeep and technical (Outils)
  Z(".chips[data-r] .chip").forEach((b) => (b.onclick = () => save(b.parentElement.dataset.r, b.dataset.v === "true")));
  Z("select[data-r]").forEach((x) => (x.onchange = () => save(x.dataset.r, /^\d+$/.test(x.value) ? +x.value : x.value)));
  Z("[data-recording]").forEach((b) => (b.onclick = () => save(b.dataset.recording, Z(`input[data-r="${b.dataset.recording}"]`)[0].value)));
  Z("input[data-r]").forEach((x) => (x.onkeydown = (e) => { if (e.key === "Enter") save(x.dataset.r, x.value); }));
}
async function toolVersions() {
  let v;
  try { v = await api("/api/tools/versions"); } catch (e) { if ($("#o-versions")) $("#o-versions").innerHTML = `<p class="warn">${esc(e.message)}</p>`; return; }
  if (!$("#o-versions")) return;
  const tr = await api("/api/jobs").catch(() => ({}));
  $("#o-versions").innerHTML = `<table class="versions">${Object.entries(v).map(([k, x]) => {
    const inProgress = (tr[`update:${k}`] || {}).state === "running";
    const state = !x.installed ? '<span class="bad">introuvable</span>' : x.up_to_date === true ? '<span class="ok">à jour</span>'
      : x.up_to_date === false ? `<span class="warn">${esc(x.latest)} disponible</span>` : '<span class="subtle">dernière version inconnue</span>';
    const button = inProgress ? '<button class="btn" disabled>Mise à jour…</button>'
      : x.up_to_date === false && x.possible ? `<button class="btn main" data-update="${k}">Mettre à jour</button>`
      : x.up_to_date === false ? `<small class="subtle">${esc(x.method)}</small>` : "";
    return `<tr><td><b>${esc(x.name)}</b></td><td class="nowrap">${esc(x.installed || "—")}</td><td>${state}</td><td>${button}</td></tr>`;
  }).join("")}</table><p class="subtle management-help">Opus, Sonnet et Haiku suivent seuls les nouveaux modèles : mettre l'outil à jour suffit.</p>`;
  $$("#o-versions [data-update]").forEach((b) => (b.onclick = async () => {
    const x = v[b.dataset.update];
    if (!confirm(`Mettre à jour ${x.name} (${x.installed} → ${x.latest}) ?\n\nCommande : ${x.method}. Les tâches doivent être terminées.`)) return;
    try { await api("/api/tools/update", { tool: b.dataset.update }); updateJobs(); setTimeout(gTools, 800); setTimeout(gMaintenance, 800); } catch (e) { alert(e.message); }
  }));
}

/* --- Usage */
const USAGES = { "tâche": "Tâches", review: "Relectures (auditeur)", supervisor: "Superviseur" };
const count = (n) => n >= 1e6 ? `${(n / 1e6).toFixed(1).replace(".", ",")} M` : n >= 1e3 ? `${Math.round(n / 1e3)} k` : String(n || 0);
const minutes = (s) => !s ? "0 min" : s < 60 ? `${s} s` : s < 3600 ? `${Math.round(s / 60)} min` : `${Math.floor(s / 3600)} h ${String(Math.round((s % 3600) / 60)).padStart(2, "0")}`;
function adjustUsage() {                                       // « Détails du jour » expanded only if they fit without scrolling
  const c = $("#g-usage") && $("#g-usage").closest(".body-g"), d = $("#u-details");
  if (!c || !d || !c.clientHeight) return;
  d.open = true;
  if (c.scrollHeight > c.clientHeight + 1) d.open = false;
}
/* Usage of all AIs: subscriptions (included), API keys (pay per use), local AIs (free) */
const AI_COLORS = ["var(--cyan)", "var(--magenta)", "#ffc35c", "#5ee6a0", "#9b8cff", "#ff8a3d", "#4aa8ff", "#e6fbff"];
const dollars = (v) => v == null ? "—" : v < 0.01 && v > 0 ? "< 0,01 $" : `${v.toFixed(2).replace(".", ",")} $`;
async function gUsage() {
  const u = await api("/api/usage");
  const order = u.order || Object.keys(u.families);
  const state_color = (fam) => AI_COLORS[order.indexOf(fam) % AI_COLORS.length];
  const max = Math.max(60, ...u.days.map((d) => Object.values(d.families).reduce((a, b) => a + b, 0)));
  const shortDay = (d) => new Date(d + "T12:00:00").toLocaleDateString("fr-FR", { weekday: "short" });
  const ACCESS = { subscription: "abonnement", key: "clé API", local: "local" };
  const cell = (t) => t.calls ? `${minutes(t.duration_s)}<small class="subtle"> · ${t.calls}</small>` : '<span class="subtle">—</span>';
  const cost = (f) => f.access === "subscription" ? `<span class="subtle" title="${f.week.cost_usd ? `≈ ${dollars(f.week.cost_usd)} si c'était facturé à l'API` : ""}">inclus</span>`
    : f.access === "local" ? '<span class="ok">gratuit</span>' : `<b>${dollars(f.week.cost_usd)}</b>`;
  const rows = order.map((fam) => { const f = u.families[fam];
    return `<tr><td><span class="square" style="background:${state_color(fam)}"></span> <b>${esc(fam)}</b></td><td class="subtle">${ACCESS[f.access]}</td><td>${cell(f.window)}</td><td>${cell(f.day)}</td><td>${cell(f.week)}</td><td class="nowrap">${cost(f)}</td></tr>`; }).join("");
  const board = (l, name) => l.length ? `<table>${l.map((x) => `<tr><td>${esc(name(x))}</td><td class="nowrap">${minutes(x.duration_s)}</td><td class="nowrap">${x.calls} appel${x.calls > 1 ? "s" : ""}</td></tr>`).join("")}</table>` : "<p class=\"empty\">Rien aujourd'hui.</p>";
  const cp = u.paid_cost || {};
  const paid = order.some((f) => u.families[f].access === "key");
  GB("usage", `${paid ? `<div class="cost-usage"><span>Payé à l'usage (clés API)</span><b>${dollars(cp.day)}</b><small>aujourd'hui</small><b>${dollars(cp.week)}</b><small>7 jours</small><b>${dollars(cp.month)}</b><small>30 jours</small></div>
      <p class="subtle management-help">Coût réel donné par OpenRouter, sinon estimé au prix du jour${cp.without_price ? ` (${cp.without_price} appel(s) sans prix connu)` : ""}. Les abonnements sont inclus, les IA locales gratuites.</p>` : ""}
    <table class="usage-summary"><thead><tr><th>IA</th><th>Accès</th><th>5 h</th><th>Aujourd'hui</th><th>7 jours</th><th>Coût 7 j</th></tr></thead><tbody>${rows}</tbody></table>
    <div class="usage-days small">${u.days.map((d) => `<div class="usage-day" title="${esc(d.day)} · ${order.filter((f) => d.families[f]).map((f) => `${f} ${minutes(d.families[f])}`).join(" · ") || "nothing"}">
      <div class="stack">${order.map((f) => d.families[f] ? `<span style="height:${Math.round(d.families[f] / max * 100)}%;background:${state_color(f)}"></span>` : "").join("")}</div><small class="subtle">${shortDay(d.day)}</small></div>`).join("")}</div>
    <details class="fold" id="u-details" style="margin-top:10px"><summary>Détails du jour</summary>
      <div class="usage-duo">${board(u.by_usage, (x) => USAGES[x.name] || x.name)}${board(u.by_project, (x) => x.name)}</div>
      ${u.latest.length ? `<p class="sub-title-g">Derniers appels</p><table>${u.latest.slice(0, 8).map((x) => `<tr><td class="nowrap">${esc(x.hour)}</td><td>${esc(x.family)}${x.model ? " · " + esc(x.model) : ""}</td><td>${esc(USAGES[x.usage] || x.usage)}</td><td>${esc(x.project)}</td><td class="nowrap">${minutes(x.duration_s)}</td><td class="nowrap">${count((x.input || 0) + (x.cache || 0) + (x.output || 0))} jetons${x.cost_usd != null && !["Claude", "Codex"].includes(x.family) ? " · " + dollars(x.cost_usd) : ""}</td><td>${x.ok ? "" : '<span class="bad">échec</span>'}</td></tr>`).join("")}</table>` : ""}
      <p class="subtle management-help">Seul l'usage lancé par le studio est compté.</p></details>
    <details class="fold" id="u-results"><summary>Tes résultats</summary><div id="u-res"><p class="empty">…</p></div></details>`);
  $("#u-results").ontoggle = (e) => { if (e.currentTarget.open) gResults(); };
  adjustUsage();
}

/* What your own tasks say about each model: first-try success, time, cost, by type of work. */
async function gResults() {
  let r;
  try { r = await api("/api/results"); } catch (e) { $("#u-res").innerHTML = `<p class="bad">${esc(e.message)}</p>`; return; }
  const pct = (a, b) => `${Math.round(100 * a / b)} %`;
  $("#u-res").innerHTML = r.rows.length ? `<table class="table-results"><thead><tr><th>Travail</th><th>IA · modèle</th><th>Tâches</th><th title="Validée sans « corriger » ni reprise">Du 1er coup</th><th>Validées</th><th>Temps moy.</th><th>Coût moy.</th></tr></thead><tbody>
    ${r.rows.map((x) => `<tr><td>${esc(x.work)}</td><td>${esc(x.ai)}</td><td>${x.tasks}</td><td class="${x.first_attempt / x.tasks >= 0.7 ?"ok" : x.first_attempt / x.tasks < 0.4 ? "warn" : ""}">${pct(x.first_attempt, x.tasks)}</td><td>${pct(x.succeeded, x.tasks)}</td><td class="nowrap">${minutes(x.average_duration_s)}</td><td class="nowrap">${x.average_cost_usd == null ? "—" : dollars(x.average_cost_usd)}</td></tr>`).join("")}</tbody></table>
    <p class="subtle management-help">Calculé sur tes ${r.total} tâche(s) terminée(s), sur ce PC. Dès ${r.min} tâches d'un même travail, le Superviseur te dit quel modèle le réussit le mieux.</p>`
    : `<p class="empty">Pas encore de tâche terminée. Le studio apprend de chaque tâche que tu valides (ou corriges) quel modèle réussit le mieux chaque travail.</p>`;
}

/* --- Data: memory, backups, cleanup */
let memoryScope = "general";
async function gMemory() {
  if (!targets.length) targets = await api("/api/targets");
  GB("memory", `<div class="row-g"><select id="m-scope" aria-label="Portée de la mémoire">${[["general", "Général"], ...targets.map((c) => [c.memory.replace(/^studio:/, ""), c.name])].map(([v, t]) => `<option value="${esc(v)}"${v === memoryScope ? " selected" : ""}>${esc(t)}</option>`).join("")}</select>
      <input class="search" id="m-q" placeholder="Chercher (Entrée)"></div><div id="m-res" class="scroll-g short">…</div>
    <details class="fold"><summary>Ajouter un souvenir</summary>
      <textarea id="m-text" class="area-text" placeholder="Un fait ou une décision à retenir — jamais de secret"></textarea>
      <div class="actions"><button class="btn" id="m-add">Ajouter</button><span id="m-msg" class="subtle"></span></div></details>`);
  $("#m-scope").onchange = () => { memoryScope = $("#m-scope").value; lookup(); };
  $("#m-q").onkeydown = (e) => { if (e.key === "Enter") lookup(); };
  $("#m-add").onclick = async () => {
    try { const r = await api("/api/memory", { scope: memoryScope, text: $("#m-text").value }); $("#m-msg").textContent = r.shared ? "Enregistré." : `Non partagé : ${r.status}`; $("#m-text").value = ""; lookup(); }
    catch (e) { $("#m-msg").textContent = e.message; }
  };
  lookup();
}
async function lookup() {
  try {
    const r = await api(`/api/memory?${new URLSearchParams({ q: $("#m-q").value, scope: memoryScope })}`);
    $("#m-res").innerHTML = (r.pending ? `<div class="alert">${r.pending} écriture(s) pas encore partagée(s).</div>` : "")
      + (r.memories.map((x) => `<div class="memory_item">${esc(x.content)}<br><small>${esc(x.scope.replace(/^studio:/, ""))} · ${esc(x.provenance?.tool || "?")} · ${esc((x.created_at || "").slice(0, 10))}</small></div>`).join("") || "<p class=\"empty\">Rien pour cette recherche.</p>");
  } catch (e) { $("#m-res").innerHTML = `<div class="alert">${esc(e.message)}</div>`; }
}
/* --- Git and GitHub: repo status, branches, working copies, one-click actions */
let gitRepository = "";                                            // repo shown in the project's Branches tab
const gitSummary = (e) => e.error ? `<span class="bad">${esc(e.error)}</span>` : [
  e.detached ? '<span class="warn">HEAD détaché</span>' : `⎇ ${esc(e.branch)}`,
  e.modified.length ? `<span class="warn">${e.modified.length} fichier${e.modified.length > 1 ? "s" : ""} modifié${e.modified.length > 1 ? "s" : ""}</span>` : '<span class="ok">propre</span>',
  e.ahead ? `<span class="warn">↑ ${e.ahead} à pousser</span>` : "", e.behind ? `<span class="warn">↓ ${e.behind} à récupérer</span>` : "",
  !e.distant ? '<span class="subtle">pas de GitHub</span>' : !e.upstream && !e.detached ? '<span class="subtle">branche pas sur GitHub</span>' : ""].filter(Boolean).join(" · ");
async function gitDetail() {
  let d;
  try { d = await api(`/api/git/${encodeURIComponent(gitRepository)}`); } catch (e) { GB("git", `<div class="alert">${esc(e.message)}</div>`); return; }
  const tr = await api("/api/jobs").catch(() => ({}));
  const inProgress = (a) => (tr[`git:${gitRepository.split(":")[1]}:${a}`] || {}).state === "running";
  const button = (a, label, ok, helpText) => `<button class="btn${a ==="pousser" && d.ahead ? " main" : ""}" data-git="${a}" ${ok && !inProgress(a) ? "" : "disabled"} title="${esc(helpText)}">${inProgress(a) ? "En cours…" : label}</button>`;
  const latest = Object.entries(tr).filter(([k]) => k.startsWith(`git:${gitRepository.split(":")[1]}:`)).map(([, j]) => j).sort((a, b) => (a.begin < b.begin ? 1 : -1));
  GB("git-state", `${d.detached ? "<div class=\"alert\">HEAD détaché : aucune branche courante.</div>" : ""}
    <div class="actions-git">${button("refresh", "Fetch", !!d.distant, "Actualiser : git fetch --prune, regarde ce qu'il y a de neuf sur GitHub, ne change aucun fichier")}
      ${button("retrieve", d.behind ? `Pull ↓${d.behind}` : "Pull", !!d.upstream && !d.detached, "Récupérer : git pull --ff-only, seulement si rien ne se mélange")}
      ${d.gh ? button("pr", "Pull request", !!d.upstream && !d.ahead && !d.detached, "Créer une pull request sur GitHub (gh pr create --fill)") : ""}
      ${d.distant ? (d.distant.startsWith("https://github.com/") ? `<a class="link link-repository" href="${esc(d.distant)}" target="_blank" rel="noopener">${esc(d.distant.replace("https://", ""))}</a>` : `<small class="subtle">${esc(d.distant)}</small>`) : ""}
      <span id="git-msg" class="subtle"></span></div>
    ${latest.length ? `<p class="subtle" style="margin:-6px 0 12px">Dernière action : ${latest[0].state === "running" ? "⚙" : latest[0].state === "ok" ? "✔" : "✖"} ${esc(latest[0].title)}${latest[0].state === "failed" && latest[0].output ? ` — <span class="bad">${esc(latest[0].output.slice(-200))}</span>` : ""}</p>` : ""}
    `);
  commitBlock(d);
  treeArgs = [d, button]; branchGraph(d, button);
  const msg = (t) => { const m = $("#git-msg"); if (m) m.textContent = t; };
  const mergedCount = d.branches.filter((b) => b.merged && !b.current).length;
  $("#g-git").onclick = async (e) => {
    const x = (sel) => e.target.closest(sel);
    let b;
    if ((b = x("[data-git]"))) {
      const a = b.dataset.git;
      if ((a === "pousser" || a === "pr") && !confirm(a === "pousser" ? `Pousser ${d.branch} vers GitHub ?` : `Créer une pull request pour ${d.branch} sur GitHub ?`)) return;
      try { const r = await api("/api/git/action", { target: gitRepository, action: a }); msg(r.message); updateJobs(); trackGit(); } catch (er) { msg(er.message); }
    } else if ((b = x("#git-clean"))) {
      if (!confirm(`Supprimer les ${mergedCount} branches déjà fusionnées ? Leurs commits sont dans ${d.branch} : rien n'est perdu.`)) return;
      try { const r = await api("/api/git/clean", { target: gitRepository }); msg(r.message); gitDetail(); gitLine(gitRepository); } catch (er) { msg(er.message); }
    } else if ((b = x("[data-merge]"))) {
      b.disabled = true; b.textContent = "Merge…";
      try {
        const r = await api("/api/git/merge", { target: gitRepository, branch: b.dataset.merge }); msg(r.message);
        const line = b.closest(".act-b");
        if (line) line.classList.add("merge");           // the button disappears, then the tree redraws
        setTimeout(() => { gitDetail(); gitLine(gitRepository); }, line && !reducedMotion() ? 650 : 0); lastView = "";
      } catch (er) { msg(er.message); b.disabled = false; b.textContent = "Merge"; }
    } else if ((b = x("[data-erase]"))) {
      if (!confirm(`Effacer la branche ${b.dataset.erase} ?\n\nSon travail non fusionné sera perdu. La tâche reste dans l'historique (annulée), avec son compte rendu.`)) return;
      try { const r = await api("/api/git/erase-branch", { target: gitRepository, branch: b.dataset.erase }); msg(r.message); gitDetail(); gitLine(gitRepository); lastView = ""; } catch (er) { msg(er.message); }
    } else if ((b = x("[data-delete-branch]"))) {
      if (!confirm(`Supprimer la branche ${b.dataset.deleteBranch} ? Elle est déjà fusionnée : aucun commit n'est perdu.`)) return;
      try { const r = await api("/api/git/delete-branch", { target: gitRepository, branch: b.dataset.deleteBranch }); msg(r.message); gitDetail(); gitLine(gitRepository); } catch (er) { msg(er.message); }
    } else if ((b = x("[data-remove-workspace]"))) {
      if (!confirm("Retirer cette copie de travail ? Le résultat, le diff et le journal de la tâche restent.")) return;
      try { const r = await api(`/api/workspaces/${b.dataset.removeWorkspace}/remove`, {}); msg(r.message); gitDetail(); } catch (er) { msg(er.message); }
    } else if ((b = x("[data-view-task]"))) {
      selection = b.dataset.viewTask; lastView = ""; currentBlock = "detail"; show(); renderTabsBlock();
    }
  };
  $$("#g-git-state [data-git]").forEach((b) => (b.onclick = async () => {
    const a = b.dataset.git;
    if (a === "pr" && !confirm(`Créer une pull request pour ${d.branch} sur GitHub ?`)) return;
    try { const r = await api("/api/git/action", { target: gitRepository, action: a }); msg(r.message); updateJobs(); trackGit(); } catch (er) { msg(er.message); }
  }));
  if (Object.keys(tr).some((k) => k.startsWith("git:") && tr[k].state === "running")) trackGit();
}
/* Branches as a « subway line »: main as a vertical neon line; each task branches off in a curve toward its card,
   color = status. The useful action is on the card (Fusionner, Valider, Reprendre): one click. Click on the card = the task. */
const reducedMotion = () => matchMedia("(prefers-reduced-motion: reduce)").matches;
function branchHue(b) {
  const st = b.task ? b.task.status : "";
  if (["created", "running", "awaiting_slot"].includes(st)) return ["bleu", "en cours"];
  if (TO_APPROVE.includes(st)) return ["jaune", "à valider"];
  if (["approved", "applied"].includes(st)) return ["vert", "prête à fusionner"];
  if (["blocked", "failed", "interrupted"].includes(st)) return ["rouge", LABELS[st]];
  if (st === "cancelled") return ["rouge", "annulée"];
  return ["gris", "branch"];
}
function sinceWhen(date) {
  const t = Date.parse(String(date).replace(" ", "T")); if (!t) return "";
  const m = Math.round((Date.now() - t) / 60000);
  return m < 1 ? "à l'instant" : m < 60 ? `il y a ${m} min` : m < 1440 ? `il y a ${Math.round(m / 60)} h` : `il y a ${Math.round(m / 1440)} j`;
}
function branchGraphLayout(rows, { center, diagonal, horizontal, laneGap }) {
  const result = rows.map((row) => ({ ...row }));
  const byName = new Map(result.map((row) => [row.b.name, row]));
  const visiting = new Set(), done = new Set(), nextLane = { "-1": 2, "1": 2 };
  const place = (row) => {
    if (done.has(row)) return;
    visiting.add(row);
    let parent = byName.get(row.b.parent_branch);
    if (parent === row || visiting.has(parent)) parent = null;
    if (parent) {
      place(parent);
      const side = parent.side;
      row.level = Math.max(parent.level + 1, nextLane[side]);
      nextLane[side] = row.level + 1;
      row.side = side;
      row.parentBranch = parent.b.name;
      row.parentY = parent.y;
      const total = Math.max(1, parent.b.own_commits || 0);
      const progress = Math.max(0, Math.min(1, 1 - (row.b.parent_commits_after_fork || 0) / total));
      row.s0 = parent.s0 + diagonal + progress * (parent.xp - parent.s0 - diagonal);
      row.y = center + side * (diagonal + (row.level - 1) * laneGap);
      row.xp = row.s0 + diagonal + (row.b.own_commits === 0 ? Math.min(horizontal, 24) : horizontal);
    } else {
      row.level = 1;
      row.parentBranch = "";
      row.parentY = center;
    }
    visiting.delete(row);
    done.add(row);
  };
  result.forEach(place);
  return result;
}

function branchGraph(d, button) {
  /* Tree styled like a USB symbol / circuit board, main horizontal toward its arrow. A single step E all along main:
     arrow → merge squares → branch starts (oldest near the merges, newer ones toward the left).
     Each branch splits off at 45° then runs parallel to main up to its symbol (same size for all).
     Above: blocked and cancelled. Below: running, awaiting approval, ready. Text appears on hover;
     the action button always stays visible at the end of the branch. */
  const el = $("#g-git"); if (!el) return;
  const alive = d.branches.filter((b) => !b.current && !b.merged).sort((a, b) => (a.date < b.date ? -1 : 1));
  // squares: merges not yet pushed to GitHub (after Push, none remain); without GitHub, the last 12
  const merges = (d.to_push || d.history || []).filter((c) => /^(Fusion studio|Merge branch)/.test(c.topic)).slice(-12);
  const mergedCount = d.branches.filter((b) => b.merged && !b.current).length;
  // E: spacing of merge squares; EB: spacing of branches, the same for all, just large enough that a branch and
  // its buttons never touch the next one on the same side (the two sides alternate freely)
  // A branch = 45° (D) + parallel line (HZ) up to its symbol, its buttons centered below. E: spacing of merge
  // squares. EB: spacing of branches, the same for all; each symbol sits midway between its start and
  // the next start (or the last merge). Too long for the frame: the tree scrolls horizontally.
  const T = 12, C = 10, D = 22, HZ = 62, E = 56, GAP = 5, BTN = 21;   // buttons centered under the symbol
  const EB = 2 * (D + HZ);                                   // the symbol sits exactly midway between two starts
  const names = new Set(alive.map((branch) => branch.name));
  const stackedCount = alive.filter((branch) => names.has(branch.parent_branch) && branch.parent_branch !== branch.name).length;
  const laneGap = D + BTN + 32, reserved = stackedCount ? stackedCount * (D + HZ) + 220 : 0;
  const cy = D + T / 2 + 7 + BTN + 10 + stackedCount * laneGap, H = cy * 2;
  const W = Math.max(el.clientWidth || 700, 60 + (merges.length + 1) * E + alive.length * EB) + reserved;
  const xA = W - 16;                                         // arrow tip; one E step between the arrow and each merge
  const pos = (k) => xA - T / 2 - (k + 1) * E;               // k-th merge from the arrow
  const origin = (i) => pos(merges.length - 1) - (i + 1) * EB - reserved;   // the oldest: symbol midway between its start and the last merge
  const shape = (cl, x, y, direction) => direction === "square" ? `<rect class="${cl}" x="${x - C / 2}" y="${y - C / 2}" width="${C}" height="${C}"/>`
    : direction === "rond" ? `<circle class="${cl}" cx="${x}" cy="${y}" r="${T / 2}"/>`
    : `<path class="${cl}" d="M${x - T / 2} ${y - T / 2} L${x + T / 2} ${y} L${x - T / 2} ${y + T / 2} Z"/>`;   // right-pointing arrow
  const rel = branchGraphLayout(alive.slice().reverse().map((b, i) => {
    const [hue, lib] = branchHue(b);
    const side = ["rouge", "gris"].includes(hue) ? -1 : 1, s0 = origin(i);
    return { b, hue: hue, lib, side: side, s0, y: cy + side * D, xp: s0 + D + HZ };
  }), { center: cy, diagonal: D, horizontal: HZ, laneGap });
  const roots = rel.filter((row) => !row.parentBranch);
  const x0 = Math.min(roots.length ? Math.min(...roots.map((row) => row.s0)) - 24 : pos(merges.length), 20);
  let xs = x0, trunks = "", defs = "";
  for (const r of roots.slice().sort((a, b) => a.s0 - b.s0)) { trunks += `<line class="trunk" x1="${xs}" y1="${cy}" x2="${r.s0}" y2="${cy}"/>`; xs = r.s0 + GAP; }
  trunks += `<line class="trunk" x1="${xs}" y1="${cy}" x2="${xA - T}" y2="${cy}"/>`;
  let svg = `${trunks}${shape("fleche", xA - T / 2, cy, "right")}${shape("footer", x0 - T / 2, cy, "rond")}`;
  svg += merges.slice().reverse().map((c, i) => `<g><title>${esc(c.date)} · ${esc(c.topic)}</title>${shape("square-f", pos(i), cy, "square")}</g>`).join("");
  const areas = rel.map((r, k) => {
    const { b, hue: hue, side: side, s0, y, xp, parentY, parentBranch } = r, t = b.task;
    const gid = `deg-${k}`;                                   // the diagonal fades from main's cyan to the branch color
    const parentHue = parentBranch ? (rel.find((row) => row.b.name === parentBranch) || {}).hue : "main";
    defs += `<linearGradient id="${gid}" gradientUnits="userSpaceOnUse" x1="${s0}" y1="${parentY}" x2="${s0 + D}" y2="${y}"><stop offset="0" class="stop-${parentHue ||"main"}"/><stop offset="1" class="stop-${hue}"/></linearGradient>`;
    svg += `<g class="branch-svg" data-i="${k}" data-parent="${esc(parentBranch || d.branch)}" data-fork="${esc(b.fork_commit || "")}"><title>${esc(b.name)} — départ ${esc(b.fork_commit || "")}</title><line class="trace-d" stroke="url(#${gid})" x1="${s0}" y1="${parentY}" x2="${s0 + D}" y2="${y}"/><line class="trace ${hue}" x1="${s0 + D}" y1="${y}" x2="${xp - T / 2 - 1}" y2="${y}"/>`
      + shape(`pad ${hue}${hue === "bleu" ? " pulse" : ""}`, xp, y, hue === "bleu" ? "rond" : hue === "jaune" ? "right" : "square")
      + (parentBranch ? `<text class="branch-name" x="${s0 + D + 4}" y="${y - 11}">${esc(short(b.name, 40))}</text>` : "") + "</g>";
    // under the symbol: only git actions — Commit (greyed out if there is nothing to commit), Merge, or Delete for a
    // red branch; Stop, Reprendre and Annuler are in the card that opens when hovering the symbol
    let act = "";
    if (hue === "rouge" && t) act = `<button class="btn small danger" data-erase="${esc(b.name)}" title="Supprimer : annule la tâche si besoin, retire sa copie et efface la branche (git branch -D)">Delete</button>`;
    else if (hue === "vert") act = `<button class="btn main small" data-merge="${esc(b.name)}" title="Fusionner : git merge dans ${esc(d.branch)}, en local ; rien n'est poussé vers GitHub">Merge</button>`;
    else if (t) {
      const toApprove = TO_APPROVE.includes(t.status);
      act = `<button class="btn${toApprove ?" main" : ""} small" data-fast="validate" data-tid="${esc(t.id)}" ${toApprove ? "" : "disabled"} title="${toApprove ? "Valider : le travail est enregistré (git commit) sur la branche de la tâche" : "Rien à valider pour l'instant"}">Commit</button>`;
    }
    const area = `left:${xp - 15}px;top:${y - 15}px;width:30px;height:30px`;     // symbol hover
    return `<div class="area-b" data-i="${k}" ${t ? `data-view-task="${esc(t.id)}"` : ""} tabindex="0" role="button" aria-label="${esc(t ? t.title : b.name)}" style="${area}"></div>
      ${act ? `<div class="act-b" style="left:${xp}px;top:${side > 0 ? y + T / 2 + 8 : y - T / 2 - 8 - BTN}px">${act}</div>` : ""}`;
  });
  const canPush = !!d.distant && !d.detached && !d.behind && (d.ahead || !d.upstream);
  el.innerHTML = `<div class="tree-header"><span class="branch-c">⎇ ${esc(d.branch)}</span>
      <span class="meta-main">${d.ahead ? `<b>${d.ahead}</b> commit${d.ahead > 1 ? "s" : ""} à pousser` : d.upstream ? "à jour avec GitHub" : "pas encore sur GitHub"}${merges.length ? ` · ${merges.length} fusion${merges.length > 1 ? "s" : ""} ${d.to_push ? "à pousser" : "récente" + (merges.length > 1 ? "s" : "")}` : ""}</span>
      ${button("pousser", d.ahead ? `Push ↑${d.ahead}` : "Push", canPush, "Pousser : git push de la branche courante vers GitHub (jamais forcé)")}</div>
    <div class="tree-frame"><div class="tree-scroll"><div class="tree" style="width:${W}px;height:${H}px"><svg width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" aria-hidden="true"><defs>${defs}</defs>${svg}</svg>${areas.join("")}
      ${!alive.length ? `<p class="tree-empty" style="top:${cy + 14}px;right:${W - pos(merges.length) + 10}px">Aucune branche ouverte : tout est dans main.</p>` : ""}</div></div>
      <div class="info-b" hidden></div></div>
    ${mergedCount ? `<div class="metro-footer"><span>✓ ${mergedCount} branche${mergedCount > 1 ? "s" : ""} fusionnée${mergedCount > 1 ? "s" : ""} encore présente${mergedCount > 1 ? "s" : ""}</span><button class="link" id="git-clean" title="Supprimer : git branch -d sur chaque branche déjà fusionnée (copies de travail retirées avec) ; aucun commit perdu">Delete</button></div>` : ""}`;
  // hovering (or keyboard focus on) a branch: its card appears above or below
  const info = el.querySelector(".info-b"), frame = el.querySelector(".tree-frame");
  let infoTimer = 0, hovered = null;
  const hide = () => { info.hidden = true; if (hovered) hovered.classList.remove("survol"); hovered = null; };
  const later = () => { clearTimeout(infoTimer); infoTimer = setTimeout(hide, 280); };
  const showView = (z) => {
    clearTimeout(infoTimer);
    const r = rel[+z.dataset.i], t = r.b.task, st = t ? t.status : "";
    const meta = [r.b.ahead != null ? `${r.b.ahead} commit${r.b.ahead > 1 ? "s" : ""}` : "", r.b.behind ? `main a avancé de ${r.b.behind}` : "", sinceWhen(r.b.date)].filter(Boolean).join(" · ");
    const running = ["created", "running", "awaiting_slot"].includes(st), stopped = ["blocked", "interrupted"].includes(st);
    const buttons = t ? [`<button class="btn main small" data-view-task="${esc(t.id)}">Voir la tâche</button>`,
      running ? `<button class="btn small" data-fast="stop" data-tid="${esc(t.id)}" title="Arrête l'agent ; Reprendre le relance là où il en était">Stop</button>` : "",
      stopped ? `<button class="btn small" data-fast="resume" data-tid="${esc(t.id)}">Reprendre</button>` : "",
      running || TO_APPROVE.includes(st) ? `<button class="btn subtle small danger" data-fast="cancel" data-tid="${esc(t.id)}">Annuler</button>` : ""].join("") : "";
    info.className = `info-b ${r.hue}`;
    info.innerHTML = `<b>${esc(t ? (withoutProject(short(t.title, 90), []) || "Tâche") : r.b.name)}</b><span class="state-b">${esc(r.lib)}</span><small>${esc(meta)}</small>${buttons ? `<div class="buttons-info">${buttons}</div>` : ""}`;
    info.hidden = false;
    const zc = z.getBoundingClientRect(), cc = frame.getBoundingClientRect();
    info.style.left = Math.min(Math.max(0, zc.left - cc.left + zc.width / 2 - info.offsetWidth / 2), cc.width - info.offsetWidth) + "px";
    info.style.top = (r.side > 0 ? zc.top - cc.top - info.offsetHeight - 6 : zc.bottom - cc.top + 6) + "px";   // main side: do not hide the buttons
    if (hovered) hovered.classList.remove("survol");
    hovered = el.querySelector(`.branch-svg[data-i="${z.dataset.i}"]`); if (hovered) hovered.classList.add("survol");
  };
  info.onmouseenter = () => clearTimeout(infoTimer);
  info.onmouseleave = later;
  info.onclick = (e) => { if (e.target.closest("button")) setTimeout(hide, 50); };
  const touch = matchMedia("(hover: none)").matches;      // phone: a tap opens the card (no hover)
  el.querySelectorAll(".area-b").forEach((z) => {
    z.onmouseenter = z.onfocus = () => { if (!touch) showView(z); };
    z.onmouseleave = z.onblur = () => { if (!touch) later(); };
    z.onkeydown = (e) => { if (e.key === "Enter") z.click(); };
    if (touch) z.onclick = (e) => { e.stopPropagation(); showView(z); };
  });
  if (touch) frame.onclick = (e) => { if (!e.target.closest(".info-b,.area-b")) hide(); };
  const scroller = el.querySelector(".tree-scroll");
  if (scroller) {
    scroller.scrollLeft = scroller.scrollWidth;                 // the arrow (latest in main) visible
    let drag = null;                                         // drag with the mouse to scroll the tree
    scroller.onpointerdown = (e) => { if (e.button || e.target.closest("button,.area-b")) return; drag = { x: e.clientX, g: scroller.scrollLeft }; scroller.classList.add("tire"); };
    scroller.onpointermove = (e) => { if (drag) scroller.scrollLeft = drag.g - (e.clientX - drag.x); };
    scroller.onpointerup = scroller.onpointerleave = () => { drag = null; scroller.classList.remove("tire"); };
    scroller.onscroll = hide;
  }
}
let treeTimer = 0, treeArgs = null;
addEventListener("resize", () => { clearTimeout(treeTimer); treeTimer = setTimeout(() => { if (treeArgs && currentBlock === "branches") branchGraph(...treeArgs); }, 200); });
/* One-click commit: files checked (very large ones unchecked by default), message auto-filled if empty */
async function commitBlock(d) {
  if (!d.modified.length) { GB("git-files", "<p class=\"empty\">Rien à commiter : ton dossier est propre.</p>"); return; }
  let info;
  try { info = await api(`/api/git/${encodeURIComponent(gitRepository)}/a-commiter`); } catch (e) { GB("git-files", `<div class="alert">${esc(e.message)}</div>`); return; }
  const f = info.files;
  const line = (x, i) => `<label class="row-commit${x.reason ?" exclu" : ""}"><input type="checkbox" data-i="${i}" ${x.checked ? "checked" : ""}>
      <span class="state-f">${esc(x.state)}</span><span class="path_value-f">${esc(x.path_value)}</span>${x.reason ? `<small class="warn">${esc(x.reason)}</small>` : ""}</label>`;
  GB("git-files", `<div class="commit-block"><p class="help-commit">${f.length} fichier${f.length > 1 ? "s" : ""} pas encore enregistré${f.length > 1 ? "s" : ""} dans <b>${esc(info.branch)}</b>. Tant qu'ils ne sont pas commités, aucune tâche ne peut être fusionnée.</p>
      <div class="list_items-commit">${f.map(line).join("")}</div>
      <div class="actions-git"><input id="commit-msg" class="field" placeholder="Message (facultatif : rempli tout seul)" maxlength="200">
        <button class="btn main" id="commit-ok">Commit</button><span id="commit-info" class="subtle"></span></div>
      <small class="subtle">Commit local seulement : rien n'est envoyé sur GitHub (bouton « Pousser » pour ça).</small></div>`);
  const account = () => { const n = $$("#g-git-files input[data-i]:checked").length; $("#commit-ok").textContent = n ? `Commit (${n})` : "Commit"; $("#commit-ok").disabled = !n; };
  $$("#g-git-files input[data-i]").forEach((c) => (c.onchange = account)); account();
  $("#commit-ok").onclick = async () => {
    const chosen = [...$$("#g-git-files input[data-i]:checked")].map((c) => f[+c.dataset.i].path_value);
    $("#commit-ok").disabled = true; $("#commit-info").textContent = "Commit…";
    try { const r = await api("/api/git/commit", { target: gitRepository, files: chosen, message: $("#commit-msg").value }); $("#commit-info").textContent = r.message; lastView = ""; gitDetail(); gitLine(gitRepository); }
    catch (e) { $("#commit-info").textContent = e.message; $("#commit-ok").disabled = false; }
  };
}
/* Live: what the agent is doing, files touched, open applications — refreshed every 4 s during the task */
let liveTimer = null, liveActive = false;
async function taskActivity(tid, active) {
  clearTimeout(liveTimer);
  const el = $("#direct-task");
  if (!el || selection !== tid) return;
  let a;
  try { a = await api(`/api/tasks/${tid}/activity`); } catch { return; }
  if (selection !== tid || !$("#direct-task")) return;
  const hour = (iso) => { try { return new Date(iso).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" }); } catch { return ""; } };
  const actions = a.actions.length ? `<ul class="direct-list_items">${a.actions.map((x, i) => `<li class="${i === 0 && active ?"current_time" : ""}${x.category_kind === "rejection" ? " bad" : ""}"><span class="hour">${esc(hour(x.hour))}</span>${esc(x.text)}${x.times > 1 ? ` <small class="subtle">×${x.times}</small>` : ""}</li>`).join("")}</ul>`
    : `<p class="subtle">${active ? "Il lit le projet et prépare son travail…" : "Aucune action notée."}</p>`;
  const fileName = (c) => c.split("/").pop();
  const taskFiles = a.files.length ? `<ul class="direct-list_items">${a.files.slice(0, 12).map((f) => `<li title="${esc(f.path_value)}"><span class="state-f ${f.state ==="new" ? "ok" : f.state === "supprimé" ? "bad" : "warn"}">${esc(f.state)}</span>${esc(fileName(f.path_value))}</li>`).join("")}${a.files.length > 12 ? `<li class="subtle">… et ${a.files.length - 12} autres</li>` : ""}</ul>`
    : '<p class="subtle">Aucun fichier modifié pour l\'instant.</p>';
  const COLORS = { "open": "ok", "en cours": "info", "en arrière-plan": "info", "fermé": "bad" };
  const appList = a.applications.length ? `<ul class="direct-list_items">${a.applications.map((x) => `<li><b>${esc(x.name)}</b> — <span class="${COLORS[x.status] ||""}">${esc(x.status)}</span></li>`).join("")}</ul>`
    : '<p class="subtle">Aucune application ouverte par l\'agent.</p>';
  if (a.model && $("#model-direct") && !$("#model-direct").textContent) $("#model-direct").textContent = " · " + a.model;
  const said = active && [...(a.log || [])].reverse().find((x) => x.category_kind === "message");   // what it says it is doing now
  if (said && $("#stage-text")) $("#stage-text").textContent = said.text;
  const log = journalView(a.log || [], active, a.used);
  // while it works: the journal, with the files touched and the open applications beside it; afterwards, the journal only
  const oldList = el.querySelector(".log-direct");          // keeps the reading position (top = follows the news)
  const atTop = !oldList || oldList.scrollTop < 30, oldTop = oldList ? oldList.scrollTop : 0, oldHeight = oldList ? oldList.scrollHeight : 0;
  liveActive = active;
  const opened = new Set([...el.querySelectorAll(".log-direct li[data-k] details[open]")].map((d) => d.closest("li").dataset.k));
  el.innerHTML = active ? `<div class="direct-grid direct-log">
      <div><p class="sub-title-g">Journal</p>${log}</div>
      <div><p class="sub-title-g">Fichiers touchés${a.files.length ? ` (${a.files.length})` : ""}</p>${taskFiles}
        <p class="sub-title-g">Applications</p>${appList}</div></div>`
    : (a.log || []).length ? `<div class="log-finished"><p class="sub-title-g">Journal <span class="n">${a.log.length}</span></p>${log}</div>` : "";
  el.hidden = !el.innerHTML;
  el.querySelectorAll(".log-direct li[data-k]").forEach((li) => { if (opened.has(li.dataset.k)) { const d = li.querySelector("details"); if (d) d.open = true; } });
  wireJournal(el);
  const list = el.querySelector(".log-direct");
  if (list) list.scrollTop = atTop ? 0 : oldTop + (list.scrollHeight - oldHeight);   // reading older lines: they stay in place
  if (active) liveTimer = setTimeout(() => taskActivity(tid, true), 2500);
}
/* Journal: every step of the agent and of the studio, newest at the top, filter by kind, detail on click */
const JOURNAL_KINDS = [["", "Tout"], ["message", "Messages"], ["file", "Fichiers"], ["command", "Commandes"], ["tool", "Skills et outils"], ["studio", "Studio"]];
let journalFilter = "";
function journalView(rows, active, used) {
  const kept = rows.filter((r) => !journalFilter || r.category_kind === journalFilter);
  const hour = (t) => { try { return new Date(t * 1000).toLocaleTimeString("fr-FR"); } catch { return ""; } };
  const ICONS = { message: "💬", file: "📄", command: "›_", tool: "⚙", studio: "◆" };
  const say = (r) => r.category_kind === "studio" ? r.text.replace(/^Statut : (\w+)/, (m, x) => "Statut : " + (LABELS[x] || x)).replace(/unreal-mcp/g, "connexion à Unreal") : r.text;
  kept.forEach((r) => (r.text = say(r)));
  const items = kept.slice(-250).reverse().map((r, i) => `<li data-k="${esc(String(r.t) + r.text.slice(0, 40))}" class="j-${esc(r.category_kind)}${r.failed ?" bad" : ""}${active && i === 0 ? " maintenant" : ""}">
      <span class="hour">${esc(hour(r.t))}</span><span class="j-ico" aria-hidden="true">${ICONS[r.category_kind] || "·"}</span>
      ${r.detail ? `<details><summary>${esc(r.text)}${r.failed ? " — échec" : r.code_output ? " — code 1, normal (rien trouvé)" : ""}</summary><code>${esc(r.detail)}</code></details>` : `<span>${esc(r.text)}${r.failed ? " — échec" : r.code_output ? " — code 1, normal (rien trouvé)" : ""}</span>`}</li>`).join("");
  const u = used || {};
  const usedLine = [u.skills && u.skills.length ? `<b>Skills</b> ${u.skills.map(esc).join(", ")}` : "",
    u.mcp && u.mcp.length ? `<b>Connecteurs</b> ${u.mcp.map(esc).join(", ")}` : "",
    u.tools && Object.keys(u.tools).length ? `<b>Outils</b> ${Object.entries(u.tools).sort((a, b) => b[1] - a[1]).map(([k, n]) => `${esc(k)} ×${n}`).join(", ")}` : ""].filter(Boolean).join(" · ");
  return `${usedLine ? `<p class="j-used">${usedLine}</p>` : ""}<div class="j-filters" role="tablist">${JOURNAL_KINDS.map(([k, n]) => `<button class="chip${k === journalFilter ?" sel" : ""}" data-jf="${k}">${n}</button>`).join("")}</div>
    <ol class="log-direct">${items || `<li class="subtle">${active ? "Il lit le projet et prépare son travail…" : "Rien de noté."}</li>`}</ol>`;
}
function wireJournal(el) {
  el.querySelectorAll("[data-jf]").forEach((b) => (b.onclick = (ev) => { ev.preventDefault(); journalFilter = b.dataset.jf; taskActivity(selection, liveActive); }));
}
let gitTimer = null;
function trackGit() { clearTimeout(gitTimer); gitTimer = setTimeout(() => { if (view === "projects" && currentBlock === "branches") { gitDetail(); gitLine(currentProject); } }, 2500); }

/* --- Skills and documents: a single search, a single viewer */
let docs = [];
const isSkill = (g) => /skill/i.test(g);
function docEntries(groups, activeFilter) {
  const f = (activeFilter || "").toLowerCase();
  return groups.map((g) => {
    const taskFiles = g.files.filter((x) => !f || (x.title + " " + x.path_value).toLowerCase().includes(f));
    if (!taskFiles.length) return "";
    let subdir = null;
    const items = taskFiles.map((x) => (x.subgroup && x.subgroup !== subdir ? `<div class="sub">${esc((subdir = x.subgroup))}</div>` : "")
      + `<div class="doc" data-c="${esc(x.path_value)}" tabindex="0">${esc(x.title)}<small>${esc(x.path_value)}</small></div>`).join("");
    return `<details class="fold" ${f ? "open" : ""}><summary>${esc(g.group)} · ${taskFiles.length}</summary>${items}</details>`;
  }).join("") || "<p class=\"empty\">Rien ne correspond.</p>";
}
async function gDocs() {
  docs = await api("/api/documents");
  const groups = [...docs.filter((g) => isSkill(g.group)), ...docs.filter((g) => !isSkill(g.group))];
  GB("docs", `<p class="subtle management-help">Toutes les IA reçoivent les mêmes skills, quelle que soit l'IA de l'agent (tenues à jour seules, au lancement et avant chaque tâche si une skill a changé). <button class="link" id="g-sync">Vérifier maintenant</button> · <button class="link" id="g-import" title="Copie dans le studio les skills et instructions déjà présents sur ton PC (dossiers de tes outils d'IA) ; rien n'est écrasé, tes originaux ne sont pas touchés">Reprendre mes skills du PC</button> <span id="g-sync-msg" class="subtle"></span></p>
    <p class="subtle management-help">Une seule liste : les skills du studio. Les outils d'IA qui ont leur propre dossier de skills en reçoivent une copie à jour, nommée <code>studio-nom</code> ; les autres IA les reçoivent avec chaque tâche.</p>
    <div class="actions folders-g">${[["projects", "Projets"], ["topics", "Sujets"], ["tasks", "Tâches"], ["Skills", "Skills"], ["rules", "Règles"], ["backups", "Sauvegardes"]].map(([c, t]) => `<button class="btn subtle" data-open-folder="${c}" title="Ouvrir le dossier ${t} dans l'Explorateur">${t}</button>`).join("")}</div>
    <p class="subtle management-help">Ici : lire et modifier les fichiers. Ajouter ou retirer des skills : <button class="link" id="g-vers-ext">Extensions</button>.</p>
    <input class="search" id="g-filter" placeholder="Chercher un skill ou un document…"><div id="g-list_items" class="scroll-g short">${docEntries(groups, "")}</div>`);
  $("#g-vers-ext").onclick = () => { customTab = "skill"; showView("custom"); };
  $$("[data-open-folder]").forEach((b) => (b.onclick = () => openPath(b.dataset.openFolder)));
  const bindHandlers = () => $$("#g-list_items .doc").forEach((d) => (d.onclick = d.onkeydown = async (ev) => {
    if (ev.type === "keydown" && ev.key !== "Enter") return;
    const r = await api(`/api/document?path_value=${encodeURIComponent(d.dataset.c)}`);
    $$("#g-list_items .doc.sel").forEach((x) => x.classList.remove("sel")); d.classList.add("sel");
    $("#g-reader").innerHTML = `<div class="actions" style="margin:0 0 6px;justify-content:space-between"><small>${esc(d.dataset.c)}</small><span><button class="btn" id="g-mod">Modifier</button> <button class="btn subtle" id="g-close">Fermer</button></span></div>
      ${/\.md$/.test(d.dataset.c) ? md(r.text) : `<pre>${esc(r.text)}</pre>`}`;
    $("#g-mod").onclick = () => openPath(d.dataset.c);
    $("#g-close").onclick = () => { d.classList.remove("sel"); $("#g-reader").innerHTML = "<p class=\"empty\">Clique un skill ou un document pour le lire ici.</p>"; };
  }));
  $("#g-filter").oninput = () => { $("#g-list_items").innerHTML = docEntries(groups, $("#g-filter").value); bindHandlers(); };
  bindHandlers();
  api("/api/skills/conflicts").then((l) => {
    if (!l.length || !$("#g-docs")) return;
    $("#g-docs").insertAdjacentHTML("afterbegin", `<div class="alert" id="g-conflicts"><b>Modifiés dans tes dossiers, hors du studio</b>${l.map((x) =>
      `<div class="setting"><span>${x.category_kind === "skill" ? "Skill" : "Instructions"} <b>${esc(x.name)}</b>${x.both_sides ? " · modifiée aussi dans le studio" : ""}<br><small class="subtle">${esc(x.origin)}</small></span><span><button class="btn subtle small" data-conflict="${esc(x.id)}" data-choices="original">Mettre à jour dans le studio</button><button class="btn subtle small" data-conflict="${esc(x.id)}" data-choices="studio">Garder la version du studio</button></span></div>`).join("")}</div>`);
    $$("#g-conflicts [data-conflict]").forEach((b) => (b.onclick = async () => {
      try { infoBubble((await api("/api/skills/conflict", { name: b.dataset.conflict, choices: b.dataset.choices })).message); gDocs(); } catch (e) { alert(e.message); }
    }));
  }).catch(() => {});
  $("#g-import").onclick = async () => {
    $("#g-sync-msg").textContent = "Copie…";
    try { const r = await api("/api/skills/import", {});
      $("#g-sync-msg").textContent = r.skills.length || r.instructions.length ? `Copié : ${[...r.skills, ...r.instructions].join(", ")}.` : "Rien de nouveau à reprendre.";
      if (r.skills.length) gDocs(); }
    catch (e) { $("#g-sync-msg").textContent = e.message; }
  };
  $("#g-sync").onclick = async () => {
    $("#g-sync-msg").textContent = "Synchronisation…";
    try { const r = await api("/api/skills/synchronize", {}); $("#g-sync-msg").textContent = r.report.join(" · ") === "Déjà à jour." ? "Tout est à jour." : r.report.join(" · "); }
    catch (e) { $("#g-sync-msg").textContent = e.message; }
  };
}

/* ================================================================ status, badge, notifications, closing */
let knownStatuses = null;
async function updateBadge() {
  try {
    const t = await api("/api/tasks");
    const av = t.filter((x) => TO_APPROVE.includes(x.status));
    $("#count-validate").hidden = !av.length; $("#count-validate").textContent = av.length;
    $("#mob-badge").hidden = !av.length; $("#mob-badge").textContent = av.length;             // phone: Work tab
    if (knownStatuses) t.filter((x) => ACTIVE_STATUSES.includes(knownStatuses[x.id]) && !ACTIVE_STATUSES.includes(x.status)).forEach(taskFinished);
    knownStatuses = Object.fromEntries(t.map((x) => [x.id, x.status]));
  } catch (e) { /* optional */ }
}
/* End of a task: a small notification with a single « Voir » button (system notification if the window is hidden) */
function taskFinished(x) {
  const state = TO_APPROVE.includes(x.status) ? "à valider" : ["approved", "applied"].includes(x.status) ? "terminée" : (LABELS[x.status] || x.status);
  const text = `${targetName(x.target)} · « ${taskName(x)} » ${state}`;
  if (document.hidden && "Notification" in window && Notification.permission === "granted") {
    const n = new Notification("Tâche " + state, { body: text, icon: "/icon-192.png", tag: x.id });
    n.onclick = () => { window.focus(); openTaskNotification(x); n.close(); };
    return;
  }
  let box = $("#notifs-end");
  if (!box) { box = document.createElement("div"); box.id = "notifs-end"; box.setAttribute("role", "status"); box.setAttribute("aria-live", "polite"); document.body.appendChild(box); }
  const el = document.createElement("div");
  el.className = `notif-end ${state_color(x.status)}`;
  el.innerHTML = `<span>${esc(text)}</span><button class="btn main small">Voir</button>`;
  el.querySelector("button").onclick = () => { el.remove(); openTaskNotification(x); };
  box.appendChild(el);
  setTimeout(() => el.classList.add("output"), 20000);
  setTimeout(() => el.remove(), 20600);
}
function openTaskNotification(x) {
  const c = (targets || []).find((k) => k.id === String(x.target).split(":").pop() && (!String(x.target).includes(":") || `${k.kind}:${k.id}` === x.target));
  selection = x.id; lastView = ""; currentBlock = "detail"; currentProject = c ? `${c.kind}:${c.id}` : currentProject; showView("projects");
  if (document.body.dataset.mob === "sup") mobileView("work");
}
async function loadState() {
  try {
    const e = await api("/api/state?leger=1");
    const ok = e.memory.state === "OK";
    $("#state-memory").hidden = ok;                    // nothing at the top when all is well; a warning otherwise
    if (!ok) $("#state-memory").textContent = `⚠ Mémoire : ${e.memory.state}`;
  } catch (err) { /* the studio is not responding: the presence check handles it */ }
}
/* Files tab: images, sheets, texts and other files created by the agents for this project */
let fileEntries = [], fileFilter = "", fileSearch = "", compareMode = false, compareChoice = [];
const FILE_LOCATIONS = { copy: ["en attente de fusion", "waiting"], project: ["dans le projet", ""], topic: ["dans le sujet", ""], capture: ["capture", ""], "": ["missing", "waiting"] };
const fileUrl = (f) => `/api/files/view?tid=${encodeURIComponent(f.tid)}&chemin=${encodeURIComponent(f.path_value)}`;
async function projectFiles() {
  const key = currentProject;
  try { fileEntries = await api(`/api/files?target=${encodeURIComponent(key)}`); } catch (e) { $("#p-files").innerHTML = `<div class="alert">${esc(e.message)}</div>`; return; }
  if (currentProject === key) renderFiles();
}
/* Results gallery: everything the agents produced for this project or topic, sorted like the topics' folders */
const RESULT_KINDS = [["images", "Images"], ["documents", "Documents"], ["3d", "3D"], ["sounds", "Sons"], ["videos", "Vidéos"], ["code", "Code"], ["other", "Autres"]];
const kindOf = (f) => f.type || (f.category_kind === "image" ? "images" : "other");
function renderFiles() {
  const q = fileSearch.toLowerCase();
  const l = fileEntries.filter((f) => (!fileFilter || (fileFilter === "ref" ? f.reference : kindOf(f) === fileFilter)) && (!q || `${f.name} ${f.path_value} ${f.task}`.toLowerCase().includes(q)));
  const n = (k) => fileEntries.filter((f) => kindOf(f) === k).length;
  const nRef = fileEntries.filter((f) => f.reference).length;
  const chips = [["", `Tout (${fileEntries.length})`], ...(nRef ? [["ref", `★ Références (${nRef})`]] : []),
    ...RESULT_KINDS.filter(([k]) => n(k) || k === fileFilter).map(([k, t]) => [k, `${t} (${n(k)})`])];
  const where = (f) => `<span class="where-f ${FILE_LOCATIONS[f.where][1]}">${FILE_LOCATIONS[f.where][0]}</span>`;
  const imgs = l.filter((f) => kindOf(f) === "images");
  const media = (f) => kindOf(f) === "sounds" && f.where ? `<audio controls preload="none" src="${fileUrl(f)}"></audio>`
    : kindOf(f) === "videos" && f.where ? `<video controls preload="metadata" src="${fileUrl(f)}"></video>` : "";
  const section = ([k, t]) => {
    const items = l.filter((f) => kindOf(f) === k);
    return items.length ? `<p class="sub-title-g sub-title-f">${t} <small class="subtle">${items.length}</small></p><ul class="list_items-f${k ==="videos" ? " file-videos" : ""}">${items.map((f) => `<li data-f="${fileEntries.indexOf(f)}" title="${esc(f.path_value)}"><b>${esc(f.name)}</b><span class="subtle">${esc(f.task)}</span>${where(f)}${media(f)}</li>`).join("")}</ul>` : "";
  };
  const others = RESULT_KINDS.slice(1).map(section).join("");
  $("#p-files").innerHTML = `<div class="filters-f"><div class="chips" id="f-category_kind"></div>
      <input class="field" id="f-search" placeholder="Chercher (nom, tâche…)" value="${esc(fileSearch)}">
      <button class="btn subtle" id="f-tidy" title="Lance l'archiviste : il déplace et renomme les fichiers des agents dans les bons dossiers, sans rien supprimer ; tu valides">Ranger le projet</button>
      ${imgsTotal() >= 2 ? `<button class="btn${compareMode ?" main" : " subtle"}" id="f-compare" title="Choisis deux images pour les comparer avec un curseur avant / après">${compareMode ? `Comparer : choisis ${2 - compareChoice.length} image${compareChoice.length ? "" : "s"}` : "Comparer"}</button>` : ""}</div>
    ${!l.length ? `<p class="empty">${fileEntries.length ? "Rien ne correspond." : "Aucun résultat pour l'instant : les images, documents, sons et autres fichiers créés par les agents s'afficheront ici."}</p>` : ""}
    ${imgs.length ? `<div class="grid-f">${imgs.map((f) => { const i = fileEntries.indexOf(f); return `<div class="card-f${compareChoice.includes(i) ?" choisie" : ""}" data-f="${i}" role="button" tabindex="0" title="${esc(f.path_value)}">${f.where && f.category_kind === "image" ? `<img src="${fileUrl(f)}" alt="${esc(f.name)}" loading="lazy">` : `<span class="without-preview">${esc((f.name.split(".").pop() || "").toUpperCase())}</span>`}<button class="star${f.reference ?" yes" : ""}" data-star="${i}" title="${f.reference ? "Retirer des références" : "Marquer comme référence : le Superviseur la donnera aux agents"}" aria-label="Référence">${f.reference ? "★" : "☆"}</button><span class="information"><b>${esc(f.name)}</b>${esc(f.task)}<br>${where(f)}</span></div>`; }).join("")}</div>` : ""}
    ${others}`;
  chipList($("#f-category_kind"), chips, fileFilter, (v) => { fileFilter = v; renderFiles(); });
  $("#f-search").oninput = (e) => { fileSearch = e.target.value; const pos = e.target.selectionStart; renderFiles(); const c = $("#f-search"); c.focus(); c.setSelectionRange(pos, pos); };
  $$("#p-files [data-f]").forEach((el) => {
    const openCard = () => {
      const i = +el.dataset.f;
      if (!compareMode) return showFile(fileEntries[i]);
      compareChoice = compareChoice.includes(i) ? compareChoice.filter((x) => x !== i) : [...compareChoice, i].slice(-2);
      if (compareChoice.length === 2) { compareImages(fileEntries[compareChoice[0]], fileEntries[compareChoice[1]]); compareMode = false; compareChoice = []; }
      renderFiles();
    };
    el.onclick = (e) => { if (!e.target.closest("[data-star], audio, video")) openCard(); };
    el.onkeydown = (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); openCard(); } };
  });
  $$("#p-files [data-star]").forEach((b) => (b.onclick = async (e) => {
    e.stopPropagation();
    const f = fileEntries[+b.dataset.star];
    try { await api("/api/files/reference", { target: currentProject, tid: f.tid, path_value: f.path_value, yes: !f.reference }); f.reference = !f.reference; renderFiles(); infoBubble(f.reference ? "Référence : le Superviseur la donnera aux agents" : "Retirée des références"); }
    catch (er) { infoBubble(er.message); }
  }));
  $("#f-tidy").onclick = async () => {
    if (!confirm("Lancer le rangement du projet ? L'archiviste déplace et renomme les fichiers produits par les agents (rien n'est supprimé), puis tu valides.")) return;
    try {
      const r = await api("/api/tasks", { target: currentProject, role: "archivist", title: "Ranger les fichiers du projet", request: TIDY_REQUEST });
      selection = r.tid; lastView = ""; infoBubble("Rangement lancé"); setTimeout(() => openProject(currentProject), 400);
    } catch (e) { infoBubble(e.message); }
  };
  if ($("#f-compare")) $("#f-compare").onclick = () => { compareMode = !compareMode; compareChoice = []; renderFiles(); };
}
const TIDY_REQUEST = `Objectif : ranger les fichiers produits par les agents dans ce projet, pour que l'utilisateur retrouve tout facilement.
Où : tout le projet, en priorité les fichiers à la racine et dans les dossiers fourre-tout (captures/, references/, sources/, outputs/…).
Faire : déplacer chaque livrable dans le dossier prévu par le projet (voir CLAUDE.md / AGENTS.md ; images et planches dans Docs/art/<sujet>/, documents dans Docs/<sujet>/), renommer les noms illisibles (identifiant de tâche, longue suite de chiffres) en noms clairs, mettre à jour les liens Markdown.
Ne pas faire : ne rien supprimer (liste les copies inutiles dans ton compte rendu), ne pas toucher au code ni aux assets du moteur.
Compte rendu : un tableau avant → après, puis la liste des copies que l'utilisateur peut retirer.`;
const imgsTotal = () => fileEntries.filter((f) => f.category_kind === "image" && f.where).length;
function compareImages(a, b) {                            // before / after slider: drag to reveal the second image
  const v = $("#viewer"), c = $("#v-content");
  $("#v-title").textContent = `${a.name}  ⟷  ${b.name}`;
  c.innerHTML = `<div class="compare"><img src="${fileUrl(a)}" alt="${esc(a.name)}"><div class="top" style="clip-path:inset(0 0 0 50%)"><img src="${fileUrl(b)}" alt="${esc(b.name)}"></div>
    <div class="line" style="left:50%"></div><span class="name-g">${esc(a.name)}</span><span class="name-d">${esc(b.name)}</span>
    <input type="range" min="0" max="100" value="50" aria-label="Position du curseur de comparaison"></div>`;
  const r = c.querySelector("input"), top = c.querySelector(".top"), stroke = c.querySelector(".line");
  r.oninput = () => { top.style.clipPath = `inset(0 0 0 ${r.value}%)`; stroke.style.left = r.value + "%"; };
  ["v-open", "v-folder", "v-task"].forEach((id) => ($("#" + id).hidden = true));
  v.hidden = false; r.focus();
}
async function showFile(f) {
  ["v-open", "v-folder", "v-task"].forEach((id) => ($("#" + id).hidden = false));
  const v = $("#viewer"), c = $("#v-content");
  $("#v-title").textContent = `${f.name} · ${f.task}`;
  c.innerHTML = "<p class=\"empty\">…</p>"; v.hidden = false; $("#v-close").focus();
  if (f.category_kind === "image") c.innerHTML = `<img src="${fileUrl(f)}" alt="${esc(f.name)}">`;
  else if (["sounds", "videos"].includes(kindOf(f))) c.innerHTML = kindOf(f) === "sounds" ? `<audio controls autoplay src="${fileUrl(f)}"></audio>` : `<video controls autoplay src="${fileUrl(f)}"></video>`;
  else {
    try {
      const r = await fetch(fileUrl(f));
      if (!r.ok) throw new Error((await r.json().catch(() => ({}))).error || r.status);
      const t = await r.text();
      c.innerHTML = `<div class="text-v">${/\.md$/i.test(f.name) ? md(t) : `<pre>${esc(t)}</pre>`}</div>`;
    } catch (e) { c.innerHTML = `<p class="empty">${esc(e.message)}</p>`; }
  }
  const openFile = (folder) => api("/api/files/open", { tid: f.tid, path_value: f.path_value, folder: folder }).catch((e) => infoBubble(e.message));
  $("#v-open").onclick = () => openFile(false);
  $("#v-folder").onclick = () => openFile(true);
  $("#v-task").onclick = () => { v.hidden = true; selection = f.tid; lastView = ""; show(); showDetail(); };
}
$("#v-close").onclick = () => ($("#viewer").hidden = true);
document.addEventListener("keydown", (e) => { if (e.key === "Escape" && !$("#viewer").hidden) $("#viewer").hidden = true; });

/* Phone: bottom bar to switch from the work block to the Supervisor (the choice is kept) */
function mobileView(v) {
  document.body.dataset.mob = v;
  $$("#bar-mobile button").forEach((b) => b.classList.toggle("active", b.dataset.mob === v));
  try { localStorage.setItem("view-mobile", v); } catch {}
  if (v === "sup") { const f = $("#thread"); if (f) f.scrollTop = f.scrollHeight; }
}
$("#bar-mobile").onclick = (e) => { const b = e.target.closest("button[data-mob]"); if (b) mobileView(b.dataset.mob); };
mobileView((() => { try { return storedValue("view-mobile") || "work"; } catch { return "work"; } })());
function openTaskNotif(tid) {
  if (!tid) return;
  const link = document.createElement("button"); link.dataset.openTask = tid; link.hidden = true;
  document.body.appendChild(link); link.click(); link.remove();
}
if ("serviceWorker" in navigator) navigator.serviceWorker.addEventListener("message", (e) => e.data && openTaskNotif(e.data.openTask));
{ const t = new URLSearchParams(location.search).get("task"); if (t) { history.replaceState(null, "", "/"); setTimeout(() => openTaskNotif(t), 1200); } }
if ("serviceWorker" in navigator && location.protocol === "https:") navigator.serviceWorker.register("/sw.js").catch(() => {});

/* Window size: recorded on every change, restored at next launch (full screen, maximized or exact size) */
let windowTimer = 0;
function recordWindow() {
  clearTimeout(windowTimer);
  windowTimer = setTimeout(() => {
    const full = !!document.fullscreenElement || (outerWidth >= screen.width && outerHeight >= screen.height);
    const maximized = !full && outerWidth >= screen.availWidth - 2 && outerHeight >= screen.availHeight - 2;
    fetch("/api/window", { method: "POST", keepalive: true, headers: { "Content-Type": "application/json", "X-Studio": "1" },
      body: JSON.stringify({ fullscreen: full, maximized: maximized, x: screenX, y: screenY, l: outerWidth, h: outerHeight }) }).catch(() => {});
  }, 700);
}
addEventListener("resize", recordWindow);          // maximize, full screen, resize: a single request per change

/* Presence and reconnection: if the PC stops responding (studio closed, network down), a banner says so and the page
   reloads itself as soon as it is back. On returning to the app (phone, tab), everything refreshes immediately. */
let offline = false, sessionInfo = {};
async function presence() {
  try {
    await api("/api/presence", {});
    if (offline) location.reload();
  } catch (e) {
    if (e.code === 403) {
      if (sessionInfo.distant) { location.reload(); return; }       // phone revoked: code page
      document.body.innerHTML = "<div class=\"closed\"><h1>Game over</h1><p class=\"empty\">Session terminée. Relance le raccourci du bureau.</p></div>";
      return;
    }
    if (!offline && (e instanceof TypeError || e.code >= 502)) {
      offline = true;
      const b = document.createElement("div");
      b.id = "hors-row"; b.setAttribute("role", "status");
      b.textContent = sessionInfo.distant ? "Studio fermé sur le PC ? Reconnexion…" : "Le studio ne répond pas. Reconnexion…";
      document.body.appendChild(b);
    }
  }
}
document.addEventListener("visibilitychange", () => {
  if (document.visibilityState !== "visible") return;
  presence(); loadState(); updateJobs();
  if (view === "projects") { loadConversation(false); if (!currentProject) workSummary(); }
});
api("/api/session").then((s) => {
  sessionInfo = s || {};
  if (sessionInfo.name && sessionInfo.name !== userName) { userName = sessionInfo.name; loadConversation(false); }
  api("/api/ai").then((d) => { const before = aiState; aiState = d; if (!before || !!before.active !== !!d.active) loadConversation(false); }).catch(() => {});
  if (sessionInfo.distant) { $("#close-studio").style.display = "none"; document.body.classList.add("distant"); }   // from the phone, it could not be reopened
}).catch(() => {});
$("#close-studio").onclick = async () => {
  try { await api("/api/stop", {}); }
  catch (e) {
    if (e.code !== 409 || !confirm("Un travail tourne encore. Fermer dès qu'il sera terminé ?")) return;
    await api("/api/stop", { after_jobs: true });
  }
  document.body.innerHTML = "<div class=\"closed\"><h1>See you next mission</h1><p class=\"empty\">Tu peux fermer cette fenêtre.</p></div>";
  setTimeout(() => window.close(), 800);
};
document.addEventListener("click", () => { if ("Notification" in window && Notification.permission === "default") Notification.requestPermission(); }, { once: true });

api("/api/targets").then((c) => { targets = c; updateBadge(); });
document.body.classList.add("static");
function listChoice(el, items, active, cb) {
  el.innerHTML = items.map(([v, t]) => `<option value="${esc(v)}"${v === active ? " selected" : ""}>${esc(t)}</option>`).join("");
  el.onchange = () => cb(el.value);
}
listChoice($("#sup-model"), SUPERVISOR_MODELS, supervisorModel, (v) => keepSup("sup-model", (supervisorModel = v)));
listChoice($("#sup-effort"), EFFORTS, supervisorEffort, (v) => keepSup("sup-effort", (supervisorEffort = v)));
const PROFILES = [["fast", "Rapide"], ["normal", "Normal"], ["performance", "Performance"]];
const PROFILE_HELP = {
  fast: "Plus vite et moins cher : modèle plus léger quand l'IA en propose, effort un cran plus bas, pas de relecture par une 2e IA.",
  normal: "Le réglage optimisé de chaque agent (recommandé).",
  performance: "Plus de raisonnement : le modèle le plus puissant de chaque IA (hors rédaction), effort un cran plus haut. Plus lent, consomme plus.",
};
function renderProjectProfile(key, clean, fallback) {          // per-project mode (Rapide / Normal / Performance)
  const current = clean || fallback || "normal";
  $("#p-profile").innerHTML = PROFILES.map(([v, t]) => `<button data-p="${v}" class="${v === current ?"sel" : ""}" aria-pressed="${v === current}">${t}</button>`).join("");
  $("#p-profile-help").textContent = PROFILE_HELP[current] || "";
  if ($("#p-header-mode")) $("#p-header-mode").value = current;               // header selector kept in sync
  $$("#p-profile button").forEach((b) => (b.onclick = async () => {
    try { const r = await api("/api/profile", { target: key, profile: b.dataset.p }); renderProjectProfile(key, r.profile, fallback); } catch (e) { alert(e.message); }
  }));
}
api("/api/choices").then((c) => {                          // offered models: [choix] modeles_claude (studio.config.toml)
  AI_EFFORTS = c.ai_efforts || {};
  loadAiRoles();
  MODELS = [["", "Auto"], ...c.models.map((m) => [m, modelName(m)])];
  SUPERVISOR_MODELS = [["", "Auto"], ...[...c.models].reverse().map((m) => [m, modelName(m)])];
  SECONDARY_MODELS = [["", "Auto"], ...(c.secondary_models || []).map((m) => [m, m])];
  supervisorChoices();
}).catch(() => {});
/* Supervisor header: its AI, then the models and effort levels of THAT AI. Refreshed whenever the AI changes. */
async function supervisorChoices(d) {
  try { d = d || await api("/api/ai"); } catch { return; }
  if (d.distant) { $("#sup-ai").closest("label").hidden = true; }
  const items = [];
  if (d.claude) items.push(["claude-code", "Claude Code (abonnement)"]);
  if (d.codex) items.push(["codex", "Codex (abonnement ChatGPT)"]);
  d.connections.filter((c) => c.provider !== "elevenlabs").forEach((c) => items.push([c.id, shortAiName(c.name)]));
  const current = d.active === "api" ? d.supervisor || (d.connections[0] || {}).id || "" : d.active || "";
  listChoice($("#sup-ai"), items.length ? items : [["", "Aucune IA"]], current, async (v) => {
    try { await api("/api/ai/choose", { supervisor: v }); } catch (e) { infoBubble(e.message); }
    supervisorChoices(); if (currentBlock === "sup-settings") gAI().catch(() => {});
  });
  $("#sup-ai").closest("label").hidden = items.length < 2 && !!items.length;
  const cx = d.connections.find((x) => x.id === current);
  const fam = current === "codex" ? "codex" : current === "claude-code" || !cx ? "claude-code" : cx.provider;
  supFamily = fam;
  const model = $("#sup-model");
  model.onfocus = null;
  model.disabled = false;
  model.dataset.connection = "";
  model.parentElement.querySelector("[data-model-note]")?.remove();
  if (fam === "claude-code") {
    listChoice(model, SUPERVISOR_MODELS, supervisorModel, (v) => keepSup("sup-model", (supervisorModel = v)));
    model.closest("label").hidden = false;
  } else if (fam === "codex") {                          // Codex: « Auto » = its default model, or one of its own list
    if (!SECONDARY_MODELS.some(([v]) => v === secondary_cliModel)) secondary_cliModel = "";
    listChoice(model, SECONDARY_MODELS, secondary_cliModel, (v) => keepSup("sup-secondary-model", (secondary_cliModel = v)));
    model.closest("label").hidden = false;
  } else if (cx) {
    model.innerHTML = `<option value="${esc(cx.model || "")}">${esc(cx.model || "?")}</option>`;
    model.closest("label").hidden = false;
    await loadRoleModels(model, cx.id);
    model.onchange = async () => { try { model.disabled = true; $("#sup-effort").disabled = true; await api("/api/ai/choose", { id: cx.id, model: model.value }); modelLists.delete(cx.id); await supervisorChoices(); } catch (e) { infoBubble(e.message); } };
  } else model.closest("label").hidden = true;          // the CLI picks its own model
  const effort = $("#sup-effort");
  effort.closest("label").hidden = false;
  effort.innerHTML = `<option value="${esc(supervisorEffort || "auto")}"></option>`;
  const refreshEffort = async () => {
    await loadEffortChoices(effort, current, model.value || cx?.model || "");
    keepSup("sup-effort", supervisorEffort = effort.value === "auto" ? "" : effort.value);
  };
  if (model._refreshEffort) model.removeEventListener("change", model._refreshEffort);
  model._refreshEffort = refreshEffort;
  if (!cx) model.addEventListener("change", refreshEffort);
  effort.onchange = () => keepSup("sup-effort", supervisorEffort = effort.value === "auto" ? "" : effort.value);
  await refreshEffort();
}
/* Refreshes: nothing heavy while the window is hidden (minimized, other tab); everything updates as soon as
   it comes back. Only the badge and « à valider » notifications continue, more slowly. */
const each = (ms, f) => setInterval(() => { if (!document.hidden) f(); }, ms);
let tick = 0;
updateJobs(); updateAlerts();
setInterval(() => { if (!document.hidden && (activeJobs() || ++tick % 3 === 0)) updateJobs(); }, 4000);   // 4 s during work, otherwise 12 s
each(60000, updateAlerts);
each(60000, () => { if (view === "management") homeLimits(); });
each(8000, () => { if (view === "projects") api("/api/projects").then((ps) => { projectList = ps; renderTabs(); renderTabsBlock(); }).catch(() => {}); });
openSupervisor();                                      // on open: always the Supervisor (afterwards, each page returns where you left it)
loadState(); presence();
function refresh() {
  if (view === "projects") loadConversation(false);
  if (view === "projects" && !currentProject) workSummary();
  if (view === "projects" && currentProject) { api(`/api/projects/${encodeURIComponent(currentProject)}`).then((p) => { taskLists(p.tasks); projectTeam(p.team); }).catch(() => {}); if (selection) show(); }
  updateBadge();
}
let hiddenTicks = 0;
setInterval(() => { if (!document.hidden) refresh(); else if (++hiddenTicks % 4 === 0) updateBadge(); }, 4000);
document.addEventListener("visibilitychange", () => { if (!document.hidden) { refresh(); updateJobs(); } });

/* PC resources in the header: mostly useful with local models (video memory used by Ollama). */
async function updateSystem() {
  if (sessionInfo.distant) return;                         // phone: the PC is what matters, not shown here
  let s;
  try { s = await api("/api/system"); } catch { return; }
  const el = $("#system");
  const gauge = (name, pct, text, title) => text == null ? "" : `<span class="m${pct >= 90 ?" max" : pct >= 75 ? " top" : ""}" title="${esc(title)}"><b>${name}</b>${pct == null ? "" : `<span class="bar"><i style="width:${Math.min(100, pct)}%"></i></span>`}<span class="v">${text}</span></span>`;
  const r = s.ram || {}, g = s.gpu || {};
  const vramPct = g.total_vram_gb ? 100 * g.vram_gb / g.total_vram_gb : null;
  const ai = (s.ollama || []).map((m) => `${m.name} (${m.vram_gb} Go)`).join(", ");
  el.innerHTML = gauge("CPU", s.cpu ?? 0, s.cpu == null ? "…" : `${Math.round(s.cpu)} %`, `Processeur : ${s.cores || "?"} cœurs`)
    + gauge("RAM", r.total_gb ? 100 * r.used_gb / r.total_gb : null, r.total_gb ? `${r.used_gb}/${Math.round(r.total_gb)} Go` : null, "Mémoire vive utilisée")
    + gauge("GPU", g.used ?? null, g.used == null ? null : `${Math.round(g.used)} %`, `${g.name || "Carte graphique"}${ai ? " · IA locale chargée : " + ai : ""}`)
    + gauge("VRAM", vramPct, g.vram_gb == null ? null : g.total_vram_gb ? `${g.vram_gb}/${Math.round(g.total_vram_gb)} Go` : `${g.vram_gb} Go`,
      `Mémoire de la carte graphique${ai ? " · IA locale : " + ai : ""}`);
  el.hidden = !el.innerHTML;
}
updateSystem();
each(3000, updateSystem);
setInterval(presence, 15000);
document.addEventListener("visibilitychange", () => { if (!document.hidden) presence(); });     // back to the window: at once
addEventListener("pagehide", () => {                       // window closed: the studio stops soon instead of after 10 min
  try { fetch("/api/presence", { method: "POST", keepalive: true, headers: { "Content-Type": "application/json", "X-Studio": "1" }, body: JSON.stringify({ end: true }) }); } catch { /* best effort */ }
});
setInterval(() => $$(".timer").forEach((el) => { el.textContent = formatDuration((+el.dataset.base || 0) + seconds(el.dataset.since)); }), 1000);

/* Window size: no zoom; only the blocks adapt (header height to fill the window). */
function adjustScale() {
  const h = document.querySelector("header");
  if (h) document.documentElement.style.setProperty("--header", h.offsetHeight + "px");
}
window.addEventListener("resize", adjustScale);
adjustScale();
each(30000, loadState);

/* Light ripple on click on everything clickable (disabled if animations are reduced in Windows) */
const CLICKABLE = ".btn,.chip,.project,.list_items li,.doc,.agent-g,.link-g";
document.addEventListener("pointerdown", (e) => {
  if (matchMedia("(prefers-reduced-motion: reduce)").matches) return;
  const el = e.target.closest(CLICKABLE);
  if (!el || el.disabled) return;
  const r = el.getBoundingClientRect(), o = document.createElement("span");
  o.className = "onde"; o.style.left = `${e.clientX - r.left}px`; o.style.top = `${e.clientY - r.top}px`;
  if (getComputedStyle(el).position === "static") el.style.position = "relative";
  if (getComputedStyle(el).overflow === "visible") el.style.overflow = "hidden";        // the ripple never overflows
  el.appendChild(o); o.addEventListener("animationend", () => o.remove());
  el.classList.remove("flash"); void el.offsetWidth; el.classList.add("flash");
  setTimeout(() => el.classList.remove("flash"), 500);
}, { passive: true });

/* ================================================================ EXTENSIONS
   Deux vues, les mêmes filtres ; lecture seule jusqu’à une action explicite sur une fiche. */
const ICONS = {
  game: '<path d="M6 11h4M8 9v4M15 12h.01M18 10h.01"/><rect x="2" y="6" width="20" height="12" rx="6"/>',
  "3d": '<path d="M12 2 3 7v10l9 5 9-5V7z"/><path d="m3 7 9 5 9-5M12 12v10"/>',
  design: '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-5-5L5 21"/>',
  code: '<path d="m16 18 6-6-6-6M8 6l-6 6 6 6"/>',
  web: '<circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a15 15 0 0 1 0 20M12 2a15 15 0 0 0 0 20"/>',
  documents: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M8 13h8M8 17h5"/>',
  audio: '<path d="M2 12h2M6 8v8M10 4v16M14 7v10M18 10v4M22 12h0"/>',
  "tools-ai": '<path d="M12 3v3M12 18v3M3 12h3M18 12h3M5.6 5.6l2.1 2.1M16.3 16.3l2.1 2.1M5.6 18.4l2.1-2.1M16.3 7.7l2.1-2.1"/><circle cx="12" cy="12" r="3"/>',
  data: '<path d="M3 3v18h18"/><path d="M7 15l4-4 3 3 5-6"/>',
  sound: '<path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/>',
  video: '<rect x="2" y="5" width="15" height="14" rx="2"/><path d="m17 10 5-3v10l-5-3z"/>',
  write: '<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/>',
  marketing: '<path d="m3 11 18-8v18L3 13z"/><path d="M11.6 16.8a3 3 0 1 1-5.8-1.6"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/>',
  custom: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
  pack: '<path d="m12 2 10 5-10 5L2 7z"/><path d="m2 12 10 5 10-5M2 17l10 5 10-5"/>',
};
const icon = (k) => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[k] || ICONS.code}</svg>`;
const TYPES_P = { skill: "Skill", mcp: "Serveur MCP", software: "Logiciel" };
const TAG_P = { skill: "SKILL", mcp: "MCP", software: "LOGICIEL" };
const EXTENSION_TABS = [["discover", "Découvrir"], ["installed", "Installé"]];
function storedValue(key) {
  // Repli de lecture pendant la transition ; les valeurs de contenu restent opaques.
  const aliases = {"order-projects":["ordre-projets"],"project-current":["projet-courant"],"tab-management":["onglet-gestion"],"audit-target":["audit-cible"],"local-runner-later":["ollama-plus-tard"],"view-mobile":["vue-mobile"],"tab-extensions":["onglet-extensions"],"sup-model":["sup-modele"],"sup-secondary-model":["sup-modele-codex","sup-model-codex"]};
  let value = localStorage.getItem(key);
  if (value === null || value === undefined) {
    for (const old of (Object.hasOwn(aliases, key) ? aliases[key] : [])) {
      value = localStorage.getItem(old);
      if (value !== null && value !== undefined) break;
    }
  }
  const rename = (table, entry) => Object.hasOwn(table, entry) ? table[entry] : entry;
  const scope = (v) => typeof v === "string" ? v.replace(/^(projet|sujet):/, (prefix) => prefix === "projet:" ? "project:" : "topic:") : v;
  if (key === "project-current" || key === "audit-target") return scope(value);
  if (key === "order-projects" && value) {
    const list = JSON.parse(value);
    if (Array.isArray(list)) return JSON.stringify(list.map(scope));
  }
  const tabs = {"equipe":"team","memoire":"memory","reglages":"settings","outils":"tools","entretien":"maintenance","telephone":"phone","documents":"docs","bibliotheque":"library","classements":"bench"};
  if (key === "tab-management") return rename(tabs, value);
  if (key === "view-mobile") return value === "travail" ? "work" : value;
  if (key === "tab-extensions") return rename({"installe":"installed","decouvrir":"discover","connecteur":"connector"}, value);
  if (key === "extension-filters" && value) {
    const saved = JSON.parse(value);
    if (saved && typeof saved === "object" && !Array.isArray(saved)) {
      const domains = {"connaissances":"knowledge","logiciel":"software","jeu":"game","son":"sound","ecriture":"write","donnees":"data","recherche":"search","outils-ia":"tools-ai"};
      const tab = {"installe":"installed","decouvrir":"discover"};
      const kind = {"logiciel":"software","connecteur":"mcp"};
      const sort = {"nom":"name","domaine":"domain"};
      return JSON.stringify({...saved, tab:rename(tab, saved.tab), kind:rename(kind, saved.kind),
        sort:rename(sort, saved.sort), domain:rename(domains, saved.domain)});
    }
  }
  return value;
}
const EXTENSION_KINDS = [["all", "Tout"], ["skill", "Skills"], ["mcp", "Connecteurs (MCP)"], ["software", "Logiciels"]];
const EXTENSION_STATES = { active: "Actif", disabled: "Désactivé", error: "Erreur", update_available: "Mise à jour disponible" };
let library = null, libraryLoadedAt = 0, customTab = "discover", customSearch = "", customCategory = "", customSort = "domain", customKind = "all";
try {
  const saved = JSON.parse(storedValue("extension-filters") || "null");
  const legacyTab = storedValue("tab-extensions");
  if (saved && typeof saved === "object") {
    if (EXTENSION_TABS.some(([key]) => key === saved.tab)) customTab = saved.tab;
    if (EXTENSION_KINDS.some(([key]) => key === saved.kind)) customKind = saved.kind;
    if (typeof saved.search === "string") customSearch = saved.search;
    if (typeof saved.domain === "string") customCategory = saved.domain;
    if (["domain", "name", "recent"].includes(saved.sort)) customSort = saved.sort;
  } else {
    if (legacyTab === "installed") customTab = "installed";
    if (legacyTab === "skill") customKind = "skill";
    if (legacyTab === "connector") customKind = "mcp";
  }
} catch (e) { /* Le stockage local est facultatif. */ }
function saveExtensionFilters() {
  try { localStorage.setItem("extension-filters", JSON.stringify({ tab: customTab, kind: customKind, search: customSearch, domain: customCategory, sort: customSort })); }
  catch (e) { /* Les filtres restent utilisables en mémoire. */ }
}
async function showCustom(reload = true) {
  if (reload || !library) {
    try {
      const catalog = await api("/api/extensions/catalog");
      library = { elements: catalog.items, categories: catalog.domains, for_you: catalog.recommended, projects: catalog.projects };
      libraryLoadedAt = Date.now();
    } catch (e) { $("#custom-body").innerHTML = `<div class="alert">${esc(e.message)}</div>`; return; }
  }
  const sel = $("#custom-cat");
  sel.innerHTML = '<option value="">Tous les domaines</option>' + Object.entries(library.categories || {}).map(([key, name]) => `<option value="${esc(key)}">${esc(name)}</option>`).join("");
  if (customCategory && !Object.hasOwn(library.categories, customCategory)) customCategory = "";
  sel.value = customCategory;
  $("#custom-search").value = customSearch;
  $("#custom-sort").value = customSort;
  $("#custom-tabs").innerHTML = EXTENSION_TABS.map(([key, name]) => `<button role="tab" data-o="${key}" aria-selected="${key === customTab}">${name}</button>`).join("");
  renderCustom();
}
const stripAccents = (t) => t.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
function customFilter(kind = customKind) {
  if (!library) return [];
  const query = stripAccents(customSearch.trim());
  const items = library.elements.filter((e) => e.installed === (customTab === "installed") && (kind === "all" || e.kind === kind)
    && (!customCategory || e.domain === customCategory)
    && (!query || stripAccents(`${e.name} ${e.description || ""} ${e.author || ""} ${library.categories[e.domain] || e.domain}`).includes(query)));
  const byName = (a, b) => a.name.localeCompare(b.name, "fr");
  if (customSort === "name") return items.sort(byName);
  if (customSort === "recent") return items.sort((a, b) => (b.installed_at || "").localeCompare(a.installed_at || "") || Number(!!b.new) - Number(!!a.new) || byName(a, b));
  const domains = Object.keys(library.categories);
  return items.sort((a, b) => domains.indexOf(a.domain) - domains.indexOf(b.domain) || byName(a, b));
}
// Le logo du logiciel quand il existe, sinon l’icône du domaine.
const extIcon = (e, cls) => `<span class="${cls}"${e.logo ? ` data-logo="${esc(e.logo)}"` : ""}>${icon(e.domain || e.category)}</span>`;
function extensionUsage(e) {
  if (e.used_by === "common") return "Commun à tous les projets";
  if (Array.isArray(e.used_by)) return e.used_by.length ? `Projets : ${e.used_by.map((p) => p.name).join(", ")}` : "Aucun projet activé";
  return "";
}
function extensionStatus(e) {
  if (!e.installed) return "";
  const state = e.detected ? "Détecté" : EXTENSION_STATES[e.state] || "Installé";
  return `<span class="extension-status ${e.state ==="error" ? "bad" : e.state === "active" ? "ok" : "warn"}" title="Disponibilité et configuration enregistrées ; aucune connexion testée">${esc(state)}</span><span class="extension-usage">${esc(extensionUsage(e))}</span>`;
}
function customCard(e) {
  const action = e.installed ? `<button data-card="${esc(e.id)}" aria-label="Gérer ${esc(e.name)}">Gérer</button>`
    : `<button class="plus" data-install-p="${esc(e.id)}" title="Ajouter" aria-label="Ajouter ${esc(e.name)}">＋</button>`;
  const note = e.type === "mcp" && !e.installed && (e.missing || []).length ? ` · il faut ${esc(e.missing.join(", "))}` : "";
  return `<div class="card-p${e.installed ?" installed" : ""}" data-card="${esc(e.id)}">${extIcon(e, "ico")}
    <span class="txt"><b>${esc(e.name)}${e.checked ? "<span class=\"check\" title=\"Source vérifiée\">✔</span>" : ""}</b><span class="desc">${esc(e.description || "")}</span>
    <span class="meta"><span class="tag-p ${e.type}">${TAG_P[e.type] || ""}</span>par ${esc(e.author || "?")} · ${esc(library.categories[e.domain] || e.domain)}${e.new ? " · nouveau" : ""}${note}</span>${extensionStatus(e)}</span>
    <span class="acts">${action}</span></div>`;
}
function renderCustom() {
  const items = customFilter(), requestBody = $("#custom-body"), counted = customFilter("all");
  $("#extension-types").innerHTML = EXTENSION_KINDS.map(([kind, name]) => `<button type="button" data-extension-kind="${kind}" aria-pressed="${customKind === kind}">${name}<span class="n">${kind === "all" ? counted.length : counted.filter((e) => e.kind === kind).length}</span></button>`).join("");
  const section = (title, entries) => entries.length ? `<section class="custom-section"><h3 class="title">${esc(title)} <span class="n">${entries.length}</span></h3><div class="custom-grid">${entries.map(customCard).join("")}</div></section>` : "";
  const byDomain = (entries) => [...new Set(entries.map((e) => e.domain))].map((domain) => section(library.categories[domain] || domain, entries.filter((e) => e.domain === domain))).join("");
  if (!items.length) {
    requestBody.innerHTML = `<p class="empty">${customTab === "installed" && !customSearch && !customCategory && customKind === "all" ? "Rien d'installé pour l'instant : va dans « Découvrir »." : "Rien ne correspond."}</p>`;
    return;
  }
  if (customTab === "installed") {
    requestBody.innerHTML = EXTENSION_KINDS.filter(([kind]) => kind !== "all").map(([kind, name]) => {
      const entries = items.filter((e) => e.kind === kind);
      return entries.length ? `<section class="extension-kind"><h2 class="extension-type-title">${name} · ${entries.length}</h2>${byDomain(entries)}</section>` : "";
    }).join("");
  } else {
    const recommended = items.filter((e) => (library.for_you || []).includes(e.id));
    requestBody.innerHTML = section("Pour tes projets", recommended) + byDomain(items.filter((e) => !recommended.includes(e)));
  }
  placeLogos(requestBody);
}
function elementSheet(id) {
  const e = library.elements.find((x) => x.id === id);
  if (!e || e.type === "pack") return;
  const el = $("#custom-card-body");
  const vars = e.type === "mcp" && !e.installed ? (e.variables || []).map((v) => `<label>${esc(v.label)}${v.help ? ` <small>(${esc(v.help)})</small>` : ""}</label><input data-var="${esc(v.name)}" type="${v.secret ? "password" : "text"}" autocomplete="off">`).join("") : "";
  const warn = e.type === "mcp" && (e.missing || []).length ? `<p class="warn">Il faut d'abord ${esc(e.missing.join(" et "))} sur le PC.</p>` : "";
  const mcpInfo = e.detected ? `<p class="management-help">Détecté · ${esc(e.command)} · ${esc(e.origin)}. Lecture seule : géré dans sa configuration d’origine.</p>` : e.type === "mcp" ? `<p class="management-help">${e.installed ? esc(extensionUsage(e)) + "." : "Disponible pour les projets où tu l’activeras."} ${e.checked ? "" : "Serveur de la communauté : vérifie qu'il te convient."} Le serveur se télécharge à sa première utilisation.</p>` : "";
  const configuration = e.installed && !e.detected && e.kind === "mcp" ? `<details class="fold"><summary>Configurer / Activer ou désactiver par projet</summary><p class="management-help">Ouvre l’équipe du projet pour modifier ses connecteurs.</p>${(library.projects || []).map((project) => `<button class="btn subtle" data-open-team="${esc(project.key)}">Configurer : ${esc(project.name)}</button>`).join("") || '<p class="subtle">Ajoute d’abord un projet.</p>'}</details>` : "";
  const logInfo = e.type === "software" ? `<p class="management-help">${e.auto ? "Trouvé sur ce PC : les agents le connaissent déjà, rien à faire." : e.installed ? "Déclaré aux agents." : e.found ? "Trouvé sur ce PC : un clic pour le déclarer aux agents." : `Pas trouvé sur ce PC. Le studio n'installe pas de logiciel : <a href="${esc(e.site)}" target="_blank" rel="noopener">site officiel</a>${e.winget ? ` ou dans PowerShell : <code>winget install --id ${esc(e.winget)} -e</code>` : ""}.`}</p>` : "";
  const path = e.type === "software" && !e.installed && !e.found ? `<label>Chemin complet du programme, une fois installé</label><input data-var="path_value" placeholder="C:\\…\\programme.exe">` : "";
  const buttons = [`<button class="btn subtle" data-close-card="1">Fermer</button>`];
  if (e.installed && e.type === "skill") buttons.unshift(`<a class="btn subtle" href="/api/library/export?id=${encodeURIComponent(e.id)}" download>Exporter (.zip)</a>`);
  if (e.installed && !e.detected && !e.core && !e.auto) buttons.unshift(`<button class="btn subtle danger" data-remove-p="${esc(e.removal_id || e.id)}" data-type="${esc(e.type)}">Retirer</button>`);
  if (e.installed && e.attempt) buttons.push(`<button class="btn" data-try_action="${esc(e.id)}">Essayer</button>`);
  if (!e.installed) buttons.push(`<button class="btn main" data-install-p="${esc(e.id)}" data-from-card="1">Ajouter</button>`);
  el.innerHTML = `<div style="display:flex;gap:14px;align-items:center">${extIcon(e, "ico-f")}
      <div><h2>${esc(e.name)}</h2><div class="meta"><span class="tag-p ${e.type}">${TAG_P[e.type]}</span>${esc(library.categories[e.category] || "")} · par ${esc(e.author || "?")}${e.checked ? " · source vérifiée" : ""}${e.licence ? " · " + esc(e.licence) : ""}${e.size ? ` · ${Math.max(1, Math.round(e.size / 1024))} Ko` : ""}</div></div></div>
    <p>${esc(e.description || "")}</p>${extensionStatus(e)}${configuration}${e.attempt ? `<p class="management-help">Exemple : « ${esc(e.attempt)} »</p>` : ""}${mcpInfo}${logInfo}${warn}${vars}${path}
    <p class="warn" id="card-msg"></p><div class="bottom">${buttons.join("")}</div>`;
  placeLogos(el);
  $("#custom-card").hidden = false;
}
async function installCustom(id, fromSheet) {
  const e = library.elements.find((x) => x.id === id);
  if (!e) return;
  if (!fromSheet && ((e.type === "mcp" && (e.variables || []).length) || e.type === "software" && !e.found)) return elementSheet(id);
  const valueMap = {};
  $$("#custom-card-body [data-var]").forEach((i) => (valueMap[i.dataset.var] = i.value));
  if (e.type === "mcp" && !confirm(`Ajouter « ${e.name} » pour tes agents ?\n${e.checked ? "" : "Serveur de la communauté (non officiel).\n"}Son paquet se téléchargera à la première utilisation.`)) return;
  try {
    const r = await api("/api/library/install", { id, values: valueMap });
    infoBubble(r.message || "Ajouté.");
    $("#custom-card").hidden = true;
    shortcutsCache = null;
    showCustom();
  } catch (err) { if (!$("#custom-card").hidden && $("#card-msg")) $("#card-msg").textContent = err.message; else { elementSheet(id); setTimeout(() => $("#card-msg") && ($("#card-msg").textContent = err.message), 50); } }
}
function tryCustom(id) {
  const e = library.elements.find((x) => x.id === id);
  if (!e) return;
  $("#custom-card").hidden = true;
  showView("projects");
  openSupervisor();
  if (document.body.dataset.mob) mobileView("sup");
  setTimeout(() => { const t = $("#message"); t.value = `${e.type === "skill" ? `Avec la skill « ${e.name} » : ` : e.type === "mcp" ? `Avec ${e.name} : ` : ""}${e.attempt || ""}`; adjustInputField(); t.focus(); }, 400);
}
$("#custom-tabs").onclick = (ev) => {
  const button = ev.target.closest("[data-o]");
  if (!button || !EXTENSION_TABS.some(([key]) => key === button.dataset.o)) return;
  customTab = button.dataset.o; saveExtensionFilters(); showCustom(false);
};
$("#extension-types").onclick = (ev) => {
  const button = ev.target.closest("[data-extension-kind]");
  if (!button || !EXTENSION_KINDS.some(([key]) => key === button.dataset.extensionKind)) return;
  customKind = button.dataset.extensionKind; saveExtensionFilters(); renderCustom();
};
$("#custom-search").oninput = (ev) => { customSearch = ev.target.value; saveExtensionFilters(); renderCustom(); };
$("#custom-cat").onchange = (ev) => { customCategory = ev.target.value; saveExtensionFilters(); renderCustom(); };
$("#custom-sort").onchange = (ev) => { customSort = ev.target.value; saveExtensionFilters(); renderCustom(); };
$("#custom-add").onclick = (ev) => { ev.stopPropagation(); $("#menu-custom").hidden = !$("#menu-custom").hidden; };
document.addEventListener("click", (ev) => { if (!ev.target.closest(".custom-add")) $("#menu-custom").hidden = true; });
$("#menu-custom").onclick = (ev) => {
  const a = (ev.target.closest("[data-a]") || {}).dataset; if (!a || !a.a) return;
  $("#menu-custom").hidden = true;
  if (a.a === "import") $("#custom-zip").click();
  if (a.a === "url") skillFromUrl();
  if (a.a === "create") { showView("projects"); openSupervisor(); if (document.body.dataset.mob) mobileView("sup");
    setTimeout(() => { const t = $("#message"); t.value = "Crée une skill pour [décris ce que la skill doit faire et quand l'utiliser]. Utilise la skill « Créer une skill » si elle est installée, et range-la dans Skills."; adjustInputField(); t.focus(); t.setSelectionRange(t.value.indexOf("["), t.value.indexOf("]") + 1); }, 400); }
  if (a.a === "mcp") mcpForm();
  if (a.a === "software") {
    $("#custom-card-body").innerHTML = `<h2>Ajouter un logiciel du PC</h2><div class="meta">Les agents sauront qu'il existe et où il est (Godot, Krita, ffmpeg…).</div>
      <label>Nom</label><input id="lg-name" placeholder="Krita"><label>Chemin complet du programme</label><input id="lg-path_value" placeholder="C:\\Program Files\\Krita (x64)\\bin\\krita.exe">
      <p class="warn" id="card-msg"></p><div class="bottom"><button class="btn subtle" data-close-card="1">Annuler</button><button class="btn main" id="lg-ok">Ajouter</button></div>`;
    $("#custom-card").hidden = false;
    $("#lg-ok").onclick = async () => {
      try { await api("/api/connectors/add", { name: $("#lg-name").value, path_value: $("#lg-path_value").value }); infoBubble("Logiciel déclaré aux agents.");
        $("#custom-card").hidden = true; customTab = "installed"; saveExtensionFilters(); showCustom(); }
      catch (e) { $("#card-msg").textContent = e.message; }
    };
  }
};
$("#custom-zip").onchange = async (ev) => {
  const f = ev.target.files[0]; ev.target.value = "";
  if (!f) return;
  const sendZip = async (ok) => { const r = await fetch(`/api/library/import?confirm=${ok ? 1 : 0}`, { method: "POST", headers: { "X-Studio": "1", "Content-Type": "application/zip" }, body: f });
    const j = await r.json().catch(() => ({})); if (!r.ok) throw new Error(j.error || "import refusé"); return j; };
  try {
    const a = await sendZip(false);
    $("#custom-card-body").innerHTML = `<h2>Importer « ${esc(a.id)} »</h2><div class="meta">${a.files} fichier(s) · skill venue d'ailleurs : relis-la avant de l'ajouter</div>
      ${a.notes.length ? `<p class="sub-title-g">À vérifier</p><ul>${a.notes.map((n) => `<li class="warn">${esc(n)}</li>`).join("")}</ul>` : '<p class="ok">Rien de suspect relevé.</p>'}
      <p class="sub-title-g">Début du SKILL.md</p><pre>${esc(a.excerpt)}</pre><p class="warn" id="card-msg"></p>
      <div class="bottom"><button class="btn subtle" data-close-card="1">Annuler</button><button class="btn main" id="zip-ok">Ajouter cette skill</button></div>`;
    $("#custom-card").hidden = false;
    $("#zip-ok").onclick = async () => { try { const r = await sendZip(true); infoBubble(r.message); $("#custom-card").hidden = true; customTab = "installed"; saveExtensionFilters(); showCustom(); } catch (e) { $("#card-msg").textContent = e.message; } };
  } catch (e) { alert(e.message); }
};
/* A skill from anywhere: GitHub folder or repository, SKILL.md page, raw file or .zip. Origin, licence, popularity and
   points to check are shown before anything is installed; GitHub content is pinned to the commit that was read. */
function skillFromUrl() {
  $("#custom-card-body").innerHTML = `<h2>Ajouter une skill depuis une adresse</h2>
    <div class="meta">Dossier ou dépôt GitHub, page d'un SKILL.md, fichier brut ou archive .zip. Tu vois son origine et sa licence avant de l'ajouter.</div>
    <label>Adresse</label><input id="su-url" placeholder="https://github.com/editeur/depot/tree/main/skills/nom-de-la-skill" spellcheck="false">
    <p class="warn" id="card-msg"></p><div class="bottom"><button class="btn subtle" data-close-card="1">Annuler</button><button class="btn main" id="su-view">Voir la skill</button></div>`;
  $("#custom-card").hidden = false; $("#su-url").focus();
  const send = (ok) => api("/api/library/import-url", { url: $("#su-url") ? $("#su-url").value : skillFromUrl.url, confirm: ok });
  const preview = async () => {
    skillFromUrl.url = $("#su-url").value; $("#su-view").disabled = true; $("#card-msg").textContent = "Lecture…";
    try {
      const a = await send(false), o = a.origin || {};
      const facts = [o.editor && `éditeur : ${esc(o.editor)}`, o.licence ? `licence : ${esc(o.licence)}` : '<span class="warn">licence non indiquée</span>',
        o.stars != null && `${o.stars} étoiles`, o.update && `mis à jour le ${esc(o.update)}`, o.commit && `version figée ${esc(o.commit)}`,
        o.archive && '<span class="warn">dépôt archivé (plus maintenu)</span>'].filter(Boolean).join(" · ");
      $("#custom-card-body").innerHTML = `<h2>Ajouter « ${esc(a.id)} »</h2><div class="meta">${esc(o.origin || "")} · ${a.files} fichier(s)</div>
        <p>${facts}</p>
        ${a.notes.length ? `<p class="sub-title-g">À vérifier</p><ul>${a.notes.map((n) => `<li class="warn">${esc(n)}</li>`).join("")}</ul>` : '<p class="ok">Rien de suspect relevé.</p>'}
        <p class="sub-title-g">Début du SKILL.md</p><pre>${esc(a.excerpt)}</pre><p class="warn" id="card-msg"></p>
        <div class="bottom"><button class="btn subtle" data-close-card="1">Annuler</button><button class="btn main" id="su-ok">Ajouter cette skill</button></div>`;
      $("#su-ok").onclick = async () => { try { const r = await send(true); infoBubble(r.message); $("#custom-card").hidden = true; customTab = "installed"; saveExtensionFilters(); showCustom(); } catch (e) { $("#card-msg").textContent = e.message; } };
    } catch (e) { $("#card-msg").textContent = e.message; $("#su-view").disabled = false; }
  };
  $("#su-view").onclick = preview;
  $("#su-url").onkeydown = (e) => { if (e.key === "Enter") preview(); };
}
function mcpForm() {
  $("#custom-card-body").innerHTML = `<h2>Ajouter un serveur MCP</h2><div class="meta">Serveur pas relu par le studio : ajoute seulement ce que tu connais.</div>
    <label>Nom</label><input id="mp-name" placeholder="mon-serveur">
    <label>Commande (serveur local)</label><input id="mp-cmd" placeholder="npx">
    <label>Arguments</label><input id="mp-args" placeholder="-y paquet-du-serveur@1.2.3">
    <label>…ou adresse (serveur distant)</label><input id="mp-url" placeholder="https://exemple.com/mcp">
    <label>Variables secrètes (facultatif) : une par ligne, NOM=valeur</label><textarea id="mp-secrets" rows="2" placeholder="MON_JETON=…" autocomplete="off" spellcheck="false"></textarea>
    <small class="subtle">Chiffrées sur ce PC, jamais affichées. Écris \${NOM} dans les arguments ou l'adresse à la place du secret ; un secret écrit en clair est refusé.</small>
    <p class="warn" id="card-msg"></p><div class="bottom"><button class="btn subtle" data-close-card="1">Annuler</button><button class="btn main" id="mp-ok">Ajouter</button></div>`;
  $("#custom-card").hidden = false;
  $("#mp-ok").onclick = async () => {
    const secrets = {};
    $("#mp-secrets").value.split(/\r?\n/).map((l) => l.trim()).filter(Boolean).forEach((l) => { const i = l.indexOf("="); if (i > 0) secrets[l.slice(0, i).trim()] = l.slice(i + 1).trim(); });
    try { const r = await api("/api/library/mcp-custom", { name: $("#mp-name").value, command: $("#mp-cmd").value, arguments: $("#mp-args").value, url: $("#mp-url").value, secrets });
      infoBubble(r.message); $("#custom-card").hidden = true; customTab = "installed"; saveExtensionFilters(); showCustom(); }
    catch (e) { $("#card-msg").textContent = e.message; }
  };
}
document.addEventListener("click", async (ev) => {
  if (view !== "custom" && $("#custom-card").hidden) return;
  const t = ev.target;
  const attempts = t.closest("[data-try_action]"); if (attempts) { ev.stopPropagation(); return tryCustom(attempts.dataset.try_action); }
  const ins = t.closest("[data-install-p]"); if (ins) { ev.stopPropagation(); ins.disabled = true; await installCustom(ins.dataset.installP, !!ins.dataset.fromCard); ins.disabled = false; return; }
  const ret = t.closest("[data-remove-p]");
  if (ret) { if (!confirm("Retirer ? Rien n'est effacé : une skill est rangée dans Archives.")) return;
    try { const r = await api("/api/library/remove", { id: ret.dataset.removeP, type: ret.dataset.type }); infoBubble(r.message); $("#custom-card").hidden = true; showCustom(); } catch (e) { $("#card-msg").textContent = e.message; } return; }
  if (t.closest("[data-close-card]") || t.id === "custom-card") { $("#custom-card").hidden = true; return; }
  const f = t.closest("[data-card]"); if (f && !t.closest("#custom-card-body")) return elementSheet(f.dataset.card);
});
document.addEventListener("keydown", (e) => { if (e.key === "Escape" && !$("#custom-card").hidden) $("#custom-card").hidden = true; });

/* --- First launch: a 3-screen guide (an AI, a project, ready), then an optional guided tour.
   Nothing installs without a click: each install opens a visible window on the PC. */
const LOGOS = {};
async function logo(name) {
  if (!(name in LOGOS)) LOGOS[name] = fetch(`/logos/${name}.svg`).then((r) => (r.ok ? r.text() : "")).catch(() => "");
  return LOGOS[name];
}
async function placeLogos(rootDir) {
  for (const el of rootDir.querySelectorAll("[data-logo]")) {
    const svg = await logo(el.dataset.logo);
    if (svg) el.innerHTML = svg.replace(/<title>.*?<\/title>/, "");
  }
}
const CLOUD_WELCOME = [
  ["openrouter", "openrouter", "OpenRouter", "Tous les modèles, dont des gratuits"], ["openai", "openai", "OpenAI", "GPT"],
  ["anthropic", "anthropic", "Anthropic", "Claude par clé"], ["gemini", "gemini", "Google Gemini", "Gemini"],
  ["mistral", "mistral", "Mistral", "Européen"], ["deepseek", "deepseek", "DeepSeek", "Peu cher"],
  ["xai", "xai", "xAI", "Grok"], ["moonshot", "kimi", "Moonshot", "Kimi"], ["groq", "groq", "Groq", "Très rapide"],
];
/* First-launch guide: 3 short screens (an AI for the Supervisor, a project, ready), « Passer » on each. The current
   screen is recorded on the PC: a studio stopped halfway resumes there. From Réglages, the AI and GitHub screens open
   alone (outside the guide); everything skipped stays doable there or with the « ＋ » button of the projects. */
const GUIDE = [["ai", "1 · Ton IA"], ["project", "2 · Ton projet"], ["ready", "3 · Prêt"]];
let welcome = null, welcomeStep = "ai", welcomeTimer = null, guideMode = false, guideProject = "", onProjectAdded = null;
const checked = (ok) => (ok ? "<span class=\"ok checked-a\">✓</span>" : "");
async function openWelcome(stage, guide = guideMode, known = null) {
  if (stage) welcomeStep = stage;
  guideMode = guide;
  let el = $("#welcome");
  if (!el) {
    el = document.createElement("div");
    el.id = "welcome"; el.setAttribute("role", "dialog"); el.setAttribute("aria-modal", "true"); el.setAttribute("aria-label", "Bienvenue");
    document.body.appendChild(el);
    el.addEventListener("click", welcomeClick);
  }
  el.hidden = false;
  if (!el.innerHTML) el.innerHTML = "<div class=\"welcome-dialog card\"><p class=\"empty\">…</p></div>";
  if (known) welcome = known;                       // state just read at startup: no second (slow) read
  else try { welcome = await api("/api/welcome"); } catch (e) { el.firstChild.innerHTML = `<p class="bad">${esc(e.message)}</p>`; return; }
  renderWelcome();
}
const openGuide = (stage) => openWelcome(GUIDE.some(([k]) => k === stage) ? stage : "ai", true);
function startGuideIfNeeded(d) {          // studio opened: the guide only for a new studio, at the recorded screen
  welcome = d;
  if (d.distant || !d.guide || !d.guide.show) return false;
  openWelcome(GUIDE.some(([k]) => k === d.guide.step) ? d.guide.step : "ai", true, d);
  return true;
}
async function guideMove(next, how) {    // how: "done" (screen completed), "skipped" (« Passer ») or nothing (« Retour »)
  const body = { step: next };
  if (how) body[how] = welcomeStep;
  try { await api("/api/welcome/record", body); } catch (e) { /* the screen changes anyway; only the resume point is lost */ }
  if (!welcome) return openWelcome(next, true);
  welcomeStep = next; guideMode = true;              // no reload of the state (slow: PC, Git): the screen changes at once
  renderWelcome();
}
async function guideFinish(visit) {
  try { await api("/api/welcome/record", { finished: true, done: "ready" }); } catch (e) { /* shown again next time */ }
  $("#welcome").hidden = true; guideMode = false; aiState = null; loadConversation(false);
  if (guideProject) openProject(guideProject);
  if (visit) launchTour();
}
function aiTiles(d) {
  const subscription = (key, logoName, title, subdir, e) => `<div class="tile-a${e.connected ?" faite" : ""}"><span class="logo-a" data-logo="${logoName}"></span>
    <span class="txt-a"><b>${title}</b><small>${subdir}</small></span>${checked(e.connected)}
    ${e.connected ? "" : e.installed ? `<button class="btn main small" data-subscription-connection="${key}">Se connecter</button>`
      : `<button class="btn small" data-install-tool="${key}">Installer</button>`}</div>`;
  const already = new Set(d.connections.map((c) => c.provider));
  const o = d.ollama, advice = (d.recommended || []).filter((m) => m.fits !== "too_big");
  const local_runnerConnected = already.has("ollama");
  let local;
  if (!o.installed) local = `<button class="btn" data-install-tool="ollama">Installer Ollama</button> <a class="link" href="${esc(o.link)}" target="_blank" rel="noopener">ou depuis son site</a>`;
  else if (!o.open) local = `<button class="btn" id="a-local-runner-open">Ouvrir Ollama</button>`;
  else if (!advice.length) local = `<p class="management-help">Ton PC est un peu juste pour une IA locale (${d.pc.ram_gb || "?"} Go de mémoire). Prends plutôt une IA cloud : OpenRouter propose des modèles gratuits.</p>`;
  else local = `<p class="management-help">Choisis un modèle${d.pc.vram_gb ? ` (carte graphique : ${d.pc.vram_gb} Go` : ` (mémoire : ${d.pc.ram_gb || "?"} Go`}${d.pc.vram_gb && d.pc.ram_gb ? `, mémoire : ${d.pc.ram_gb} Go)` : ")"} :</p>
    <div class="models-a">${advice.map((m) => { const inst = o.models.some((n) => n === m.name || n.startsWith(m.name + ":") || m.name.startsWith(n));
      return `<div class="model-a${m.recommended ?" recommended" : ""}"><span><b>${esc(m.title)}</b>${m.recommended ? ' <span class="tag-a">conseillé</span>' : ""}<small>≈ ${m.memory_gb ?? "?"} Go · ${m.fits === "fast" ? "rapide sur ta carte graphique" : m.fits === "possible" ? "possible, plus lent" : "à essayer"}${m.note ? " · " + esc(m.note) : ""}</small></span>
      <span class="act-a" data-progress="${esc(m.name)}">${inst ? (local_runnerConnected ? '<span class="ok">Prêt</span>' : `<button class="btn main small" data-use-local="${esc(m.name)}">Utiliser</button>`) : `<button class="btn small" data-install-local="${esc(m.name)}">Installer</button>`}</span></div>`; }).join("")}</div>`;
  return `<p class="title-a">Avec un abonnement</p><div class="grid-a">
      ${subscription("claude", "claude", "Claude", "Abonnement Pro ou Max", d.claude)}${subscription("codex", "openai", "ChatGPT", "Abonnement Plus ou Pro (Codex)", d.codex)}</div>
    <p class="title-a">Avec une clé API (paiement à l'usage)</p><div class="grid-a">
      ${CLOUD_WELCOME.map(([f, l, t, s]) => `<button class="tile-a button-a${already.has(f) ?" faite" : ""}" data-cloud-key="${f}"><span class="logo-a" data-logo="${l}"></span><span class="txt-a"><b>${t}</b><small>${s}</small></span>${checked(already.has(f))}</button>`).join("")}
      <button class="tile-a button-a" data-other-ai="1"><span class="logo-a">＋</span><span class="txt-a"><b>Autre IA</b><small>Compatible OpenAI (adresse)</small></span></button></div>
    <p class="title-a">Ou sur ton PC (gratuit, privé)</p><div class="tile-a large${local_runnerConnected ?" faite" : ""}"><span class="logo-a" data-logo="ollama"></span><span class="txt-a"><b>Ollama</b><small>${o.installed ? (o.open ? "ouvert" : "installé, fermé") : "pas encore installé"}</small></span>${checked(local_runnerConnected)}</div>
    <div class="local-a">${local}</div>`;
}
function renderWelcome() {
  const d = welcome, el = $("#welcome");
  if (!d || !el || el.hidden) return;
  const stages = guideMode ? `<div class="stages-a">${GUIDE.map(([k, t]) => `<span class="${k === welcomeStep ? "active" : ""}">${t}</span>`).join("")}</div>` : "";
  const skip = (next) => `<button class="btn subtle" data-guide-skip="${next}">Passer</button>`;
  const close = "<button class=\"btn subtle\" data-close-welcome=\"1\">Fermer</button>";
  let requestBody = "";
  if (welcomeStep === "github") {
    const g = d.git;
    requestBody = `<h1>GitHub <small class="subtle">(facultatif)</small></h1><p class="sub-a">Pour sauvegarder et partager tes projets en ligne.</p>
      <div class="grid-a">
        <div class="tile-a${g.installed ?" faite" : ""}"><span class="logo-a" data-logo="git"></span><span class="txt-a"><b>Git</b><small>${g.installed ? "installé" : "suivi des versions de tes projets"}</small></span>${checked(g.installed)}
          ${g.installed ? "" : `<button class="btn small" data-install-tool="git">Installer</button>`}</div>
        <div class="tile-a${g.github ?" faite" : ""}"><span class="logo-a" data-logo="github"></span><span class="txt-a"><b>GitHub</b><small>${g.github ? "connecté" : "ton compte (gratuit)"}</small></span>${checked(g.github)}
          ${g.github || !g.installed ? "" : `<button class="btn main small" id="a-github">Se connecter</button>`}</div></div>
      <p class="management-help">Pas de compte ? <a href="https://github.com/signup" target="_blank" rel="noopener">Crée-le ici</a>, puis « Se connecter ».</p>
      <p class="warn" id="msg-welcome"></p>
      <div class="bottom-a">${close}<button class="btn subtle" id="a-verify">Vérifier</button></div>`;
  } else if (welcomeStep === "ai" || !guideMode) {
    welcomeStep = "ai";
    const tiles = aiTiles(d);
    requestBody = guideMode
      ? `<h1>Ton IA</h1><p class="sub-a">Connecte une IA : c'est elle qui fait parler ton Superviseur.</p>
        ${d.ready ? `<p class="ok">✓ Une IA est prête pour le Superviseur.</p><details class="more-a"><summary>Connecter une autre IA</summary>${tiles}</details>` : tiles}
        <p class="warn" id="msg-welcome"></p>
        <div class="bottom-a">${skip("project")}<button class="btn subtle" id="a-verify">Vérifier</button>
          <button class="btn main" data-guide-next="project"${d.ready ? "" : " disabled"}>Continuer</button></div>`
      : `<h1>Connecter une IA</h1><p class="sub-a">Abonnement, clé ou IA sur ton PC : tu peux en connecter plusieurs.</p>${tiles}
        <p class="warn" id="msg-welcome"></p>
        <div class="bottom-a">${close}<button class="btn subtle" id="a-verify">Vérifier</button></div>`;
  } else if (welcomeStep === "project") {
    const list = (d.targets || []).map((x) => `<button class="tile-a button-a${x.key === guideProject ? " faite" : ""}" data-guide-project="${esc(x.key)}"><span class="logo-a">${x.kind === "project" ? "▣" : "◇"}</span>
      <span class="txt-a"><b>${esc(x.name)}</b><small>${x.kind === "project" ? "projet" : "sujet"}</small></span>${checked(x.key === guideProject)}</button>`).join("");
    requestBody = `<h1>Ton projet</h1><p class="sub-a">Choisis un projet ou ajoute le dossier d'un projet de ton PC.</p>
      <div class="grid-a">${list}<button class="tile-a button-a" data-guide-add="1"><span class="logo-a">＋</span><span class="txt-a"><b>Ajouter un projet</b><small>un dossier de ton PC</small></span></button></div>
      <p class="warn" id="msg-welcome"></p>
      <div class="bottom-a"><button class="btn subtle" data-guide-back="ai">Retour</button>${skip("ready")}
        <button class="btn main" data-guide-next="ready"${guideProject ? "" : " disabled"}>Continuer</button></div>`;
  } else {
    requestBody = `<h1>Ton studio est prêt</h1><p class="sub-a">Écris au Superviseur ce que tu veux faire, en une phrase.</p>
      ${d.ready ? "" : "<p class=\"management-help\">Sans IA, le Superviseur ne répond pas : connecte-en une dans Réglages › IA.</p>"}
      ${guideProject || (d.targets || []).length ? "" : "<p class=\"management-help\">Ajoute un projet quand tu veux avec le bouton ＋.</p>"}
      <div class="bottom-a"><button class="btn subtle" data-guide-back="project">Retour</button><button class="btn" data-finish-welcome="without">Commencer</button><button class="btn main" data-finish-welcome="visit">Visite guidée (1 min)</button></div>`;
  }
  el.innerHTML = `<div class="welcome-dialog card">${stages}${requestBody}</div>`;
  placeLogos(el);
  trackInstalls();
}
async function trackInstalls() {
  clearTimeout(welcomeTimer);
  if (welcomeStep !== "ai" || !welcome || !welcome.ollama.open || $("#welcome")?.hidden) return;
  let loc;
  try { loc = await api("/api/local-models"); } catch { return; }
  let busy = false;
  for (const [name, e] of Object.entries(loc.models || {})) {
    const p = e.progress, place = $(`#welcome [data-progress="${CSS.escape(name)}"]`);
    if (!place || !p) continue;
    if (p.state === "downloading") { busy = true; place.innerHTML = `<span class="info">${p.pct} %</span>`; }
    else if (p.state === "error") place.innerHTML = `<span class="bad" title="${esc(p.message)}">Échec</span> <button class="btn subtle small" data-install-local="${esc(name)}">Réessayer</button>`;
    else if (p.state === "finished") place.innerHTML = `<button class="btn main small" data-use-local="${esc(name)}">Utiliser</button>`;
  }
  if (busy) welcomeTimer = setTimeout(trackInstalls, 2000);
}
async function welcomeClick(ev) {
  const t = ev.target, msg = (m, ok) => { const el = $("#msg-welcome"); if (el) { el.textContent = m || ""; el.className = ok ? "ok" : "warn"; } };
  const b = t.closest("button");
  if (!b) return;
  try {
    if (b.dataset.guideSkip) return await guideMove(b.dataset.guideSkip, "skipped");
    if (b.dataset.guideNext) return await guideMove(b.dataset.guideNext, "done");
    if (b.dataset.guideBack) return await guideMove(b.dataset.guideBack, "");
    if (b.dataset.guideProject) { guideProject = b.dataset.guideProject; return await guideMove("ready", "done"); }
    if (b.dataset.guideAdd) {
      onProjectAdded = (key, name) => {
        if (!welcome.targets.some((x) => x.key === key)) welcome.targets.push({ key, name: name || key, kind: key.split(":")[0] });
        guideProject = key; guideMove("ready", "done");
      };
      return newProject();
    }
    if (b.dataset.finishWelcome) return await guideFinish(b.dataset.finishWelcome === "visit");
    if (b.dataset.closeWelcome) { $("#welcome").hidden = true; return; }
    if (b.id === "a-verify") { b.disabled = true; msg("Vérification…", true); await openWelcome(); return; }
    if (b.dataset.cloudKey) return connectCloud(b.dataset.cloudKey, "", () => openWelcome());
    if (b.dataset.otherAi) { $("#welcome").hidden = true; return standard_apiSettings(); }
    if (b.dataset.subscriptionConnection) { b.disabled = true; const r = await api(b.dataset.subscriptionConnection === "claude" ? "/api/claude/connection" : "/api/codex/connection", {}); msg(r.info, true); return; }
    if (b.id === "a-local-runner-open") { b.disabled = true; b.textContent = "Ouverture…"; await api("/api/local-models/start", {}); return openWelcome(); }
    if (b.dataset.installLocal) { b.disabled = true; await api("/api/local-models/install", { name: b.dataset.installLocal }); return trackInstalls(); }
    if (b.dataset.useLocal) { b.disabled = true; await api("/api/ai/add", { provider: "ollama", model: b.dataset.useLocal }); infoBubble("IA locale connectée."); return openWelcome(); }
    if (b.id === "a-github") { b.disabled = true; const r = await api("/api/welcome/github", {}); msg(r.info, true); return; }
  } catch (e) { msg(e.message); b.disabled = false; }
}
/* Install a tool (coding agents, Ollama, Git): button usable everywhere (home, cloud connection). */
document.addEventListener("click", async (ev) => {
  const b = ev.target.closest("[data-install-tool]");
  if (!b) return;
  ev.stopPropagation();
  const names = { claude: "Claude Code", codex: "Codex", ollama: "Ollama", git: "Git" }, name = names[b.dataset.installTool];
  if (!confirm(`Installer ${name} ? Une fenêtre s'ouvre sur le PC avec l'installation officielle ; tu peux la fermer à tout moment.`)) return;
  b.disabled = true;
  try {
    const r = await api("/api/welcome/install", { tool: b.dataset.installTool });
    const place = $("#msg-welcome") || $("#card-msg");
    const text = r.info + (r.command ? ` Commande : ${r.command}` : "");
    if (place) { place.textContent = text; place.className = r.ok ? "ok" : "warn"; } else infoBubble(text);
    if (r.link) window.open(r.link, "_blank", "noopener");
    b.textContent = "Vérifier après l'installation"; b.disabled = false; b.removeAttribute("data-install-tool"); b.id = "a-verify";
  } catch (e) { infoBubble(e.message); b.disabled = false; }
}, true);

/* Guided tour: a few bubbles placed on the real areas of the studio. Replayable with the « Guide » button. */
const TOUR = [
  ["#supervisor", "Le Superviseur", "Ton point d'entrée : décris ce que tu veux, en une phrase. Il répond, ou propose une tâche avec un bouton « Lancer ». Rien ne part sans ton clic."],
  ["#block-work", "Le travail", "Les tâches lancées apparaissent ici. Quand une tâche est finie, tu la relis puis tu cliques « Valider » (ou tu demandes une correction)."],
  ["#plus-p", "Tes projets", "Ajoute un projet (un dossier de ton PC) : chaque projet a son onglet, son équipe d'agents et son mode Rapide, Normal ou Performance."],
  ["nav [data-view=\"custom\"]", "Extensions", "Des skills (savoir-faire) et des connecteurs (outils, logiciels) en un clic, pour toutes tes IA."],
  ["nav [data-view=\"management\"]", "Gestion", "Les agents, les modèles et leurs classements, ce que consomme chaque IA, la mémoire partagée et les skills."],
  ["#system", "Ton PC", "Processeur, mémoire et carte graphique en direct : utile quand une IA tourne sur ton PC."],
  ["#guide", "Revoir ce guide", "Ce bouton relance la visite quand tu veux. Bonne mission !"],
];
let tourStep = 0;
function launchTour() {
  if (view !== "projects") document.querySelector("nav [data-view=\"projects\"]")?.click();
  tourStep = 0; showStep();
}
function finishTour() {
  $("#visit")?.remove(); $$(".target-visit").forEach((x) => x.classList.remove("target-visit"));
  api("/api/welcome/record", { visit: true }).catch(() => {});
}
function showStep() {
  $$(".target-visit").forEach((x) => x.classList.remove("target-visit"));
  let step = TOUR[tourStep];
  while (step && !(document.querySelector(step[0])?.offsetParent)) step = TOUR[++tourStep];   // hidden area (small screen): skipped
  if (!step) return finishTour();
  const target = document.querySelector(step[0]);
  target.classList.add("target-visit");
  target.scrollIntoView({ block: "nearest" });
  let bubble = $("#visit");
  if (!bubble) { bubble = document.createElement("div"); bubble.id = "visit"; bubble.setAttribute("role", "dialog"); document.body.appendChild(bubble); }
  const last = TOUR.slice(tourStep + 1).every((p) => !document.querySelector(p[0])?.offsetParent);
  bubble.innerHTML = `<b>${esc(step[1])}</b><p>${esc(step[2])}</p><div class="bottom-a"><small class="subtle">${tourStep + 1}/${TOUR.length}</small>
    <button class="btn subtle small" id="v-skip">Passer</button><button class="btn main small" id="v-next">${last ? "Terminer" : "Suivant"}</button></div>`;
  const r = target.getBoundingClientRect(), l = Math.min(340, innerWidth - 32);
  bubble.style.width = l + "px";
  bubble.style.left = Math.max(16, Math.min(innerWidth - l - 16, r.left + r.width / 2 - l / 2)) + "px";
  const h = bubble.offsetHeight;
  bubble.style.top = (r.bottom + h + 16 < innerHeight ? r.bottom + 12 : Math.max(16, r.top - h - 12)) + "px";
  $("#v-skip").onclick = finishTour;
  $("#v-next").onclick = () => { tourStep++; showStep(); };
  $("#v-next").focus();
}
document.addEventListener("keydown", (e) => { if (e.key === "Escape" && $("#visit")) finishTour(); });
if ($("#guide")) $("#guide").onclick = launchTour;
api("/api/welcome").then(startGuideIfNeeded).catch(() => {});

/* --- Language (Réglages › Langue): in English, the main interface labels are translated at display time
   (exact match of short texts: never the content of tasks, files or messages). */
const EN = {
  "Projets": "Projects", "Extensions": "Extensions", "Gestion": "Manage", "Fermer": "Close", "Guide": "Guide", "◆ Accueil": "◆ Home",
  "Salut.": "Hi.", "Tâches": "Tasks", "Réglages": "Settings", "À valider": "To review", "En cours": "In progress", "Terminées": "Done",
  "Rien à valider.": "Nothing to review.", "Rien en cours.": "Nothing in progress.", "Superviseur": "Supervisor", "Envoyer": "Send",
  "Modèle": "Model", "Effort": "Effort", "Mode": "Mode", "Auto": "Auto", "Bas": "Low", "Moyen": "Medium", "Élevé": "High", "Très élevé": "Very high",
  "Rapide": "Fast", "Normal": "Normal", "Performance": "Performance", "Lancer": "Launch", "Ignorer": "Ignore", "Cette nuit": "Tonight",
  "Modifier la demande": "Edit request", "Valider": "Approve", "Corriger": "Request changes", "Annuler": "Cancel", "Ajouter": "Add",
  "Détail": "Details", "Équipe": "Team", "Fichiers": "Files", "Branches": "Branches", "Projet": "Project", "Ouvrir": "Open", "Dossier": "Folder",
  "Voir la tâche": "View task", "Agents et outils": "Agents & tools", "Mémoire et skills": "Memory & skills", "Agents": "Agents",
  "Créer un agent": "Create an agent", "Modèles et benchmarks": "Models & benchmarks", "Usage": "Usage", "Limites et alertes": "Limits & alerts",
  "Outils et entretien": "Tools & maintenance", "Entretien": "Maintenance", "Skills et documents": "Skills & documents",
  "Audits des agents": "Agent audits", "Mémoire partagée": "Shared memory", "Lecture": "Reader", "IA": "AI", "Réglages du studio": "Studio settings",
  "Téléphone": "Phone", "Découvrir": "Discover", "Connecteurs": "Connectors", "Skills": "Skills", "Installé": "Installed", "＋ Ajouter": "＋ Add",
  "Par catégorie": "By category", "Par nom": "By name", "Nouveautés d'abord": "Newest first", "Importer une skill (.zip)": "Import a skill (.zip)",
  "Créer une skill avec le Superviseur": "Create a skill with the Supervisor", "Ajouter un serveur MCP": "Add an MCP server",
  "Ajouter un logiciel du PC": "Add a PC app", "Fichiers ou images": "Files or images", "Un dossier": "A folder",
  "Mode des agents pour ce projet": "Agent mode for this project", "Modifier le contexte": "Edit context", "Contexte du projet": "Project context",
  "Retirer ce projet du studio": "Remove this project from the studio", "À enregistrer (commit)": "To save (commit)",
  "Choisis une tâche pour voir son avancement et la valider.": "Pick a task to see its progress and approve it.",
  "Clique un skill ou un document pour le lire ici.": "Click a skill or document to read it here.", "Travail": "Work",
  "Tes résultats": "Your results", "Détails du jour": "Today's details", "Classement global": "Overall ranking",
  "Connecter": "Connect", "Installer": "Install", "Désinstaller": "Uninstall", "Se connecter": "Sign in", "Vérifier": "Check",
  "Continuer": "Continue", "Plus tard": "Later", "Retour": "Back", "Passer": "Skip", "Commencer": "Start", "Suivant": "Next", "Terminer": "Finish",
  "Bienvenue dans ton studio": "Welcome to your studio", "Avec un abonnement": "With a subscription",
  "Avec une clé API (paiement à l'usage)": "With an API key (pay as you go)", "Ou sur ton PC (gratuit, privé)": "Or on your PC (free, private)",
  "1 · Ton IA": "1 · Your AI", "2 · Ton projet": "2 · Your project", "3 · Prêt": "3 · Ready", "Ton IA": "Your AI", "Ton projet": "Your project",
  "Connecte une IA : c'est elle qui fait parler ton Superviseur.": "Connect an AI: it is what makes your Supervisor talk.",
  "✓ Une IA est prête pour le Superviseur.": "✓ An AI is ready for the Supervisor.", "Connecter une autre IA": "Connect another AI",
  "Abonnement, clé ou IA sur ton PC : tu peux en connecter plusieurs.": "Subscription, key or AI on your PC: you can connect several.",
  "Choisis un projet ou ajoute le dossier d'un projet de ton PC.": "Pick a project or add a project folder from your PC.",
  "Ajouter un projet": "Add a project", "un dossier de ton PC": "a folder on your PC", "projet": "project", "sujet": "topic",
  "Ton studio est prêt": "Your studio is ready", "Écris au Superviseur ce que tu veux faire, en une phrase.": "Tell the Supervisor what you want to do, in one sentence.",
  "Sans IA, le Superviseur ne répond pas : connecte-en une dans Réglages › IA.": "Without an AI the Supervisor cannot answer: connect one in Settings › AI.",
  "Ajoute un projet quand tu veux avec le bouton ＋.": "Add a project whenever you want with the ＋ button.",
  "Pour sauvegarder et partager tes projets en ligne.": "To back up and share your projects online.", "(facultatif)": "(optional)",
  "Git et GitHub (facultatif)": "Git and GitHub (optional)", "Connecter GitHub": "Connect GitHub", "Guide de démarrage": "Getting started guide",
  "Rouvrir": "Reopen", "ouvert": "open", "installé, fermé": "installed, closed", "pas encore installé": "not installed yet",
  "Visite guidée (1 min)": "Guided tour (1 min)", "Autre IA": "Other AI", "Utiliser": "Use", "Prêt": "Ready", "conseillé": "recommended",
  "Partir de": "Start from", "Vide": "Empty", "Site web": "Website", "Jeu vidéo": "Video game", "Application": "App", "Document": "Document", "Images": "Images",
  "Ajouter un projet ou un sujet": "Add a project or topic", "Projet (avec dossier)": "Project (with folder)", "Sujet (sans dossier)": "Topic (no folder)",
  "Étape": "Step", "Modèle exact": "Exact model", "Entrée": "Input", "Sortie": "Output", "Relecture": "Review", "Bilan": "Report",
  "Aucune IA connectée pour l'instant.": "No AI connected yet.", "Connecter une IA": "Connect an AI", "en cours": "in progress", "à valider": "to review",
  "validée": "approved", "annulée": "cancelled", "terminée": "done", "échec": "failed", "bloquée": "blocked", "interrupted": "interrupted",
};
const EN_PH = { "Pose une question ou décris un travail · @ fichier · / raccourci": "Ask a question or describe a job · @ file · / shortcut",
  "Rechercher…": "Search…", "Chercher (texte, projet…)": "Search (text, project…)", "Chercher (texte, résumé…)": "Search (text, summary…)",
  "Nom (ex. Mon site web)": "Name (e.g. My website)", "Dossier du projet (C:\\…)": "Project folder" };
const TOUR_EN = [
  ["The Supervisor", "Your starting point: describe what you want in one sentence. It answers, or proposes a task with a “Launch” button. Nothing starts without your click."],
  ["The work", "Launched tasks show up here. When a task is done, review it and click “Approve” (or ask for changes)."],
  ["Your projects", "Add a project (a folder on your PC): each project gets its tab, its agent team and its Fast, Normal or Performance mode."],
  ["Extensions", "Skills (know-how) and connectors (tools, apps) in one click, for all your AIs."],
  ["Manage", "Agents, models and their rankings, what each AI costs, shared memory and skills."],
  ["Your PC", "Live CPU, memory and graphics card: handy when an AI runs on your PC."],
  ["Replay this guide", "This button replays the tour whenever you want. Good luck on your mission!"],
];
function translateNode(rootDir) {
  const walker = document.createTreeWalker(rootDir, NodeFilter.SHOW_TEXT);
  for (let n = rootDir.nodeType === 3 ? rootDir : walker.nextNode(); n; n = walker.nextNode()) {
    const t = n.nodeValue.trim();
    if (t && t.length < 90 && EN[t]) n.nodeValue = n.nodeValue.replace(t, EN[t]);
  }
  if (rootDir.querySelectorAll) [rootDir, ...rootDir.querySelectorAll("[placeholder]")].forEach((x) => { if (x.placeholder && EN_PH[x.placeholder]) x.placeholder = EN_PH[x.placeholder]; });
}
function enableEnglish() {
  document.documentElement.lang = "en";
  TOUR.forEach((p, i) => { if (TOUR_EN[i]) [p[1], p[2]] = TOUR_EN[i]; });
  translateNode(document.body);
  new MutationObserver((ms) => { for (const m of ms) for (const n of m.addedNodes) if (n.nodeType === 1 || n.nodeType === 3) translateNode(n); })
    .observe(document.body, { childList: true, subtree: true });
}
api("/api/session").then((s) => { if (s && s.language === "en") enableEnglish(); }).catch(() => {});


/* Choix facultatif par tâche : les valeurs sont revalidées côté serveur au clic. */
async function fillTaskAI(select, current = "") {
  select.disabled = true;
  try {
    const d = aiState = await api("/api/ai");
    const items = [["", "Celle de l’agent (par défaut)"]];
    if (d.claude) items.push(["claude-code", TOOL_LABELS["claude-code"]]);
    if (d.codex) items.push(["codex", TOOL_LABELS.codex]);
    d.connections.filter((c) => c.provider !== "elevenlabs").forEach((c) => items.push([c.id, c.name]));
    if (current && !items.some(([id]) => id === current)) items.push([current, "IA demandée · plus connectée"]);
    listChoice(select, items, current, () => {});
  } finally { select.disabled = false; }
}
$("#new-task").onclick = async () => {
  if (!currentProject) return;
  const target = currentProject, dialog = $("#task-dialog");
  const organization = await api("/api/organization");
  dialog.innerHTML = `<form class="dialog-card card" style="min-width:min(580px,85vw)">
    <h2>Nouvelle tâche</h2><label>Titre<input class="field" name="title" maxlength="70"></label>
    <label>Demande<textarea name="request" rows="6" required maxlength="8000"></textarea></label>
    <label>Agent<select name="role"><option value="">Choisi par le studio</option>${organization.team.filter((r) => r.id !== "reviewer").map((r) => `<option value="${esc(r.id)}">${esc(r.name)}</option>`).join("")}</select></label>
    <label>IA pour cette tâche<select name="ai"></select></label>
    <div class="task-model-effort"><label>Modèle<select name="model"></select></label><label>Effort<select name="effort"><option value="auto">Auto</option></select></label></div>
    <label><input type="checkbox" name="express"> Tâche express (rapide, validation du diff par toi)</label>
    <p class="warn" role="alert"></p><div class="bottom"><button type="button" class="btn subtle" data-cancel>Annuler</button><button type="submit" class="btn main">Lancer</button></div></form>`;
  const form = dialog.querySelector("form");
  await fillTaskAI(form.elements.ai);
  let taskChoiceRevision = 0;
  const taskChoices = async () => {
    const revision = ++taskChoiceRevision, controls = form.elements;
    controls.model.disabled = controls.effort.disabled = true;
    const cap = await api("/api/ai/efforts", { id: controls.ai.value, role: controls.role.value, target });
    if (revision !== taskChoiceRevision) return;
    form.dataset.resolvedRole = cap.role || controls.role.value;
    form.dataset.resolvedModel = cap.model || "";
    const connection = aiState.connections.find((c) => c.id === cap.id);
    controls.model.dataset.connection = connection?.id || "";
    listChoice(controls.model, [["", `Auto${cap.model ? " · " + cap.model : ""}`], ...(cap.models || []).map((m) => [m, m])], "", () => {});
    if (connection) await loadRoleModels(controls.model, connection.id);
    else controls.model.disabled = false;
    if (revision !== taskChoiceRevision) return;
    controls.model.onchange = () => loadEffortChoices(controls.effort, cap.id, controls.model.value || cap.model, controls.role.value, target);
    await loadEffortChoices(controls.effort, cap.id, cap.model, controls.role.value, target);
  };
  form.elements.ai.onchange = form.elements.role.onchange = () => taskChoices().catch((e) => form.querySelector('[role="alert"]').textContent = e.message);
  await taskChoices();
  dialog.querySelector("[data-cancel]").onclick = () => dialog.close();
  form.onsubmit = async (event) => {
    event.preventDefault();
    if (form.elements.effort.dataset.loadingEffort || form.elements.model.disabled) { form.querySelector('[role="alert"]').textContent = "Attends le chargement des modèles et des efforts ou réessaie."; return; }
    const submit = form.querySelector('[type="submit"]'); submit.disabled = true;
    try {
      const r = await api("/api/tasks", { target, title: form.elements.title.value, request: form.elements.request.value, role: form.elements.role.value || (form.elements.effort.value !== "auto" ? form.dataset.resolvedRole : ""),
        ai: form.elements.ai.value, model: form.elements.model.value || (form.elements.effort.value !== "auto" ? form.dataset.resolvedModel : ""), effort: form.elements.effort.value || "auto",
        ...(form.elements.express.checked ? { mode: "fast", manual_approval: true } : {}) });
      dialog.close(); selection = r.tid; lastView = ""; show();
    } catch (error) { form.querySelector('[role="alert"]').textContent = error.message; } finally { submit.disabled = false; }
  };
  dialog.showModal(); form.elements.request.focus();
};
