/* First launch: one click (optional first name, suggested folder) → creation, then the studio opens on its short guide
   (an AI, a project, ready). « Passer » creates the studio with the suggested values: first name and folder stay
   changeable later (Réglages; an existing studio folder can be joined from another PC). */
const $ = (s) => document.querySelector(s);
async function api(path, body) {
  const opt = body === undefined ? {} : { method: "POST", headers: { "Content-Type": "application/json", "X-Studio": "1" }, body: JSON.stringify(body) };
  const r = await fetch(path, opt);
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.error || r.status);
  return j;
}
// Language of the studio: interface texts AND folder names (Projets/Projects…), chosen once here.
const TEXTS = {
  en: { title: "Welcome to your AI studio", sub: "One click to create your studio, the rest comes right after.", skip: "Skip",
        firstName: "Your first name", optional: "(optional)", folder: "Studio folder:", change: "change",
        "help-folder": "Your rules, skills, tasks, memory and backups will live here. Your projects stay where they are. Already have a studio (other PC, backup)? Pick its folder: it will be reused as is.",
        browse: "Browse…", create: "Create my studio", summary: "Reuse this studio", creating: "Creating…",
        ready: "Studio created", reused: "Studio reused", opening: "Opening the studio…",
        slow: "The studio is slow to start: launch it again from its icon." },
};
const FR = {};
document.querySelectorAll("[data-t]").forEach((el) => (FR[el.dataset.t] = el.textContent));
Object.assign(FR, { create: "Créer mon studio", summary: "Reprendre ce studio", creating: "Création…", ready: "Studio créé",
  reused: "Studio repris", opening: "Ouverture du studio…", slow: "Le studio tarde à démarrer : relance-le depuis son icône." });
let language = (navigator.language || "fr").toLowerCase().startsWith("fr") ? "fr" : "en";
const t = (k) => (language === "en" ? TEXTS.en[k] : FR[k]);
function applyLanguage(l) {
  language = l;
  document.documentElement.lang = l;
  document.querySelectorAll("[data-t]").forEach((el) => (el.textContent = t(el.dataset.t)));
  document.querySelectorAll("[data-language]").forEach((b) => b.setAttribute("aria-pressed", String(b.dataset.language === l)));
  $("#name").placeholder = l === "en" ? "E.g. Alex" : "Ex. Alex";
  if (!$("#create").disabled) $("#create").textContent = t(lastCheck && lastCheck.join ? "summary" : "create");
}
let lastCheck = null;
document.querySelectorAll("[data-language]").forEach((b) => (b.onclick = () => applyLanguage(b.dataset.language)));
function showView(n) { document.querySelectorAll("section[data-stage]").forEach((s) => (s.hidden = +s.dataset.stage !== n)); }
let countdown = 0, valid = true, suggested = "";
async function check() {
  const d = $("#folder").value.trim();
  $("#folder-short").textContent = d;
  try {
    const v = await api("/api/verify", { folder: d });
    valid = v.ok; lastCheck = v;
    $("#info-folder").textContent = v.info || "";
    $("#info-folder").className = "info " + (v.ok ? "ok" : "warn");
    $("#create").textContent = t(v.join ? "summary" : "create");
    if (!v.ok) $("#fold-folder").open = true;
    return v;
  } catch (e) { valid = false; $("#info-folder").textContent = e.message; $("#info-folder").className = "info warn"; $("#fold-folder").open = true; }
}
$("#folder").addEventListener("input", () => { clearTimeout(countdown); countdown = setTimeout(check, 300); });
$("#browse").onclick = async () => {
  $("#browse").disabled = true;
  try { const r = await api("/api/browse", { folder: $("#folder").value }); if (r.folder) { $("#folder").value = r.folder; check(); } }
  finally { $("#browse").disabled = false; }
};
async function create(skipped) {
  if (skipped && suggested) { $("#name").value = ""; $("#folder").value = suggested; }   // « Passer »: the suggested values
  const v = await check();
  if (!v || !v.ok) return;
  $("#create").disabled = true; $("#skip").disabled = true; $("#info-create").textContent = t("creating"); $("#info-create").className = "info";
  try {
    const name = $("#name").value.trim();
    const r = await api("/api/create", { name: name, folder: $("#folder").value.trim(), packs: [], language: language });
    showView(2);
    $("#title-end").textContent = r.joined ? t("reused") : `${t("ready")}${name ? ", " + name : ""}`;
    $("#text-end").textContent = t("opening");
    openStudio(r.next_steps);
  } catch (e) { $("#info-create").textContent = e.message; $("#info-create").className = "info warn"; $("#create").disabled = false; $("#skip").disabled = false; }
}
$("#create").onclick = () => create(false);
$("#skip").onclick = () => create(true);
document.addEventListener("keydown", (e) => { if (e.key === "Enter" && e.target.id === "name") $("#create").click(); });
async function openStudio(nextUrl) {                  // the studio starts on the same port: wait until it responds
  for (let i = 0; i < 120; i++) {
    await new Promise((r) => setTimeout(r, 1000));
    try { const p = await (await fetch("/api/ping", { cache: "no-store" })).json(); if (p.studio) { location.href = nextUrl; return; } } catch { /* not yet */ }
  }
  $("#text-end").textContent = t("slow");
}
(async () => {
  try { const information = await api("/api/information"); suggested = information.folder; $("#folder").value = information.folder; check(); } catch (e) { $("#info-create").textContent = e.message; }
  applyLanguage(language);
  showView(1);
  $("#name").focus();
})();
setInterval(() => api("/api/presence", {}).catch(() => {}), 20000);
