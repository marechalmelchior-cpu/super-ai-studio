// decor.js — fond « Vide » : plongée sans fin dans l'ensemble de Mandelbrot, presque noir, filaments néon.
// Chaque plongée part d'une vue large, s'enfonce jusqu'à ~10 000× vers un point riche (vallée des hippocampes,
// spirales, mini-Mandelbrot…), s'éteint, puis repart ailleurs avec une autre teinte.
// WebGL pur, aucune dépendance, rien sur le réseau. Économe : 45 % de la résolution, 30 images/s au plus,
// 8 images/s quand la fenêtre n'a pas le focus, arrêt complet quand elle est cachée ou réduite.
// Mode « fixe » (Gestion › Outils) ou réglage système « réduire les animations » : une seule image, plus aucun calcul.
(() => {
  "use strict";
  const KEY = "studio.background";
  const cv = document.getElementById("background");
  const state = { mode: "animated", active: false, latest: 0, focus: document.hasFocus() };
  try { state.mode = ["static", "fixe"].includes((localStorage.getItem(KEY) ?? localStorage.getItem("studio.fond"))) ? "static" : "animated"; } catch (e) { /* stockage indisponible : animé */ }
  const reducedMotion = window.matchMedia ? window.matchMedia("(prefers-reduced-motion: reduce)") : { matches: false };
  window.studioBackground = {
    mode: () => (reducedMotion.matches ? "static" : state.mode),
    toggle() {
      state.mode = state.mode === "animated" ? "static" : "animated";
      try { localStorage.setItem(KEY, state.mode); } catch (e) { /* tant pis : vaut pour cette session */ }
      relaunch();
      return this.mode();
    },
  };
  if (!cv) return;
  const fallback = () => document.documentElement.classList.add("without-webgl");
  const gl = cv.getContext("webgl", { antialias: false, alpha: false, depth: false, stencil: false, powerPreference: "low-power" });
  if (!gl) { fallback(); return; }
  const hp = gl.getShaderPrecisionFormat(gl.FRAGMENT_SHADER, gl.HIGH_FLOAT);
  if (!hp || hp.precision < 23) { fallback(); return; }        // le zoom profond exige des flottants 32 bits

  const VS = "attribute vec2 p;void main(){gl_Position=vec4(p,0.,1.);}";
  const FS = `precision highp float;
uniform vec2 R;      // taille du rendu
uniform vec2 C;      // centre de la vue dans le plan complexe
uniform float L;     // profondeur : la vue mesure 1.6·e^-L de haut
uniform float N;     // itérations max (croît avec la profondeur)
uniform float H;     // teinte qui tourne
uniform float F;     // fondu d'entrée / de sortie de chaque plongée
uniform float T;     // lente rotation de la vue
vec3 c5(float i){i=mod(i,5.);
  if(i<.5)return vec3(.10,.95,1.);    // cyan
  if(i<1.5)return vec3(.55,.25,1.);   // violet électrique
  if(i<2.5)return vec3(1.,.15,.70);   // magenta
  if(i<3.5)return vec3(1.,.55,.20);   // orange laser
  return vec3(.25,1.,.60);}           // vert acide
vec3 neon(float t){t=fract(t)*5.;float i=floor(t),f=t-i;f=f*f*(3.-2.*f);return mix(c5(i),c5(i+1.),f);}
void main(){
  vec2 uv=(gl_FragCoord.xy-.5*R)/R.y;
  float cs=cos(T),sn=sin(T); uv=vec2(cs*uv.x-sn*uv.y,sn*uv.x+cs*uv.y);
  float s=exp(-L)*1.6;
  vec2 c=C+uv*s, z=vec2(0.), dz=vec2(0.);
  float n=0., escaped=0., huge=0.;
  for(int i=0;i<1100;i++){
    if(float(i)>=N) break;
    dz=2.*vec2(z.x*dz.x-z.y*dz.y,z.x*dz.y+z.y*dz.x)+vec2(1.,0.);
    if(dot(dz,dz)>1e30){dz*=1e-15;huge=1.;}   // évite le débordement : point collé au bord, il brillera
    z=vec2(z.x*z.x-z.y*z.y,2.*z.x*z.y)+c;
    if(dot(z,z)>256.){escaped=1.;break;}
    n+=1.;
  }
  vec3 col=vec3(0.);                              // l'intérieur de l'ensemble reste noir
  if(escaped>0.){
    float r2=dot(z,z), rz=sqrt(r2);
    float smooth=n-log2(log2(r2))+4.;
    float d=huge>0.?0.:(.5*rz*log(rz)/max(length(dz),1e-30))/(s/R.y);   // distance au bord, en pixels
    float glow=exp(-min(d*.9,50.))*1.5+.3*exp(-min(d*.1,50.));            // filament net + halo
    col=neon(log(smooth+1.)*.6+H)*glow;
  }
  col=col/(1.+col)*1.1*F;
  gl_FragColor=vec4(col,1.);
}`;
  const shader = (type, src) => { const s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s); return gl.getShaderParameter(s, gl.COMPILE_STATUS) ? s : null; };
  const vs = shader(gl.VERTEX_SHADER, VS), fs = shader(gl.FRAGMENT_SHADER, FS);
  const prog = gl.createProgram();
  if (vs && fs) { gl.attachShader(prog, vs); gl.attachShader(prog, fs); gl.linkProgram(prog); }
  if (!vs || !fs || !gl.getProgramParameter(prog, gl.LINK_STATUS)) { fallback(); return; }
  gl.useProgram(prog);
  gl.bindBuffer(gl.ARRAY_BUFFER, gl.createBuffer());
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);   // un triangle couvre l'écran
  const loc = gl.getAttribLocation(prog, "p");
  gl.enableVertexAttribArray(loc); gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);
  const u = Object.fromEntries(["R", "C", "L", "N", "H", "F", "T"].map((n) => [n, gl.getUniformLocation(prog, n)]));

  // Points d'arrivée : des zones du bord de l'ensemble qui restent riches jusqu'à la limite des flottants 32 bits.
  const TARGETS = [[-0.743643887, 0.131825904], [-0.77568377, 0.13646737], [0.3245046418, 0.0485510113],
                  [-0.10109636, 0.95628651], [-1.74975914, 0.0], [-0.235125, 0.827215]];
  const START = [-0.6, 0.0], L0 = 2.0, L1 = 9.4, SPEED = 0.17, FADE = 2.5;
  const DURATION = (L1 - L0) / SPEED;                     // ≈ 44 s par plongée
  const origin = performance.now() - Math.random() * DURATION * TARGETS.length * 1000;   // chaque ouverture commence ailleurs

  function image(t) {
    const scale = 0.45, w = Math.max(1, Math.round(innerWidth * scale)), h = Math.max(1, Math.round(innerHeight * scale));
    if (cv.width !== w || cv.height !== h) { cv.width = w; cv.height = h; gl.viewport(0, 0, w, h); }
    const k = Math.floor(t / DURATION), tc = t - k * DURATION, target = TARGETS[k % TARGETS.length];
    const L = L0 + tc * SPEED, slide = Math.exp(-2 * L);          // le centre rejoint la cible plus vite que la vue ne rétrécit
    const smooth = (a, b, x) => { const v = Math.min(1, Math.max(0, (x - a) / (b - a))); return v * v * (3 - 2 * v); };
    gl.uniform2f(u.R, w, h);
    gl.uniform2f(u.C, target[0] + (START[0] - target[0]) * slide, target[1] + (START[1] - target[1]) * slide);
    gl.uniform1f(u.L, L);
    gl.uniform1f(u.N, Math.min(1100, Math.round(150 + 70 * L)));
    gl.uniform1f(u.H, (tc * 0.012 + k * 0.37) % 1);
    gl.uniform1f(u.F, smooth(0, FADE, tc) * (1 - smooth(DURATION - FADE, DURATION, tc)));
    gl.uniform1f(u.T, (k * 1.3 + tc * 0.015) % 6.283185307);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
  }
  const current_time = () => (performance.now() - origin) / 1000;
  function loop(ms) {
    if (!state.active) return;
    requestAnimationFrame(loop);
    if (ms - state.latest < (state.focus ? 33 : 125)) return;
    state.latest = ms; image(current_time());
  }
  function relaunch() {
    const animated = window.studioBackground.mode() === "animated" && !document.hidden;
    image(animated ? current_time() : DURATION * 0.82);          // en fixe : une belle image, au fond de la première plongée
    if (animated && !state.active) { state.active = true; requestAnimationFrame(loop); }
    if (!animated) state.active = false;
  }
  document.addEventListener("visibilitychange", relaunch);
  addEventListener("focus", () => { state.focus = true; });
  addEventListener("blur", () => { state.focus = false; });
  addEventListener("resize", () => { if (!state.active) image(window.studioBackground.mode() === "animated" ? current_time() : DURATION * 0.82); });
  if (reducedMotion.addEventListener) reducedMotion.addEventListener("change", relaunch);
  cv.addEventListener("webglcontextlost", (e) => { e.preventDefault(); state.active = false; fallback(); });
  relaunch();
})();
