"""Signature des mises à jour : Ed25519 (RFC 8032), en Python pur, sans dépendance.

- La clé PUBLIQUE est livrée dans le studio (``studio/update-public-key.txt``, hexadécimal).
- La clé PRIVÉE reste sur le PC de Mel, hors de tout dépôt (``scripts/update_signing_key.py``) ; ``installeur/build.py``
  signe le manifeste avec elle.
- Le manifeste garde ses clés publiées (``fichier``, ``mineure``…) et gagne ``signature`` : les studios 0.4.38 / 0.4.39,
  qui ne la lisent pas, continuent à se mettre à jour.
- Une mise à jour mineure ne s'installe toute seule que si la signature est valide (``studio/updates.py``).

Arithmétique : implémentation de référence de la RFC 8032 (section 6), adaptée sans changement d'algorithme.
"""
from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path

PUBLIC_KEY_FILE = Path(__file__).resolve().parent / "update-public-key.txt"
CONTEXT = b"super-ai-studio-update-v1\n"

# --- Ed25519 (RFC 8032, section 6) -----------------------------------------------------------------------------
_p = 2 ** 255 - 19
_q = 2 ** 252 + 27742317777372353535851937790883648493


def _inv(x: int) -> int:
    return pow(x, _p - 2, _p)


_d = -121665 * _inv(121666) % _p
_sqrt_m1 = pow(2, (_p - 1) // 4, _p)


def _sha512_modq(s: bytes) -> int:
    return int.from_bytes(hashlib.sha512(s).digest(), "little") % _q


def _add(P, Q):
    A, B = (P[1] - P[0]) * (Q[1] - Q[0]) % _p, (P[1] + P[0]) * (Q[1] + Q[0]) % _p
    C, D = 2 * P[3] * Q[3] * _d % _p, 2 * P[2] * Q[2] % _p
    E, F, G, H = B - A, D - C, D + C, B + A
    return (E * F, G * H, F * G, E * H)


def _mul(s: int, P):
    Q = (0, 1, 1, 0)
    while s > 0:
        if s & 1:
            Q = _add(Q, P)
        P = _add(P, P)
        s >>= 1
    return Q


def _equal(P, Q) -> bool:
    return (P[0] * Q[2] - Q[0] * P[2]) % _p == 0 and (P[1] * Q[2] - Q[1] * P[2]) % _p == 0


def _recover_x(y: int, sign: int):
    if y >= _p:
        return None
    x2 = (y * y - 1) * _inv(_d * y * y + 1)
    if x2 == 0:
        return None if sign else 0
    x = pow(x2, (_p + 3) // 8, _p)
    if (x * x - x2) % _p != 0:
        x = x * _sqrt_m1 % _p
    if (x * x - x2) % _p != 0:
        return None
    if (x & 1) != sign:
        x = _p - x
    return x


_gy = 4 * _inv(5) % _p
_gx = _recover_x(_gy, 0)
_G = (_gx, _gy, 1, _gx * _gy % _p)


def _compress(P) -> bytes:
    zinv = _inv(P[2])
    x, y = P[0] * zinv % _p, P[1] * zinv % _p
    return int.to_bytes(y | ((x & 1) << 255), 32, "little")


def _decompress(s: bytes):
    if len(s) != 32:
        return None
    y = int.from_bytes(s, "little")
    sign = y >> 255
    y &= (1 << 255) - 1
    x = _recover_x(y, sign)
    return None if x is None else (x, y, 1, x * y % _p)


def _expand(secret: bytes) -> tuple[int, bytes]:
    if len(secret) != 32:
        raise ValueError("clé privée : 32 octets attendus")
    h = hashlib.sha512(secret).digest()
    a = int.from_bytes(h[:32], "little")
    a &= (1 << 254) - 8
    a |= 1 << 254
    return a, h[32:]


def public_key(secret: bytes) -> bytes:
    a, _ = _expand(secret)
    return _compress(_mul(a, _G))


def sign(secret: bytes, message: bytes) -> bytes:
    a, prefix = _expand(secret)
    A = _compress(_mul(a, _G))
    r = _sha512_modq(prefix + message)
    Rs = _compress(_mul(r, _G))
    h = _sha512_modq(Rs + A + message)
    return Rs + int.to_bytes((r + h * a) % _q, 32, "little")


def verify(public: bytes, message: bytes, signature: bytes) -> bool:
    if len(public) != 32 or len(signature) != 64:
        return False
    A, R = _decompress(public), _decompress(signature[:32])
    if not A or not R:
        return False
    s = int.from_bytes(signature[32:], "little")
    if s >= _q:
        return False
    h = _sha512_modq(signature[:32] + public + message)
    return _equal(_mul(s, _G), _add(R, _mul(h, A)))


# --- Manifest -----------------------------------------------------------------------------------------------------
def signed_message(version: str, file: str, sha256: str, minor: bool, notes: str = "") -> bytes:
    """What the signature covers: version, archive name, its SHA-256, the « minor » flag (auto-install) and the SHA-256
    of the release notes (shown to the user). Final format: unchanged when the key arrives."""
    body = json.dumps({"version": str(version), "file": str(file), "sha256": str(sha256).lower(), "minor": bool(minor),
                       "notes_sha256": hashlib.sha256(str(notes or "").encode("utf-8")).hexdigest()},
                      sort_keys=True, separators=(",", ":"))
    return CONTEXT + body.encode("utf-8")


def read_public_key(path: Path = PUBLIC_KEY_FILE) -> bytes | None:
    """The shipped public key, or None if the file is empty or absent (then nothing is « signed »)."""
    try:
        lines = [l.strip() for l in Path(path).read_text(encoding="utf-8").splitlines() if l.strip() and not l.startswith("#")]
    except OSError:
        return None
    return bytes.fromhex(lines[0]) if lines and re.fullmatch(r"[0-9a-fA-F]{64}", lines[0]) else None


def manifest_state(man: dict, public: bytes | None) -> str:
    """« valid », « invalid » (present but wrong: refuse), « missing » (unsigned) or « no_key » (no key shipped)."""
    signature = man.get("signature")
    if public is None:
        return "no_key"
    if not signature:
        return "missing"
    try:
        raw = bytes.fromhex(str(signature))
    except ValueError:
        return "invalid"
    file = str(man.get("file") or man.get("fichier", ""))
    message = signed_message(man.get("version", ""), file, str(man.get("sha256", "")), bool(man.get("minor", man.get("mineure"))),
                             str(man.get("notes", "")))
    return "valid" if verify(public, message, raw) else "invalid"


def key_id(public: bytes) -> str:
    return hashlib.sha256(public).hexdigest()[:16]
