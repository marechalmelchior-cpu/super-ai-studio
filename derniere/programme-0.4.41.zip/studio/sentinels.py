"""Sentinelles du studio : empreinte des fichiers qui gouvernent les agents (règles, rôles, scripts de garde, registres,
configurations des agents), prise avant et après le passage d'un agent.

Elles **signalent** (journal de la tâche, compte rendu, relecture), elles n'annulent rien : Mel peut travailler en même
temps. Seules des métadonnées sont gardées (chemin relatif, taille, date, SHA-256) : jamais un contenu, ni celui des clés
chiffrées ou de la mémoire. Fichiers suivis par git ou non : tous ceux des emplacements surveillés, créations et
suppressions comprises.
"""
from __future__ import annotations

import hashlib

from .migrations.compatibility import TechnicalPath as Path

# Settings of the studio that change what an agent may do (runtime files such as window.json or seen-models.json are not
# watched: the studio writes them itself during a task).
DATA_FILES = ("mcp.json", "mcp-secrets.json", "connections.json", "teams.json", "efforts.json", "ai-roles.json",
              "models.json", "profile.json", "project-profiles.json", "devices.json", "interface-key.json",
              "approved-commands.json", "supervisor-instruction.md")
MAX_FILES = 5000


def watched(paths) -> list[tuple[Path, str]]:
    """(root, glob) pairs; ``paths`` is the studio's StudioPaths."""
    code, root = Path(paths.code), Path(paths.root)
    out = [(Path(paths.global_dir), "**/*"), (root / "Skills", "**/*"), (Path(paths.roles), "**/*"),
           (code / "studio", "mcp_guard.py"), (code / "scripts" / "tools", "**/*"),
           (Path(paths.config_file).parent, Path(paths.config_file).name),
           (code / "configs-preparees", "**/*"), (code / "templates", "*.json")]
    out += [(Path(paths.projects), "*/project.toml"), (Path(paths.topics), "*/topic.toml")]
    out += [(Path(paths.data), name) for name in DATA_FILES]
    return out


def _digest(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def snapshot(paths) -> dict[str, dict]:
    """{relative path: {size, mtime_ns, sha256}} for every watched file that exists (links are not followed)."""
    base = Path(paths.root)
    out: dict[str, dict] = {}
    for folder, pattern in watched(paths):
        if not folder.exists():
            continue
        for p in sorted(folder.glob(pattern)):
            if len(out) >= MAX_FILES:
                return out
            try:
                if p.is_symlink() or not p.is_file() or "__pycache__" in p.parts:
                    continue
                st = p.stat()
                rel = p.relative_to(base).as_posix() if base in p.parents else p.as_posix()
                out[rel] = {"size": st.st_size, "mtime_ns": st.st_mtime_ns, "sha256": _digest(p)}
            except (OSError, ValueError):
                continue
    return out


def compare(before: dict, after: dict) -> dict[str, list[str]]:
    return {"created": sorted(set(after) - set(before)), "deleted": sorted(set(before) - set(after)),
            "modified": sorted(k for k in set(before) & set(after) if before[k].get("sha256") != after[k].get("sha256"))}


def summary(changes: dict[str, list[str]]) -> list[str]:
    labels = {"created": "créé", "deleted": "supprimé", "modified": "modifié"}
    return [f"{path} ({labels[kind]})" for kind in ("modified", "created", "deleted") for path in changes.get(kind, [])]
