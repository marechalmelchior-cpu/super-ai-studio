"""SIMULATED runner — for tests and offline demos.

Its results are always marked ``simulated=True`` and shown as « SIMULATION ».
It calls no model: it applies a predefined script per attempt.
"""
from __future__ import annotations

from ..migrations.compatibility import TechnicalPath as Path
from typing import Callable

from .base import ExecResult, Mission

Script = Callable[[Mission, Path], str]


class SimulatedExecutor:
    name = "simulation"

    def __init__(self, scripts: dict[int, Script] | Script):
        self.scripts = scripts
        self.calls = 0

    def available(self) -> tuple[bool, str]:
        return True, "Exécutant simulé (aucun modèle appelé)"

    def execute(self, mission: Mission, workdir: Path, runner) -> ExecResult:
        self.calls += 1
        fn = self.scripts if callable(self.scripts) else self.scripts.get(mission.try_count) or self.scripts[max(self.scripts)]
        summary = fn(mission, workdir)
        return ExecResult(True, f"[SIMULATION] {summary}", self.name, simulated=True)
