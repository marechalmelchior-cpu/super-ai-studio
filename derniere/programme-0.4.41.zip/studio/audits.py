"""Skill and agent memory audits — Gestion buttons.

Two studio skills give the method, attached to the request so that any AI can run it:
- ``audit-skills``: inventory of skills (studio, project), usage observed in histories, duplicates,
  skills loaded for nothing, global or local. ``fix`` only applies safe corrections (metadata).
- ``audit-memories``: rereads every Markdown file meant for agents (instruction files, rules, skills, plans) and
  checks it against the code; verdict GARDER / METTRE À JOUR / FUSIONNER / ARCHIVER / SUPPRIMER / À VÉRIFIER. ``clean`` applies.

Here: 1) « Auditer » starts a read-only task; its report is the audit report, and the task files itself.
2) « Appliquer » on a finished audit starts the fix in the project's isolated copy; in autonomous mode it is
validated and merged on its own. Studio rule, stronger than the skills: nothing is deleted, everything goes to archive.
Targets: every project with a folder, and the studio itself (its Skills and shared rules, see Registry.studio_target).
"""
from __future__ import annotations

from datetime import date

SKILL = {"skills": "audit-skills", "memories": "audit-memories"}
MODE = {"skills": {"audit": "audit", "apply": "fix"}, "memories": {"audit": "audit", "apply": "clean"}}
COMMON = ("Règles du studio, prioritaires sur le skill : n'affiche, ne recopie et ne cite aucun secret, clé, token ni "
          "contenu sensible de mémoire (chemins et noms de fichiers seulement) ; ne lis pas les mémoires privées de tes "
          "outils d'IA ; ni commit ni push (le studio s'en charge).")


def category_kind(request: str) -> tuple[str, str] | None:
    """« [audit-skills audit] … » (or the older « $audit-skills audit … ») → ("skills", "audit"); otherwise None."""
    for what, name in SKILL.items():
        for mode, arg in MODE[what].items():
            if request.startswith((f"[{name} {arg}]", f"${name} {arg}")):
                return what, mode
    return None


def studio_method(studio, what: str) -> str:
    """The method always comes from the studio's own skill, so the audit works the same with any AI."""
    name = SKILL[what]
    for folder in (name, "audit-memories" if what == "memories" else name):      # older workspaces: French folder name
        try:
            text = (studio.paths.skills / folder / "SKILL.md").read_text(encoding="utf-8")
        except OSError:
            continue
        return f"\n\nMéthode à suivre (skill « {name} » du studio) :\n{text}"
    return ""


def request(studio, target: str, what: str, mode: str, since: str = "") -> str:
    if what not in SKILL or mode not in MODE[what]:
        raise ValueError("Audit inconnu.")
    t = studio.registry.get(target)
    if t.kind != "project" or not t.path():
        raise ValueError("Un audit se lance sur un projet qui a un dossier.")
    from .registry import STUDIO_ID
    real = str(t.path())
    is_studio = t.id == STUDIO_ID
    rules = studio.paths.names["rules"]
    head = f"[{SKILL[what]} {MODE[what][mode]}]" + (f" {real}" if what == "skills" and mode == "audit" and not is_studio else "")
    head += studio_method(studio, what)
    if mode == "audit":
        if is_studio:
            what_to_read = (f"Cible : le studio lui-même. Skills communs à toutes les IA : {real}/Skills ; règles communes : "
                            f"{real}/{rules}. Lis-les directement, en lecture seule. Vérifie aussi qu'aucune règle ni aucun "
                            "skill n'est réservé à une IA en particulier sans raison.")
        else:
            what_to_read = (f"Projet à auditer : {real} (lis-le directement, en lecture seule), ses skills et les skills du "
                            "studio, avec les historiques de sessions de tes outils d'IA comme preuves d'usage s'ils existent."
                            if what == "skills" else
                            "Projet à auditer : le dossier courant (copie du projet au dernier commit). Lis tous les fichiers "
                            "éligibles du manifeste, pas un échantillon.")
        return (f"{head}\n\nL'utilisateur a lancé explicitement cet audit depuis Gestion. MODE AUDIT : lecture seule, tu n'écris, "
                f"ne déplaces et ne supprimes aucun fichier, nulle part. {what_to_read}\n{COMMON}\n\n"
                "Ton compte rendu final EST le rapport, en français : d'abord 5 lignes (ce qui va, ce qui coûte ou "
                "trompe les agents, gain attendu), puis une ligne par élément avec verdict et preuve, puis les "
                "corrections classées en « sûres, appliquées par le bouton Appliquer » et « à décider par l'utilisateur ».")
    if not since:
        raise ValueError("Appliquer : indique l'audit de départ.")
    a = studio.store.get(since)
    if category_kind(a["request"] or "") != (what, "audit") or a["target"] != target:
        raise ValueError("Cette tâche n'est pas un audit de ce type sur ce projet.")
    if a["status"] not in ("approved", "applied"):
        raise ValueError("L'audit n'est pas fini.")
    report = studio.run_dir(since) / "RESULTAT.md"
    scope = ("Applique seulement les corrections sûres DANS LE DOSSIER COURANT (skills et règles de la copie). Ce qui est "
              "hors de ta copie (dossiers de configuration de tes outils d'IA) : n'y écris rien, liste précisément les "
              "changements proposés pour l'utilisateur." if what == "skills" else
              "Applique les verdicts dans le dossier courant (copie du projet), fichiers Markdown destinés aux agents "
              "uniquement ; réaudite d'abord si l'arbre a changé depuis le rapport.")
    return (f"{head}\n\nL'utilisateur a validé l'application depuis Gestion. Rapport d'audit de départ : {report} (tâche {since}). "
            f"{scope}\nRien n'est supprimé : SUPPRIMER et ARCHIVER = déplacer le fichier dans le dossier d'archives du "
            f"projet s'il existe, sinon dans Archives/audit-{date.today():%Y%m%d}/ en gardant son chemin ; FUSIONNER = "
            "reporter le savoir unique dans le fichier de référence, réparer les liens, puis archiver la source. "
            f"Ce qui est À VÉRIFIER ne bouge pas.\n{COMMON}\n\n"
            "Compte rendu en français : modifiés / archivés / laissés et pourquoi / bloqués.")


def launch(studio, target: str, what: str, mode: str, since: str = "") -> str:
    title = ("Audit des " if mode == "audit" else "Appliquer l'audit des ") + ("skills" if what == "skills" else "mémoires")
    return studio.create(target, request(studio, target, what, mode, since), role="maintenance", title=title)   # the role's AI, whichever it is


def latest(studio) -> list[dict]:
    """Per project: last audit and last application of each type (for « il y a N jours »)."""
    seen_items: dict[str, dict] = {}
    for t in studio.store.list(limit=2000):
        g = category_kind(t.get("request") or "")
        if not g:
            continue
        key = f"{g[0]}_{g[1]}"
        d = seen_items.setdefault(t["target"], {})
        if key not in d:                              # list sorted from newest to oldest
            d[key] = {"tid": t["id"], "date": t["created_at"], "status": t["status"]}
    return [{"target": f"{p.kind}:{p.id}", "name": p.name, **seen_items.get(f"{p.kind}:{p.id}", {})}
            for p in [studio.registry.studio_target(), *studio.registry.all()] if p.kind == "project" and p.path_value]
