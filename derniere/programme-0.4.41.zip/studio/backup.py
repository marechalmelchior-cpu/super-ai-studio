"""Backup, verification and restore to a test location.

- SQLite databases are copied consistently (SQLite backup API).
- Each file is listed in ``manifest.json`` with its SHA-256 hash.
- On Windows, the archive is encrypted with DPAPI (current Windows account):
  no plaintext copy is written. Elsewhere (tests), ``protection="aucune"``.
- A backup never overwrites another; a restore only happens
  into an empty or non-existent folder (never over the live data).
"""
from __future__ import annotations

import hashlib
import io
from .migrations import compatibility as json
import os
import re
import sqlite3
import sys
import tempfile
import zipfile
from datetime import datetime, timezone
from .migrations.compatibility import TechnicalPath as Path

from .paths import StudioPaths

MAGIC = b"STUDIO-DPAPI-BACKUP-V1\0"
INCLUDE_FILES = ("Studio/studio.config.toml",)
# Données de travail régénérables, pièces jointes et copies historiques : pas des réglages actifs.
DATA_EXCLUDED_DIRS = frozenset({
    "__pycache__", ".pytest_cache", "cache", "caches", "logs", "logs", "tmp", "temp",
    "edge-studio", "agentmemory", "attachments", "test-restores", "previous-config",
    "anciennes-versions",
})
DATA_EXCLUDED_FILES = frozenset({
    "benchmarks-update.json", "catalog-update.json", "mcp-tools.json",
    "interface-key.json", "interface-session.json",
})


def _configuration_files(data: Path):
    def raise_error(error):
        raise error

    for folder, directories, files in os.walk(data, followlinks=False, onerror=raise_error):
        directories[:] = sorted(name for name in directories
                                if name.casefold() not in DATA_EXCLUDED_DIRS
                                and not name.startswith(".")
                                and not (Path(folder) / name).is_symlink()
                                and not (Path(folder) / name).is_junction())
        for name in sorted(files):
            path = Path(folder) / name
            if (path.suffix.lower() not in {".json", ".md"} or name.startswith((".", "~"))
                    or name.casefold() in DATA_EXCLUDED_FILES or path.is_symlink()
                    or re.search(r"(?:[._-](?:tmp|temp|partiel|bak|old|swp|log|cache))(?:[._-]|$)", name, re.I)
                    or re.fullmatch(r"(?:supervisor-instruction|superviseur-consigne)-[0-9a-f]+\.md", name, re.I)):
                continue
            yield path


def _configuration_bytes(path: Path, protection: str) -> bytes:
    from .security import assert_no_secret

    raw = path.read_bytes()
    text = raw.decode("utf-8-sig")
    if path.suffix.lower() == ".json":
        settings = json.loads(text)
        values = []
        if path.name == "connections.json":
            values = [item.get("key", "") for item in settings.get("connections", [])]
        elif path.name == "mcp-secrets.json":
            values = list(settings.values())
        if any(value and (not isinstance(value, str) or not value.startswith(("dpapi:", "local1:")))
               for value in values):
            raise ValueError("Réglage refusé : une clé de connexion n'est pas chiffrée.")
        # La clé VAPID historique est en clair sur disque : seule une archive chiffrée la protège.
        if path.name == "push.json" and settings.get("vapid") and protection != "dpapi":
            raise ValueError("Les notifications exigent une sauvegarde chiffrée DPAPI.")
    # Les clés restent chiffrées ; aucune fonction de déchiffrement n'est appelée ici.
    checked = re.sub(r'"(?:dpapi|local1):[^"\r\n]*"', '""', text)
    checked = re.sub(r"\$\{[A-Za-z_][A-Za-z0-9_]*\}", "", checked)
    assert_no_secret(checked, "réglages de sauvegarde")
    return raw


def include_dirs(paths: StudioPaths) -> tuple:
    n = paths.names
    return (n["rules"], "Skills", n["projects"], n["topics"], "Studio/Decisions", "Studio/roles", "Studio/models")


# ------------------------------------------------------------------ DPAPI ---
def _dpapi(data: bytes, protect: bool) -> bytes:
    if sys.platform != "win32":
        raise RuntimeError("DPAPI n'est disponible que sous Windows.")
    import ctypes
    from ctypes import wintypes

    class BLOB(ctypes.Structure):
        _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_char))]
    buf = ctypes.create_string_buffer(data, len(data))
    inp, out = BLOB(len(data), ctypes.cast(buf, ctypes.POINTER(ctypes.c_char))), BLOB()
    crypt32, kernel32 = ctypes.windll.crypt32, ctypes.windll.kernel32
    fn = crypt32.CryptProtectData if protect else crypt32.CryptUnprotectData
    ok = fn(ctypes.byref(inp), None, None, None, None, 0, ctypes.byref(out))
    if not ok:
        raise RuntimeError("Échec DPAPI (compte Windows différent ou archive altérée).")
    try:
        return ctypes.string_at(out.pbData, out.cbData)
    finally:
        kernel32.LocalFree(out.pbData)


def protect(data: bytes) -> bytes:
    return MAGIC + _dpapi(data, True)


def unprotect(blob: bytes) -> bytes:
    if not blob.startswith(MAGIC):
        raise ValueError("Format d'archive inconnu.")
    return _dpapi(blob[len(MAGIC):], False)


# --------------------------------------------------------------- creation ---
def _sqlite_copy(src: Path) -> bytes:
    with tempfile.TemporaryDirectory() as td:
        dst = Path(td) / "copy.db"
        s = sqlite3.connect(src)
        d = sqlite3.connect(dst)
        try:
            s.backup(d)
        finally:
            d.close()
            s.close()
        return dst.read_bytes()


def create_backup(paths: StudioPaths, protection: str = "auto", with_runs: bool = False) -> Path:
    if protection == "auto":
        protection = "dpapi" if sys.platform == "win32" else "aucune"
    if protection not in {"dpapi", "aucune"}:
        raise ValueError("Protection de sauvegarde inconnue.")
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    entries: dict[str, bytes] = {}
    results = set(paths.result_folders.values())          # <topics>/<topic>/<kind>/
    for d in include_dirs(paths) + ((paths.names["tasks"],) if with_runs else ()):
        base = paths.root / d
        if base.exists():
            for f in sorted(base.rglob("*")):
                rel = f.relative_to(paths.root).parts
                if d == paths.names["topics"] and len(rel) > 3 and rel[2] in results:
                    continue                            # topic results (images, videos…): not copied every day
                if f.is_file() and "__pycache__" not in f.parts:
                    entries[f.relative_to(paths.root).as_posix()] = f.read_bytes()
    for rel in INCLUDE_FILES:
        f = paths.root / rel
        if f.exists():
            entries[rel] = f.read_bytes()
    if paths.data.exists():
        for setting in _configuration_files(paths.data):
            entries[f"Studio/data/{setting.relative_to(paths.data).as_posix()}"] = _configuration_bytes(setting, protection)
        for db in sorted(paths.data.glob("*.db")):
            entries[f"Studio/data/{db.name}"] = _sqlite_copy(db)
    manifest = {"created_utc": stamp, "protection": protection, "root": "AI-Workspace",
                "inputs": [{"path_value": k, "bytes": len(v), "sha256": hashlib.sha256(v).hexdigest()}
                            for k, v in entries.items()]}
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("manifest.json", json.dumps(manifest, ensure_ascii=False, indent=1))
        for k, v in entries.items():
            z.writestr(k, v)
    raw = buf.getvalue()
    paths.backups.mkdir(parents=True, exist_ok=True)
    out = paths.backups / f"studio-{stamp}.{'dpapi' if protection == 'dpapi' else 'zip'}"
    tmp = out.with_name(out.name + ".partiel")
    with open(tmp, "xb") as fh:                         # written separately: an interruption never leaves a truncated backup
        fh.write(protect(raw) if protection == "dpapi" else raw)
    os.rename(tmp, out)                                 # fails if the target exists: never overwritten
    return out


def _open(archive: Path) -> zipfile.ZipFile:
    blob = archive.read_bytes()
    raw = unprotect(blob) if blob.startswith(MAGIC) else blob
    return zipfile.ZipFile(io.BytesIO(raw))


def verify_backup(archive: Path) -> dict:
    with _open(archive) as z:
        manifest = json.loads(z.read("manifest.json"))
        bad = [e["path_value"] for e in manifest["inputs"]
               if hashlib.sha256(z.read(e["path_value"])).hexdigest() != e["sha256"]]
        extra = set(z.namelist()) - {e["path_value"] for e in manifest["inputs"]} - {"manifest.json"}
    return {"ok": not bad and not extra, "inputs": len(manifest["inputs"]), "alterees": bad,
            "inattendues": sorted(extra), "protection": manifest["protection"], "created_utc": manifest["created_utc"]}


def restore_to_test(archive: Path, target: Path) -> dict:
    target = Path(target)
    if target.exists() and any(target.iterdir()):
        raise FileExistsError("La restauration de test exige un dossier vide ou inexistant.")
    check = verify_backup(archive)
    if not check["ok"]:
        raise ValueError(f"Archive invalide : {check}")
    target.mkdir(parents=True, exist_ok=True)
    with _open(archive) as z:
        manifest = json.loads(z.read("manifest.json"))
        for e in manifest["inputs"]:
            dst = (target / e["path_value"]).resolve()
            if target.resolve() not in dst.parents:
                raise ValueError("Chemin d'archive invalide.")
            dst.parent.mkdir(parents=True, exist_ok=True)
            dst.write_bytes(z.read(e["path_value"]))
    integrity = {}
    for db in (target / "Studio/data").glob("*.db") if (target / "Studio/data").exists() else []:
        c = sqlite3.connect(db)
        integrity[db.name] = c.execute("PRAGMA integrity_check").fetchone()[0]
        c.close()
    return {"ok": all(v == "ok" for v in integrity.values()), "files": check["inputs"],
            "bases": integrity, "folder": str(target)}


def protect_agentmemory_export(backend, dest_dir: Path) -> Path:
    """Export of the central memory server, encrypted immediately (Windows)."""
    data = json.dumps(backend._req("GET", "export"), ensure_ascii=False).encode()
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    dest_dir.mkdir(parents=True, exist_ok=True)
    out = dest_dir / f"agentmemory-export-{stamp}.dpapi"
    with open(out, "xb") as fh:
        fh.write(protect(data))
    return out
