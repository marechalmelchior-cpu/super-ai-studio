"""The user's personal AI studio — orchestration, shared memory, connectors.

The package deliberately has no dependencies for everything other than
orchestration (LangGraph). Connectors use the standard library.
"""

import os

__version__ = "0.1.0"

# Local data by default: no LangSmith/LangChain tracing to the Internet.
for _var in ("LANGSMITH_TRACING", "LANGCHAIN_TRACING_V2", "LANGCHAIN_TRACING"):
    os.environ[_var] = "false"
