"""Import of skills and instructions already on the PC: a COPY in the studio, which then takes care of them.

- Sources: skills of the subscription tools (~/.claude/skills, ~/.agents/skills, ~/.codex/skills); global
  instructions ~/.claude/CLAUDE.md and ~/.codex/AGENTS.md.
- Copied into the studio workspace: Skills/<name>/ (and Regles/importes/ for the .md files). The originals are never
  modified, moved or deleted: the user removes them if they want.
- Nothing is overwritten: name already taken in the studio → « <name>-importe ». Copies made by the studio (« studio-… »)
  and links are not imported. Automatically only once (data/import-initial.json), then on request.
"""
from __future__ import annotations

from .migrations import compatibility as json
import shutil
import time
from .migrations.compatibility import TechnicalPath as Path
from .paths import StudioPaths

SOURCES_SKILLS = (".claude/skills", ".agents/skills", ".codex/skills")
SOURCES_MD = ((".claude/CLAUDE.md", "CLAUDE (Claude Code).md"), (".codex/AGENTS.md", "AGENTS (Codex).md"))
STUDIO_MARKER = "genere-par-ai-workspace"
IGNORED = shutil.ignore_patterns("__pycache__", "node_modules", ".git", "*.pyc")
MAX_SKILL_BYTES = 50 * 2**20
MANIFEST = ".import.json"


def _size(d: Path) -> int:
    total = 0
    for p in d.rglob("*"):
        try:
            if p.is_file() and not p.is_symlink():
                total += p.stat().st_size
        except OSError:
            pass
    return total


def _from_studio(d: Path) -> bool:
    if d.name.startswith("studio-"):
        return True
    try:
        return STUDIO_MARKER in (d / "SKILL.md").read_text(encoding="utf-8", errors="replace")[:2000]
    except OSError:
        return False


def import_(root_dir: Path, home: Path | None = None) -> dict:
    """Copies what is not yet in the studio. Returns {skills, instructions, ignores}."""
    root_dir, home = Path(root_dir), Path(home or Path.home())
    dest_skills = root_dir / "Skills"
    dest_skills.mkdir(parents=True, exist_ok=True)
    report = {"skills": [], "instructions": [], 'ignored': []}
    already: dict[str, Path] = {}                       # SKILL.md content → studio skill (same skill seen in both tools)
    for d in dest_skills.iterdir():
        f = d / MANIFEST
        if f.is_file():
            try:
                for o in json.loads(f.read_text(encoding="utf-8")).get("origins", []):
                    already[o] = d
            except (OSError, ValueError):
                pass
    contents: dict[str, Path] = {}
    for rel in SOURCES_SKILLS:
        base = home / rel
        if not base.is_dir():
            continue
        for d in sorted(base.iterdir()):
            try:
                if d.is_symlink() or not d.is_dir() or not (d / "SKILL.md").is_file() or _from_studio(d):
                    continue
                origin = str(d)
                if origin in already:
                    continue
                text = (d / "SKILL.md").read_text(encoding="utf-8", errors="replace")
                if text in contents:                 # same skill already copied from the other tool: record the origin
                    target = contents[text]
                    _add_origin(target, origin)
                    continue
                if _size(d) > MAX_SKILL_BYTES:
                    report['ignored'].append(f"{d.name} (plus de 50 Mo)")
                    continue
                name, n = d.name, 1
                target = dest_skills / name
                while target.exists():
                    if (target / "SKILL.md").is_file() and (target / "SKILL.md").read_text(encoding="utf-8", errors="replace") == text:
                        break                         # the same skill is already in the studio: nothing to copy
                    n += 1
                    target = dest_skills / (f"{d.name}-importe" if n == 2 else f"{d.name}-importe-{n - 1}")
                if target.exists():
                    _add_origin(target, origin)
                    contents[text] = target
                    continue
                shutil.copytree(d, target, symlinks=False, ignore=IGNORED, ignore_dangling_symlinks=True)
                _add_origin(target, origin)
                h, recent = folder_fingerprint(target)
                sheet = _manifest(target)
                sheet.update(fingerprint=h, date_origin=folder_date(d))
                _write_manifest(target, sheet)
                contents[text] = target
                report["skills"].append(target.name)
            except OSError as e:
                report['ignored'].append(f"{d.name} ({type(e).__name__})")
    from .paths import StudioPaths
    dest_md = StudioPaths(Path(root_dir)).imported_rules
    for rel, name in SOURCES_MD:
        src = home / rel
        target = dest_md / name
        try:
            if src.is_file() and not target.exists():
                dest_md.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src, target)
                report["instructions"].append(name)
        except OSError as e:
            report['ignored'].append(f"{rel} ({type(e).__name__})")
    return report


def _add_origin(skill: Path, origin: str) -> None:
    f = skill / MANIFEST
    try:
        d = json.loads(f.read_text(encoding="utf-8")) if f.exists() else {}
    except (OSError, ValueError):
        d = {}
    d.setdefault("importe", time.strftime("%Y-%m-%d %H:%M"))
    d["origins"] = sorted(set(d.get("origins", [])) | {origin})
    f.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")


def import_once(root_dir: Path, data: Path, home: Path | None = None) -> dict | None:
    """On first launch (or the first opening after the update): only once."""
    marker = Path(data) / "import-initial.json"
    if marker.exists():
        return None
    r = import_(root_dir, home)
    marker.parent.mkdir(parents=True, exist_ok=True)
    marker.write_text(json.dumps({"date": time.strftime("%Y-%m-%d %H:%M"), **r}, ensure_ascii=False, indent=1), encoding="utf-8")
    return r


def origins(skill: Path) -> set[str]:
    try:
        return set(json.loads((Path(skill) / MANIFEST).read_text(encoding="utf-8")).get("origins", []))
    except (OSError, ValueError):
        return set()


# ------------------------------------------------------------------ tracking the originals after the copy
def folder_fingerprint(d: Path) -> tuple[str, float]:
    """(content fingerprint, most recent date) of a skill, excluding the studio's card and ignored heavy files."""
    import hashlib
    h, recent = hashlib.sha256(), 0.0
    for p in sorted(Path(d).rglob("*")):
        rel = p.relative_to(d).as_posix()
        if not p.is_file() or p.name == MANIFEST or any(x in ("__pycache__", "node_modules", ".git") for x in p.parts):
            continue
        try:
            st = p.stat()
            recent = max(recent, st.st_mtime)
            h.update(rel.encode() + b"\0" + hashlib.sha256(p.read_bytes()).digest())
        except OSError:
            continue
    return h.hexdigest()[:24], recent


def folder_date(d: Path) -> float:
    """Most recent date of a skill: a few stat() calls, no file read."""
    recent = 0.0
    for p in Path(d).rglob("*"):
        if p.name == MANIFEST or any(x in ("__pycache__", "node_modules", ".git") for x in p.parts):
            continue
        try:
            if p.is_file():
                recent = max(recent, p.stat().st_mtime)
        except OSError:
            pass
    return recent


def _manifest(skill: Path) -> dict:
    try:
        return json.loads((skill / MANIFEST).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def _write_manifest(skill: Path, d: dict) -> None:
    (skill / MANIFEST).write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")


def _replace_copy(root_dir: Path, skill: Path, origin: Path) -> None:
    """IN-PLACE update of the studio's copy from the original: new or changed files copied again, files
    gone from the original removed from the copy. No other copy is made (no archive on each update)."""
    sheet = _manifest(skill)
    ignored = ("__pycache__", "node_modules", ".git")
    desired = set()
    for p in Path(origin).rglob("*"):
        if p.is_symlink() or not p.is_file() or any(x in ignored for x in p.parts) or p.suffix == ".pyc":
            continue
        rel = p.relative_to(origin)
        desired.add(rel.as_posix())
        d = skill / rel
        try:
            if d.is_file() and d.stat().st_size == p.stat().st_size and d.read_bytes() == p.read_bytes():
                continue
            d.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(p, d)
        except OSError:
            pass
    for p in sorted(skill.rglob("*"), reverse=True):        # what the original no longer has (except the studio's card)
        rel = p.relative_to(skill).as_posix()
        try:
            if p.is_file() and p.name != MANIFEST and rel not in desired:
                p.unlink()
            elif p.is_dir() and not any(p.iterdir()):
                p.rmdir()
        except OSError:
            pass
    h, recent = folder_fingerprint(skill)
    sheet.update(fingerprint=h, date_origin=folder_date(origin), update=time.strftime("%Y-%m-%d %H:%M"))
    sheet.pop("conflict", None)
    sheet.pop("conflict_origin", None)
    _write_manifest(skill, sheet)


def track(root_dir: Path, data: Path | None = None, home: Path | None = None) -> dict:
    """Skills and instructions imported from the PC: if the original changed outside the studio, NOTHING is replaced
    automatically: an update is offered (« Mettre à jour dans le studio » / « Garder la version du studio »), only once
    per version. Fast: an original is read again only if its date changed."""
    report = {"proposals": []}
    base = Path(root_dir) / "Skills"
    for skill in (sorted(base.iterdir()) if base.is_dir() else []):
        sheet = _manifest(skill)
        if not sheet.get("origins"):
            continue
        existing = [Path(o) for o in sheet["origins"] if (Path(o) / "SKILL.md").is_file()]
        if not existing:
            continue
        if "fingerprint" not in sheet:                       # skill imported before tracking existed: starting point = now
            sheet.update(fingerprint=folder_fingerprint(skill)[0], date_origin=max(folder_date(o) for o in existing))
            _write_manifest(skill, sheet)
            continue
        dates = {o: folder_date(o) for o in existing}
        origin = max(existing, key=dates.get)
        if dates[origin] <= float(sheet.get("date_origin", 0)):
            continue                                       # original untouched: nothing to read
        h_orig, recent = folder_fingerprint(origin)
        sheet["date_origin"] = recent
        if h_orig not in (sheet["fingerprint"], sheet.get("rejected")) and (sheet.get("proposal") or {}).get("fingerprint") != h_orig:
            two = folder_fingerprint(skill)[0] != sheet["fingerprint"]          # also modified in the studio
            sheet["proposal"] = {"fingerprint": h_orig, "origin": str(origin), "both_sides": two}
            report["proposals"].append(f"skill « {skill.name} »")
        _write_manifest(skill, sheet)
    if data is not None:                                   # imported CLAUDE.md / AGENTS.md
        report["proposals"] += _track_md(Path(root_dir), Path(data), Path(home or Path.home()))
    return report


def _tracking_md(data: Path) -> dict:
    try:
        raw = json.loads((data / "import-md.json").read_text(encoding="utf-8"))
        # Une entrée par fichier (clé = nom du fichier, opaque) : ses champs suivent les anciens noms (empreinte, refusee…).
        return {name: json.normalize(entry) for name, entry in raw.items()}
    except (OSError, ValueError, AttributeError):
        return {}


def _track_md(root_dir: Path, data: Path, home: Path) -> list[str]:
    import hashlib
    tracking, change, out = _tracking_md(data), False, []
    for rel, name in SOURCES_MD:
        src, copy_dir = home / rel, StudioPaths(Path(root_dir)).imported_rules / name
        if not src.is_file() or not copy_dir.is_file():
            continue
        e = tracking.get(name)
        try:
            mt = src.stat().st_mtime
            if e is None:                                  # starting point: the current copy
                tracking[name] = {"fingerprint": hashlib.sha256(copy_dir.read_bytes()).hexdigest()[:24], "date": mt}
                change = True
                continue
            if mt <= e.get("date", 0):
                continue
            h = hashlib.sha256(src.read_bytes()).hexdigest()[:24]
            e["date"] = mt
            change = True
            if h not in (e["fingerprint"], e.get("rejected")) and (e.get("proposal") or {}).get("fingerprint") != h:
                e["proposal"] = {"fingerprint": h, "origin": str(src),
                                    "both_sides": hashlib.sha256(copy_dir.read_bytes()).hexdigest()[:24] != e["fingerprint"]}
                out.append(f"instructions « {name} »")
        except OSError:
            continue
    if change:
        (data / "import-md.json").write_text(json.dumps(tracking, ensure_ascii=False, indent=1), encoding="utf-8")
    return out


def refresh_copy(root_dir: Path, data: Path, source: Path) -> bool:
    """The studio itself changed an instruction file of the user's tools (renamed paths): its copy in the rules follows,
    without asking the user about a change they did not make."""
    import hashlib
    for rel, name in SOURCES_MD:
        if not Path(source).as_posix().endswith(rel):
            continue
        copy_dir = StudioPaths(Path(root_dir)).imported_rules / name
        if not copy_dir.is_file():
            return False
        b = Path(source).read_bytes()
        copy_dir.write_bytes(b)
        tracking = _tracking_md(Path(data))
        tracking[name] = {"fingerprint": hashlib.sha256(b).hexdigest()[:24], "date": Path(source).stat().st_mtime}
        (Path(data) / "import-md.json").write_text(json.dumps(tracking, ensure_ascii=False, indent=1), encoding="utf-8")
        return True
    return False


def proposals(root_dir: Path, data: Path | None = None) -> list[dict]:
    """Updates waiting for the user's answer."""
    out = []
    base = Path(root_dir) / "Skills"
    for skill in (sorted(base.iterdir()) if base.is_dir() else []):
        p = _manifest(skill).get("proposal")
        if p:
            out.append({"id": f"skill:{skill.name}", "name": skill.name, "category_kind": "skill", "origin": p["origin"],
                        "both_sides": bool(p.get("both_sides"))})
    for name, e in (_tracking_md(Path(data)) if data is not None else {}).items():
        p = e.get("proposal")
        if p:
            out.append({"id": f"md:{name}", "name": name, "category_kind": "instructions", "origin": p["origin"],
                        "both_sides": bool(p.get("both_sides"))})
    return out


def settle(root_dir: Path, ident: str, choice: str, data: Path | None = None) -> dict:
    """« original »: the studio takes the version from the source folder (in-place update);
    « studio »: keep the studio's version and stop asking for THIS version of the original."""
    import hashlib
    category_kind, _, name = ident.partition(":")
    if not name or "/" in name or "\\" in name or ".." in name:
        raise ValueError("Élément inconnu.")
    if category_kind == "skill":
        skill = Path(root_dir) / "Skills" / name
        f = _manifest(skill)
        p = f.get("proposal")
        if not p:
            raise ValueError("Aucune mise à jour en attente pour cette skill.")
        if choice == "original":
            if not (Path(p["origin"]) / "SKILL.md").is_file():
                raise ValueError("L'original n'existe plus.")
            _replace_copy(root_dir, skill, Path(p["origin"]))
            f = _manifest(skill)
            f.pop("proposal", None)
            _write_manifest(skill, f)
            return {"ok": True, "message": f"Skill {name} mise à jour dans le studio."}
        f.pop("proposal", None)
        f["rejected"] = p["fingerprint"]
        _write_manifest(skill, f)
        return {"ok": True, "message": f"Skill {name} : la version du studio est gardée."}
    if category_kind == "md" and data is not None:
        tracking = _tracking_md(Path(data))
        e = tracking.get(name) or {}
        p = e.get("proposal")
        if not p:
            raise ValueError("Aucune mise à jour en attente pour ce fichier.")
        copy_dir = StudioPaths(Path(root_dir)).imported_rules / name
        if choice == "original":
            shutil.copy2(p["origin"], copy_dir)
            e["fingerprint"] = hashlib.sha256(copy_dir.read_bytes()).hexdigest()[:24]
            msg = f"{name} mis à jour dans le studio."
        else:
            msg = f"{name} : la version du studio est gardée."
        e.pop("proposal", None)
        e["rejected"] = p["fingerprint"]
        (Path(data) / "import-md.json").write_text(json.dumps(tracking, ensure_ascii=False, indent=1), encoding="utf-8")
        return {"ok": True, "message": msg}
    raise ValueError("Élément inconnu.")
