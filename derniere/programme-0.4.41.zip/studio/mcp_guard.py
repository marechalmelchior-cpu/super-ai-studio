"""Guard for unreal-mcp tools in studio tasks (PreToolUse hook of the agent CLI).

"All" mode (default, user's choice of 24/10): agents use unreal-mcp as in an interactive session; each
action is recorded in the task log (read / write) so it shows up in the report.
"Read" mode (Superviseur › Réglages): only read actions go through, as described below.

unreal-mcp routes ALL its actions through a single tool, ``call_tool``: reading the level and deleting an actor use the
same tool, so a "tool by tool" permission is not enough. This guard looks at the requested action and:

- allows ``list_toolsets`` and ``describe_toolset`` (they only describe);
- allows ``call_tool`` only for a READ action: its name starts with a read verb
  (get, find, list, describe, search, query, read, count, has, is, snapshot, inspect, dump) AND contains no
  write word (set, create, delete, spawn, save, compile, press, run…);
- refuses everything else, with the reason (the agent sees it and reports it).

Safe by default: ``call_tool`` is NOT among the roles' allowed tools; only this guard can open it, case by
case. If the guard fails to start, the CLI refuses the call (no approval window in a task).
Every decision is recorded in ``Studio/data/garde-unreal-mcp.log`` (action and decision, never the arguments).

Shell commands (Bash, PowerShell) in tasks: allowed as in a normal session (launching the editor, project
scripts, tests, git status…), recorded in the task log; only destructive or publishing commands
are refused (push, reset --hard, clean, recursive deletion, formatting, Windows shutdown, global
taskkill…). The review ("read" mode) has no shell.

Launched by the CLI with the call's JSON on standard input; replies with JSON on standard output.
"""
from __future__ import annotations
import sys
from pathlib import Path
if not __package__:
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from studio.migrations.compatibility import environment

from studio.migrations import compatibility as json
import ast
import re
import shlex
import sys
from datetime import datetime
from pathlib import Path

PREFIX = "mcp__unreal-mcp__"
DESCRIPTION = {"list_toolsets", "describe_toolset"}
READ_VERBS = ("get", "find", "list", "describe", "search", "query", "read", "count", "has", "is", "snapshot",
                  "inspect", "dump")
WRITE_WORDS = ("set", "create", "delete", "remove", "destroy", "spawn", "add", "save", "compile", "build", "move",
                 "rename", "import", "export", "execute", "exec", "run", "start", "stop", "press", "click", "type",
                 "focus", "open", "close", "load", "unload", "apply", "modify", "write", "edit", "update", "change",
                 "duplicate", "copy", "paste", "attach", "detach", "select", "play", "simulate", "restart", "quit",
                 "reset", "clear", "replace", "assign", "bind", "register", "enable", "disable", "toggle", "fix",
                 "generate", "bake", "migrate", "commit", "submit", "send", "post", "invoke", "call")


def words(name: str) -> list[str]:
    """« get_current_level », « GetCurrentLevel », « SceneTools.find_actors » → lowercase words."""
    name = name.split(".")[-1]
    name = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", name)
    return [m for m in re.split(r"[^A-Za-z0-9]+", name.lower()) if m]


def decision(entry: dict) -> tuple[str, str]:
    tool = str(entry.get("tool_name") or "")
    if not tool.startswith(PREFIX):
        return "", ""                                   # not an unreal-mcp tool: the guard stays silent
    short = tool[len(PREFIX):]
    if short in DESCRIPTION:
        return "allow", f"{short} : description des outils, lecture seule"
    if short != "call_tool":
        return "deny", f"{short} : outil unreal-mcp non prévu pour les tâches du studio"
    ti = entry.get("tool_input") or {}
    action = str(ti.get("tool_name") or ti.get("tool") or ti.get("name") or "")
    if not action:
        return "deny", "call_tool sans nom d'action : refusé"
    m = words(action)
    if not m or m[0] not in READ_VERBS:
        return "deny", f"action « {action} » refusée : les tâches du studio n'ont que les actions de lecture (get, find, list…)"
    writes = [x for x in m if x in WRITE_WORDS]
    if writes:
        return "deny", f"action « {action} » refusée : contient « {writes[0]} » (écriture possible)"
    return "allow", f"action « {action} » en lecture seule"


SHELL = {"Bash", "PowerShell"}
EDIT_TOOLS = {"Edit", "Write", "MultiEdit", "NotebookEdit"}     # only recorded (live activity); the permission does not change
FORBIDDEN = [
    (r"\brm\s+(-[a-zA-Z]*[rR][a-zA-Z]*|--recursive)\b", "suppression récursive"),
    (r"\b(remove-item|ri|rm|del|erase|rd|rmdir)\b[^|;&]*\s-(r|recurse)\b", "suppression récursive"),
    (r"\b(rd|rmdir|del|erase)\b[^|;&]*\s/s\b", "suppression récursive"),
    # DISK formatting only (« format D: »): never -Format, Format-List or .format( in Python
    (r"(^|[;&|(]|\bcmd(\.exe)?\s+/[ck])\s*format(\.com)?\s+[a-z]:", "formatage de disque"),
    (r"\b(diskpart|bcdedit|vssadmin\s+delete|cipher\s+/w)\b", "commande système destructrice"),
    (r"\b(shutdown|restart-computer|stop-computer|logoff)\b", "arrêt de Windows"),
    (r"\btaskkill\b[^|;&]*/im\b", "taskkill global (cibler un processus précis)"),
    (r"\bstop-process\b[^|;&]*-name\b", "arrêt de processus par nom (cibler un PID)"),
    (r"\b(reg\s+delete|remove-itemproperty|set-executionpolicy|netsh|sc(\.exe)?\s+delete)\b", "réglage système"),
    (r"(iwr|irm|invoke-webrequest|invoke-restmethod|curl|wget)[^|]*\|\s*(iex|invoke-expression|sh|bash|powershell)\b",
     "télécharger puis exécuter"),
]


GIT_BUILTINS = set("""add apply archive bisect blame branch bundle cat-file check-attr check-ignore check-ref-format
checkout cherry cherry-pick clone commit config count-objects describe diff difftool fetch for-each-ref
format-patch fsck gc grep help init log ls-files ls-remote ls-tree merge merge-base mergetool mv notes pull
range-diff reflog remote reset restore revert rev-list rev-parse rm shortlog show show-branch show-ref
sparse-checkout stage stash status submodule switch tag var verify-commit verify-tag version worktree
push send-pack clean rebase filter-branch filter-repo""".split())
GIT_FLAGS = {"--no-pager", "--paginate", "-p", "-P", "--bare", "--no-replace-objects", "--literal-pathspecs",
             "--glob-pathspecs", "--noglob-pathspecs", "--icase-pathspecs", "--no-optional-locks",
             "--no-lazy-fetch", "--no-advice"}
GIT_VALUES = {"-C", "-c", "--git-dir", "--work-tree", "--namespace", "--super-prefix"}
SHELL_SEPARATORS = ";&|()\n"


def shell_words(command: str) -> list[str]:
    """Découpe les arguments et séparateurs sans exécuter ni développer le shell."""
    lexer = shlex.shlex(command, posix=True, punctuation_chars=SHELL_SEPARATORS)
    lexer.whitespace = " \t\r"
    lexer.whitespace_split = True
    lexer.commenters = ""
    lexer.escape = ""                                  # Préserve les chemins Windows.
    return list(lexer)


def git_command(args: list[str]) -> tuple[str, list[str]]:
    """Retrouve la sous-commande après les options globales et les alias explicites."""
    aliases = {}
    index = 0
    while index < len(args) and args[index].startswith("-"):
        option = args[index]
        index += 1
        if option in ("--version", "-v", "--help", "-h", "--html-path", "--info-path", "--man-path", "--exec-path"):
            return "help", []
        if option in GIT_FLAGS:
            continue
        key, separator, value = option.partition("=")
        if option in GIT_VALUES:
            if index == len(args):
                raise ValueError("option Git sans valeur")
            key, value = option, args[index]
            index += 1
        elif option.startswith(("-C", "-c")):
            key, value = option[:2], option[2:]
        elif not (separator and key in GIT_VALUES):
            raise ValueError("option globale Git non vérifiable")
        if key == "-c":
            name, _, expansion = value.partition("=")
            if name.lower() in {"core.sshcommand", "core.gitproxy", "core.hookspath", "core.editor", "core.pager",
                                "sequence.editor", "diff.external", "credential.helper"} or name.lower().endswith(
                                    (".command", ".cmd", ".clean", ".smudge", ".process", ".textconv")):
                raise ValueError("réglage Git exécutant un programme")
            if name.lower().startswith("alias."):
                aliases[name[6:]] = expansion
    if index == len(args):
        return "help", []
    command, rest = args[index], args[index + 1:]
    seen = set()
    while command not in GIT_BUILTINS:
        if command not in aliases or command in seen:
            raise ValueError("sous-commande ou alias Git non vérifiable")
        seen.add(command)
        expansion = aliases[command]
        if expansion.lstrip().startswith("!"):
            raise ValueError("alias Git exécutant un shell")
        parts = shell_words(expansion)
        if not parts or any(all(c in SHELL_SEPARATORS for c in part) for part in parts):
            raise ValueError("alias Git non vérifiable")
        command, rest = parts[0], parts[1:] + rest
    return command, rest


def _git_reason(args: list[str]) -> str:
    try:
        command, rest = git_command(args)
    except ValueError as error:
        return str(error)
    options = rest[:rest.index("--")] if "--" in rest else rest
    flags = "".join(a[1:] for a in options if a.startswith("-") and not a.startswith("--"))
    if command in {"push", "send-pack"}:
        return "git push : la publication passe par Gestion › Branches"
    if command in {"clean", "rebase", "filter-branch", "filter-repo"}:
        return f"git {command} : suppression ou réécriture d'historique"
    if command == "reset" and any(a.startswith("--") and "--hard".startswith(a) for a in options):
        return "git reset --hard"
    if command in {"checkout", "restore"} and "." in rest:
        return "annulation de tous les fichiers"
    delete = "d" in flags or any(a.startswith("--") and "--delete".startswith(a) for a in options)
    force = "f" in flags or any(a.startswith("--") and "--force".startswith(a) for a in options)
    if command == "branch" and ("D" in flags or delete and force):
        return "suppression forcée de branche"
    if command == "stash" and any(a in {"drop", "clear"} for a in options):
        return "suppression de remises"
    return ""


ROUGH_GIT = [                                          # fallback when the command cannot be split into words
    (r"\bgit(\.exe)?\b[^;&|\n]*\b(push|send-pack)\b", "git push : la publication passe par Gestion › Branches"),
    (r"\bgit(\.exe)?\b[^;&|\n]*\b(clean|rebase|filter-branch|filter-repo)\b", "suppression ou réécriture d'historique"),
    (r"\bgit(\.exe)?\b[^;&|\n]*\breset\b[^;&|\n]*--hard\b", "git reset --hard"),
    (r"\bgit(\.exe)?\b[^;&|\n]*\bbranch\b[^;&|\n]*\s(-D|--delete\s+--force|-df|-fd)\b", "suppression forcée de branche"),
    (r"\bgit(\.exe)?\b[^;&|\n]*\bstash\s+(drop|clear)\b", "suppression de remises"),
    (r"\bgit(\.exe)?\b[^;&|\n]*\b(checkout|restore)\b[^;&|\n]*\s\.(\s|$)", "annulation de tous les fichiers"),
    (r"\bgit(\.exe)?\b[^;&|\n]*\s-c\s*[\"']?alias\.", "alias Git dans une commande non lisible"),
]


def _rough_git_reason(command: str) -> str:
    """Précise le motif d'un refus quand le shell ne peut pas être découpé."""
    for pattern, reason in ROUGH_GIT:
        if re.search(pattern, command):
            return reason
    return ""


def _python_reason(code: str) -> str:
    """Contrôle borné des extraits usuels ; les scripts restent soumis au confinement système."""
    try:
        tree = ast.parse(code)
    except (SyntaxError, ValueError):
        return "extrait Python non vérifiable"
    modules = {"subprocess", "ctypes", "importlib", "socket", "urllib", "http", "multiprocessing", "pty"}
    calls = {"eval", "exec", "compile", "__import__", "getattr", "setattr", "globals", "locals", "system",
             "popen", "run", "call", "check_call", "check_output", "rmtree", "remove", "unlink", "rmdir",
             "execv", "execve", "execl", "execlp", "execvp", "spawnv", "spawnve", "startfile"}
    for node in ast.walk(tree):
        if isinstance(node, ast.Import) and any(a.name.split(".")[0] in modules for a in node.names):
            return "extrait Python lançant un processus ou un accès réseau"
        if isinstance(node, ast.ImportFrom) and (node.module or "").split(".")[0] in modules:
            return "extrait Python lançant un processus ou un accès réseau"
        if isinstance(node, ast.ImportFrom) and any(a.name.lower() in calls for a in node.names):
            return "import Python d'un appel sensible"
        if isinstance(node, ast.Attribute) and (node.attr.lower() in calls or node.attr.startswith("__")):
            return "référence Python à un appel sensible ou introspectif"
        if isinstance(node, ast.Call):
            name = node.func.id if isinstance(node.func, ast.Name) else node.func.attr if isinstance(node.func, ast.Attribute) else ""
            if not name or name.lower() in calls:
                return "appel Python indirect, destructif ou exécutable"
    return ""


def _python_heredoc(command: str) -> tuple[bool, str]:
    match = re.fullmatch(r"\s*(?:[\w./:\\-]*python(?:3|\.exe)?)(?:\s+-I)?\s+-\s*<<['\"]?(\w+)['\"]?\r?\n(.*?)\r?\n\1\s*",
                         command, re.S)
    return (True, _python_reason(match.group(2))) if match else (False, "")


def _shell_git_reason(command: str, depth: int = 0) -> str:
    if depth > 8:
        return "trop d'enveloppes shell pour vérifier la commande"
    heredoc, reason = _python_heredoc(command)
    if heredoc:
        return reason
    try:
        tokens = shell_words(command)
    except ValueError:                                 # heredoc, regex with \" or l'apostrophe: not readable word by word
        return _rough_git_reason(command) or "commande non découpable : utiliser une commande simple ou un script vérifiable"
    start = True
    prefix = ""
    skip_value = False
    for index, token in enumerate(tokens):
        if all(c in SHELL_SEPARATORS for c in token):
            start = True
            prefix, skip_value = "", False
            continue
        if not start:
            continue
        if skip_value:
            skip_value = False
            continue
        if prefix and token.startswith("-"):
            if prefix == "env":
                if token in {"-S", "--split-string"} or token.startswith("--split-string="):
                    return "développement env non vérifiable"
                skip_value = token in {"-u", "--unset", "-C", "--chdir"}
            continue
        if (re.match(r"^[A-Za-z_][A-Za-z0-9_]*=", token)
                or re.match(r"^\$[A-Za-z_][A-Za-z0-9_:]*=", token)
                or token.startswith("$") and index + 1 < len(tokens) and tokens[index + 1] == "="):
            continue
        program = re.sub(r"\.(exe|cmd|bat)$", "", token.replace("\\", "/").rsplit("/", 1)[-1].lower())
        if any(c in token for c in ("$", "%", "`", "^", "!")):
            return "nom de programme calculé ou échappé"
        if program in {"eval", "iex", "invoke-expression", "set-alias", "new-alias", "alias", "function", "doskey"}:
            return "évaluation ou alias shell non vérifiable"
        if program in {"command", "env", "call"}:
            prefix = program
            continue
        start = False
        end = next((i for i in range(index + 1, len(tokens))
                    if all(c in SHELL_SEPARATORS for c in tokens[i])), len(tokens))
        rest = tokens[index + 1:end]
        if program in {"python", "python3", "py"}:
            if "-c" in rest:
                position = rest.index("-c") + 1
                reason = _python_reason(rest[position]) if position < len(rest) else "extrait Python absent"
                if reason:
                    return reason
            elif any(arg.startswith("-c") and len(arg) > 2 for arg in rest):
                return "extrait Python compact non vérifiable"
        if program == "git":
            reason = _git_reason(rest)
            if reason:
                return reason
        elif program in {"cmd", "powershell", "pwsh", "sh", "bash"}:
            if program in {"powershell", "pwsh"} and any(
                    arg.startswith("-") and len(arg) > 1 and
                    ("-encodedcommand".startswith(arg.lower()) or "-encodedarguments".startswith(arg.lower()))
                    for arg in rest):
                return "commande shell encodée non vérifiable"
            switches = {"/c", "/k"} if program == "cmd" else {"-c", "-command"}
            for i, arg in enumerate(rest):
                if arg.lower() in switches or (program in {"sh", "bash"} and arg.startswith("-")
                                               and not arg.startswith("--") and "c" in arg[1:]):
                    reason = _shell_git_reason(" ".join(rest[i + 1:]), depth + 1)
                    if reason:
                        return reason
                    break
    return ""


def decision_shell(command: str) -> tuple[str, str]:
    reason = _shell_git_reason(command or "")
    if reason:
        return "deny", f"commande refusée par le studio ({reason}). Dis-le dans ton compte rendu, sans contourner."
    c = (command or "").lower()
    if (re.search(r"\b(curl|wget|iwr|invoke-webrequest)\b", c)
            and re.search(r"(?:;|&&|\n)\s*(?:sh|bash|python|powershell|pwsh)\b", c)):
        return "deny", "commande refusée par le studio (télécharger puis exécuter)."
    for pattern, reason in FORBIDDEN:
        if re.search(pattern, c):
            return "deny", f"commande refusée par le studio ({reason}). Dis-le dans ton compte rendu, sans contourner."
    return "allow", "commande autorisée et notée par le studio"


def is_read(entry: dict) -> bool:
    return decision(entry)[0] == "allow"


def _edit_reason(filename: str, task_folder: str) -> str:
    """Vérifie le chemin réel, même si l'outil fournit un chemin relatif."""
    import os


    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
    try:
        from studio.project_page import safe_path
    except ImportError:
        return "Vérification de chemin indisponible : écriture refusée."
    path = Path(os.path.abspath(filename))
    task = Path(os.path.abspath(task_folder))
    for name in ('copie-de-travail', "captures"):
        root = task / name
        try:
            relative = path.relative_to(root)
        except ValueError:
            continue
        try:
            safe_path(root, relative.as_posix())
        except ValueError:
            return "Lien, jonction ou chemin non autorisé pour cette tâche."
        return ""
    return "Écriture hors de la copie et des captures : le studio garde ses fichiers et logs."


_CONTROL = re.compile(r"[\x00-\x1f\x7f  ]")
_VISIBLE = {"\n": "\\n", "\r": "\\r", "\t": "\\t"}


def clean_field(text, limit: int = 300) -> str:
    """One log field: secrets masked, line breaks, tabs and control characters made visible (\\n, \\t…), so a value
    sent by the agent can never forge another log line."""
    return _CONTROL.sub(lambda m: _VISIBLE.get(m.group(0), "\\x%02x" % (ord(m.group(0)) & 0xFF)), _mask(str(text)))[:limit]


def jot(action: str, dec: str, category_kind: str) -> None:
    """Global log (data/unreal-mcp-guard.log) and task log (STUDIO_UNREAL_ACTIONS), without the arguments; plus a
    structured log (data/unreal-mcp-guard.jsonl): one JSON object per event, with an identifier given here."""
    import uuid
    action, dec, category_kind = clean_field(action, 200), clean_field(dec, 10), clean_field(category_kind, 10)
    at = datetime.now().isoformat(timespec='seconds')
    line = f"{at}  {dec:5}  {category_kind:8}  {action}\n"
    data = Path(__file__).resolve().parents[1] / "data"
    event = json.dumps({"id": uuid.uuid4().hex, "at": at, "decision": dec, "kind": category_kind, "action": action},
                       ensure_ascii=False) + "\n"
    for f, text in ((data / "unreal-mcp-guard.log", line), (environment("STUDIO_UNREAL_ACTIONS"), line),
                    (data / "unreal-mcp-guard.jsonl", event)):
        if not f:
            continue
        try:
            f = Path(f); f.parent.mkdir(parents=True, exist_ok=True)
            with f.open("a", encoding="utf-8") as h:
                h.write(text)
        except OSError:
            pass


def main() -> int:
    try:
        raw_text = sys.stdin.buffer.read() if hasattr(sys.stdin, "buffer") else sys.stdin.read().encode("utf-8")
        entry = json.loads(raw_text.decode("utf-8", errors="replace") or "{}")     # the CLI sends UTF-8 (accented paths)
    except ValueError:
        entry = {}
    import os


    entry = entry if isinstance(entry, dict) else {}
    tool = str(entry.get("tool_name") or "")
    ti0 = entry.get("tool_input") or {}
    if tool in EDIT_TOOLS:                                # recorded for live activity, NO decision: the role's rule applies
        path_value = str(ti0.get("file_path") or ti0.get("notebook_path") or "")
        task = environment("STUDIO_TASK_FOLDER", "")
        if task and path_value:
            reason = _edit_reason(path_value, task)
            if reason:
                log_activity("rejection", f"écrire {Path(path_value).name} dans le dossier de la tâche")
                return reply("deny", reason)
        log_activity("file", f"{'crée' if tool == 'Write' else 'modifie'}  {_mask(path_value)[:300]}")
        return 0
    if tool in SHELL:
        cmd = str((entry.get("tool_input") or {}).get("command") or "")
        if environment("STUDIO_MCP_UNREAL", "all") == "read":
            dec, reason = "deny", "relecture : pas de commande shell"
        else:
            dec, reason = decision_shell(cmd)
        log_command(f"{dec:5}  {tool:10}  {_mask(' '.join(cmd.split()))[:300 if dec == 'allow' else 2000]}"
                    + (f"  ⟶ {reason}" if dec != "allow" else ""))      # a refusal keeps its reason and the whole command
        log_activity("command" if dec == "allow" else "rejection", _mask(' '.join(cmd.split()))[:300] + ("" if dec == "allow" else f" ⟶ {reason}"))
        return reply(dec, reason)
    dec, reason = decision(entry)
    if not dec:
        return 0
    reading = dec == "allow"
    if environment("STUDIO_MCP_UNREAL", "all") != "read":
        dec, reason = "allow", "unreal-mcp : accès complet (réglage du studio)"
    ti = entry.get("tool_input") or {}
    short = str(entry.get("tool_name", ""))[len(PREFIX):]
    action = f"{ti.get('toolset_name', '')}.{ti.get('tool_name', '')}".strip(".") if short == "call_tool" else short
    jot(action, dec, "read" if reading else "écriture")
    log_activity("unreal", f"{'lecture' if reading else 'écriture'}  {action}")
    return reply(dec, reason)


def _mask(text: str) -> str:
    """No secrets in the log: studio redaction, or a simple mask if the package cannot be imported."""
    try:
        sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
        from studio.security import redact
        return redact(text)
    except Exception:                                   # noqa: BLE001
        return re.sub(r"(?i)(token|key|secret|password|passwd|pwd|bearer)\S*\s*[=:]?\s*\S+", r"\1=***", text)


def log_command(line: str) -> None:
    import os


    f = environment("STUDIO_COMMANDS")
    if not f:
        return
    try:
        f = Path(f); f.parent.mkdir(parents=True, exist_ok=True)
        with f.open("a", encoding="utf-8") as h:
            h.write(f"{datetime.now().isoformat(timespec='seconds')}  {line}\n")
    except OSError:
        pass


def log_activity(category_kind: str, text: str) -> None:
    """Task activity feed (STUDIO_ACTIVITE): what the agent is doing, shown live to the user, never a secret."""
    import os


    f = environment("STUDIO_ACTIVITY")
    if not f:
        return
    try:
        f = Path(f); f.parent.mkdir(parents=True, exist_ok=True)
        with f.open("a", encoding="utf-8") as h:
            h.write(f"{datetime.now().isoformat(timespec='seconds')}\t{clean_field(category_kind, 20)}\t{clean_field(text, 2000)}\n")
    except OSError:
        pass


def reply(dec: str, reason: str) -> int:
    output = json.dumps({"hookSpecificOutput": {"hookEventName": "PreToolUse", "permissionDecision": dec,
                                                "permissionDecisionReason": reason}}, ensure_ascii=False)
    stream = sys.stdout if sys.stdout is not None else open(1, "w", encoding="utf-8", closefd=False)
    stream.write(output)
    stream.flush()
    return 0


if __name__ == "__main__":
    sys.exit(main())
