"""Studio configuration (TOML, read-only via tomllib)."""
from __future__ import annotations

import copy
import tomllib
from .migrations import compatibility as _compat
from .migrations.compatibility import TechnicalPath as Path
from typing import Any

DEFAULTS: dict[str, Any] = {
    "limits": {
        "concurrent_tasks": 1,        # low concurrency to start
        "stage_timeout_s": 900,       # timeout for a tool call
        "task_timeout_s": 3600,      # per run (waiting for approval does not count)
        "max_corrections": 2,           # retries after audit
        "autonomy": "complete",        # « complete »: review OK → validated, applied, merged automatically; « validation »: the user validates
    },
    "memory": {
        # "agentmemory" = chosen technology; "sqlite" = explicit local alternative.
        "backend": "agentmemory",
        "url": "http://127.0.0.1:3111",
        "timeout_s": 5.0,
        "on_failure": "continue_reported",   # or "bloquer"
        "task_ttl_days": 14,
    },
    "tools": {
        "primary_cli": "claude",
        "secondary_cli": "codex",
        "blender": "",
        "unreal_editor_cmd": "",
        "git": "git",
        "mcp_unreal": "all",            # agents: full access to unreal-mcp; « lecture » = read actions only
    },
    "interface": {"host": "127.0.0.1", "port": 8765, "mobile_access": False},
    "user": {"name": "", "language": "fr"},
    "maintenance": {"automatic_cleanup": True},     # daily cleanup of technical files (studio/cleanup.py): never projects or results   # language: fr or en (Supervisor, agents, interface)         # first name (Réglages › « Ton prénom »); empty = neutral texts
    "benchmarks": {"url": ""},          # full up-to-date rankings (same format as templates/benchmarks.json); empty = today's prices only
    "audit": {"model_reviewer": True, "incremental_review": False},   # incremental: off by default (Réglages › Exécution)
    "api_agents": {"commands": "safe", "local_context": 32768},   # contexte_local: max working memory of local models (tokens)
    "night": {"begin": "01:00", "end": "07:00"},   # « Cette nuit » tasks: start within this window (PC time)  # agent commands via API key / local AI: non | sures | toutes
    "supervisor": {"web": True, "outcome": True, "model": "", "fast_model": "haiku", "timeout_s": 300,
                   "light_model": ""},   # light_model: summaries and reports; "" = chosen from the rankings among connected AIs   # Request window: CLI tool in read-only mode
    # Attachments made readable (studio/attachments.py); speech model stored in Studio/data/modeles-parole
    "attachments": {"speech_model": "small", "models_directory": ""},
    "usage": {"primary_alert_5h_min": 60, "secondary_alert_5h_min": 60, "primary_limits": True, "secondary_limits": True},   # alert: limit reached in less than N min at the current rate
    "choices": {"primary_models": ["opus", "sonnet", "haiku"], "secondary_max_effort": "high"},
}


def _merge(base: dict, extra: dict) -> dict:
    out = copy.deepcopy(base)
    for k, v in extra.items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _merge(out[k], v)
        else:
            out[k] = v
    return out


def load_config(path: Path | None) -> dict[str, Any]:
    cfg = copy.deepcopy(DEFAULTS)
    if path and Path(path).exists():
        with open(path, "rb") as fh:
            cfg = _merge(cfg, _compat.toml_load(fh))
    host = cfg["interface"]["host"]
    if host not in ("127.0.0.1", "localhost"):
        raise ValueError("L'interface du studio doit rester locale (127.0.0.1).")
    return cfg


def set_tool(path: Path, key: str, value: str) -> None:
    """Change a single ``cle = …`` line in the [outils] section (comments and the rest of the file preserved)."""
    import re
    if "'" in value or "\n" in value:
        raise ValueError("Chemin invalide.")
    text = Path(path).read_text(encoding="utf-8")
    begin = re.search(r"(?m)^\[tools\]\s*$", text)
    if not begin:
        raise ValueError("Section [outils] absente.")
    finish = re.search(r"(?m)^\[", text[begin.end():])
    area = text[begin.end(): begin.end() + finish.start()] if finish else text[begin.end():]
    pattern = re.compile(rf"(?m)^({re.escape(key)}\s*=\s*)(\"[^\"]*\"|'[^']*')([ \t]*#.*)?$")
    if not pattern.search(area):
        raise ValueError(f"Clé « {key} » absente de [outils].")
    zone2 = pattern.sub(lambda m: f"{m.group(1)}'{value}'{m.group(3) or ''}", area, count=1)
    new_name = text[: begin.end()] + zone2 + text[begin.end() + len(area):]
    _compat.toml_loads(new_name)
    tmp = Path(path).with_suffix(".tmp")
    tmp.write_text(new_name, encoding="utf-8", newline="")
    tmp.replace(path)


def find_blender() -> list[str]:
    """Look for blender.exe: Steam libraries (registry + libraryfolders.vdf), Program Files, PATH."""
    import os
    import re
    import shutil
    import sys
    seen_items: list[str] = []
    steam: list[Path] = []
    if sys.platform == "win32":
        try:
            import winreg
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Valve\Steam") as k:
                steam.append(Path(winreg.QueryValueEx(k, "SteamPath")[0]))
        except OSError:
            pass
    for base in (os.environ.get("ProgramFiles(x86)"), os.environ.get("ProgramFiles")):
        if base:
            steam.append(Path(base) / "Steam")
    libs: list[Path] = []
    for s in steam:
        libs.append(s)
        vdf = s / "steamapps" / "libraryfolders.vdf"
        if vdf.exists():
            libs += [Path(p.replace("\\\\", "\\")) for p in re.findall(r'"path"\s+"([^"]+)"', vdf.read_text(encoding="utf-8", errors="replace"))]
    candidates = [lib / "steamapps" / "common" / "Blender" / "blender.exe" for lib in libs]
    for base in (os.environ.get("ProgramFiles"),):
        if base:
            candidates += sorted((Path(base) / "Blender Foundation").glob("*/blender.exe"), reverse=True)
    w = shutil.which("blender")
    if w:
        candidates.append(Path(w))
    for c in candidates:
        if c.is_file() and str(c) not in seen_items:
            seen_items.append(str(c))
    return seen_items
