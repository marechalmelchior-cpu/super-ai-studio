"""Supervisor « / » shortcuts: ready-made requests (templates/shortcuts.json), extended or replaced by
the user's own (data/raccourcis.json, same shape). Read-only; an unreadable file is ignored."""
from __future__ import annotations

from .migrations import compatibility as json
import re
from .migrations.compatibility import TechnicalPath as Path


def _read(f: Path) -> list[dict]:
    try:
        d = json.loads(f.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return []
    out = []
    aliases = {"relire": "review", "bilan": "outcome", "ranger": "tidy", "corriger": "correct", "optimiser": "optimize"}
    for r in (d.get("shortcuts") if isinstance(d, dict) else d) or []:
        if isinstance(r, dict) and r.get("name") in aliases:
            r["name"] = aliases[r["name"]]
        if isinstance(r, dict) and re.fullmatch(r"[a-z0-9-]{1,30}", str(r.get("name", ""))) and str(r.get("text", "")).strip():
            out.append({"name": r["name"], "title": str(r.get("title") or r["name"])[:60], "text": str(r["text"])[:4000]})
    return out


def entries(code: Path, data: Path) -> list[dict]:
    all_items = {r["name"]: r for r in _read(Path(code) / "templates" / "shortcuts.json")}
    for r in _read(Path(data) / "shortcuts.json"):
        all_items[r["name"]] = {**r, "custom": True}
    return list(all_items.values())
