"""Connection status: memory, AI subscription tools, Blender, Unreal, Python.

Each line distinguishes: connected (proof obtained), missing, or not checked.
Checks reuse existing connections and start no service.
"""
from __future__ import annotations

import importlib.util
import sys


def check_all(studio, probe_tools: bool = True) -> dict:
    out: dict[str, dict] = {}
    h = studio.memory.health()
    out["memory"] = {"state": h.state, "backend": h.backend, "detail": h.detail, "pending": h.pending}
    out["python"] = {"state": "OK", "detail": sys.version.split()[0],
                     "langgraph": bool(importlib.util.find_spec("langgraph")),
                     "checkpoint_sqlite": bool(importlib.util.find_spec("langgraph.checkpoint.sqlite"))}
    if probe_tools:
        for name, ex in studio.executors.items():
            ok, info = ex.available()
            out[name] = {"state": "OK" if ok else "ABSENT", "detail": info}
        if out.get("api", {}).get("state") == "ABSENT" and any(out.get(k, {}).get("state") == "OK" for k in ("claude-code", "codex")):
            del out["api"]                               # API key optional when a subscription works
        from .connectors.apps import Blender, Unreal
        if studio.cfg["tools"].get("blender"):          # connectors: shown only if they were added
            b = Blender(studio.cfg["tools"].get("blender", "")).probe()
            out["blender"] = {"state": "OK" if b.get("ok") else "NON_VERIFIE", "detail": b.get("version") or b.get("detail", "")}
        if studio.cfg["tools"].get("unreal_editor_cmd"):
            u = Unreal(studio.cfg["tools"].get("unreal_editor_cmd", "")).probe()
            out["unreal"] = {"state": "OK" if u.get("ok") else "NON_VERIFIE", "detail": u.get("version") or u.get("detail", "")}
    spec = lambda m: bool(importlib.util.find_spec(m))
    reads = {"PDF": spec("pymupdf") or spec("fitz"), "images": spec("PIL"), "sons/vidéos": spec("faster_whisper") and spec("av")}
    needs = [k for k, v in reads.items() if not v]
    out["attachments_attached"] = {
        "state": "OK" if not needs else "PARTIEL",
        "detail": ("Lit : Word, Excel, PowerPoint, ZIP" + "".join(f", {k}" for k, v in reads.items() if v)
                   + (f". Manque : {', '.join(needs)} → scripts\\Install-Attachment-Readers.ps1 -Confirmer" if needs else "."))}
    out["chatgpt"] = {"state": "MANUEL", "detail": "Export/import de dossiers de contexte ; accès automatique non connecté."}
    return out
