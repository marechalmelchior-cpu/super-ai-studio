"""API keys encrypted on this PC, whatever the platform.

- Windows: DPAPI (tied to the Windows account);
- Mac and Linux: encryption with a local per-account key (file readable only by you, stored outside the
  studio folder, so never in its backups) — SHA-256 stream in counter mode + HMAC seal, standard library.
"""
from __future__ import annotations
from .migrations.compatibility import environment

import base64
import hashlib
import hmac
import os


import secrets
import sys
from .migrations.compatibility import TechnicalPath as Path


def _key_folder() -> Path:
    if environment("STUDIO_VAULT"):
        return Path(environment("STUDIO_VAULT"))
    if sys.platform == "darwin":
        return Path.home() / "Library" / "Application Support" / "super-ai-studio"
    return Path(os.environ.get("XDG_CONFIG_HOME") or Path.home() / ".config") / "super-ai-studio"


def _local_key() -> bytes:
    f = _key_folder() / "key"
    try:
        k = f.read_bytes()
        if len(k) == 32:
            return k
    except OSError:
        pass
    f.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    k = secrets.token_bytes(32)
    fd = os.open(f, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)          # never overwritten: a lost key would make the keys unreadable
    with os.fdopen(fd, "wb") as h:
        h.write(k)
    return k


def _keystream(k: bytes, nonce: bytes, n: int) -> bytes:
    out, i = b"", 0
    while len(out) < n:
        out += hashlib.sha256(k + nonce + i.to_bytes(8, "big")).digest()
        i += 1
    return out[:n]


def encrypt(text: str) -> str:
    if sys.platform == "win32":
        from .backup import protect
        return "dpapi:" + base64.b64encode(protect(text.encode())).decode()
    k, nonce, raw_text = _local_key(), secrets.token_bytes(16), text.encode()
    c = bytes(a ^ b for a, b in zip(raw_text, _keystream(k, nonce, len(raw_text))))
    seal = hmac.new(k, nonce + c, hashlib.sha256).digest()[:16]
    return "local1:" + base64.b64encode(nonce + seal + c).decode()


def decrypt(v: str) -> str:
    if not v:
        return ""
    category_kind, _, b = v.partition(":")
    raw = base64.b64decode(b)
    if category_kind == "dpapi":
        from .backup import unprotect
        return unprotect(raw).decode()
    if category_kind == "local1":
        k = _local_key()
        nonce, seal, c = raw[:16], raw[16:32], raw[32:]
        if not hmac.compare_digest(seal, hmac.new(k, nonce + c, hashlib.sha256).digest()[:16]):
            raise ValueError("Clé illisible sur ce compte : reconnecte cette IA.")
        return bytes(a ^ b for a, b in zip(c, _keystream(k, nonce, len(c)))).decode()
    return raw.decode()                                 # old local format (before 0.4.17)
