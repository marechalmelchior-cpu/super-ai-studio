"""Studio settings editable from Gestion (« Réglages » column).

Closed list: only these keys can be written, with their type and allowed values. Each write:
1. first copies ``studio.config.toml`` into ``Studio/data/previous-config/`` (nothing is ever deleted);
2. replaces ONE ``cle = valeur`` line in the section (comments and rest of the file kept; key added if missing);
3. checks that the file is still valid TOML, then writes it atomically;
4. updates the in-memory configuration. Settings read only at startup say so (``restart``).
"""
from __future__ import annotations

import re
import shutil
import tomllib
from .migrations import compatibility as _compat
from datetime import datetime
from .migrations.compatibility import TechnicalPath as Path

# (section, key) → description
SETTINGS: dict[tuple[str, str], dict] = {
    ("supervisor", "web"): {"type": "bool", "label": "Recherche sur le web", "group": "Superviseur"},
    ("user", "name"): {"type": "text", "label": "Ton prénom (agents et Superviseur)", "group": "Superviseur"},
    ("user", "language"): {"type": "str", "choices": ["fr", "en"], "label": "Langue · Language (fr / en)", "group": "Superviseur"},
    ("supervisor", "outcome"): {"type": "bool", "label": "Bilan du Superviseur à la fin de chaque tâche", "group": "Superviseur"},
    ("supervisor", "light_model"): {"type": "str", "pattern": r"[A-Za-z0-9._:/@-]{0,80}", "placeholder": "vide = choisi par les classements",
                                    "label": "Modèle léger pour les bilans et résumés (jamais pour la relecture)", "group": "Superviseur"},
    ("usage", "primary_limits"): {"type": "bool", "label": "Limites Claude en % (Gestion › Usage)", "group": "Limites et alertes"},
    ("usage", "secondary_limits"): {"type": "bool", "label": "Limites Codex en % (Gestion › Usage)", "group": "Limites et alertes"},
    ("usage", "primary_alert_5h_min"): {"type": "int", "choices": [0, 15, 30, 60, 90, 120], "unit": "min",
                                        "label": "Alerte : limite Claude atteinte dans moins de", "group": "Limites et alertes"},
    ("usage", "secondary_alert_5h_min"): {"type": "int", "choices": [0, 15, 30, 60, 90, 120], "unit": "min",
                                       "label": "Alerte : limite Codex atteinte dans moins de", "group": "Limites et alertes"},
    ("limits", "autonomy"): {"type": "str", "choices": ["complete", "validation"],
                               "label": "Tâches : finir seules (complete) ou attendre ma validation", "group": "Exécution des tâches"},
    ("limits", "concurrent_tasks"): {"type": "int", "choices": [1, 2, 3, 4], "restart": True,
                                        "label": "Tâches en parallèle", "group": "Exécution des tâches"},
    ("limits", "max_corrections"): {"type": "int", "choices": [0, 1, 2, 3],
                                     "label": "Corrections auto après relecture", "group": "Exécution des tâches"},
    ("audit", "model_reviewer"): {"type": "bool", "restart": True,
                                   "label": "Relecture par un second modèle", "group": "Exécution des tâches"},
    ("audit", "incremental_review"): {"type": "bool", "label": "Relecture incrémentale après une correction (essai)",
                                      "group": "Exécution des tâches"},
    # Effort levels follow each AI's own models (chosen per task, per agent or in the Supervisor's header);
    # MCP servers are chosen per project (project › Équipe), never here.
    ("api_agents", "commands"): {"type": "str", "choices": ["safe", "all", "no"], "labels": {"safe": "sures", "all": "toutes", "no": "non"},
                                  "label": "Commandes des IA connectées par clé ou en local (sures = tests et compilation)", "group": "Technique"},
    ("api_agents", "local_context"): {"type": "int", "choices": [8192, 16384, 32768, 65536, 131072], "unit": "jetons",
                                       "label": "IA locales : mémoire de travail max (plus = plus de mémoire vidéo)",
                                       "group": "Technique"},
    ("night", "begin"): {"type": "str", "choices": ["22:00", "23:00", "00:00", "01:00", "02:00", "03:00"],
                        "label": "Tâches de nuit : début", "group": "Exécution des tâches"},
    ("night", "end"): {"type": "str", "choices": ["05:00", "06:00", "07:00", "08:00", "09:00"],
                      "label": "Tâches de nuit : fin (rapport ensuite)", "group": "Exécution des tâches"},
    ("maintenance", "automatic_cleanup"): {"type": "bool", "label": "Ménage automatique (vieilles sauvegardes, copies et caches)", "group": "Entretien"},
    ("interface", "mobile_access"): {"type": "bool", "cache": True,          # button on the « Téléphone » card
                                    "label": "Accès depuis le téléphone (Tailscale)", "group": "Téléphone"},
    ("tools", "blender"): {"type": "path_value", "cache": True, "label": "Blender (blender.exe)", "group": "Connecteurs"},
    ("tools", "unreal_editor_cmd"): {"type": "path_value", "cache": True, "label": "Unreal (UnrealEditor-Cmd.exe)", "group": "Connecteurs"},
}


def entries(cfg: dict) -> list[dict]:
    """Settings with their current value, in display order."""
    return [{"section": s, "key": k, "value": cfg.get(s, {}).get(k), **d} for (s, k), d in SETTINGS.items() if not d.get("cache")]


def validate(section: str, key: str, value):
    d = SETTINGS.get((section, key))
    if not d:
        raise ValueError("Réglage inconnu.")
    t = d["type"]
    if t == "bool":
        if not isinstance(value, bool):
            raise ValueError("Oui ou non attendu.")
        return value
    if t == "int":
        try:
            v = int(value)
        except (TypeError, ValueError):
            raise ValueError("Nombre attendu.") from None
        if "choices" in d and v not in d["choices"]:
            raise ValueError("Valeur non proposée.")
        return v
    v = str(value or "").strip()
    if t == "text" and not (0 < len(v) <= 40):
        raise ValueError("Entre 1 et 40 caractères.")
    if "'" in v or "\n" in v or "\r" in v or len(v) > 400:
        raise ValueError("Valeur invalide.")
    if "choices" in d and v not in d["choices"]:
        raise ValueError("Valeur non proposée.")
    if "pattern" in d and not re.fullmatch(d["pattern"], v):
        raise ValueError("Valeur invalide.")
    return v


def _literal(v) -> str:
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, int):
        return str(v)
    return f"'{v}'"                       # TOML literal string: the \ in Windows paths stay as they are


def store_file(path: Path, section: str, key: str, value) -> Path:
    """Writes a value to the file; returns the copy made before the change."""
    path = Path(path)
    text = path.read_text(encoding="utf-8")
    line = f"{key} = {_literal(value)}"
    begin = re.search(rf"(?m)^\[{re.escape(section)}\]\s*$", text)
    if not begin:
        new_name = text.rstrip("\n") + f"\n\n[{section}]\n{line}\n"
    else:
        finish = re.search(r"(?m)^\[", text[begin.end():])
        area = text[begin.end(): begin.end() + finish.start()] if finish else text[begin.end():]
        pattern = re.compile(rf"(?m)^({re.escape(key)}\s*=\s*)(\"[^\"\n]*\"|'[^'\n]*'|true|false|-?\d+(?:\.\d+)?)([ \t]*#.*)?$")
        if pattern.search(area):
            zone2 = pattern.sub(lambda m: f"{m.group(1)}{_literal(value)}{m.group(3) or ''}", area, count=1)
        else:
            zone2 = area.rstrip("\n") + f"\n{line}\n" + ("\n" if finish else "")
            if not area.strip():
                zone2 = f"\n{line}\n" + ("\n" if finish else "")
        new_name = text[: begin.end()] + zone2 + text[begin.end() + len(area):]
    parsed = _compat.toml_loads(new_name)                          # the file must stay valid…
    if parsed.get(section, {}).get(key) != value:           # …and contain exactly the new value
        raise ValueError("Écriture non vérifiée : rien n'est modifié.")
    copies = path.parent / "data" / "previous-config"
    copies.mkdir(parents=True, exist_ok=True)
    copy_dir = copies / f"studio.config-{datetime.now().strftime('%Y%m%d-%H%M%S-%f')}.toml"
    shutil.copy2(path, copy_dir)
    try:
        from .cleanup import cap
        cap(copies, "studio.config-*.toml", 10)     # the last 10 copies kept
    except Exception:                                   # noqa: BLE001
        pass
    tmp = path.with_suffix(".tmp")
    tmp.write_text(new_name, encoding="utf-8", newline="")
    tmp.replace(path)
    return copy_dir


def modify(cfg: dict, path: Path, section: str, key: str, value) -> dict:
    v = validate(section, key, value)
    store_file(path, section, key, v)
    cfg.setdefault(section, {})[key] = v
    d = SETTINGS[(section, key)]
    return {"ok": True, "value": v, "restart": bool(d.get("restart")),
            "message": "Enregistré : pris en compte au prochain démarrage du studio." if d.get("restart") else "Enregistré."}
