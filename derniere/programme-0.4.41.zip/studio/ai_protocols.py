"""Native transports that preserve reasoning state across tool turns."""
from __future__ import annotations

import json


def anthropic_chat(c, messages, tools, delay, effort):
    from .ai import _request, AIError
    from .ai_effort import parameters
    system, native = [], []
    for message in messages:
        role = message.get("role")
        if role in ("system", "developer"):
            system.append({"type": "text", "text": str(message.get("content") or "")})
            continue
        if role == "tool":
            blocks = [{"type": "tool_result", "tool_use_id": message["tool_call_id"], "content": str(message.get("content") or "")}]
            role = "user"
        elif message.get("_anthropic_content"):
            blocks = message["_anthropic_content"]
        else:
            content = message.get("content") or ""
            if isinstance(content, str):
                blocks = [{"type": "text", "text": content}] if content else []
            else:
                blocks = []
                for block in content:
                    if block.get("type") == "text":
                        blocks.append({"type": "text", "text": block.get("text", "")})
                    elif block.get("type") == "image_url":
                        url = block["image_url"]["url"]
                        if url.startswith("data:"):
                            header, data = url.split(",", 1)
                            source = {"type": "base64", "media_type": header[5:].split(';')[0], "data": data}
                        else:
                            source = {"type": "url", "url": url}
                        blocks.append({"type": "image", "source": source})
            for call in message.get("tool_calls") or []:
                function = call["function"]
                args = function.get("arguments") or "{}"
                blocks.append({"type": "tool_use", "id": call["id"], "name": function["name"],
                               "input": json.loads(args) if isinstance(args, str) else args})
        if not blocks:
            continue
        if native and native[-1]["role"] == role:
            native[-1]["content"].extend(blocks)
        else:
            native.append({"role": role, "content": blocks})
    params = parameters(c, effort)
    budget = (params.get("thinking") or {}).get("budget_tokens", 0)
    body = {"model": c["model"], "messages": native, "max_tokens": max(16384, budget + 8192), **params}
    if system:
        body["system"] = system
    if tools:
        body["tools"] = [{"name": t["function"]["name"], "description": t["function"].get("description", ""),
                          "input_schema": t["function"].get("parameters", {"type": "object"})} for t in tools]
    response = _request(c, "/messages", body, delay)
    blocks = response.get("content") or []
    calls = [{"id": b["id"], "type": "function", "function": {"name": b["name"], "arguments": json.dumps(b.get("input") or {})}}
             for b in blocks if b.get("type") == "tool_use"]
    usage = response.get("usage") or {}
    message = {"role": "assistant", "content": "".join(b.get("text", "") for b in blocks if b.get("type") == "text"),
               "_anthropic_content": blocks}
    if calls:
        message["tool_calls"] = calls
    if not blocks and response.get("error"):
        raise AIError("L’IA a refusé la requête.")
    return {"message": message, "usage": {"prompt_tokens": usage.get("input_tokens", 0),
            "completion_tokens": usage.get("output_tokens", 0), "cache_read_input_tokens": usage.get("cache_read_input_tokens", 0)},
            "end": response.get("stop_reason", ""), "model": response.get("model") or c["model"]}


def responses_chat(c, messages, tools, delay, effort):
    from .ai import _request
    from .ai_effort import parameters
    items = []
    for message in messages:
        if message.get("_responses_items"):
            items.extend(message["_responses_items"])
        elif message.get("role") == "tool":
            items.append({"type": "function_call_output", "call_id": message["tool_call_id"], "output": str(message.get("content") or "")})
        else:
            content = message.get("content") or ""
            if isinstance(content, list):
                content = [{"type": "input_text", "text": b.get("text", "")} if b.get("type") == "text" else
                           {"type": "input_image", "image_url": b["image_url"]["url"]} for b in content if b.get("type") in ("text", "image_url")]
            if content:
                items.append({"role": message["role"], "content": content})
            for call in message.get("tool_calls") or []:
                items.append({"type": "function_call", "call_id": call["id"], **call["function"]})
    body = {"model": c["model"], "input": items, "store": False, "include": ["reasoning.encrypted_content"]}
    params = parameters(c, effort)
    if params:
        body["reasoning"] = {"effort": params["reasoning_effort"]}
    if tools:
        body["tools"] = [{"type": "function", **t["function"]} for t in tools]
    response = _request(c, "/responses", body, delay)
    output = response.get("output") or []
    calls = [{"id": b["call_id"], "type": "function", "function": {"name": b["name"], "arguments": b["arguments"]}}
             for b in output if b.get("type") == "function_call"]
    message = {"role": "assistant", "content": "".join(t.get("text", "") for b in output if b.get("type") == "message"
                                                         for t in b.get("content", []) if t.get("type") == "output_text"),
               "_responses_items": output}
    if calls:
        message["tool_calls"] = calls
    usage = response.get("usage") or {}
    return {"message": message, "usage": {"prompt_tokens": usage.get("input_tokens", 0), "completion_tokens": usage.get("output_tokens", 0)},
            "end": response.get("status", ""), "model": response.get("model") or c["model"]}
