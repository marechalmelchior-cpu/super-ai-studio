"""SIMULATED demo scenarios (test project and topic without a repository).

The first attempt deliberately contains a defect to show that
the audit flags it and triggers a correction.
"""
from __future__ import annotations

from .migrations.compatibility import TechnicalPath as Path

from .connectors.base import Mission
from .connectors.simulation import SimulatedExecutor


def _code_try1(m: Mission, work: Path) -> str:
    (work / "calc.py").write_text(
        '"""Projet de TEST du studio."""\n\n\ndef average(values):\n'
        "    if not values:\n        return 0\n    return sum(values) / len(values)\n", encoding="utf-8")
    return "calc.py : liste vide gérée en renvoyant 0."


def _code_try2(m: Mission, work: Path) -> str:
    (work / "calc.py").write_text(
        '"""Projet de TEST du studio."""\n\n\ndef average(values):\n'
        "    if not values:\n        raise ValueError(\"average() : la liste est vide\")\n"
        "    return sum(values) / len(values)\n", encoding="utf-8")
    return "calc.py : ValueError explicite pour une liste vide (retour d'audit pris en compte)."


def _topic_try1(m: Mission, work: Path) -> str:
    (work / "note.md").write_text("# Note de veille\n\n## Synthèse\nLangGraph assure la reprise via ses points de reprise.\n",
                                  encoding="utf-8")
    return "note.md rédigée."


def _topic_try2(m: Mission, work: Path) -> str:
    (work / "note.md").write_text(
        "# Note de veille\n\n## Synthèse\nLangGraph assure la reprise via ses points de reprise.\n\n"
        "## Sources\n- https://docs.langchain.com/oss/python/langgraph/persistence\n", encoding="utf-8")
    return "note.md complétée avec ses sources."


def demo_executors() -> dict:
    return {"code": SimulatedExecutor({1: _code_try1, 2: _code_try2}),
            "topic": SimulatedExecutor({1: _topic_try1, 2: _topic_try2})}
