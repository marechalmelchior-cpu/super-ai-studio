"""Studio workspace: the data (rules, skills, projects, tasks, memory, settings) kept apart from the program.

- The program (``Studio`` folder containing ``studio/``) can be installed anywhere; an update never touches
  the workspace.
- The workspace is found in this order: ``STUDIO_HOME`` variable; the user's pointer file
  (``%APPDATA%\\SuperAIStudio\\espace.json``); otherwise the old layout, where the program lives INSIDE the workspace
  (``AI-Workspace\\Studio\\studio``) — the case of the original studio, which keeps working unchanged.
- First launch without a workspace: the wizard asks for a folder. A folder that already holds a workspace is
  simply joined (nothing copied or replaced); otherwise the workspace is created with the base and the chosen packs.
  No existing file is ever overwritten.
"""
from __future__ import annotations
from .migrations.compatibility import environment

from .migrations import compatibility as json
import os


import re
import shutil
import sys
import tomllib
from .migrations import compatibility as _compat
from .migrations.compatibility import TechnicalPath as Path

CODE = Path(__file__).resolve().parents[1]               # program folder (contains studio/, templates/, scripts/)
TEMPLATES = CODE / "templates"


def pointer_file() -> Path:
    if environment("STUDIO_POINTER"):
        return Path(environment("STUDIO_POINTER"))
    base = os.environ.get("APPDATA") if sys.platform == "win32" else None
    base = Path(base) if base else Path.home() / ".config"
    return base / "SuperAIStudio" / "workspace.json"


def is_workspace(d: Path) -> bool:
    return (Path(d) / "Studio" / "studio.config.toml").is_file()


def configured_root() -> Path | None:
    """Workspace root, or None if the studio has no workspace yet (first launch)."""
    if environment("STUDIO_HOME"):
        return Path(os.environ["STUDIO_HOME"]).resolve()
    try:
        r = Path(json.loads(pointer_file().read_text(encoding="utf-8"))["root"])
        if is_workspace(r):
            return r.resolve()
    except (OSError, ValueError, KeyError, TypeError):
        pass
    old = CODE.parent                                   # historical layout: AI-Workspace\Studio\studio
    if CODE.name == "Studio" and (is_workspace(old) or (old / "Regles").is_dir() or (old / "Projets").is_dir()):
        return old.resolve()
    return None


def write_pointer(root_dir: Path) -> None:
    f = pointer_file()
    f.parent.mkdir(parents=True, exist_ok=True)
    t = f.with_suffix(".partiel")
    t.write_text(json.dumps({"root": str(Path(root_dir).resolve())}, ensure_ascii=False), encoding="utf-8")
    t.replace(f)


def proposed_folder() -> Path:
    docs = Path.home() / "Documents"
    return (docs if docs.is_dir() else Path.home()) / "Studio IA"


# ------------------------------------------------------------------ user's first name
_VOWELS = "AEIOUYÉÈÊÂÎÔaeiouyéèêâîô"


def replace_name(text: str, name: str) -> str:
    """Studio texts speak of « l'utilisateur »; with a first name set ([utilisateur] nom), it replaces it
    (« de l'utilisateur » → « d'Alex » before a vowel). Old texts written with « Mel » follow the same rule.
    Without a first name: text unchanged."""
    name = (name or "").strip()
    if not name:
        return text
    vowel = name[0] in _VOWELS
    for topic in ("l'utilisateur", "Mel"):
        if topic == name:
            continue
        text = re.sub(rf"\b([dD])e {topic}\b", lambda m: f"{m.group(1)}'{name}" if vowel else f"{m.group(1)}e {name}", text)
        text = re.sub(rf"\b([qQ])ue {topic}\b", lambda m: f"{m.group(1)}u'{name}" if vowel else f"{m.group(1)}ue {name}", text)
        text = re.sub(rf"\b[lL]'utilisateur\b" if topic != "Mel" else r"\bMel\b", name, text)
    return text




_current_name = {"name": ""}


def set_name(cfg: dict) -> str:
    """User's first name ([utilisateur] nom, Réglages › « Ton prénom »); missing = neutral texts."""
    _current_name["name"] = str((cfg.get("user") or {}).get("name") or "").strip()
    return _current_name["name"]


def name() -> str:
    return _current_name["name"]


def custom(text: str) -> str:
    """Texts sent to agents or shown in the interface: « l'utilisateur » becomes their first name if set."""
    return replace_name(text, _current_name['name']) if isinstance(text, str) else text



# ------------------------------------------------------------------ packs
def packs() -> list[dict]:
    out = []
    for d in sorted((TEMPLATES / "packs").glob("*/pack.toml")):
        p = _compat.toml_loads(d.read_text(encoding="utf-8"))
        out.append({"id": d.parent.name, "name": p["name"], "description": p["description"],
                    "skills": p.get("skills", []), "roles": p.get("roles", [])})
    return out


def _copy(src: Path, dest: Path, replacements: dict[str, str], name: str, created: list[str],
          rename: dict[str, str] | None = None) -> None:
    """Copies a template folder without ever overwriting an existing file; personalized texts (first name, paths).
    rename: top-level names to localize (folder or file). A renamed file whose new name differs is skipped
    when the caller writes its own version (README in another language)."""
    rename = rename or {}
    for f in sorted(src.rglob("*")):
        if f.is_dir():
            continue
        parts = f.relative_to(src).parts
        top = rename.get(parts[0], parts[0])
        if len(parts) == 1 and parts[0] in rename and top != parts[0] and f.suffix == ".md":
            continue                                    # localized README written by the caller
        target = dest.joinpath(top, *parts[1:])
        if target.exists():
            continue
        target.parent.mkdir(parents=True, exist_ok=True)
        if f.suffix.lower() in (".md", ".toml", ".txt"):
            t = replace_name(f.read_text(encoding="utf-8"), name)   # first name first: the paths put in after are never altered
            for k, v in replacements.items():
                t = t.replace(k, v)
            target.write_text(t, encoding="utf-8")
        else:
            shutil.copy2(f, target)
        created.append(str(target))


def install_pack(root_dir: Path, pack: str, name: str) -> list[str]:
    """Adds a pack's skills and roles to a workspace (nothing existing is replaced)."""
    pack = json.canonical(pack)
    from .paths import StudioPaths
    language = StudioPaths(Path(root_dir)).lang
    d = TEMPLATES / "packs" / pack
    if not (d / "pack.toml").is_file():
        raise ValueError(f"Pack inconnu : {pack}")
    created: list[str] = []
    repl = {"{{NAME}}": name, "{{LANGUAGE}}": language, "{{LANGUAGE_NAME}}": "français" if language == "fr" else "English", "{{STUDIO_CMD}}": f'"{CODE / "studio.cmd"}"', "{{NOM}}": name}
    if (d / "Skills").is_dir():
        _copy(d / "Skills", Path(root_dir) / "Skills", repl, name, created)
    if (d / "roles").is_dir():
        _copy(d / "roles", Path(root_dir) / "Studio" / "roles", repl, name, created)
    return created


def packs_state(root_dir: Path) -> list[dict]:
    """Offered packs, with « installe » when all their skills and roles are already in the workspace."""
    out = []
    for p in packs():
        present = all((Path(root_dir) / "Skills" / s / "SKILL.md").is_file() for s in p["skills"]) and \
            all((Path(root_dir) / "Studio" / "roles" / f"{r}.toml").is_file() for r in p["roles"])
        out.append({**p, "installed": present})
    return out


_STOP_WORDS = {"pour", "avec", "dans", "les", "des", "une", "qui", "que", "sur", "par", "son", "ses", "est", "sont", "aux",
               "the", "and", "for", "with", "this", "that", "from", "faire", "fait", "tout", "tous", "plus"}



def create_agent(root_dir: Path, name: str, mission: str, deliverable: str = "", tool: str = "auto") -> dict:
    """New specialized agent (Studio/roles/<id>.toml) from three sentences; nothing existing is replaced.
    The Supervisor picks it when a request is about its subject; it works with the connected AI."""
    name, mission, deliverable = (name or "").strip()[:60], (mission or "").strip()[:800], (deliverable or "").strip()[:300]
    if not name or len(mission) < 10:
        raise ValueError("Donne un nom et une phrase sur ce que fait l'agent.")
    if tool not in ("auto", "claude-code", "codex"):
        raise ValueError("Outil inconnu.")
    import unicodedata
    base = re.sub(r"[^a-z0-9]+", "-", unicodedata.normalize("NFKD", name.lower()).encode("ascii", "ignore").decode()).strip("-")[:40] or "agent"
    base = json.ROLE_ALIASES.get(base, base)
    folder = Path(root_dir) / "Studio" / "roles"
    folder.mkdir(parents=True, exist_ok=True)
    ident, n = base, 2
    while (folder / f"{ident}.toml").exists() or ident == "reviewer":
        ident, n = f"{base}-{n}", n + 1
    words = []
    for m in re.findall(r"[\wÀ-ÿ-]{4,}", f"{name} {mission} {deliverable}".lower()):
        if m not in _STOP_WORDS and m not in words:
            words.append(m)
    q = lambda s: json.dumps(s, ensure_ascii=False)                 # valid TOML string (escapes included)
    text = "\n".join([
        f"id = {q(ident)}", f"name = {q(name)}", 'domains = ["code", "doc", "topic", "web", "unreal", "python", "outillage"]',
        f"executor = {q('claude-code' if tool == 'auto' else tool)}",
        f"keywords = {q(words[:14])}",
        'tools = ["Read", "Glob", "Grep", "Write", "Edit"]',
        f"deliverables = {q([deliverable or 'Le livrable demandé, dans le dossier de la tâche'])}",
        'criteria = ["Le livrable demandé est présent et complet", "Compte rendu clair : fait, vérifié, reste à faire"]',
        'limits = ["Ne supprime rien", "Reste dans le périmètre de la demande"]',
        f"instructions = {q(mission)}", "# agent créé depuis Gestion › Agents", ""])
    _compat.toml_loads(text)
    (folder / f"{ident}.toml").write_text(text, encoding="utf-8")
    return {"id": ident, "name": name}


README_EN = """# Your AI studio

Everything you do with the studio lives here, tidy:

- `Projects/`: one sheet per project (context for the agents). The project's files stay in their own folder.
- `Topics/`: one folder per topic (ideas, research, images…) with its context and its results sorted by kind:
  `Images/`, `Documents/`, `3D/`, `Sounds/`, `Videos/`, `Code/`.
- `Tasks/`: one folder per task, « date + title ». The report is `RESULTAT.md`; `details/` holds the technical files.
- `Skills/`: your agents' know-how, one folder per skill.
- `Rules/`: rules and .md files shared by all your AIs.
- `Backups/`: one backup per day (7 days + 4 weeks kept).
- `Archives/`: what you remove from the studio (nothing is ever erased).
- `Studio/`: technical (settings, agents, memory). No need to touch it.

The studio cleans up after itself: old backups, work copies of finished tasks, caches. Never your projects,
topics or their results.
"""


def create_workspace(root_dir: Path, name: str, pack_choice: list[str], language: str = "fr") -> dict:
    """Creates (or joins) the workspace and registers it as the user's workspace. Nothing is overwritten."""
    root_dir = Path(root_dir).expanduser()
    if not root_dir.is_absolute():
        raise ValueError("Indique un chemin complet (ex. C:\\Users\\toi\\Documents\\Studio IA).")
    name = re.sub(r"[\r\n'\"\\]", "", (name or "").strip())[:40]
    if is_workspace(root_dir):
        write_pointer(root_dir)
        return {"joined": True, "root": str(root_dir), "created": []}
    if root_dir.exists() and any(root_dir.iterdir()):
        root_dir = root_dir / "Studio IA"                       # folder already filled: the workspace goes into a subfolder
        if is_workspace(root_dir):
            write_pointer(root_dir)
            return {"joined": True, "root": str(root_dir), "created": []}
    root_dir.mkdir(parents=True, exist_ok=True)
    created: list[str] = []
    language = language if language in ("fr", "en") else "fr"
    repl = {"{{NAME}}": name, "{{LANGUAGE}}": language, "{{LANGUAGE_NAME}}": "français" if language == "fr" else "English", "{{STUDIO_CMD}}": f'"{CODE / "studio.cmd"}"', "{{NOM}}": name, "{{LANGUE}}": language,
            "{{LANGUE_NOM}}": "français" if language == "fr" else "English"}
    from .paths import FOLDERS, StudioPaths, folder_language
    names = FOLDERS[language]
    _copy(TEMPLATES / "workspace", root_dir, repl, name, created,
          rename={FOLDERS["fr"][k]: names[k] for k in ("rules", "projects", "topics", "tasks", "backups", "deliverables", "readme")})
    # (older installations still hold French template folders — Projets, Sujets…: they follow the language too)
    if language == "en":
        (root_dir / "README.md").write_text(README_EN, encoding="utf-8")          # the French text was not copied
    folder_language.cache_clear()
    for p in pack_choice:
        created += install_pack(root_dir, p, name)
    paths = StudioPaths(root_dir)
    for d in (paths.projects, paths.topics, paths.runs, paths.data):   # backups and archives: created when needed
        d.mkdir(parents=True, exist_ok=True)
    write_pointer(root_dir)
    return {"joined": False, "root": str(root_dir), "created": created}


# ------------------------------------------------------------------ tools already on the PC (read-only)
def detect_tools() -> list[dict]:
    """What the studio already finds: nothing is installed or modified."""
    import urllib.request
    from .connectors.base import find_exe

    def connected(task_files: list[Path]) -> bool:
        return any(f.exists() for f in task_files)

    h = Path.home()
    out = []
    from .connectors.primary_cli import WIN_CANDIDATES
    primary_cli = find_exe("claude", WIN_CANDIDATES)
    out.append({"id": "claude", "name": "Claude Code", "present": bool(primary_cli),
                "detail": ("connecté" if connected([h / ".claude" / ".credentials.json", h / ".claude.json"]) else "installé")
                if primary_cli else "pas installé (facultatif)"})
    secondary_cli = find_exe("codex", [str(h / "AppData/Roaming/npm/codex.cmd")])
    out.append({"id": "codex", "name": "Codex (ChatGPT)", "present": bool(secondary_cli),
                "detail": ("connecté" if connected([h / ".codex" / "auth.json"]) else "installé") if secondary_cli else "pas installé (facultatif)"})
    git = shutil.which("git")
    out.append({"id": "git", "name": "Git", "present": bool(git), "detail": "installé" if git else "pas installé (conseillé)"})
    local_runner = False
    for url in ("http://127.0.0.1:11434/api/tags", "http://127.0.0.1:1234/v1/models"):
        try:
            with urllib.request.urlopen(url, timeout=1):
                local_runner = True
                break
        except OSError:
            pass
    out.append({"id": "local", "name": "IA locale (Ollama, LM Studio)", "present": local_runner,
                "detail": "en marche" if local_runner else "non détectée (facultatif)"})
    return out
