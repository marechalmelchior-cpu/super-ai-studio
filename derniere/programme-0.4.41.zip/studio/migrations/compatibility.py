"""Lecture de l'ancien format, écriture exclusivement dans le nouveau format."""
from __future__ import annotations
import json as _json
import os
import re
import tomllib
from pathlib import Path
from .names import KEYS, FILES, ID_RENAMES, ROLE_ALIASES, SKILL_ALIASES, TOOL_KEYS
from .schemas import CONFIG_FIELDS, PROJECT_FIELDS, ROLE_FIELDS, PACK_FIELDS

# Les phrases, modèles, identifiants de projet et contenus utilisateur restent intacts.
ENUM_FIELDS = {"state", "status", "decision", "role", "producer", "auditor", "executor", "isolation",
               "application", "isolation", "provider", "source", "agent_mode", "mode", "mcp_unreal", "commands", "on_failure", "kind",
               "category", "type", "author", "autonomy"}
CONTENT_FIELDS = {"text", "request", "summary", "description", "message", "note", "detail", "content",
                  "context", "guidance", "instructions", "keywords", "rules", "checks", "documents"}
ROLE_IDS = {"programmeur", "auditeur", "producteur", "chercheur", "artiste-technique", "directeur-artistique",
            "designer-ui", "dev-mobile", "developpeur-web", "expert-godot", "illustrateur", "scenariste",
            "seo-contenu", "securite-donnees", "accessibilite", "admin-outillage", "animateur-technique",
            "archiviste", "entretien", "equilibrage", "gardien-licences", "ia-personnages", "localisation",
            "optimisation", "retro-ingenierie"}

CANONICAL_KEYS = frozenset(KEYS.values())
STRUCTURAL_KEYS = frozenset({"id", "options", "roles", "team", "teams", "params", "parameters", "source_options",
                          "items", "data", "result", "results", "usage", "artifacts", "steps", "stage", "stages",
                          "settings", "targets", "scope", "provenance", "fields", "defaults", "limits", "models",
                          "configuration", "context", "changes", "execution", "verification", "audit", "decision",
                          "total"})


def canonical(value: str) -> str:
    return KEYS.get(value, value)

def normalize(value, field: str = ""):
    if isinstance(value, dict):
        out = {}
        for key, item in value.items():
            role_context = field in {"roles", "team", "teams", "role_map"} or (isinstance(field, str) and field.startswith(("project:", "topic:")))
            role_card = isinstance(item, dict) and bool(set(item) & {"actif", "modele", "executeur", "consignes", "active", "model", "instructions"})
            new = ROLE_ALIASES.get(key, key) if role_context and role_card else canonical(key)
            if key != new and new in value:
                continue                 # la clé canonique explicite est prioritaire
            known = key in KEYS or new in CANONICAL_KEYS or new in STRUCTURAL_KEYS or (isinstance(key, str) and key.startswith(("project:", "topic:")))
            role_card = role_context and role_card
            opaque = isinstance(item, (dict, list)) and not known and not role_card
            fixed = item if new in CONTENT_FIELDS or opaque else normalize(item, new)
            if new in out and out[new] != fixed:
                raise ValueError("Ancien et nouveau noms en conflit ; migration interrompue.")
            out[new] = fixed
        return out
    if isinstance(value, list):
        return [normalize(item, field) for item in value]
    if isinstance(value, str) and (field in ENUM_FIELDS or (isinstance(field, str) and field.startswith(("project:", "topic:")) and value in ("rapide", "normal", "max"))):
        return canonical_value(value, field)
    return value

OPAQUE_JSON_FILES = frozenset({"mcp.json", "mcp-secrets.json", "mcp-agent.json"})


def raw_loads(value, *args, **kwargs):
    """Les formats externes et leurs noms personnalisés ne sont jamais traduits."""
    return _json.loads(value, *args, **kwargs)


def normalize_mcp_cache(value):
    if not isinstance(value, dict):
        return value
    aliases = {"empreinte": "fingerprint", "outils": "tools"}
    return {server: {aliases.get(key,key): item for key,item in entry.items()} if isinstance(entry,dict) else entry
            for server,entry in value.items()}


def loads(value, *args, **kwargs):
    return normalize(_json.loads(value, *args, **kwargs))

def load(stream, *args, **kwargs):
    return normalize(_json.load(stream, *args, **kwargs))

def toml_load(stream):
    return normalize_toml(tomllib.load(stream))

def toml_loads(value):
    return normalize_toml(tomllib.loads(value))

def __getattr__(name):
    return getattr(_json, name)

def _renamed_path(path, reverse=False):
    path = Path(path)
    parts = list(path.parts)
    positions = []
    for index, part in enumerate(parts):
        if part == "data" and index and parts[index-1] == "Studio" and index + 1 < len(parts):
            positions = [index + 1]
            break
        if part == "details" and index + 1 == len(parts) - 1:
            positions = [index + 1]
            break
        if part == "SuperAIStudio" and index + 1 == len(parts) - 1:
            positions = [index + 1]
            break
    if not positions and len(parts) >= 3 and parts[-3] in ("Taches", "Tasks") and parts[-1].startswith(".studio-worktree-"):
        positions = [len(parts)-1]
    if not positions:
        return path
    mapping = {new: old for old, new in FILES.items()} if reverse else FILES
    for index in positions:
        part = parts[index]
        for old, new in sorted(mapping.items(), key=lambda pair: len(pair[0]), reverse=True):
            if part == old or (old.endswith("-") and part.startswith(old)):
                parts[index] = new + part[len(old):]
                break
    return Path(*parts)


def legacy_path(path):
    path = Path(path)
    if path.exists():
        return path
    old = _renamed_path(path, reverse=True)
    if old != path and old.exists():
        # Le repli ne peut pas suivre un lien qui sort du dossier technique demandé.
        common = Path(*path.parts[:next(i+1 for i, part in enumerate(path.parts) if part in ("data", "details", "SuperAIStudio", "Taches", "Tasks"))])
        if old.resolve().is_relative_to(common.resolve()):
            return old
    return path

class TechnicalPath(type(Path())):
    """Le repli concerne seulement la lecture ; open(..., 'w') vise toujours le nouveau chemin."""
    def open(self, mode="r", *args, **kwargs):
        target = legacy_path(Path(self)) if mode in ("r", "rb", "rt") else Path(self)
        return target.open(mode, *args, **kwargs)
    def exists(self, *, follow_symlinks=True):
        return legacy_path(Path(self)).exists()
    def is_file(self, *, follow_symlinks=True):
        return legacy_path(Path(self)).is_file()
    def is_dir(self):
        return legacy_path(Path(self)).is_dir()
    def stat(self, *, follow_symlinks=True):
        return legacy_path(Path(self)).stat(follow_symlinks=follow_symlinks)
    def iterdir(self):
        base = legacy_path(Path(self))
        for result in base.iterdir():
            yield type(self)(_renamed_path(result))
    def glob(self, pattern, **kwargs):
        found = set()
        patterns = [pattern]
        for old, new in FILES.items():
            if new in pattern:
                patterns.append(pattern.replace(new, old))
        for item in patterns:
            base = legacy_path(Path(self))
            for result in base.glob(item, **kwargs):
                result = type(self)(_renamed_path(result))
                if result not in found:
                    found.add(result)
                    yield result

def api_path(path):
    if not path.startswith("/api/"):
        return path
    # Une composante inconnue est un identifiant utilisateur ; ne jamais découper son nom.
    return "/".join(part if part in CANONICAL_KEYS else KEYS.get(part, part) for part in path.split("/"))


def environment(name, default=None):
    value = os.environ.get(name)
    if value is not None:
        return value
    old = next((key for key, new in KEYS.items() if key.startswith("STUDIO_") and new == name), name)
    return os.environ.get(old, default)


def normalize_catalog(value, field=""):
    """Convertit le schéma publié connu ; descriptions et extensions restent opaques."""
    containers = {"categories", "domains", "roles", "source", "sources", "files", "variables", "models", "items", "elements", "new", "skills", "packs", "pricing", "metrics", "members", "base"}
    if field in CONTENT_FIELDS:
        return value
    if isinstance(value, dict):
        out = {}
        for key, item in value.items():
            new = canonical_value(key, "category") if field == "categories" else canonical(key)
            known = key in KEYS or new in CANONICAL_KEYS or new in containers
            if not known and isinstance(item, (dict, list)):
                out[key] = item
            else:
                out[new] = normalize_catalog(item, new)
        return out
    if isinstance(value, list):
        return [normalize_catalog(item, field) for item in value]
    if isinstance(value, str):
        if field in {"id", "members", "base"}:
            return ID_RENAMES.get(value, value)
        if field == "roles":
            return ROLE_ALIASES.get(value, value)
        if field == "skills":
            return SKILL_ALIASES.get(value, value)
        if field == "pack":
            return {"avance": "advanced"}.get(value, value)
        if field in {"category", "type", "kind", "provider"}:
            return canonical_value(value, field)
    return value


def normalize_toml(value, *, role=False):
    """Un champ d'extension inconnu, même avec une sous-clé française, reste opaque."""
    configuration = not any(key in value for key in ("id", "name", "nom", "chemin", "path_value", "executor", "executeur")) and any(canonical(key) in CONFIG_FIELDS and isinstance(item, dict) for key, item in value.items())
    pack = ("skills" in value or "roles" in value) and "executeur" not in value and "executor" not in value
    fields = PACK_FIELDS if pack else ROLE_FIELDS if role or "executeur" in value or "executor" in value else PROJECT_FIELDS
    out = {}
    for key, item in value.items():
        new = canonical(key)
        if configuration and new in CONFIG_FIELDS and isinstance(item, dict):
            fixed = {}
            for subkey, content in item.items():
                target = TOOL_KEYS.get(subkey, subkey) if new == "tools" else canonical(subkey)
                if target in CONFIG_FIELDS[new]:
                    fixed[target] = normalize(content, target)
                else:
                    fixed[subkey] = content
            out[new] = fixed
        elif pack and new in ("skills", "roles") and isinstance(item, list):
            out[new] = [(ROLE_ALIASES if new == "roles" else SKILL_ALIASES).get(entry, entry) for entry in item]
        elif not configuration and new in fields:
            out[new] = ROLE_ALIASES.get(item, item) if role and new == "id" and isinstance(item, str) else normalize(item, new)
        else:
            out[key] = item
    return out


_STATE_VALUES = set("created running awaiting_approval awaiting_approval_with_defects approved applied blocked interrupted cancelled failed awaiting_slot completed stopped awaiting_merge awaiting_application paused chain_merge chain_done chain_stage chain_finished chain_application chain_stacked team_proposed pending pending_unshared awaiting_user awaiting_decision done finished open closed enabled disabled active inactive working available unavailable unknown missing invalid valid empty already already_running already_present success error ok preparing scheduled joined installed modified added deleted downloading detached up_to_date behind ahead both_sides waiting proposed proposal free elsewhere timed_out launched night team_applied".split())   # + états des propositions de conversation
_VALUE_TARGETS = {
    "state": _STATE_VALUES, "status": _STATE_VALUES,
    "decision": set("approve correct cancel remove ignore continue resume stop apply deny allow".split()),
    "mode": {"fast", "normal", "max", "performance"}, "agent_mode": {"fast", "normal", "max", "performance"},
    "mcp_unreal": {"all", "read"}, "commands": {"safe", "all", "no"},
    "application": {"manual", "auto_after_approval"}, "isolation": {"copy", "worktree", "read"},
    "provider": {"other"}, "source": {"subscription", "api", "local", "other"},
    "stage_name": set("intake select selection context plan planning execution verify verification audit correct correction present presentation approval finalize finalization cancelled error review request build".split()), "autonomy": {"complete", "validation"},
    "on_failure": {"continue_reported", "block"},
    "type": set("response task team actions text yes_no choices choice file folder image video voice software skill mcp project topic subscription subscriptions command".split()),
    "kind": set("response task team actions text yes_no choices choice file folder image video voice software skill mcp project topic subscription subscriptions command loop".split()),
    "category": set("global code agents knowledge reasoning image images video voice transcription software game web sound write data documents marketing search tools-ai text custom".split()),
    "author": {"supervisor", "user", "assistant", "system", "studio", "tool"},
}


def canonical_value(value, field):
    if field in {"role", "producer", "auditor", "executor"}:
        return ROLE_ALIASES.get(value, value)
    new = canonical(value)
    return new if new in _VALUE_TARGETS.get(field, set()) else value


def normalize_role_map(value):
    if not isinstance(value, dict):
        return value
    return {ROLE_ALIASES.get(key, key): normalize(item) for key, item in value.items()}



def read_role_map(text):
    return normalize_role_map(_json.loads(text))


def shared_database(data, current_name, legacy_name):
    """Un fichier encore ouvert par un ancien serveur MCP garde son emplacement partagé."""
    data = Path(data)
    old, new = data / legacy_name, data / current_name
    if old.is_file():
        if new.is_file():
            raise ValueError("Deux bases de mémoire sont présentes : aucune n'est remplacée ; vérifie la restauration avant de connecter la mémoire.")
        return old
    return new
