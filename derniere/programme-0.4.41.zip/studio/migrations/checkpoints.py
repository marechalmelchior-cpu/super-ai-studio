"""Compatibilité de lecture des points de reprise, sans réécrire leurs blobs historiques."""
from __future__ import annotations
from langgraph.checkpoint.sqlite import SqliteSaver
from .compatibility import canonical, normalize


def _channel(name):
    if isinstance(name, str) and name.startswith("branch:to:"):
        return "branch:to:" + canonical(name[len("branch:to:"):])
    return canonical(name)


def _payload(value):
    from langgraph.types import Send
    if isinstance(value, Send):
        return Send(canonical(value.node), normalize(value.arg))
    if isinstance(value, list):
        return [_payload(item) for item in value]
    return normalize(value)


def _checkpoint(checkpoint):
    result = dict(checkpoint)
    result["channel_values"] = {_channel(k): _payload(v) for k,v in checkpoint.get("channel_values", {}).items()}
    result["channel_versions"] = {_channel(k): v for k, v in checkpoint.get("channel_versions", {}).items()}
    result["versions_seen"] = {canonical(node): {_channel(k): v for k, v in versions.items()}
                               for node, versions in checkpoint.get("versions_seen", {}).items()}
    return result


class CompatibleSqliteSaver(SqliteSaver):
    def get_tuple(self, config):
        value = super().get_tuple(config)
        if value is None:
            return None
        writes = [(task, _channel(channel), _payload(content)) for task, channel, content in value.pending_writes or []]
        return value._replace(checkpoint=_checkpoint(value.checkpoint), pending_writes=writes)

    def list(self, config, **kwargs):
        for value in super().list(config, **kwargs):
            writes = [(task, _channel(channel), _payload(content)) for task, channel, content in value.pending_writes or []]
            yield value._replace(checkpoint=_checkpoint(value.checkpoint), pending_writes=writes)
