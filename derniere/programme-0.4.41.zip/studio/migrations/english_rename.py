"""Migration 1 : sauvegarde cohérente, conversion atomique, arrêt sur erreur."""
from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import sqlite3
import tempfile
import tomllib
from contextlib import contextmanager, closing
from datetime import datetime, timezone
from pathlib import Path

from .compatibility import KEYS, FILES, ENUM_FIELDS, ROLE_IDS, canonical, normalize, normalize_toml, normalize_catalog, canonical_value, normalize_role_map, _renamed_path, OPAQUE_JSON_FILES, normalize_mcp_cache
from .names import ROLE_ALIASES, SKILL_ALIASES, TOOL_KEYS
from .schemas import CONFIG_FIELDS, PROJECT_FIELDS, ROLE_FIELDS, PACK_FIELDS

VERSION = 1
MARKER = "english-rename-version.json"


class MigrationError(RuntimeError):
    """L'ouverture du studio est refusée ; aucune donnée sensible dans le message."""


def atomic_write(path: Path, value: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix=".english-rename-", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(value)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(name, path)
    finally:
        Path(name).unlink(missing_ok=True)


def _hash(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _safe(root, relative):
    path = root / relative
    if Path(relative).is_absolute() or ".." in Path(relative).parts or not path.resolve().is_relative_to(root.resolve()):
        raise MigrationError("Chemin de migration hors du studio : opération refusée.")
    if path.is_symlink() or (hasattr(path, "is_junction") and path.is_junction()):
        raise MigrationError("Lien dans les données à migrer : opération refusée.")
    return path


@contextmanager
def _locked(studio):
    # Verrou de système : libéré même après un arrêt brutal du processus.
    studio.mkdir(parents=True, exist_ok=True)
    with (studio / ".english-rename.lock").open("a+b") as stream:
        stream.seek(0)
        stream.write(b"0")
        stream.flush()
        stream.seek(0)
        try:
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            raise MigrationError("Migration déjà en cours : ferme les autres instances du studio.") from None
        try:
            yield
        finally:
            if os.name == "nt":
                stream.seek(0)
                msvcrt.locking(stream.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(stream, fcntl.LOCK_UN)



def _assert_closed(studio):
    session = studio / "data/interface-session.json"
    if not session.is_file():
        return
    try:
        pid = int(json.loads(session.read_text(encoding="utf-8")).get("pid", 0))
    except (ValueError, TypeError, OSError):
        raise MigrationError("Session illisible : ferme le studio avant la migration.") from None
    if not pid or pid == os.getpid():
        return
    if os.name == "nt":
        import ctypes
        handle = ctypes.windll.kernel32.OpenProcess(0x1000, False, pid)
        alive = bool(handle)
        if handle:
            code = ctypes.c_ulong()
            ctypes.windll.kernel32.GetExitCodeProcess(handle, ctypes.byref(code))
            ctypes.windll.kernel32.CloseHandle(handle)
            alive = code.value == 259
    else:
        try:
            os.kill(pid, 0)
            alive = True
        except ProcessLookupError:
            alive = False
        except PermissionError:
            alive = True
    if alive:
        raise MigrationError("Ferme l'autre instance du studio avant de migrer ou de restaurer.")


def _legacy_database(path):
    if not path.is_file():
        return False
    with closing(sqlite3.connect(path.as_uri() + "?mode=ro", uri=True)) as connection:
        names = {row[0] for row in connection.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        return bool(names & {"chaines", "appels", "demandes"})


def _files(root):
    paths = set()
    data = root / "Studio/data"
    if data.exists():
        # Toute la donnée, y compris les bases mémoire, est sauvegardée, jamais affichée.
        for directory, dirs, names in os.walk(data, followlinks=False):
            for name in dirs:
                _safe(root, (Path(directory) / name).relative_to(root))
            paths.update(Path(directory) / name for name in names)
    config = root / "Studio/studio.config.toml"
    if config.is_file():
        paths.add(config)
    for folder, pattern in (("Projets", "*/project.toml"), ("Projects", "*/project.toml"),
                            ("Sujets", "*/topic.toml"), ("Topics", "*/topic.toml"),
                            ("Studio/roles", "*.toml")):
        paths.update((root / folder).glob(pattern))
    # Les contenus de résultat et les journaux restent inchangés.
    for folder in ("Taches", "Tasks"):
        for task_root in (root / folder).glob("*"):
            for name in (".studio-worktree-pret", ".studio-worktree-ready"):
                if (task_root / name).is_file():
                    paths.add(task_root / name)
        for task in (root / folder).glob("*/details"):
            for path in task.rglob("*"):
                if path.is_file() and path.suffix.lower() in (".json", ".toml", ".md", ".txt", ".log") and path.stat().st_size <= 5_000_000:
                    # Aucune copie de travail ou de relecture dans le périmètre.
                    if len(path.relative_to(task).parts) == 1:
                        paths.add(path)
    for path in paths:
        _safe(root, path.relative_to(root))
    return sorted(paths)


def backup(root: Path, destination: Path, paths: list[Path]) -> dict:
    required = sum(path.stat().st_size for path in paths)
    destination.parent.mkdir(parents=True, exist_ok=True)
    if shutil.disk_usage(destination.parent).free < required * 2 + 64 * 1024 * 1024:
        raise MigrationError("Place disque insuffisante pour la sauvegarde de migration.")
    destination.mkdir()
    manifest = {"version": VERSION, "root": str(root.resolve()), "state": "backing_up", "files": {}, "created": [], "directories": [p.relative_to(root).as_posix() for p in (root / "Studio/data").rglob("*") if p.is_dir()], "created_directories": []}
    # WAL et SHM ne sont pas restaurés séparément : l'API backup produit une base cohérente autonome.
    databases = {path for path in paths if path.suffix in (".db", ".sqlite", ".sqlite3")}
    for path in paths:
        relative = path.relative_to(root).as_posix()
        if any(str(path) == str(database) + suffix for database in databases for suffix in ("-wal", "-shm")):
            continue
        saved = destination / "files" / relative
        saved.parent.mkdir(parents=True, exist_ok=True)
        if path in databases:
            with closing(sqlite3.connect(path.as_uri() + "?mode=ro", uri=True)) as source, closing(sqlite3.connect(saved)) as target:
                source.backup(target)
                if target.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
                    raise MigrationError("Intégrité de la sauvegarde SQLite non confirmée.")
        else:
            shutil.copy2(path, saved)
        manifest["files"][relative] = _hash(saved)
    manifest["state"] = "backed_up"
    atomic_write(destination / "manifest.json", json.dumps(manifest, indent=2).encode())
    # Lecture de vérification AVANT toute mutation des originaux.
    verify_backup(destination, manifest)
    return manifest


def verify_backup(destination, manifest):
    for relative, expected in manifest["files"].items():
        saved = _safe(destination / "files", relative)
        if not saved.is_file() or _hash(saved) != expected:
            raise MigrationError("Sauvegarde incomplète ou altérée : opération refusée.")


def rollback(root: Path, destination: Path) -> None:
    root, destination = Path(root).resolve(), Path(destination).resolve()
    _assert_closed(root / "Studio")
    manifest = json.loads((destination / "manifest.json").read_text(encoding="utf-8"))
    if manifest["root"] != str(root) or manifest.get("version") != VERSION:
        raise MigrationError("Cette sauvegarde appartient à un autre studio ou schéma.")
    verify_backup(destination, manifest)
    for relative in list(manifest["files"]) + manifest.get("created", []):
        _safe(root, relative)
    for relative in manifest.get("directories", []):
        _safe(root, relative).mkdir(parents=True, exist_ok=True)
    # Le studio doit être fermé. Les fichiers créés par cette seule migration sont retirés.
    for relative in manifest.get("created", []):
        if relative not in manifest["files"]:
            _safe(root, relative).unlink(missing_ok=True)
    for relative in manifest["files"]:
        target = _safe(root, relative)
        if target.suffix in (".db", ".sqlite", ".sqlite3"):
            for suffix in ("-wal", "-shm", "-journal"):
                Path(str(target) + suffix).unlink(missing_ok=True)
        atomic_write(target, (destination / "files" / relative).read_bytes())
    for relative in sorted(manifest.get("created_directories", []), key=lambda item: len(Path(item).parts), reverse=True):
        directory = _safe(root, relative)
        if directory.exists() and not any(directory.iterdir()):
            directory.rmdir()
    atomic_write(destination / "rollback-complete.json", b'{"version":1,"restored":true}\n')


def convert_toml(text: str, *, role: bool = False) -> str:
    """Conserve l'ordre, l'espacement, les commentaires et les chaînes multilignes."""
    parsed = tomllib.loads(text)
    lines = text.splitlines(keepends=True)
    output, multiline = [], None
    configuration = not any(key in parsed for key in ("id", "name", "nom", "chemin", "path_value", "executor", "executeur")) and any(canonical(key) in CONFIG_FIELDS and isinstance(item, dict) for key, item in parsed.items())
    section = ""
    pack = ("skills" in parsed or "roles" in parsed) and not role
    for line in lines:
        # Une chaîne multiligne est un contenu, jamais un ensemble de clés TOML.
        if multiline:
            output.append(line)
            if line.count(multiline) % 2:
                multiline = None
            continue
        match = re.match(r'^(\s*)(\[\[?)([^\]]+)(\]\]?)(.*)$', line)
        if match:
            parts = match[3].split('.')
            section = canonical(parts[0].strip())
            if section not in CONFIG_FIELDS:
                output.append(line)
                continue
            line = match[1] + match[2] + '.'.join(canonical(part.strip()) for part in parts) + match[4] + match[5] + ('\n' if line.endswith('\n') else '')
        else:
            match = re.match(r'''^(\s*)([A-Za-z_][\w-]*|"[^"]+"|'[^']+')(\s*=\s*)(.*)$''', line)
            if match:
                old = match[2].strip("\"'")
                key = TOOL_KEYS.get(old, old) if configuration and section == "tools" else canonical(old)
                allowed = CONFIG_FIELDS.get(section, set()) if configuration else (PACK_FIELDS if pack else ROLE_FIELDS if role else PROJECT_FIELDS) if not section else set()
                if key not in allowed:
                    for delimiter in ('"""', "\'\'\'"):
                        if match[4].lstrip().startswith(delimiter) and match[4].count(delimiter) % 2:
                            multiline = delimiter
                    output.append(line)
                    continue
                rest = match[4]
                if pack and key in ("skills", "roles"):
                    rest = re.sub(r"([\"'])([^\"']*)(\1)", lambda m: m[1] + ((ROLE_ALIASES if key == "roles" else SKILL_ALIASES).get(m[2], m[2])) + m[3], rest)
                if key in ENUM_FIELDS or (role and key == "id"):
                    rest = re.sub(r'''^(["'])([^"']*)(\1)''',
                                  lambda m: m[1] + (ROLE_ALIASES.get(m[2], m[2]) if key == "id" else canonical_value(m[2], key)) + m[3], rest)
                line = match[1] + (match[2] if key == old else key) + match[3] + rest + ('\n' if line.endswith('\n') else '')
        for delimiter in ('\"\"\"', "\'\'\'"):
            if line.count(delimiter) % 2:
                multiline = delimiter
        output.append(line)
    converted = ''.join(output)
    # Les tableaux inline et clés citées complexes ne sont jamais changés à l'aveugle.
    normalized = normalize_toml(parsed, role=role)
    if tomllib.loads(converted) != normalized:
        raise MigrationError("Fiche TOML complexe non convertible sans perte : migration arrêtée.")
    return converted


def rewrite_owned_paths(value, root, field=""):
    """Actualise seulement les références techniques dans data ; le contenu reste opaque."""
    from .compatibility import CONTENT_FIELDS, STRUCTURAL_KEYS, CANONICAL_KEYS
    path_fields = {"path", "path_value", "folder", "attachment_path", "result_path"}
    if field in CONTENT_FIELDS:
        return value
    if isinstance(value, dict):
        return {key: rewrite_owned_paths(item, root, key) if key in path_fields or key in CANONICAL_KEYS or key in STRUCTURAL_KEYS else item for key,item in value.items()}
    if isinstance(value, list):
        return [rewrite_owned_paths(item, root, field) for item in value]
    if isinstance(value, str) and field in path_fields:
        original = Path(value)
        absolute = original if original.is_absolute() else root / original
        if absolute.resolve().is_relative_to((root / "Studio/data").resolve()):
            target = _renamed_path(absolute)
            if target != absolute:
                target = target if original.is_absolute() else target.relative_to(root)
                return target.as_posix() if "/" in value and "\\" not in value else str(target)
    return value


def migrate_database(path: Path, root: Path | None = None):
    if not path.exists():
        return
    with closing(sqlite3.connect(path)) as connection:
        connection.execute("BEGIN IMMEDIATE")
        tables = {row[0] for row in connection.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        for old, new in (("chaines", "chains"), ("appels", "calls"), ("demandes", "requests")):
            if old in tables:
                if new in tables:
                    raise MigrationError("Deux tables concurrentes : migration arrêtée.")
                connection.execute(f'ALTER TABLE "{old}" RENAME TO "{new}"')
        tables = {row[0] for row in connection.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        allowed = {"tasks", "steps", "artifacts", "errors", "effects", "processes", "approvals", "slots", "events", "usage", "calls", "chains", "requests", "conversation"}
        for table in sorted(tables & allowed):
            columns = [row[1] for row in connection.execute(f'PRAGMA table_info("{table}")')]
            for old in columns:
                new = canonical(old)
                if new != old:
                    if new in columns:
                        raise MigrationError("Deux colonnes concurrentes : migration arrêtée.")
                    connection.execute(f'ALTER TABLE "{table}" RENAME COLUMN "{old}" TO "{new}"')
            columns = [row[1] for row in connection.execute(f'PRAGMA table_info("{table}")')]
            for column in columns:
                if column in ("status", "state", "decision", "name", "role", "author"):
                    present = [row[0] for row in connection.execute(f'SELECT DISTINCT "{column}" FROM "{table}"')]
                    for old in present:
                        new = canonical_value(old, "stage_name" if column == "name" else column)
                        if old != new:
                            connection.execute(f'UPDATE "{table}" SET "{column}"=? WHERE "{column}"=?', (new, old))
                if root and table == "artifacts" and column == "path":
                    for rowid, original in connection.execute('SELECT rowid,path FROM artifacts').fetchall():
                        converted = rewrite_owned_paths(original, root, "path")
                        if converted != original:
                            connection.execute('UPDATE artifacts SET path=? WHERE rowid=?', (converted,rowid))
                if column in ("options", "proposal", "stages", "result"):
                    rows = connection.execute(f'SELECT rowid, "{column}" FROM "{table}"').fetchall()
                    for rowid, content in rows:
                        try:
                            before = json.loads(content)
                        except (ValueError, TypeError):
                            continue
                        after = normalize(before)
                        if root:
                            after = rewrite_owned_paths(after, root)
                        if before != after:
                            connection.execute(f'UPDATE "{table}" SET "{column}"=? WHERE rowid=?',
                                               (json.dumps(after, ensure_ascii=False), rowid))
        if "calls" in tables:
            connection.execute("DROP INDEX IF EXISTS appels_at")
            connection.execute("CREATE INDEX IF NOT EXISTS calls_at ON calls(at)")
        connection.execute("CREATE TABLE IF NOT EXISTS schema_migrations (version INTEGER PRIMARY KEY, applied_at TEXT NOT NULL)")
        connection.execute("INSERT OR IGNORE INTO schema_migrations VALUES (?,?)", (VERSION, datetime.now(timezone.utc).isoformat()))
        if connection.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
            raise MigrationError("Intégrité SQLite non confirmée : transaction annulée.")
        connection.commit()


def _new_name(path, studio):
    # Seuls les rôles actifs du studio changent de nom ; un rôle dans un instantané rangé sous data/
    # (test de restauration, ancienne configuration…) suit seulement le renommage de son dossier de tête.
    if path.parent == studio / "roles" and path.suffix == ".toml":
        from .names import ROLE_ALIASES
        return path.with_name(ROLE_ALIASES.get(path.stem, path.stem) + path.suffix)
    return _renamed_path(path)


def migrate(root: Path, *, note=lambda message: None, backup_function=None):
    root = Path(root).resolve()
    studio, data = root / "Studio", root / "Studio/data"
    marker = data / MARKER
    with _locked(studio):
        # Une migration interrompue est d'abord remise à son état sauvegardé.
        pending = studio / ".english-rename-pending.json"
        if pending.exists():
            previous = json.loads(pending.read_text(encoding="utf-8"))
            rollback(root, Path(previous["backup"]))
            pending.unlink()
        if marker.exists() and not _legacy_database(data / "studio.db"):
            version = json.loads(marker.read_text(encoding="utf-8")).get("version")
            if version != VERSION:
                raise MigrationError("Version de schéma incompatible avec ce studio.")
            return None
        _assert_closed(studio)
        paths = _files(root)
        stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
        folder = "Backups" if (root / "Backups").exists() and not (root / "Sauvegardes").exists() else "Sauvegardes"
        destination = root / folder / "migrations" / (stamp + '-english-rename')
        note("Migration 1 : sauvegarde et vérification en cours.")
        try:
            manifest = (backup_function or backup)(root, destination, paths)
        except Exception:
            raise MigrationError("Sauvegarde de migration impossible : aucune donnée migrée ; vérifie les droits et la place disque, puis relance.") from None
        def audit(event):
            log = destination / "migration.log"
            previous = log.read_bytes() if log.exists() else b""
            stamp = datetime.now(timezone.utc).isoformat(timespec="seconds")
            atomic_write(log, previous + f"{stamp} schema=1 event={event}\n".encode("ascii"))
        audit("backup_verified")
        manifest["created"] = [marker.relative_to(root).as_posix()]
        conversions = []
        card_roots = {root / name for name in ('Projets', 'Projects', 'Sujets', 'Topics')}
        task_roots = {root / name for name in ('Taches', 'Tasks')}
        try:
            database_paths = {path for path in paths if path.suffix in (".db", ".sqlite", ".sqlite3")}
            for path in paths:
                if any(str(path) == str(database) + suffix for database in database_paths for suffix in ("-wal", "-shm")):
                    continue
                # Les bases mémoire et checkpoints sont conservées ; seul le schéma studio est converti.
                if path.name == 'studio.db' and path.parent == data:
                    continue
                target = _new_name(path, studio)
                if target != path and target.exists():
                    raise MigrationError("Ancien et nouveau fichiers présents : migration arrêtée sans écrasement.")
                content = path.read_bytes()
                if path in database_paths and target != path:
                    # La copie cohérente intègre le WAL ; copier seulement le fichier principal perdrait des lignes.
                    content = (destination / "files" / path.relative_to(root)).read_bytes()
                # Contenus convertis : fichiers actifs seulement, jamais l'intérieur d'un instantané rangé sous data/.
                task_details = path.parent.name == 'details' and path.parent.parent.parent in task_roots
                if path.suffix == '.json' and path.name not in OPAQUE_JSON_FILES and (path.name in FILES or path.name in FILES.values() or any(old.endswith('-') and path.name.startswith((old,new)) for old,new in FILES.items())) and (path.parent == data or task_details):
                    before = json.loads(content)
                    if path.name in ("mcp-outils.json", "mcp-tools.json"):
                        after = normalize_mcp_cache(before)
                    elif path.name in ("catalogue-maj.json", "catalog-update.json", "benchmarks-maj.json", "benchmarks-update.json"):
                        after = normalize_catalog(before)
                    elif path.name in ("models.json", "modeles.json", "efforts.json", "ai-roles.json", "ia-roles.json"):
                        after = normalize_role_map(before)
                    else:
                        after = normalize(before)
                    if path.name not in ("mcp-outils.json", "mcp-tools.json"):
                        after = rewrite_owned_paths(after, root)
                    if before != after:
                        content = (json.dumps(after, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
                elif path.suffix == '.toml' and (path.parent == studio or path.parent.parent in card_roots or path.parent == studio / 'roles'):
                    content = convert_toml(content.decode('utf-8-sig'), role=path.parent == studio / 'roles').encode('utf-8')
                if target != path or content != path.read_bytes():
                    conversions.append((path, target, content))
                    if target != path:
                        manifest["created"].append(target.relative_to(root).as_posix())
                        parent = target.parent
                        while not parent.exists() and parent != root:
                            relative = parent.relative_to(root).as_posix()
                            if relative not in manifest["created_directories"]:
                                manifest["created_directories"].append(relative)
                            parent = parent.parent
            manifest["state"] = "ready"
            atomic_write(destination / "manifest.json", json.dumps(manifest, indent=2).encode())
            atomic_write(pending, json.dumps({"backup": str(destination)}).encode())
            audit("conversion_started")
            for path, target, content in conversions:
                atomic_write(target, content)
                if target != path:
                    path.unlink()
                    if path in database_paths:
                        for suffix in ("-wal", "-shm"):
                            Path(str(path) + suffix).unlink(missing_ok=True)
            migrate_database(data / 'studio.db', root)
            atomic_write(marker, json.dumps({"version": VERSION}).encode())
            audit("conversion_complete")
            pending.unlink()
            note("Migration 1 : sauvegarde vérifiée, conversion terminée, intégrité SQLite confirmée.")
            return destination
        except Exception:
            try:
                audit("conversion_failed")
            except OSError:
                pass
            if pending.exists():
                try:
                    rollback(root, destination)
                    pending.unlink()
                except Exception:
                    raise MigrationError("Restauration incomplète : studio arrêté. Conserve la sauvegarde de migration et utilise le script de retour arrière, studio fermé.") from None
            raise MigrationError("Migration arrêtée ; sauvegarde conservée et état précédent restauré. Aucun démarrage en écriture.") from None
