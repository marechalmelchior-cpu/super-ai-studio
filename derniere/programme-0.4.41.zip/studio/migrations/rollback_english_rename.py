"""Restauration hors ligne ; fermer le studio et remettre le code précédent ensuite."""
from __future__ import annotations
import argparse
from pathlib import Path
from .english_rename import _locked, rollback


def main(argv=None):
    parser = argparse.ArgumentParser(description="Restaurer une sauvegarde avant le renommage anglais.")
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--backup", type=Path, required=True)
    args = parser.parse_args(argv)
    with _locked(args.root / "Studio"):
        rollback(args.root, args.backup)
    print("Sauvegarde vérifiée et restaurée. Remets le code précédent avant de rouvrir le studio.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
