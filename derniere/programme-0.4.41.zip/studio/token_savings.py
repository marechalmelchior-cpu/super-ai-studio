"""Économies de tokens sans perte de contrôle : tri des défauts de relecture, arrêt d'une boucle de correction qui
n'avance plus, bilan déterministe d'un cas simple, modèle « léger » pour les résumés, relecture incrémentale.

Garde-fous communs : rien ici ne produit un verdict OK, ne marque une relecture comme faite, ne valide ni ne fusionne.
La relecture (sécurité comprise) garde toujours son propre modèle ; le modèle léger ne sert qu'aux résumés et bilans.
"""
from __future__ import annotations

import hashlib
import re

from .migrations import compatibility as json
from .migrations.compatibility import TechnicalPath as Path

# --- 1. Tri des défauts -----------------------------------------------------------------------------------------
SEVERITIES = ("blocking", "security", "missing_proof", "minor", "historical")
LABELS = {"blocking": "bloquant", "security": "sécurité", "missing_proof": "preuve manquante", "minor": "mineur",
          "historical": "historique"}
MINOR_ONLY = frozenset({"minor", "historical"})
_TAGS = {"bloquant": "blocking", "blocking": "blocking", "sécurité": "security", "securite": "security", "security": "security",
         "preuve manquante": "missing_proof", "preuve": "missing_proof", "missing proof": "missing_proof",
         "mineur": "minor", "minor": "minor", "historique": "historical", "historical": "historical"}
_TAG = re.compile(r"^\s*(?:[-*•]|\d+[.)])?\s*\*{0,2}\[\s*([^\]]{3,20}?)\s*\]\*{0,2}", re.I)
_ITEM = re.compile(r"^\s*(?:[-*•]|\d+[.)])\s+\S")
TRIAGE_INSTRUCTION = ("Commence chaque défaut par son étiquette entre crochets : [bloquant] (le résultat ne remplit pas la demande "
                      "ou casse quelque chose), [sécurité], [preuve manquante] (affirmation non vérifiable), [mineur] (style, "
                      "confort) ou [historique] (déjà présent avant la tâche, hors de son périmètre). En cas de doute : [bloquant].")


def classify(review_text: str) -> list[dict]:
    """Défauts listés après la ligne VERDICT, avec leur gravité. Sans étiquette reconnue : bloquant (prudence)."""
    lines = (review_text or "").splitlines()
    start = next((i + 1 for i, line in enumerate(lines) if re.search(r"VERDICT\s*:", line, re.I)), 0)
    out = []
    for line in lines[start:]:
        tag = _TAG.match(line)
        if not tag and not _ITEM.match(line):
            continue
        severity = _TAGS.get(tag.group(1).strip().lower(), "blocking") if tag else "blocking"
        text = (line[tag.end():] if tag else re.sub(r"^\s*(?:[-*•]|\d+[.)])\s+", "", line)).strip(" :—-")
        if text:
            out.append({"severity": severity, "text": text[:600]})
    return out


def triage(validation_defects: list[str], review: dict, model_audit: dict | None) -> dict:
    """Gravité de chaque défaut restant. Les défauts des vérifications et des règles sont toujours bloquants ;
    une relecture DEFAUTS dont aucun défaut n'est lisible compte comme un défaut bloquant."""
    items = [{"severity": "blocking", "text": d[:600]} for d in validation_defects]
    if review.get("state") == "defects":
        found = classify((model_audit or {}).get("review_text") or (model_audit or {}).get("summary", ""))
        items += found or [{"severity": "blocking", "text": "Défauts de relecture sans détail lisible."}]
    elif review.get("state") == "unavailable":
        items += [{"severity": "blocking", "text": d[:600]} for d in review.get("defects", [])]
    counts = {k: sum(1 for x in items if x["severity"] == k) for k in SEVERITIES}
    return {"items": items, "counts": counts, "only_minor": bool(items) and all(x["severity"] in MINOR_ONLY for x in items)}


def diff_fingerprint(details: Path, attempt: int) -> str:
    try:
        return hashlib.sha256((Path(details) / f"diff-{attempt}.patch").read_bytes()).hexdigest()
    except OSError:
        return ""


def no_progress(details: Path, attempt: int) -> bool:
    """La tentative n'a rien changé au résultat de la précédente (même diff, octet pour octet)."""
    if attempt <= 1:
        return False
    a, b = diff_fingerprint(details, attempt), diff_fingerprint(details, attempt - 1)
    return bool(a) and a == b


# --- 3. Bilan déterministe ---------------------------------------------------------------------------------------
SMALL_FILES = 5
SMALL_LINES = 300


def diff_size(text: str) -> tuple[int, int, int]:
    """(fichiers, lignes ajoutées, lignes retirées) d'un diff unifié."""
    files = len(re.findall(r"^diff --git ", text, re.M)) or len(re.findall(r"^\+\+\+ ", text, re.M))
    plus = sum(1 for line in text.splitlines() if line.startswith("+") and not line.startswith("+++"))
    minus = sum(1 for line in text.splitlines() if line.startswith("-") and not line.startswith("---"))
    return files, plus, minus


def simple_outcome(task: dict, status: dict, diff_text: str) -> dict | None:
    """Cas simple où un avis d'IA n'apporte rien : tâche finie, vérifications et relecture OK, petit périmètre.
    Renvoie les éléments du bilan, sinon None (échec, défauts, relecture absente, gros changement, simulation…)."""
    audit = status.get("audit") or {}
    verification = status.get("verification") or {}
    if task.get("status") not in ("awaiting_approval", "approved", "applied") or status.get("simulation"):
        return None
    if audit.get("verdict") != "OK" or not audit.get("reviewed") or (audit.get("review") or {}).get("state") != "ok":
        return None
    if verification.get("ok") is not True:
        return None
    files, plus, minus = diff_size(diff_text or "")
    if not files or files > SMALL_FILES or plus + minus > SMALL_LINES:
        return None
    reviewer = (audit.get("model_reviewer") or {})
    return {"files": files, "plus": plus, "minus": minus, "checks": len(verification.get("checks") or []),
            "reviewer": reviewer.get("exact_model") or reviewer.get("executor") or "relecteur"}


def simple_outcome_text(title: str, facts: dict, status_label: str) -> str:
    return (f"### Résumé\nTâche « {title} » terminée : {facts['files']} fichier{'s' if facts['files'] > 1 else ''} modifié"
            f"{'s' if facts['files'] > 1 else ''} (+{facts['plus']} / −{facts['minus']} lignes), vérifications OK"
            f"{' (' + str(facts['checks']) + ')' if facts['checks'] else ''}, relecture OK ({facts['reviewer']}). {status_label}\n\n"
            "Preuves : ouvre la tâche (lien ci-dessus) — compte rendu, diff complet, vérifications et relecture.\n\n"
            "_Bilan automatique sans IA : cas simple, tout est OK._")


# --- 4. Modèle léger ---------------------------------------------------------------------------------------------
LIGHT_MARGIN = 0.25                     # « léger » : le moins cher parmi ceux à 25 % au plus du meilleur pour résumer
SUMMARY_RANKINGS = ["conversation", "global"]


def light_model(studio, actor: str, connection: dict | None = None) -> tuple[str, str]:
    """(modèle, origine) pour un résumé ou un bilan avec l'IA du Superviseur. Ton choix dans Réglages d'abord ;
    sinon le moins cher des modèles bien classés que cette IA sait lancer ; sinon ("", "") = comportement habituel.
    Jamais utilisé pour une relecture."""
    explicit = str((studio.cfg.get("supervisor") or {}).get("light_model") or "").strip()
    if explicit:
        return explicit, "réglage"
    from . import agents
    if actor in ("claude-code", "codex"):
        source = {"id": actor, "provider": "anthropic" if actor == "claude-code" else "codex"}
    elif actor == "api" and connection:
        f = connection.get("provider", "")
        source = {"id": connection.get("id", ""), "provider": "local" if f in ("ollama", "lmstudio") else f}
    else:
        return "", ""
    try:
        ranked = agents._ranking("", SUMMARY_RANKINGS)
    except (OSError, ValueError, KeyError):
        return "", ""
    usable = [m for m in ranked if agents.tool_model(source, m) and bool(m.get("local")) == (source["provider"] == "local")]
    if not usable:
        return "", ""
    note = lambda m: m.get("_note") or m.get("score") or 0      # noqa: E731
    top = note(usable[0])
    near = [m for m in usable if note(m) >= top * (1 - LIGHT_MARGIN) and m.get("price") is not None]
    if not near:
        return "", ""
    best = min(near, key=lambda m: (m["price"], -note(m)))
    return agents.tool_model(source, best), "classements"


# --- 5. Relecture incrémentale -----------------------------------------------------------------------------------
REFERENCE = "review-reference.json"


def file_blocks(diff: str) -> dict[str, str]:
    """Un bloc par fichier (« diff --git a/x b/x » … jusqu'au suivant)."""
    out: dict[str, str] = {}
    current, buf = None, []
    for line in (diff or "").splitlines(keepends=True):
        m = re.match(r"diff --git a/(.+?) b/(.+?)\s*$", line)
        if m:
            if current is not None:
                out[current] = "".join(buf)
            current, buf = m.group(2), [line]
        elif current is not None:
            buf.append(line)
    if current is not None:
        out[current] = "".join(buf)
    return out


def reference_key(*parts: str) -> str:
    """Empreinte de tout ce qui invalide une relecture de référence : demande, critères, règles, modèle, preuves."""
    h = hashlib.sha256()
    for p in parts:
        h.update((p or "").encode("utf-8", "replace") + b"\x00")
    return h.hexdigest()


def rules_fingerprint(paths: list) -> str:
    h = hashlib.sha256()
    for p in sorted(str(x) for x in paths):
        h.update(p.encode("utf-8", "replace"))
        try:
            h.update(Path(p).read_bytes())
        except OSError:
            h.update(b"<absent>")
    return h.hexdigest()


def read_reference(details: Path) -> dict:
    try:
        d = json.loads((Path(details) / REFERENCE).read_text(encoding="utf-8"))
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def write_reference(details: Path, *, attempt: int, key: str, diff: str, open_defects: list[str], mode: str) -> None:
    d = {"attempt": attempt, "key": key, "diff_sha256": hashlib.sha256(diff.encode("utf-8", "replace")).hexdigest(),
         "open_defects": open_defects[:40], "mode": mode}
    (Path(details) / REFERENCE).write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")


def incremental_context(previous_diff: str, diff: str, open_defects: list[str], full_path: str) -> tuple[str, str]:
    """(texte pour le relecteur, delta seul). Index de tous les fichiers, blocs changés depuis la relecture de
    référence, défauts encore ouverts, et l'obligation de contrôler les interactions avec le reste du diff."""
    before, now = file_blocks(previous_diff), file_blocks(diff)
    changed = [f for f in now if before.get(f) != now[f]]
    gone = [f for f in before if f not in now]
    rows = []
    for f, block in now.items():
        n, plus, minus = diff_size(block)
        rows.append(f"- {f} (+{plus} / −{minus}){' — modifié depuis la relecture précédente' if f in changed else ''}")
    rows += [f"- {f} — retiré du diff depuis la relecture précédente" for f in gone]
    delta = "".join(now[f] for f in changed)
    text = ("Relecture incrémentale : la relecture précédente portait sur tout le diff. Ton verdict porte quand même sur "
            "l'ENSEMBLE du résultat actuel, pas seulement sur le delta.\n"
            f"1. Vérifie que chaque défaut encore ouvert ci-dessous est corrigé.\n2. Relis le delta (blocs des fichiers modifiés "
            f"depuis la relecture précédente).\n3. Contrôle les interactions entre ces blocs et le reste : appels, imports, "
            f"signatures, données partagées, fichiers retirés. Le diff complet est dans {full_path} : ouvre-le dès qu'un bloc "
            "inchangé peut être touché par le delta, ou en cas de doute.\n\n"
            "### Index de tous les fichiers du diff\n" + "\n".join(rows)
            + "\n\n### Défauts encore ouverts à la relecture précédente\n"
            + ("\n".join(f"- {d[:600]}" for d in open_defects) or "- aucun"))
    return text, delta
