"""Connectors: PC software the agents can use (Blender, Unreal Editor, Krita, ffmpeg…).

Empty by default: everyone adds their own (Accueil › Réglages › Connecteurs). Blender and Unreal keep their place in
studio.config.toml ([outils]) because studio features use them; the others go in
data/connecteurs.json. Only the name and path are passed to agents.
"""
from __future__ import annotations

from .migrations import compatibility as json
import re
import secrets
from .migrations.compatibility import TechnicalPath as Path

TYPES = {"blender": ("Blender", "tools", "blender"), "unreal": ("Unreal Editor (UnrealEditor-Cmd.exe)", "tools", "unreal_editor_cmd")}
SUGGESTIONS = ["Blender", "Unreal Editor", "Godot", "Unity", "Krita", "GIMP", "Inkscape", "ffmpeg", "Audacity", "OBS Studio",
               "DaVinci Resolve", "Visual Studio Code", "Node.js", "Docker"]


def _file(studio) -> Path:
    return studio.paths.data / "connectors.json"


def _personal(studio) -> list[dict]:
    try:
        l = json.loads(_file(studio).read_text(encoding="utf-8"))
        return [c for c in l if isinstance(c, dict) and c.get("id") and c.get("name")]
    except (OSError, ValueError):
        return []


def list_all(studio) -> list[dict]:
    out = []
    for t, (name, section, key) in TYPES.items():
        path_value = str(studio.cfg.get(section, {}).get(key, "") or "")
        if path_value:
            out.append({"id": t, "name": name, "path_value": path_value, "type": t, "ok": Path(path_value).exists()})
    for c in _personal(studio):
        out.append({**c, "type": "other", "ok": Path(c.get("path_value", "")).exists()})
    return out


def _validate_path(path_value: str) -> str:
    path_value = (path_value or "").strip().strip('"')
    if not path_value or "\n" in path_value or "'" in path_value or len(path_value) > 400:
        raise ValueError("Indique le path_value complete du programme (ex. C:\\Program Files\\Krita\\bin\\krita.exe).")
    if not (re.match(r"^[A-Za-z]:[\\/]", path_value) or path_value.startswith("/")):
        raise ValueError("Chemin complet attendu (ex. C:\\…\\programme.exe).")
    return path_value


def add_item(studio, name: str, path_value: str) -> list[dict]:
    from . import settings
    name = re.sub(r"[\r\n]", " ", (name or "").strip())[:60]
    if not name:
        raise ValueError("Donne un nom au connecteur.")
    path_value = _validate_path(path_value)
    bottom = name.lower()
    t = "blender" if "blender" in bottom else "unreal" if "unreal" in bottom else ""
    if t:
        _, section, key = TYPES[t]
        settings.store_file(studio.paths.config_file, section, key, path_value)
        studio.cfg.setdefault(section, {})[key] = path_value
    else:
        l = _personal(studio)
        l.append({"id": f"c-{secrets.token_hex(3)}", "name": name, "path_value": path_value})
        _file(studio).write_text(json.dumps(l, ensure_ascii=False, indent=1), encoding="utf-8")
    return list_all(studio)


def removed(studio, ident: str) -> list[dict]:
    from . import settings
    if ident in TYPES:
        _, section, key = TYPES[ident]
        settings.store_file(studio.paths.config_file, section, key, "")
        studio.cfg.setdefault(section, {})[key] = ""
    else:
        _file(studio).write_text(json.dumps([c for c in _personal(studio) if c["id"] != ident], ensure_ascii=False, indent=1),
                                    encoding="utf-8")
    return list_all(studio)


def for_agents(studio) -> str:
    """Mission note: declared software (name and path only)."""
    l = [c for c in list_all(studio) if c["type"] == "other" and c["ok"]]
    try:                                                # catalogue software found on the PC: known without declaring it
        from .library import catalog, detect_software
        known = {c["name"].lower() for c in l}
        for e in catalog()["elements"]:
            if e["type"] == "software" and e["name"].lower() not in known:
                p = detect_software(e)
                if p:
                    l.append({"name": e["name"], "path_value": p})
    except Exception:                                   # noqa: BLE001 — a hint for the agents, never blocks a task
        pass
    return ("Logiciels du PC déclarés par l'utilisateur (utilisables si ton outil le permet, sinon cite-les dans le compte rendu) : "
            + " ; ".join(f"{c['name']} ({c['path_value']})" for c in l)) if l else ""
