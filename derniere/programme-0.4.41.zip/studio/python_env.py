"""Environnement Python versionné pour les mises à jour qui apportent de nouveaux composants (wheels/).

Avant : pip installait dans l'environnement en service ; un échec à mi-chemin le laissait modifié, et le retour arrière
du programme ne le réparait pas. Maintenant :

1. un NOUVEL environnement est préparé à côté (``.venvs/<version>``), l'ancien n'est jamais touché ;
2. il est vérifié (``pip check`` et import des modules du studio) ;
3. seulement alors, ``.venvs/active.json`` le désigne, avec l'ancien comme retour arrière ;
4. au démarrage suivant, le studio se relance avec cet interpréteur (``relaunch_if_needed``).

Retour arrière : ``python -m studio python-env-rollback`` (l'ancien environnement est conservé). Un environnement dont
la préparation a échoué est gardé sous ``<version>.failed-<date>`` pour diagnostic, jamais activé.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import time
from pathlib import Path

ENVS = ".venvs"
POINTER = "active.json"
SWITCHED = "STUDIO_PYTHON_ENV_SWITCHED"
VERIFY = "import studio.config, studio.orchestrator.runner, studio.ui.server"


def python_in(env: Path, windowed: bool = False) -> Path:
    if sys.platform == "win32":
        return Path(env) / "Scripts" / ("pythonw.exe" if windowed else "python.exe")
    return Path(env) / "bin" / "python"


def _run(cmd: list, cwd: Path, timeout: float = 900) -> subprocess.CompletedProcess:
    from .connectors.base import NO_WINDOW
    return subprocess.run([str(c) for c in cmd], cwd=str(cwd), capture_output=True, text=True, encoding="utf-8",
                          errors="replace", timeout=timeout, stdin=subprocess.DEVNULL, **NO_WINDOW)


def prepare(code: Path, version: str, run=_run) -> Path:
    """Creates and checks a new environment for ``version``; raises RuntimeError (nothing activated) on failure."""
    code = Path(code)
    stamp = time.strftime("%Y%m%d-%H%M%S")
    new = code / ENVS / f"{version}-{stamp}"
    new.parent.mkdir(parents=True, exist_ok=True)
    base = getattr(sys, "_base_executable", "") or sys.executable
    py = python_in(new)
    source = ["--no-index", "--find-links", str(code / "wheels")] if sys.platform == "win32" else []   # bundled: Windows
    steps = [("création", [base, "-m", "venv", str(new)]),
             ("composants", [py, "-m", "pip", "install", "--disable-pip-version-check", *source, "-r", str(code / "requirements.lock.txt")]),
             ("cohérence", [py, "-m", "pip", "check"]),
             ("démarrage", [py, "-c", VERIFY])]
    for name, cmd in steps:
        r = run(cmd, code)
        if r.returncode:
            failed = new.with_name(f"{new.name}.failed")
            try:
                if new.exists():
                    new.rename(failed)               # kept for diagnosis, never activated
            except OSError:
                pass
            raise RuntimeError(f"nouvel environnement Python non prêt (étape {name}) : "
                               + ((r.stderr or "") + (r.stdout or ""))[-300:] + " — l'environnement actuel n'a pas changé")
    return new


def pointer(code: Path) -> dict:
    try:
        d = json.loads((Path(code) / ENVS / POINTER).read_text(encoding="utf-8"))
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def _write_pointer(code: Path, d: dict) -> None:
    f = Path(code) / ENVS / POINTER
    f.parent.mkdir(parents=True, exist_ok=True)
    tmp = f.with_name(f.name + ".tmp")
    tmp.write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, f)


FAILED_KEEP_DAYS = 7


def activate(code: Path, new: Path, current: Path | None = None) -> dict:
    """Points the studio at ``new`` for its next start; the environment in service becomes the rollback target.
    Then only those two are kept in .venvs (plus recent failed ones, for diagnosis)."""
    current = Path(current or sys.prefix)
    d = {"current": str(Path(new)), "previous": str(current), "at": time.strftime("%Y-%m-%dT%H:%M:%S")}
    _write_pointer(code, d)
    prune(code)
    return d


def prune(code: Path, now: float | None = None) -> list[str]:
    """Removes, inside .venvs only, the environments that are neither the active one nor the previous one, and failed
    ones older than 7 days. The original .venv (outside .venvs) is never touched. Returns the removed names."""
    import shutil
    d = pointer(code)
    keep = set()
    for k in ("current", "previous"):
        if d.get(k):
            try:
                keep.add(Path(d[k]).resolve())
            except OSError:
                pass
    folder = Path(code) / ENVS
    if not d.get("current") or not folder.is_dir():
        return []
    now = time.time() if now is None else now
    removed = []
    for p in sorted(folder.iterdir()):
        if not p.is_dir() or p.is_symlink() or p.resolve() in keep:
            continue
        if p.name.endswith(".failed") and now - p.stat().st_mtime < FAILED_KEEP_DAYS * 86400:
            continue
        shutil.rmtree(p, ignore_errors=True)
        removed.append(p.name)
    return removed


def rollback(code: Path) -> dict:
    d = pointer(code)
    if not d.get("previous") or not python_in(Path(d["previous"])).exists():
        raise ValueError("Pas d'environnement précédent disponible.")
    d = {"current": d["previous"], "previous": d["current"], "at": time.strftime("%Y-%m-%dT%H:%M:%S"), "rollback": True}
    _write_pointer(code, d)
    return d


def target(code: Path) -> Path | None:
    """Interpreter the studio should run with, if it is not the current one (and exists)."""
    d = pointer(code)
    env = Path(d["current"]) if d.get("current") else None
    if env is None or not python_in(env).exists():
        return None
    try:
        if env.resolve() == Path(sys.prefix).resolve():
            return None
    except OSError:
        return None
    return python_in(env, windowed=Path(sys.executable).name.lower() == "pythonw.exe")


def relaunch_if_needed(code: Path, argv: list[str]) -> int | None:
    """Started from the old environment after an update: runs the same command with the new interpreter.
    Returns its exit code, or None when nothing is to be done (already the right one, or already relaunched)."""
    if os.environ.get(SWITCHED):
        return None
    py = target(code)
    if py is None:
        return None
    return subprocess.call([str(py), "-m", "studio", *argv], cwd=str(code), env={**os.environ, SWITCHED: "1"})
