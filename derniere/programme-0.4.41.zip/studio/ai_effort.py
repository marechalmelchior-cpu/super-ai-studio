"""Model-specific reasoning controls. Wire contracts reviewed on 2026-10-28."""
from __future__ import annotations

import re
import time
from urllib.parse import urlparse

LABELS = {"none": "Sans réflexion", "off": "Sans réflexion", "on": "Avec réflexion",
          "minimal": "Minimal", "low": "Bas", "medium": "Moyen", "high": "Élevé",
          "xhigh": "Très élevé", "max": "Maximum", "default": "Réflexion par défaut", "between_tools": "Réflexion entre les outils"}
BUDGETS = (1024, 8192, 24576)
VALUES = ("auto", *LABELS, *(f"budget:{n}" for n in BUDGETS))
THREE = ("low", "medium", "high")
FULL = (*THREE, "xhigh", "max")
# Provider inventory only: menus must use capabilities(), never this union directly.
AI_EFFORTS = {p: [(v, LABELS.get(v, v)) for v in values] for p, values in {
    "claude-code": FULL, "codex": ("none", "minimal", *FULL),
    "openai": ("none", "minimal", *FULL), "anthropic": ("off", "between_tools", *FULL, *(f"budget:{n}" for n in BUDGETS)),
    "gemini": ("none", "minimal", *THREE), "mistral": ("none", "low", "high", "max"),
    "deepseek": ("off", "on", "low", "high", "max"), "groq": ("none", "default", *THREE),
    "moonshot": ("off", "on", "low", "high", "max"), "xai": (*THREE, "xhigh"),
    "openrouter": ("none", "minimal", *FULL, *(f"budget:{n}" for n in BUDGETS)),
    "ollama": ("off", "on", *FULL), "lmstudio": ("off", "on", *THREE),
    "other": ("none", "minimal", "off", "on", *FULL), "local": ("off", "on", *FULL), "elevenlabs": (),
}.items()}
_cache = {}


def valid_value(value):
    return isinstance(value, str) and (value in ("", *VALUES) or bool(re.fullmatch(r"local:[a-z][a-z0-9_-]{0,31}", value)))


def _label(value):
    if value.startswith("budget:"):
        return f"Budget : {int(value.split(':')[1]):,} jetons".replace(",", " ")
    return LABELS.get(value, value.removeprefix("local:"))


def _result(model, values=(), kind="effort", error=""):
    return {"model": model, "options": [[v, _label(v)] for v in dict.fromkeys(values)],
            "kind": kind, "adjustable": bool(values),
            "message": error or ("" if values else "Non réglable pour ce modèle")}


def _metadata(c, kind, refresh=True):
    """No generation or runner startup; cache by endpoint, connection, key and model."""
    from . import ai
    key = (kind, c.get("id"), ai._base(c), c.get("key"), c.get("model"))
    old = _cache.get(key)
    if old and time.monotonic() - old[0] < 30:
        return old[1]
    if not refresh:
        return {}
    if kind == "ollama":
        data = ai._request({**c, "url": ai._local_runner_host(c)}, "/api/show", {"model": c["model"]}, delay=5)
    elif kind == "lmstudio":
        data = ai._request({**c, "url": ai._base(c).removesuffix("/v1")}, "/api/v1/models", delay=5)
    else:
        data = ai._request(c, "/models", delay=5)
    _cache[key] = (time.monotonic(), data)
    return data


def _openai_values(model):
    if "chat" in model or "image" in model or "realtime" in model or "audio" in model:
        return ()
    if model.startswith(("gpt-5.1-codex-max", "gpt-5.2-codex", "gpt-5.3-codex")):
        return (*THREE, "xhigh")
    if model.startswith(("gpt-5-codex", "gpt-5.1-codex")):
        return THREE
    if re.match(r"gpt-6(?:[.-]|$)", model):
        return FULL if any(n in model for n in ("astra", "terra", "6.1-sol")) else ("none", *FULL)
    if re.match(r"gpt-5\.[678](?:-|$)", model):
        return ("none", *FULL)
    if re.match(r"gpt-5\.[2345](?:-|$)", model):
        return ("medium", "high", "xhigh") if "pro" in model else ("none", *THREE, "xhigh")
    if model.startswith("gpt-5.1"):
        return (*THREE, "xhigh") if "codex" in model else ("none", *THREE)
    if re.match(r"gpt-5(?:-|$)", model):
        return ("high",) if "pro" in model else ("minimal", *THREE)
    if re.match(r"o[134](?:-|$)", model) and not any(n in model for n in ("preview", "o1-mini")):
        return THREE
    return ()


def _anthropic_values(model, cli=False):
    if cli and model in ("", "opus", "sonnet", "haiku"):
        return FULL
    budgets = tuple(f"budget:{n}" for n in BUDGETS)
    if "sonnet-5-5" in model:
        return FULL if cli else ("between_tools", *FULL)
    if re.search(r"(?:opus|sonnet|haiku)-5|(?:fable|mythos)(?:-|$)|opus-4-[78]", model):
        if cli:
            return FULL
        can_disable = ("haiku-5-5" in model or re.search(r"(?:opus|sonnet)-5(?:-|$)", model) and "5-5" not in model
                       or re.search(r"opus-4-[78]", model))
        return (*(("off",) if can_disable else ()), *FULL, *(budgets if "mythos-preview" in model else ()))
    if re.search(r"(?:opus|sonnet)-4-6", model):
        return (*THREE, "max") if cli else ("off", *THREE, "max", *budgets)
    if "opus-4-5" in model:
        return () if cli else ("off", *THREE, *budgets)
    if not cli and re.search(r"(?:sonnet|opus|haiku)-4|sonnet-3-7|3-7-sonnet", model):
        return ("off", *budgets)
    return ()


def capabilities(actor, model="", c=None, refresh=True):
    """Only documented model contracts, or exact capabilities advertised by the server."""
    model = str(model or (c or {}).get("model") or "")
    m = model.lower().removeprefix("models/")
    if actor == "claude-code":
        return _result(model, _anthropic_values(m, cli=True))
    if actor == "codex":
        return _result(model, _openai_values(m) if m else FULL)
    if not c:
        return _result(model)
    provider = c.get("provider", actor)
    provider = effective_provider(c)
    try:
        if provider == "ollama":
            data = _metadata(c, provider, refresh)
            values = (data.get("thinking") or {}).get("values")
            if values is not None:
                values = ["on" if v is True else "off" if v is False else str(v) for v in values]
                if values == ["off"]:
                    values = []
                return _result(model, [v if v in LABELS else "local:" + v for v in values], "think")
            # Older servers expose capabilities, but no per-model values.
            if "thinking" in (data.get("capabilities") or []):
                return _result(model, THREE if "gpt-oss" in m else ("off", "on"), "think")
            return _result(model)
        if provider == "lmstudio":
            rows = _metadata(c, provider, refresh).get("models") or []
            row = next((r for r in rows if model in [r.get("key"), *[i.get("id") for i in r.get("loaded_instances", [])]]), {})
            values = (row.get("reasoning") or {}).get("allowed_options") or []
            return _result(model, [v for v in values if v in ("off", "on", *THREE)], "lm_reasoning")
        if provider in ("openrouter", "other"):
            rows = _metadata(c, provider, refresh).get("data") or []
            row = next((r for r in rows if r.get("id") == model), {})
            reasoning = row.get("reasoning") or {}
            values = reasoning.get("supported_efforts", [])
            if values is None:
                values = ("none", "minimal", *FULL)
            values = [v for v in values if v in LABELS and not (v == "none" and reasoning.get("mandatory"))]
            if provider == "openrouter" and reasoning.get("supports_max_tokens"):
                values += [f"budget:{n}" for n in BUDGETS]
            return _result(model, values, "router" if provider == "openrouter" else "effort")
    except (OSError, ValueError, RuntimeError):
        return _result(model, error="Capacités indisponibles : réessaie quand l’IA répond.")
    if provider == "openai":
        return _result(model, _openai_values(m))
    if provider == "anthropic":
        return _result(model, _anthropic_values(m), "anthropic")
    if provider == "gemini":
        values = ()
        if m.startswith("gemini-2.5-") and not any(v in m for v in ("tts", "image", "native-audio")):
            values = THREE if "pro" in m else ("none", *THREE)
        elif m.startswith("gemini-3-pro"):
            values = ("low", "high")
        elif m.startswith("gemini-3.1-flash-lite-image"):
            values = ("minimal", "high")
        elif m.startswith(("gemini-3.1-pro", "gemini-3.8-", "gemini-4-argon")):
            values = THREE
        elif m.startswith(("gemini-3-flash", "gemini-3.1-flash-lite", "gemini-3.5-", "gemini-3.6-", "gemini-robotics-er-2")):
            values = ("minimal", *THREE)
        return _result(model, values)
    if provider == "mistral":
        values = ("low", "high", "max") if m == "zai-glm-5-3" else ("none", "high") if m in (
            "mistral-small-latest", "mistral-small-4", "mistral-small-2603", "mistral-medium-3-5", "mistral-medium-latest", "mistral-large-4-0") else ()
        return _result(model, values)
    if provider == "deepseek":
        if m.startswith(("deepseek-flash", "deepseek-v4")):
            return _result(model, ("off", "low", "high", "max"), "deepseek")
    if provider == "groq":
        values = THREE if m in ("openai/gpt-oss-20b", "openai/gpt-oss-120b") else ()
        if m == "qwen/qwen3-32b" or "qwen3.6" in m:
            values = ("none", "default")
        if "qwen3.8" in m:
            values = ("none", "default", *THREE)
        if "muse-spark" in m:
            values = (*THREE, "xhigh")
        return _result(model, values)
    if provider == "moonshot":
        if m.startswith("kimi-k3"):
            return _result(model, ("low", "high", "max"))
        if m.startswith(("kimi-k2.5", "kimi-k2.6")):
            return _result(model, ("off", "on"), "thinking")
    if provider == "xai":
        values = ("low", "high") if m.startswith("grok-3-mini") else ()
        if m.startswith(("grok-4.6", "grok-4.7", "grok-4.20-multi-agent")):
            values = (*THREE, "xhigh")
        elif m.startswith(("grok-4.3", "grok-4.5", "grok-4.20")) and "non-reasoning" not in m:
            values = THREE
        return _result(model, values)
    return _result(model)


def effective_provider(c):
    provider = c.get("provider", "")
    if provider != "other":
        return provider
    host = urlparse(ai_base(c)).hostname or ""
    return {"api.openai.com": "openai", "api.anthropic.com": "anthropic", "api.mistral.ai": "mistral",
            "api.deepseek.com": "deepseek", "api.groq.com": "groq", "api.x.ai": "xai",
            "api.moonshot.ai": "moonshot", "openrouter.ai": "openrouter",
            "generativelanguage.googleapis.com": "gemini"}.get(host, "other")


def preset_value(values, requested):
    """Rank semantics, not the server's list order (some gateways sort descending)."""
    if requested in values:
        return requested
    def rank(value):
        if value.startswith("budget:"):
            return 4 + int(value.split(':')[1]) / 32768
        return {"none": 0, "off": 0, "minimal": 1, "low": 2, "default": 3, "on": 3,
                "medium": 3, "high": 4, "xhigh": 5, "max": 6}.get(value, 3)
    return (min(values, key=rank) if requested == "low" else max(values, key=rank)) if values and requested else "auto"


def ai_base(c):
    from .ai import _base
    return _base(c)


def parameters(c, effort):
    """Explicit requests are never clamped or silently retried without the control."""
    if effort in ("", "auto"):
        return {}
    cap = capabilities(c.get("provider", ""), c=c)
    if effort not in {v for v, _ in cap["options"]}:
        raise ValueError(cap["message"] or "Cet effort n’est pas accepté pour ce modèle. Choisis un niveau proposé ou Auto.")
    kind = cap["kind"]
    if kind == "think":
        return {"think": {"off": False, "on": True}.get(effort, effort.removeprefix("local:"))}
    if kind == "lm_reasoning":
        return {"reasoning_effort": effort}
    if kind in ("thinking", "deepseek"):
        result = {"thinking": {"type": "disabled" if effort == "off" else "enabled"}}
        if kind == "deepseek" and effort != "off":
            result["reasoning_effort"] = effort
        return result
    if kind == "router":
        return {"reasoning": {"max_tokens": int(effort.split(':')[1])} if effort.startswith("budget:") else {"effort": effort}}
    if kind == "anthropic":
        if effort == "off":
            return {"thinking": {"type": "disabled"}}
        if effort == "between_tools":
            return {"thinking": {"type": "between_tools"}, "output_config": {"effort": "high"}}
        if effort.startswith("budget:"):
            return {"thinking": {"type": "enabled", "budget_tokens": int(effort.split(':')[1])}}
        result = {"output_config": {"effort": effort}}
        result["thinking"] = ({"type": "enabled", "budget_tokens": 24576} if "opus-4-5" in c["model"] else {"type": "adaptive"})
        return result
    return {"reasoning_effort": effort}


def selection(studio, ident="", model="", role_id="", target=""):
    """Resolve the same effective AI/model as an actual task before displaying choices."""
    from . import ai
    resolved_role = role_id
    if not ident:
        role = studio.roles.get(role_id) or studio.roles.get("producer") or next(iter(studio.roles.values()))
        resolved_role = role.id
        opts = {"model": model} if model else {}
        actor, connection = studio.role_ai(role, opts, target)
        ident = connection or actor
        model = model or studio.execution_model(role, opts, target)
    if ident in ("claude-code", "codex"):
        if ident == "codex" and not model:
            from .connectors.secondary_cli import SecondaryCliExecutor
            model = SecondaryCliExecutor.default_model()
        result = capabilities(ident, model)
        result.update(id=ident, role=resolved_role, models=list((studio.executors.get(ident).models() if callable(getattr(studio.executors.get(ident), "models", None)) else
                                           studio.choice().get("secondary_models" if ident == "codex" else "models", []))))
        return result
    c = ai.connection(studio.paths.data, ident)
    if not c:
        raise ValueError("IA inconnue : connecte-la d’abord dans les réglages.")
    c = {**c, "model": model or c.get("model", "")}
    return {**capabilities(c["provider"], c=c), "id": ident, "role": resolved_role}
