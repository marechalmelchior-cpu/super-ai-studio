"""Catalogue normalisé en lecture seule pour les deux vues Extensions."""
from __future__ import annotations

from . import library, software_connectors, teams


KINDS = {"skill": "skill", "mcp": "mcp", "software": "software"}


def build_catalog(studio) -> dict:
    """Décrit la disponibilité et les choix des projets, sans tester ni lancer un outil."""
    snapshot = library.state(studio)
    targets = list(studio.registry.all())
    choices = teams.read_file(studio.paths.data)
    declared = software_connectors.list_all(studio)
    software = [e for e in snapshot["elements"] if e["type"] == "software" and not e.get("outside_catalog")]
    declarations = {}
    aliases = set()
    for entry in declared:
        match = next((e for e in software if e["name"].casefold() == entry["name"].casefold()
                      or e["id"] == "software-" + entry["id"]), None)
        declarations[(match or entry)["id"]] = entry
        if match:
            aliases.add(entry["id"])
    items = []
    for entry in snapshot["elements"]:
        kind = KINDS.get(entry["type"])
        if not kind or (kind == "software" and entry.get("outside_catalog") and entry["id"] in aliases):
            continue
        item = {**entry, "kind": kind, "installed": bool(entry.get("installed")),
                "domain": entry.get("category") or "custom", "state": "available", "used_by": None}
        declaration = declarations.get(item["id"])
        if declaration:
            item.update(installed=True, auto=False, found=bool(declaration["ok"]))
            item["removal_id"] = declaration["id"]
        if item["installed"]:
            item.update(state="active", used_by="common")
            if kind == "software" and not item.get("found", True):
                item["state"] = "error"
            if kind == "skill":
                meta = library._read_json(studio.paths.root / "Skills" / item["id"] / ".library.json", {})
                if isinstance(meta, dict) and isinstance(meta.get("installed"), str):
                    item["installed_at"] = meta["installed"]
            if kind == "mcp":
                enabled = []
                for target in targets:
                    key = f"{target.kind}:{target.id}"
                    selected = (choices.get(key) or {}).get("mcp")
                    active = item["id"] in selected if isinstance(selected, list) else teams.relevant_mcp(item["id"], target)
                    if active:
                        enabled.append({"key": key, "name": target.name})
                common = not any(engine in item["id"].lower() for engine in teams.ENGINE_MCP)
                if not common or any(isinstance((choices.get(f"{t.kind}:{t.id}") or {}).get("mcp"), list) for t in targets):
                    item["used_by"] = enabled
                if targets and not enabled:
                    item["state"] = "disabled"
        items.append(item)
    from .mcp_discovery import detected
    items.extend(detected(studio))
    from .mcp_discovery import detected
    items.extend(detected(studio))
    available = {e["id"] for e in items if not e["installed"]}
    packs = {e["id"]: e for e in snapshot["elements"] if e["type"] == "pack"}
    recommended = []
    for ident in snapshot.get("for_you", []):
        for member in packs.get(ident, {}).get("members", [ident]):
            if member in available and member not in recommended:
                recommended.append(member)
    return {"items": items, "domains": {**snapshot["categories"], "custom": "Personnel et studio"},
            "recommended": recommended[:6], "discover": [e["id"] for e in items if not e["installed"]],
            "projects": [{"key": f"{t.kind}:{t.id}", "name": t.name} for t in targets]}
