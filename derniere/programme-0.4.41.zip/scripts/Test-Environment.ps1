﻿# Test-Environment.ps1 — LECTURE SEULE.
# Relève les versions et capacités utiles au studio. N'installe rien, ne démarre rien,
# ne lance aucun client MCP, n'affiche aucun secret. Résultat : AI-Workspace\Studio\data\journaux\environnement-<date>.json
$ErrorActionPreference = 'Continue'
$Racine = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
$res = [ordered]@{ cree = (Get-Date).ToUniversalTime().ToString('o'); machine = $env:COMPUTERNAME }

function Version($exe, $argList) {
    try { $o = & $exe @argList 2>&1 | Select-Object -First 2; return (($o | Out-String).Trim()) } catch { return $null }
}
function Cmd($name) { $c = Get-Command $name -ErrorAction SilentlyContinue; if ($c) { $c.Source } else { $null } }

# Python
$res.python = [ordered]@{ py = Cmd 'py'; python = Cmd 'python'; uv = Cmd 'uv' }
if ($res.python.py) { $res.python.versions = (& py -0p 2>&1 | Out-String).Trim() }
if ($res.python.python) { $res.python.version = Version 'python' @('--version')
    $venvpy = Join-Path (Split-Path -Parent $PSScriptRoot) '.venv\Scripts\python.exe'
    if (Test-Path $venvpy) { $res.python.langgraph_studio = (& $venvpy -c 'import importlib.metadata as m;print(m.version("langgraph"))' 2>$null) } }

# Node / Git
$res.node = [ordered]@{ chemin = Cmd 'node'; version = Version 'node' @('--version'); npx = Cmd 'npx' }
$res.git = [ordered]@{ chemin = Cmd 'git'; version = Version 'git' @('--version') }

# Claude Code
$claude = Cmd 'claude'
$res.claude_code = [ordered]@{ chemin = $claude; version = $(if ($claude) { Version $claude @('--version') }) }
$cj = Join-Path $env:USERPROFILE '.claude.json'
if (Test-Path $cj) {
    try {
        $j = Get-Content $cj -Raw | ConvertFrom-Json
        $servers = @()
        if ($j.mcpServers) { foreach ($p in $j.mcpServers.PSObject.Properties) {
            $servers += [ordered]@{ nom = $p.Name; commande = $p.Value.command; args = $p.Value.args
                                    env_noms = $(if ($p.Value.env) { @($p.Value.env.PSObject.Properties.Name) } else { @() }) } } }
        $res.claude_code.mcp_utilisateur = $servers
    } catch { $res.claude_code.mcp_utilisateur = 'illisible' }
}
$plug = Join-Path $env:USERPROFILE '.claude\plugins'
$res.claude_code.plugins_mcp_agentmemory = @(Get-ChildItem $plug -Recurse -Filter '.mcp.json' -ErrorAction SilentlyContinue |
    Where-Object { (Get-Content $_.FullName -Raw) -match 'agentmemory' } | ForEach-Object { $_.FullName })

# Codex
$codex = Cmd 'codex'
$app = Get-ChildItem "$env:LOCALAPPDATA\OpenAI\Codex\bin\*\codex.exe" -ErrorAction SilentlyContinue | Sort-Object LastWriteTime | Select-Object -Last 1
$res.codex = [ordered]@{ chemin_path = $codex; version_path = $(if ($codex) { Version $codex @('--version') })
                         chemin_app = $(if ($app) { $app.FullName }); version_app = $(if ($app) { Version $app.FullName @('--version') }) }

# AgentMemory
$am = Join-Path $env:APPDATA 'npm\node_modules\@agentmemory\agentmemory\package.json'
$res.agentmemory = [ordered]@{
    global_version = $(if (Test-Path $am) { (Get-Content $am -Raw | ConvertFrom-Json).version } else { 'absent' })
    cli_dans_path = Cmd 'agentmemory'
    iii_bin_agentmemory = Test-Path (Join-Path $env:USERPROFILE '.agentmemory\bin\iii.exe')
    iii_dossier = Test-Path (Join-Path $env:USERPROFILE '.iii')
    iii_dans_path = Cmd 'iii'
    port_3111_ecoute = [bool](Get-NetTCPConnection -LocalPort 3111 -State Listen -ErrorAction SilentlyContinue)
    standalone_json = Test-Path (Join-Path $env:USERPROFILE '.agentmemory\standalone.json')
}
$procs = Get-CimInstance Win32_Process -Filter "Name='node.exe'" -ErrorAction SilentlyContinue |
    Where-Object { $_.CommandLine -match 'agentmemory' }
$res.agentmemory.processus = @($procs | ForEach-Object {
    $parent = Get-CimInstance Win32_Process -Filter "ProcessId=$($_.ParentProcessId)" -ErrorAction SilentlyContinue
    [ordered]@{ pid = $_.ProcessId; parent = $(if ($parent) { $parent.Name }); serveur = ($_.CommandLine -match 'agentmemory(\.cmd)?"?\s*$|cli\.mjs') } })

# Blender / Unreal
$res.blender = @(Get-ChildItem 'C:\Program Files\Blender Foundation\*\blender.exe' -ErrorAction SilentlyContinue |
    ForEach-Object { [ordered]@{ chemin = $_.FullName; version = (Version $_.FullName @('--version')) -split "`n" | Select-Object -First 1 } })
$res.unreal = @(Get-ChildItem 'C:\Program Files\Epic Games\UE_*\Engine\Build\Build.version' -ErrorAction SilentlyContinue |
    ForEach-Object { $b = Get-Content $_.FullName -Raw | ConvertFrom-Json
        [ordered]@{ dossier = $_.Directory.Parent.Parent.FullName; version = "$($b.MajorVersion).$($b.MinorVersion).$($b.PatchVersion)"
                    editor_cmd = Test-Path (Join-Path $_.Directory.Parent.FullName 'Binaries\Win64\UnrealEditor-Cmd.exe') } })

$out = Join-Path $Racine ("Studio\data\journaux\environnement-{0}.json" -f (Get-Date -Format 'yyyyMMdd-HHmmss'))
New-Item -ItemType Directory -Force -Path (Split-Path $out) | Out-Null
[System.IO.File]::WriteAllText($out, ($res | ConvertTo-Json -Depth 6), (New-Object System.Text.UTF8Encoding($false)))
Write-Output "Relevé écrit : $out"
