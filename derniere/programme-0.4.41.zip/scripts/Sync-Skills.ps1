﻿# Sync-Skills.ps1 — copie les skills communs vers Claude Code et Codex (préfixe « studio- »).
# Source unique : AI-Workspace\Skills. N'écrase jamais un skill qui n'a pas été créé par le studio.
param([switch]$Confirmer)
$ErrorActionPreference = 'Stop'
$Racine = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
$cibles = @((Join-Path $env:USERPROFILE '.claude\skills'), (Join-Path $env:USERPROFILE '.codex\skills'))
$marque = '<!-- genere-par-ai-workspace : ne pas modifier ici -->'
foreach ($skill in Get-ChildItem (Join-Path $Racine 'Skills') -Directory) {
  if ($skill.Name -in @('supervisor', 'superviseur')) { continue }   # réservé au Superviseur du studio, jamais copié chez les agents
  foreach ($c in $cibles) {
    $dest = Join-Path $c ("studio-" + $skill.Name)
    $md = Join-Path $dest 'SKILL.md'
    if ((Test-Path $md) -and -not ([System.IO.File]::ReadAllText($md, [System.Text.Encoding]::UTF8) -match [regex]::Escape($marque))) {
      Write-Output "IGNORÉ (skill existant non géré par le studio) : $dest"; continue }
    if (-not $Confirmer) { Write-Output "À copier : $($skill.Name) -> $dest"; continue }
    New-Item -ItemType Directory -Force -Path $dest | Out-Null
    # Lecture explicite en UTF-8 : Get-Content de Windows PowerShell 5.1 lit sinon en ANSI et produit « Ã© » (défaut du 22/10).
    $src = [System.IO.File]::ReadAllText((Join-Path $skill.FullName 'SKILL.md'), [System.Text.Encoding]::UTF8)
    if ($src -match 'Ã[©¨ª ¢®´»§]') { throw "Source mal encodée (double encodage) : $($skill.Name). Rien n'est copié." }
    $src = $src -replace '(?m)^name:\s*(?!studio-)(.+)$', 'name: studio-$1'
    $src = $src -replace '(?s)^(---.*?---\r?\n)', "`$1$marque`r`n"
    [System.IO.File]::WriteAllText($md, $src, (New-Object System.Text.UTF8Encoding($false)))   # sans BOM (en-tête YAML)
    # Appel explicite seulement (disable-model-invocation: true) : équivalent Codex dans agents\openai.yaml
    if (($c -like '*\.codex\skills') -and ($src -match '(?ms)^---.*?^disable-model-invocation:\s*true\s*$.*?^---')) {
      $yaml = Join-Path $dest 'agents\openai.yaml'
      if (-not (Test-Path $yaml) -or ([System.IO.File]::ReadAllText($yaml, [System.Text.Encoding]::UTF8) -match 'genere-par-ai-workspace')) {
        New-Item -ItemType Directory -Force -Path (Split-Path $yaml) | Out-Null
        [System.IO.File]::WriteAllText($yaml, "# genere-par-ai-workspace : appel explicite seulement (`$nom-du-skill)`npolicy:`n  allow_implicit_invocation: false`n", (New-Object System.Text.UTF8Encoding($false)))
      }
    }
  }
}
if (-not $Confirmer) { Write-Output 'Simulation uniquement. Ajouter -Confirmer pour copier.'; exit 0 }
# Skills des projets (.claude\skills) -> .agents\skills pour Codex, avec exclusion Git locale.
$py = Join-Path $PSScriptRoot '..\.venv\Scripts\python.exe'
if (Test-Path $py) {
  Push-Location (Split-Path -Parent $PSScriptRoot)
  try { & $py -X utf8 -m studio skills-synchroniser } finally { Pop-Location }
} else { Write-Output 'Skills des projets non synchronisés : Studio\.venv introuvable.' }
