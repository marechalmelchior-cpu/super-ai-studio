﻿# Apply-Configs.ps1 — À LANCER SEULEMENT APRÈS VALIDATION. Fermer Codex et Claude Code avant.
# 1) sauvegarde ; 2) régénère la proposition à partir de la config actuelle ; 3) montre le diff ; 4) applique après « OUI ».
$ErrorActionPreference = 'Stop'
$Studio = Split-Path -Parent $PSScriptRoot
$py = Join-Path $Studio '.venv\Scripts\python.exe'
if (-not (Test-Path $py)) { $py = 'python' }
. (Join-Path $PSScriptRoot 'Common.ps1')
$ouverts = Get-ClientsAOuvrir
if ($ouverts) { Write-Output ('Fermer d''abord : ' + ($ouverts -join ', ') + ' (Claude Desktop peut rester ouvert)'); exit 1 }
Push-Location $Studio
try {
  & $py -m studio config-preparer
  Get-Content 'configs-preparees\codex.config.toml.diff'
  if ((Read-Host 'Appliquer ce changement à ~/.codex/config.toml ? Taper OUI') -ne 'OUI') { exit 1 }
  & $py -m studio config-appliquer
  # Claude Code : sauvegarde chiffrée de ~/.claude.json puis mise à jour par la commande officielle.
  & $py -c "from pathlib import Path;from studio.backup import protect;import datetime as d;s=Path.home()/'.claude.json';o=Path('..')/'Sauvegardes'/'Configs'/('claude.json-'+d.datetime.utcnow().strftime('%Y%m%dT%H%M%SZ')+'.dpapi');o.parent.mkdir(parents=True,exist_ok=True);o.open('xb').write(protect(s.read_bytes()));print(o)"
  $version = & $py -c "from studio.configs import AGENTMEMORY_VERSION;print(AGENTMEMORY_VERSION)"
  Write-Output "Entrée Claude Code proposée : npx -y @agentmemory/mcp@$version ; AGENTMEMORY_URL=http://localhost:3111 ; AGENTMEMORY_FORCE_PROXY=1"
  if ((Read-Host 'Remplacer le serveur MCP « agentmemory » (portée utilisateur) de Claude Code ? Taper OUI') -eq 'OUI') {
    claude mcp remove agentmemory -s user
    claude mcp add agentmemory -s user -e AGENTMEMORY_URL=http://localhost:3111 -e AGENTMEMORY_FORCE_PROXY=1 '--' npx -y "@agentmemory/mcp@$version"
  }
} finally { Pop-Location }
