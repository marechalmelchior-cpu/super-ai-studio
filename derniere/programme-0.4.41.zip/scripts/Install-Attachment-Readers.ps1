﻿# Install-Attachment-Readers.ps1 — modules optionnels pour que les agents lisent toutes les pièces jointes.
# Sans -Confirmer : affiche ce qui serait installé et la place prise, n'installe rien.
#   PyMuPDF  (~120 Mo) : texte des PDF + image de chaque page
#   Pillow   (~20 Mo)  : conversion des images peu courantes (BMP, TIFF, TGA, PSD…) et spectrogrammes
#   faster-whisper + PyAV (~400 Mo avec leurs dépendances) : sons et vidéos (transcription de la parole, images clés, niveaux)
#   + modèle de parole « small » (~480 Mo) téléchargé à la première pièce sonore, dans Studio\data\modeles-parole
# -SansParole : PyMuPDF et Pillow seulement (~140 Mo).
# Tout reste local : aucune clé, aucun service, rien ne démarre tout seul.
param([switch]$Confirmer, [switch]$SansParole)
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'Common.ps1')
$Studio = Split-Path -Parent $PSScriptRoot
$lock = Join-Path $Studio 'requirements-attachments.lock.txt'
if (-not (Test-Path -LiteralPath $lock)) { $lock = Join-Path $Studio 'requirements-pieces.lock.txt' }   # nom livré par la mise à jour 0.4.39
$paquets = @(Get-Content $lock -Encoding UTF8 | Where-Object { $_ -and -not $_.StartsWith('#') })
if ($SansParole) { $paquets = @($paquets | Where-Object { $_ -match '^(PyMuPDF|pillow)==' }) }
Write-Output 'Modules qui seraient installés dans Studio\.venv :'
$paquets | ForEach-Object { Write-Output "  $_" }
if (-not $SansParole) { Write-Output 'Place : ~550 Mo + modèle de parole ~480 Mo à la première pièce sonore (≈ 1 Go au total).' }
else { Write-Output 'Place : ~140 Mo.' }
if (-not $Confirmer) { Write-Output 'Rien n''a été installé. Ajouter -Confirmer pour installer.'; exit 1 }
$py = Get-StudioPython
if (-not $py) { throw 'Studio\.venv introuvable : lancer d''abord Install-Dependencies.ps1 -Confirmer.' }
& $py -m pip install --disable-pip-version-check @paquets
if ($LASTEXITCODE) { throw 'Installation en échec (rien d''autre n''a été modifié).' }
Push-Location $Studio
try { & $py -X utf8 -c "from studio import pieces; import json; print(json.dumps(pieces.capacites(), ensure_ascii=False))" }
finally { Pop-Location }
Write-Output 'Fermer puis relancer Super AI Agent Pro Station Max 2000 pour en profiter.'
