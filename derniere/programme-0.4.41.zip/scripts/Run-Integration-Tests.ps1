﻿# Run-Integration-Tests.ps1 — tests réels APRÈS mise en service. Ouvrir un PowerShell NEUF (variables d'environnement à jour).
# Consomme quelques appels de Claude Code et Codex (abonnements). Les étapes 3 et 5 arrêtent puis redémarrent le serveur.
$ErrorActionPreference = 'Stop'
$Studio = Split-Path -Parent $PSScriptRoot
$py = Join-Path $Studio '.venv\Scripts\python.exe'
if ((Read-Host 'Lancer les tests d''intégration (≈ 8 appels Claude/Codex) ? Taper o') -ne 'o') { exit 1 }
Push-Location $Studio
try {
  $env:STUDIO_INTEGRATION = '1'
  & $py -X utf8 -m pytest -v -s -rs tests\integration
} finally { Remove-Item Env:STUDIO_INTEGRATION -ErrorAction SilentlyContinue; Pop-Location }
