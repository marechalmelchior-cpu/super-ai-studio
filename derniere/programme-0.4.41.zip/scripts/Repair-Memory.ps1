﻿# Repair-Memory.ps1 — remise en route de la mémoire partagée (22/10) :
#  1) sauvegarde CHIFFRÉE des données du serveur ; 2) relevé des variables d'embedding (masqué) ;
#  3) redémarrage avec le modèle d'embedding figé et reconstruction de l'index de recherche incompatible ;
#  4) ajout du serveur MCP « studio-memoire » (portée imposée, panne visible) à Codex et à Claude Code ;
#  5) contrôles. Fermer Codex et Claude Code avant (Claude Desktop peut rester ouvert).
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'Common.ps1')
$Studio = Split-Path -Parent $PSScriptRoot
$Racine = Split-Path -Parent $Studio
$py = Get-StudioPython
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
Start-Transcript -Path "$Racine\Studio\data\journaux\reparation-memoire-$stamp.log" | Out-Null
try {
  while ($o = Get-ClientsAOuvrir) { Write-Host ('Ferme : ' + ($o -join ', ')) -ForegroundColor Yellow; Read-Host 'Puis Entrée' | Out-Null }

  Write-Host "`n=== 1. Arrêt éventuel et sauvegarde chiffrée des données ===" -ForegroundColor Cyan
  & (Join-Path $PSScriptRoot 'Stop-Memory.ps1') | Out-Null
  $data = Join-Path $Studio 'data\agentmemory\data'
  Add-Type -AssemblyName System.Security, System.IO.Compression, System.IO.Compression.FileSystem
  $ms = New-Object System.IO.MemoryStream
  $zip = New-Object System.IO.Compression.ZipArchive($ms, [System.IO.Compression.ZipArchiveMode]::Create, $true)
  foreach ($f in Get-ChildItem $data -Recurse -File) {
    $rel = $f.FullName.Substring($data.Length + 1)
    [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip, $f.FullName, $rel) | Out-Null }
  $zip.Dispose()
  $enc = [System.Security.Cryptography.ProtectedData]::Protect($ms.ToArray(), $null, 'CurrentUser')
  $magic = [System.Text.Encoding]::ASCII.GetBytes("STUDIO-DPAPI-BACKUP-V1`0")
  $out = "$Racine\Sauvegardes\Configs\agentmemory-donnees-$stamp.dpapi"
  $fs = [System.IO.File]::Open($out, 'CreateNew'); $fs.Write($magic, 0, $magic.Length); $fs.Write($enc, 0, $enc.Length); $fs.Close()
  Write-Output "Sauvegarde : $out ($([math]::Round((Get-Item $out).Length/1KB)) Ko)"

  Write-Host "`n=== 2. Variables liées aux embeddings (valeurs sensibles masquées) ===" -ForegroundColor Cyan
  foreach ($scope in 'Process', 'User', 'Machine') {
    $vars = [Environment]::GetEnvironmentVariables($scope)
    foreach ($k in $vars.Keys) { if ($k -match 'EMBEDDING|OPENAI|GEMINI|VOYAGE|COHERE|OPENROUTER') {
      $v = if ($k -match 'KEY|SECRET|TOKEN') { '<MASQUÉ>' } else { $vars[$k] }; Write-Output "$scope : $k = $v" } } }

  Write-Host "`n=== 3. Redémarrage (modèle figé, index reconstruit) ===" -ForegroundColor Cyan
  & (Join-Path $PSScriptRoot 'Start-Memory.ps1') -Confirmer -ReconstruireIndex
  if ($LASTEXITCODE) { throw 'Serveur non démarré : voir Studio\data\agentmemory\logs\serveur.err.log' }

  Write-Host "`n=== 4. Serveur MCP studio-memoire pour Codex et Claude Code ===" -ForegroundColor Cyan
  Push-Location $Studio
  try {
    & $py -m studio config-preparer --studio-mcp | Out-Null
    Get-Content 'configs-preparees\codex.config.toml.diff'
    & $py -m studio config-appliquer
    if ($LASTEXITCODE) { throw 'Config Codex non appliquée.' }
  } finally { Pop-Location }
  $claude = (Get-Command claude -ErrorAction SilentlyContinue).Source
  if ($claude) {
    $ErrorActionPreference = 'Continue'; & $claude mcp remove studio-memoire -s user | Out-Null; $ErrorActionPreference = 'Stop'   # absent au premier passage
    & $claude mcp add studio-memoire -s user -e "PYTHONPATH=$Studio" -e STUDIO_MCP_CLIENT=claude-code -e PYTHONUTF8=1 '--' $py -m studio.mcp_server
    if ($LASTEXITCODE) { throw 'claude mcp add studio-memoire a échoué.' }
  } else { Write-Host 'Commande claude introuvable : ajout côté Claude Code non fait.' -ForegroundColor Yellow }

  & (Join-Path $PSScriptRoot 'Sync-Skills.ps1') -Confirmer      # instructions mémoire mises à jour (skills studio-*)

  Write-Host "`n=== 5. Contrôles ===" -ForegroundColor Cyan
  & (Join-Path $Studio 'studio.cmd') etat --rapide
  & $py -X utf8 -m pytest -q (Join-Path $Studio 'tests\test_mcp_server.py')
  Write-Host "`nTerminé. Lance ensuite : .\scripts\Run-Integration-Tests.ps1" -ForegroundColor Green
} catch {
  Write-Host "`nARRÊT : $($_.Exception.Message)" -ForegroundColor Red
} finally { Stop-Transcript | Out-Null }
