﻿# Stop-Memory.ps1 — arrête UNIQUEMENT le serveur lancé par Start-Memory.ps1 :
# le lanceur enregistré, puis le moteur iii et le worker qu'il a démarrés en processus détachés
# (identifiés par ~/.agentmemory/iii.pid et worker.pid, écrits APRÈS notre démarrage et vérifiés par nom et heure de lancement).
param([string]$Donnees = '')
$ErrorActionPreference = 'Stop'
$Racine = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
if (-not $Donnees) { $Donnees = Join-Path $Racine 'Studio\data\agentmemory' }
$f = Join-Path $Donnees 'serveur-studio.json'
if (-not (Test-Path $f)) { Write-Output 'Aucun serveur lancé par le studio.'; exit 0 }
$info = Get-Content $f -Raw | ConvertFrom-Json
$debut = [datetime]$info.demarre
$arretes = @()
function Stop-SiNotre([int]$procId, [string[]]$noms, [string]$role) {
  $p = Get-Process -Id $procId -ErrorAction SilentlyContinue
  if (-not $p) { return }
  if ($noms -notcontains $p.ProcessName.ToLower()) { Write-Output "PID $procId ($($p.ProcessName)) ignoré : nom inattendu pour $role."; return }
  if ($p.StartTime -lt $debut.AddSeconds(-5)) { Write-Output "PID $procId ignoré : lancé avant notre démarrage ($role)."; return }
  taskkill /PID $procId /T /F | Out-Null
  $script:arretes += "$role (PID $procId)"
}
Stop-SiNotre $info.pid @('cmd', 'node', 'npx', 'agentmemory') 'lanceur'
$am = Join-Path $env:USERPROFILE '.agentmemory'
foreach ($e in @(@{ f = 'worker.pid'; n = @('node'); r = 'worker' }, @{ f = 'iii.pid'; n = @('iii'); r = 'moteur iii' })) {
  $pf = Join-Path $am $e.f
  if ((Test-Path $pf) -and (Get-Item $pf).LastWriteTime -ge $debut.AddSeconds(-5)) {
    $procId = 0
    if ([int]::TryParse((Get-Content $pf -Raw).Trim(), [ref]$procId)) { Stop-SiNotre $procId $e.n $e.r }
  }
}
Start-Sleep -Seconds 2
Write-Output ('Arrêtés : ' + $(if ($arretes) { $arretes -join ', ' } else { 'aucun' }))
$reste = Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue | Where-Object { $_.LocalPort -in 3111, 49134 }
if ($reste) { Write-Output ('Encore à l''écoute : ' + (($reste | ForEach-Object { "$($_.LocalPort) (PID $($_.OwningProcess))" }) -join ', ') + ' — rien d''autre n''est arrêté.'); exit 1 }
Write-Output 'Serveur AgentMemory du studio arrêté (ports 3111 et 49134 fermés).'
