"""Clé de signature des mises à jour du studio (Ed25519).

  python scripts/update_signing_key.py generate --private <fichier>
      Crée la clé privée dans <fichier> (jamais dans un dépôt git ni dans le dossier du studio ; jamais d'écrasement)
      et écrit la clé publique dans studio/update-public-key.txt (livrée avec le studio).
  python scripts/update_signing_key.py show --private <fichier>
      Affiche la clé publique et son identifiant, et vérifie qu'elle correspond à celle du studio.

La clé privée n'est jamais affichée. Sauvegarde-la hors du PC (voir le rapport de livraison) : sans elle, plus aucune
mise à jour signée ; si elle fuit, quelqu'un peut signer une fausse mise à jour.
"""
from __future__ import annotations

import argparse
import os
import secrets
import subprocess
import sys
from pathlib import Path

CODE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(CODE))
from studio.update_signature import PUBLIC_KEY_FILE, key_id, public_key, read_public_key  # noqa: E402


def forbidden_place(path: Path) -> str:
    """Why this place is refused for a private key (inside a git repository or the studio), or ""."""
    p = path.resolve()
    for parent in [p.parent, *p.parent.parents]:
        if (parent / ".git").exists():
            return f"dans un dépôt git ({parent})"
        if (parent / "Studio" / "studio" / "update_signature.py").exists() or parent == CODE.resolve():
            return f"dans le dossier du studio ({parent})"
    return ""


def read_private(path: Path) -> bytes:
    lines = [l.strip() for l in path.read_text(encoding="utf-8").splitlines() if l.strip() and not l.startswith("#")]
    return bytes.fromhex(lines[0])


def generate(path: Path, public_file: Path = PUBLIC_KEY_FILE) -> str:
    why = forbidden_place(path)
    if why:
        raise SystemExit(f"Refusé : la clé privée ne doit pas être {why}.")
    if path.exists():
        raise SystemExit(f"Refusé : {path} existe déjà (jamais d'écrasement d'une clé).")
    if read_public_key(public_file) is not None:
        raise SystemExit(f"Refusé : {public_file} contient déjà une clé publique (changer de clé se prépare à part).")
    secret = secrets.token_bytes(32)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        f.write("# Clé PRIVÉE de signature des mises à jour du studio. Ne jamais la publier ni la copier dans un dépôt.\n")
        f.write(secret.hex() + "\n")
    if sys.platform == "win32":                     # readable by this Windows account only (best effort)
        subprocess.run(["icacls", str(path), "/inheritance:r", "/grant:r", f"{os.environ.get('USERNAME', '')}:F"],
                       capture_output=True, check=False)
    public = public_key(secret)
    text = public_file.read_text(encoding="utf-8") if public_file.exists() else ""
    public_file.write_text(text.rstrip("\n") + ("\n" if text else "") + public.hex() + "\n", encoding="utf-8", newline="\n")
    return public.hex()


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="Clé de signature des mises à jour du studio")
    parser.add_argument("action", choices=["generate", "show"])
    parser.add_argument("--private", required=True, help="fichier de la clé privée (hors de tout dépôt)")
    args = parser.parse_args(argv)
    path = Path(args.private).expanduser()
    if args.action == "generate":
        public = generate(path)
        print(f"Clé privée créée : {path}")
        print(f"Clé publique écrite dans {PUBLIC_KEY_FILE} : {public} (identifiant {key_id(bytes.fromhex(public))})")
        return 0
    public = public_key(read_private(path))
    shipped = read_public_key()
    print(f"Clé publique : {public.hex()} (identifiant {key_id(public)})")
    print("Correspond à la clé du studio." if shipped == public else "NE correspond PAS à studio/update-public-key.txt.")
    return 0 if shipped == public else 1


if __name__ == "__main__":
    raise SystemExit(main())
