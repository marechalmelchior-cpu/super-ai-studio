"""Build an Unreal project unattended: closes the editor cleanly, builds, reopens it.

    python unreal_compile.py --uproject "C:\\...\\RPG3D.uproject" [--target RPG3DEditor]
                              [--reopen "C:\\...\\RPG3D.uproject"] [--log build.log]

Never force-closes: if Unreal asks to save changes, it stays open (code 3).
A running PIE is never stopped by this tool: nothing is closed (code 5), stop the PIE first.
Exit codes: 0 built · 2 build failed · 3 editor left open · 4 tool not found · 5 PIE running.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

STUDIO = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(STUDIO))
from studio import unreal  # noqa: E402
from studio.config import load_config  # noqa: E402
from studio.paths import default_paths  # noqa: E402


def main() -> int:
    a = argparse.ArgumentParser(description=__doc__)
    a.add_argument("--uproject", required=True)
    a.add_argument("--target", default="")
    a.add_argument("--reopen", "--rouvrir", dest="reopen", default="")
    a.add_argument("--log", default="")
    o = a.parse_args()
    cfg = load_config(default_paths().config_file)
    r = unreal.run_compile(Path(o.uproject), cfg, lambda m: print(m, flush=True), target=o.target,
                        reopen=Path(o.reopen) if o.reopen else None, log=Path(o.log) if o.log else None)
    print(json.dumps(r, ensure_ascii=False, indent=1))
    return int(r["code"])


if __name__ == "__main__":
    sys.exit(main())
