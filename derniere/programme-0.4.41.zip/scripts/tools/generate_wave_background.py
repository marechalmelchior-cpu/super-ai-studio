r"""Generates the studio's static background (studio/ui/static/fond.webp): neon light ribbons in 3D perspective — each
ribbon is made of dozens of thin threads twisting together; they start in the foreground (slightly blurred) and
cross each other as they recede. Design tool only (numpy, scipy, Pillow), never run by the studio.
Usage: python generate_wave_background.py 2560 1440 ..\..\studio\ui\static\fond.webp
"""
import numpy as np, sys
from scipy.ndimage import gaussian_filter
from PIL import Image
W,H=int(sys.argv[1]),int(sys.argv[2]); out=sys.argv[3]
SS=2; w,h=W*SS,H*SS; F=h*.95; VX,VY=w*.5,h*.5
rng=np.random.default_rng(11)
CY=np.array([.20,.92,1.]); BL=np.array([.18,.42,1.]); VI=np.array([.55,.32,1.]); MA=np.array([1.,.22,.70]); GL=np.array([.85,.97,1.])
near=np.zeros((h,w,3)); far=np.zeros((h,w,3)); BATCHES={'proche':[],'loin':[]}
def splat(buf,X,Y,weights,color):
    ok=(X>=0)&(X<w-1)&(Y>=0)&(Y<h-1)&(weights>0)
    X,Y,p,c=X[ok],Y[ok],weights[ok],color[ok]
    x0=np.floor(X).astype(np.int64); y0=np.floor(Y).astype(np.int64); fx=X-x0; fy=Y-y0
    for dx,dy,ww in ((0,0,(1-fx)*(1-fy)),(1,0,fx*(1-fy)),(0,1,(1-fx)*fy),(1,1,fx*fy)):
        idx=(y0+dy)*w+(x0+dx)
        for k in range(3):
            buf[...,k]+=np.bincount(idx,weights=p*ww*c[:,k],minlength=w*h).reshape(h,w)
def ribbon(begin,finish,n,width,ay,fy,ap,fp,ph,tw0,twf,cA,cB,force,M=14000):
    begin=np.array(begin,float); finish=np.array(finish,float)
    s=np.linspace(0,1,M); L=np.linalg.norm(finish-begin); d=(finish-begin)/L
    up=np.array([0,1.,0]); up=up-d*np.dot(up,d); up/=np.linalg.norm(up); pe=np.cross(d,up)
    e=s*s*(3-2*s)*.35+s*.65                                   # slight acceleration: the ribbon stretches into the distance
    center=begin[None]+np.outer(e*L,d)+np.outer(ay*np.sin(fy*e*L+ph),up)+np.outer(ap*np.sin(fp*e*L+ph*1.7),pe)
    tw=tw0+twf*e*L
    for t in np.linspace(-.5,.5,n):
        lar=width*(.75+.25*np.sin(1.3*e*L+t*3+ph))
        P=center+np.outer(t*lar*np.cos(tw),up)+np.outer(t*lar*np.sin(tw),pe)
        z=P[:,2]; okz=z>.4; z=np.maximum(z,.4)
        X=VX+F*P[:,0]/z; Y=VY-F*P[:,1]/z
        seg=np.hypot(np.diff(X,append=X[-1]),np.diff(Y,append=Y[-1]))
        haze=np.exp(-np.maximum(z-2.5,0)/16.)
        edge=.55+.45*(abs(t)*2)**2                           # ribbon edges glow a little more
        p=np.minimum(seg,3.)*haze*edge*force*okz
        color=(cA[None]*(1-(t+.5))+cB[None]*(t+.5))
        color=color*np.ones((M,1))
        nz=z<3.2                                              # foreground: rendered blurred (depth of field)
        BATCHES['proche'].append((X[nz],Y[nz],p[nz],color[nz])); BATCHES['loin'].append((X[~nz],Y[~nz],p[~nz],color[~nz]))
#      start (x,y,z)          end (x,y,z)        threads width ay   fy   ap   fp   ph   twist    colors        strength
ribbon((-3.4,-1.6,1.5),  (24.,3.5,24.),       70, 1.0,   .7, .20, .5, .13, .2, 0., .20,   CY,BL,        .32)
ribbon((-2.8,-.4,1.8),   (22.,6.,27.),        60, .8,    .6, .24,.45, .17, 2.1, 1.2,-.17,  MA,VI,        .30)
ribbon((-3.8,-2.4,1.7),  (25.,1.,22.),        44, .55,   .45, .32, .4, .22, 4.0, 2.,  .26,   VI,MA,        .24)
ribbon((-2.2,-1.0,2.4),  (21.,5.,25.),        20, .3,    .3, .5, .25, .3, 5.2, .5,  .35,   GL,CY,        .18)
for name,buf in (('proche',near),('loin',far)):
    X=np.concatenate([l[0] for l in BATCHES[name]]); Y=np.concatenate([l[1] for l in BATCHES[name]])
    P=np.concatenate([l[2] for l in BATCHES[name]]); C=np.concatenate([l[3] for l in BATCHES[name]])
    splat(buf,X,Y,P,C)
def tone(b): return 1-np.exp(-b)
near=gaussian_filter(near,(2.5*SS,2.5*SS,0)); 
total=near+far
img=total*1.0+gaussian_filter(total,(3*SS,3*SS,0))*1.6+gaussian_filter(total,(18*SS,18*SS,0))*2.2
yy,xx=np.mgrid[0:h,0:w].astype(float); u=(xx-w*.5)/h; v=(yy-h*.5)/h
background=np.array([.008,.012,.03])+np.exp(-((u-.25)**2*2.5+(v+.05)**2*6))[...,None]*np.array([.03,.035,.09])
col=background+tone(img*1.3)*.95
# subtle glowing dust
for _ in range(90):
    px,py=rng.uniform(0,w),rng.uniform(0,h); r=rng.uniform(.6,2.2)*SS; c=[CY,MA,VI,GL][rng.integers(4)]
    x0,x1,y0,y1=int(max(px-8*r,0)),int(min(px+8*r,w)),int(max(py-8*r,0)),int(min(py+8*r,h))
    col[y0:y1,x0:x1]+=c*(np.exp(-((xx[y0:y1,x0:x1]-px)**2+(yy[y0:y1,x0:x1]-py)**2)/(r*r))*rng.uniform(.08,.35))[...,None]
img=Image.fromarray((np.clip(col,0,1)*255).astype(np.uint8)).resize((W,H),Image.LANCZOS)
a=np.asarray(img).astype(float)/255; U=(np.mgrid[0:H,0:W][1]-.5*W)/H; V=(np.mgrid[0:H,0:W][0]-.5*H)/H
a*=np.clip(1-.42*(U**2*.55+V**2*1.5),0,1)[...,None]; a+=rng.normal(0,.004,a.shape[:2])[...,None]
img=Image.fromarray((np.clip(a,0,1)*255).astype(np.uint8))
img.save(out, quality=90, method=6) if out.endswith(".webp") else img.save(out)
