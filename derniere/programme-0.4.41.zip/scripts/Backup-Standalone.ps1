﻿# Backup-Standalone.ps1 — copie CHIFFRÉE (DPAPI) de ~/.agentmemory/standalone.json.
# À lancer après la fermeture de CHAQUE ancien client AgentMemory (fenêtre Codex/Claude) lors de la mise en service :
# chaque client réécrit ce fichier en entier à sa fermeture, la copie conserve chaque état successif.
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Security
$Racine = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
$src = Join-Path $env:USERPROFILE '.agentmemory\standalone.json'
if (-not (Test-Path $src)) { Write-Output 'standalone.json absent.'; exit 0 }
$bytes = [System.IO.File]::ReadAllBytes($src)
$sha = ([System.BitConverter]::ToString([System.Security.Cryptography.SHA256]::Create().ComputeHash($bytes))).Replace('-', '').ToLowerInvariant()
$dir = Join-Path $Racine 'Sauvegardes\Configs\standalone'
New-Item -ItemType Directory -Force -Path $dir | Out-Null
if (Get-ChildItem $dir -Filter "*-$($sha.Substring(0,12)).dpapi" -ErrorAction SilentlyContinue) { Write-Output "État déjà sauvegardé ($($sha.Substring(0,12)))."; exit 0 }
$magic = [System.Text.Encoding]::ASCII.GetBytes("STUDIO-DPAPI-BACKUP-V1`0")
$enc = [System.Security.Cryptography.ProtectedData]::Protect($bytes, $null, 'CurrentUser')
$out = Join-Path $dir ("standalone-{0}-{1}.dpapi" -f (Get-Date -Format 'yyyyMMdd-HHmmss'), $sha.Substring(0,12))
$fs = [System.IO.File]::Open($out, 'CreateNew'); $fs.Write($magic, 0, $magic.Length); $fs.Write($enc, 0, $enc.Length); $fs.Close()
Write-Output "Sauvegardé : $out (empreinte claire $($sha.Substring(0,12))…)"
