# Demande groupée de mise en service

> **Document historique** : mise en service faite le 22/10 (voir `JOURNAL.md`). Les chiffres ci-dessous (ex. 8 skills) datent de ce jour-là.

> **Validée par Mel le 2026-10-22 (« fais le »).** Tout s'exécute en une commande, dans PowerShell :
> ```powershell
> cd C:\Users\Mel\Documents\AI-Workspace\Studio ; powershell -ExecutionPolicy Bypass -File .\scripts\Setup-Studio.ps1
> ```
> Le script enchaîne A → B → fermeture de Codex/Claude Code (Claude Desktop reste ouvert) → C → D → E1/E4, s'arrête au premier échec
> et journalise tout dans `Taches\mise-en-service-<date>.log`. Ensuite : rouvrir Codex et Claude Code, puis `.\scripts\Run-Integration-Tests.ps1`.
> Déjà appliqué depuis la session Claude : `~/.codex/AGENTS.md` (était vide) et les 8 skills `~/.codex/skills/studio-*`.

Préparée le 2026-10-22. **Rien de ce qui suit n'a été exécuté.** Chaque bloc est indépendant ; tu peux tout valider, en partie ou rien.
Ordre recommandé : A → B → C → D → E. Toutes les commandes se lancent depuis `C:\Users\Mel\Documents\AI-Workspace\Studio`.

---

## A. Vérifications préalables — lecture seule, sans risque (recommandé tout de suite)

| # | Commande | Ce que ça fait |
|---|---|---|
| A1 | `.\scripts\Test-DPAPI-Backups.ps1` | Déchiffre **en mémoire** les 2 sauvegardes DPAPI connues et compare leurs empreintes aux rapports. Aucune copie en clair. |
| A2 | `.\scripts\Test-Environment.ps1` | Relève versions et capacités : Python, Node, Git, Claude Code, Codex (PATH et app), AgentMemory global + moteur iii, port 3111, déclarations MCP « agentmemory » (noms seulement, sans valeurs), Blender, Unreal (`Build.version`). Écrit `Taches\environnement-<date>.json`. Ne lance aucun client MCP. |

Pourquoi : je n'ai pas pu exécuter de commande Windows (mon accès passe par un environnement Linux qui ne voit que les dossiers connectés). DPAPI, versions de Claude Code/Codex, présence d'UE 5.8 et de Blender restent donc **non vérifiés**. Après A2, je pourrai ajuster la suite (notamment C2).

---

## B. Installation — accord requis

| # | Quoi | Détail |
|---|---|---|
| B1 | Environnement Python isolé du studio | `.\scripts\Install-Dependencies.ps1 -Confirmer` : crée `Studio\.venv` (rien d'installé globalement) et installe `requirements.lock.txt` — LangGraph 1.2.16, langgraph-checkpoint-sqlite 3.1.2, pytest 9.1.1 et leurs dépendances figées (46 paquets). Lance ensuite la suite de tests hors serveur sous Windows. Python ≥ 3.11 requis (tomllib) (testé en 3.13 sous Linux ; à confirmer sous Windows par E2). Téléchargement depuis PyPI. |

Aucune installation n'est nécessaire pour AgentMemory dans ce plan : le serveur **0.9.22 déjà installé globalement** (et qui a fonctionné le 2026-05-26) est réutilisé.
Option ultérieure, non demandée ici : passer serveur + clients en 0.9.30 (`npm i -g @agentmemory/agentmemory@0.9.30`) pour le filtre `project` natif et `--data-dir`.

---

## C. Changements de configuration — après sauvegarde automatique, Codex et Claude Code fermés

Script : `.\scripts\Apply-Configs.ps1` (refuse si Codex ou Claude Code tournent ; régénère la proposition depuis la config du moment, affiche le diff, demande « OUI » à chaque étape).
Retour arrière : `.\scripts\Restore-Configs.ps1`.

**C1 — Codex `~/.codex/config.toml`** (diff exact préparé dans `Studio\configs-preparees\codex.config.toml.diff`) :
```diff
 [mcp_servers.agentmemory]
 command = "npx"
-args = [
-    "-y",
-    "@agentmemory/mcp",
-]
+args = ["-y", "@agentmemory/mcp@0.9.22"]

 [mcp_servers.agentmemory.env]
 AGENTMEMORY_URL = "http://localhost:3111"
 AGENTMEMORY_TOOLS = "all"
+AGENTMEMORY_FORCE_PROXY = "1"
```
Effets : client de même version que le serveur ; **plus aucun repli silencieux** vers une mémoire locale divergente — si le serveur est arrêté, les outils mémoire échouent visiblement. Aucune autre ligne ne change.

**C2 — Claude Code** : même entrée pour le serveur MCP `agentmemory` en portée utilisateur, via les commandes officielles
`claude mcp remove agentmemory -s user` puis `claude mcp add agentmemory -s user -e AGENTMEMORY_URL=http://localhost:3111 -e AGENTMEMORY_FORCE_PROXY=1 -- npx -y "@agentmemory/mcp@0.9.22"`.
`~/.claude.json` est d'abord sauvegardé **chiffré** (DPAPI) dans `Sauvegardes\Configs\`.
Relevé A2 : le plugin agentmemory de Claude déclare **aussi** le serveur (`~/.claude/plugins/agentmemory/.mcp.json`, non modifié). Pour que ce client-là ne bascule pas non plus en silence, le script définit les variables d'environnement utilisateur `AGENTMEMORY_FORCE_PROXY=1` et `AGENTMEMORY_URL=http://localhost:3111` (valeurs précédentes sauvegardées, restaurées par `Restore-Configs.ps1`). Deux clients par session Claude subsistent (même serveur, pas de divergence) : garder l'un des deux est une décision ultérieure.

**C3 — Points d'entrée des instructions communes**
- `~/.codex/AGENTS.md` (actuellement vide) ← `Studio\adapters\AGENTS.global.propose.md` (copie générée des règles communes).
- `~/.claude/CLAUDE.md` ← ajout en fin de fichier de `Studio\adapters\CLAUDE.global.ajout-propose.md` (2 imports `@…`). Le contenu existant est conservé.

**C4 — Skills communs** : `.\scripts\Sync-Skills.ps1` (aperçu) puis `-Confirmer` → 8 skills copiés en `~/.claude/skills/studio-*` et `~/.codex/skills/studio-*`. N'écrase aucun skill existant non géré par le studio.

---

## D. Premier démarrage — accord requis

1. **Anciens clients encore ouverts** (créés par Codex en mode de secours) : ils ne sont pas fermés par le studio. Quand tu décides de fermer une fenêtre Codex/Claude, lance juste après `.\scripts\Backup-Standalone.ps1` : chaque client réécrit `~/.agentmemory/standalone.json` en entier à sa fermeture, ce script en garde chaque état (chiffré). Le client 38624 a été exporté le 22/10 (1 souvenir, identique à la sauvegarde) ; les autres n'ont pas pu être exportés et le restent signalés.
2. **Serveur central** : `.\scripts\Start-Memory.ps1 -Confirmer` — un seul serveur AgentMemory 0.9.22, en arrière-plan, **sans démarrage automatique ni service Windows**, ports 3111 (API) et 3112 liés à 127.0.0.1 dans la config livrée, 3113 (visionneuse) local par défaut ; le port interne 49134 sera contrôlé par E1 (`netstat`) juste après le démarrage. Données durables : `Studio\data\agentmemory\data\` (nouveau stockage vide). Arrêt : `.\scripts\Stop-Memory.ps1` (n'arrête que ce serveur).
3. Rouvrir Claude Code et Codex : leurs clients se connectent au serveur commun.

Les anciens stockages (`standalone.json`, `Downloads\Studio\data`, mémoires natives Claude/Codex) **ne sont pas importés**. Leur examen et une reprise sélective seront une tâche séparée, à valider.

---

## E. Tests prévus après démarrage

| # | Commande | Démontre |
|---|---|---|
| E1 | `.\.venv\Scripts\python -m studio etat` | mémoire OK + connexions réelles (Claude Code, Codex, Blender, Unreal) |
| E2 | `.\.venv\Scripts\python -m pytest -q tests` | suite hors serveur sous Windows + aller-retour DPAPI |
| E3 | `.\scripts\Run-Integration-Tests.ps1` | 1) Claude Code → Codex et inverse (outils MCP natifs) + chemin cadré ; 2) deux projets séparés, général partagé ; 3) survie à un arrêt/redémarrage du serveur ; 5) panne visible ; 6) parcours complet avec Claude Code réel sur le projet de test. Chaque étape demande confirmation. |
| E4 | `python -m studio sauvegarder` puis `test-restore` | 8) restauration dans un emplacement de test sous Windows (DPAPI) |
| E5 | Interface : `.\scripts\Start-Interface.ps1` | parcours depuis l'interface, approbation, correction, annulation |

Coûts : E3 consomme quelques appels courts de Claude Code et Codex sur tes abonnements (≈ 7 appels + 1 tâche complète). Ta config Codex utilise `service_tier = "priority"`, qui peut consommer davantage. Aucun accès API payant n'est utilisé par le studio (pas de clé API injectée).

---

## F. Retour arrière complet

1. `.\scripts\Stop-Memory.ps1`
2. `.\scripts\Restore-Configs.ps1` (Codex puis Claude ; l'état courant est conservé avant restauration)
3. Retirer les dossiers `studio-*` des skills, vider `~/.codex/AGENTS.md`, retirer les 2 lignes d'import de `~/.claude/CLAUDE.md`
4. `Studio\.venv` peut être supprimé à la main ; aucune donnée existante n'a été modifiée.

---

## G. Hors de cette demande (à décider plus tard)

- ~~RPG3D : autoriser l'isolation par `git worktree`~~ — **autorisé par Mel le 2026-10-22** (ADR-0011).
- Passage d'AgentMemory en 0.9.30.
- Accès automatique de ChatGPT au studio (connexion séparée, à démontrer).
- Examen/migration sélective des anciennes mémoires.
- Mise sous Git d'AI-Workspace (aucun push sans accord).
