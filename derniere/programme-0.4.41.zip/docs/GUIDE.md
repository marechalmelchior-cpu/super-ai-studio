# AI-Workspace — Studio IA de Mel

Guide court. Détails techniques : `Studio/README.md`. Mise en service : `Studio/docs/MISE-EN-SERVICE.md`. Suivi du chantier : `JOURNAL.md`.

## Organisation
| Dossier | Contenu |
|---|---|
| `Regles/` | priorités, instructions communes, conventions, sécurité |
| `Skills/` | procédures réutilisables (source unique Claude Code + Codex) |
| `Projets/` | registre des projets (pointent vers leurs vrais dossiers) |
| `Sujets/` | sujets sans dépôt |
| `Studio/Decisions/` | décisions (ADR) : proposées puis validées par Mel |
| `Studio/` | orchestrateur LangGraph, connecteurs, rôles, interface, tests, scripts |
| `Taches/` | une tâche = un dossier : résultat, diff, preuves, exports ChatGPT |
| `Sauvegardes/` | sauvegardes et procédure de restauration |

## Super Max Pro IA Station (l'interface)
Double-clic sur le raccourci **Super Max Pro IA Station** du bureau (créé une fois par `Studio\scripts\Create-Shortcut.ps1`).
Fenêtres : **Demande** (conversation avec le Superviseur, qui répond ou propose de confier un travail à un projet) ·
**Projets** (avancement, validation) · **Gestion** (skills, mémoire, équipe et modèles, outils, sauvegardes, documents, usage). Local uniquement (127.0.0.1), clé de session à chaque ouverture, s'arrête seule ~1 min après la
fermeture de la fenêtre (jamais pendant une tâche) ou avec « Fermer le studio ». Journal : `Studio\data\logs\interface.log`.

## Utiliser en ligne de commande
Depuis `AI-Workspace\Studio` :
```powershell
.\studio.cmd organisation      # équipe, projets et sujets, tâches en cours
.\studio.cmd etat              # mémoire et connexions
.\studio.cmd tache "Décris le travail" --cible studio-demo --lancer
.\studio.cmd suivre <tâche>
.\studio.cmd approuver <tâche> --empreinte <empreinte affichée>
.\studio.cmd corriger <tâche> "ce qu'il faut changer"
.\studio.cmd annuler <tâche>
```
Parcours d'une tâche : demande → projet/sujet → contexte → plan → exécution (espace isolé) → vérifications → audit
(correction automatique jusqu'à 2 fois) → résultat présenté → **ton approbation**. Une modification après approbation l'invalide.

## Ajouter un projet ou un sujet
Interface (bloc « Ajouter ») ou `.\studio.cmd project-add <id> "<Nom>" --path_value "C:\..."` / `topic-add`. Aucun code à modifier.

## ChatGPT
`.\studio.cmd chatgpt-export <tâche>` → joindre le fichier dans ChatGPT → enregistrer sa réponse → `.\studio.cmd chatgpt-import <tâche> <file>` (proposition à valider).

## Sauvegarder / restaurer
`.\studio.cmd backup` · `verifier-sauvegarde <archive>` · `restaurer-test <archive> <dossier-vide>`. Voir `Sauvegardes/RESTAURATION.md`.
