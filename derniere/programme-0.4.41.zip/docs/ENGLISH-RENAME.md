# Renommage anglais — migration de schéma 1

Le code, les clés, les états, les routes et les fichiers techniques utilisent les nouveaux noms anglais.
Les textes français, les identifiants saisis par l'utilisateur et les dossiers visibles (`Taches`, `Projets`,
`Sujets`, `Regles`, `Sauvegardes`, `copy-de-work`) restent stables.

## Ouverture et sauvegarde

`studio.migrations.migrate(root)` est appelé avant les lectures du lanceur et de `Studio`, et avant l'ouverture
SQL directe du store. Fermer les autres instances avant l'installation du correctif. Au premier démarrage,
la migration sauvegarde les données et les petites pièces techniques, vérifie leurs empreintes, puis convertit.
La sauvegarde se trouve dans `Sauvegardes/migrations/<horodatage>-english-rename/`.
`data/english-rename-version.json` et la table `schema_migrations` portent la version 1.
Une erreur de sauvegarde ou de conversion arrête l'ouverture en écriture avec un message explicite.
Une conversion interrompue dispose d'un journal de reprise et restaure d'abord son instantané.

SQLite est copié avec l'API `backup` qui intègre le WAL ; la conversion des tables, colonnes, états et JSON
est transactionnelle et contrôlée par `integrity_check`. JSON et TOML sont remplacés atomiquement.
Les commentaires, l'ordre et les chaînes multilignes TOML sont conservés. Une syntaxe complexe qui ne peut
être convertie sans perte provoque un arrêt après sauvegarde, sans démarrage sur des données partielles.
Les champs d'extension inconnus restent opaques. Les journaux et les contenus de résultat restent intacts.

## Transition d'une version

`studio/migrations/names.py` conserve les alias. `compatibility.py` lit les anciennes clés, les états et les
fichiers restaurés ; les écritures visent les nouveaux noms. Les chemins d'API historiques sont résolus à
l'entrée. `checkpoints.py` adapte les canaux et les écritures en attente des points de reprise à la lecture.
Les commandes, chemins de configuration, champs et identifiants natifs des outils externes gardent leur
orthographe imposée ; les symboles et les clés de configuration internes des deux CLI sont neutres.

Les bases partagées `memoire-alternative.db` et `memoire-etat.db` déjà présentes gardent temporairement leur
nom, car un serveur MCP indépendant peut encore les utiliser. Une nouvelle installation crée les noms anglais.
Le connecteur refuse deux fichiers concurrents et ne crée pas silencieusement une mémoire vide.

`modeles/catalogue.json` et `modeles/benchmarks.json` restent strictement inchangés pour les consommateurs
anciens. Le studio lit ces formats et le schéma anglais local dans `templates/`. Les URL publiées ne changent pas.
Une publication ultérieure du schéma anglais doit utiliser un nouveau point d'accès, avec une période de
lecture des deux schémas ; elle ne fait pas partie de ce correctif.

## Retour arrière, studio fermé

Depuis `Studio/`, avant de retirer le code du correctif :

```powershell
$backup = Get-ChildItem -LiteralPath '..\Sauvegardes\migrations' -Directory -Filter '*-english-rename' | Sort-Object Name -Descending | Select-Object -First 1
if (-not $backup) { throw 'Sauvegarde de migration absente.' }
& '.\.venv\Scripts\python.exe' -m studio.migrations.rollback_english_rename --root (Resolve-Path '..').Path --backup $backup.FullName
if ($LASTEXITCODE -ne 0) { throw 'Restauration non confirmée : ne pas rouvrir le studio.' }
git apply --check -R '..\Propositions\codex-full-english-rename\fix.diff'
if ($LASTEXITCODE -ne 0) { throw 'Le code a changé : conserver les modifications et rétablir manuellement la version précédente.' }
git apply -R '..\Propositions\codex-full-english-rename\fix.diff'
```

Le script vérifie toute la sauvegarde avant de restaurer les fichiers. Il retire uniquement les nouveaux
fichiers recensés par cette migration. La sauvegarde reste disponible. Cette restauration remet l'état
au moment de la migration : les travaux ultérieurs doivent être sauvegardés séparément avant le retour arrière.
La commande `git apply -R` ne doit être utilisée qu'après un contrôle réussi, avec le même diff et sans
écraser de modifications plus récentes. Rouvrir le studio seulement quand données et code sont revenus ensemble.

## Fusion Git et interface

Après une fusion réussie, le studio retire le worktree de la tâche si son contenu correspond au commit.
Une simple différence CRLF/LF ne bloque plus. Les fichiers modifiés, non suivis ou ignorés sont conservés ;
un message demande de sauvegarder ou commiter les changements avant de réessayer dans Gestion › Branches.
Le bouton de suppression d'une branche fusionnée tente d'abord ce retrait et conserve le résultat de tâche.
Les sélecteurs des réglages projet et agent partagent la palette du studio ; case et libellé restent sur une ligne.
