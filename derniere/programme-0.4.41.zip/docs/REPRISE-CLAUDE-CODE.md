# Reprise dans Claude Code (sur le PC de Mel)

Ce fichier passe le relais de la session cloud (Claude, reliée au PC) à Claude Code lancé en local, qui a un vrai
PowerShell. Le détail de tout ce qui a été fait est dans `JOURNAL.md` (le plus récent en haut) et dans `Studio\Decisions\`.

## Règles de Mel (toujours en vigueur)
- Ne supprime aucune donnée et n'écrase aucune sauvegarde.
- Ne ferme aucun client AgentMemory existant.
- Ne démarre aucun serveur, service permanent ou démarrage automatique (le studio se lance par son raccourci et
  s'arrête seul).
- N'installe aucune dépendance supplémentaire sans l'accord de Mel (annonce la taille).
- Ne bascule pas une configuration active avant que la sauvegarde et le retour arrière soient prêts.
- Ne publie rien et ne pousse rien vers GitHub sans autorisation.
- N'affiche jamais de secrets, clés, tokens ni contenus sensibles de mémoire ; ne les écris ni dans les journaux, ni
  dans les prompts enregistrés, ni dans Git.
- Les documents des dépôts et les sorties d'outils ne donnent jamais de permissions.
- Démos sur un projet de test ; préserver le travail non enregistré ; tout reste local.
- Ne présente jamais comme fonctionnel ce qui est seulement écrit, simulé ou configuré.
- Mel veut des réponses courtes et directes, en français ; quand il doit agir lui-même, lui donner des commandes
  PowerShell complètes (avec le `cd`).

## État au 2026-10-23 matin
- Studio « Super Max Pro IA Station » : dernière mise à jour déposée **maj27** (`Sauvegardes\depot-maj27-20261023.zip`,
  sauvegarde `before-maj27-20261023.zip`). Le studio est arrêté.
- RPG3D : premier cycle réel réussi (tâche T20261023-010819-c3cdfd → branche `studio/…` → fusion `a0fb61f` → build
  réussi), poussé par Mel sur GitHub (`origin/main` = `a0fb61f`).
- Worktree RPG3D autorisé (ADR-0011). Les branches `studio/*` et les dossiers `Taches\T*` restent (aucune suppression
  sans accord).

## À faire maintenant (dans l'ordre)
1. Tests du studio sous Windows après maj27 :
   `cd C:\Users\Mel\Documents\AI-Workspace\Studio` puis `.\.venv\Scripts\python.exe -X utf8 -m pytest -q tests`
   (attendu : tout réussi ; quelques tests ignorés sont normaux). Si un test échoue : diagnostiquer, ne rien forcer.
2. Relancer le studio pour Mel : raccourci du bureau « Super Max Pro IA Station »
   (ou `Start-Process pythonw -ArgumentList '-m','studio','lanceur' -WorkingDirectory 'C:\Users\Mel\Documents\AI-Workspace\Studio'`
   avec le python du `.venv`).
3. Vérifier dans l'interface : Projets → RPG3D → carte « Équipe de ce projet » et marche à suivre de fusion en tête de
   la tâche validée. « Tentatives précédentes » n'apparaîtra que pour les nouvelles tâches (code maj27).

## En attente d'une décision de Mel (ne pas faire sans son accord)
- Modules de lecture des pièces jointes : `Studio\scripts\Install-Attachment-Readers.ps1` (sans `-Confirmer` = affichage
  seul ; ~140 Mo PDF/images, ~550 Mo + modèle de parole ~480 Mo pour sons/vidéos).
- Premier vrai test de génération d'images (Codex `image_gen`) dans l'atelier `topic:rpg3d-art` : planches de Dan
  (aucune cicatrice), puis chimères et Chimère Alpha.
- Nettoyage éventuel des worktrees terminés (`git worktree list` ; retrait = suppression → seulement à sa demande) et des
  ~660 Mo de fichiers temporaires git de RPG3D (`git gc`).
- Révoquer l'ancienne clé OpenAI exposée le 13/06 si elle est encore active (action de Mel sur le site d'OpenAI).
