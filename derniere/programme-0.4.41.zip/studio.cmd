@echo off
rem Point d entree du studio pour Mel, Claude Code et Codex : studio.cmd <commande> ...
set "PYTHONPATH=%~dp0"
set "PYTHONUTF8=1"
set "PY=%~dp0.venv\Scripts\python.exe"
if not exist "%PY%" set "PY=python"
"%PY%" -m studio %*
