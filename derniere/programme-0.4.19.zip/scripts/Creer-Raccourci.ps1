﻿# Creer-Raccourci.ps1 — crée (ou renomme) le raccourci « Super AI Agent Pro Station Max 2000 » sur le bureau.
# Un double-clic ouvre le studio dans sa propre fenêtre : locale (127.0.0.1), session protégée,
# arrêt automatique quand la fenêtre est fermée et qu'aucune tâche ne tourne. Aucun service, aucun démarrage automatique.
# L'ancien raccourci « Super Max Pro IA Station » qui lance ce studio est renommé (pas supprimé) ; un raccourci du même
# nom qui pointerait ailleurs n'est jamais modifié.
$ErrorActionPreference = 'Stop'
$Nom = 'Super AI Agent Pro Station Max 2000'
$Studio = Split-Path -Parent $PSScriptRoot
$pyw = Join-Path $Studio '.venv\Scripts\pythonw.exe'
$ico = Join-Path $Studio 'studio\ui\static\logo-boom-2000.ico'   # nouveau nom : Windows ne garde pas l'ancienne image en cache
if (-not (Test-Path $pyw)) { throw "pythonw introuvable : $pyw (lancer d'abord scripts\Installer-Dependances.ps1)" }
$desktop = [Environment]::GetFolderPath('Desktop')
$lnk = Join-Path $desktop "$Nom.lnk"
$ancien = Join-Path $desktop 'Super Max Pro IA Station.lnk'
$sh = New-Object -ComObject WScript.Shell
if (Test-Path $lnk) {
    $old = $sh.CreateShortcut($lnk)
    if ($old.TargetPath -ne $pyw) { throw "Un autre raccourci « $Nom » existe déjà sur le bureau ($($old.TargetPath)) : rien n'est modifié." }
} elseif (Test-Path $ancien) {
    $old = $sh.CreateShortcut($ancien)
    if ($old.TargetPath -eq $pyw) {
        Rename-Item -LiteralPath $ancien -NewName "$Nom.lnk"
        Write-Host "Ancien raccourci renommé : $Nom"
    } else {
        Write-Host "Un raccourci « Super Max Pro IA Station » pointe ailleurs ($($old.TargetPath)) : il est laissé tel quel."
    }
}
$s = $sh.CreateShortcut($lnk)
$s.TargetPath = $pyw
$s.Arguments = '-m studio lanceur'
$s.WorkingDirectory = $Studio
if (Test-Path $ico) { $s.IconLocation = "$ico,0" }
$s.Description = "$Nom - studio IA local protégé (127.0.0.1)"
$s.Save()
# Le bureau garde parfois l'ancienne image en cache : on lui demande de se rafraîchir (sans rien supprimer).
try { & ie4uinit.exe -show 2>$null } catch { }
Write-Host "Raccourci prêt : $lnk"
Write-Host "Double-clique dessus pour ouvrir le studio. Bouton « Fermer » en haut à droite pour l'arrêter."
