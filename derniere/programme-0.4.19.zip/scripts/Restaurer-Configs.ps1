﻿# Restaurer-Configs.ps1 — retour arrière des configurations (l'état courant est conservé avant restauration).
$ErrorActionPreference = 'Stop'
$Studio = Split-Path -Parent $PSScriptRoot
$py = Join-Path $Studio '.venv\Scripts\python.exe'
if (-not (Test-Path $py)) { $py = 'python' }
Push-Location $Studio
try {
  & $py -m studio config-restaurer
  $last = Get-ChildItem '..\Sauvegardes\Configs\claude.json-*.dpapi' -ErrorAction SilentlyContinue | Sort-Object Name | Select-Object -Last 1
  if ($last -and (Read-Host "Restaurer ~/.claude.json depuis $($last.Name) ? Taper OUI") -eq 'OUI') {
    & $py -c "import sys,datetime as d;from pathlib import Path;from studio.backup import protect,unprotect;s=Path.home()/'.claude.json';k=Path('..')/'Sauvegardes'/'Configs'/('avant-restauration-claude.json-'+d.datetime.utcnow().strftime('%Y%m%dT%H%M%SZ')+'.dpapi');k.open('xb').write(protect(s.read_bytes()));s.write_bytes(unprotect(Path(sys.argv[1]).read_bytes()));print('restauré')" $last.FullName
  }
  $envFile = Get-ChildItem '..\Sauvegardes\Configs\env-utilisateur-*.json' -ErrorAction SilentlyContinue | Sort-Object Name | Select-Object -First 1
  if ($envFile) {
    $prev = Get-Content $envFile.FullName -Raw | ConvertFrom-Json
    foreach ($n in 'AGENTMEMORY_FORCE_PROXY', 'AGENTMEMORY_URL') { [Environment]::SetEnvironmentVariable($n, $prev.$n, 'User') }
    Write-Output "Variables utilisateur remises à leur état d'avant la mise en service ($($envFile.Name))."
  }
} finally { Pop-Location }
