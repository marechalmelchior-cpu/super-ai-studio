r"""Génère le fond fixe du studio (studio/ui/static/fond.webp) : rubans de lumière néon en perspective 3D — chaque
ruban est fait de dizaines de fils fins qui se tordent ensemble ; ils partent du premier plan (légèrement flou) et
s'entrecroisent en filant au loin. Outil de conception seulement (numpy, scipy, Pillow), jamais lancé par le studio.
Usage : python generer_fond_ondes.py 2560 1440 ..\..\studio\ui\static\fond.webp
"""
import numpy as np, sys
from scipy.ndimage import gaussian_filter
from PIL import Image
W,H=int(sys.argv[1]),int(sys.argv[2]); out=sys.argv[3]
SS=2; w,h=W*SS,H*SS; F=h*.95; VX,VY=w*.5,h*.5
rng=np.random.default_rng(11)
CY=np.array([.20,.92,1.]); BL=np.array([.18,.42,1.]); VI=np.array([.55,.32,1.]); MA=np.array([1.,.22,.70]); GL=np.array([.85,.97,1.])
proche=np.zeros((h,w,3)); loin=np.zeros((h,w,3)); LOTS={'proche':[],'loin':[]}
def splat(buf,X,Y,poids,coul):
    ok=(X>=0)&(X<w-1)&(Y>=0)&(Y<h-1)&(poids>0)
    X,Y,p,c=X[ok],Y[ok],poids[ok],coul[ok]
    x0=np.floor(X).astype(np.int64); y0=np.floor(Y).astype(np.int64); fx=X-x0; fy=Y-y0
    for dx,dy,ww in ((0,0,(1-fx)*(1-fy)),(1,0,fx*(1-fy)),(0,1,(1-fx)*fy),(1,1,fx*fy)):
        idx=(y0+dy)*w+(x0+dx)
        for k in range(3):
            buf[...,k]+=np.bincount(idx,weights=p*ww*c[:,k],minlength=w*h).reshape(h,w)
def ruban(debut,fin,n,largeur,ay,fy,ap,fp,ph,tw0,twf,cA,cB,force,M=14000):
    debut=np.array(debut,float); fin=np.array(fin,float)
    s=np.linspace(0,1,M); L=np.linalg.norm(fin-debut); d=(fin-debut)/L
    up=np.array([0,1.,0]); up=up-d*np.dot(up,d); up/=np.linalg.norm(up); pe=np.cross(d,up)
    e=s*s*(3-2*s)*.35+s*.65                                   # légère accélération : le ruban s'étire au loin
    centre=debut[None]+np.outer(e*L,d)+np.outer(ay*np.sin(fy*e*L+ph),up)+np.outer(ap*np.sin(fp*e*L+ph*1.7),pe)
    tw=tw0+twf*e*L
    for t in np.linspace(-.5,.5,n):
        lar=largeur*(.75+.25*np.sin(1.3*e*L+t*3+ph))
        P=centre+np.outer(t*lar*np.cos(tw),up)+np.outer(t*lar*np.sin(tw),pe)
        z=P[:,2]; okz=z>.4; z=np.maximum(z,.4)
        X=VX+F*P[:,0]/z; Y=VY-F*P[:,1]/z
        seg=np.hypot(np.diff(X,append=X[-1]),np.diff(Y,append=Y[-1]))
        brume=np.exp(-np.maximum(z-2.5,0)/16.)
        bord=.55+.45*(abs(t)*2)**2                           # les bords du ruban brillent un peu plus
        p=np.minimum(seg,3.)*brume*bord*force*okz
        coul=(cA[None]*(1-(t+.5))+cB[None]*(t+.5))
        coul=coul*np.ones((M,1))
        nz=z<3.2                                              # premier plan : rendu flou (profondeur de champ)
        LOTS['proche'].append((X[nz],Y[nz],p[nz],coul[nz])); LOTS['loin'].append((X[~nz],Y[~nz],p[~nz],coul[~nz]))
#      début (x,y,z)          fin (x,y,z)        fils largeur  ay   fy   ap   fp   ph   torsion  couleurs      force
ruban((-3.4,-1.6,1.5),  (24.,3.5,24.),       70, 1.0,   .7, .20, .5, .13, .2, 0., .20,   CY,BL,        .32)
ruban((-2.8,-.4,1.8),   (22.,6.,27.),        60, .8,    .6, .24,.45, .17, 2.1, 1.2,-.17,  MA,VI,        .30)
ruban((-3.8,-2.4,1.7),  (25.,1.,22.),        44, .55,   .45, .32, .4, .22, 4.0, 2.,  .26,   VI,MA,        .24)
ruban((-2.2,-1.0,2.4),  (21.,5.,25.),        20, .3,    .3, .5, .25, .3, 5.2, .5,  .35,   GL,CY,        .18)
for nom,buf in (('proche',proche),('loin',loin)):
    X=np.concatenate([l[0] for l in LOTS[nom]]); Y=np.concatenate([l[1] for l in LOTS[nom]])
    P=np.concatenate([l[2] for l in LOTS[nom]]); C=np.concatenate([l[3] for l in LOTS[nom]])
    splat(buf,X,Y,P,C)
def ton(b): return 1-np.exp(-b)
proche=gaussian_filter(proche,(2.5*SS,2.5*SS,0)); 
somme=proche+loin
img=somme*1.0+gaussian_filter(somme,(3*SS,3*SS,0))*1.6+gaussian_filter(somme,(18*SS,18*SS,0))*2.2
yy,xx=np.mgrid[0:h,0:w].astype(float); u=(xx-w*.5)/h; v=(yy-h*.5)/h
fond=np.array([.008,.012,.03])+np.exp(-((u-.25)**2*2.5+(v+.05)**2*6))[...,None]*np.array([.03,.035,.09])
col=fond+ton(img*1.3)*.95
# poussière lumineuse discrète
for _ in range(90):
    px,py=rng.uniform(0,w),rng.uniform(0,h); r=rng.uniform(.6,2.2)*SS; c=[CY,MA,VI,GL][rng.integers(4)]
    x0,x1,y0,y1=int(max(px-8*r,0)),int(min(px+8*r,w)),int(max(py-8*r,0)),int(min(py+8*r,h))
    col[y0:y1,x0:x1]+=c*(np.exp(-((xx[y0:y1,x0:x1]-px)**2+(yy[y0:y1,x0:x1]-py)**2)/(r*r))*rng.uniform(.08,.35))[...,None]
img=Image.fromarray((np.clip(col,0,1)*255).astype(np.uint8)).resize((W,H),Image.LANCZOS)
a=np.asarray(img).astype(float)/255; U=(np.mgrid[0:H,0:W][1]-.5*W)/H; V=(np.mgrid[0:H,0:W][0]-.5*H)/H
a*=np.clip(1-.42*(U**2*.55+V**2*1.5),0,1)[...,None]; a+=rng.normal(0,.004,a.shape[:2])[...,None]
img=Image.fromarray((np.clip(a,0,1)*255).astype(np.uint8))
img.save(out, quality=90, method=6) if out.endswith(".webp") else img.save(out)
