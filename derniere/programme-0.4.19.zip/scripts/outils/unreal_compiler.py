"""Compiler un projet Unreal sans intervention : ferme l'éditeur proprement, compile, le rouvre.

    python unreal_compiler.py --uproject "C:\\...\\RPG3D.uproject" [--cible RPG3DEditor]
                              [--rouvrir "C:\\...\\RPG3D.uproject"] [--journal build.log]

Jamais de fermeture forcée : si Unreal demande d'enregistrer des modifications, il reste ouvert (code 3).
Un PIE en cours n'est jamais arrêté par cet outil : rien n'est fermé (code 5), arrêter le PIE d'abord.
Codes de sortie : 0 compilé · 2 compilation en échec · 3 éditeur resté ouvert · 4 outil introuvable · 5 PIE en cours.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

STUDIO = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(STUDIO))
from studio import unreal  # noqa: E402
from studio.config import load_config  # noqa: E402
from studio.paths import default_paths  # noqa: E402


def main() -> int:
    a = argparse.ArgumentParser(description=__doc__)
    a.add_argument("--uproject", required=True)
    a.add_argument("--cible", default="")
    a.add_argument("--rouvrir", default="")
    a.add_argument("--journal", default="")
    o = a.parse_args()
    cfg = load_config(default_paths().config_file)
    r = unreal.compiler(Path(o.uproject), cfg, lambda m: print(m, flush=True), cible=o.cible,
                        rouvrir=Path(o.rouvrir) if o.rouvrir else None, journal=Path(o.journal) if o.journal else None)
    print(json.dumps(r, ensure_ascii=False, indent=1))
    return int(r["code"])


if __name__ == "__main__":
    sys.exit(main())
