﻿# Demarrer-Memoire.ps1 — démarre UN serveur AgentMemory central (pas de démarrage automatique, pas de service Windows).
# Données durables : dossier de travail fixe (AgentMemory 0.9.22 stocke dans .\data relatif au dossier courant).
param([switch]$Confirmer, [string]$Donnees = '', [string]$Version = '0.9.22', [switch]$ReconstruireIndex)
$ErrorActionPreference = 'Stop'
$Racine = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
if (-not $Donnees) { $Donnees = Join-Path $Racine 'Studio\data\agentmemory' }
$admin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if ($admin) { Write-Output 'Refusé : ne pas démarrer la mémoire depuis un PowerShell administrateur (le serveur deviendrait impossible à arrêter sans droits admin).'; exit 1 }
if (-not $Confirmer) { Write-Output "Ajouter -Confirmer pour démarrer. Dossier de données prévu : $Donnees"; exit 1 }
if (Get-NetTCPConnection -LocalPort 3111 -State Listen -ErrorAction SilentlyContinue) {
  Write-Output 'Un serveur écoute déjà sur 3111 : rien n''est démarré (vérifier qu''il s''agit bien du serveur attendu).'; exit 0 }
New-Item -ItemType Directory -Force -Path $Donnees, "$Donnees\logs" | Out-Null
# Modèle d'embedding figé sur celui de ~/.agentmemory/.env : une variable d'environnement différente dans le terminal
# ne doit pas changer le modèle d'un démarrage à l'autre (cause de l'index incompatible du 22/10 : 2048 vs 384 dimensions).
$envFile = Join-Path $env:USERPROFILE '.agentmemory\.env'
$prov = if (Test-Path $envFile) { (Select-String -Path $envFile -Pattern '^EMBEDDING_PROVIDER=(.+)$' | Select-Object -First 1).Matches.Groups[1].Value } else { '' }
if ($prov) { $env:EMBEDDING_PROVIDER = $prov.Trim().Trim('"'); Write-Output "Modèle d'embedding figé : $($env:EMBEDDING_PROVIDER)" }
if ($ReconstruireIndex) {
  $env:AGENTMEMORY_DROP_STALE_INDEX = 'true'
  Write-Output 'Index de recherche incompatible ignoré et reconstruit (les souvenirs eux-mêmes sont conservés).' }
# Lanceur : installation globale si présente, sinon la version épinglée via npx (téléchargée une fois dans le cache npm).
$cli = Join-Path $env:APPDATA 'npm\agentmemory.cmd'
if (-not (Test-Path $cli)) { $c = Get-Command agentmemory -ErrorAction SilentlyContinue | Where-Object { $_.Source -match '\.(cmd|exe)$' } | Select-Object -First 1; $cli = $(if ($c) { $c.Source }) }
if ($cli) { $file = $cli; $argsList = @(); $mode = "installé ($cli)" }
else { $file = (Get-Command npx.cmd).Source; $argsList = @('-y', "@agentmemory/agentmemory@$Version"); $mode = "npx @agentmemory/agentmemory@$Version" }
Write-Output "Lanceur : $mode"
$sp = @{ FilePath = $file; WorkingDirectory = $Donnees; WindowStyle = 'Hidden'; PassThru = $true
         RedirectStandardOutput = "$Donnees\logs\serveur.out.log"; RedirectStandardError = "$Donnees\logs\serveur.err.log" }
if ($argsList.Count) { $sp.ArgumentList = $argsList }
$p = Start-Process @sp
Remove-Item Env:AGENTMEMORY_DROP_STALE_INDEX -ErrorAction SilentlyContinue   # reconstruction : pour ce démarrage seulement
[ordered]@{ pid = $p.Id; demarre = (Get-Date).ToString('o'); donnees = $Donnees; lanceur = $mode } | ConvertTo-Json |
  Set-Content (Join-Path $Donnees 'serveur-studio.json') -Encoding UTF8
for ($i = 0; $i -lt 60; $i++) {
  Start-Sleep -Seconds 2
  try {
    Invoke-WebRequest 'http://127.0.0.1:3111/agentmemory/livez' -UseBasicParsing -TimeoutSec 2 | Out-Null
    $h = try { Invoke-RestMethod 'http://127.0.0.1:3111/agentmemory/health' -TimeoutSec 5 } catch { $null }
    $v = $(if ($h) { $h.version } else { '?' })
    if (Test-Path "$Donnees\data") { Write-Output "AgentMemory $v prêt (PID $($p.Id)). Données : $Donnees\data" }
    else { Write-Output "AgentMemory $v prêt (PID $($p.Id)) MAIS dossier $Donnees\data absent : emplacement des données à vérifier avant usage." }
    exit 0
  } catch {}
  if ($p.HasExited) { Write-Output "Arrêt immédiat (code $($p.ExitCode)). Voir $Donnees\logs\serveur.err.log"; exit 1 }
}
Write-Output "Lancé (PID $($p.Id)) mais pas encore prêt après 2 min : voir $Donnees\logs\"; exit 1
