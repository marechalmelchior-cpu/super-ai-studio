﻿# Verifier-Sauvegardes-DPAPI.ps1 — LECTURE SEULE.
# Vérifie que les sauvegardes AgentMemory chiffrées (DPAPI) restent lisibles par ce compte Windows,
# sans écrire aucune copie en clair. Compare les empreintes à celles des rapports du 21-22 octobre.
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Security
Add-Type -AssemblyName System.IO.Compression
$base = Join-Path $env:USERPROFILE 'Documents\Codex\2026-10-21\referenced-chatgpt-conversation-this-is-an\outputs'
$cibles = @(
  @{ fichier = "$base\AgentMemory-preparation-20261021T165849Z\Sauvegarde-AgentMemory.dpapi"
     sha_chiffre = '110de40ff9550c4fc8958d24eec9079c05bb13b693f67596ef890bc054539529'; sha_clair = $null },
  @{ fichier = "$base\AgentMemory-diagnostic-20261022T093026Z\Export-client-38624.dpapi"
     sha_chiffre = '7107c997f7e9beba1fd87b2087c86448dc19beb5ee4251358c3aa97d939ac63a'
     sha_clair = 'e73b020abd239079b460188399fd9254572a1f48705ff006956ec888bd0c9d32' }
)
$magic = [System.Text.Encoding]::ASCII.GetBytes("AGENTMEMORY-DPAPI-BACKUP-V1`0")
$sha = [System.Security.Cryptography.SHA256]::Create()
function Hex($b) { ([System.BitConverter]::ToString($b)).Replace('-', '').ToLowerInvariant() }
$rapport = @()
foreach ($c in $cibles) {
  $r = [ordered]@{ fichier = Split-Path $c.fichier -Leaf; present = Test-Path $c.fichier }
  if ($r.present) {
    $bytes = [System.IO.File]::ReadAllBytes($c.fichier)
    $r.empreinte_chiffree_ok = ((Hex $sha.ComputeHash($bytes)) -eq $c.sha_chiffre)
    try {
      for ($i = 0; $i -lt $magic.Length; $i++) { if ($bytes[$i] -ne $magic[$i]) { throw 'format' } }
      $payload = New-Object byte[] ($bytes.Length - $magic.Length)
      [Array]::Copy($bytes, $magic.Length, $payload, 0, $payload.Length)
      $plain = [System.Security.Cryptography.ProtectedData]::Unprotect($payload, $null, 'CurrentUser')
      $r.dechiffrement = 'OK (en mémoire uniquement)'
      $r.octets_clairs = $plain.Length
      $empreintes = @(Hex $sha.ComputeHash($plain))
      try {
        $zip = [System.IO.Compression.ZipArchive]::new((New-Object System.IO.MemoryStream(,$plain)), 'Read', $false)
        $r.entrees_zip = $zip.Entries.Count
        foreach ($e in $zip.Entries) { $st = $e.Open(); try { $empreintes += Hex $sha.ComputeHash($st) } finally { $st.Dispose() } }
        $zip.Dispose()
      } catch { $r.entrees_zip = 'non zip (export JSON)' }
      # L'empreinte du rapport porte sur l'export contenu dans l'archive, pas sur l'archive entière.
      if ($c.sha_clair) { $r.empreinte_export_ok = ($empreintes -contains $c.sha_clair) }
      [Array]::Clear($plain, 0, $plain.Length)
    } catch { $r.dechiffrement = 'ECHEC (compte Windows différent, format inconnu ou fichier altéré)' }
  }
  $rapport += $r
}
$rapport | ConvertTo-Json -Depth 4
# Contrôle complet de l'archive principale par le vérificateur d'origine (empreinte de chaque fichier, sans extraction).
$verif = Join-Path $base 'AgentMemory-preparation-20261021T165849Z\Verifier-Sauvegarde.ps1'
if (Test-Path $verif) { Write-Output ('Vérificateur d''origine : ' + ((& $verif) | Out-String).Trim()) }
