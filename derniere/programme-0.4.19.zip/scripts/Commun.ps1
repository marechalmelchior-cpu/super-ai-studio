﻿# Commun.ps1 — fonctions partagées (chargé par les autres scripts).

function Get-ClientsAOuvrir {
    # Codex (app ou CLI) et Claude Code (CLI). L'application Claude Desktop n'est PAS concernée :
    # elle relie la session de Claude au PC et ne lance pas les clients AgentMemory de Claude Code.
    $codex = @(Get-Process -Name codex -ErrorAction SilentlyContinue)
    # L'application de bureau qui relance codex.exe (app-server) compte aussi : on remonte au processus parent.
    $codex += @(Get-CimInstance Win32_Process -Filter "Name='codex.exe'" -ErrorAction SilentlyContinue | ForEach-Object {
        Get-Process -Id $_.ParentProcessId -ErrorAction SilentlyContinue } |
        Where-Object { $_.Name -notmatch '^(codex|powershell|pwsh|cmd|explorer|WindowsTerminal|OpenConsole|conhost|claude)$' })
    $cc = @(Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object {
        ($_.Name -eq 'claude.exe' -and $_.ExecutablePath -and $_.ExecutablePath -notmatch 'AnthropicClaude|\\Programs\\Claude\\|WindowsApps') -or
        ($_.Name -eq 'node.exe' -and $_.CommandLine -match '@anthropic-ai[\\/]claude-code') })
    $res = @()
    if ($codex.Count) { $res += "Codex ($($codex.Count) processus)" }
    if ($cc.Count) { $res += "Claude Code ($($cc.Count) processus)" }
    return $res
}

function Get-StudioPython {
    $studio = Split-Path -Parent $PSScriptRoot
    $venv = Join-Path $studio '.venv\Scripts\python.exe'
    if (Test-Path $venv) { return $venv }
    return $null
}

function Find-BasePython {
    # Python >= 3.11 (tomllib) pour créer l'environnement du studio.
    $candidats = @()
    if (Get-Command py -ErrorAction SilentlyContinue) { foreach ($v in '3.13', '3.12', '3.11', '3') { $candidats += ,@('py', "-$v") } }
    if (Get-Command python -ErrorAction SilentlyContinue) { $candidats += ,@('python') }
    foreach ($c in $candidats) {
        $exe = $c[0]; $pre = @($c | Select-Object -Skip 1)
        try { $ok = & $exe @pre -c "import sys;print(sys.version_info>=(3,11))" 2>$null } catch { $ok = $null }
        if ("$ok".Trim() -eq 'True') { return ,$c }
    }
    return $null
}
