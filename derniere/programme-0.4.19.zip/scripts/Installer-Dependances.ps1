﻿# Installer-Dependances.ps1 — crée Studio\.venv et installe les versions figées (accord requis : -Confirmer).
param([switch]$Confirmer)
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'Commun.ps1')
$Studio = Split-Path -Parent $PSScriptRoot
if (-not $Confirmer) { Get-Content (Join-Path $Studio 'requirements.lock.txt'); Write-Output 'Ajouter -Confirmer pour installer.'; exit 1 }
$venv = Join-Path $Studio '.venv'
if (-not (Test-Path $venv)) {
  $base = Find-BasePython
  if (-not $base) { throw 'Python 3.11 ou plus introuvable (py ou python). Installer Python 3.12/3.13 puis relancer.' }
  $exe = $base[0]; $pre = @($base | Select-Object -Skip 1)
  & $exe @pre -m venv $venv
  if ($LASTEXITCODE) { throw 'Création de l''environnement Python impossible.' }
}
& "$venv\Scripts\python.exe" -m pip install --disable-pip-version-check -r (Join-Path $Studio 'requirements.lock.txt')
if ($LASTEXITCODE) { throw 'Installation des dépendances en échec.' }
Push-Location $Studio
try { & "$venv\Scripts\python.exe" -X utf8 -m pytest -q tests; if ($LASTEXITCODE) { throw 'Tests hors serveur en échec sous Windows.' } }
finally { Pop-Location }
