﻿# Lancer-Interface.ps1 — ouvre l'interface locale (http://127.0.0.1:8765), au premier plan. Ctrl+C pour arrêter.
$Studio = Split-Path -Parent $PSScriptRoot
$py = Join-Path $Studio '.venv\Scripts\python.exe'
if (-not (Test-Path $py)) { $py = 'python' }
Push-Location $Studio
try { Start-Process 'http://127.0.0.1:8765'; & $py -m studio interface } finally { Pop-Location }
