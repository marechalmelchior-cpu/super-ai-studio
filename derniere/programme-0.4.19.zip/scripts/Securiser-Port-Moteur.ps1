﻿# Securiser-Port-Moteur.ps1 — le moteur iii d'AgentMemory 0.9.22 écoute sur 0.0.0.0:49134 (non configurable dans
# cette version). Ce script bloque les connexions ENTRANTES depuis le réseau sur ce port. Les connexions locales
# (127.0.0.1, utilisées par AgentMemory lui-même) ne passent pas par le pare-feu et continuent de fonctionner.
# Sans -Confirmer : lecture seule (état des règles). Avec -Confirmer : à lancer dans un PowerShell ADMINISTRATEUR.
# Retour arrière : Remove-NetFirewallRule -DisplayName 'Studio IA - bloquer moteur AgentMemory 49134 entrant'
param([switch]$Confirmer)
$ErrorActionPreference = 'Stop'
$nom = 'Studio IA - bloquer moteur AgentMemory 49134 entrant'
$ecoute = Get-NetTCPConnection -LocalPort 49134 -State Listen -ErrorAction SilentlyContinue | Select-Object LocalAddress, OwningProcess
Write-Output ('Écoute 49134 : ' + (($ecoute | ForEach-Object { "$($_.LocalAddress) (PID $($_.OwningProcess))" }) -join ', '))
$regles = @(Get-NetFirewallPortFilter -Protocol TCP -ErrorAction SilentlyContinue | Where-Object { $_.LocalPort -eq '49134' } | Get-NetFirewallRule)
$iii = (Get-Command iii -ErrorAction SilentlyContinue).Source
if ($iii) { $regles += @(Get-NetFirewallApplicationFilter -Program $iii -ErrorAction SilentlyContinue | Get-NetFirewallRule) }
if ($regles.Count) { $regles | Select-Object DisplayName, Direction, Action, Enabled, Profile | Format-Table | Out-String | Write-Output }
else { Write-Output 'Aucune règle de pare-feu spécifique au port 49134 ou à iii.exe.' }
if (-not $Confirmer) { Write-Output 'Lecture seule. Ajouter -Confirmer (PowerShell administrateur) pour créer la règle de blocage.'; exit 0 }
$admin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $admin) { throw 'Relancer ce script dans un PowerShell ouvert « en tant qu''administrateur ».' }
if (Get-NetFirewallRule -DisplayName $nom -ErrorAction SilentlyContinue) { Write-Output 'Règle déjà présente.'; exit 0 }
New-NetFirewallRule -DisplayName $nom -Direction Inbound -Protocol TCP -LocalPort 49134 -Action Block -Profile Any | Out-Null
Write-Output "Règle créée : $nom (les règles de blocage priment sur les autorisations)."
