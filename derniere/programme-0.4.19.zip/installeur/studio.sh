#!/bin/sh
# Point d entrée du studio sur Mac et Linux : sh installeur/studio.sh <commande> … (sans argument : ouvre le studio)
ICI="$(cd "$(dirname "$0")/.." && pwd)"
export PYTHONPATH="$ICI" PYTHONUTF8=1
PY="$ICI/.venv/bin/python"
[ -x "$PY" ] || PY="python3"
[ $# -eq 0 ] && set -- lanceur
exec "$PY" -m studio "$@"
