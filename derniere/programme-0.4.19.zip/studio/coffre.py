"""Clés API chiffrées sur ce PC, quelle que soit la plateforme.

- Windows : DPAPI (lié au compte Windows) ;
- Mac et Linux : chiffrement avec une clé locale propre au compte (fichier lisible par toi seul, rangé hors du
  dossier du studio, donc jamais dans ses sauvegardes) — flux SHA-256 en mode compteur + sceau HMAC, bibliothèque standard.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import os
import secrets
import sys
from pathlib import Path


def _dossier_cle() -> Path:
    if os.environ.get("STUDIO_COFFRE"):
        return Path(os.environ["STUDIO_COFFRE"])
    if sys.platform == "darwin":
        return Path.home() / "Library" / "Application Support" / "super-ai-studio"
    return Path(os.environ.get("XDG_CONFIG_HOME") or Path.home() / ".config") / "super-ai-studio"


def _cle_locale() -> bytes:
    f = _dossier_cle() / "cle"
    try:
        k = f.read_bytes()
        if len(k) == 32:
            return k
    except OSError:
        pass
    f.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    k = secrets.token_bytes(32)
    fd = os.open(f, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)          # jamais écrasée : une clé perdue rendrait les clés illisibles
    with os.fdopen(fd, "wb") as h:
        h.write(k)
    return k


def _flux(k: bytes, nonce: bytes, n: int) -> bytes:
    out, i = b"", 0
    while len(out) < n:
        out += hashlib.sha256(k + nonce + i.to_bytes(8, "big")).digest()
        i += 1
    return out[:n]


def chiffrer(texte: str) -> str:
    if sys.platform == "win32":
        from .backup import protect
        return "dpapi:" + base64.b64encode(protect(texte.encode())).decode()
    k, nonce, brut = _cle_locale(), secrets.token_bytes(16), texte.encode()
    c = bytes(a ^ b for a, b in zip(brut, _flux(k, nonce, len(brut))))
    sceau = hmac.new(k, nonce + c, hashlib.sha256).digest()[:16]
    return "local1:" + base64.b64encode(nonce + sceau + c).decode()


def dechiffrer(v: str) -> str:
    if not v:
        return ""
    genre, _, b = v.partition(":")
    raw = base64.b64decode(b)
    if genre == "dpapi":
        from .backup import unprotect
        return unprotect(raw).decode()
    if genre == "local1":
        k = _cle_locale()
        nonce, sceau, c = raw[:16], raw[16:32], raw[32:]
        if not hmac.compare_digest(sceau, hmac.new(k, nonce + c, hashlib.sha256).digest()[:16]):
            raise ValueError("Clé illisible sur ce compte : reconnecte cette IA.")
        return bytes(a ^ b for a, b in zip(c, _flux(k, nonce, len(c)))).decode()
    return raw.decode()                                 # ancien format local (avant 0.4.17)
