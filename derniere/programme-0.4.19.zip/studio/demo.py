"""Scénarios SIMULÉS de démonstration (projet de test et sujet sans dépôt).

La première tentative contient volontairement un défaut pour démontrer que
l'audit le signale et provoque une correction.
"""
from __future__ import annotations

from pathlib import Path

from .connectors.base import Mission
from .connectors.simulation import SimulatedExecutor


def _code_try1(m: Mission, work: Path) -> str:
    (work / "calc.py").write_text(
        '"""Projet de TEST du studio."""\n\n\ndef moyenne(valeurs):\n'
        "    if not valeurs:\n        return 0\n    return sum(valeurs) / len(valeurs)\n", encoding="utf-8")
    return "calc.py : liste vide gérée en renvoyant 0."


def _code_try2(m: Mission, work: Path) -> str:
    (work / "calc.py").write_text(
        '"""Projet de TEST du studio."""\n\n\ndef moyenne(valeurs):\n'
        "    if not valeurs:\n        raise ValueError(\"moyenne() : la liste est vide\")\n"
        "    return sum(valeurs) / len(valeurs)\n", encoding="utf-8")
    return "calc.py : ValueError explicite pour une liste vide (retour d'audit pris en compte)."


def _topic_try1(m: Mission, work: Path) -> str:
    (work / "note.md").write_text("# Note de veille\n\n## Synthèse\nLangGraph assure la reprise via ses points de reprise.\n",
                                  encoding="utf-8")
    return "note.md rédigée."


def _topic_try2(m: Mission, work: Path) -> str:
    (work / "note.md").write_text(
        "# Note de veille\n\n## Synthèse\nLangGraph assure la reprise via ses points de reprise.\n\n"
        "## Sources\n- https://docs.langchain.com/oss/python/langgraph/persistence\n", encoding="utf-8")
    return "note.md complétée avec ses sources."


def demo_executors() -> dict:
    return {"code": SimulatedExecutor({1: _code_try1, 2: _code_try2}),
            "sujet": SimulatedExecutor({1: _topic_try1, 2: _topic_try2})}
