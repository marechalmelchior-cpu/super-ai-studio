"""Audits des skills et des mémoires des agents — boutons de Gestion.

Deux skills globaux de l'utilisateur font le travail (installés dans ~/.agents/skills, lus par Codex) :
- ``audit-skills``  : inventaire des skills (Claude, Codex, projet), usage observé dans les historiques, doublons,
  skills chargés pour rien, global ou local. ``fix`` n'applique que des corrections sûres (métadonnées).
- ``audit-memories`` : relit chaque Markdown destiné aux agents (CLAUDE.md, AGENTS.md, règles, skills, plans) et le
  confronte au code ; verdict GARDER / METTRE À JOUR / FUSIONNER / ARCHIVER / SUPPRIMER / À VÉRIFIER. ``clean`` applique.

Ici : 1) « Auditer » lance une tâche en lecture seule ; le compte rendu est le rapport, la tâche se classe seule.
2) « Appliquer » sur un audit fini lance la correction dans la copie isolée du projet ; en mode autonome elle est
validée et fusionnée seule. Règle du studio, plus forte que les skills : rien n'est supprimé, tout part en archive.
"""
from __future__ import annotations

from datetime import date

SKILL = {"skills": "audit-skills", "memoires": "audit-memories"}
MODE = {"skills": {"audit": "audit", "appliquer": "fix"}, "memoires": {"audit": "audit", "appliquer": "clean"}}
COMMUN = ("Règles du studio, prioritaires sur le skill : n'affiche, ne recopie et ne cite aucun secret, clé, token ni "
          "contenu sensible de mémoire (chemins et noms de fichiers seulement) ; ne lis pas ~/.codex/memories ; ni commit "
          "ni push (le studio s'en charge).")


def genre(demande: str) -> tuple[str, str] | None:
    """« $audit-skills audit … » → ("skills", "audit") ; sinon None."""
    for quoi, nom in SKILL.items():
        for mode, arg in MODE[quoi].items():
            if demande.startswith(f"${nom} {arg}"):
                return quoi, mode
    return None


def methode_du_studio(studio, quoi: str) -> str:
    """Skill global absent (studio installé chez quelqu'un d'autre) : la méthode du socle est jointe à la demande."""
    from pathlib import Path
    nom = SKILL[quoi]
    h = Path.home()
    if any((h / d / nom / "SKILL.md").is_file() for d in (".agents/skills", ".codex/skills", ".claude/skills")):
        return ""
    socle = studio.paths.skills / ("audit-memoires" if quoi == "memoires" else nom) / "SKILL.md"
    try:
        texte = socle.read_text(encoding="utf-8")
    except OSError:
        return ""
    return f"\n\nMéthode à suivre (skill « {nom} » du studio) :\n{texte}"


def demande(studio, cible: str, quoi: str, mode: str, depuis: str = "") -> str:
    if quoi not in SKILL or mode not in MODE[quoi]:
        raise ValueError("Audit inconnu.")
    t = studio.registry.get(cible)
    if t.kind != "project" or not t.path():
        raise ValueError("Un audit se lance sur un projet qui a un dossier.")
    vrai = str(t.path())
    tete = f"${SKILL[quoi]} {MODE[quoi][mode]}" + (f" {vrai}" if quoi == "skills" and mode == "audit" else "")
    tete += methode_du_studio(studio, quoi)
    if mode == "audit":
        quoi_lire = (f"Projet à auditer : {vrai} (lis-le directement, en lecture seule) et les skills globaux "
                     "(~/.claude/skills, ~/.agents/skills, ~/.codex/skills, plugins Claude), avec les historiques "
                     "~/.claude/projects, ~/.claude/history.jsonl et ~/.codex/sessions comme preuves d'usage."
                     if quoi == "skills" else
                     "Projet à auditer : le dossier courant (copie du projet au dernier commit). Lis tous les fichiers "
                     "éligibles du manifeste, pas un échantillon.")
        return (f"{tete}\n\nL'utilisateur a lancé explicitement cet audit depuis Gestion. MODE AUDIT : lecture seule, tu n'écris, "
                f"ne déplaces et ne supprimes aucun fichier, nulle part. {quoi_lire}\n{COMMUN}\n\n"
                "Ton compte rendu final EST le rapport, en français : d'abord 5 lignes (ce qui va, ce qui coûte ou "
                "trompe les agents, gain attendu), puis une ligne par élément avec verdict et preuve, puis les "
                "corrections classées en « sûres, appliquées par le bouton Appliquer » et « à décider par l'utilisateur ».")
    if not depuis:
        raise ValueError("Appliquer : indique l'audit de départ.")
    a = studio.store.get(depuis)
    if genre(a["request"] or "") != (quoi, "audit") or a["target"] != cible:
        raise ValueError("Cette tâche n'est pas un audit de ce type sur ce projet.")
    if a["status"] not in ("approuvee", "appliquee"):
        raise ValueError("L'audit n'est pas fini.")
    rapport = studio.run_dir(depuis) / "RESULTAT.md"
    portee = ("Applique seulement les corrections sûres DANS LE DOSSIER COURANT (skills du projet). Les skills globaux "
              "(~/.claude, ~/.agents, ~/.codex) sont hors de ta copie : n'y écris rien, liste précisément les "
              "changements proposés pour l'utilisateur." if quoi == "skills" else
              "Applique les verdicts dans le dossier courant (copie du projet), fichiers Markdown destinés aux agents "
              "uniquement ; réaudite d'abord si l'arbre a changé depuis le rapport.")
    return (f"{tete}\n\nL'utilisateur a validé l'application depuis Gestion. Rapport d'audit de départ : {rapport} (tâche {depuis}). "
            f"{portee}\nRien n'est supprimé : SUPPRIMER et ARCHIVER = déplacer le fichier dans le dossier d'archives du "
            f"projet s'il existe, sinon dans Archives/audit-{date.today():%Y%m%d}/ en gardant son chemin ; FUSIONNER = "
            "reporter le savoir unique dans le fichier de référence, réparer les liens, puis archiver la source. "
            f"Ce qui est À VÉRIFIER ne bouge pas.\n{COMMUN}\n\n"
            "Compte rendu en français : modifiés / archivés / laissés et pourquoi / bloqués.")


def lancer(studio, cible: str, quoi: str, mode: str, depuis: str = "") -> str:
    titre = ("Audit des " if mode == "audit" else "Appliquer l'audit des ") + ("skills" if quoi == "skills" else "mémoires")
    return studio.create(cible, demande(studio, cible, quoi, mode, depuis), role="entretien", executeur="codex", titre=titre)


def derniers(studio) -> list[dict]:
    """Par projet : dernier audit et dernière application de chaque type (pour « il y a N jours »)."""
    vus: dict[str, dict] = {}
    for t in studio.store.list(limit=2000):
        g = genre(t.get("request") or "")
        if not g:
            continue
        cle = f"{g[0]}_{g[1]}"
        d = vus.setdefault(t["target"], {})
        if cle not in d:                              # liste triée du plus récent au plus ancien
            d[cle] = {"tid": t["id"], "date": t["created_at"], "statut": t["status"]}
    return [{"cible": f"{p.kind}:{p.id}", "nom": p.nom, **vus.get(f"{p.kind}:{p.id}", {})}
            for p in studio.registry.all() if p.kind == "project" and p.chemin]
