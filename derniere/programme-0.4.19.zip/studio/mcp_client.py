"""Client MCP du studio : les serveurs MCP des Extensions servent aussi aux agents par clé API ou locaux (Ollama…).

Claude Code et Codex lancent eux-mêmes leurs serveurs (le studio leur passe la liste de la tâche). Pour les autres
modèles, c'est ce client qui parle aux serveurs et présente leurs outils au modèle (« mcp__serveur__outil »).

Performance :
- la liste des outils de chaque serveur est gardée dans data/mcp-outils.json (selon sa configuration) : une tâche
  ne démarre aucun serveur pour savoir ce qu'il propose ;
- un serveur ne démarre qu'au premier appel d'un de ses outils, reste ouvert pendant la tâche, puis est fermé ;
- descriptions coupées, nombre d'outils plafonné : la mission reste légère pour les petits modèles locaux.

Sécurité : seuls les serveurs installés par l'utilisateur (data/mcp.json) et actifs pour le projet ; les clés viennent
de data/mcp-secrets.json (chiffrées), jamais écrites ailleurs ; ce que renvoie un serveur est une donnée, pas un ordre.
"""
from __future__ import annotations

import hashlib
import json
import os
import queue
import re
import shutil
import subprocess
import sys
import threading
import urllib.request
from pathlib import Path

PROTOCOLE = "2025-06-18"
MAX_OUTILS = 60
MAX_DESC = 300
MAX_RESULTAT = 20_000
_VAR = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)\}")


def _etendre(v, env: dict):
    if isinstance(v, str):
        return _VAR.sub(lambda m: env.get(m.group(1), ""), v)
    if isinstance(v, list):
        return [_etendre(x, env) for x in v]
    if isinstance(v, dict):
        return {k: _etendre(x, env) for k, x in v.items()}
    return v


def nom_outil(serveur: str, outil: str) -> str:
    """Nom accepté par tous les fournisseurs (lettres, chiffres, _ et -, 64 au plus)."""
    n = re.sub(r"[^A-Za-z0-9_-]", "_", f"mcp__{serveur}__{outil}")
    return n if len(n) <= 64 else n[:55] + "_" + hashlib.sha1(n.encode()).hexdigest()[:8]


def empreinte(conf: dict) -> str:
    return hashlib.sha256(json.dumps(conf, sort_keys=True).encode()).hexdigest()[:16]


class ServeurMcp:
    """Un serveur MCP : local (stdio) ou distant (HTTP « streamable »)."""

    def __init__(self, nom: str, conf: dict, env: dict, delai: float = 60):
        self.nom, self.conf, self.delai = nom, conf, delai
        self.env = {**os.environ, **env}
        self.proc = None
        self.file: queue.Queue = queue.Queue()
        self.n = 0
        self.session = ""
        self.verrou = threading.Lock()

    # -- transport
    def _http(self, msg: dict, attendre: bool = True) -> dict | None:
        url = _etendre(self.conf.get("url", ""), self.env)
        if not url.startswith(("https://", "http://127.0.0.1", "http://localhost")):
            raise RuntimeError("adresse refusée (https seulement, ou ce PC)")
        h = {"Content-Type": "application/json", "Accept": "application/json, text/event-stream",
             **{k: v for k, v in _etendre(self.conf.get("headers", {}), self.env).items() if v}}
        if self.session:
            h["Mcp-Session-Id"] = self.session
        req = urllib.request.Request(url, data=json.dumps(msg).encode(), headers=h, method="POST")
        with urllib.request.urlopen(req, timeout=self.delai) as r:
            self.session = r.headers.get("Mcp-Session-Id") or self.session
            corps = r.read().decode("utf-8", "replace")
            if not attendre or not corps.strip():
                return None
            if "text/event-stream" in (r.headers.get("Content-Type") or ""):
                for ligne in corps.splitlines():
                    if ligne.startswith("data:"):
                        d = json.loads(ligne[5:].strip())
                        if d.get("id") == msg.get("id"):
                            return d
                return None
            return json.loads(corps)

    def _lire(self):
        for ligne in self.proc.stdout:
            self.file.put(ligne)
        self.file.put(None)

    def _demarrer(self) -> None:
        cmd = [_etendre(self.conf.get("command", ""), self.env), *[str(x) for x in _etendre(self.conf.get("args", []), self.env)]]
        exe = shutil.which(cmd[0]) or cmd[0]              # npx → npx.cmd sous Windows
        env = {**self.env, **{k: str(v) for k, v in _etendre(self.conf.get("env", {}), self.env).items()}}
        opts = {"creationflags": 0x08000000} if sys.platform == "win32" else {}
        self.proc = subprocess.Popen([exe, *cmd[1:]], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                                     env=env, text=True, encoding="utf-8", errors="replace", bufsize=1, **opts)
        threading.Thread(target=self._lire, daemon=True).start()

    def _envoyer(self, methode: str, params: dict | None = None, notification: bool = False) -> dict | None:
        msg = {"jsonrpc": "2.0", "method": methode, **({"params": params} if params is not None else {})}
        if not notification:
            self.n += 1
            msg["id"] = self.n
        if self.conf.get("url"):
            r = self._http(msg, not notification)
        else:
            self.proc.stdin.write(json.dumps(msg) + "\n")
            self.proc.stdin.flush()
            if notification:
                return None
            r = None
            while True:
                try:
                    ligne = self.file.get(timeout=self.delai)
                except queue.Empty:
                    raise RuntimeError(f"le serveur {self.nom} ne répond pas") from None
                if ligne is None:
                    raise RuntimeError(f"le serveur {self.nom} s'est arrêté")
                try:
                    d = json.loads(ligne)
                except ValueError:
                    continue                                 # journal du serveur sur stdout : ignoré
                if d.get("id") == msg["id"]:
                    r = d
                    break
        if r and r.get("error"):
            raise RuntimeError(str(r["error"].get("message", r["error"]))[:300])
        return (r or {}).get("result")

    # -- protocole
    def ouvrir(self) -> None:
        with self.verrou:
            if self.proc is not None or self.session:
                return
            if not self.conf.get("url"):
                self._demarrer()
            self._envoyer("initialize", {"protocolVersion": PROTOCOLE, "capabilities": {},
                                         "clientInfo": {"name": "super-ai-studio", "version": "1"}})
            self._envoyer("notifications/initialized", notification=True)

    def outils(self) -> list[dict]:
        self.ouvrir()
        out, curseur = [], None
        for _ in range(10):
            r = self._envoyer("tools/list", {"cursor": curseur} if curseur else {}) or {}
            out += r.get("tools", [])
            curseur = r.get("nextCursor")
            if not curseur:
                break
        return out

    def appeler(self, outil: str, args: dict) -> str:
        self.ouvrir()
        r = self._envoyer("tools/call", {"name": outil, "arguments": args or {}}) or {}
        morceaux = []
        for b in r.get("content", []):
            if b.get("type") == "text":
                morceaux.append(b.get("text", ""))
            elif b.get("type") == "resource":
                morceaux.append(str((b.get("resource") or {}).get("text", ""))[:4000])
            else:
                morceaux.append(f"[{b.get('type', 'contenu')} non affichable ici]")
        t = "\n".join(morceaux) or ("(aucun résultat)" if not r.get("isError") else "Erreur sans détail.")
        t = ("ERREUR : " if r.get("isError") else "") + t
        return t[:MAX_RESULTAT] + ("\n… (tronqué)" if len(t) > MAX_RESULTAT else "")

    def fermer(self) -> None:
        p, self.proc = self.proc, None
        if p is not None:
            try:
                p.stdin.close()
                p.terminate()
                p.wait(timeout=5)
            except Exception:                              # noqa: BLE001
                try:
                    p.kill()
                except Exception:                          # noqa: BLE001
                    pass


class BoiteMcp:
    """Serveurs MCP d'une tâche pour un modèle par API : définitions d'outils (cache) et appels (démarrage à la demande)."""

    def __init__(self, data: Path, actifs: list[str] | None = None, demarrer=ServeurMcp):
        from .bibliotheque import env_mcp, mcp_installes
        self.data = Path(data)
        tous = mcp_installes(self.data)
        self.confs = {n: c for n, c in tous.items() if actifs is None or n in actifs}
        self.env = env_mcp(self.data) if self.confs else {}
        self.demarrer = demarrer
        self.ouverts: dict[str, ServeurMcp] = {}
        self.carte: dict[str, tuple[str, str]] = {}
        self.erreurs: list[str] = []

    def _serveur(self, nom: str) -> ServeurMcp:
        if nom not in self.ouverts:
            self.ouverts[nom] = self.demarrer(nom, self.confs[nom], self.env)
        return self.ouverts[nom]

    def _cache(self) -> dict:
        try:
            d = json.loads((self.data / "mcp-outils.json").read_text(encoding="utf-8"))
            return d if isinstance(d, dict) else {}
        except (OSError, ValueError):
            return {}

    def definitions(self) -> list[dict]:
        """Outils au format « function » (OpenAI/Ollama/OpenRouter). Liste lue dans le cache ; un serveur pas encore
        connu est interrogé une fois, puis mémorisé."""
        if not self.confs:
            return []
        cache, change, defs = self._cache(), False, []
        for nom, conf in sorted(self.confs.items()):
            e = empreinte(conf)
            outils = (cache.get(nom) or {}).get("outils") if (cache.get(nom) or {}).get("empreinte") == e else None
            if outils is None:
                try:
                    outils = [{"name": o.get("name", ""), "description": str(o.get("description", ""))[:MAX_DESC],
                               "inputSchema": o.get("inputSchema") or {"type": "object", "properties": {}}}
                              for o in self._serveur(nom).outils() if o.get("name")]
                    cache[nom] = {"empreinte": e, "outils": outils}
                    change = True
                except Exception as ex:                    # noqa: BLE001 — serveur absent : la tâche continue sans lui
                    self.erreurs.append(f"{nom} : {str(ex)[:160]}")
                    continue
            for o in outils:
                n = nom_outil(nom, o["name"])
                self.carte[n] = (nom, o["name"])
                schema = o["inputSchema"] if isinstance(o.get("inputSchema"), dict) else {"type": "object", "properties": {}}
                schema.setdefault("type", "object")
                schema.setdefault("properties", {})
                defs.append({"type": "function", "function": {"name": n, "description": f"[{nom}] {o['description']}",
                                                              "parameters": schema}})
        if change:
            try:
                t = self.data / "mcp-outils.tmp"
                t.write_text(json.dumps(cache, ensure_ascii=False), encoding="utf-8")
                t.replace(self.data / "mcp-outils.json")
            except OSError:
                pass
        return defs[:MAX_OUTILS]

    def connait(self, nom: str) -> bool:
        return nom in self.carte

    def appeler(self, nom: str, args: dict) -> str:
        serveur, outil = self.carte[nom]
        try:
            return self._serveur(serveur).appeler(outil, args)
        except Exception as ex:                            # noqa: BLE001 — l'agent voit l'erreur et s'adapte
            return f"Échec du serveur {serveur} : {str(ex)[:300]}"

    def fermer(self) -> None:
        for s in self.ouverts.values():
            s.fermer()
        self.ouverts.clear()


# ------------------------------------------------------------------ Codex : serveurs passés à la commande
def _toml(v) -> str:
    return json.dumps(v, ensure_ascii=False)              # chaînes et listes JSON = valeurs TOML valides


def options_codex(confs: dict, memoire: dict | None = None) -> tuple[list[str], list[str]]:
    """« -c mcp_servers.<nom>.… » pour une exécution de Codex (rien n'est écrit dans sa configuration).
    Les clés ne sont jamais sur la ligne de commande : seulement le NOM des variables (env_vars, bearer_token_env_var),
    leurs valeurs passent par l'environnement du processus. Renvoie (options, noms des serveurs)."""
    opts, noms = [], []
    tout = {**confs, **({"studio-memoire": memoire} if memoire else {})}
    for nom, c in sorted(tout.items()):
        if not re.fullmatch(r"[A-Za-z0-9_-]{1,40}", nom):
            continue
        base = f"mcp_servers.{nom}"
        if c.get("url"):
            opts += ["-c", f"{base}.url={_toml(c['url'])}"]
            auth = str((c.get("headers") or {}).get("Authorization", ""))
            m = re.fullmatch(r"Bearer \$\{([A-Za-z_][A-Za-z0-9_]*)\}", auth)
            if m:
                opts += ["-c", f"{base}.bearer_token_env_var={_toml(m.group(1))}"]
        elif c.get("command"):
            opts += ["-c", f"{base}.command={_toml(c['command'])}", "-c", f"{base}.args={_toml([str(a) for a in c.get('args', [])])}"]
            env = c.get("env") or {}
            fixes = {k: v for k, v in env.items() if not _VAR.search(str(v))}
            variables = sorted({m for v in env.values() for m in _VAR.findall(str(v))} | {k for k, v in env.items() if _VAR.search(str(v))})
            if fixes:
                opts += ["-c", f"{base}.env={{{', '.join(f'{json.dumps(k)} = {_toml(str(v))}' for k, v in fixes.items())}}}"]
            if variables:
                opts += ["-c", f"{base}.env_vars={_toml(variables)}"]
        else:
            continue
        opts += ["-c", f'{base}.default_tools_approval_mode="approve"', "-c", f"{base}.startup_timeout_sec=60"]
        if nom == "studio-memoire":
            opts += ["-c", f'{base}.enabled_tools=["memoire_chercher", "memoire_conflits", "memoire_etat", "image_creer", "voix_creer"]']
        noms.append(nom)
    return opts, noms


def serveur_memoire() -> dict:
    """Serveur « studio-memoire » (lecture seule pour les agents) : le Python du studio, aucun téléchargement."""
    code = str(Path(__file__).resolve().parents[1])
    return {"command": sys.executable, "args": ["-m", "studio.mcp_server"],
            "env": {"PYTHONPATH": code, "STUDIO_MCP_CLIENT": "agent", "PYTHONUTF8": "1"}}
