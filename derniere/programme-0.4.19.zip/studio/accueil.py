"""Première ouverture : connecter une IA (cloud ou locale), puis GitHub, en quelques clics ; et la visite guidée.

Rien ne s'installe sans un clic de l'utilisateur : chaque installation ouvre une fenêtre visible sur le PC
(Windows : winget ou l'installateur officiel ; Mac et Linux : la commande officielle dans un terminal, ou à copier).
"""
from __future__ import annotations

import json
import re
import shutil
import subprocess
import sys
from pathlib import Path

LIENS = {
    "ollama": "https://ollama.com/download",
    "git": "https://git-scm.com/downloads",
    "claude": "https://claude.com/product/claude-code",
    "codex": "https://developers.openai.com/codex/cli",
    "node": "https://nodejs.org",
}

# Commandes officielles, par plateforme. Windows : winget (fourni avec Windows 10/11) ou script officiel.
_WIN = {
    "ollama": "winget install --id Ollama.Ollama -e",
    "git": "winget install --id Git.Git -e",
    "claude": "powershell -NoProfile -ExecutionPolicy Bypass -Command \"irm https://claude.ai/install.ps1 | iex\"",
    "codex": "winget install --id OpenJS.NodeJS.LTS -e",          # Node.js d'abord ; Codex au clic suivant
}
_MAC = {
    "ollama": "brew install ollama",
    "git": "xcode-select --install",
    "claude": "curl -fsSL https://claude.ai/install.sh | bash",
    "codex": "brew install --cask codex",
}
_LINUX = {
    "ollama": "curl -fsSL https://ollama.com/install.sh | sh",
    "git": "sudo apt install -y git || sudo dnf install -y git",
    "claude": "curl -fsSL https://claude.ai/install.sh | bash",
    "codex": "npm install -g @openai/codex",
}


def plateforme() -> str:
    return "windows" if sys.platform == "win32" else "mac" if sys.platform == "darwin" else "linux"


def commande(outil: str) -> str:
    table = {"windows": _WIN, "mac": _MAC, "linux": _LINUX}[plateforme()]
    if outil == "codex" and plateforme() == "windows" and shutil.which("npm"):
        return "npm install -g @openai/codex"
    if outil == "claude" and plateforme() == "windows" and not shutil.which("git"):
        return "winget install --id Git.Git -e && " + _WIN["claude"]       # Claude Code sous Windows a besoin de Git
    if outil == "codex" and plateforme() == "mac" and not shutil.which("brew") and shutil.which("npm"):
        return "npm install -g @openai/codex"
    return table.get(outil, "")


def _fichier(data: Path) -> Path:
    return Path(data) / "accueil.json"


def lire(data: Path) -> dict:
    try:
        d = json.loads(_fichier(data).read_text(encoding="utf-8"))
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def noter(data: Path, **valeurs) -> dict:
    d = {**lire(data), **{k: bool(v) for k, v in valeurs.items() if k in ("fini", "visite")}}
    _fichier(data).write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")
    return d


def _memoire_go(note: str) -> float | None:
    m = re.search(r"≈\s*(\d+(?:[.,]\d+)?)\s*Go", note or "")
    return float(m.group(1).replace(",", ".")) if m else None


def modeles_conseilles(catalogue: list[dict], ram_go: float | None, vram_go: float | None) -> list[dict]:
    """Modèles locaux du catalogue avec ce qu'ils demandent et s'ils tiennent sur ce PC.
    « rapide » = tient dans la carte graphique ; « possible » = tient dans la mémoire (plus lent) ; sinon trop gros."""
    vus, sortie = set(), []
    for m in sorted((m for m in catalogue if m.get("local") and m.get("categorie") == "global"), key=lambda m: -(m.get("score") or 0)):
        nom = m.get("ollama") or m.get("cle")
        if not nom or nom in vus:
            continue
        vus.add(nom)
        go = _memoire_go(m.get("note", ""))
        if go is None:
            tient = "inconnu"
        elif vram_go and go <= vram_go:
            tient = "rapide"
        elif ram_go and go <= ram_go * 0.75:
            tient = "possible"
        else:
            tient = "trop_gros"
        sortie.append({"nom": nom, "titre": m.get("nom", nom), "score": m.get("score"), "memoire_go": go, "tient": tient,
                       "note": (m.get("note", "").split("—", 1)[1].strip() if "—" in m.get("note", "") else "")})
    rang = {"rapide": 0, "possible": 1, "inconnu": 2, "trop_gros": 3}
    meilleur = min(sortie, key=lambda x: (rang[x["tient"]], -(x["score"] or 0)), default=None)
    for x in sortie:
        x["conseille"] = x is meilleur and x["tient"] in ("rapide", "possible")
    return sortie


def _vram_windows() -> float | None:
    """Mémoire de la carte graphique (toutes marques) lue dans le registre de Windows ; None ailleurs ou si absente."""
    if sys.platform != "win32":
        return None
    try:
        import winreg
        base = r"SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}"
        meilleur = 0
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, base) as k:
            for i in range(32):
                try:
                    with winreg.OpenKey(k, f"{i:04d}") as s:
                        v, _ = winreg.QueryValueEx(s, "HardwareInformation.qwMemorySize")
                        meilleur = max(meilleur, int(v if isinstance(v, int) else int.from_bytes(v, "little")))
                except OSError:
                    continue
        return round(meilleur / 2**30, 1) or None
    except (OSError, ImportError, ValueError):
        return None


def _executer(cmd: list[str], delai: float = 6) -> tuple[int, str]:
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=delai,
                           **({"creationflags": 0x08000000} if sys.platform == "win32" else {}))
        return r.returncode, (r.stdout or "") + (r.stderr or "")
    except (OSError, subprocess.SubprocessError):
        return -1, ""


def github_connecte() -> bool | None:
    """Vrai si un compte GitHub est enregistré (gh ou le gestionnaire d'identifiants de Git). None : impossible à savoir."""
    if shutil.which("gh"):
        return _executer(["gh", "auth", "status"])[0] == 0
    if shutil.which("git"):
        code, sortie = _executer(["git", "credential-manager", "github", "list"])
        if code == 0:
            return bool(sortie.strip())
    return None


def etat(studio, home: Path | None = None) -> dict:
    """Ce que l'écran de bienvenue affiche : IA déjà prêtes, Ollama, Git/GitHub, modèles adaptés au PC."""
    from . import agents, ia, modeles_locaux, systeme
    from .connectors.base import find_exe
    from .connectors.claude_code import WIN_CANDIDATES
    home = home or Path.home()
    data = studio.paths.data
    claude = bool(find_exe(studio.cfg["outils"].get("claude", "claude"), WIN_CANDIDATES))
    codex = bool(find_exe(studio.cfg["outils"].get("codex", "codex")))
    connexions = [c for c in ia.public(data).get("connexions", [])]
    claude_ok = claude and ((home / ".claude" / ".credentials.json").is_file() or sys.platform == "darwin")
    codex_ok = codex and (home / ".codex" / "auth.json").is_file()
    installes = modeles_locaux.installes()
    r = systeme.releve()
    gpu = r.get("gpu") or {}
    ram_go = (r.get("ram") or {}).get("total_go")
    vram = gpu.get("vram_total_go") or _vram_windows()
    if not vram and sys.platform == "darwin" and ram_go:
        import platform
        if platform.machine() == "arm64":
            vram = round(ram_go * 0.66, 1)            # Mac Apple Silicon : mémoire unifiée, les deux tiers pour l'IA
    git = bool(shutil.which("git"))
    pret = bool(connexions) or claude_ok or codex_ok
    d = lire(data)
    return {
        "fini": bool(d.get("fini")), "visite": bool(d.get("visite")), "pret": pret, "plateforme": plateforme(),
        "winget": bool(shutil.which("winget")) if plateforme() == "windows" else False,
        "claude": {"installe": claude, "connecte": claude_ok, "commande": commande("claude")},
        "codex": {"installe": codex, "connecte": codex_ok, "commande": commande("codex")},
        "connexions": [{"fournisseur": c.get("fournisseur"), "nom": c.get("nom"), "modele": c.get("modele")} for c in connexions],
        "ollama": {"installe": bool(modeles_locaux.executable_ollama()), "ouvert": installes is not None,
                   "modeles": installes or [], "commande": commande("ollama"), "lien": LIENS["ollama"]},
        "pc": {"ram_go": ram_go, "vram_go": vram, "gpu": gpu.get("nom", "")},
        "conseilles": modeles_conseilles(agents.benchmarks(data)["modeles"], ram_go, vram),
        "git": {"installe": git, "github": github_connecte() if git else False, "commande": commande("git"), "lien": LIENS["git"]},
    }


def _console(titre: str, cmd: str) -> None:
    """Ouvre une fenêtre visible qui exécute la commande ; l'utilisateur voit tout et peut fermer."""
    if sys.platform == "win32":
        subprocess.Popen(["cmd", "/c", "start", titre, "cmd", "/k", cmd], creationflags=0x00000010)
    elif sys.platform == "darwin":
        script = cmd.replace("\\", "\\\\").replace('"', '\\"')
        subprocess.Popen(["osascript", "-e", f'tell application "Terminal" to do script "{script}"'], start_new_session=True)
    else:
        for t in (["x-terminal-emulator", "-e"], ["gnome-terminal", "--"], ["konsole", "-e"], ["xfce4-terminal", "-x"], ["xterm", "-e"]):
            if shutil.which(t[0]):
                subprocess.Popen([*t, "bash", "-c", cmd + "; exec bash"], start_new_session=True)
                return
        raise ValueError("Aucun terminal trouvé : copie la commande dans un terminal.")


def installer(outil: str) -> dict:
    """Installe un outil sur clic (fenêtre visible). Sans winget ou sans terminal : renvoie la commande et le lien."""
    if outil not in ("ollama", "git", "claude", "codex"):
        raise ValueError("Outil inconnu.")
    cmd = commande(outil)
    noms = {"ollama": "Ollama", "git": "Git", "claude": "Claude Code", "codex": "Codex"}
    if plateforme() == "windows" and cmd.startswith("winget") and not shutil.which("winget"):
        return {"ok": False, "lien": LIENS[outil], "info": f"Installe {noms[outil]} depuis son site, puis reviens ici."}
    if plateforme() == "mac" and cmd.startswith("brew") and not shutil.which("brew"):
        return {"ok": False, "lien": LIENS[outil], "commande": cmd, "info": f"Installe {noms[outil]} depuis son site, puis reviens ici."}
    try:
        _console(f"Installation de {noms[outil]}", cmd)
    except (OSError, ValueError) as e:
        return {"ok": False, "commande": cmd, "lien": LIENS[outil], "info": str(e)}
    if outil == "codex" and "NodeJS" in cmd:
        return {"ok": True, "info": "Codex a besoin de Node.js : une fenêtre l'installe. Ensuite, reclique « Installer » pour Codex."}
    return {"ok": True, "info": f"Une fenêtre d'installation de {noms[outil]} s'est ouverte : suis-la, puis clique « Vérifier »."}


def connecter_github() -> dict:
    """Connexion GitHub dans le navigateur (gh ou le gestionnaire d'identifiants livré avec Git)."""
    if shutil.which("gh"):
        cmd = "gh auth login --web --git-protocol https"
    elif shutil.which("git"):
        cmd = "git credential-manager github login"
    else:
        raise ValueError("Installe d'abord Git.")
    _console("Connexion GitHub", cmd)
    return {"ok": True, "info": "Une fenêtre de connexion GitHub s'est ouverte : suis-la (le navigateur s'ouvre), puis clique « Vérifier »."}
