"""Ce qui change d'un système à l'autre (Windows, Mac, Linux), au même endroit."""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
from pathlib import Path


def ouvrir(chemin: Path | str) -> None:
    """Ouvre un fichier ou un dossier avec l'application du système (Explorateur, Finder, gestionnaire de fichiers)."""
    if sys.platform == "win32":
        os.startfile(str(chemin))  # noqa: S606 — chemins vérifiés par l'appelant
    elif sys.platform == "darwin":
        subprocess.Popen(["open", str(chemin)], start_new_session=True)
    elif shutil.which("xdg-open"):
        subprocess.Popen(["xdg-open", str(chemin)], start_new_session=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    else:
        raise OSError("Aucune application pour ouvrir ce fichier (xdg-open absent).")


def navigateur_app() -> str | None:
    """Navigateur capable d'ouvrir le studio en fenêtre d'application (--app) : Edge, Chrome, Chromium, Brave."""
    if sys.platform == "win32":
        for base in (os.environ.get("ProgramFiles(x86)"), os.environ.get("ProgramFiles"), os.environ.get("LOCALAPPDATA")):
            for rel in ("Microsoft/Edge/Application/msedge.exe", "Google/Chrome/Application/chrome.exe"):
                if base and (Path(base) / rel).is_file():
                    return str(Path(base) / rel)
        return shutil.which("msedge") or shutil.which("chrome")
    if sys.platform == "darwin":
        for app in ("Microsoft Edge", "Google Chrome", "Chromium", "Brave Browser"):
            p = Path("/Applications") / f"{app}.app" / "Contents" / "MacOS" / app
            if p.is_file():
                return str(p)
        return None
    for nom in ("microsoft-edge", "microsoft-edge-stable", "google-chrome", "google-chrome-stable", "chromium", "chromium-browser", "brave-browser"):
        if shutil.which(nom):
            return shutil.which(nom)
    return None


def completer_path() -> None:
    """Mac et Linux : lancé depuis le Finder ou le menu, le studio n'hérite pas toujours du PATH du terminal.
    Ajoute les dossiers où s'installent Claude Code, Codex, Node, Ollama, Homebrew (sans rien retirer)."""
    if sys.platform == "win32":
        return
    home = Path.home()
    en_plus = [home / ".local/bin", home / ".npm-global/bin", home / ".claude/local", Path("/opt/homebrew/bin"),
               Path("/usr/local/bin"), home / ".volta/bin", home / ".bun/bin"]
    actuel = os.environ.get("PATH", "").split(os.pathsep)
    ajout = [str(p) for p in en_plus if p.is_dir() and str(p) not in actuel]
    if ajout:
        os.environ["PATH"] = os.pathsep.join(actuel + ajout)
