"""Onglet « Fichiers » d'un projet : tout ce que les agents ont créé (images, planches, textes, autres), où que ce soit.

Source : les fichiers relevés par le studio à la fin de chaque tâche (table ``artifacts``) et les images de
``Taches/<tâche>/captures``. Chaque fichier est cherché dans la copie de travail de sa tâche (pas encore fusionnée),
sinon dans le dossier du projet (fusionné). Lecture seule : rien n'est déplacé ni supprimé.
"""
from __future__ import annotations

from pathlib import Path, PurePosixPath

IMAGES = {".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".webp": "image/webp", ".gif": "image/gif"}
TEXTES = {".md", ".txt", ".csv", ".html", ".pdf", ".docx", ".json"}
BRUIT = (".patch", ".log", ".pyc", ".tmp")
MAX_IMAGE, MAX_TEXTE = 40_000_000, 2_000_000


def genre(chemin: str) -> str:
    s = PurePosixPath(chemin).suffix.lower()
    if s in IMAGES:
        return "image"
    if s in TEXTES and not (s == ".json" and "/" in chemin):     # relevés JSON des agents (captures/…) : « autre »
        return "texte"
    return "autre"


def _sous(base: Path, rel: str) -> Path | None:
    """base/rel seulement s'il reste dans base (aucun ../, aucun chemin absolu)."""
    if not rel or rel.startswith(("/", "\\")) or ":" in rel or ".." in PurePosixPath(rel.replace("\\", "/")).parts:
        return None
    p = (base / rel).resolve()
    try:
        p.relative_to(base.resolve())
    except ValueError:
        return None
    return p


def emplacement(studio, tid: str, rel: str) -> tuple[Path | None, str]:
    """(fichier, « copie » | « projet » | « capture ») — None si introuvable ou non autorisé."""
    from .orchestrator.runner import ESPACE
    run = studio.run_dir(tid, creer=False)
    if rel.startswith("captures/") and rel.count("/") == 1:
        f = _sous(run, rel)
        if f and f.is_file():
            return f, "capture"
    f = _sous(run / ESPACE, rel)
    if f and f.is_file():
        return f, "copie"
    try:
        t = studio.store.get(tid)
        c = studio.registry.get(t["target"])
    except KeyError:
        return None, ""
    if c.has_path:
        f = _sous(c.path(), rel)
        if f and f.is_file():
            return f, "projet"
    else:                                               # sujet : copie de travail retirée, le résultat est rangé dans Sujets/
        from .orchestrator.runner import type_livrable
        nom = Path(rel).name
        f = _sous(studio.paths.topics / c.id, f"{type_livrable(nom)}/{nom}")
        if f and f.is_file():
            return f, "sujet"
        try:                                            # rangé sous un autre nom (« nom v2 ») : liste écrite dans RESULTAT.md
            for l in (run / "RESULTAT.md").read_text(encoding="utf-8").splitlines():
                chemin = l[2:].strip() if l.startswith("- ") else ""
                if chemin.startswith(("Sujets/", "Livrables/")) and Path(chemin).stem.startswith(Path(nom).stem) \
                        and Path(chemin).suffix == Path(nom).suffix:
                    f = _sous(studio.paths.root, chemin)
                    if f and f.is_file():
                        return f, "sujet"
        except OSError:
            pass
    return None, ""


def _refs_fichier(studio) -> Path:
    return studio.paths.data / "references.json"


def references(studio, cible: str = "") -> list[dict]:
    """Fichiers marqués « référence » par l'utilisateur (étoile) : [{cible, tid, chemin}], gardés dans data/references.json."""
    import json
    try:
        refs = json.loads(_refs_fichier(studio).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        refs = []
    return [r for r in refs if isinstance(r, dict) and (not cible or r.get("cible") == cible)]


def marquer_reference(studio, cible: str, tid: str, rel: str, oui: bool) -> list[dict]:
    import json
    refs = [r for r in references(studio) if not (r.get("tid") == tid and r.get("chemin") == rel)]
    if oui:
        refs.append({"cible": cible, "tid": tid, "chemin": rel})
    _refs_fichier(studio).write_text(json.dumps(refs, ensure_ascii=False, indent=1), encoding="utf-8")
    return references(studio, cible)


def autorise(studio, tid: str, rel: str) -> bool:
    """Seuls les fichiers relevés pour cette tâche (ou ses captures) peuvent être affichés."""
    if rel.startswith("captures/") and rel.count("/") == 1:
        return True
    return any(a["path"] == rel for a in studio.store.artifacts(tid))


def liste(studio, cible: str, limite: int = 400) -> list[dict]:
    out, vus = [], set()
    def meme_cible(x: str) -> bool:
        if x == cible:
            return True
        try:
            c = studio.registry.get(x)
            return f"{c.kind}:{c.id}" == cible
        except KeyError:
            return False
    taches = [t for t in studio.store.list(100000) if t["status"] != "annulee" and meme_cible(t["target"])]
    for t in taches:
        titre = (t.get("options") or {}).get("titre") or (t.get("request") or "")[:60]
        derniers: dict[str, dict] = {}
        for a in studio.store.artifacts(t["id"]):
            derniers[a["path"]] = a
        captures = studio.run_dir(t["id"], creer=False) / "captures"
        if captures.is_dir():
            for f in captures.iterdir():
                if f.is_file() and f.suffix.lower() in IMAGES:
                    derniers.setdefault(f"captures/{f.name}", {"path": f"captures/{f.name}", "created_at": t["updated_at"]})
        for rel, a in derniers.items():
            if rel.lower().endswith(BRUIT) or PurePosixPath(rel).name.startswith("."):
                continue
            f, ou = emplacement(studio, t["id"], rel)
            cle = str(f) if f else f"{t['id']}:{rel}"
            if cle in vus:
                continue
            vus.add(cle)
            out.append({"tid": t["id"], "chemin": rel, "nom": PurePosixPath(rel).name, "genre": genre(rel),
                        "tache": titre, "statut": t["status"], "date": a.get("created_at") or t["updated_at"],
                        "ou": ou, "taille": f.stat().st_size if f else 0})
    refs = {(r["tid"], r["chemin"]) for r in references(studio, cible)}
    for x in out:
        x["reference"] = (x["tid"], x["chemin"]) in refs
    out.sort(key=lambda x: (not x["reference"], -(_horodatage(x["date"]))))
    return out[:limite]


def _horodatage(d: str) -> float:
    from datetime import datetime
    try:
        return datetime.fromisoformat(str(d).replace("Z", "+00:00")).timestamp()
    except ValueError:
        return 0.0


def pour_superviseur(studio, cible: str) -> str:
    """Références choisies par l'utilisateur, pour le contexte du Superviseur : chemin dans le projet et emplacement actuel."""
    lignes = []
    for r in references(studio, cible):
        f, ou = emplacement(studio, r["tid"], r["chemin"])
        if f is None:
            continue
        lignes.append(f"- {r['chemin']} ({'dans le projet' if ou == 'projet' else 'pas encore fusionné : ' + str(f)})")
    return "\n".join(lignes)
