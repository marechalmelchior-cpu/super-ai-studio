"""« Tes résultats » : le studio apprend de tes propres tâches quel modèle réussit le mieux chaque type de travail.

Pour chaque tâche terminée : le métier (type de travail), l'IA et le modèle qui l'ont faite, si elle a été validée du
premier coup (sans « corriger » de ta part ni reprise après audit), le temps et le coût. Rien ne quitte le PC.
"""
from __future__ import annotations

import json

FINIES = ("approuvee", "appliquee", "annulee", "echec")
MIN_TACHES = 3                      # en dessous, pas assez de recul pour conseiller


def _taches(store) -> list[dict]:
    with store.db() as c:
        lignes = c.execute("SELECT t.id, t.status, t.options, "
                           "(SELECT COUNT(*) FROM approvals a WHERE a.task_id=t.id AND a.decision='corriger') AS corrections, "
                           "(SELECT MAX(attempt) FROM steps s WHERE s.task_id=t.id) AS tentatives "
                           "FROM tasks t WHERE t.status IN (?,?,?,?) AND json_extract(t.options,'$.bilan') IS NOT NULL",
                           FINIES).fetchall()
    out = []
    for r in lignes:
        b = (json.loads(r["options"] or "{}").get("bilan") or {})
        if not b.get("famille"):
            continue
        reussie = r["status"] in ("approuvee", "appliquee")
        out.append({"role": b.get("role", ""), "ia": b["famille"] + (f" · {b['modele']}" if b.get("modele") else ""),
                    "reussie": reussie, "premier_coup": reussie and not r["corrections"] and (r["tentatives"] or 1) <= 1,
                    "duree_s": float(b.get("duree_s") or 0), "cout_usd": b.get("cout_usd")})
    return out


def resultats(studio) -> dict:
    """Par type de travail puis par modèle : nombre, réussite du premier coup, réussite finale, temps et coût moyens."""
    groupes: dict[tuple[str, str], list[dict]] = {}
    for t in _taches(studio.store):
        groupes.setdefault((t["role"], t["ia"]), []).append(t)
    noms = {r.id: r.nom for r in studio.roles.values()}
    lignes = []
    for (role, ia), ts in groupes.items():
        couts = [t["cout_usd"] for t in ts if t["cout_usd"] is not None]
        lignes.append({"role": role, "travail": noms.get(role, role or "—"), "ia": ia, "taches": len(ts),
                       "premier_coup": sum(t["premier_coup"] for t in ts), "reussies": sum(t["reussie"] for t in ts),
                       "duree_moy_s": round(sum(t["duree_s"] for t in ts) / len(ts)),
                       "cout_moy_usd": round(sum(couts) / len(couts), 4) if couts else None})
    lignes.sort(key=lambda x: (x["travail"].lower(), -x["premier_coup"] / x["taches"], -x["taches"]))
    return {"lignes": lignes, "total": sum(x["taches"] for x in lignes), "min": MIN_TACHES}


def conseil(studio, role: str) -> dict | None:
    """Meilleur modèle pour ce type de travail d'après tes tâches (au moins MIN_TACHES), sinon None."""
    if not role:
        return None
    cands = [x for x in resultats(studio)["lignes"] if x["role"] == role and x["taches"] >= MIN_TACHES]
    if not cands:
        return None
    best = max(cands, key=lambda x: (x["premier_coup"] / x["taches"], x["reussies"] / x["taches"],
                                      -(x["cout_moy_usd"] or 0), -x["duree_moy_s"]))
    return {"ia": best["ia"], "premier_coup": best["premier_coup"], "taches": best["taches"],
            "texte": f"D'après tes tâches : {best['ia']} réussit ce travail du premier coup {best['premier_coup']} fois sur {best['taches']}."}
