"""Diagnostic du client MCP AgentMemory (celui que lancent Claude Code et Codex).

Lance exactement la commande des configurations (npx -y @agentmemory/mcp@<version>, FORCE_PROXY),
fait la poignée de main MCP (initialize puis tools/list) et mesure les durées.
Rien n'est écrit dans la mémoire. Aucun secret n'est affiché (journal masqué).
"""
from __future__ import annotations

import json
import os
import queue
import shutil
import subprocess
import threading
import time

from .configs import AGENTMEMORY_VERSION
from .connectors.base import SANS_FENETRE
from .security import redact


def _reader(stream, q):
    for line in iter(stream.readline, ""):
        q.put(line)
    q.put(None)


def diagnose(version: str = AGENTMEMORY_VERSION, timeout: float = 120.0) -> dict:
    npx = shutil.which("npx") or "npx"
    cmd = [npx, "-y", f"@agentmemory/mcp@{version}"]
    env = dict(os.environ, AGENTMEMORY_URL="http://localhost:3111", AGENTMEMORY_FORCE_PROXY="1")
    t0 = time.time()
    p = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env,
                         text=True, encoding="utf-8", errors="replace", bufsize=1)
    out_q, err_q = queue.Queue(), queue.Queue()
    threading.Thread(target=_reader, args=(p.stdout, out_q), daemon=True).start()
    threading.Thread(target=_reader, args=(p.stderr, err_q), daemon=True).start()
    res: dict = {"commande": " ".join(cmd[1:]), "ok": False}

    def send(obj):
        p.stdin.write(json.dumps(obj) + "\n")
        p.stdin.flush()

    def wait_id(i, limit):
        end = time.time() + limit
        while time.time() < end:
            try:
                line = out_q.get(timeout=0.5)
            except queue.Empty:
                if p.poll() is not None:
                    return None
                continue
            if line is None:
                return None
            try:
                msg = json.loads(line)
            except ValueError:
                continue
            if msg.get("id") == i:
                return msg
        return None

    try:
        send({"jsonrpc": "2.0", "id": 1, "method": "initialize",
              "params": {"protocolVersion": "2024-11-05", "capabilities": {}, "clientInfo": {"name": "studio-diag", "version": "1"}}})
        init = wait_id(1, timeout)
        res["initialize_s"] = round(time.time() - t0, 1)
        if not init:
            res["erreur"] = "pas de réponse à initialize (démarrage trop long ou arrêt du client)"
        else:
            res["serveur_mcp"] = (init.get("result") or {}).get("serverInfo")
            send({"jsonrpc": "2.0", "method": "notifications/initialized"})
            send({"jsonrpc": "2.0", "id": 2, "method": "tools/list"})
            tools = wait_id(2, 60)
            if tools and "result" in tools:
                names = [t.get("name") for t in tools["result"].get("tools", [])]
                res.update(ok=True, outils=len(names), exemples=names[:6],
                           mode="proxy (serveur central)" if len(names) > 7 else "réduit — à vérifier")
            else:
                res["erreur"] = f"tools/list : {json.dumps(tools)[:300] if tools else 'pas de réponse'}"
        res["duree_totale_s"] = round(time.time() - t0, 1)
    finally:
        try:
            p.stdin.close()
        except OSError:
            pass
        try:
            p.wait(timeout=5)
        except subprocess.TimeoutExpired:
            if os.name == "nt":
                subprocess.run(["taskkill", "/PID", str(p.pid), "/T", "/F"], capture_output=True, **SANS_FENETRE)
            else:
                p.kill()
        err = []
        while True:
            try:
                line = err_q.get_nowait()
            except queue.Empty:
                break
            if line:
                err.append(line.rstrip())
        res["journal_client"] = [redact(l)[:300] for l in err[-15:]]
        res["code_sortie"] = p.returncode
    return res
