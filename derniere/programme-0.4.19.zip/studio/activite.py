"""Activité en direct d'une tâche, en français simple : ce que fait l'agent, les fichiers touchés, les applications ouvertes.

- actions : le fil noté par le garde (details/activite.log : commandes, actions dans Unreal, fichiers modifiés),
  traduit en phrases courtes (« Compile le projet », « Modifie EnemyBase.cpp ») ;
- fichiers : l'état git de la copie de travail (tout ce qui a changé, scripts compris), sinon le fil d'activité ;
- applications : Unreal, Blender et ce que l'agent a lancé, avec leur statut (ouvert, en compilation, fermé…).
Lecture seule, rien n'est jamais lancé ni fermé ici. Aucune ligne de commande n'est montrée telle quelle.
"""
from __future__ import annotations

import os
import re
import subprocess
import time
from pathlib import Path

# ------------------------------------------------------------------ actions en clair
_REGLES = [
    (r"unreal_compiler\.py", "Ferme Unreal, compile le projet et le rouvre"),
    (r"Build\.bat|UnrealBuildTool|RunUAT", "Compile le projet"),
    (r"run_in_editor\.py\s+\S*?([\w-]+)\.py", lambda m: f"Lance le script « {m.group(1)} » dans Unreal"),
    (r"UnrealEditor(-Cmd)?(\.exe)?", "Lance Unreal"),
    (r"blender(\.exe)?[\"']?\s.*(--background|\s-b\s)", "Lance Blender en arrière-plan"),
    (r"blender(\.exe)?\b", "Ouvre Blender"),
    (r"\bgit\s+(diff|status|log|show)\b", "Regarde les changements"),
    (r"\bpytest\b", "Lance les tests"),
    (r"(?:\bpython3?|\bpy)(?:\.exe)?\s+(?:-\S+\s+)*\S*?([\w-]+)\.py", lambda m: f"Lance le script « {m.group(1)} »"),
    (r"\b(mkdir|New-Item)\b", "Crée un dossier"),
    (r"\b(cp|copy|Copy-Item|mv|move|Move-Item)\b", "Copie ou déplace des fichiers"),
    (r"\b(grep|rg|sed\s+-n|cat|head|tail|ls|find|Get-Content|Select-String|Get-ChildItem|type|dir|wc)\b", "Lit des fichiers"),
]
_UNREAL = [
    (r"list_toolsets|describe_toolset", "regarde les outils disponibles"),
    (r"load_level|open_level", "ouvre un niveau"), (r"save", "enregistre"), (r"spawn", "place un acteur"),
    (r"delete|destroy|remove", "supprime un élément"), (r"screenshot|capture", "fait une capture"),
    (r"(play|pie|simulate)", "lance le jeu (PIE)"), (r"compile", "compile un Blueprint"),
    (r"set_|update|modify|edit", "modifie un élément"), (r"create|add_", "crée un élément"),
    (r"get_|list_|find|describe|search|query|read|snapshot|inspect", "lit l'état de l'éditeur"),
]


def _commande(cmd: str) -> str:
    c = re.sub(r"^\s*(cd\s+(\"[^\"]*\"|'[^']*'|\S+)\s*(&&|;)\s*)+", "", cmd)        # « cd dossier && … » : sans intérêt
    c = re.sub(r"^\s*\$\w+\s*=\s*[^;]+;\s*", "", c)
    for motif, sortie in _REGLES:
        m = re.search(motif, c, re.I)
        if m:
            return sortie(m) if callable(sortie) else sortie
    mot = (c.split() or ["commande"])[0].strip("&\"'")
    return f"Lance une commande ({Path(mot).name[:30]})"


def _unreal(texte: str) -> str:
    genre, _, action = texte.partition("  ")
    nom = action.split(".")[-1]
    for motif, sortie in _UNREAL:
        if re.search(motif, nom, re.I):
            return f"Dans Unreal : {sortie}"
    return f"Dans Unreal : {nom.replace('_', ' ')}"


def phrase(genre: str, texte: str, base: Path | None = None) -> str:
    if genre == "fichier":
        verbe, _, chemin = texte.partition("  ")
        return f"{'Crée' if verbe == 'crée' else 'Modifie'} {Path(chemin.replace(chr(92), '/')).name}"
    if genre == "unreal":
        return _unreal(texte)
    nom = lambda t: Path(t.replace(chr(92), "/")).name or t
    simples = {"lit": lambda t: f"Lit {nom(t)}", "liste": lambda t: "Parcourt les dossiers" if t in ("", ".") else f"Parcourt {nom(t)}",
               "cherche": lambda t: f"Cherche « {t[:40]} » dans le projet", "image": lambda t: f"Génère l'image {nom(t)}",
               "voix": lambda t: f"Génère la voix {nom(t)}", "pense": lambda t: f"Démarre ({t})" if t else "Démarre",
               "fin": lambda t: "Écrit son compte rendu"}
    if genre in simples:
        return simples[genre](texte)
    if genre == "refus":
        return f"Commande refusée par le studio : {_commande(texte).lower()}"
    return _commande(texte)


def actions(details: Path, n: int = 5) -> list[dict]:
    f = details / "activite.log"
    if not f.exists():
        return []
    try:
        lignes = f.read_text(encoding="utf-8", errors="replace").splitlines()[-200:]
    except OSError:
        return []
    out = []
    for l in lignes:
        p = l.split("\t", 2)
        if len(p) < 3:
            continue
        texte = phrase(p[1], p[2])
        if out and out[-1]["texte"] == texte:                 # « Lit des fichiers » ×10 : une seule ligne
            out[-1]["fois"] += 1
            out[-1]["heure"] = p[0]
            continue
        out.append({"heure": p[0], "texte": texte, "genre": p[1], "fois": 1})
    return out[-n:][::-1]


# ------------------------------------------------------------------ fichiers touchés
_CACHES = (".mission-", ".studio-", "_pieces/", "Saved/", "Intermediate/", "Binaries/", "DerivedDataCache/")


def fichiers(travail: Path, details: Path, git: str = "git") -> list[dict]:
    out: dict[str, str] = {}
    if (travail / ".git").exists():
        try:
            from .connectors.base import SANS_FENETRE
            r = subprocess.run([git, "-C", str(travail), "status", "--porcelain=v1", "-z", "--untracked-files=all"],
                               capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=20,
                               stdin=subprocess.DEVNULL, **SANS_FENETRE)
            morceaux, i = r.stdout.split("\0"), 0
            while i < len(morceaux):
                m = morceaux[i]; i += 1
                if len(m) < 4:
                    continue
                if m[0] in "RC":
                    i += 1
                xy, chemin = m[:2], m[3:]
                out[chemin] = "nouveau" if xy == "??" or "A" in xy else "supprimé" if "D" in xy else "modifié"
        except (OSError, subprocess.TimeoutExpired):
            pass
    if not out and (details / "activite.log").exists():
        base = str(travail).replace("\\", "/").rstrip("/") + "/"
        for l in (details / "activite.log").read_text(encoding="utf-8", errors="replace").splitlines():
            p = l.split("\t", 2)
            if len(p) == 3 and p[1] == "fichier":
                verbe, _, chemin = p[2].partition("  ")
                chemin = chemin.replace("\\", "/")
                rel = chemin[len(base):] if chemin.lower().startswith(base.lower()) else Path(chemin).name
                out[rel] = "nouveau" if verbe == "crée" and rel not in out else out.get(rel, "modifié")
    return [{"chemin": k, "etat": v} for k, v in out.items() if not any(c in k for c in _CACHES)][:40]


# ------------------------------------------------------------------ applications ouvertes
_APPS = {"unrealeditor.exe": "Unreal Editor", "unrealeditor-cmd.exe": "Unreal (sans fenêtre)", "blender.exe": "Blender",
         "unrealbuildtool.exe": "Compilation Unreal", "devenv.exe": "Visual Studio", "code.exe": "VS Code",
         "photoshop.exe": "Photoshop", "krita.exe": "Krita", "gimp.exe": "GIMP", "substancepainter.exe": "Substance Painter",
         "houdini.exe": "Houdini", "maya.exe": "Maya", "audacity.exe": "Audacity", "obs64.exe": "OBS"}
_OUTILS = {"cmd.exe", "conhost.exe", "powershell.exe", "pwsh.exe", "bash.exe", "sh.exe", "node.exe", "python.exe",
           "pythonw.exe", "py.exe", "git.exe", "claude.exe", "codex.exe", "rg.exe", "uv.exe", "npx.exe", "npm.exe",
           "timeout.exe", "find.exe", "findstr.exe", "where.exe", "tasklist.exe", "openconsole.exe", "git-remote-https.exe",
           "ssh.exe", "less.exe", "cat.exe", "grep.exe", "sed.exe", "head.exe", "tail.exe", "ls.exe", "wc.exe", "sort.exe"}
_cache: dict = {"t": 0.0, "liste": []}


def _processus() -> list[tuple[int, int, str, str]]:
    """(pid, parent, nom, ligne de commande) — Windows ; la ligne de commande sert seulement à reconnaître, jamais montrée."""
    if os.name != "nt":
        return []
    if time.monotonic() - _cache["t"] < 4:
        return _cache["liste"]
    from .connectors.base import SANS_FENETRE
    ps = ("Get-CimInstance Win32_Process | ForEach-Object { \"$($_.ProcessId)`t$($_.ParentProcessId)`t$($_.Name)`t$($_.CommandLine)\" }")
    try:
        r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", ps], capture_output=True, text=True,
                           encoding="utf-8", errors="replace", timeout=20, stdin=subprocess.DEVNULL, **SANS_FENETRE)
        liste = []
        for l in r.stdout.splitlines():
            p = l.split("\t", 3)
            if len(p) >= 3 and p[0].isdigit() and p[1].isdigit():
                liste.append((int(p[0]), int(p[1]), p[2], p[3] if len(p) > 3 else ""))
    except (OSError, subprocess.TimeoutExpired):
        liste = []
    _cache.update(t=time.monotonic(), liste=liste)
    return liste


def applications(pids_agent: list[int], projet_unreal: bool, procs: list | None = None) -> list[dict]:
    procs = _processus() if procs is None else procs
    enfants: dict[int, list] = {}
    for pid, parent, nom, cl in procs:
        enfants.setdefault(parent, []).append((pid, nom, cl))
    descendants, a_voir = set(), list(pids_agent)
    while a_voir:
        p = a_voir.pop()
        for pid, _, _ in enfants.get(p, []):
            if pid not in descendants:
                descendants.add(pid)
                a_voir.append(pid)
    vus: dict[str, dict] = {}
    ubt = [pid for pid, _, n, cl in procs if n.lower() == "unrealbuildtool.exe" or (n.lower() == "dotnet.exe" and "unrealbuildtool" in cl.lower())]
    compile_ = bool(ubt)
    for pid, _, nom, cl in procs:
        n = nom.lower()
        par_agent = pid in descendants
        if n in _APPS:
            lib = _APPS[n]
            statut = "en arrière-plan" if n == "blender.exe" and re.search(r"(--background|\s-b\s)", cl) else "ouvert"
            if n == "unrealbuildtool.exe":
                statut = "en cours"
            vus.setdefault(lib, {"nom": lib, "statut": statut, "par_agent": par_agent})
            vus[lib]["par_agent"] = vus[lib]["par_agent"] or par_agent
        elif par_agent and n not in _OUTILS and not (n == "dotnet.exe" and "unrealbuildtool" in cl.lower()):
            lib = Path(nom).stem
            vus.setdefault(lib, {"nom": lib, "statut": "ouvert", "par_agent": True})
    if compile_:
        vus.setdefault("Compilation Unreal", {"nom": "Compilation Unreal", "statut": "en cours", "par_agent": any(p in descendants for p in ubt)})
    if projet_unreal and "Unreal Editor" not in vus:
        vus["Unreal Editor"] = {"nom": "Unreal Editor", "statut": "fermé", "par_agent": False}
    ordre = {"Unreal Editor": 0, "Compilation Unreal": 1, "Blender": 2}
    return sorted(vus.values(), key=lambda a: (ordre.get(a["nom"], 9), a["nom"]))
