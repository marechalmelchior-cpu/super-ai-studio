"""SIMULATION — faux serveur AgentMemory pour les tests hors serveur.

Reproduit le comportement observé dans le code réel :
- mode "0.9.22" : pas de champ project, supersession Jaccard > 0,7 globale ;
- mode "0.9.30" : project stocké/filtré par /memories, supersession limitée
  quand les deux souvenirs ont un project ; smart-search ignore project.
Il ne remplace en aucun cas un test d'intégration avec le vrai serveur.
"""
from __future__ import annotations

import json
import threading
import uuid
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse


def _jaccard(a: str, b: str) -> float:
    sa = {t for t in a.split() if len(t) > 2}
    sb = {t for t in b.split() if len(t) > 2}
    if not sa and not sb:
        return 1.0
    if not sa or not sb:
        return 0.0
    i = len(sa & sb)
    return i / (len(sa) + len(sb) - i)


class FakeAgentMemory:
    def __init__(self, mode: str = "0.9.22", secret: str = "secret-de-test"):
        self.mode, self.secret = mode, secret
        self.memories: list[dict] = []
        self.lock = threading.Lock()
        self.down = False
        self.httpd: ThreadingHTTPServer | None = None

    # ---- logique ----------------------------------------------------------
    def remember(self, body: dict) -> dict:
        with self.lock:
            content = body["content"]
            project = body.get("project") if self.mode != "0.9.22" else None
            sup = None
            for m in self.memories:
                if not m["isLatest"]:
                    continue
                if project and m.get("project") and m["project"] != project:
                    continue
                if _jaccard(content.lower(), m["content"].lower()) > 0.7:
                    sup = m
                    break
            mem = {"id": "mem_" + uuid.uuid4().hex[:12], "content": content, "type": body.get("type", "fact"),
                   "concepts": body.get("concepts", []), "isLatest": True,
                   "createdAt": datetime.now(timezone.utc).isoformat(), "agentId": body.get("agentId")}
            if project:
                mem["project"] = project
            if sup:
                sup["isLatest"] = False
                mem["supersedes"] = [sup["id"]]
            self.memories.append(mem)
            return {"success": True, "memory": mem}

    def list(self, q: dict) -> dict:
        with self.lock:
            items = list(self.memories)
        if q.get("latest") == "true":
            items = [m for m in items if m["isLatest"]]
        if self.mode != "0.9.22" and q.get("project"):
            items = [m for m in items if m.get("project") == q["project"]]
        total = len(items)
        off, lim = int(q.get("offset", 0)), min(int(q.get("limit", 5000)), 100)   # plafond comme un vrai serveur
        return {"memories": items[off:off + lim], "total": total, "offset": off}

    # ---- serveur ----------------------------------------------------------
    def start(self) -> str:
        fake = self

        class H(BaseHTTPRequestHandler):
            def log_message(self, *a):  # silence
                pass

            def _send(self, code, obj):
                data = json.dumps(obj).encode()
                self.send_response(code)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)

            def _auth(self):
                if fake.down:
                    self.close_connection = True
                    self._send(503, {"error": "down"})
                    return False
                if fake.secret and self.headers.get("Authorization") != f"Bearer {fake.secret}":
                    self._send(401, {"error": "unauthorized"})
                    return False
                return True

            def do_GET(self):
                u = urlparse(self.path)
                q = {k: v[0] for k, v in parse_qs(u.query).items()}
                if u.path == "/agentmemory/livez":
                    if fake.down:
                        return self._send(503, {})
                    return self._send(200, {"status": "ok"})
                if not self._auth():
                    return
                if u.path == "/agentmemory/health":
                    return self._send(200, {"status": "healthy", "version": fake.mode + "-SIMULATION"})
                if u.path == "/agentmemory/memories":
                    return self._send(200, fake.list(q))
                self._send(404, {"error": "not found"})

            def do_POST(self):
                if not self._auth():
                    return
                n = int(self.headers.get("Content-Length", 0))
                body = json.loads(self.rfile.read(n) or b"{}")
                if self.path == "/agentmemory/remember":
                    return self._send(201, fake.remember(body))
                if self.path == "/agentmemory/smart-search":   # ignore project (comme le vrai)
                    words = body.get("query", "").lower().split()
                    hits = [m for m in fake.memories if m["isLatest"] and any(w in m["content"].lower() for w in words)]
                    return self._send(200, {"results": hits})
                self._send(404, {"error": "not found"})

        self.httpd = ThreadingHTTPServer(("127.0.0.1", 0), H)
        threading.Thread(target=self.httpd.serve_forever, daemon=True).start()
        return f"http://127.0.0.1:{self.httpd.server_address[1]}"

    def stop(self):
        if self.httpd:
            self.httpd.shutdown()
            self.httpd.server_close()
