"""Alternative locale derrière le même connecteur mémoire.

N'est utilisée que si la configuration le demande explicitement
(``memoire.backend = "sqlite"``). Jamais en repli silencieux d'AgentMemory.
"""
from __future__ import annotations

import json
import sqlite3
import threading
from pathlib import Path

from .models import MemoryRecord, MemoryUnavailable, Provenance, Scope

SCHEMA = """
CREATE TABLE IF NOT EXISTS memories (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  label TEXT NOT NULL,
  key TEXT NOT NULL,
  subject TEXT NOT NULL DEFAULT '',
  supersedes TEXT NOT NULL DEFAULT '',
  type TEXT NOT NULL DEFAULT 'fact',
  content TEXT NOT NULL,
  provenance TEXT NOT NULL,
  created_at TEXT NOT NULL,
  UNIQUE(label, key)
);
CREATE INDEX IF NOT EXISTS idx_mem_label ON memories(label);
"""


class SqliteBackend:
    name = "sqlite"

    def __init__(self, path: Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._local = threading.local()
        with self._conn() as c:
            c.executescript(SCHEMA)

    def _conn(self) -> sqlite3.Connection:
        c = getattr(self._local, "c", None)
        if c is None:
            c = sqlite3.connect(self.path, timeout=30, isolation_level=None)
            c.execute("PRAGMA journal_mode=WAL")
            c.execute("PRAGMA busy_timeout=30000")
            c.row_factory = sqlite3.Row
            self._local.c = c
        return c

    def ping(self) -> dict:
        try:
            self._conn().execute("SELECT 1").fetchone()
            return {"ok": True, "detail": str(self.path)}
        except sqlite3.Error as e:  # pragma: no cover
            raise MemoryUnavailable(f"Base locale illisible : {e}") from e

    def put(self, rec: MemoryRecord) -> tuple[str, bool]:
        """Insère si la clé est nouvelle. Retourne (id, créé ?)."""
        c = self._conn()
        cur = c.execute(
            "INSERT OR IGNORE INTO memories(label,key,subject,supersedes,type,content,provenance,created_at)"
            " VALUES (?,?,?,?,?,?,?,?)",
            (rec.scope.label, rec.key, rec.subject, rec.supersedes, rec.type, rec.content,
             json.dumps(rec.provenance.__dict__, ensure_ascii=False), rec.created_at),
        )
        row = c.execute("SELECT id FROM memories WHERE label=? AND key=?", (rec.scope.label, rec.key)).fetchone()
        return str(row["id"]), cur.rowcount == 1

    def list(self, scope: Scope) -> list[MemoryRecord]:
        rows = self._conn().execute(
            "SELECT * FROM memories WHERE label=? ORDER BY id", (scope.label,)
        ).fetchall()
        out = []
        for r in rows:
            if r["label"] != scope.label:   # défense en profondeur
                continue
            out.append(MemoryRecord(
                scope=scope, content=r["content"], key=r["key"],
                provenance=Provenance(**json.loads(r["provenance"])), type=r["type"],
                subject=r["subject"], supersedes=r["supersedes"], created_at=r["created_at"],
                backend_id=str(r["id"]),
            ))
        return out
