"""Git et GitHub des projets — onglet de Gestion et ligne d'état de la page projet.

Tout se fait par git directement (instantané, sans agent ni jeton consommé) :
- lecture : branche courante, fichiers modifiés, avance / retard sur GitHub, branches locales (fusionnées ou non,
  tâche du studio liée, copie de travail), adresse du dépôt distant sans identifiants ;
- actions, chacune sur un clic de l'utilisateur (le clic vaut accord) : actualiser (fetch), récupérer (pull --ff-only),
  pousser la branche courante, créer une pull request (si l'outil gh est installé), supprimer une branche
  DÉJÀ fusionnée (git branch -d, jamais -D : rien n'est perdu).
- commit LOCAL des fichiers cochés par l'utilisateur (jamais de push), fusion d'une branche de tâche.
Jamais : force push, reset, rebase, suppression d'une branche non fusionnée, changement de branche.
"""
from __future__ import annotations

import re
import shutil
from pathlib import Path

from .connectors import workspace as ws
from .orchestrator.store import TERMINAL
from .security import redact


def _git_exe(studio) -> str:
    return studio.cfg["outils"].get("git", "git")


def depots(studio) -> list:
    """Projets dont le dossier est un dépôt git."""
    return [c for c in studio.registry.all()
            if c.kind == "project" and c.has_path and c.path().is_dir() and (c.path() / ".git").exists()]


def _cible(studio, cle: str):
    for c in depots(studio):
        if f"{c.kind}:{c.id}" == cle:
            return c
    raise ValueError("Ce projet n'est pas un dépôt git.")


def adresse_publique(url: str) -> str:
    """Adresse du dépôt distant sans identifiant ni jeton ; lien https pour GitHub."""
    url = re.sub(r"//[^/@]+@", "//", url.strip())
    m = re.match(r"^(?:git@github\.com:|https://github\.com/)([^/]+/[^/]+?)(?:\.git)?/?$", url)
    return f"https://github.com/{m.group(1)}" if m else redact(url)


def _suivi(texte: str) -> tuple[int, int]:
    a = re.search(r"ahead (\d+)", texte or ""); b = re.search(r"behind (\d+)", texte or "")
    return (int(a.group(1)) if a else 0, int(b.group(1)) if b else 0)


def etat(studio, cible) -> dict:
    git, d = _git_exe(studio), cible.path()
    out = {"cible": f"{cible.kind}:{cible.id}", "nom": cible.nom, "branche": "", "detache": False, "modifies": [],
           "en_avance": 0, "en_retard": 0, "amont": "", "distant": "", "erreur": ""}
    try:
        st = ws._git(git, d, "status", "--porcelain=v1", "--branch", "--untracked-files=normal", timeout=60)
    except ws.WorktreeError as e:
        out["erreur"] = redact(str(e))[:300]
        return out
    lignes = st.splitlines()
    tete = lignes[0][3:] if lignes and lignes[0].startswith("## ") else ""
    if tete.startswith("HEAD (no branch)") or tete.startswith("HEAD détachée"):
        out["detache"] = True
    else:
        nom = tete.split("...")[0].split(" ")[0]
        out["branche"] = nom.replace("No commits yet on ", "")
        if "..." in tete:
            out["amont"] = tete.split("...")[1].split(" ")[0]
        out["en_avance"], out["en_retard"] = _suivi(tete)
    out["modifies"] = [l[3:] for l in lignes[1:] if l.strip()][:200]
    try:
        out["distant"] = adresse_publique(ws._git(git, d, "remote", "get-url", "origin", timeout=20).strip())
    except ws.WorktreeError:
        pass
    return out


def detail(studio, cle: str) -> dict:
    c = _cible(studio, cle)
    git, d = _git_exe(studio), c.path()
    e = etat(studio, c)
    fusionnees = set()
    try:
        fusionnees = {l.strip(" *+") for l in ws._git(git, d, "branch", "--merged", "HEAD", timeout=60).splitlines()}
    except ws.WorktreeError:
        pass
    from . import actions
    copies = {x["tache"]: x for x in actions.espaces(studio) if x["projet"] == c.nom}
    branches = []
    fmt = "%(refname:short)%09%(objectname:short)%09%(committerdate:iso8601)%09%(upstream:short)%09%(upstream:track)%09%(subject)"
    try:
        refs = ws._git(git, d, "for-each-ref", "--sort=-committerdate", f"--format={fmt}", "refs/heads", timeout=60)
    except ws.WorktreeError:
        refs = ""
    for l in refs.splitlines():
        p = (l.split("\t") + [""] * 6)[:6]
        nom = p[0]
        tache = None
        if nom.startswith("studio/"):
            tid = nom[len("studio/"):]
            try:
                t = studio.store.get(tid)
                tache = {"id": tid, "statut": t["status"], "titre": ((t.get("options") or {}).get("titre") or t["request"] or "")[:120]}
            except KeyError:
                tache = {"id": tid, "statut": "inconnue", "titre": ""}
        av, re_ = _suivi(p[4])
        branches.append({"nom": nom, "commit": p[1], "date": p[2][:16], "amont": p[3], "en_avance": av, "en_retard": re_,
                         "sujet": redact(p[5])[:160], "courante": nom == e["branche"],
                         "fusionnee": nom in fusionnees and nom != e["branche"], "tache": tache,
                         "copie": copies.get(tache["id"]) if tache else None})
    branches.sort(key=lambda b: (not b["courante"], b["fusionnee"]))   # courante, puis en cours, puis fusionnées (stable : récentes d'abord)
    for b in branches:                          # graphe : commits propres à la branche, et avance prise par la branche courante
        if b["courante"] or b["fusionnee"]:
            continue
        try:
            g = ws._git(git, d, "rev-list", "--left-right", "--count", f"HEAD...{b['nom']}", timeout=30).split()
            b["derriere"], b["devant"] = int(g[0]), int(g[1])
        except (ws.WorktreeError, ValueError, IndexError):
            pass
    historique = []
    try:
        for l in ws._git(git, d, "log", "-40", "--format=%h%x09%cs%x09%s", timeout=30).splitlines():
            h, date, sujet = (l.split("\t") + ["", ""])[:3]
            historique.append({"commit": h, "date": date, "sujet": redact(sujet)[:120]})
    except ws.WorktreeError:
        pass
    a_pousser = None                            # commits pas encore sur GitHub (les carrés de fusion disparaissent après Push)
    if e.get("amont"):
        try:
            a_pousser = []
            for l in ws._git(git, d, "log", "--format=%h%x09%cs%x09%s", "@{upstream}..HEAD", timeout=30).splitlines():
                h, date, sujet = (l.split("\t") + ["", ""])[:3]
                a_pousser.append({"commit": h, "date": date, "sujet": redact(sujet)[:120]})
            a_pousser.reverse()
        except ws.WorktreeError:
            a_pousser = None
    return {**e, "branches": branches, "historique": historique[::-1], "a_pousser": a_pousser, "gh": bool(shutil.which("gh"))}


def liste(studio) -> list[dict]:
    return [etat(studio, c) for c in depots(studio)]


# ---------------------------------------------------------------- actions (un clic de l'utilisateur = son accord)
RESEAU = {"actualiser": "Actualiser depuis GitHub", "recuperer": "Récupérer les nouveautés", "pousser": "Pousser vers GitHub",
          "pr": "Créer une pull request"}


def lancer(studio, travaux, cle: str, action: str) -> dict:
    """Actions réseau : en arrière-plan, visibles dans « Travaux ». Les identifiants restent ceux de Windows (jamais lus)."""
    c = _cible(studio, cle)
    git, d = _git_exe(studio), c.path()
    e = etat(studio, c)
    if action not in RESEAU:
        raise ValueError("Action inconnue.")
    if action != "actualiser" and (e["detache"] or not e["branche"]):
        raise ValueError("Le dépôt n'est pas sur une branche : rien n'est fait.")
    if action == "actualiser":
        cmd = [git, "fetch", "--prune", "origin"]
    elif action == "recuperer":
        if not e["amont"]:
            raise ValueError(f"La branche {e['branche']} ne suit aucune branche GitHub.")
        cmd = [git, "pull", "--ff-only"]                  # jamais de fusion ni de rebase cachés
    elif action == "pousser":
        if e["en_retard"]:
            raise ValueError("GitHub a des commits que tu n'as pas : récupère d'abord (jamais de push forcé).")
        cmd = [git, "push"] if e["amont"] else [git, "push", "-u", "origin", e["branche"]]
    else:
        gh = shutil.which("gh")
        if not gh:
            raise ValueError("L'outil gh (GitHub CLI) n'est pas installé.")
        if not e["amont"] or e["en_avance"]:
            raise ValueError("Pousse d'abord la branche sur GitHub.")
        cmd = [gh, "pr", "create", "--fill", "--head", e["branche"]]
    nom = f"git:{c.id}:{action}"
    travaux.lancer(nom, f"{RESEAU[action]} — {c.nom} ({e['branche'] or 'origin'})", cmd, d, timeout_s=600)
    return {"travail": nom, "message": f"{RESEAU[action]} : lancé."}


ROUGES = ("annulee", "echec", "bloquee", "interrompue")


def effacer_branche(studio, cle: str, branche: str) -> dict:
    """Bouton Delete d'une branche rouge (tâche bloquée, interrompue, en échec ou annulée), sur le clic de l'utilisateur : la tâche est
    annulée si besoin, sa copie de travail retirée, puis la branche effacée (git branch -D). Son travail non fusionné est
    perdu : l'interface le dit avant. Le dossier Taches\\<tâche> (résultat, journal) reste."""
    c = _cible(studio, cle)
    git, d = _git_exe(studio), c.path()
    if not re.fullmatch(r"studio/[A-Za-z0-9._-]{1,120}", branche or ""):
        raise ValueError("Seules les branches des tâches du studio peuvent être effacées ici.")
    tid = branche[len("studio/"):]
    t = studio.store.get(tid)
    if t["status"] not in ROUGES:
        raise ValueError("Seule une tâche bloquée, interrompue, en échec ou annulée peut être effacée.")
    if t["status"] in ("bloquee", "interrompue"):
        studio.cancel(tid)
    espace = studio.run_dir(tid) / ws.ESPACE
    if (espace / ".git").is_file():
        ws._git(git, d, "worktree", "remove", "--force", str(espace), timeout=600)
        (studio.run_dir(tid) / ws.MARQUE_PRET).unlink(missing_ok=True)
    if ws._git(git, d, "branch", "--list", branche).strip():
        ws._git(git, d, "branch", "-D", "--", branche, timeout=60)
    studio.store.event(tid, f"Branche {branche} effacée et copie retirée (par l'utilisateur depuis l'onglet Branches)")
    return {"message": f"Branche {branche} effacée ; la tâche reste dans l'historique (annulée)."}


def supprimer_branche(studio, cle: str, branche: str) -> dict:
    """Seulement une branche locale déjà fusionnée dans la branche courante (git branch -d) : aucun commit perdu."""
    c = _cible(studio, cle)
    git, d = _git_exe(studio), c.path()
    if not re.fullmatch(r"[A-Za-z0-9._/-]{1,200}", branche or "") or branche.startswith("-"):
        raise ValueError("Nom de branche invalide.")
    e = etat(studio, c)
    if branche == e["branche"]:
        raise ValueError("C'est la branche courante.")
    if not ws._vrai(git, d, "merge-base", "--is-ancestor", branche, "HEAD"):
        raise ValueError(f"{branche} n'est pas fusionnée : elle reste.")
    if branche.startswith("studio/"):
        tid = branche[len("studio/"):]
        try:
            t = studio.store.get(tid)
            if t["status"] not in TERMINAL:
                raise ValueError("La tâche de cette branche n'est pas terminée.")
            if (studio.run_dir(tid) / ws.ESPACE / ".git").is_file():
                from . import actions
                return actions.retirer_espace(studio, tid)   # retire la copie puis la branche fusionnée
        except KeyError:
            pass
    ws._git(git, d, "branch", "-d", "--", branche, timeout=60)
    return {"message": f"Branche {branche} supprimée (elle était fusionnée : aucun commit perdu)."}


def supprimer_fusionnees(studio, cle: str) -> dict:
    """Toutes les branches locales déjà fusionnées dans la branche courante, en une fois (git branch -d, jamais -D).
    Une branche de tâche avec sa copie de travail : la copie est retirée avec. Une branche refusée est laissée et dite."""
    d = detail(studio, cle)
    faites, laissees = [], []
    for b in d["branches"]:
        if not b["fusionnee"] or b["courante"]:
            continue
        try:
            supprimer_branche(studio, cle, b["nom"])
            faites.append(b["nom"])
        except (ValueError, ws.WorktreeError) as e:
            laissees.append(f"{b['nom']} ({str(e)[:120]})")
    msg = (f"{len(faites)} branche{'s' if len(faites) > 1 else ''} fusionnée{'s' if len(faites) > 1 else ''} supprimée{'s' if len(faites) > 1 else ''}"
           if faites else "Aucune branche fusionnée à supprimer")
    if laissees:
        msg += " ; laissées : " + ", ".join(laissees)
    return {"message": msg + ". Aucun commit perdu.", "supprimees": faites, "laissees": laissees}


# ---------------------------------------------------------------- commit et fusion depuis l'onglet Branches
GROS_DEFAUT = 50 * 1024 * 1024          # au-delà : décoché d'office (GitHub refuse les fichiers de plus de 100 Mo)
LIMITE_GITHUB = 100 * 1024 * 1024
_ETATS = {"M": "modifié", "A": "ajouté", "D": "supprimé", "R": "renommé", "C": "copié", "?": "nouveau", "T": "modifié", "U": "en conflit"}


def a_commiter(studio, cle: str) -> dict:
    """Fichiers modifiés ou nouveaux de la branche courante, chacun avec sa taille et une case cochée ou non."""
    c = _cible(studio, cle)
    git, d = _git_exe(studio), c.path()
    e = etat(studio, c)
    brut = ws._git(git, d, "status", "--porcelain=v1", "-z", "--untracked-files=all", timeout=120)
    morceaux, fichiers, i = brut.split("\0"), [], 0
    while i < len(morceaux):
        m = morceaux[i]
        i += 1
        if len(m) < 4:
            continue
        xy, chemin = m[:2], m[3:]
        if xy[0] in "RC":
            i += 1                                       # -z : l'ancien nom suit le nouveau
        code = (xy[1] if xy[1] not in " ?" else xy[0]) if xy != "??" else "?"
        p = d / chemin
        octets = p.stat().st_size if p.is_file() else 0
        coche, raison = True, ""
        if octets > GROS_DEFAUT:
            coche, raison = False, (f"{octets // (1024 * 1024)} Mo : " + ("trop gros pour GitHub (100 Mo max)"
                                                                          if octets > LIMITE_GITHUB else "très gros, à confirmer"))
        if "U" in xy:
            coche, raison = False, "en conflit : à régler d'abord"
        fichiers.append({"chemin": chemin, "etat": _ETATS.get(code, code), "octets": octets, "coche": coche, "raison": raison})
        if len(fichiers) >= 500:
            break
    return {"branche": e["branche"], "detache": e["detache"], "fichiers": fichiers}


def commiter(studio, cle: str, chemins: list[str], message: str = "") -> dict:
    """Commit LOCAL des fichiers cochés par l'utilisateur sur la branche courante (jamais de push, jamais d'autre fichier)."""
    c = _cible(studio, cle)
    git, d = _git_exe(studio), c.path()
    info = a_commiter(studio, cle)
    if info["detache"] or not info["branche"]:
        raise ValueError("Le dépôt n'est pas sur une branche : rien n'est commité.")
    connus = {f["chemin"]: f for f in info["fichiers"]}
    chemins = [x for x in dict.fromkeys(chemins or []) if x]
    if not chemins:
        raise ValueError("Coche au moins un fichier.")
    inconnus = [x for x in chemins if x not in connus]
    if inconnus:
        raise ValueError("Fichiers qui ne sont plus modifiés (rafraîchis la liste) : " + ", ".join(inconnus[:5]))
    trop_gros = [x for x in chemins if connus[x]["octets"] > LIMITE_GITHUB]
    if trop_gros:
        raise ValueError("Trop gros pour GitHub (plus de 100 Mo), décoche-les : " + ", ".join(trop_gros[:5]))
    message = " ".join((message or "").split())[:200] or (
        f"Studio : {len(chemins)} fichier{'s' if len(chemins) > 1 else ''} — " + ", ".join(Path(x).stem for x in chemins[:3])
        + ("…" if len(chemins) > 3 else ""))
    liste = "\0".join(chemins) + "\0"
    ws._git(git, d, "add", "--pathspec-from-file=-", "--pathspec-file-nul", entree=liste, timeout=600)
    ws._git(git, d, "commit", "--no-verify", "-m", message, "--pathspec-from-file=-", "--pathspec-file-nul",
            entree=liste, timeout=600)
    sha = ws._git(git, d, "rev-parse", "--short", "HEAD").strip()
    return {"message": f"Commité sur {info['branche']} : {sha} — {message}. Rien n'est poussé vers GitHub.", "commit": sha}


def fusionner_branche(studio, cle: str, branche: str) -> dict:
    """Fusion d'une branche de tâche (studio/…) dans la branche courante : même chemin que le bouton de la tâche."""
    _cible(studio, cle)
    if not re.fullmatch(r"studio/T\d{8}-\d{6}-[0-9a-f]{6}", branche or ""):
        raise ValueError("Seules les branches des tâches du studio se fusionnent ici.")
    from . import actions
    return actions.fusionner(studio, branche[len("studio/"):])
