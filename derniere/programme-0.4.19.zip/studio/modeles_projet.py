"""Modèles de projet : « Créer un site », « Créer un jeu »… en un clic, l'équipe d'agents, le mode et le contexte de départ.

Un modèle ne fait que régler le projet (métiers actifs, mode, CONTEXTE.md de départ) : tout reste modifiable ensuite
dans l'onglet Équipe et la fiche du projet. Rien n'est téléchargé, rien n'est supprimé.
"""
from __future__ import annotations

MODELES = {
    "site": {
        "nom": "Site web", "type": "web", "profil": "normal",
        "roles": ["developpeur-web", "designer-ui", "ui-ux", "seo-contenu", "accessibilite", "qa", "producteur", "build-publication"],
        "contexte": "Site web. À préciser : public visé, pages principales, style souhaité, hébergement prévu.\n"
                    "Par défaut : HTML/CSS/JS simples, rapides et accessibles, qui marchent sur téléphone.",
    },
    "jeu": {
        "nom": "Jeu vidéo", "type": "code", "profil": "performance",
        "roles": ["game-designer", "programmeur", "level-designer", "directeur-artistique", "illustrateur", "sound-designer",
                  "scenariste", "equilibrage", "qa", "producteur"],
        "contexte": "Jeu vidéo. À préciser : moteur (Godot, Unity, Unreal, web…), genre, plateforme, ambiance.\n"
                    "Par défaut : une petite version jouable d'abord, puis on enrichit.",
    },
    "appli": {
        "nom": "Application ou logiciel", "type": "code", "profil": "normal",
        "roles": ["programmeur", "developpeur-web", "designer-ui", "ui-ux", "qa", "securite-donnees", "documentation", "producteur",
                  "build-publication"],
        "contexte": "Application ou logiciel. À préciser : ce qu'elle doit faire, pour qui, sur quel appareil, langage souhaité.\n"
                    "Par défaut : code simple et testé, un README pour l'installer et s'en servir.",
    },
    "document": {
        "nom": "Document ou étude", "type": "doc", "profil": "normal",
        "roles": ["chercheur", "documentation", "scenariste", "localisation", "producteur"],
        "contexte": "Document, étude ou recherche. À préciser : sujet, public, longueur, format attendu (Word, PDF, page web…).\n"
                    "Par défaut : sources citées, faits vérifiés, texte clair.",
    },
    "visuels": {
        "nom": "Images et visuels", "type": "art", "profil": "normal",
        "roles": ["directeur-artistique", "illustrateur", "artiste-technique", "technical-artist", "designer-ui", "producteur"],
        "contexte": "Images et visuels (illustrations, logos, concept arts, affiches). À préciser : usage, style, formats.\n"
                    "Par défaut : plusieurs pistes proposées avant de finaliser.",
    },
}


def liste() -> list[dict]:
    return [{"id": k, "nom": v["nom"]} for k, v in MODELES.items()]


def appliquer(studio, cible: str, modele: str) -> dict:
    """Règle un projet tout juste créé selon le modèle : métiers actifs, mode, contexte de départ."""
    from . import equipes
    m = MODELES.get(modele)
    if not m:
        raise ValueError("Modèle de projet inconnu.")
    t = studio.registry.get(cible)
    cle = f"{t.kind}:{t.id}"
    garder = set(m["roles"])
    d = equipes.lire(studio.paths.data)
    roles = d.setdefault(cle, {}).setdefault("roles", {})
    for r in studio.roles.values():
        if r.id == "auditeur" or (r.projets and cle not in r.projets):
            continue
        if r.id in garder:
            if roles.get(r.id) == {"actif": False}:
                roles.pop(r.id)
        else:
            roles[r.id] = {**roles.get(r.id, {}), "actif": False}
    equipes._ecrire(studio.paths.data, d)
    studio.set_profil_projet(cle, m["profil"])
    ctx = t.fichier.parent / "CONTEXTE.md" if t.fichier else None
    if ctx is not None and ctx.exists() and "À compléter par l'utilisateur" in ctx.read_text(encoding="utf-8"):
        ctx.write_text(f"# {t.nom}\n\n{m['contexte']}\n", encoding="utf-8")       # seulement le texte de départ, tout juste créé
    return {"modele": modele, "roles": sorted(garder & set(studio.roles)), "profil": m["profil"]}
