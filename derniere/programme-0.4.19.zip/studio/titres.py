"""Nom court d'une tâche : quelques mots clairs, la demande complète reste à côté.

Le Superviseur propose son propre titre (« titre » dans sa proposition). Sinon — tâche directe, chaîne, ancienne
tâche — le studio le tire de la demande : première phrase, sans « Objectif : », sans Markdown, 60 caractères au plus.
"""
from __future__ import annotations

import re

PREFIXES = r"(objectif|but|tâche|tache|demande|mission|contexte|résumé|resume|titre|todo|à faire|a faire)\s*[:：\-–—]\s*"


def sans_projet(t: str, noms: tuple[str, ...] = ()) -> str:
    """Retire le nom du projet (on voit déjà dans quel onglet on est) : « … sur RPG3D », « RPG3D : … »."""
    for n in sorted({x for x in noms if x and len(x) >= 2}, key=len, reverse=True):
        n = re.escape(n)
        t = re.sub(rf"\s*\b(sur|dans|de|du|pour|à|au)\s+(le\s+projet\s+|le\s+)?{n}\b", "", t, flags=re.I)
        t = re.sub(rf"^\s*{n}\s*[:：\-–—]\s*", "", t, flags=re.I)
        t = re.sub(rf"\s*\(\s*{n}\s*\)", "", t, flags=re.I)
    return " ".join(t.split()).strip(" ,;:-–—")


def titre_court(demande: str, maxi: int = 50, noms: tuple[str, ...] = ()) -> str:
    t = str(demande or "").split("\n\n---\n")[0]                       # rappel de chaîne : pour l'agent, pas pour le nom
    t = re.sub(r"[`*#>]+", "", t)
    t = re.sub(r"(?<!\w)_+|_+(?!\w)", "", t)  # garde L_Exploration
    t = re.sub(r"\$audit-(skills|memories)\s+audit\b.*", lambda m: "Audit des " + ("skills" if m.group(1) == "skills" else "mémoires"), t, flags=re.S)
    t = re.sub(r"\$audit-(skills|memories)\s+(fix|clean)\b.*", lambda m: "Appliquer l'audit des " + ("skills" if m.group(1) == "skills" else "mémoires"), t, flags=re.S)
    t = " ".join(t.split())
    t = re.sub(r"^" + PREFIXES, "", t, flags=re.I)
    m = re.match(r"(?:exécute|execute|fais|réalise|traite)\s+(?:la\s+)?tâche\s+(?:\S*[/\\])?([\w.-]+?)\.md\b", t, re.I)
    if m:                                       # « Exécute la tâche Tasks/Corriger-X.md » → « Corriger X »
        t = m.group(1).replace("-", " ").replace("_", " ")
    # première phrase ou première partie avant « Où : », « Contexte : »…
    t = re.split(r"(?<=[.!?])\s|\s(?:où|ou|contexte|lis|lire|cible|livrable|critères?|périmètre)\s*:\s", t, maxsplit=1, flags=re.I)[0]
    t = sans_projet(t.strip(" .;:-–—"), noms)
    if len(t) > maxi and 20 <= t.rfind(", ", 0, maxi + 1):
        t = t[:t.rfind(", ", 0, maxi + 1)]                      # une virgule avant la limite : on s'y arrête
    if len(t) > maxi:
        coupe = t[:maxi].rsplit(" ", 1)[0].rstrip(" ,;:-–—(")
        t = (coupe or t[:maxi]) + "…"
    return (t[:1].upper() + t[1:]) if t else "Tâche"
