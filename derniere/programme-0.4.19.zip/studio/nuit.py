"""Tâches de nuit : « Cette nuit » sur une proposition du Superviseur la met en file ; elle part seule pendant la plage
de nuit (réglage, 01:00 → 07:00 par défaut), puis un rapport attend dans la conversation générale le matin.

- Rien ne part en dehors de la plage ; le PC doit rester allumé et le studio ouvert (sinon la file attend la nuit
  suivante, rien n'est perdu).
- Les tâches lancées suivent le parcours normal (relecture, validation) : la nuit ne valide jamais rien à ta place.
- File : data/nuit.json (écriture atomique).
"""
from __future__ import annotations

import json
import os
import threading
import uuid
from datetime import datetime, timedelta
from pathlib import Path

_verrou = threading.Lock()
ETATS_FINIS = {"approuvee": "faite", "appliquee": "appliquée", "a_approuver": "à valider", "a_approuver_avec_defauts": "à valider (défauts)",
               "bloquee": "bloquée", "echec": "en échec", "annulee": "annulée", "interrompue": "interrompue"}


def _fichier(data: Path) -> Path:
    return Path(data) / "nuit.json"


def lire(data: Path) -> dict:
    try:
        d = json.loads(_fichier(data).read_text(encoding="utf-8"))
        if isinstance(d, dict):
            return {"file": list(d.get("file", [])), "lancees": list(d.get("lancees", [])), "rapports": list(d.get("rapports", []))}
    except (OSError, ValueError):
        pass
    return {"file": [], "lancees": [], "rapports": []}


def _ecrire(data: Path, d: dict) -> None:
    f = _fichier(data)
    f.parent.mkdir(parents=True, exist_ok=True)
    t = f.with_suffix(".tmp")
    t.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
    os.replace(t, f)


def plage(cfg: dict) -> tuple[str, str]:
    n = cfg.get("nuit") or {}
    return str(n.get("debut") or "01:00"), str(n.get("fin") or "07:00")


def _minutes(h: str) -> int:
    hh, _, mm = h.partition(":")
    return int(hh) * 60 + int(mm or 0)


def dans_la_nuit(cfg: dict, maintenant: datetime) -> bool:
    d, f = (_minutes(x) for x in plage(cfg))
    m = maintenant.hour * 60 + maintenant.minute
    return d <= m < f if d < f else (m >= d or m < f)


def nuit_de(cfg: dict, maintenant: datetime) -> str:
    """Date de la nuit en cours ou de la dernière nuit : le jour du soir où elle commence."""
    d = _minutes(plage(cfg)[0])
    m = maintenant.hour * 60 + maintenant.minute
    if d >= 12 * 60 and m >= d:                       # plage commencée ce soir (ex. 23:00)
        return maintenant.date().isoformat()
    return (maintenant.date() - timedelta(days=1)).isoformat()


def planifier(studio, rid: int, cible: str = "", demande: str = "", modele: str = "", mode: str = "", effort: str = "") -> dict:
    msg = next((m for m in studio.store.messages(500) if m["id"] == rid), None)
    if msg is None or not msg["proposition"] or msg["proposition"].get("etat") != "proposee":
        raise ValueError("Aucune proposition à mettre en file pour ce message.")
    p = dict(msg["proposition"])
    demande = (demande or p.get("demande", "")).strip()
    if not demande:
        raise ValueError("Demande vide.")
    e = {"id": uuid.uuid4().hex[:12], "rid": rid, "cible": cible or p.get("cible", ""), "demande": demande,
         "titre": p.get("titre", ""), "modele": modele, "mode": mode, "effort": effort,
         "ajoute": datetime.now().isoformat(timespec="seconds")}
    with _verrou:
        d = lire(studio.paths.data)
        d["file"].append(e)
        _ecrire(studio.paths.data, d)
    p.update(etat="nuit", nuit=e["id"], demande=demande, cible=e["cible"], modele_nuit=modele, mode_nuit=mode, effort_nuit=effort)
    studio.store.update_message(rid, proposition=p)
    return {"ok": True, "id": e["id"], "debut": plage(studio.cfg)[0]}


def retirer(studio, ident: str) -> dict:
    with _verrou:
        d = lire(studio.paths.data)
        e = next((x for x in d["file"] if x["id"] == ident), None)
        if not e:
            raise ValueError("Cette tâche n'est plus en file (déjà lancée ou retirée).")
        d["file"] = [x for x in d["file"] if x["id"] != ident]
        _ecrire(studio.paths.data, d)
    msg = next((m for m in studio.store.messages(500) if m["id"] == e["rid"]), None)
    if msg and msg["proposition"].get("etat") == "nuit":
        studio.store.update_message(e["rid"], proposition={**msg["proposition"], "etat": "proposee"})
    return {"ok": True}


def tic(studio, sup, lancer, maintenant: datetime | None = None) -> dict:
    """Appelé chaque minute : lance la file pendant la nuit ; après la nuit, écrit le rapport une seule fois."""
    maintenant = maintenant or datetime.now()
    fait = {"lancees": [], "rapport": False}
    nuit = dans_la_nuit(studio.cfg, maintenant)
    with _verrou:
        d = lire(studio.paths.data)
        a_lancer = d["file"] if nuit else []
        d["file"] = [] if nuit else d["file"]
        if a_lancer:
            _ecrire(studio.paths.data, d)
    for e in a_lancer:
        try:
            tid = sup.lancer(e["rid"], e["cible"], e["demande"], e.get("modele", ""), e.get("mode", ""), e.get("effort", ""),
                             depuis_nuit=True)
            lancer(tid)
            e.update(tid=tid, lancee=maintenant.isoformat(timespec="seconds"), nuit=nuit_de(studio.cfg, maintenant))
        except Exception as ex:                          # noqa: BLE001 — noté dans le rapport du matin
            e.update(erreur=str(ex)[:300], lancee=maintenant.isoformat(timespec="seconds"), nuit=nuit_de(studio.cfg, maintenant))
        fait["lancees"].append(e)
    with _verrou:
        d = lire(studio.paths.data)
        if fait["lancees"]:
            d["lancees"] = (d["lancees"] + fait["lancees"])[-200:]
        a_rapporter = sorted({x.get("nuit") for x in d["lancees"] if x.get("nuit")} - set(d["rapports"]))
        a_rapporter = [n for n in a_rapporter if not (nuit and n == nuit_de(studio.cfg, maintenant))]
        for n in a_rapporter:
            _rapport(studio, [x for x in d["lancees"] if x.get("nuit") == n])
            d["rapports"] = (d["rapports"] + [n])[-60:]
            fait["rapport"] = True
        if fait["lancees"] or a_rapporter:
            _ecrire(studio.paths.data, d)
    return fait


def _rapport(studio, lancees: list[dict]) -> None:
    lignes, liens = [], []
    for e in lancees:
        titre = e.get("titre") or e["demande"][:70]
        if e.get("erreur"):
            lignes.append(f"- **{titre}** : pas lancée ({e['erreur']})")
            continue
        try:
            t = studio.store.get(e["tid"])
            etat = ETATS_FINIS.get(t["status"], "encore en cours")
        except KeyError:
            etat = "introuvable"
        lignes.append(f"- **{titre}** : {etat}")
        liens.append({"tid": e["tid"], "titre": titre, "cible": e.get("cible", ""), "etat": etat})
    a_valider = sum(1 for x in liens if x["etat"].startswith("à valider"))
    texte = (f"### Rapport de la nuit\n{len(lancees)} tâche(s) lancée(s) pendant la nuit"
             + (f", **{a_valider} à valider**" if a_valider else "") + ".\n\n" + "\n".join(lignes))
    studio.store.message("superviseur", texte, proposition={"rapport_nuit": liens})
