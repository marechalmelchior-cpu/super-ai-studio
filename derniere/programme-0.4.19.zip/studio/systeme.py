"""Ressources du PC pour l'en-tête : processeur, mémoire vive, carte graphique (utilisation et mémoire vidéo).

- Aucune dépendance : API Windows (ctypes) ou /proc sous Linux ; carte graphique NVIDIA par nvidia-smi, sinon compteurs
  de performance de Windows (toutes marques) ; modèles chargés par Ollama (mémoire vidéo occupée par l'IA locale).
- Léger : un relevé de carte graphique au plus toutes les 4 s (dans un fil), seulement pendant que la page le demande ;
  le reste se lit en quelques microsecondes.
"""
from __future__ import annotations

import ctypes
import json
import os
import shutil
import subprocess
import sys
import threading
import time
import urllib.request

_etat = {"cpu": None, "gpu": {}, "ollama": [], "demande": 0.0, "fil": False}
_verrou = threading.Lock()
_SANS_FENETRE = 0x08000000 if sys.platform == "win32" else 0


# ------------------------------------------------------------------ processeur
def _temps_cpu() -> tuple[int, int] | None:
    """(inactif, total) cumulés."""
    if sys.platform == "win32":
        class FT(ctypes.Structure):
            _fields_ = [("l", ctypes.c_uint32), ("h", ctypes.c_uint32)]
        i, k, u = FT(), FT(), FT()
        if not ctypes.windll.kernel32.GetSystemTimes(ctypes.byref(i), ctypes.byref(k), ctypes.byref(u)):
            return None
        v = lambda f: (f.h << 32) | f.l                                  # noqa: E731
        return v(i), v(k) + v(u)                                          # le temps noyau inclut l'inactif
    if sys.platform == "darwin":                                          # Mac : compteurs du noyau (host_statistics)
        try:
            lib = ctypes.CDLL("/usr/lib/libSystem.dylib")
            t, n = (ctypes.c_uint32 * 4)(), ctypes.c_uint32(4)                # user, system, idle, nice
            if lib.host_statistics(lib.mach_host_self(), 3, ctypes.byref(t), ctypes.byref(n)) != 0:
                return None
            return t[2], sum(t)
        except (OSError, AttributeError):
            return None
    try:
        with open("/proc/stat", encoding="ascii") as f:
            n = [int(x) for x in f.readline().split()[1:]]
        return n[3] + (n[4] if len(n) > 4 else 0), sum(n)
    except (OSError, ValueError):
        return None


def cpu() -> float | None:
    t = _temps_cpu()
    if t is None:
        return None
    with _verrou:
        avant, _etat["cpu"] = _etat["cpu"], t
    if not avant or t[1] <= avant[1]:
        return None
    return round(100 * (1 - (t[0] - avant[0]) / (t[1] - avant[1])), 1)


# ------------------------------------------------------------------ mémoire vive
def ram() -> dict:
    if sys.platform == "win32":
        class MS(ctypes.Structure):
            _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong), ("total", ctypes.c_ulonglong),
                        ("libre", ctypes.c_ulonglong), ("a", ctypes.c_ulonglong), ("b", ctypes.c_ulonglong),
                        ("c", ctypes.c_ulonglong), ("d", ctypes.c_ulonglong), ("e", ctypes.c_ulonglong)]
        m = MS()
        m.dwLength = ctypes.sizeof(MS)
        if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m)):
            return {"total_go": round(m.total / 2**30, 1), "utilise_go": round((m.total - m.libre) / 2**30, 1)}
        return {}
    if sys.platform == "darwin":                                          # Mac : sysctl (total) et vm_stat (pages occupées)
        try:
            import re
            import subprocess
            total = int(subprocess.run(["sysctl", "-n", "hw.memsize"], capture_output=True, text=True, timeout=3).stdout.strip())
            vm = subprocess.run(["vm_stat"], capture_output=True, text=True, timeout=3).stdout
            page = int((re.search(r"page size of (\d+)", vm) or [0, 16384])[1])
            pages = lambda nom: int((re.search(rf"{nom}:\s+(\d+)", vm) or [0, 0])[1])   # noqa: E731
            utilise = (pages("Pages active") + pages("Pages wired down") + pages("Pages occupied by compressor")) * page
            return {"total_go": round(total / 2**30, 1), "utilise_go": round(utilise / 2**30, 1)}
        except (OSError, ValueError, subprocess.SubprocessError):
            return {}
    try:
        info = {}
        with open("/proc/meminfo", encoding="ascii") as f:
            for l in f:
                k, v = l.split(":", 1)
                info[k] = int(v.split()[0]) * 1024
        total, dispo = info["MemTotal"], info.get("MemAvailable", info.get("MemFree", 0))
        return {"total_go": round(total / 2**30, 1), "utilise_go": round((total - dispo) / 2**30, 1)}
    except (OSError, ValueError, KeyError):
        return {}


# ------------------------------------------------------------------ carte graphique (fil, toutes les 4 s)
def _nvidia() -> dict:
    exe = shutil.which("nvidia-smi")
    if not exe:
        return {}
    r = subprocess.run([exe, "--query-gpu=name,utilization.gpu,memory.used,memory.total", "--format=csv,noheader,nounits"],
                       capture_output=True, text=True, timeout=4, creationflags=_SANS_FENETRE)
    l = (r.stdout or "").strip().splitlines()
    if r.returncode or not l:
        return {}
    nom, util, used, total = [x.strip() for x in l[0].split(",")][:4]
    return {"nom": nom, "util": float(util), "vram_go": round(float(used) / 1024, 1), "vram_total_go": round(float(total) / 1024, 1)}


class _CompteursWindows:
    """Toutes marques (AMD, Intel, NVIDIA) : compteurs de performance de Windows lus par l'API PDH, avec les noms
    anglais (fonctionne sur un Windows en français), sans lancer de programme. Requête ouverte une fois, relue à chaque tour."""
    FMT_DOUBLE, PLUS = 0x200, 0x800007D2

    def __init__(self):
        self.pdh = ctypes.windll.pdh
        self.q = ctypes.c_void_p()
        if self.pdh.PdhOpenQueryW(None, 0, ctypes.byref(self.q)) != 0:
            raise OSError("PDH indisponible")
        self.util, self.mem = ctypes.c_void_p(), ctypes.c_void_p()
        self.pdh.PdhAddEnglishCounterW(self.q, "\\GPU Engine(*engtype_3D)\\Utilization Percentage", 0, ctypes.byref(self.util))
        self.pdh.PdhAddEnglishCounterW(self.q, "\\GPU Adapter Memory(*)\\Dedicated Usage", 0, ctypes.byref(self.mem))
        self.pdh.PdhCollectQueryData(self.q)                  # premier relevé : base de calcul

    def _valeurs(self, c) -> list[float]:
        class Valeur(ctypes.Structure):
            _fields_ = [("statut", ctypes.c_ulong), ("double", ctypes.c_double)]

        class Element(ctypes.Structure):
            _fields_ = [("nom", ctypes.c_wchar_p), ("valeur", Valeur)]
        taille, n = ctypes.c_ulong(0), ctypes.c_ulong(0)
        r = self.pdh.PdhGetFormattedCounterArrayW(c, self.FMT_DOUBLE, ctypes.byref(taille), ctypes.byref(n), None)
        if r not in (0, self.PLUS) or not taille.value:
            return []
        buf = (ctypes.c_byte * taille.value)()
        if self.pdh.PdhGetFormattedCounterArrayW(c, self.FMT_DOUBLE, ctypes.byref(taille), ctypes.byref(n), buf) != 0:
            return []
        el = ctypes.cast(buf, ctypes.POINTER(Element))
        return [el[i].valeur.double for i in range(n.value) if el[i].valeur.statut in (0, 1)]

    def lire(self) -> dict:
        if self.pdh.PdhCollectQueryData(self.q) != 0:
            return {}
        util, mem = self._valeurs(self.util), self._valeurs(self.mem)
        if not util and not mem:
            return {}
        return {"util": round(min(sum(util), 100.0), 1), "vram_go": round(max(mem or [0]) / 2**30, 1)}


def _ollama() -> list[dict]:
    try:
        with urllib.request.urlopen("http://127.0.0.1:11434/api/ps", timeout=1) as r:
            d = json.loads(r.read() or b"{}")
        return [{"nom": m.get("name", ""), "vram_go": round((m.get("size_vram") or 0) / 2**30, 1)} for m in d.get("models", [])]
    except (OSError, ValueError):
        return []


def _fil() -> None:
    compteurs = None
    if sys.platform == "win32" and not shutil.which("nvidia-smi"):
        try:
            compteurs = _CompteursWindows()
        except Exception:                                # noqa: BLE001 — pas de compteur : carte graphique non affichée
            compteurs = None
    while time.time() - _etat["demande"] < 30:           # personne ne regarde depuis 30 s : le fil s'arrête
        try:
            g = _nvidia() or (compteurs.lire() if compteurs else {})
        except Exception:                                # noqa: BLE001
            g = {}
        o = _ollama()
        with _verrou:
            _etat["gpu"], _etat["ollama"] = g, o
        time.sleep(4)
    with _verrou:
        _etat["fil"] = False


def releve() -> dict:
    """Ce que l'en-tête affiche ; lance le fil des relevés lents s'il dort."""
    with _verrou:
        _etat["demande"] = time.time()
        lancer = not _etat["fil"]
        _etat["fil"] = True
    if lancer:
        threading.Thread(target=_fil, daemon=True).start()
    with _verrou:
        gpu, ollama = dict(_etat["gpu"]), list(_etat["ollama"])
    return {"cpu": cpu(), "coeurs": os.cpu_count(), "ram": ram(), "gpu": gpu, "ollama": ollama}
