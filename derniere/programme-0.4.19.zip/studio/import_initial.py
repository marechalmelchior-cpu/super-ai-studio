"""Reprise des skills et instructions déjà présents sur le PC : une COPIE dans le studio, puis le studio s'en occupe.

- Sources : skills de Claude Code (~/.claude/skills) et de Codex (~/.agents/skills, ~/.codex/skills) ; instructions
  globales ~/.claude/CLAUDE.md et ~/.codex/AGENTS.md.
- Copie dans l'espace du studio : Skills/<nom>/ (et Regles/importes/ pour les .md). Les originaux ne sont jamais
  modifiés, déplacés ni supprimés : l'utilisateur les retire lui-même s'il le souhaite.
- Rien n'est écrasé : nom déjà pris dans le studio → « <nom>-importe ». Les copies faites par le studio (« studio-… »)
  et les liens ne sont pas repris. Une seule fois automatiquement (data/import-initial.json), ensuite sur demande.
"""
from __future__ import annotations

import json
import shutil
import time
from pathlib import Path

SOURCES_SKILLS = (".claude/skills", ".agents/skills", ".codex/skills")
SOURCES_MD = ((".claude/CLAUDE.md", "CLAUDE (Claude Code).md"), (".codex/AGENTS.md", "AGENTS (Codex).md"))
MARQUE_STUDIO = "genere-par-ai-workspace"
IGNORES = shutil.ignore_patterns("__pycache__", "node_modules", ".git", "*.pyc")
MAX_SKILL_OCTETS = 50 * 2**20
FICHE = ".import.json"


def _taille(d: Path) -> int:
    total = 0
    for p in d.rglob("*"):
        try:
            if p.is_file() and not p.is_symlink():
                total += p.stat().st_size
        except OSError:
            pass
    return total


def _de_studio(d: Path) -> bool:
    if d.name.startswith("studio-"):
        return True
    try:
        return MARQUE_STUDIO in (d / "SKILL.md").read_text(encoding="utf-8", errors="replace")[:2000]
    except OSError:
        return False


def importer(racine: Path, home: Path | None = None) -> dict:
    """Copie ce qui n'est pas encore dans le studio. Renvoie {skills, instructions, ignores}."""
    racine, home = Path(racine), Path(home or Path.home())
    dest_skills = racine / "Skills"
    dest_skills.mkdir(parents=True, exist_ok=True)
    rapport = {"skills": [], "instructions": [], "ignores": []}
    deja: dict[str, Path] = {}                       # contenu SKILL.md → skill du studio (même skill vue chez Claude et Codex)
    for d in dest_skills.iterdir():
        f = d / FICHE
        if f.is_file():
            try:
                for o in json.loads(f.read_text(encoding="utf-8")).get("origines", []):
                    deja[o] = d
            except (OSError, ValueError):
                pass
    contenus: dict[str, Path] = {}
    for rel in SOURCES_SKILLS:
        base = home / rel
        if not base.is_dir():
            continue
        for d in sorted(base.iterdir()):
            try:
                if d.is_symlink() or not d.is_dir() or not (d / "SKILL.md").is_file() or _de_studio(d):
                    continue
                origine = str(d)
                if origine in deja:
                    continue
                texte = (d / "SKILL.md").read_text(encoding="utf-8", errors="replace")
                if texte in contenus:                 # même skill déjà copiée depuis l'autre outil : on note l'origine
                    cible = contenus[texte]
                    _ajouter_origine(cible, origine)
                    continue
                if _taille(d) > MAX_SKILL_OCTETS:
                    rapport["ignores"].append(f"{d.name} (plus de 50 Mo)")
                    continue
                nom, n = d.name, 1
                cible = dest_skills / nom
                while cible.exists():
                    if (cible / "SKILL.md").is_file() and (cible / "SKILL.md").read_text(encoding="utf-8", errors="replace") == texte:
                        break                         # déjà la même skill dans le studio : rien à copier
                    n += 1
                    cible = dest_skills / (f"{d.name}-importe" if n == 2 else f"{d.name}-importe-{n - 1}")
                if cible.exists():
                    _ajouter_origine(cible, origine)
                    contenus[texte] = cible
                    continue
                shutil.copytree(d, cible, symlinks=False, ignore=IGNORES, ignore_dangling_symlinks=True)
                _ajouter_origine(cible, origine)
                h, recent = empreinte_dossier(cible)
                fiche = _fiche(cible)
                fiche.update(empreinte=h, date_origine=date_dossier(d))
                _ecrire_fiche(cible, fiche)
                contenus[texte] = cible
                rapport["skills"].append(cible.name)
            except OSError as e:
                rapport["ignores"].append(f"{d.name} ({type(e).__name__})")
    dest_md = racine / "Regles" / "importes"
    for rel, nom in SOURCES_MD:
        src = home / rel
        cible = dest_md / nom
        try:
            if src.is_file() and not cible.exists():
                dest_md.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src, cible)
                rapport["instructions"].append(nom)
        except OSError as e:
            rapport["ignores"].append(f"{rel} ({type(e).__name__})")
    return rapport


def _ajouter_origine(skill: Path, origine: str) -> None:
    f = skill / FICHE
    try:
        d = json.loads(f.read_text(encoding="utf-8")) if f.exists() else {}
    except (OSError, ValueError):
        d = {}
    d.setdefault("importe", time.strftime("%Y-%m-%d %H:%M"))
    d["origines"] = sorted(set(d.get("origines", [])) | {origine})
    f.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")


def importer_une_fois(racine: Path, data: Path, home: Path | None = None) -> dict | None:
    """Au premier lancement (ou à la première ouverture après la mise à jour) : une seule fois."""
    marque = Path(data) / "import-initial.json"
    if marque.exists():
        return None
    r = importer(racine, home)
    marque.parent.mkdir(parents=True, exist_ok=True)
    marque.write_text(json.dumps({"date": time.strftime("%Y-%m-%d %H:%M"), **r}, ensure_ascii=False, indent=1), encoding="utf-8")
    return r


def origines(skill: Path) -> set[str]:
    try:
        return set(json.loads((Path(skill) / FICHE).read_text(encoding="utf-8")).get("origines", []))
    except (OSError, ValueError):
        return set()


# ------------------------------------------------------------------ suivi des originaux après la copie
def empreinte_dossier(d: Path) -> tuple[str, float]:
    """(empreinte du contenu, date la plus récente) d'une skill, sans la fiche du studio ni les fichiers lourds ignorés."""
    import hashlib
    h, recent = hashlib.sha256(), 0.0
    for p in sorted(Path(d).rglob("*")):
        rel = p.relative_to(d).as_posix()
        if not p.is_file() or p.name == FICHE or any(x in ("__pycache__", "node_modules", ".git") for x in p.parts):
            continue
        try:
            st = p.stat()
            recent = max(recent, st.st_mtime)
            h.update(rel.encode() + b"\0" + hashlib.sha256(p.read_bytes()).digest())
        except OSError:
            continue
    return h.hexdigest()[:24], recent


def date_dossier(d: Path) -> float:
    """Date la plus récente d'une skill : quelques stat(), aucun fichier lu."""
    recent = 0.0
    for p in Path(d).rglob("*"):
        if p.name == FICHE or any(x in ("__pycache__", "node_modules", ".git") for x in p.parts):
            continue
        try:
            if p.is_file():
                recent = max(recent, p.stat().st_mtime)
        except OSError:
            pass
    return recent


def _fiche(skill: Path) -> dict:
    try:
        return json.loads((skill / FICHE).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def _ecrire_fiche(skill: Path, d: dict) -> None:
    (skill / FICHE).write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")


def _remplacer_copie(racine: Path, skill: Path, origine: Path) -> None:
    """Mise à jour SUR PLACE de la copie du studio d'après l'original : fichiers nouveaux ou changés recopiés, fichiers
    disparus de l'original retirés de la copie. Aucune autre copie n'est faite (pas d'archive à chaque mise à jour)."""
    fiche = _fiche(skill)
    ignores = ("__pycache__", "node_modules", ".git")
    voulus = set()
    for p in Path(origine).rglob("*"):
        if p.is_symlink() or not p.is_file() or any(x in ignores for x in p.parts) or p.suffix == ".pyc":
            continue
        rel = p.relative_to(origine)
        voulus.add(rel.as_posix())
        d = skill / rel
        try:
            if d.is_file() and d.stat().st_size == p.stat().st_size and d.read_bytes() == p.read_bytes():
                continue
            d.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(p, d)
        except OSError:
            pass
    for p in sorted(skill.rglob("*"), reverse=True):        # ce que l'original n'a plus (sauf la fiche du studio)
        rel = p.relative_to(skill).as_posix()
        try:
            if p.is_file() and p.name != FICHE and rel not in voulus:
                p.unlink()
            elif p.is_dir() and not any(p.iterdir()):
                p.rmdir()
        except OSError:
            pass
    h, recent = empreinte_dossier(skill)
    fiche.update(empreinte=h, date_origine=date_dossier(origine), maj=time.strftime("%Y-%m-%d %H:%M"))
    fiche.pop("conflit", None)
    fiche.pop("conflit_origine", None)
    _ecrire_fiche(skill, fiche)


def suivre(racine: Path, data: Path | None = None, home: Path | None = None) -> dict:
    """Skills et instructions reprises du PC : si l'original a changé hors du studio, RIEN n'est remplacé tout seul :
    une mise à jour est proposée (« Mettre à jour dans le studio » / « Garder la version du studio »), une seule fois
    par version. Rapide : un original n'est relu que si sa date a changé."""
    rapport = {"propositions": []}
    base = Path(racine) / "Skills"
    for skill in (sorted(base.iterdir()) if base.is_dir() else []):
        fiche = _fiche(skill)
        if not fiche.get("origines"):
            continue
        existants = [Path(o) for o in fiche["origines"] if (Path(o) / "SKILL.md").is_file()]
        if not existants:
            continue
        if "empreinte" not in fiche:                       # skill reprise avant le suivi : point de départ = maintenant
            fiche.update(empreinte=empreinte_dossier(skill)[0], date_origine=max(date_dossier(o) for o in existants))
            _ecrire_fiche(skill, fiche)
            continue
        dates = {o: date_dossier(o) for o in existants}
        origine = max(existants, key=dates.get)
        if dates[origine] <= float(fiche.get("date_origine", 0)):
            continue                                       # original pas touché : rien à lire
        h_orig, recent = empreinte_dossier(origine)
        fiche["date_origine"] = recent
        if h_orig not in (fiche["empreinte"], fiche.get("refusee")) and (fiche.get("proposition") or {}).get("empreinte") != h_orig:
            deux = empreinte_dossier(skill)[0] != fiche["empreinte"]          # modifiée aussi dans le studio
            fiche["proposition"] = {"empreinte": h_orig, "origine": str(origine), "deux_cotes": deux}
            rapport["propositions"].append(f"skill « {skill.name} »")
        _ecrire_fiche(skill, fiche)
    if data is not None:                                   # CLAUDE.md / AGENTS.md repris
        rapport["propositions"] += _suivre_md(Path(racine), Path(data), Path(home or Path.home()))
    return rapport


def _suivi_md(data: Path) -> dict:
    try:
        return json.loads((data / "import-md.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def _suivre_md(racine: Path, data: Path, home: Path) -> list[str]:
    import hashlib
    suivi, change, out = _suivi_md(data), False, []
    for rel, nom in SOURCES_MD:
        src, copie = home / rel, racine / "Regles" / "importes" / nom
        if not src.is_file() or not copie.is_file():
            continue
        e = suivi.get(nom)
        try:
            mt = src.stat().st_mtime
            if e is None:                                  # point de départ : la copie actuelle
                suivi[nom] = {"empreinte": hashlib.sha256(copie.read_bytes()).hexdigest()[:24], "date": mt}
                change = True
                continue
            if mt <= e.get("date", 0):
                continue
            h = hashlib.sha256(src.read_bytes()).hexdigest()[:24]
            e["date"] = mt
            change = True
            if h not in (e["empreinte"], e.get("refusee")) and (e.get("proposition") or {}).get("empreinte") != h:
                e["proposition"] = {"empreinte": h, "origine": str(src),
                                    "deux_cotes": hashlib.sha256(copie.read_bytes()).hexdigest()[:24] != e["empreinte"]}
                out.append(f"instructions « {nom} »")
        except OSError:
            continue
    if change:
        (data / "import-md.json").write_text(json.dumps(suivi, ensure_ascii=False, indent=1), encoding="utf-8")
    return out


def propositions(racine: Path, data: Path | None = None) -> list[dict]:
    """Mises à jour en attente de la réponse de l'utilisateur."""
    out = []
    base = Path(racine) / "Skills"
    for skill in (sorted(base.iterdir()) if base.is_dir() else []):
        p = _fiche(skill).get("proposition")
        if p:
            out.append({"id": f"skill:{skill.name}", "nom": skill.name, "genre": "skill", "origine": p["origine"],
                        "deux_cotes": bool(p.get("deux_cotes"))})
    for nom, e in (_suivi_md(Path(data)) if data is not None else {}).items():
        p = e.get("proposition")
        if p:
            out.append({"id": f"md:{nom}", "nom": nom, "genre": "instructions", "origine": p["origine"],
                        "deux_cotes": bool(p.get("deux_cotes"))})
    return out


def resoudre(racine: Path, ident: str, choix: str, data: Path | None = None) -> dict:
    """« original » : le studio prend la version du dossier d'origine (mise à jour sur place) ;
    « studio » : on garde la version du studio et on ne redemande plus pour CETTE version de l'original."""
    import hashlib
    genre, _, nom = ident.partition(":")
    if not nom or "/" in nom or "\\" in nom or ".." in nom:
        raise ValueError("Élément inconnu.")
    if genre == "skill":
        skill = Path(racine) / "Skills" / nom
        f = _fiche(skill)
        p = f.get("proposition")
        if not p:
            raise ValueError("Aucune mise à jour en attente pour cette skill.")
        if choix == "original":
            if not (Path(p["origine"]) / "SKILL.md").is_file():
                raise ValueError("L'original n'existe plus.")
            _remplacer_copie(racine, skill, Path(p["origine"]))
            f = _fiche(skill)
            f.pop("proposition", None)
            _ecrire_fiche(skill, f)
            return {"ok": True, "message": f"Skill {nom} mise à jour dans le studio."}
        f.pop("proposition", None)
        f["refusee"] = p["empreinte"]
        _ecrire_fiche(skill, f)
        return {"ok": True, "message": f"Skill {nom} : la version du studio est gardée."}
    if genre == "md" and data is not None:
        suivi = _suivi_md(Path(data))
        e = suivi.get(nom) or {}
        p = e.get("proposition")
        if not p:
            raise ValueError("Aucune mise à jour en attente pour ce fichier.")
        copie = Path(racine) / "Regles" / "importes" / nom
        if choix == "original":
            shutil.copy2(p["origine"], copie)
            e["empreinte"] = hashlib.sha256(copie.read_bytes()).hexdigest()[:24]
            msg = f"{nom} mis à jour dans le studio."
        else:
            msg = f"{nom} : la version du studio est gardée."
        e.pop("proposition", None)
        e["refusee"] = p["empreinte"]
        (Path(data) / "import-md.json").write_text(json.dumps(suivi, ensure_ascii=False, indent=1), encoding="utf-8")
        return {"ok": True, "message": msg}
    raise ValueError("Élément inconnu.")
