"""Accès au studio depuis le téléphone, par Tailscale (réseau privé chiffré entre les appareils de l'utilisateur).

- Le studio n'écoute toujours que 127.0.0.1 : rien n'est ouvert sur le réseau local ni sur Internet.
- Quand l'utilisateur active « Accès depuis le téléphone » (Gestion › Réglages), le lanceur demande à Tailscale de relayer
  https://<nom-du-pc>.<réseau>.ts.net vers le studio (``tailscale serve``, au premier plan : le relais s'arrête avec le
  studio, aucune configuration permanente n'est laissée). Seuls les appareils du compte Tailscale de l'utilisateur y accèdent.
- Un téléphone s'associe une fois (Superviseur › Réglages › Téléphone : code à 6 chiffres à taper sur le téléphone) : il
  reçoit une clé d'appareil (cookie),
  gardée seulement sous forme d'empreinte dans data/appareils.json, révocable à tout moment.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import secrets
import shutil
import subprocess
import sys
import threading
from datetime import datetime, timezone
from pathlib import Path

COOKIE_APPAREIL = "studio_appareil"
_hotes: set[str] = set()                  # noms autorisés en plus de 127.0.0.1 (relais Tailscale actif)
_verrou = threading.Lock()


def tailscale_exe() -> str | None:
    p = Path(r"C:\Program Files\Tailscale\tailscale.exe")
    return str(p) if p.is_file() else shutil.which("tailscale")


def etat_tailscale(exe: str | None = None) -> dict:
    """Lecture seule : Tailscale connecté ? nom du PC dans le réseau ? certificats HTTPS activés ?"""
    exe = exe or tailscale_exe()
    if not exe:
        return {"ok": False, "info": "Tailscale n'est pas installé sur ce PC."}
    from .connectors.base import SANS_FENETRE
    try:
        r = subprocess.run([exe, "status", "--json"], capture_output=True, text=True, encoding="utf-8", errors="replace",
                           timeout=20, stdin=subprocess.DEVNULL, **SANS_FENETRE)
        d = json.loads(r.stdout or "{}")
    except (OSError, subprocess.TimeoutExpired, ValueError):
        return {"ok": False, "info": "Tailscale ne répond pas."}
    dns = str((d.get("Self") or {}).get("DNSName") or "").rstrip(".")
    if d.get("BackendState") != "Running" or not dns:
        return {"ok": False, "info": "Tailscale n'est pas connecté : clique sur son icône près de l'horloge, puis Log in."}
    if not d.get("CertDomains"):
        return {"ok": False, "dns": dns, "info": "Active « HTTPS Certificates » sur login.tailscale.com/admin/dns."}
    return {"ok": True, "dns": dns, "info": f"https://{dns}"}


def autoriser_hote(dns: str) -> None:
    with _verrou:
        _hotes.update({dns, f"{dns}:443"})


def hote_autorise(host: str) -> bool:
    with _verrou:
        return host in _hotes


def hote_distant() -> str:
    with _verrou:
        return next((h for h in _hotes if ":" not in h), "")


_relais: dict = {"p": None, "journal": None}


def _appli_ouverte(nom: str) -> bool:
    if sys.platform != "win32":
        return False
    from .connectors.base import SANS_FENETRE
    try:
        r = subprocess.run(["tasklist", "/FI", f"IMAGENAME eq {nom}", "/NH"], capture_output=True, text=True, timeout=10,
                           stdin=subprocess.DEVNULL, errors="replace", **SANS_FENETRE)
        return nom.lower() in r.stdout.lower()
    except (OSError, subprocess.TimeoutExpired):
        return False


def connecter_tailscale(note=lambda m: None, attente_s: float = 30.0) -> dict:
    """À l'ouverture du studio : ouvre l'application Tailscale si elle est fermée et reconnecte le PC au réseau
    (``tailscale up``, comme l'utilisateur l'a fait à la main). Aucun réglage de Tailscale n'est modifié. Renvoie l'état."""
    import time
    e = etat_tailscale()
    exe = tailscale_exe()
    if e["ok"] or not exe:
        return e
    from .connectors.base import SANS_FENETRE
    ipn = Path(exe).with_name("tailscale-ipn.exe")
    if sys.platform == "win32" and ipn.is_file() and not _appli_ouverte(ipn.name):
        try:
            subprocess.Popen([str(ipn)], stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                             close_fds=True, creationflags=getattr(subprocess, "DETACHED_PROCESS", 0x8))
            note("accès téléphone : application Tailscale ouverte")
            time.sleep(3)
        except OSError:
            pass
    try:
        r = subprocess.run([exe, "up", "--timeout=25s"], capture_output=True, text=True, encoding="utf-8", errors="replace",
                           timeout=40, stdin=subprocess.DEVNULL, **SANS_FENETRE)
        sortie = (r.stdout or "") + (r.stderr or "")
    except (OSError, subprocess.TimeoutExpired):
        sortie = ""
    if "login.tailscale.com" in sortie or "NeedsLogin" in sortie:
        return {"ok": False, "info": "Tailscale demande de te reconnecter : clique sur son icône près de l'horloge, puis Log in."}
    fin = time.monotonic() + attente_s
    while time.monotonic() < fin:
        e = etat_tailscale()
        if e["ok"] or e.get("dns"):
            return e
        time.sleep(2)
    if "requires mentioning all" in sortie:
        e["info"] = "Tailscale refuse la reconnexion automatique : clique sur son icône près de l'horloge, puis Connect."
    return e


def demarrer_relais(port: int, journaux: Path | None = None, note=lambda m: None) -> dict:
    """``tailscale serve`` au premier plan vers le studio (s'arrête avec lui, rien de permanent). Tailscale fermé ou
    déconnecté : il est rouvert et reconnecté d'abord. Renvoie l'état (ok, info, dns)."""
    e = connecter_tailscale(note)
    if not e["ok"]:
        note(f"accès téléphone : {e['info']}")
        return e
    with _verrou:
        p = _relais["p"]
        if p is not None and p.poll() is None:
            return e
    from .connectors.base import SANS_FENETRE
    journal = Path(journaux) / "tailscale-serve.log" if journaux else None
    try:
        sortie = open(journal, "w", encoding="utf-8") if journal else subprocess.DEVNULL
        p = subprocess.Popen([tailscale_exe(), "serve", "--https=443", f"http://127.0.0.1:{port}"], stdin=subprocess.DEVNULL,
                             stdout=sortie, stderr=subprocess.STDOUT, **SANS_FENETRE)
    except OSError as x:
        note(f"accès téléphone : relais impossible ({type(x).__name__})")
        return {"ok": False, "info": "Le relais Tailscale n'a pas pu démarrer."}
    with _verrou:
        _relais.update(p=p, journal=journal)
    autoriser_hote(e["dns"])
    note(f"accès téléphone : https://{e['dns']}")
    return e


def relais_actif() -> bool:
    with _verrou:
        p = _relais["p"]
    return p is not None and p.poll() is None


def couper_relais() -> None:
    with _verrou:
        p, _relais["p"] = _relais["p"], None
        _hotes.clear()
    if p is not None and p.poll() is None:
        p.terminate()
        try:
            p.wait(timeout=5)
        except subprocess.TimeoutExpired:
            p.kill()


def etat_relais() -> dict:
    """actif ? et, si Tailscale demande d'autoriser « Serve » sur le réseau, le lien qu'il donne."""
    import re
    with _verrou:
        p, journal = _relais["p"], _relais["journal"]
    actif = p is not None and p.poll() is None
    lien, texte = "", ""
    if journal:
        try:
            texte = Path(journal).read_text(encoding="utf-8", errors="replace")[-4000:]
        except OSError:
            texte = ""
        m = re.search(r"https://login\.tailscale\.com/\S+", texte)
        lien = m.group(0) if m else ""
    return {"actif": actif, "autoriser": lien, "erreur": "" if actif or not texte else texte.strip().splitlines()[-1][:200]}


# ---------------------------------------------------------------- code d'association (6 chiffres, 10 min, 5 essais)
_code: dict = {}


def nouveau_code(nom: str = "") -> dict:
    import time
    c = f"{secrets.randbelow(1_000_000):06d}"
    with _verrou:
        _code.clear()
        _code.update(code=c, nom=(nom or "Téléphone").strip()[:40], fin=time.time() + 600, essais=0)
    return {"code": c, "minutes": 10}


def utiliser_code(data: Path, saisi: str) -> str | None:
    """Clé d'appareil si le code est bon (il ne sert qu'une fois) ; None sinon (5 erreurs : le code est annulé)."""
    import time
    saisi = "".join(ch for ch in str(saisi) if ch.isdigit())
    with _verrou:
        if not _code or time.time() > _code["fin"]:
            _code.clear()
            return None
        if not hmac.compare_digest(saisi, _code["code"]):
            _code["essais"] += 1
            if _code["essais"] >= 5:
                _code.clear()
            return None
        nom = _code["nom"]
        _code.clear()
    return associer(data, nom)


def code_en_cours() -> bool:
    import time
    with _verrou:
        return bool(_code) and time.time() <= _code["fin"]


# ---------------------------------------------------------------- appareils associés
def _fichier(data: Path) -> Path:
    return Path(data) / "appareils.json"


def _empreinte(cle: str) -> str:
    return hashlib.sha256(cle.encode()).hexdigest()


def appareils(data: Path) -> list[dict]:
    try:
        l = json.loads(_fichier(data).read_text(encoding="utf-8"))
        return [a for a in l if isinstance(a, dict) and a.get("id") and a.get("empreinte")]
    except (OSError, ValueError):
        return []


def _ecrire(data: Path, l: list[dict]) -> None:
    f = _fichier(data)
    f.with_suffix(".partiel").write_text(json.dumps(l, ensure_ascii=False, indent=1), encoding="utf-8")
    f.with_suffix(".partiel").replace(f)


def associer(data: Path, nom: str) -> str:
    """Nouvelle clé d'appareil (montrée une seule fois, dans le lien) ; seule son empreinte est gardée."""
    cle = secrets.token_urlsafe(32)
    with _verrou:
        l = appareils(data)
        l.append({"id": secrets.token_hex(4), "nom": (nom or "Téléphone").strip()[:40], "empreinte": _empreinte(cle),
                  "cree": datetime.now(timezone.utc).isoformat(timespec="seconds"), "vu": ""})
        _ecrire(data, l)
    return cle


def verifier(data: Path, cle: str) -> bool:
    if not cle:
        return False
    e = _empreinte(cle)
    with _verrou:
        l = appareils(data)
        for a in l:
            if hmac.compare_digest(a["empreinte"], e):
                maintenant = datetime.now(timezone.utc).isoformat(timespec="minutes")
                if a.get("vu") != maintenant:
                    a["vu"] = maintenant
                    _ecrire(data, l)
                return True
    return False


def revoquer(data: Path, ident: str) -> None:
    with _verrou:
        _ecrire(data, [a for a in appareils(data) if a["id"] != ident])


def public(data: Path) -> list[dict]:
    return [{k: a.get(k, "") for k in ("id", "nom", "cree", "vu")} for a in appareils(data)]
