"""Résolution des emplacements du studio.

Racine (l'« espace ») : voir ``studio/espace.py`` — STUDIO_HOME, sinon le pointeur de l'utilisateur, sinon le dossier
parent de ``Studio`` (disposition historique). Le programme (``code``) peut être installé ailleurs que l'espace.
Aucun chemin de projet n'est déduit ici : les projets sont déclarés dans le registre.
"""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class StudioPaths:
    root: Path

    # Rangement maj75 : noms français, lisibles ; le technique est dans Studio\, l'ancien dans Archives\.
    @property
    def global_dir(self) -> Path: return self.root / "Regles"
    @property
    def skills(self) -> Path: return self.root / "Skills"          # nom gardé : Claude Code et Codex le lisent
    @property
    def projects(self) -> Path: return self.root / "Projets"
    @property
    def topics(self) -> Path: return self.root / "Sujets"
    @property
    def studio(self) -> Path: return self.root / "Studio"
    @property
    def decisions(self) -> Path: return self.studio / "Decisions"
    @property
    def roles(self) -> Path: return self.studio / "roles"
    @property
    def runs(self) -> Path: return self.root / "Taches"           # une tâche = « 2026-10-24 Titre court »
    @property
    def sauvegardes(self) -> Path: return self.root / "Sauvegardes"
    @property
    def backups(self) -> Path: return self.sauvegardes / "Studio-complet"
    @property
    def sauvegardes_configs(self) -> Path: return self.sauvegardes / "Configs"
    @property
    def mises_a_jour(self) -> Path: return self.sauvegardes / "Mises-a-jour"
    @property
    def archives(self) -> Path: return self.root / "Archives"
    @property
    def livrables(self) -> Path: return self.root / "Livrables"     # ancien emplacement des résultats des sujets (avant 0.4.18)
    @property
    def data(self) -> Path: return self.studio / "data"
    @property
    def code(self) -> Path: return Path(__file__).resolve().parents[1]    # programme : studio/, scripts/, modeles/
    @property
    def pieces(self) -> Path: return self.data / "pieces-jointes"   # fichiers glissés dans la fenêtre du Superviseur
    @property
    def journaux(self) -> Path: return self.data / "journaux"
    @property
    def restaurations(self) -> Path: return self.data / "restaurations-test"
    @property
    def db(self) -> Path: return self.data / "studio.db"
    @property
    def checkpoints(self) -> Path: return self.data / "checkpoints.db"
    @property
    def config_file(self) -> Path: return self.studio / "studio.config.toml"

    def ensure(self) -> "StudioPaths":
        for d in (self.runs, self.data, self.backups, self.projects, self.topics, self.journaux):
            d.mkdir(parents=True, exist_ok=True)
        return self


def default_paths(root: str | os.PathLike | None = None) -> StudioPaths:
    if root is None:
        from .espace import racine_configuree
        root = racine_configuree() or Path(__file__).resolve().parents[2]
    return StudioPaths(Path(root).resolve())
