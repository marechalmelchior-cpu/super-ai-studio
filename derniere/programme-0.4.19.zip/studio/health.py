"""État des connexions : mémoire, Claude Code, Codex, Blender, Unreal, Python.

Chaque ligne distingue : connecté (preuve obtenue), absent, ou non vérifié.
Les vérifications réutilisent les connexions existantes et ne lancent aucun service.
"""
from __future__ import annotations

import importlib.util
import sys


def check_all(studio, probe_tools: bool = True) -> dict:
    out: dict[str, dict] = {}
    h = studio.memory.health()
    out["memoire"] = {"etat": h.etat, "backend": h.backend, "detail": h.detail, "en_attente": h.en_attente}
    out["python"] = {"etat": "OK", "detail": sys.version.split()[0],
                     "langgraph": bool(importlib.util.find_spec("langgraph")),
                     "checkpoint_sqlite": bool(importlib.util.find_spec("langgraph.checkpoint.sqlite"))}
    if probe_tools:
        for name, ex in studio.executors.items():
            ok, info = ex.available()
            out[name] = {"etat": "OK" if ok else "ABSENT", "detail": info}
        if out.get("api", {}).get("etat") == "ABSENT" and any(out.get(k, {}).get("etat") == "OK" for k in ("claude-code", "codex")):
            del out["api"]                               # clé API facultative quand un abonnement fonctionne
        from .connectors.apps import Blender, Unreal
        if studio.cfg["outils"].get("blender"):          # connecteurs : affichés seulement s'ils ont été ajoutés
            b = Blender(studio.cfg["outils"].get("blender", "")).probe()
            out["blender"] = {"etat": "OK" if b.get("ok") else "NON_VERIFIE", "detail": b.get("version") or b.get("detail", "")}
        if studio.cfg["outils"].get("unreal_editor_cmd"):
            u = Unreal(studio.cfg["outils"].get("unreal_editor_cmd", "")).probe()
            out["unreal"] = {"etat": "OK" if u.get("ok") else "NON_VERIFIE", "detail": u.get("version") or u.get("detail", "")}
    spec = lambda m: bool(importlib.util.find_spec(m))
    lit = {"PDF": spec("pymupdf") or spec("fitz"), "images": spec("PIL"), "sons/vidéos": spec("faster_whisper") and spec("av")}
    manque = [k for k, v in lit.items() if not v]
    out["pieces_jointes"] = {
        "etat": "OK" if not manque else "PARTIEL",
        "detail": ("Lit : Word, Excel, PowerPoint, ZIP" + "".join(f", {k}" for k, v in lit.items() if v)
                   + (f". Manque : {', '.join(manque)} → scripts\\Installer-Lecture-Pieces.ps1 -Confirmer" if manque else "."))}
    out["chatgpt"] = {"etat": "MANUEL", "detail": "Export/import de dossiers de contexte ; accès automatique non connecté."}
    return out
