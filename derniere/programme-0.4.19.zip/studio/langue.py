"""Langue du studio (Réglages › Langue) : le Superviseur et les agents répondent dans la langue choisie."""
from __future__ import annotations

CONSIGNES = {
    "en": ("\n\n# Language\nThe user chose ENGLISH. Always write to the user in English (answers, proposals, reports, summaries), "
           "even though these instructions are in French. File names and code stay as they are."),
}


def langue(cfg: dict) -> str:
    v = str((cfg.get("utilisateur") or {}).get("langue") or "fr")
    return v if v in ("fr", "en") else "fr"


def consigne(cfg: dict) -> str:
    return CONSIGNES.get(langue(cfg), "")
