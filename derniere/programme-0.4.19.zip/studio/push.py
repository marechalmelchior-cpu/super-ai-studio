"""Notifications sur le téléphone (Web Push) : une tâche attend ta validation ou est bloquée → notification, avec
« Valider » directement dedans quand la relecture n'a rien relevé.

- Standard Web Push avec clé VAPID (ECDSA P-256, signature faite ici en Python pur : aucun composant à installer).
- Notification SANS contenu : le service de push du téléphone (Google pour Chrome) ne voit ni titre ni projet ; le
  téléphone vient lire les détails sur le studio, par Tailscale, avec son appareil associé.
- Seuls les services de push connus sont contactés (fcm.googleapis.com, Mozilla, Microsoft, Apple).
- data/push.json : clé privée VAPID (jamais affichée), abonnements des téléphones, tâches déjà signalées.
"""
from __future__ import annotations

import base64
import hashlib
import json
import os
import secrets
import threading
import time
import urllib.error
import urllib.request
from pathlib import Path
from urllib.parse import urlparse

A_SIGNALER = {"a_approuver": "à valider", "a_approuver_avec_defauts": "à valider (défauts relevés)", "bloquee": "bloquée",
              "echec": "en échec"}
SERVICES = ("fcm.googleapis.com", "updates.push.services.mozilla.com", "push.services.mozilla.com", "web.push.apple.com",
            ".notify.windows.com")
CONTACT = "https://github.com/marechalmelchior-cpu/super-ai-studio"
_verrou = threading.Lock()

# ------------------------------------------------------------------ P-256 (ECDSA) en Python pur
P = 0xFFFFFFFF00000001000000000000000000000000FFFFFFFFFFFFFFFFFFFFFFFF
A = P - 3
N = 0xFFFFFFFF00000000FFFFFFFFFFFFFFFFBCE6FAADA7179E84F3B9CAC2FC632551
G = (0x6B17D1F2E12C4247F8BCE6E563A440F277037D812DEB33A0F4A13945D898C296,
     0x4FE342E2FE1A7F9B8EE7EB4A7C0F9E162BCE33576B315ECECBB6406837BF51F5)


def _ajouter(p1, p2):
    if p1 is None:
        return p2
    if p2 is None:
        return p1
    (x1, y1), (x2, y2) = p1, p2
    if x1 == x2 and (y1 + y2) % P == 0:
        return None
    if p1 == p2:
        l = (3 * x1 * x1 + A) * pow(2 * y1, P - 2, P) % P
    else:
        l = (y2 - y1) * pow(x2 - x1, P - 2, P) % P
    x3 = (l * l - x1 - x2) % P
    return x3, (l * (x1 - x3) - y1) % P


def _multiplier(k: int, pt=G):
    r = None
    while k:
        if k & 1:
            r = _ajouter(r, pt)
        pt = _ajouter(pt, pt)
        k >>= 1
    return r


def _b64(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode()


def cle_publique(d: int) -> bytes:
    x, y = _multiplier(d)
    return b"\x04" + x.to_bytes(32, "big") + y.to_bytes(32, "big")


def signer(d: int, message: bytes) -> bytes:
    z = int.from_bytes(hashlib.sha256(message).digest(), "big")
    while True:
        k = secrets.randbelow(N - 1) + 1
        r = _multiplier(k)[0] % N
        s = pow(k, N - 2, N) * (z + r * d) % N
        if r and s:
            return r.to_bytes(32, "big") + s.to_bytes(32, "big")


def verifier(pub: bytes, message: bytes, sig: bytes) -> bool:
    r, s = int.from_bytes(sig[:32], "big"), int.from_bytes(sig[32:], "big")
    if not (0 < r < N and 0 < s < N):
        return False
    z = int.from_bytes(hashlib.sha256(message).digest(), "big")
    w = pow(s, N - 2, N)
    q = (int.from_bytes(pub[1:33], "big"), int.from_bytes(pub[33:], "big"))
    pt = _ajouter(_multiplier(z * w % N), _multiplier(r * w % N, q))
    return pt is not None and pt[0] % N == r


def jeton_vapid(d: int, endpoint: str, maintenant: float | None = None) -> str:
    u = urlparse(endpoint)
    tete = _b64(json.dumps({"typ": "JWT", "alg": "ES256"}, separators=(",", ":")).encode())
    corps = _b64(json.dumps({"aud": f"{u.scheme}://{u.netloc}", "exp": int((maintenant or time.time()) + 12 * 3600),
                             "sub": CONTACT}, separators=(",", ":")).encode())
    return f"{tete}.{corps}.{_b64(signer(d, f'{tete}.{corps}'.encode()))}"


# ------------------------------------------------------------------ état : clé, abonnements, tâches signalées
def _fichier(data: Path) -> Path:
    return Path(data) / "push.json"


def lire(data: Path) -> dict:
    try:
        d = json.loads(_fichier(data).read_text(encoding="utf-8"))
        if isinstance(d, dict) and d.get("vapid"):
            d.setdefault("abonnements", [])
            d.setdefault("signalees", {})
            return d
    except (OSError, ValueError):
        pass
    return {"vapid": "", "abonnements": [], "signalees": {}}


def _ecrire(data: Path, d: dict) -> None:
    f = _fichier(data)
    f.parent.mkdir(parents=True, exist_ok=True)
    t = f.with_suffix(".tmp")
    t.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
    os.replace(t, f)


def _cle(data: Path) -> int:
    with _verrou:
        d = lire(data)
        if not d["vapid"]:
            d["vapid"] = format(secrets.randbelow(N - 1) + 1, "064x")
            _ecrire(data, d)
        return int(d["vapid"], 16)


def cle_serveur(data: Path) -> str:
    """Clé publique VAPID à donner au navigateur (applicationServerKey)."""
    return _b64(cle_publique(_cle(data)))


def service_connu(endpoint: str) -> bool:
    u = urlparse(endpoint or "")
    h = (u.hostname or "").lower()
    return u.scheme == "https" and any(h == s.lstrip(".") or (s.startswith(".") and h.endswith(s)) for s in SERVICES)


def abonner(data: Path, abonnement: dict, appareil: str = "") -> dict:
    ep = str((abonnement or {}).get("endpoint", ""))
    if not service_connu(ep):
        raise ValueError("Service de notification inconnu : abonnement refusé.")
    _cle(data)
    with _verrou:
        d = lire(data)
        d["abonnements"] = [a for a in d["abonnements"] if a["endpoint"] != ep] + [
            {"endpoint": ep, "appareil": appareil[:40], "ajoute": time.strftime("%Y-%m-%d %H:%M")}]
        _ecrire(data, d)
    return {"ok": True, "abonnes": len(d["abonnements"])}


def desabonner(data: Path, endpoint: str) -> dict:
    with _verrou:
        d = lire(data)
        d["abonnements"] = [a for a in d["abonnements"] if a["endpoint"] != endpoint]
        _ecrire(data, d)
    return {"ok": True}


def envoyer(data: Path, envoi=None) -> int:
    """Réveille chaque téléphone abonné (notification sans contenu). Abonnement expiré (404/410) : retiré."""
    d = lire(data)
    if not d["abonnements"]:
        return 0
    cle = _cle(data)
    pub = cle_serveur(data)
    ok, morts = 0, []
    for a in d["abonnements"]:
        if not service_connu(a["endpoint"]):
            morts.append(a["endpoint"])
            continue
        req = urllib.request.Request(a["endpoint"], data=b"", method="POST", headers={
            "Authorization": f"vapid t={jeton_vapid(cle, a['endpoint'])}, k={pub}", "TTL": "86400", "Urgency": "high",
            "Content-Length": "0"})
        try:
            code = envoi(req) if envoi else urllib.request.urlopen(req, timeout=15).status
            ok += 1 if 200 <= code < 300 else 0
        except urllib.error.HTTPError as e:
            if e.code in (404, 410):
                morts.append(a["endpoint"])
        except OSError:
            pass
    if morts:
        with _verrou:
            d = lire(data)
            d["abonnements"] = [a for a in d["abonnements"] if a["endpoint"] not in morts]
            _ecrire(data, d)
    return ok


def en_attente(studio, depuis_h: float = 48) -> list[dict]:
    """Ce que le téléphone affiche : tâches à valider ou bloquées (titre, projet, empreinte pour « Valider »)."""
    out = []
    limite = time.time() - depuis_h * 3600
    for t in studio.store.list(200):
        if t["status"] not in A_SIGNALER:
            continue
        try:
            from datetime import datetime
            maj = datetime.fromisoformat(str(t.get("updated_at", ""))).timestamp()
        except ValueError:
            maj = time.time()
        if maj < limite:
            continue
        e = {"tid": t["id"], "titre": (t.get("titre") or t["request"])[:90], "etat": A_SIGNALER[t["status"]],
             "status": t["status"], "cible": t["target"]}
        if t["status"] == "a_approuver":
            try:
                s = studio.status(t["id"])
                if s.get("attend_decision") and s.get("empreinte"):
                    e["empreinte"] = s["empreinte"]
            except Exception:                            # noqa: BLE001 — sans empreinte : « Ouvrir » seulement
                pass
        out.append(e)
    return out[:10]


def tic(studio, envoi=None) -> int:
    """Nouvelles tâches à signaler depuis le dernier passage → un réveil par téléphone. Renvoie le nombre de réveils."""
    d = lire(studio.paths.data)
    if not d["abonnements"]:
        return 0
    actuel = {t["id"]: t["status"] for t in studio.store.list(200) if t["status"] in A_SIGNALER}
    nouveaux = [tid for tid, s in actuel.items() if d["signalees"].get(tid) != s]
    with _verrou:
        d = lire(studio.paths.data)
        d["signalees"] = actuel
        _ecrire(studio.paths.data, d)
    return envoyer(studio.paths.data, envoi) if nouveaux else 0
