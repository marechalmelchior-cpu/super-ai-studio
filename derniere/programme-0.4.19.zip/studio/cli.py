"""Point d'entrée en ligne de commande (français).

Exemples :
  python -m studio etat
  python -m studio tache "Corriger moyenne()" --cible studio-demo --lancer
  python -m studio suivre <TID>
  python -m studio approuver <TID> --empreinte <empreinte affichée>
  python -m studio memoire-chercher "combat" --portee project:rpg3d
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


def _studio(args, executors=None):
    from .orchestrator.runner import Studio
    return Studio(executors=executors)


OUTILS = {"claude-code": "Claude Code", "codex": "Codex", "simulation": "SIMULATION"}


def _print_organisation(o: dict):
    print("ÉQUIPE — à qui tu parles")
    for r in o["equipe"]:
        outil = OUTILS.get(r["outil"], r["outil"]) + (" (lecture seule)" if r["lecture_seule"] else "")
        if not r["actif"]:
            outil = "règles automatiques (auditeur modèle désactivé)"
        travail = [x["id"] for x in r["taches"] if x["status"] in ("creee", "en_cours", "en_attente_creneau")]
        attente = [x["id"] for x in r["taches"] if x["id"] not in travail]
        etat = (f"au travail : {', '.join(travail)}  " if travail else "") + (f"attend ton accord : {', '.join(attente)}" if attente else "")
        etat = etat or "libre"
        print(f"  {r['nom']:<26} {outil:<24} {etat}")
    print("\nPROJETS ET SUJETS")
    for c in o["cibles"]:
        print(f"  {c['nom']:<34} {'projet' if c['kind'] == 'project' else 'sujet':<7} {c.get('dossier') or '(sans dossier)'}")
    print("\nTÂCHES EN COURS")
    for x in o["taches_actives"] or []:
        print(f"  {x['id']}  {x['status']:<24} {x['target']:<14} {x['summary'][:60]}")
    if not o["taches_actives"]:
        print("  aucune")
    li = o["limites"]
    print(f"\nRÈGLES : {li['taches_simultanees']} tâche à la fois · {li['corrections_max']} corrections auto max · "
          f"mémoire {o['memoire']} · rien n'est appliqué sans ton approbation")


def _print(obj, as_json: bool):
    if as_json:
        print(json.dumps(obj, ensure_ascii=False, indent=2, default=str))
    elif isinstance(obj, dict) and "tache" in obj:
        t = obj["tache"]
        print(f"Tâche {t['id']} — {t['status']}  ({t['target']})")
        print(f"  {t['summary']}")
        if obj.get("simulation"):
            print("  ⚠ SIMULATION : aucun modèle appelé")
        if obj.get("memoire"):
            print(f"  Mémoire : {obj['memoire']}")
        eq = obj.get("equipe") or {}
        if eq.get("producteur"):
            print(f"  Équipe : {eq['producteur']['role']} via {OUTILS.get(eq['producteur']['outil'], eq['producteur']['outil'])}"
                  f" · auditeur : {OUTILS.get(eq['auditeur']['outil'], eq['auditeur']['outil'])} (lecture seule)")
        for e in obj["etapes"]:
            print(f"  [{e['status']:>8}] {e['name']} (tentative {e['attempt']}) {e['detail'][:90]}")
        if obj.get("attend_decision"):
            print(f"\n  Résultat : {obj['dossier']}/RESULTAT.md")
            print(f"  Empreinte à approuver : {obj['empreinte']}")
    else:
        print(json.dumps(obj, ensure_ascii=False, indent=2, default=str))



def _chaine_suivante(st, tid: str) -> None:
    """Comme l'interface : une étape de chaîne validée (ou annulée) en ligne de commande fait avancer sa chaîne."""
    from .chaines import avancer
    nouveau = avancer(st, tid)
    if nouveau:
        print(f"Chaîne : étape suivante lancée ({nouveau}).")
        st.run(nouveau)

def main(argv: list[str] | None = None) -> int:
    for stream in (sys.stdout, sys.stderr):           # console Windows en cp1252 : pas de plantage sur « ⚠ », « é »…
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, ValueError):
            pass
    p = argparse.ArgumentParser(prog="studio", description="Studio IA de l'utilisateur")
    p.add_argument("--json", action="store_true", help="sortie JSON")
    sub = p.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("etat"); s.add_argument("--rapide", action="store_true")
    sub.add_parser("cibles")
    s = sub.add_parser("projet-ajouter"); s.add_argument("id"); s.add_argument("nom"); s.add_argument("--chemin", required=True)
    s.add_argument("--type", default="doc"); s.add_argument("--depot", default=""); s.add_argument("--isolation", default="copie")
    s = sub.add_parser("sujet-ajouter"); s.add_argument("id"); s.add_argument("nom"); s.add_argument("--description", default="")
    s = sub.add_parser("tache"); s.add_argument("demande"); s.add_argument("--cible", required=True)
    s.add_argument("--role", default=""); s.add_argument("--executeur", default=""); s.add_argument("--lancer", action="store_true")
    s.add_argument("--modele", default="", help="opus | sonnet | haiku (Claude Code) ou nom de modèle Codex ; vide = réglage du rôle")
    s.add_argument("--mode", default="", choices=["", "rapide", "max"], help="rapide (sans relecture par un 2e modèle) | max (raisonnement maximal + compilation)")
    for name in ("lancer", "reprendre", "suivre", "annuler", "copier", "chatgpt-export"):   # copier = copier-coller vers une IA
        sub.add_parser(name).add_argument("tid")
    s = sub.add_parser("approuver"); s.add_argument("tid"); s.add_argument("--empreinte", required=True)
    s.add_argument("--commentaire", default="")
    s = sub.add_parser("corriger"); s.add_argument("tid"); s.add_argument("commentaire")
    for name in ("coller", "chatgpt-import"):          # coller = réponse de l'IA, enregistrée comme proposition
        s = sub.add_parser(name); s.add_argument("tid"); s.add_argument("fichier")
    sub.add_parser("taches")
    sub.add_parser("organisation", help="équipe, projets et sujets, tâches en cours")
    sub.add_parser("skills-synchroniser", help="skills du studio vers Claude et Codex, skills des projets vers .agents/skills (Codex)")
    s = sub.add_parser("regler-blender", help="trouve blender.exe (Steam compris) et l'enregistre dans studio.config.toml")
    s.add_argument("chemin", nargs="?", default="")
    s = sub.add_parser("processus"); s.add_argument("tid", nargs="?")
    s = sub.add_parser("memoire-chercher"); s.add_argument("requete", nargs="?", default="")
    s.add_argument("--portee", action="append", default=[]); s.add_argument("--sans-general", action="store_true")
    s.add_argument("--limite", type=int, default=20)
    s = sub.add_parser("memoire-ajouter"); s.add_argument("texte"); s.add_argument("--portee", required=True)
    s.add_argument("--outil", required=True, help="claude-code | codex | api | mel | copier-coller")
    s.add_argument("--sujet", default=""); s.add_argument("--cle", default=""); s.add_argument("--tache", default="")
    s = sub.add_parser("memoire-corriger"); s.add_argument("--portee", required=True); s.add_argument("--cle", required=True)
    s.add_argument("texte"); s.add_argument("--outil", default="mel")
    s = sub.add_parser("memoire-conflits"); s.add_argument("--portee", required=True)
    sub.add_parser("memoire-envoyer-attente")
    s = sub.add_parser("sauvegarder"); s.add_argument("--avec-runs", action="store_true")
    s = sub.add_parser("verifier-sauvegarde"); s.add_argument("fichier")
    s = sub.add_parser("restaurer-test"); s.add_argument("fichier"); s.add_argument("dossier")
    s = sub.add_parser("config-preparer", help="prépare la copie révisable de la config Codex")
    s.add_argument("--codex", default=str(Path.home() / ".codex" / "config.toml"))
    s.add_argument("--studio-mcp", action="store_true", help="ajoute aussi le serveur MCP studio-memoire")
    s = sub.add_parser("config-appliquer"); s.add_argument("--codex", default=str(Path.home() / ".codex" / "config.toml"))
    s = sub.add_parser("config-restaurer"); s.add_argument("--codex", default=str(Path.home() / ".codex" / "config.toml"))
    s.add_argument("--depuis", default="")
    sub.add_parser("diagnostic-mcp", help="teste le client MCP AgentMemory des configurations")
    sub.add_parser("demo")
    sub.add_parser("interface")
    sub.add_parser("lanceur", help="ouvre l'interface (raccourci du bureau) : session protégée, arrêt automatique")
    a = p.parse_args(argv)

    from .memory import MemoryUnavailable, Provenance, Scope
    try:
        if a.cmd in ("memoire-chercher", "memoire-ajouter", "memoire-corriger", "memoire-conflits", "memoire-envoyer-attente"):
            from .config import load_config
            from .memory import build_connector
            from .paths import default_paths
            paths = default_paths().ensure()
            mem = build_connector(load_config(paths.config_file), paths.data)
            if a.cmd == "memoire-chercher":
                if not a.portee and a.sans_general:
                    raise SystemExit("Indiquer au moins une portée.")
                recs = mem.recall(a.requete, [Scope.parse(x) for x in a.portee], not a.sans_general, a.limite)
                _print([r.to_dict() for r in recs], True)
            elif a.cmd == "memoire-ajouter":
                r = mem.remember(Scope.parse(a.portee), a.texte, Provenance(outil=a.outil, tache=a.tache),
                                 key=a.cle or None, subject=a.sujet)
                _print({"statut": r.status, "partage": r.shared, "cle": r.record.key, "detail": r.detail}, True)
                return 0 if r.shared else 3
            elif a.cmd == "memoire-corriger":
                r = mem.correct(Scope.parse(a.portee), a.cle, a.texte, Provenance(outil=a.outil))
                _print({"statut": r.status, "cle": r.record.key}, True)
            elif a.cmd == "memoire-conflits":
                _print({k: [x.to_dict() for x in v] for k, v in mem.conflicts(Scope.parse(a.portee)).items()}, True)
            else:
                _print(mem.flush_outbox(), True)
            return 0
        if a.cmd in ("sauvegarder", "verifier-sauvegarde", "restaurer-test"):
            from .backup import create_backup, restore_to_test, verify_backup
            from .paths import default_paths
            if a.cmd == "sauvegarder":
                print(create_backup(default_paths().ensure(), avec_runs=a.avec_runs))
            elif a.cmd == "verifier-sauvegarde":
                _print(verify_backup(Path(a.fichier)), True)
            else:
                _print(restore_to_test(Path(a.fichier), Path(a.dossier)), True)
            return 0
        if a.cmd == "config-preparer":
            from .configs import diff, patch_codex_config, sha256_text
            from .paths import default_paths
            src = Path(a.codex)
            old = src.read_text(encoding="utf-8")
            new = patch_codex_config(old)
            if a.studio_mcp:
                from .configs import add_studio_mcp_codex
                new = add_studio_mcp_codex(new, str(default_paths().studio))
            out = default_paths().code / "configs-preparees"
            out.mkdir(parents=True, exist_ok=True)
            (out / "codex.config.toml.propose").write_text(new, encoding="utf-8", newline="")
            (out / "codex.config.toml.diff").write_text(diff(old, new, "config.toml"), encoding="utf-8")
            (out / "codex.config.toml.base.sha256").write_text(sha256_text(old), encoding="utf-8")
            print(out / "codex.config.toml.diff")
            return 0
        if a.cmd in ("config-appliquer", "config-restaurer"):
            from .configs import apply_codex, restore_codex
            from .paths import default_paths
            dp = default_paths()
            if a.cmd == "config-appliquer":
                _print(apply_codex(Path(a.codex), dp.code / "configs-preparees", dp.backups / "configs"), True)
            else:
                _print(restore_codex(Path(a.codex), dp.backups / "configs", Path(a.depuis) if a.depuis else None), True)
            return 0
        if a.cmd == "diagnostic-mcp":
            from .diag_mcp import diagnose
            r1 = diagnose()
            _print({"premier_lancement": r1}, True)
            if r1.get("initialize_s", 0) > 20:
                _print({"second_lancement_cache_chaud": diagnose()}, True)
            return 0 if r1.get("ok") else 4
        if a.cmd == "regler-blender":
            from .config import set_outil, trouver_blender
            from .paths import default_paths
            trouves = [a.chemin] if a.chemin else trouver_blender()
            if not trouves or not Path(trouves[0]).is_file():
                print("Blender introuvable. Indique son chemin : studio.cmd regler-blender \"C:\\…\\blender.exe\"")
                return 1
            set_outil(default_paths().config_file, "blender", trouves[0])
            print(f"Blender enregistré : {trouves[0]}" + (f"\nAutres trouvés : {', '.join(trouves[1:])}" if len(trouves) > 1 else ""))
            return 0
        if a.cmd == "lanceur":
            from .launcher import main as lanceur
            return lanceur()
        if a.cmd == "interface":
            from .ui.server import serve
            serve()
            return 0
        if a.cmd == "demo":
            from .demo import demo_executors
            ex = demo_executors()
            st = _studio(a, executors={"simulation": ex["code"]})
            t1 = st.create("studio-demo", "Corriger moyenne() pour une liste vide (démonstration)", executeur="simulation")
            _print(st.run(t1), a.json)
            st.executors["simulation"] = ex["sujet"]
            t2 = st.create("topic:veille-ia", "Rédiger une note de synthèse sur la persistance LangGraph (démonstration)",
                           executeur="simulation")
            _print(st.run(t2), a.json)
            print("\nDÉMONSTRATION SIMULÉE : approuver ou annuler avec les commandes indiquées.")
            return 0

        st = _studio(a)
        if a.cmd == "skills-synchroniser":
            from .superviseur import synchroniser_tout
            print("\n".join(synchroniser_tout(st)))
        elif a.cmd == "organisation":
            o = st.organisation()
            print(json.dumps(o, ensure_ascii=False, indent=2, default=str)) if a.json else _print_organisation(o)
        elif a.cmd == "etat":
            from .health import check_all
            _print(check_all(st, probe_tools=not a.rapide), True)
        elif a.cmd == "cibles":
            _print([t.to_public() for t in st.registry.all()], True)
        elif a.cmd == "projet-ajouter":
            t = st.registry.add("project", a.id, a.nom, chemin=a.chemin, type=a.type, depot=a.depot, isolation=a.isolation)
            _print(t.to_public(), True)
        elif a.cmd == "sujet-ajouter":
            _print(st.registry.add("topic", a.id, a.nom, description=a.description).to_public(), True)
        elif a.cmd == "tache":
            opts = {k: v for k, v in (("role", a.role), ("executeur", a.executeur), ("modele", a.modele), ("mode", a.mode)) if v}
            tid = st.create(a.cible, a.demande, **opts)
            print(f"Tâche créée : {tid}")
            if a.lancer:
                _print(st.run(tid), a.json)
        elif a.cmd == "lancer":
            _print(st.run(a.tid), a.json)
        elif a.cmd == "reprendre":
            _print(st.resume(a.tid), a.json)
            _chaine_suivante(st, a.tid)
        elif a.cmd == "suivre":
            _print(st.status(a.tid), a.json)
        elif a.cmd == "approuver":
            _print(st.decide(a.tid, "approuver", a.empreinte, a.commentaire), a.json)
            _chaine_suivante(st, a.tid)
        elif a.cmd == "corriger":
            _print(st.decide(a.tid, "corriger", "", a.commentaire), a.json)
        elif a.cmd == "annuler":
            _print(st.cancel(a.tid), a.json)
            _chaine_suivante(st, a.tid)
        elif a.cmd == "taches":
            for t in st.store.list():
                print(f"{t['id']}  {t['status']:<26} {t['target']:<20} {t['summary'][:60]}")
        elif a.cmd == "processus":
            from .orchestrator.processes import processes
            _print(processes(st.store, a.tid), True)
        elif a.cmd in ("copier", "chatgpt-export"):
            print(st.export_chatgpt(a.tid))
        elif a.cmd in ("coller", "chatgpt-import"):
            from .connectors.chatgpt import import_report
            _print(import_report(Path(a.fichier), st.run_dir(a.tid) / "copier-coller", a.tid), True)
        return 0
    except MemoryUnavailable as e:
        print(f"MÉMOIRE EN PANNE : {e}", file=sys.stderr)
        return 2
    except (KeyError, ValueError, FileExistsError) as e:
        print(f"Erreur : {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
