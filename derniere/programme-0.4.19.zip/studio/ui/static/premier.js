/* Premier lancement : un clic (prénom facultatif, dossier proposé) → création, puis ouverture du studio, où l'accueil
   propose de connecter une IA en un bouton. */
const $ = (s) => document.querySelector(s);
async function api(path, body) {
  const opt = body === undefined ? {} : { method: "POST", headers: { "Content-Type": "application/json", "X-Studio": "1" }, body: JSON.stringify(body) };
  const r = await fetch(path, opt);
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.erreur || r.status);
  return j;
}
function montrer(n) { document.querySelectorAll("section[data-etape]").forEach((s) => (s.hidden = +s.dataset.etape !== n)); }
let minuterie = 0, valide = true;
async function verifier() {
  const d = $("#dossier").value.trim();
  $("#dossier-court").textContent = d;
  try {
    const v = await api("/api/verifier", { dossier: d });
    valide = v.ok;
    $("#info-dossier").textContent = v.info || "";
    $("#info-dossier").className = "info " + (v.ok ? "ok" : "warn");
    $("#creer").textContent = v.rejoindre ? "Reprendre ce studio" : "Créer mon studio";
    if (!v.ok) $("#pli-dossier").open = true;
    return v;
  } catch (e) { valide = false; $("#info-dossier").textContent = e.message; $("#info-dossier").className = "info warn"; $("#pli-dossier").open = true; }
}
$("#dossier").addEventListener("input", () => { clearTimeout(minuterie); minuterie = setTimeout(verifier, 300); });
$("#parcourir").onclick = async () => {
  $("#parcourir").disabled = true;
  try { const r = await api("/api/parcourir", { dossier: $("#dossier").value }); if (r.dossier) { $("#dossier").value = r.dossier; verifier(); } }
  finally { $("#parcourir").disabled = false; }
};
$("#creer").onclick = async () => {
  const v = await verifier();
  if (!v || !v.ok) return;
  $("#creer").disabled = true; $("#info-creer").textContent = "Création…"; $("#info-creer").className = "info";
  try {
    const nom = $("#nom").value.trim();
    const r = await api("/api/creer", { nom, dossier: $("#dossier").value.trim(), packs: [] });
    montrer(2);
    $("#titre-fin").textContent = r.rejoint ? "Studio repris" : `Ton studio est prêt${nom ? ", " + nom : ""}`;
    $("#texte-fin").textContent = "Ouverture du studio…";
    ouvrirStudio(r.suite);
  } catch (e) { $("#info-creer").textContent = e.message; $("#info-creer").className = "info warn"; $("#creer").disabled = false; }
};
document.addEventListener("keydown", (e) => { if (e.key === "Enter" && e.target.id === "nom") $("#creer").click(); });
async function ouvrirStudio(suite) {                  // le studio démarre sur le même port : on attend qu'il réponde
  for (let i = 0; i < 120; i++) {
    await new Promise((r) => setTimeout(r, 1000));
    try { const p = await (await fetch("/api/ping", { cache: "no-store" })).json(); if (p.studio) { location.href = suite; return; } } catch { /* pas encore */ }
  }
  $("#texte-fin").textContent = "Le studio tarde à démarrer : relance-le depuis son icône.";
}
(async () => {
  try { const infos = await api("/api/infos"); $("#dossier").value = infos.dossier; verifier(); } catch (e) { $("#info-creer").textContent = e.message; }
  montrer(1);
  $("#nom").focus();
})();
setInterval(() => api("/api/presence", {}).catch(() => {}), 20000);
