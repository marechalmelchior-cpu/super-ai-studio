"""Raccourcis « / » du Superviseur : demandes toutes faites (modeles/raccourcis.json), complétées ou remplacées par
celles de l'utilisateur (data/raccourcis.json, même forme). Lecture seule ; un fichier illisible est ignoré."""
from __future__ import annotations

import json
import re
from pathlib import Path


def _lire(f: Path) -> list[dict]:
    try:
        d = json.loads(f.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return []
    out = []
    for r in (d.get("raccourcis") if isinstance(d, dict) else d) or []:
        if isinstance(r, dict) and re.fullmatch(r"[a-z0-9-]{1,30}", str(r.get("nom", ""))) and str(r.get("texte", "")).strip():
            out.append({"nom": r["nom"], "titre": str(r.get("titre") or r["nom"])[:60], "texte": str(r["texte"])[:4000]})
    return out


def liste(code: Path, data: Path) -> list[dict]:
    tous = {r["nom"]: r for r in _lire(Path(code) / "modeles" / "raccourcis.json")}
    for r in _lire(Path(data) / "raccourcis.json"):
        tous[r["nom"]] = {**r, "perso": True}
    return list(tous.values())
