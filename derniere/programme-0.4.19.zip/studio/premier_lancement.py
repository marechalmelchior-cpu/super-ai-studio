"""Premier lancement (studio installé sans espace) : assistant dans la fenêtre du studio.

1. Prénom. 2. Dossier de l'espace (proposé : Documents\\Studio IA ; un espace existant est rejoint tel quel).
3. Packs facultatifs. 4. Outils déjà présents sur le PC (lecture seule). → « Créer mon studio ».
Même protections que le studio : 127.0.0.1 seulement, clé de session échangée contre un cookie, en-tête X-Studio sur
les envois. Rien n'est installé ; aucun fichier existant n'est écrasé. La connexion à une IA se fait ensuite, dans le
studio (Superviseur).
"""
from __future__ import annotations

import hmac
import json
import secrets
import subprocess
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from . import espace

STATIC = Path(__file__).resolve().parent / "ui" / "static"
COOKIE = "studio_premier"
ABSENCE_S = 180                     # fenêtre fermée sans finir : l'assistant s'arrête (rien n'a été créé)


def choisir_dossier(depart: str = "") -> str:
    """Boîte « Choisir un dossier » du système (Windows, Finder sur Mac, zenity ou kdialog sous Linux). Vide si annulée."""
    if sys.platform != "win32":
        import shutil
        if sys.platform == "darwin":
            cmd = ["osascript", "-e", 'POSIX path of (choose folder with prompt "Dossier de ton studio")']
        elif shutil.which("zenity"):
            cmd = ["zenity", "--file-selection", "--directory", "--title=Dossier de ton studio"] + ([f"--filename={depart}/"] if depart else [])
        elif shutil.which("kdialog"):
            cmd = ["kdialog", "--getexistingdirectory", depart or str(Path.home())]
        else:
            return ""
        try:
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=600, stdin=subprocess.DEVNULL)
            return r.stdout.strip().rstrip("/") if r.returncode == 0 else ""
        except (OSError, subprocess.TimeoutExpired):
            return ""
    from .connectors.base import SANS_FENETRE
    script = ("Add-Type -AssemblyName System.Windows.Forms; $d = New-Object System.Windows.Forms.FolderBrowserDialog; "
              "$d.Description = 'Dossier de ton studio'; $d.ShowNewFolderButton = $true; "
              "$d.SelectedPath = $env:STUDIO_DEPART; "
              "if ($d.ShowDialog() -eq 'OK') { [Console]::OutputEncoding = [Text.Encoding]::UTF8; $d.SelectedPath }")
    try:
        import os
        r = subprocess.run(["powershell", "-NoProfile", "-STA", "-Command", script], capture_output=True, text=True,
                           env={**os.environ, "STUDIO_DEPART": depart[:400]},
                           encoding="utf-8", errors="replace", timeout=600, stdin=subprocess.DEVNULL, **SANS_FENETRE)
        return r.stdout.strip().splitlines()[-1] if r.stdout.strip() else ""
    except (OSError, subprocess.TimeoutExpired):
        return ""


def etat_dossier(dossier: str) -> dict:
    d = Path(dossier).expanduser()
    if not dossier or not d.is_absolute():
        return {"ok": False, "info": "Indique un chemin complet."}
    if espace.est_espace(d):
        return {"ok": True, "rejoindre": True, "info": "Un studio existe déjà ici : il sera repris tel quel."}
    if d.exists() and not d.is_dir():
        return {"ok": False, "info": "Ce chemin est un fichier."}
    if d.exists() and any(d.iterdir()):
        sous = d / "Studio IA"
        if espace.est_espace(sous):
            return {"ok": True, "rejoindre": True, "cible": str(sous), "info": "Un studio existe déjà dans « Studio IA » : il sera repris."}
        return {"ok": True, "cible": str(sous), "info": f"Ce dossier contient déjà des fichiers : le studio sera créé dans {sous} (rien n'est touché)."}
    return {"ok": True, "info": "Le dossier sera créé." if not d.exists() else "Dossier vide : parfait."}


def servir(port: int, ouvrir, apres_creation, note=lambda m: None) -> dict | None:
    """Lance l'assistant ; renvoie le résultat de creer_espace, ou None si la fenêtre a été fermée avant la fin.
    ``ouvrir(url)`` ouvre la fenêtre ; ``apres_creation(racine) -> str`` renvoie l'adresse du studio (clé comprise)."""
    cle = secrets.token_urlsafe(24)
    fin = threading.Event()
    resultat: dict = {}
    presence = {"t": time.monotonic()}
    hotes = {f"127.0.0.1:{port}", f"localhost:{port}"}

    class H(BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def _send(self, code: int, obj=None, ctype="application/json", raw: bytes | None = None, extra=()):
            data = raw if raw is not None else json.dumps(obj, ensure_ascii=False).encode()
            self.send_response(code)
            self.send_header("Content-Type", f"{ctype}; charset=utf-8" if ctype.startswith(("text", "application/json")) else ctype)
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Referrer-Policy", "no-referrer")
            self.send_header("Content-Security-Policy", "default-src 'self'; img-src 'self' data:; style-src 'self' "
                                                        "'unsafe-inline'; script-src 'self'; frame-ancestors 'none'")
            for k, v in extra:
                self.send_header(k, v)
            self.end_headers()
            self.wfile.write(data)

        def _cookie_ok(self) -> bool:
            for part in (self.headers.get("Cookie") or "").split(";"):
                k, _, v = part.strip().partition("=")
                if k == COOKIE and hmac.compare_digest(v, cle):
                    return True
            return False

        def do_GET(self):
            if self.headers.get("Host") not in hotes:
                return self._send(403, {"erreur": "hôte refusé"})
            u = urlparse(self.path)
            if u.path == "/api/ping":
                return self._send(200, {"premier": True})
            if u.path in ("/logo-entete.png", "/icone-192.png"):
                return self._send(200, ctype="image/png", raw=(STATIC / u.path.lstrip("/")).read_bytes())
            if u.path.startswith("/fonts/") and (STATIC / u.path.lstrip("/")).is_file() and ".." not in u.path:
                return self._send(200, ctype="font/woff2", raw=(STATIC / u.path.lstrip("/")).read_bytes())
            t = (parse_qs(u.query).get("t") or [""])[0]
            if u.path == "/" and t and hmac.compare_digest(t, cle):
                return self._send(303, raw=b"", extra=(("Set-Cookie", f"{COOKIE}={cle}; HttpOnly; SameSite=Strict; Path=/"),
                                                         ("Location", "/")))
            if not self._cookie_ok():
                return self._send(403, ctype="text/html", raw="<p style='font:16px system-ui;padding:30px'>Relance le studio.</p>".encode())
            presence["t"] = time.monotonic()
            if u.path == "/":
                return self._send(200, ctype="text/html", raw=(STATIC / "premier.html").read_bytes())
            if u.path == "/premier.js":
                return self._send(200, ctype="text/javascript", raw=(STATIC / "premier.js").read_bytes())
            if u.path == "/api/infos":
                return self._send(200, {"dossier": str(espace.dossier_propose()), "packs": espace.packs(),
                                        "outils": espace.detecter_outils()})
            return self._send(404, {"erreur": "inconnu"})

        def do_POST(self):
            if self.headers.get("Host") not in hotes or self.headers.get("X-Studio") != "1" or not self._cookie_ok():
                return self._send(403, {"erreur": "refusé"})
            presence["t"] = time.monotonic()
            n = int(self.headers.get("Content-Length", 0) or 0)
            u = urlparse(self.path).path
            try:
                b = json.loads(self.rfile.read(min(n, 100_000)) or b"{}")
                if not isinstance(b, dict):
                    raise ValueError("Requête invalide.")
                if u == "/api/presence":
                    return self._send(200, {"ok": True})
                if u == "/api/verifier":
                    return self._send(200, etat_dossier(str(b.get("dossier", ""))))
                if u == "/api/parcourir":
                    return self._send(200, {"dossier": choisir_dossier(str(b.get("dossier", "")))})
                if u == "/api/creer":
                    if resultat:
                        return self._send(409, {"erreur": "déjà créé"})
                    connus = {p["id"] for p in espace.packs()}
                    choix = [p for p in b.get("packs", []) if p in connus]
                    r = espace.creer_espace(Path(str(b.get("dossier", ""))), str(b.get("nom", "")), choix)
                    resultat.update(r)
                    suite = apres_creation(Path(r["racine"]))
                    note(f"premier lancement : espace {'rejoint' if r['rejoint'] else 'créé'}")
                    self._send(200, {"ok": True, **r, "crees": len(r["crees"]), "suite": suite})
                    fin.set()
                    return
            except (ValueError, OSError) as e:
                return self._send(400, {"erreur": str(e)})
            return self._send(404, {"erreur": "inconnu"})

    httpd = ThreadingHTTPServer(("127.0.0.1", port), H)
    httpd.daemon_threads = True
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    ouvrir(f"http://127.0.0.1:{port}/?t={cle}")
    while not fin.wait(2):
        if time.monotonic() - presence["t"] > ABSENCE_S:
            break
    time.sleep(0.3)                                         # la réponse « créé » part avant l'arrêt
    httpd.shutdown()
    httpd.server_close()
    return dict(resultat) or None
