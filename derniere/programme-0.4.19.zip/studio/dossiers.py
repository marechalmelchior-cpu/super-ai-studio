"""Noms de dossiers lisibles pour les tâches : « 2026-10-24 Brancher les animations ».

L'identifiant technique (T20261024-…) reste dans la base ; seul le dossier visible porte un nom clair.
Noms sûrs sous Windows : pas de < > : " / \\ | ? *, pas de point ni d'espace final, longueur bornée.
"""
from __future__ import annotations

import re
from datetime import datetime
from pathlib import Path

_INTERDITS = re.compile(r'[<>:"/\\|?*\x00-\x1f]+')
_PETITS_MOTS = {"à", "a", "de", "du", "des", "d", "le", "la", "les", "l", "et", "ou", "avec", "ses", "son", "sa",
                "pour", "au", "aux", "en", "un", "une", "que", "qui", "dans", "sur", "par"}
_RESERVES = {"con", "prn", "aux", "nul", *(f"com{i}" for i in range(1, 10)), *(f"lpt{i}" for i in range(1, 10))}


def propre(texte: str, maxi: int = 60) -> str:
    t = _INTERDITS.sub(" ", texte or "")
    t = re.sub(r"\s+", " ", t).strip()
    if len(t) > maxi:
        t = t[:maxi].rsplit(" ", 1)[0] if " " in t[:maxi] else t[:maxi]
    coupe = t.endswith("…")
    t = t.rstrip(" .…,;:-–—")
    if coupe:                                       # titre coupé : pas de petit mot qui pend à la fin
        mots = t.split(" ")
        while len(mots) > 2 and mots[-1].lower() in _PETITS_MOTS:
            mots.pop()
        t = " ".join(mots).rstrip(" ,;:-–—")
    return "" if t.lower() in _RESERVES else t


def nom_tache(titre: str, quand: datetime | None = None, existe=lambda nom: False) -> str:
    """« AAAA-MM-JJ Titre » ; « (2) », « (3) »… si le nom est déjà pris."""
    jour = (quand or datetime.now()).strftime("%Y-%m-%d")
    base = f"{jour} {propre(titre) or 'Tâche'}"
    nom, n = base, 2
    while existe(nom):
        nom, n = f"{base} ({n})", n + 1
    return nom


def est_nom_simple(nom: str) -> bool:
    return bool(nom) and nom == Path(nom).name and nom not in (".", "..") and not _INTERDITS.search(nom)
