"""Connecteurs des logiciels de projet : Blender, Unreal Engine, Git.

Ils détectent les versions réellement installées et exécutent seulement des
opérations sans interface. Une opération graphique ou un test PIE demande une
interaction manuelle : elle est signalée comme telle et n'est jamais déclarée
réussie sans preuve (journal, fichier produit, code de retour).
"""
from __future__ import annotations

import json
import re
import subprocess
from pathlib import Path

from .base import find_exe, sha256_file

BLENDER_CANDIDATES = ["C:/Program Files/Blender Foundation/Blender */blender.exe"]
from .base import SANS_FENETRE  # noqa: E402

UE_CANDIDATES = ["C:/Program Files/Epic Games/UE_*/Engine/Binaries/Win64/UnrealEditor-Cmd.exe"]


def _run(cmd: list[str], timeout: int = 60) -> tuple[int | None, str]:
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, encoding="utf-8", errors="replace", **SANS_FENETRE)
        return r.returncode, (r.stdout or "") + (r.stderr or "")
    except (OSError, subprocess.TimeoutExpired) as e:
        return None, type(e).__name__


class Blender:
    def __init__(self, exe: str = ""):
        self.exe = find_exe(exe or "blender", BLENDER_CANDIDATES)

    def probe(self) -> dict:
        if not self.exe:
            return {"ok": False, "detail": "Blender introuvable (renseigner outils.blender)."}
        code, out = _run([self.exe, "--version"], 60)
        m = re.search(r"Blender\s+(\d+\.\d+(?:\.\d+)?)", out)
        return {"ok": code == 0 and bool(m), "version": m.group(1) if m else "", "exe": self.exe,
                "capacites": ["scripts Python en arrière-plan (--background)", "rendu sans interface"],
                "manuel": ["opérations dans l'interface graphique"]}

    def run_script(self, store, task_id: str, script: Path, workdir: Path, args: list[str], timeout: float, expected: list[Path]):
        from ..orchestrator.processes import run_process
        cmd = [self.exe, "--background", "--factory-startup", "--python", str(script), "--", *args]
        res = run_process(store, task_id, cmd, workdir, timeout)
        proofs = {str(p): sha256_file(p) for p in expected if p.exists()}
        ok = res.returncode == 0 and len(proofs) == len(expected)
        return {"ok": ok, "code": res.returncode, "preuves": proofs, "journal": res.stdout[-4000:]}


class Unreal:
    def __init__(self, editor_cmd: str = ""):
        self.exe = find_exe(editor_cmd, UE_CANDIDATES)

    @staticmethod
    def project_association(uproject: Path) -> str:
        try:
            return json.loads(uproject.read_text(encoding="utf-8")).get("EngineAssociation", "")
        except (OSError, ValueError):
            return ""

    def probe(self) -> dict:
        if not self.exe:
            return {"ok": False, "detail": "UnrealEditor-Cmd introuvable (renseigner outils.unreal_editor_cmd)."}
        version = ""
        exe = Path(self.exe)
        for build in (exe.parents[2] / "Build" / "Build.version", exe.parents[3] / "Build" / "Build.version"):
            try:                                       # Engine\Build\Build.version (UE 5) ; ancien emplacement en repli
                b = json.loads(build.read_text(encoding="utf-8"))
                version = f"{b['MajorVersion']}.{b['MinorVersion']}.{b['PatchVersion']}"
                break
            except (OSError, ValueError, KeyError):
                continue
        return {"ok": exe.exists() or bool(version), "version": version or "inconnue", "exe": self.exe,
                "capacites": ["commandlets", "tests d'automatisation sans rendu (-nullrhi)"],
                "manuel": ["PIE et vérifications visuelles dans l'éditeur", "compilation si l'éditeur du projet est ouvert"]}

    @staticmethod
    def automation_command(exe: str, uproject: Path, test_filter: str, log: Path) -> list[str]:
        return [exe, str(uproject), f"-ExecCmds=Automation RunTests {test_filter};Quit", "-unattended",
                "-nullrhi", "-nosplash", "-nopause", f"-abslog={log}"]

    @staticmethod
    def parse_automation_log(text: str) -> dict:
        ok = len(re.findall(r"Result=\{Success\}", text))
        ko = len(re.findall(r"Result=\{(?:Fail|Failed|Error)\}", text))
        return {"reussis": ok, "echecs": ko, "preuve": ok + ko > 0, "ok": ok > 0 and ko == 0}


class Git:
    def __init__(self, exe: str = "git"):
        self.exe = find_exe(exe) or exe

    def status(self, repo: Path) -> dict:
        """Lecture seule, sans verrou (``--no-optional-locks``)."""
        code, out = _run([self.exe, "--no-optional-locks", "-C", str(repo), "status", "--porcelain", "-b"], 60)
        if code != 0:
            return {"ok": False, "detail": out[-500:]}
        lines = out.splitlines()
        return {"ok": True, "branche": lines[0][3:] if lines else "", "modifications_non_commitees": len(lines) - 1}

    def remotes(self, repo: Path) -> list[str]:
        code, out = _run([self.exe, "--no-optional-locks", "-C", str(repo), "remote", "-v"], 30)
        urls = {re.sub(r"://[^@/]+@", "://", l.split()[1]) for l in out.splitlines() if len(l.split()) >= 2}
        return sorted(urls) if code == 0 else []
