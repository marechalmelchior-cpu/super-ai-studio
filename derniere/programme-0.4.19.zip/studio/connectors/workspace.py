"""Espaces de travail isolés et consolidation.

- ``copie`` : copie du projet dans ``Taches/<tâche>/copie-de-travail`` (petits projets, sujets) ;
- ``worktree`` : ``git worktree`` (gros dépôts) — modifie les métadonnées .git du
  projet réel, donc soumis à autorisation par projet ;
- ``lecture`` : aucun espace modifiable (projets réels tant que rien n'est autorisé).
Le résultat est un correctif (diff) appliqué au projet réel seulement après
approbation, et seulement si la politique du projet le prévoit.

Une seule liste d'exclusion sert à la copie ET aux relevés d'empreintes : un
dossier non copié (Saved/, Binaries/…) n'apparaît jamais comme « supprimé ».
"""
from __future__ import annotations

import difflib
import fnmatch
import hashlib
import json
import os
import shutil
from datetime import datetime, timezone
from pathlib import Path

from .base import sha256_file

SKIP_NAMES = (".git", "__pycache__", ".pytest_cache", ".venv", "node_modules", "Binaries", "Intermediate",
              "DerivedDataCache", "Saved", ".mission-*", ".studio-tmp-*", "_pieces")
TEXT_MAX = 2_000_000


class ApplyRefused(RuntimeError):
    """Application refusée avant toute écriture (projet modifié entre-temps, suppression…)."""


def _skipped(rel: str, exclude: list[str]) -> bool:
    parts = rel.split("/")
    if any(fnmatch.fnmatch(part, pat) for part in parts for pat in SKIP_NAMES):
        return True
    return any(rel == e.rstrip("/") or rel.startswith(e.rstrip("/") + "/") for e in exclude)


def snapshot(root: Path | None, exclude: list[str] | None = None) -> dict[str, str]:
    out: dict[str, str] = {}
    if root is None or not root.exists():
        return out
    exclude = exclude or []
    for dirpath, dirnames, filenames in os.walk(root):
        rel_dir = Path(dirpath).relative_to(root).as_posix()
        rel_dir = "" if rel_dir == "." else rel_dir + "/"
        dirnames[:] = [d for d in dirnames if not _skipped(rel_dir + d, exclude)]
        for f in filenames:
            rel = rel_dir + f
            if not _skipped(rel, exclude):
                out[rel] = sha256_file(Path(dirpath) / f)
    return dict(sorted(out.items()))


def prepare_copy(source: Path | None, dest: Path, exclude: list[str] | None = None) -> Path:
    if dest.exists():
        return dest
    if source is None:
        dest.mkdir(parents=True)
        return dest
    exclude = exclude or []

    def ignore(d, names):
        rel_dir = Path(d).relative_to(source).as_posix()
        return {n for n in names if _skipped(n if rel_dir == "." else f"{rel_dir}/{n}", exclude)}
    shutil.copytree(source, dest, ignore=ignore)
    return dest


def changes(before: dict[str, str], after: dict[str, str]) -> dict[str, list[str]]:
    return {"ajoutes": sorted(set(after) - set(before)),
            "supprimes": sorted(set(before) - set(after)),
            "modifies": sorted(k for k in set(before) & set(after) if before[k] != after[k])}


def unified_diff(src_root: Path | None, work_root: Path, ch: dict[str, list[str]]) -> str:
    chunks = []
    for rel in ch["modifies"] + ch["ajoutes"] + ch["supprimes"]:
        a = (src_root / rel) if src_root else None
        b = work_root / rel

        def lines(p):
            if p is None or not p.is_file() or p.stat().st_size > TEXT_MAX:
                return []
            try:
                return p.read_text(encoding="utf-8").splitlines(keepends=True)
            except UnicodeDecodeError:
                return [f"<fichier binaire {sha256_file(p)[:12]}>\n"]
        # une ligne finale sans retour à la ligne ne doit pas coller l'en-tête du fichier suivant (diff lisible)
        chunks.extend(x if x.endswith("\n") else x + "\n" for x in difflib.unified_diff(lines(a), lines(b), f"a/{rel}", f"b/{rel}"))
    return "".join(chunks)


def result_hash(work_root: Path, files: list[str], summary: str) -> str:
    h = hashlib.sha256(summary.encode())
    for rel in sorted(files):
        p = work_root / rel
        h.update(rel.encode())
        h.update(sha256_file(p).encode() if p.is_file() else b"<supprime>")
    return h.hexdigest()


def apply_changes(work_root: Path, target_root: Path, ch: dict[str, list[str]], expected_base: dict[str, str],
                  run_dir: Path) -> dict:
    """Applique au projet réel :
    - refuse toute suppression et tout fichier modifié depuis la copie (travail non enregistré de l'utilisateur) ;
    - sauvegarde les fichiers remplacés dans ``Taches/<tâche>/details/avant-application`` et écrit un manifeste ;
    - remplace chaque fichier de façon atomique (fichier temporaire + os.replace)."""
    if ch["supprimes"]:
        raise ApplyRefused("Suppression non autorisée par le studio : rien n'est appliqué ("
                           + ", ".join(ch["supprimes"][:5]) + ")")
    drift = [rel for rel in ch["modifies"]
             if not (target_root / rel).exists() or sha256_file(target_root / rel) != expected_base.get(rel)]
    drift += [rel for rel in ch["ajoutes"] if (target_root / rel).exists()]
    if drift:
        raise ApplyRefused("Le projet réel a changé depuis la préparation : " + ", ".join(drift[:10]))
    backup = run_dir / "avant-application"
    files = ch["modifies"] + ch["ajoutes"]
    manifest = {"debut": datetime.now(timezone.utc).isoformat(timespec="seconds"), "cible": str(target_root),
                "fichiers": {rel: sha256_file(work_root / rel) for rel in files}, "sauvegarde": str(backup)}
    for rel in ch["modifies"]:
        dst = backup / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(target_root / rel, dst)
    (run_dir / "application.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=1), encoding="utf-8")
    for rel in files:
        dst = target_root / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        tmp = dst.with_name(f".studio-tmp-{dst.name}")
        shutil.copy2(work_root / rel, tmp)
        os.replace(tmp, dst)
    return {"appliques": files, "sauvegarde_avant": str(backup)}


# ------------------------------------------------------------------ git worktree (gros dépôts, autorisé par projet)
class WorktreeError(RuntimeError):
    """Création ou lecture du worktree impossible : rien n'est écrit dans le projet réel."""


ESPACE = "copie-de-travail"                      # copie (ou worktree) du projet dans le dossier de la tâche
MARQUE_PRET = ".studio-worktree-pret"            # écrite à côté de l'espace quand l'extraction est complète


def _git(git: str, cwd: Path, *args: str, timeout: float = 600, entree: str | None = None) -> str:
    """git sans console ni invite (jamais de demande de mot de passe), chemins pris à la lettre (pas de motifs)."""
    import subprocess
    from .base import SANS_FENETRE
    env = {**os.environ, "GIT_TERMINAL_PROMPT": "0", "GIT_LITERAL_PATHSPECS": "1"}
    try:
        r = subprocess.run([git, "-C", str(cwd), *args], capture_output=True, text=True, encoding="utf-8",
                           errors="replace", timeout=timeout, env=env, input=entree,
                           stdin=None if entree is not None else subprocess.DEVNULL, **SANS_FENETRE)
    except subprocess.TimeoutExpired:
        raise WorktreeError(f"git {' '.join(args[:2])} : délai dépassé ({int(timeout)} s)") from None
    except OSError as e:
        raise WorktreeError(f"git {' '.join(args[:2])} : {e}") from None
    if r.returncode:
        raise WorktreeError(f"git {' '.join(args[:3])} : {(r.stderr or r.stdout).strip()[-400:]}")
    return r.stdout


def _vrai(git: str, cwd: Path, *args: str) -> bool:
    """Commande git dont le code de sortie est la réponse (merge-base --is-ancestor, symbolic-ref -q…)."""
    try:
        _git(git, cwd, *args)
        return True
    except WorktreeError:
        return False


def _chemins(fichiers: list[str]) -> str:
    return "\0".join(fichiers) + "\0"


def prepare_worktree(git: str, repo: Path, dest: Path, branch: str, dossiers: list[str] | None = None) -> str:
    """Crée (ou reprend) un worktree du dernier commit sur une branche dédiée. Le dossier de travail de l'utilisateur,
    sa branche et ses fichiers non commités ne sont jamais touchés ; seules les métadonnées .git/worktrees et la
    branche ``branch`` sont ajoutées. ``dossiers`` : extraction partielle (sparse, mode cône) ; vide = tout.
    Une extraction interrompue (arrêt pendant le checkout) est reprise, jamais prise pour un espace vide."""
    pret = dest.parent / MARQUE_PRET
    if (dest / ".git").is_file():
        if not pret.exists():                       # worktree créé mais extraction pas terminée : on la refait
            if dossiers:
                _git(git, dest, "sparse-checkout", "set", "--cone", "--", *dossiers)
            _git(git, dest, "read-tree", "-mu", "HEAD", timeout=1800)
            pret.write_text("ok", encoding="utf-8")
        return _git(git, dest, "rev-parse", "HEAD").strip()
    if dest.exists() and any(dest.iterdir()):
        raise WorktreeError(f"Le dossier {dest} existe déjà sans être un worktree : rien n'est fait.")
    existe = bool(_git(git, repo, "branch", "--list", branch).strip())
    args = ["worktree", "add", "--no-checkout"] + ([str(dest), branch] if existe else ["-b", branch, str(dest), "HEAD"])
    _git(git, repo, *args)
    if dossiers:
        _git(git, dest, "sparse-checkout", "set", "--cone", "--", *dossiers)
    _git(git, dest, "read-tree", "-mu", "HEAD", timeout=1800)
    pret.write_text("ok", encoding="utf-8")
    return _git(git, dest, "rev-parse", "HEAD").strip()


def git_changes(git: str, work: Path, exclude: list[str] | None = None, base: str = "HEAD"
                ) -> tuple[dict[str, list[str]], dict[str, str]]:
    """Changements de l'espace par rapport à son commit de DÉPART (``base``) : un commit fait par l'agent pendant
    l'exécution ne peut donc pas cacher des fichiers à la revue. Fichiers non suivis compris (hors .gitignore et
    exclusions) ; un dossier (dépôt imbriqué…) n'est jamais traité comme un fichier."""
    exclude = exclude or []
    ch: dict[str, list[str]] = {"ajoutes": [], "modifies": [], "supprimes": []}
    hashes: dict[str, str] = {}
    suivis = _git(git, work, "diff", "--name-status", "-z", "--no-renames", base).split("\0")
    i = 0
    while i + 1 < len(suivis):
        etat, rel = suivis[i], suivis[i + 1]
        i += 2
        if not etat or _skipped(rel, exclude):
            continue
        cle = "supprimes" if etat.startswith("D") else "ajoutes" if etat.startswith("A") else "modifies"
        ch[cle].append(rel)
    for rel in _git(git, work, "ls-files", "--others", "--exclude-standard", "-z").split("\0"):
        if rel and not rel.endswith("/") and not _skipped(rel, exclude):
            ch["ajoutes"].append(rel)
    for rel in ch["ajoutes"] + ch["modifies"]:
        p = work / rel
        if p.is_file():
            hashes[rel] = sha256_file(p)
    ch = {k: sorted(set(v)) for k, v in ch.items()}
    ch["ajoutes"] = [r for r in ch["ajoutes"] if r in hashes]
    ch["modifies"] = [r for r in ch["modifies"] if r in hashes]
    return ch, hashes


def git_diff(git: str, work: Path, ch: dict[str, list[str]], base: str = "HEAD") -> str:
    """Diff complet par rapport au commit de départ : fichiers suivis (y compris ce que l'agent aurait commité) par git,
    nouveaux fichiers non suivis par difflib. Aucun chemin sur la ligne de commande."""
    suivis = {r for r in _git(git, work, "diff", "--name-only", "-z", "--no-renames", base).split("\0") if r}
    texte = _git(git, work, "diff", "--no-color", "--no-ext-diff", "--no-renames", base) if suivis else ""
    nouveaux = [r for r in ch["ajoutes"] if r not in suivis]
    return texte + unified_diff(None, work, {"modifies": [], "ajoutes": nouveaux, "supprimes": []})


def commit_worktree(git: str, work: Path, ch: dict[str, list[str]], message: str) -> str:
    """Après l'accord de l'utilisateur : commit des seuls fichiers présentés, sur la branche du worktree. Jamais de push.
    Chemins passés par l'entrée standard (aucune limite de longueur, aucun motif interprété)."""
    fichiers = ch["ajoutes"] + ch["modifies"] + ch["supprimes"]
    if not fichiers:
        return _git(git, work, "rev-parse", "HEAD").strip()
    _git(git, work, "reset", "-q")                  # rien d'autre que les fichiers présentés ne part dans le commit
    try:                                            # --sparse : fichiers hors de l'extraction partielle (git ≥ 2.35)
        _git(git, work, "add", "-A", "--sparse", "--pathspec-from-file=-", "--pathspec-file-nul", entree=_chemins(fichiers))
    except WorktreeError as e:
        if "sparse" not in str(e).lower() or "unknown option" not in str(e).lower():
            raise
        _git(git, work, "add", "-A", "--pathspec-from-file=-", "--pathspec-file-nul", entree=_chemins(fichiers))
    if _vrai(git, work, "diff", "--cached", "--quiet"):
        return _git(git, work, "rev-parse", "HEAD").strip()      # tout était déjà dans des commits de l'agent
    _git(git, work, "commit", "--no-verify", "-m", message)
    return _git(git, work, "rev-parse", "HEAD").strip()
