"""Connecteur Codex — ``codex exec`` (mode non interactif officiel).

Choix (doc : https://learn.chatgpt.com/docs/non-interactive-mode) :
- ``codex exec --json`` : événements JSON Lines (``thread.started``,
  ``turn.completed`` avec ``usage``, ``turn.failed``, ``item.completed``, ``error``) ;
- ``--sandbox workspace-write`` (``--full-auto`` n'est plus pris en charge) ;
- ``-o <fichier>`` : dernier message ; ``--skip-git-repo-check`` pour un espace non Git ;
- le dossier de travail est fixé par le processus (pas d'option non vérifiée) ;
- authentification : celle déjà enregistrée par Codex (abonnement ChatGPT) ;
  aucune clé API n'est injectée par le studio.
- reprise : Codex choisit lui-même l'identifiant de conversation ; le studio le retrouve dans
  ``~/.codex/sessions/…/rollout-*.jsonl`` (``session_meta`` : id, dossier, heure) et, après Stop puis Reprendre, relance
  ``codex exec … resume <id> "<consigne>"``. Échec de reprise → nouveau départ normal.
``codex mcp-server`` a été retiré par OpenAI : il n'est pas utilisé.
Le SDK Python ``openai-codex`` (app-server) reste une option documentée (ADR-0005).
"""
from __future__ import annotations

import json
import os
import re
import subprocess
import time
from pathlib import Path

from ..orchestrator.processes import run_process
from .base import CONSIGNE_REPRISE, SANS_FENETRE, ExecResult, Mission, fiche_conversation, find_exe, niveau_effectif, noter

WIN_CANDIDATES = [str(Path.home() / "AppData/Local/OpenAI/Codex/bin/*/codex.exe"),
                  str(Path.home() / "AppData/Roaming/npm/codex.cmd")]


class CodexExecutor:
    name = "codex"

    def __init__(self, exe: str = "codex", sandbox: str = "workspace-write", timeout_s: float = 900,
                 ephemeral: bool = False, output_schema: Path | None = None):
        if sandbox == "danger-full-access":
            raise ValueError("Le studio n'utilise pas danger-full-access.")
        self.exe = find_exe(exe, WIN_CANDIDATES)
        self.sandbox, self.timeout_s, self.ephemeral, self.output_schema = sandbox, timeout_s, ephemeral, output_schema

    def available(self) -> tuple[bool, str]:
        if not self.exe:
            return False, "Codex CLI introuvable."
        try:
            out = subprocess.run([self.exe, "--version"], capture_output=True, text=True, timeout=30, **SANS_FENETRE)
            return out.returncode == 0, f"{(out.stdout or out.stderr).strip()[:80]} ({self.exe})"
        except (OSError, subprocess.TimeoutExpired) as e:
            return False, f"Codex ne répond pas : {type(e).__name__}"

    # Codex : minimal | low | medium | high | xhigh (selon le modèle). « max » n'existe pas chez Codex : on demande
    # [choix] codex_effort_max (par défaut « high », le plus haut niveau accepté par tous les modèles Codex).
    effort_max = "high"

    def niveau_codex(self, niveau: str) -> str:
        return {"low": "low", "medium": "medium", "high": "high", "xhigh": "xhigh", "max": self.effort_max}.get(niveau, "")

    def connait_reprise(self) -> bool:
        """``codex exec resume`` : seulement si l'aide de la version installée le mentionne."""
        if getattr(self, "_reprise", None) is None:
            try:
                aide = subprocess.run([self.exe, "exec", "--help"], capture_output=True, text=True, timeout=30,
                                      encoding="utf-8", errors="replace", **SANS_FENETRE).stdout if self.exe else ""
            except (OSError, subprocess.TimeoutExpired):
                aide = ""
            self._reprise = bool(re.search(r"^\s+resume\b", aide, re.M))
        return self._reprise

    @staticmethod
    def sessions(home: Path | None = None) -> Path:
        return Path(os.environ.get("CODEX_HOME") or Path(home or Path.home()) / ".codex") / "sessions"

    @classmethod
    def retrouver_session(cls, dossier: Path, depuis: float, home: Path | None = None) -> str:
        """Conversation Codex démarrée dans ``dossier`` depuis ``depuis`` (la plus ancienne : c'est celle de la mission)."""
        cible = os.path.normcase(os.path.abspath(str(dossier)))
        trouvees = []
        for f in cls.sessions(home).glob("*/*/*/rollout-*.jsonl"):
            try:
                if f.stat().st_mtime < depuis - 60:
                    continue
                with f.open(encoding="utf-8", errors="replace") as h:
                    meta = (json.loads(h.readline() or "{}").get("payload") or {})
            except (OSError, ValueError, AttributeError):
                continue
            sid, cwd = str(meta.get("id") or ""), str(meta.get("cwd") or "")
            if not sid or os.path.normcase(os.path.abspath(cwd)) != cible:
                continue
            try:
                from datetime import datetime
                t = datetime.fromisoformat(str(meta.get("timestamp", "")).replace("Z", "+00:00")).timestamp()
            except ValueError:
                t = f.stat().st_mtime
            if t >= depuis - 5:
                trouvees.append((t, sid))
        return min(trouvees)[1] if trouvees else ""

    def build_command(self, last_msg: Path, modele: str = "", effort: str = "", niveau: str = "", reprise: str = "",
                      dossiers: list[str] | None = None, mcp: list[str] | None = None) -> list[str]:
        cmd = [self.exe or "codex", "exec", "--json", "--sandbox", self.sandbox, "--skip-git-repo-check",
               "-o", str(last_msg)] + list(mcp or [])
        for d in dossiers or []:                  # ex. Taches\<tâche>\captures : l'agent peut y enregistrer ses preuves
            cmd += ["--add-dir", d]
        if modele:
            cmd += ["--model", modele]
        n = self.niveau_codex(niveau_effectif(niveau, effort))
        if n:                                     # profondeur de raisonnement de Codex
            cmd += ["-c", f'model_reasoning_effort="{n}"']
        if self.ephemeral:
            cmd.append("--ephemeral")
        if self.output_schema:
            cmd += ["--output-schema", str(self.output_schema)]
        if reprise:              # même conversation : la mission est déjà dans son historique
            return cmd + ["resume", reprise, CONSIGNE_REPRISE.format(ref="")]
        cmd.append("-")          # la mission est lue sur l'entrée standard
        return cmd

    def execute(self, mission: Mission, workdir: Path, runner) -> ExecResult:
        ok, info = self.available()
        if not ok:
            return ExecResult(False, info, self.name, error=info)
        dd = getattr(runner, "details_dir", None)
        last = (dd(mission.task_id) if dd and mission.task_id else workdir.parent) / f"codex-dernier-message-{mission.tentative}.txt"
        fiche = None if self.ephemeral else fiche_conversation(runner, mission, "codex", "json")
        reprise, info = "", {}
        mcp, env = self._mcp(mission, runner)
        if fiche is not None and fiche.exists():          # la mission avait été arrêtée : retrouver sa conversation
            try:
                info = json.loads(fiche.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                info = {}
            if info.get("debut") and self.connait_reprise():
                reprise = info.get("id") or self.retrouver_session(workdir, float(info["debut"]))
        if reprise:
            fiche.write_text(json.dumps({**info, "id": reprise}), encoding="utf-8")
            noter(runner, mission.task_id, f"{mission.role} reprend sa conversation Codex là où il s'était arrêté")
            res = run_process(runner.store, mission.task_id, self.build_command(last, mission.modele, mission.effort,
                              mission.niveau, reprise, mission.dossiers, mcp), workdir, self.timeout_s, **({"env": env} if env else {}))
            if res.status == "termine" and '"thread.started"' not in (res.stdout or ""):
                noter(runner, mission.task_id, "Reprise Codex impossible : nouveau départ de la mission")
                reprise = ""                                 # conversation introuvable : départ normal
        if not reprise:
            if fiche is not None:
                fiche.write_text(json.dumps({"debut": time.time()}), encoding="utf-8")
            res = run_process(runner.store, mission.task_id, self.build_command(last, mission.modele, mission.effort,
                              mission.niveau, dossiers=mission.dossiers, mcp=mcp), workdir, self.timeout_s, stdin_text=mission.prompt(),
                              **({"env": env} if env else {}))
            if mcp and res.status == "termine" and res.returncode not in (0, None) and re.search(r"mcp_servers|project_doc_fallback|unknown (field|key)", (res.stderr or "") + (res.stdout or "")[:2000]):
                noter(runner, mission.task_id, "Codex refuse les réglages de lancement (version ancienne ?) : relance sans eux")
                res = run_process(runner.store, mission.task_id, self.build_command(last, mission.modele, mission.effort,
                                  mission.niveau, dossiers=mission.dossiers), workdir, self.timeout_s, stdin_text=mission.prompt())
        if fiche is not None and res.status == "termine":    # conversation menée à son terme : plus rien à reprendre
            fiche.unlink(missing_ok=True)
        final = last.read_text(encoding="utf-8", errors="replace") if last.exists() else ""
        return self.parse(res.stdout, final, res.returncode, res.status)

    @staticmethod
    def _mcp(mission: Mission, runner) -> tuple[list[str], dict | None]:
        """Serveurs MCP du projet (Extensions) + mémoire partagée en lecture, pour cette exécution seulement."""
        try:
            import os
            from ..bibliotheque import env_mcp, mcp_installes
            from ..mcp_client import options_codex, serveur_memoire
            data = runner.paths.data
            tous = mcp_installes(data)
            choisis = {n: tous[n] for n in tous if mission.mcp is None or n in mission.mcp}
            opts, _ = options_codex(choisis, serveur_memoire())
            # projet sans AGENTS.md : Codex lit son CLAUDE.md (un seul fichier d'instructions pour tous les modèles)
            return ['-c', 'project_doc_fallback_filenames=["CLAUDE.md"]'] + opts, {**os.environ, **env_mcp(data)}
        except Exception:                             # noqa: BLE001 — hors du studio (tests) : rien d'ajouté
            return [], None

    def parse(self, jsonl: str, final: str, code: int | None, status: str) -> ExecResult:
        if status != "termine":
            return ExecResult(False, f"Codex : {status}", self.name, error=status)
        thread, usage, errors, messages = "", {}, [], []
        for line in jsonl.splitlines():
            try:
                ev = json.loads(line)
            except json.JSONDecodeError:
                continue
            t = ev.get("type", "")
            if t == "thread.started":
                thread = ev.get("thread_id", "")
            elif t == "turn.completed":
                usage = ev.get("usage", {}) or {}
            elif t in ("turn.failed", "error"):
                errors.append(json.dumps(ev.get("error", ev), ensure_ascii=False)[:500])
            elif t == "item.completed":
                item = ev.get("item", {}) or {}
                if item.get("type") in ("agent_message", "assistant_message") and item.get("text"):
                    messages.append(item["text"])
        ok = code == 0 and not errors
        return ExecResult(ok=ok, summary=(final or (messages[-1] if messages else ""))[:8000], executor=self.name,
                          session_id=thread, raw={"usage": usage}, error="; ".join(errors)[:2000])
