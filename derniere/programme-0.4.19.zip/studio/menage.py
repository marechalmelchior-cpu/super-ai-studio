"""Ménage automatique : le studio ne grossit pas indéfiniment, et reste propre au fil de l'eau.

Quand ça se fait (jamais deux fois le même ménage) :
- à la fin de chaque tâche (validée, appliquée, annulée) : sa copie de travail et ses copies de relecture ;
- juste après la sauvegarde du jour : rotation des sauvegardes ; après une mise à jour : anciennes versions ;
  après un changement de réglage : copies des réglages ; avant d'ouvrir la fenêtre : cache du navigateur ;
- une fois par jour au plus (rouvrir le studio ne relance rien) : rattrapage des tâches finies depuis 7 jours,
  points de reprise, journaux ;
- sur demande : Gestion › Entretien › « Faire le ménage maintenant ».

On garde toujours : projets, sujets et leurs résultats, skills, règles, mémoire, RESULTAT.md et details/ de chaque tâche.
On limite seulement le technique recréable ou périmé :
- sauvegardes complètes : les 7 derniers jours + une par semaine sur 4 semaines (jamais moins de 3) ;
- anciennes versions du programme (copie avant chaque mise à jour) : les 3 dernières ;
- copies des réglages : les 10 dernières ;
- copie du projet dans une tâche (copie-de-travail, copies de relecture) : retirée 7 jours après la fin de la tâche ;
- points de reprise des tâches finies depuis plus de 30 jours ;
- journaux : 30 jours ; journal de l'interface ramené à 1 Mo au-delà de 5 Mo ;
- cache de la fenêtre du studio au-delà de 150 Mo.
Une tâche en cours ou à valider n'est jamais touchée. Réglage : Réglages › « Ménage automatique ».
"""
from __future__ import annotations

import json
import shutil
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

JOURS_SAUVEGARDES, SEMAINES_SAUVEGARDES, MIN_SAUVEGARDES = 7, 4, 3
VERSIONS, COPIES_REGLAGES = 3, 10
JOURS_TACHE, JOURS_REPRISE, JOURS_JOURNAUX = 7, 30, 30
FINIES = ("approuvee", "appliquee", "annulee", "echec")
CACHES_FENETRE = ("Cache", "Code Cache", "GPUCache", "DawnCache", "DawnGraphiteCache", "DawnWebGPUCache", "GrShaderCache",
                  "ShaderCache", "Service Worker/CacheStorage", "Service Worker/ScriptCache")


def _taille(p: Path) -> int:
    """Taille d'un fichier ou d'un dossier ; un élément illisible compte pour 0 (jamais d'erreur)."""
    def une(f: Path) -> int:
        try:
            return f.stat().st_size if f.is_file() else 0
        except OSError:
            return 0
    try:
        return une(p) if p.is_file() else sum(une(f) for f in p.rglob("*")) if p.is_dir() else 0
    except OSError:
        return 0


def _retirer(p: Path, bilan: dict, cle: str) -> None:
    try:
        n = _taille(p)
        shutil.rmtree(p) if p.is_dir() else p.unlink()
        bilan[cle] = bilan.get(cle, 0) + 1
        bilan["octets"] += n
    except OSError:
        pass                                            # fichier ouvert ou verrouillé : on réessaiera la prochaine fois


def sauvegardes_a_retirer(fichiers: list[Path], maintenant: datetime | None = None) -> list[Path]:
    """Garde la plus récente de chacun des 7 derniers jours, puis la plus récente de chacune des 4 semaines suivantes."""
    maintenant = maintenant or datetime.now(timezone.utc)
    dates = []
    for f in fichiers:
        try:
            dates.append((datetime.strptime(f.name.split("-", 1)[1][:16], "%Y%m%dT%H%M%SZ").replace(tzinfo=timezone.utc), f))
        except (IndexError, ValueError):
            continue                                    # nom inconnu : jamais touché
    dates.sort(reverse=True)
    garder, jours, semaines = set(), set(), set()
    for d, f in dates:
        age = (maintenant - d).days
        if age < JOURS_SAUVEGARDES and d.date() not in jours:
            jours.add(d.date())
            garder.add(f)
        elif JOURS_SAUVEGARDES <= age < JOURS_SAUVEGARDES + 7 * SEMAINES_SAUVEGARDES \
                and (age - JOURS_SAUVEGARDES) // 7 not in semaines:          # une par tranche de 7 jours
            semaines.add((age - JOURS_SAUVEGARDES) // 7)
            garder.add(f)
    for _, f in dates:                                  # jamais moins de 3 sauvegardes, même anciennes
        if len(garder) >= MIN_SAUVEGARDES:
            break
        garder.add(f)
    return [f for _, f in dates if f not in garder]


def _plus_recents(dossier: Path, motif: str, garder: int) -> list[Path]:
    if not dossier.is_dir():
        return []
    fichiers = sorted((f for f in dossier.glob(motif) if f.is_file()), key=lambda f: f.stat().st_mtime, reverse=True)
    return fichiers[garder:]


def limiter(dossier: Path, motif: str, garder: int) -> int:
    """Garde les `garder` plus récents (appelé juste après avoir créé une nouvelle copie). Renvoie le nombre retiré."""
    bilan = {"octets": 0}
    for f in _plus_recents(Path(dossier), motif, garder):
        _retirer(f, bilan, "n")
    return bilan.get("n", 0)


def tourner_sauvegardes(dossier: Path) -> int:
    """Juste après la sauvegarde du jour : 7 jours + 4 semaines gardés."""
    bilan = {"octets": 0}
    dossier = Path(dossier)
    if dossier.is_dir():
        for f in sauvegardes_a_retirer([p for p in dossier.glob("studio-*") if p.suffix in (".dpapi", ".zip")]):
            _retirer(f, bilan, "n")
    return bilan.get("n", 0)


def menage_actif(config_file: Path) -> bool:
    try:
        from .config import load_config
        return (load_config(config_file).get("entretien") or {}).get("menage_auto") is not False
    except Exception:                                   # noqa: BLE001
        return True


def _anciennes_versions(code: Path, data: Path) -> Path:
    return code.parent / "anciennes-versions" if code.name == "app" else data / "anciennes-versions"


def copie_retirable(studio, row: dict) -> bool:
    """La copie de travail d'une tâche finie ne contient plus rien d'utile :
    worktree (le travail est sur sa branche : retirer_espace revérifie), sujet (résultats déjà rangés dans Sujets/),
    projet en copie appliquée ou sans rien à appliquer, tâche annulée. Projet en copie validée mais pas appliquée : gardée."""
    if row["status"] not in FINIES:
        return False
    if row["status"] in ("annulee", "echec"):
        return True
    try:
        t = studio.registry.get(row["target"])
    except (KeyError, ValueError):
        return False                                    # projet retiré du studio : on ne touche à rien
    if not t.has_path or row["status"] == "appliquee":
        return True
    d = studio.run_dir(row["id"], creer=False)
    return (d / "copie-de-travail" / ".git").is_file() or (d / "details" / "rien-a-appliquer.json").exists()


def nettoyer_tache(studio, tid: str, bilan: dict | None = None) -> dict:
    """Fin de tâche (validée, appliquée, annulée) : retire sa copie de travail et les copies de relecture.
    RESULTAT.md, captures et details/ restent. Une tâche en échec garde sa copie 7 jours (tri quotidien)."""
    from . import actions
    from .connectors import workspace as ws
    bilan = bilan if bilan is not None else {"octets": 0}
    try:
        row = studio.store.get(tid)
    except KeyError:
        return bilan
    if not copie_retirable(studio, row):
        return bilan
    dossier = studio.run_dir(tid, creer=False)
    espace = dossier / ws.ESPACE
    if espace.exists():
        if (espace / ".git").is_file():                 # worktree git : contrôles de retirer_espace (branche validée intacte)
            try:
                n = _taille(espace)
                actions.retirer_espace(studio, tid)
                bilan["copies_taches"] = bilan.get("copies_taches", 0) + 1
                bilan["octets"] += n
            except Exception:                           # noqa: BLE001 — fichiers hors branche, git absent… : on garde
                pass
        else:
            _retirer(espace, bilan, "copies_taches")
    details = dossier / "details"
    if details.is_dir():
        for copie in details.glob("relecture-*"):       # copies jetables de l'auditeur
            if copie.is_dir():
                _retirer(copie, bilan, "copies_relecture")
    return bilan


def apres_tache(studio, tid: str) -> None:
    """Appelé quand une tâche se termine : le studio reste propre au fil de l'eau. Ne lève jamais."""
    if (studio.cfg.get("entretien") or {}).get("menage_auto") is False:
        return
    try:
        if studio.store.get(tid)["status"] in ("approuvee", "appliquee", "annulee"):
            nettoyer_tache(studio, tid)
    except Exception:                                   # noqa: BLE001
        pass


def _taches(studio, bilan: dict, maintenant: float) -> None:
    """Rattrapage : tâches finies depuis plus de 7 jours (échecs compris, ou nettoyage coupé à l'époque)."""
    with studio.store.db() as c:
        lignes = c.execute("SELECT id, status, updated_at FROM tasks WHERE status IN (?,?,?,?)", FINIES).fetchall()
    for r in lignes:
        try:
            fin = datetime.fromisoformat(r["updated_at"]).timestamp()
        except (TypeError, ValueError):
            continue
        if maintenant - fin >= JOURS_TACHE * 86400:
            nettoyer_tache(studio, r["id"], bilan)


def _reprises(studio, bilan: dict) -> None:
    """Points de reprise (LangGraph) des tâches finies depuis longtemps : inutiles, une tâche finie ne reprend pas."""
    import sqlite3
    f = studio.paths.checkpoints
    if not f.exists():
        return
    limite = (datetime.now(timezone.utc) - timedelta(days=JOURS_REPRISE)).isoformat(timespec="seconds")
    with studio.store.db() as c:
        ids = [r["id"] for r in c.execute("SELECT id FROM tasks WHERE status IN (?,?,?,?) AND updated_at < ?", (*FINIES, limite))]
    if not ids:
        return
    try:
        con = sqlite3.connect(f, timeout=5)
        try:
            tables = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            n = 0
            for t in ("checkpoints", "writes"):
                if t in tables:
                    for i in range(0, len(ids), 500):
                        lot = ids[i:i + 500]
                        n += con.execute(f"DELETE FROM {t} WHERE thread_id IN ({','.join('?' * len(lot))})", lot).rowcount
            con.commit()
            if n:
                bilan["reprises"] = bilan.get("reprises", 0) + n   # place réutilisée par SQLite : le fichier cesse de grossir
        finally:
            con.close()
    except sqlite3.Error:
        pass


def _journaux(studio, bilan: dict, maintenant: float) -> None:
    d = studio.paths.journaux
    if not d.is_dir():
        return
    for f in d.rglob("*"):
        if f.is_file() and maintenant - f.stat().st_mtime > JOURS_JOURNAUX * 86400:
            _retirer(f, bilan, "journaux")
        elif f.is_file() and f.suffix == ".log" and f.stat().st_size > 5 * 2**20:
            try:                                        # journal actif trop gros : on garde la fin (1 Mo)
                with open(f, "rb") as h:
                    h.seek(-2**20, 2)
                    fin = h.read()
                avant = f.stat().st_size
                f.write_bytes(fin[fin.find(b"\n") + 1:])
                bilan["octets"] += avant - f.stat().st_size
                bilan["journaux"] = bilan.get("journaux", 0) + 1
            except OSError:
                pass


def cache_fenetre(data: Path) -> int:
    """Avant d'ouvrir la fenêtre : caches du navigateur du studio vidés s'ils dépassent 150 Mo. Renvoie les octets libérés."""
    bilan = {"octets": 0}
    profil = Path(data) / "edge-studio"
    if profil.is_dir() and _taille(profil) >= 150 * 2**20:
        for base in [profil, *[p for p in profil.iterdir() if p.is_dir()]]:
            for nom in CACHES_FENETRE:
                if (base / nom).is_dir():
                    _retirer(base / nom, bilan, "n")
    return bilan["octets"]


def _cache_fenetre(studio, bilan: dict) -> None:
    profil = studio.paths.data / "edge-studio"
    if _taille(profil) < 150 * 2**20:
        return
    for base in [profil, *[p for p in profil.iterdir() if p.is_dir()]] if profil.is_dir() else []:
        for nom in CACHES_FENETRE:
            if (base / nom).is_dir():
                _retirer(base / nom, bilan, "cache_fenetre")


def lancer(studio, forcer: bool = False) -> dict:
    """Une fois par jour (ou sur demande) ; renvoie ce qui a été libéré. Ne lève jamais."""
    f = studio.paths.data / "menage.json"
    try:
        dernier = json.loads(f.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        dernier = {}
    aujourd_hui = datetime.now().strftime("%Y-%m-%d")
    if not forcer and dernier.get("jour") == aujourd_hui:
        return dernier
    if not forcer and (studio.cfg.get("entretien") or {}).get("menage_auto") is False:
        return {**dernier, "coupe": True}
    bilan: dict = {"octets": 0}
    maintenant = time.time()
    etapes = (
        lambda: [_retirer(x, bilan, "sauvegardes") for x in sauvegardes_a_retirer(
            [p for p in studio.paths.backups.glob("studio-*") if p.suffix in (".dpapi", ".zip")])] if studio.paths.backups.is_dir() else None,
        lambda: [_retirer(x, bilan, "anciennes_versions") for x in _plus_recents(_anciennes_versions(studio.paths.code, studio.paths.data), "*.zip", VERSIONS)],
        lambda: [_retirer(x, bilan, "copies_reglages") for x in _plus_recents(studio.paths.data / "config-avant", "*.toml", COPIES_REGLAGES)],
        lambda: _taches(studio, bilan, maintenant),
        lambda: _reprises(studio, bilan),
        lambda: _journaux(studio, bilan, maintenant),
        lambda: _cache_fenetre(studio, bilan),
    )
    for e in etapes:
        try:
            e()
        except Exception:                               # noqa: BLE001 — une étape ratée n'empêche pas les autres
            pass
    total = dict(dernier.get("total") or {})
    for k, v in bilan.items():
        total[k] = total.get(k, 0) + v
    r = {"jour": aujourd_hui, "dernier": bilan, "total": total}
    try:
        f.write_text(json.dumps(r, ensure_ascii=False, indent=1), encoding="utf-8")
    except OSError:
        pass
    return r


def resume(r: dict) -> str:
    b = r.get("dernier") or {}
    if not b.get("octets") and len(b) <= 1:
        return "Rien à libérer."
    mo = b.get("octets", 0) / 2**20
    noms = {"sauvegardes": "sauvegarde(s)", "anciennes_versions": "ancienne(s) version(s)", "copies_reglages": "copie(s) de réglages",
            "copies_taches": "copie(s) de projet dans des tâches finies", "copies_relecture": "copie(s) de relecture",
            "reprises": "point(s) de reprise", "journaux": "journal(aux)", "cache_fenetre": "dossier(s) de cache"}
    parts = [f"{v} {noms[k]}" for k, v in b.items() if k in noms and v]
    return f"{mo:.0f} Mo libérés : " + ", ".join(parts) + "."


def migrer_livrables(studio) -> int:
    """Une fois : les résultats rangés dans Livrables/<Nom du sujet>/ rejoignent leur sujet (Sujets/<sujet>/).
    Rien n'est écrasé ni perdu : un fichier identique déjà présent n'est pas recopié, un fichier différent devient « nom v2 ».
    Livrables/ n'est retiré que s'il ne contient plus rien d'autre que son LISEZ-MOI."""
    import hashlib
    from .dossiers import propre
    base = studio.paths.livrables
    if not base.is_dir():
        return 0
    empreinte = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()    # noqa: E731
    n = 0
    for t in studio.registry.all():
        if t.kind != "topic":
            continue
        src = base / (propre(t.nom or t.id) or t.id)
        if not src.is_dir():
            continue
        for f in sorted(p for p in src.rglob("*") if p.is_file()):
            dest = studio.paths.topics / t.id / f.relative_to(src)
            dest.parent.mkdir(parents=True, exist_ok=True)
            k = 2
            while dest.exists() and empreinte(dest) != empreinte(f):
                dest = dest.with_name(f"{f.stem} v{k}{f.suffix}")
                k += 1
            if dest.exists():
                f.unlink()                              # copie identique déjà dans le sujet
            else:
                shutil.move(str(f), str(dest))
            n += 1
        for d in sorted((p for p in src.rglob("*") if p.is_dir()), key=lambda p: -len(p.parts)) + [src]:
            try:
                d.rmdir()                               # seulement les dossiers devenus vides
            except OSError:
                pass
    reste = [p for p in base.rglob("*") if p.is_file() and p.name != "LISEZ-MOI.md"]
    if not reste:
        (base / "LISEZ-MOI.md").unlink(missing_ok=True)
        try:
            base.rmdir()
        except OSError:
            pass
    return n
