"""Extensions : skills, connecteurs (serveurs MCP et logiciels du PC) et packs, à découvrir et installer.

Règles :
- Catalogue trié (modeles/catalogue.json, mis à jour avec le studio). Les skills Anthropic viennent d'un commit figé
  de github.com/anthropics/skills : chaque fichier est vérifié (SHA-256) avant d'être écrit.
- Rien n'est jamais écrasé : une skill déjà présente n'est pas remplacée. « Retirer » range dans Archives, n'efface rien.
- Serveurs MCP : configuration ajoutée à data/mcp.json, utilisée par les agents Claude Code. Les clés sont chiffrées
  (DPAPI sous Windows) dans data/mcp-secrets.json et passées aux agents par variables d'environnement, jamais en clair
  dans un fichier. Le paquet du serveur (npx, uvx) se télécharge au premier usage : le studio le dit avant d'installer.
- Logiciels : détectés sur le PC et déclarés aux agents ; jamais installés par le studio (lien officiel et commande
  winget à lancer soi-même).
- Skill importée (.zip) : vérifiée (chemins, taille, SKILL.md) et relue (scripts, adresses web, consignes suspectes).
"""
from __future__ import annotations

import glob
import hashlib
import io
import json
import os
import re
import shutil
import time
import urllib.parse
import urllib.request
import zipfile
from pathlib import Path

from .espace import CODE, MODELES

MAX_IMPORT = 30 * 1024 * 1024
_ID = re.compile(r"^[a-z0-9][a-z0-9-]{0,60}$")
PREREQUIS = {"node": ("npx", "Node.js", "https://nodejs.org/fr/download"),
             "uv": ("uvx", "uv (Astral)", "https://docs.astral.sh/uv/getting-started/installation/")}


_DATA: dict = {}


def catalogue() -> dict:
    """Catalogue livré avec le studio, ou celui publié depuis (data/catalogue-maj.json, mis à jour chaque jour) s'il
    est plus récent."""
    try:
        base = json.loads((MODELES / "catalogue.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        base = {"categories": {}, "nouveaux": [], "elements": []}
    d = _DATA.get("data")
    if d:
        maj = _lire_json(Path(d) / "catalogue-maj.json", {})
        if isinstance(maj, dict) and isinstance(maj.get("elements"), list) and str(maj.get("version", "")) > str(base.get("version", "")):
            return maj
    return base


def actualiser_catalogue(data: Path, depot: str, force: bool = False) -> dict:
    """Chaque jour : catalogue publié dans le dépôt du studio (catalogue/catalogue.json). Rien n'est installé."""
    _DATA["data"] = str(data)
    f = Path(data) / "catalogue-maj.json"
    if not depot or (not force and f.exists() and time.time() - f.stat().st_mtime < 24 * 3600):
        return {"ok": True, "frais": True}
    try:
        d = json.loads(_telecharger(f"https://raw.githubusercontent.com/{depot}/main/catalogue/catalogue.json", 20))
        if not isinstance(d.get("elements"), list):
            raise ValueError("format inattendu")
        _ecrire_json(f, d)
        return {"ok": True}
    except Exception as e:                               # noqa: BLE001 — hors ligne : catalogue livré gardé
        return {"ok": False, "erreur": type(e).__name__}


def _element(ident: str) -> dict:
    e = next((x for x in catalogue()["elements"] if x["id"] == ident), None)
    if not e:
        raise ValueError("Élément inconnu du catalogue.")
    return e


# ------------------------------------------------------------------ fichiers d'état
def _lire_json(f: Path, defaut):
    try:
        return json.loads(f.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return defaut


def _ecrire_json(f: Path, d) -> None:
    f.parent.mkdir(parents=True, exist_ok=True)
    t = f.with_suffix(f.suffix + ".tmp")
    t.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
    os.replace(t, f)


def fichier_mcp(data: Path) -> Path:
    return Path(data) / "mcp.json"


def mcp_installes(data: Path) -> dict:
    d = _lire_json(fichier_mcp(data), {})
    return d.get("mcpServers", {}) if isinstance(d, dict) else {}


def env_mcp(data: Path) -> dict:
    """Variables des serveurs MCP (clés déchiffrées) pour le processus de l'agent, jamais écrites ailleurs."""
    from .ia import _dechiffrer
    out = {}
    for k, v in _lire_json(Path(data) / "mcp-secrets.json", {}).items():
        try:
            out[k] = _dechiffrer(v)
        except Exception:                                # noqa: BLE001 — clé illisible : le serveur dira qu'elle manque
            pass
    return out


# ------------------------------------------------------------------ ce qui est installé
def _skills_presentes(racine: Path) -> dict[str, dict]:
    out = {}
    d = Path(racine) / "Skills"
    for s in sorted(d.glob("*/SKILL.md")) if d.is_dir() else []:
        if s.parent.name == "superviseur":                # méthode du Superviseur : réservée, jamais listée
            continue
        meta = _lire_json(s.parent / ".bibliotheque.json", {})
        texte = s.read_text(encoding="utf-8", errors="replace")
        desc = re.search(r"(?mi)^description:\s*[\"']?(.+?)[\"']?\s*$", texte)
        titre = re.search(r"(?m)^#\s+(.+?)\s*$", texte.split("---", 2)[-1] if texte.startswith("---") else texte)
        out[s.parent.name] = {"source": meta.get("source", "studio"), "description": desc.group(1)[:200] if desc else "",
                              "titre": titre.group(1)[:60] if titre else "", "socle": (MODELES / "espace" / "Skills" / s.parent.name).is_dir()}
    return out


def detecter_logiciel(e: dict) -> str:
    for exe in e.get("executables", []):
        p = shutil.which(exe)
        if p:
            return p
    for motif in e.get("chemins", []):
        trouves = sorted(glob.glob(os.path.expanduser(motif)))
        if trouves:
            return trouves[-1]
    return ""


def etat(studio) -> dict:
    from . import connecteurs
    _DATA["data"] = str(studio.paths.data)
    cat = catalogue()
    skills = _skills_presentes(studio.paths.root)
    mcp = mcp_installes(studio.paths.data)
    logiciels = {c["nom"].lower(): c for c in connecteurs.lister(studio)}
    from .espace import etat_packs
    packs_locaux = {p["id"]: p for p in etat_packs(studio.paths.root)}
    elements = []
    for e in cat["elements"]:
        x = {k: v for k, v in e.items() if k not in ("source", "config", "chemins", "executables")}
        if e["type"] == "skill":
            x["installe"] = e["id"] in skills
        elif e["type"] == "mcp":
            x["installe"] = e["id"] in mcp
            x["manque"] = [PREREQUIS[p][1] for p in e.get("prerequis", []) if not shutil.which(PREREQUIS[p][0])]
        elif e["type"] == "logiciel":
            x["installe"] = e["nom"].lower() in logiciels
            x["trouve"] = bool(detecter_logiciel(e)) if not x["installe"] else True
        elif e["type"] == "pack":
            x["membres_etat"] = {m: _membre_installe(m, skills, mcp, logiciels, packs_locaux) for m in e["membres"]}
            x["installe"] = all(x["membres_etat"][m] for m in (e.get("base") or e["membres"]))
        x["nouveau"] = e["id"] in cat.get("nouveaux", [])
        elements.append(x)
    connus = {e["id"] for e in cat["elements"]}
    for nom, s in skills.items():                         # tes skills hors catalogue (socle, perso, importées)
        if nom not in connus:
            elements.append({"id": nom, "type": "skill", "nom": s["titre"] or nom.replace("-", " ").capitalize(), "description": s["description"],
                             "socle": s["socle"],
                             "auteur": {"import": "Importée", "studio": "Le studio"}.get(s["source"], "Toi"), "verifie": s["source"] == "studio",
                             "categorie": "perso", "installe": True, "hors_catalogue": True})
    for nom in mcp:
        if nom not in connus:
            elements.append({"id": nom, "type": "mcp", "nom": nom, "description": "Serveur MCP ajouté à la main.", "auteur": "Toi",
                             "verifie": False, "categorie": "perso", "installe": True, "hors_catalogue": True})
    noms_cat = {e["nom"].lower() for e in cat["elements"] if e["type"] == "logiciel"}
    for c in logiciels.values():
        if c["nom"].lower() not in noms_cat:
            elements.append({"id": c["id"], "type": "logiciel", "nom": c["nom"], "description": c.get("chemin", ""), "auteur": "Toi",
                             "verifie": False, "categorie": "perso", "installe": True, "hors_catalogue": True, "trouve": c.get("ok", False)})
    return {"elements": elements, "categories": cat.get("categories", {}), "pour_vous": pour_vous(studio, elements)}


def _membre_installe(m: str, skills, mcp, logiciels, packs_locaux) -> bool:
    if m.startswith("pack:"):
        return bool(packs_locaux.get(m[5:], {}).get("installe"))
    e = next((x for x in catalogue()["elements"] if x["id"] == m), None)
    if not e:
        return True
    return (m in skills if e["type"] == "skill" else m in mcp if e["type"] == "mcp"
            else e["nom"].lower() in logiciels if e["type"] == "logiciel" else False)


def pour_vous(studio, elements: list[dict]) -> list[str]:
    """Recommandations d'après tes projets et ton PC (jamais ce qui est déjà installé)."""
    voulus: list[str] = []
    for t in studio.registry.all():
        if not t.has_path:
            continue
        try:
            p = t.path()
            noms = {x.name.lower() for x in p.iterdir()} if p.is_dir() else set()
        except OSError:
            continue
        if any(n.endswith(".uproject") for n in noms) or t.extra.get("type") == "unreal" or "project.godot" in noms:
            voulus += ["domaine-jeu-video", "game-design-document", "level-design"]
        if {"package.json", "index.html", "vite.config.js", "vite.config.ts"} & noms:
            voulus += ["domaine-web", "playwright", "seo-contenu-web"]
        if any(n.endswith((".blend", ".fbx", ".glb")) for n in noms):
            voulus += ["domaine-3d", "pipeline-assets-3d"]
        if (p / ".git").exists():
            voulus += ["git"]
    if studio.cfg.get("outils", {}).get("blender"):
        voulus += ["blender-mcp"]
    voulus += ["domaine-bureau", "context7", "skill-creator", "domaine-design", "revue-de-code", "veille-et-synthese"]
    installes = {e["id"] for e in elements if e.get("installe")}
    out = []
    for v in voulus:
        if v not in installes and v not in out:
            out.append(v)
    return out[:6]


# ------------------------------------------------------------------ installer
def _telecharger(url: str, delai: float = 60) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": "SuperAIStudio"})
    with urllib.request.urlopen(req, timeout=delai) as r:
        return r.read()


def installer(studio, ident: str, valeurs: dict | None = None, telecharger=None) -> dict:
    e = _element(ident)
    valeurs = valeurs or {}
    if e["type"] == "skill":
        return _installer_skill(studio, e, telecharger or _telecharger)
    if e["type"] == "mcp":
        return _installer_mcp(studio, e, valeurs)
    if e["type"] == "logiciel":
        return _installer_logiciel(studio, e, str(valeurs.get("chemin", "")))
    if e["type"] == "pack":
        faits, notes = [], []
        choix = valeurs.get("selection")
        membres = [m for m in e["membres"] if m in choix] if isinstance(choix, list) else list(e.get("base") or e["membres"])
        for m in membres:
            try:
                if m.startswith("pack:"):
                    from .espace import installer_pack, nom
                    installer_pack(studio.paths.root, m[5:], nom())
                    faits.append(m)
                    continue
                r = installer(studio, m, valeurs.get(m) if isinstance(valeurs.get(m), dict) else {}, telecharger)
                if r.get("ok"):
                    faits.append(m)
            except ValueError as ex:
                notes.append(f"{_element(m)['nom'] if not m.startswith('pack:') else m} : {ex}")
        _recharger_roles(studio)
        return {"ok": True, "installes": faits, "notes": notes,
                "message": f"Pack installé ({len(faits)} élément(s))" + (" — à compléter : " + " ; ".join(notes) if notes else ".")}
    raise ValueError("Type inconnu.")


def _recharger_roles(studio) -> None:
    try:
        from .orchestrator.roles import load_roles
        studio.roles = load_roles(studio.paths.roles)
    except Exception:                                    # noqa: BLE001
        pass


def _installer_skill(studio, e: dict, telecharger) -> dict:
    dest = Path(studio.paths.root) / "Skills" / e["id"]
    if (dest / "SKILL.md").exists():
        return {"ok": True, "deja": True, "message": f"« {e['nom']} » est déjà installée."}
    src = e["source"]
    if src["type"] == "studio":
        from .espace import installer_pack, nom
        installer_pack(studio.paths.root, src["pack"], nom())
        _recharger_roles(studio)
    elif src["type"] == "studio-skill":
        orig = MODELES / src["dossier"]
        if not (orig / "SKILL.md").is_file():
            raise ValueError("Skill absente de cette version du studio : mets le studio à jour.")
        for f in sorted(orig.rglob("*")):
            if f.is_file():
                (dest / f.relative_to(orig)).parent.mkdir(parents=True, exist_ok=True)
                (dest / f.relative_to(orig)).write_bytes(f.read_bytes())
        _ecrire_json(dest / ".bibliotheque.json", {"source": "catalogue", "installe": time.strftime("%Y-%m-%d %H:%M")})
    elif src["type"] == "github":
        contenus = {}
        for f in src["fichiers"]:
            if ".." in f["chemin"].split("/") or f["chemin"].startswith("/"):
                raise ValueError("Chemin refusé dans le catalogue.")
            url = (f"https://raw.githubusercontent.com/{src['depot']}/{src['commit']}/"
                   + urllib.parse.quote(f"{src['dossier']}/{f['chemin']}"))
            try:
                b = telecharger(url)
            except OSError as ex:
                raise ValueError(f"Téléchargement impossible ({type(ex).__name__}) : vérifie la connexion internet.") from None
            if hashlib.sha256(b).hexdigest() != f["sha256"]:
                raise ValueError(f"Fichier altéré ({f['chemin']}) : rien n'est installé.")
            contenus[f["chemin"]] = b
        tmp = dest.with_name(f".{e['id']}.installation")
        if tmp.exists():
            shutil.rmtree(tmp)
        for chemin, b in contenus.items():                # tout est vérifié avant d'écrire, puis dossier remplacé d'un coup
            (tmp / chemin).parent.mkdir(parents=True, exist_ok=True)
            (tmp / chemin).write_bytes(b)
        _ecrire_json(tmp / ".bibliotheque.json", {"source": "catalogue", "depot": src["depot"], "commit": src["commit"],
                                                  "installe": time.strftime("%Y-%m-%d %H:%M"), "licence": e.get("licence", "")})
        tmp.rename(dest)
    _synchroniser(studio)
    return {"ok": True, "message": f"« {e['nom']} » installée : les agents l'utilisent dès maintenant."}


def _synchroniser(studio) -> None:
    try:
        from .superviseur import synchroniser_skills
        synchroniser_skills(studio.paths.root)
    except Exception:                                    # noqa: BLE001 — « Synchroniser les skills » reste possible
        pass


def _installer_mcp(studio, e: dict, valeurs: dict) -> dict:
    manque = [p for p in e.get("prerequis", []) if not shutil.which(PREREQUIS[p][0])]
    if manque:
        n, lien = PREREQUIS[manque[0]][1], PREREQUIS[manque[0]][2]
        raise ValueError(f"Il faut d'abord {n} sur le PC : {lien} (installe-le, puis réessaie).")
    from .ia import _chiffrer
    secrets_f = Path(studio.paths.data) / "mcp-secrets.json"
    secrets = _lire_json(secrets_f, {})
    for v in e.get("variables", []):
        val = str(valeurs.get(v["nom"], "")).strip()
        if not val and v.get("secret"):
            raise ValueError(f"{v['libelle']} : obligatoire.")
        if val:
            if "\n" in val or len(val) > 2000:
                raise ValueError(f"{v['libelle']} : valeur invalide.")
            secrets[v["nom"]] = _chiffrer(val)
    _ecrire_json(secrets_f, secrets)
    d = _lire_json(fichier_mcp(studio.paths.data), {})
    d = d if isinstance(d, dict) else {}
    d.setdefault("mcpServers", {})[e["id"]] = e["config"]
    _ecrire_json(fichier_mcp(studio.paths.data), d)
    return {"ok": True, "message": f"« {e['nom']} » ajouté : les agents Claude Code l'utilisent dès la prochaine tâche."
                                   + (" Le serveur se télécharge à sa première utilisation." if e.get("prerequis") else "")}


def _installer_logiciel(studio, e: dict, chemin: str) -> dict:
    from . import connecteurs
    chemin = chemin or detecter_logiciel(e)
    if not chemin:
        raise ValueError(f"{e['nom']} n'est pas trouvé sur le PC. Installe-le depuis {e['site']}"
                         + (f" (ou dans PowerShell : winget install --id {e['winget']} -e)" if e.get("winget") else "")
                         + ", puis réessaie.")
    connecteurs.ajouter(studio, e["nom"], chemin)
    return {"ok": True, "message": f"{e['nom']} déclaré aux agents ({chemin})."}


# ------------------------------------------------------------------ retirer (rien n'est effacé)
def retirer(studio, ident: str, type_: str) -> dict:
    from . import connecteurs
    if not _ID.match(ident or ""):
        raise ValueError("Identifiant invalide.")
    if type_ == "skill":
        src = Path(studio.paths.root) / "Skills" / ident
        if not (src / "SKILL.md").exists():
            raise ValueError("Skill introuvable.")
        if ident == "superviseur" or (MODELES / "espace" / "Skills" / ident).is_dir():
            raise ValueError("Cette skill fait partie de la méthode du studio : elle reste.")
        archive = Path(studio.paths.root) / "Archives" / "skills-retires" / f"{ident}-{time.strftime('%Y%m%d-%H%M%S')}"
        archive.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(src), str(archive))
        home = Path.home()
        for outil in (".claude", ".codex"):               # copies faites par le studio : rangées avec elle
            copie = home / outil / "skills" / f"studio-{ident}"
            if (copie / "SKILL.md").exists() and "genere-par-ai-workspace" in (copie / "SKILL.md").read_text(encoding="utf-8", errors="replace"):
                shutil.move(str(copie), str(archive / f"copie-{outil.strip('.')}"))
        return {"ok": True, "message": f"Skill rangée dans Archives\\skills-retires ({archive.name})."}
    if type_ == "mcp":
        d = _lire_json(fichier_mcp(studio.paths.data), {})
        cfg = (d.get("mcpServers") or {}).pop(ident, None) if isinstance(d, dict) else None
        if cfg is None:
            raise ValueError("Serveur MCP introuvable.")
        _ecrire_json(fichier_mcp(studio.paths.data), d)
        noms = set(re.findall(r"\$\{([A-Z0-9_]+)\}", json.dumps(cfg)))
        autres = set(re.findall(r"\$\{([A-Z0-9_]+)\}", json.dumps(d.get("mcpServers", {}))))
        sec_f = Path(studio.paths.data) / "mcp-secrets.json"
        sec = _lire_json(sec_f, {})
        _ecrire_json(sec_f, {k: v for k, v in sec.items() if k not in noms - autres})
        return {"ok": True, "message": "Serveur MCP retiré (les agents ne l'utilisent plus)."}
    if type_ == "logiciel":
        e = next((x for x in catalogue()["elements"] if x["id"] == ident), None)
        nom = (e or {}).get("nom", "").lower()
        c = next((x for x in connecteurs.lister(studio) if (x["nom"].lower() == nom if e else x["id"] == ident)), None)
        if not c:
            raise ValueError("Logiciel non déclaré.")
        connecteurs.retirer(studio, c["id"])
        return {"ok": True, "message": f"{c['nom']} n'est plus déclaré aux agents (rien n'est désinstallé)."}
    raise ValueError("Ce type ne se retire pas d'un bloc : retire ses éléments un par un.")


# ------------------------------------------------------------------ importer une skill (.zip)
SUSPECTS = [(r"(?i)ignore (all |the )?(previous|prior) instructions|ignore les instructions", "demande d'ignorer des consignes"),
            (r"(?i)(curl|wget|iwr|invoke-webrequest)[^\n|]*\|\s*(sh|bash|iex|powershell)", "télécharge puis exécute"),
            (r"(?i)(api[_-]?key|token|password|mot de passe)\s*[:=]", "parle de clés ou mots de passe"),
            (r"[A-Za-z0-9+/]{400,}={0,2}", "long bloc encodé")]


def relire(fichiers: dict[str, bytes]) -> list[str]:
    """Points à vérifier avant d'installer une skill venue d'ailleurs (rien n'est exécuté)."""
    notes = []
    scripts = [c for c in fichiers if c.lower().endswith((".py", ".ps1", ".sh", ".bat", ".cmd", ".js", ".exe", ".dll"))]
    if scripts:
        notes.append(f"Contient {len(scripts)} script(s) que les agents pourront lancer : " + ", ".join(scripts[:5]))
    for c, b in fichiers.items():
        if not c.lower().endswith((".md", ".txt", ".py", ".ps1", ".sh", ".js", ".json", ".yaml", ".yml", ".toml")):
            continue
        t = b.decode("utf-8", errors="ignore")
        for motif, raison in SUSPECTS:
            if re.search(motif, t):
                notes.append(f"{c} : {raison}")
        urls = set(re.findall(r"https?://[^\s)\"'>]+", t))
        if urls:
            notes.append(f"{c} : {len(urls)} adresse(s) web")
    return notes[:12]


def importer_skill(studio, archive: bytes, confirmer: bool = False) -> dict:
    if len(archive) > MAX_IMPORT:
        raise ValueError("Archive trop lourde (30 Mo maximum).")
    try:
        z = zipfile.ZipFile(io.BytesIO(archive))
    except zipfile.BadZipFile:
        raise ValueError("Ce n'est pas un fichier .zip.") from None
    noms = [i for i in z.infolist() if not i.is_dir()]
    if sum(i.file_size for i in noms) > 100 * 1024 * 1024 or len(noms) > 2000:
        raise ValueError("Archive trop grosse une fois décompressée.")
    skill_md = sorted((i.filename for i in noms if i.filename.replace("\\", "/").split("/")[-1] == "SKILL.md"), key=len)
    if not skill_md:
        raise ValueError("Pas de SKILL.md dans l'archive : ce n'est pas une skill.")
    base = skill_md[0].replace("\\", "/")[: -len("SKILL.md")]
    fichiers = {}
    for i in noms:
        n = i.filename.replace("\\", "/")
        if not n.startswith(base) or ".." in n.split("/") or n.startswith("/") or ":" in n:
            continue
        fichiers[n[len(base):]] = z.read(i)
    texte = fichiers["SKILL.md"].decode("utf-8", errors="replace")
    m = re.search(r"(?mi)^name:\s*[\"']?([A-Za-z0-9 _-]+?)[\"']?\s*$", texte)
    ident = re.sub(r"[^a-z0-9-]+", "-", (m.group(1) if m else base.strip("/").split("/")[-1] or "skill").lower()).strip("-")[:60] or "skill"
    notes = relire(fichiers)
    dest = Path(studio.paths.root) / "Skills" / ident
    if (dest / "SKILL.md").exists():
        raise ValueError(f"Une skill « {ident} » existe déjà : rien n'est remplacé (renomme-la dans son SKILL.md).")
    if not confirmer:
        return {"ok": True, "apercu": True, "id": ident, "fichiers": len(fichiers), "notes": notes,
                "extrait": texte[:1500]}
    for c, b in fichiers.items():
        (dest / c).parent.mkdir(parents=True, exist_ok=True)
        (dest / c).write_bytes(b)
    _ecrire_json(dest / ".bibliotheque.json", {"source": "import", "installe": time.strftime("%Y-%m-%d %H:%M"), "relecture": notes})
    _synchroniser(studio)
    return {"ok": True, "id": ident, "message": f"Skill « {ident} » importée ({len(fichiers)} fichier(s))."}


def exporter_skill(studio, ident: str) -> bytes:
    """Une de tes skills en .zip, pour la partager."""
    if not _ID.match(ident or ""):
        raise ValueError("Identifiant invalide.")
    d = Path(studio.paths.root) / "Skills" / ident
    if not (d / "SKILL.md").exists():
        raise ValueError("Skill introuvable.")
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for f in sorted(d.rglob("*")):
            if f.is_file() and f.name != ".bibliotheque.json":
                z.write(f, f"{ident}/{f.relative_to(d).as_posix()}")
    return buf.getvalue()


def ajouter_mcp_perso(studio, nom: str, commande: str, arguments: str = "", url: str = "") -> dict:
    """Serveur MCP ajouté à la main (commande ou adresse) — à tes risques : il n'a pas été relu par le studio."""
    ident = re.sub(r"[^a-z0-9-]+", "-", (nom or "").lower()).strip("-")[:40]
    if not ident:
        raise ValueError("Donne un nom au serveur.")
    if url:
        if not re.match(r"^https://|^http://(127\.0\.0\.1|localhost)(:\d+)?/", url):
            raise ValueError("Adresse https (ou http://127.0.0.1 pour un serveur local) attendue.")
        cfg = {"type": "http", "url": url}
    else:
        commande = (commande or "").strip()
        if not commande or any(c in commande for c in "|&;<>`\n"):
            raise ValueError("Commande simple attendue (ex. npx).")
        import shlex
        cfg = {"command": commande, "args": shlex.split(arguments or "", posix=os.name != "nt")}
    d = _lire_json(fichier_mcp(studio.paths.data), {})
    d = d if isinstance(d, dict) else {}
    if ident in d.get("mcpServers", {}):
        raise ValueError("Un serveur porte déjà ce nom.")
    d.setdefault("mcpServers", {})[ident] = cfg
    _ecrire_json(fichier_mcp(studio.paths.data), d)
    return {"ok": True, "message": f"Serveur « {ident} » ajouté pour les agents Claude Code."}
