---
name: blender-arriere-plan
description: Exécuter un script Blender en arrière-plan et prouver les fichiers produits.
---

# blender-arriere-plan

- **Domaine** : Blender, pipelines d'assets

## Objectif
Générer ou transformer des assets par script, sans interface.

## Quand l'utiliser
Génération procédurale, exports FBX/GLB, rendus de vignettes.

## Prérequis
Chemin de Blender connu (`outils.blender` dans `studio.config.toml`).

## Étapes
1. Écrire le script dans l'espace isolé de la tâche.
2. `blender --background --factory-startup --python script.py -- <args>`.
3. Écrire les sorties dans l'espace de la tâche, jamais par-dessus un asset existant.

## Vérifications
- Code de retour 0 + chaque fichier attendu présent avec son empreinte.
- Opérations d'interface : signalées comme manuelles.
