---
name: retro-ingenierie
description: Méthode commune (Claude et Codex) pour comprendre un format de fichier, un binaire, un protocole ou du code sans sources — sur copies, avec preuves, sans jamais contourner une protection.
---

# retro-ingenierie

- **Domaine** : formats de fichiers, binaires (.exe, .dll, .so), protocoles, code sans sources, données de jeu (.pak, .uasset…)

## Objectif
Comprendre et documenter comment une chose est faite, de façon reproductible : chaque affirmation a une preuve (offset et
octets, sortie de script, ligne de code) et un niveau de confiance.

## Quand l'utiliser
Rôle « Rétro-ingénieur », ou toute tâche qui demande de lire un fichier dont le format n'est pas documenté, de comprendre
un programme sans ses sources, ou de rendre deux outils compatibles.

## Cadre (avant tout)
1. **Droits** : uniquement les fichiers et logiciels de l'utilisateur, des formats ouverts ou documentés, ou l'interopérabilité de ses
   propres outils. Pour un logiciel ou un asset tiers, lire ses conditions d'utilisation (ou demander au Gardien des
   licences) ; si elles interdisent la rétro-ingénierie, ou dans le doute : **s'arrêter et le signaler**.
2. **Jamais** de contournement : DRM, anti-triche, clé de licence, chiffrement, signature, protection anti-copie. Jamais
   de code malveillant, d'exploit ni de « crack ». Si l'analyse y mène, s'arrêter et le dire.
3. **Analyse statique seulement** : ne jamais exécuter un binaire inconnu, même « pour voir ».
4. **Aucune installation** d'outil (Ghidra, IDA, ImHex…) : le proposer à l'utilisateur avec sa taille ; il décide.

## Outils disponibles
- Python du studio (chemin exact donné dans la mission) avec, s'ils sont installés (Gestion › Outils) : `pefile`
  (exécutables Windows : en-têtes, sections, imports), `lief` (PE, ELF, Mach-O), `capstone` (désassemblage),
  `kaitaistruct` (lecture de formats décrits en .ksy). Sans eux : la bibliothèque standard (`struct`, `zlib`, `hashlib`).
- Vérifier d'abord : `import pefile, lief, capstone, kaitaistruct` ; s'il en manque, le dire et continuer en `struct`.

## Étapes
1. **Copie et empreinte** : copier chaque fichier dans `_re/echantillons/` ; noter la taille et le SHA-256 de l'original
   dans `RETRO.md`. Les originaux ne sont jamais modifiés (empreinte revérifiée à la fin).
2. **Identification** : octets magiques des 16 premiers octets, taille, chaînes lisibles, **entropie par bloc** (proche
   de 8 bits/octet = compressé ou chiffré : si chiffré, s'arrêter là). Exécutable : `pefile`/`lief` (sections, imports,
   ressources, version).
3. **Hypothèses de structure** : comparer plusieurs échantillons (octets qui changent / restent fixes), repérer tailles,
   compteurs, offsets, tables, alignements, ordre des octets (petit/gros boutiste), blocs compressés (essayer `zlib`).
4. **Description formelle** : écrire le format en `.ksy` (Kaitai Struct) dans `_re/formats/` comme spécification lisible,
   et un lecteur Python dans `_re/` ; le lancer sur **tous** les échantillons. Si le format est réécrit : aller-retour
   lecture → écriture → octets identiques.
5. **Code compilé** (si nécessaire et autorisé) : désassembler une fonction ou une plage précise avec `capstone`, à partir
   des adresses trouvées par `pefile`/`lief` ; expliquer ce que fait le code, sans le modifier.
6. **Preuves** : pour chaque champ ou conclusion : offset, octets en hexadécimal, interprétation, et confiance
   **observé** (vérifié sur tous les échantillons) / **déduit** (cohérent mais pas prouvé partout) / **supposé**.

## Rapport `RETRO.md`
- Objet, droits vérifiés (comment), fichiers et empreintes.
- Méthode et outils utilisés.
- Structure trouvée : tableau offset / taille / type / nom / signification / confiance.
- Scripts fournis et comment les relancer (`"<python du studio>" _re/<script>.py`), avec leur sortie.
- Ce qui reste inconnu, et ce qu'il faudrait (autres échantillons, outil à installer, accord de l'utilisateur).

## Vérifications
- Les scripts se relancent et donnent la même sortie.
- Les empreintes des originaux n'ont pas changé.
- Aucune affirmation sans preuve ; aucun secret (clé, mot de passe trouvé dans un binaire) recopié : emplacement seulement.
