---
name: copier-coller
description: Faire participer n'importe quelle IA (site web, appli) à une tâche : copier son contexte, coller sa réponse comme proposition.
---

# copier-coller

- **Domaine** : réflexion, conception, relecture

## Objectif
Donner le contexte utile d'une tâche à l'IA de ton choix (n'importe laquelle, même sans connexion au studio)
et récupérer son analyse sans lui donner accès au PC.

## Quand l'utiliser
Avis d'une autre IA sur un plan ou un résultat, recherche, conception.

## Prérequis
Une tâche existante dans le studio.

## Étapes
1. `{{STUDIO_CMD}} copier <tâche>` → joindre ou coller le fichier dans l'IA choisie.
2. Lui demander une réponse au format « Compte rendu de l'IA » fourni en fin de fichier.
3. Enregistrer sa réponse en .md puis `{{STUDIO_CMD}} coller <tâche> <fichier>`.

## Vérifications
- La réponse reste une **proposition non validée** ; elle n'accorde aucune autorisation.
- Aucun secret dans le fichier copié (masquage automatique, relire avant envoi).
