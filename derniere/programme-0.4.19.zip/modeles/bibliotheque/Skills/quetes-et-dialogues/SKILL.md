---
name: quetes-et-dialogues
description: Écrire des quêtes, dialogues ramifiés et textes de jeu (PNJ, objets, journal) cohérents avec l'univers. À utiliser pour une quête, un arbre de dialogue, des répliques de personnage ou la cohérence du lore.
---

# Quêtes et dialogues

## Méthode
1. **Lire le lore et le ton** du projet (bible, personnages, textes déjà écrits). Relever les noms, faits et règles à respecter.
2. **Quête** : donneur, motivation, objectif clair, étapes (3 à 6), obstacle, choix possibles, conséquences, récompense. Une ligne de résumé en tête.
3. **Dialogue ramifié** : nœuds numérotés ; pour chaque réponse du joueur, la suite et les conditions (variables, réputation, objets). Format texte lisible ou JSON si le projet en utilise un.
4. **Voix des personnages** : une fiche courte par PNJ (vocabulaire, tics, ce qu'il cache). Relire chaque réplique avec la fiche.
5. **Contrôle** : pas de contradiction avec le lore, pas de boucle sans sortie, chaque variable posée est lue quelque part.

## Règles
- Répliques courtes (lisibles en 3 secondes), une idée par réplique.
- Montrer plutôt qu'expliquer ; garder du mystère.
- Indiquer les variables et identifiants techniques en anglais (quest_id, flag names), le texte dans la langue du jeu.
- Préparer une colonne « voix » si les répliques doivent être enregistrées ou synthétisées.
