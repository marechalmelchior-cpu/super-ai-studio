---
name: montage-video-ffmpeg
description: Monter, convertir et préparer des vidéos en ligne de commande avec FFmpeg — découpe, assemblage, sous-titres, musique, compression pour le web ou les réseaux, extraits GIF. À utiliser pour une bande-annonce, une vidéo de démo, un format réseau social ou une conversion.
---

# Montage vidéo avec FFmpeg

## Recettes
- Découper sans réencoder : `ffmpeg -ss 00:00:05 -to 00:00:20 -i in.mp4 -c copy part.mp4`
- Assembler : liste de fichiers + `ffmpeg -f concat -safe 0 -i liste.txt -c copy out.mp4` (mêmes codecs), sinon réencoder.
- Web (H.264) : `ffmpeg -i in.mov -c:v libx264 -crf 22 -preset slow -c:a aac -b:a 160k -movflags +faststart out.mp4`
- Vertical 9:16 (réseaux) : recadrer avec `-vf "crop=ih*9/16:ih,scale=1080:1920"`.
- Sous-titres incrustés : `-vf subtitles=sous-titres.srt`.
- Musique de fond baissée : filtre `amix` avec un volume réduit pour la musique.
- GIF propre : générer une palette (`palettegen`) puis l'appliquer (`paletteuse`).
- Volume normalisé : `-af loudnorm=I=-16:TP=-1.5:LRA=11`.

## Méthode
1. Lire les infos des sources (`ffprobe`) : durée, résolution, images par seconde, codecs.
2. Écrire les commandes dans un script (.ps1 ou .bat) pour pouvoir refaire le montage.
3. Ne jamais écraser une source : sorties dans un dossier « Exports » avec des noms clairs.
4. Vérifier le résultat (durée, taille du fichier, extrait regardé).
