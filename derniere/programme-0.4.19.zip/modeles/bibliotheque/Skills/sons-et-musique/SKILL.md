---
name: sons-et-musique
description: Produire et préparer des sons, musiques et voix pour un jeu ou une vidéo — liste des besoins, création ou génération, nettoyage, normalisation, découpe, formats et intégration. À utiliser pour un sound design, une liste de sons, des voix de personnages ou préparer des fichiers audio.
---

# Sons et musique

## Méthode
1. **Liste des besoins** : chaque son avec son déclencheur, son intention (ex. « pas sur neige, léger »), sa durée, s'il boucle, ses variations (3 à 5 pour les sons répétés).
2. **Création** : banque libre de droits (licence notée), synthèse, enregistrement, ou génération (ElevenLabs si connecté) — en notant la source de chaque fichier.
3. **Nettoyage** : silence en début/fin coupé, bruit réduit, fondus courts pour éviter les clics.
4. **Normalisation** : niveaux cohérents (voix ≈ −16 LUFS pour une vidéo, effets réglés entre eux dans le moteur).
5. **Formats** : WAV 48 kHz pour la source ; OGG pour Godot ou le web ; WAV importé dans Unreal (compression faite par le moteur).
6. **Intégration** : noms clairs en anglais (« SFX_Footstep_Snow_01 », « VO_Merchant_Greeting_01 »), dossiers par catégorie, tableau des fichiers.

## Outils
FFmpeg pour convertir et normaliser en ligne de commande (loudnorm), Audacity ou REAPER pour éditer.

## Règles
- Licence de chaque son notée dans le tableau.
- Garder les sources non compressées à part.
