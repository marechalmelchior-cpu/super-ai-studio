---
name: equilibrage-jeu
description: Équilibrer un jeu avec des chiffres — dégâts, vie, économie, progression, butin, difficulté — par tableaux, formules et simulations. À utiliser pour régler des valeurs, comparer des armes ou des classes, ou vérifier qu'une courbe de progression tient.
---

# Équilibrage

## Méthode
1. **Relever les valeurs actuelles** dans le projet (tables de données, Blueprints, fichiers de config). Les mettre dans un tableau unique (CSV ou Excel).
2. **Fixer la cible** : temps pour tuer (TTK), temps pour mourir, durée d'un niveau, nombre de combats avant une amélioration, revenu par heure.
3. **Écrire les formules** explicitement (dégâts = base × multiplicateur − armure…) et calculer la cible pour chaque cas.
4. **Simuler** : petit script (Python) qui joue des milliers de combats ou de parties et sort moyennes, écarts, pires cas.
5. **Proposer les nouvelles valeurs** avec l'écart chiffré avant/après et la raison.
6. **Vérifier les extrêmes** : meilleur équipement, pire équipement, joueur débutant, joueur expert, combinaisons qui cassent le jeu.

## Règles
- Une seule source de vérité pour les chiffres (table de données), jamais des valeurs éparpillées.
- Changer peu de choses à la fois ; noter chaque changement dans un journal d'équilibrage.
- Toujours livrer le tableau et le script de simulation (code en anglais), pas seulement des conclusions.
