---
name: pipeline-assets-3d
description: Préparer des modèles 3D pour un jeu — échelle, origine, nommage, topologie, UV, LOD, matériaux, export FBX/GLB vers Unreal, Godot ou Unity — et vérifier qu'ils s'importent proprement. À utiliser pour créer, nettoyer ou exporter des assets 3D.
---

# Pipeline d'assets 3D

## Vérifications avant export
- **Échelle** : 1 unité = 1 m dans Blender ; Unreal travaille en cm (export FBX avec échelle adaptée). Vérifier la taille réelle (porte ≈ 2,1 m, personnage ≈ 1,8 m).
- **Origine** : au sol, centrée (ou au pivot logique : charnière d'une porte). Transformations appliquées (rotation 0, échelle 1).
- **Axes** : avant/haut selon le moteur (Unreal : X avant, Z haut ; Godot glTF : −Z avant, Y haut).
- **Topologie** : pas de faces dupliquées, normales cohérentes, budget de polygones respecté.
- **UV** : sans chevauchement pour les lightmaps (2ᵉ canal UV pour Unreal), densité de texels homogène.
- **Matériaux** : un nom clair par matériau, textures en PBR (base color, normal, ORM).
- **LOD** : 2 à 4 niveaux pour les objets fréquents.

## Nommage (en anglais)
SM_ (static mesh), SK_ (skeletal), M_ / MI_ (matériaux), T_ (textures, suffixes _BC _N _ORM), A_ (animations). Ex. « SM_Barrel_01 ».

## Méthode
1. Lire les conventions du projet (CLAUDE.md, dossiers existants) avant tout.
2. Script Blender en arrière-plan quand c'est possible (reproductible), avec un rapport : dimensions, nombre de polygones, matériaux.
3. Exporter dans le dossier d'import du projet, jamais par-dessus un asset existant sans le dire.
4. Prouver le résultat : capture de rendu et dimensions mesurées.
