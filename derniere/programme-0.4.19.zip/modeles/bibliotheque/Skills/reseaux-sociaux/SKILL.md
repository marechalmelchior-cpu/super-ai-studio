---
name: reseaux-sociaux
description: Préparer la communication sur les réseaux sociaux — calendrier éditorial, posts adaptés à chaque réseau, légendes, hashtags, visuels à prévoir, suivi des résultats. À utiliser pour lancer un compte, annoncer une sortie, préparer un mois de publications ou analyser ce qui marche.
---

# Réseaux sociaux

## Méthode
1. **Objectif et public** : notoriété, ventes, réservations, communauté ; qui on veut toucher et où (Instagram, TikTok, X, LinkedIn, YouTube, Discord).
2. **Piliers de contenu** : 3 à 5 thèmes récurrents (coulisses, conseils, nouveautés, communauté, offres).
3. **Calendrier** : tableau date / réseau / pilier / sujet / format / texte / visuel / statut. Rythme réaliste.
4. **Posts** : accroche dans la première ligne, une seule idée, appel à l'action ; adapter longueur et ton au réseau ; 3 à 8 hashtags pertinents.
5. **Visuels** : décrire précisément chaque visuel à produire (format carré, 4:5, 9:16), dans la charte du projet.
6. **Suivi** : portée, interactions, clics, abonnés ; garder ce qui marche, arrêter le reste.

## Règles
- Aucune publication sans validation de l'utilisateur.
- Pas de faux avis, de fausse urgence ni de chiffres inventés.
- Livrer le calendrier en Excel et les textes prêts à copier.
