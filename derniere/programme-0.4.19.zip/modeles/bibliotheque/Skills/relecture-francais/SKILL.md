---
name: relecture-francais
description: Relire et corriger un texte en français — orthographe, grammaire, typographie, clarté, ton — en gardant la voix de l'auteur, avec la liste des corrections importantes. À utiliser pour corriger un texte, un site, des dialogues, un courriel ou un document avant publication.
---

# Relecture en français

## Ce qui est corrigé
- Orthographe, accords, conjugaison, homophones (a/à, ou/où, ces/ses, -é/-er).
- Typographie française : espace insécable avant « : ; ! ? » et à l'intérieur des guillemets « », majuscules accentuées (À, É), points de suspension « … ».
- Clarté : phrases trop longues coupées, répétitions, mots vagues, jargon inutile.
- Cohérence : tutoiement ou vouvoiement constant, noms propres et termes identiques partout.

## Méthode
1. Demander (ou déduire) le public et le ton voulus.
2. Corriger directement le texte en gardant le style de l'auteur : pas de réécriture complète sans demande.
3. Lister à part les changements de sens ou de ton proposés, pour validation.
4. Pour un site ou un jeu : ne toucher qu'au texte visible, jamais aux identifiants ni au code.
