# Conventions communes

- Identifiants de projets et sujets : minuscules, chiffres, `.`, `_`, `-` (ex. `mon-jeu`, `veille-ia`).
- Dates : ISO 8601 (UTC dans les fichiers techniques, heure de Paris dans les comptes rendus).
- Tâches du studio : `Taches/<date titre>/` (RESULTAT.md, captures ; le technique dans `details/`).
- Résultats d'un sujet : `Sujets/<sujet>/<type>/` (Images, Documents, 3D, Sons, Videos, Code, Autres).
- Les projets restent à leur emplacement ; le studio y pointe via `Projets/<id>/project.toml`.
- Scripts Windows : PowerShell, UTF-8 avec BOM, lecture seule par défaut, `-Confirmer` pour toute action.
