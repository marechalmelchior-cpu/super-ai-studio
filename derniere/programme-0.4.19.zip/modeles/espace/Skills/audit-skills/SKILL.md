---
name: audit-skills
description: Auditer les skills des agents (studio, projet, Claude Code, Codex) — usage réel, doublons, skills chargés pour rien, global ou local ; rapport d'abord, corrections sûres seulement sur accord.
---

# audit-skills

- **Domaine** : entretien du studio (bouton Gestion › Entretien › Auditer les skills)
- **Modes** : `audit` (lecture seule, rapport) ; `fix` (applique seulement les corrections sûres du rapport validé)

## Audit (lecture seule)
1. Inventaire : skills du projet (`.claude/skills`, `.agents/skills`), skills du studio (`Skills/`), skills globaux
   (`~/.claude/skills`, `~/.agents/skills`, `~/.codex/skills`). Pour chacun : nom, description, taille, emplacement.
2. Usage observé : chercher le nom du skill dans les historiques des outils s'ils existent (`~/.claude/projects`,
   `~/.codex/sessions`). Jamais de contenu de conversation dans le rapport : seulement « utilisé N fois / jamais ».
3. Problèmes : doublons (même rôle, deux noms), description trop vague pour être déclenchée, skill énorme chargé pour
   une petite tâche, skill propre à un projet installé en global (ou l'inverse), liens cassés.
4. Rapport : 5 lignes de synthèse, puis une ligne par skill `GARDER | METTRE À JOUR | FUSIONNER | ARCHIVER | À VÉRIFIER`
   avec la preuve, puis les corrections classées « sûres » (métadonnées, liens) et « à décider par l'utilisateur ».

## Fix (après validation)
- Seulement les corrections sûres, dans le dossier courant. Rien n'est supprimé : ARCHIVER = déplacer dans les archives.
- Les skills globaux ne sont jamais modifiés : lister les changements proposés.
