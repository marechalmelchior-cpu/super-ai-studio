---
name: isolation-git
description: Travailler sur un dépôt sans toucher aux modifications non enregistrées de l'utilisateur ; pas de push sans accord.
---

# isolation-git

- **Domaine** : projets Git

## Objectif
Éviter les écritures concurrentes et protéger le travail en cours.

## Quand l'utiliser
Toute modification de code dans un projet réel.

## Prérequis
Autorisation d'isolation du projet (`isolation = "worktree"` validée par l'utilisateur).

## Étapes
1. Lecture seule : `git --no-optional-locks status --porcelain`.
2. Créer un worktree séparé par tâche (après autorisation).
3. Un agent = un worktree ou un ensemble de fichiers attribué.
4. Consolider par diff relu, puis appliquer après approbation.

## Vérifications
- Aucun `reset`, `checkout` de fichiers modifiés, `stash` ou `push` sans demande explicite.
- Le diff appliqué correspond au diff approuvé (empreinte).
