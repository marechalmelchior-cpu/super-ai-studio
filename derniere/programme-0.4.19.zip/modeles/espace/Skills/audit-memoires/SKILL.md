---
name: audit-memoires
description: Auditer les fichiers d'instructions des agents (CLAUDE.md, AGENTS.md, règles, skills, plans) contre le code réel — ce qui est faux, en double ou chargé pour rien ; rapport d'abord, nettoyage seulement sur accord.
---

# audit-memoires

- **Domaine** : entretien du studio (bouton Gestion › Entretien › Auditer les mémoires)
- **Modes** : `audit` (lecture seule, rapport) ; `clean` (applique les verdicts du rapport validé)

## Audit (lecture seule)
1. Lister tous les Markdown destinés aux agents dans le projet : `CLAUDE.md`, `AGENTS.md`, règles, skills, plans,
   notes de contexte. Tous, pas un échantillon.
2. Confronter chaque affirmation vérifiable au dépôt (chemins, commandes, noms de classes, versions) : vrai, faux ou
   périmé, avec la preuve (fichier, ligne).
3. Repérer les doublons entre fichiers, les contradictions, et ce qui est chargé à chaque session sans servir.
4. Rapport : 5 lignes de synthèse, puis une ligne par fichier `GARDER | METTRE À JOUR | FUSIONNER | ARCHIVER |
   SUPPRIMER | À VÉRIFIER` avec la preuve.

## Clean (après validation)
- Appliquer les verdicts dans le dossier courant, fichiers Markdown pour agents uniquement.
- Rien n'est supprimé : SUPPRIMER et ARCHIVER = déplacer dans les archives en gardant le chemin ; FUSIONNER = reporter
  le savoir unique dans le fichier de référence puis archiver la source. À VÉRIFIER ne bouge pas.
