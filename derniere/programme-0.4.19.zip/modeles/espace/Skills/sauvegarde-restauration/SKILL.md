---
name: sauvegarde-restauration
description: Sauvegarder le studio et vérifier qu'une sauvegarde se restaure dans un emplacement de test.
---

# sauvegarde-restauration

- **Domaine** : studio

## Objectif
Pouvoir revenir en arrière sans perte.

## Quand l'utiliser
Avant toute mise en service ou changement de configuration ; régulièrement.

## Prérequis
Python du studio.

## Étapes
1. `{{STUDIO_CMD}} sauvegarder` (chiffré DPAPI sous Windows).
2. `{{STUDIO_CMD}} verifier-sauvegarde <archive>`.
3. `{{STUDIO_CMD}} restaurer-test <archive> <dossier-vide>`.

## Vérifications
- `ok: true` et `integrity_check = ok` pour chaque base.
- Jamais de restauration par-dessus les données actives.
