---
name: code-review
description: Relire du code ou un ensemble de changements — bugs, sécurité, performance, lisibilité, tests manquants — et rendre une liste classée par gravité avec corrections proposées. À utiliser pour une revue de pull request, un audit de module ou avant une fusion.
---

# Revue de code

## Ordre de lecture
1. **Comprendre l'intention** (demande, ticket, message de commit) avant de lire le code.
2. **Correction** : logique fausse, cas limites (vide, nul, très grand, concurrence), erreurs non gérées, ressources non libérées.
3. **Sécurité** : entrées non validées, injections (SQL, commandes, chemins), secrets dans le code, droits trop larges.
4. **Performance** : boucles coûteuses, requêtes répétées, allocations inutiles dans les boucles chaudes (Tick dans Unreal, _process dans Godot).
5. **Lisibilité** : noms, fonctions trop longues, duplication, commentaires faux.
6. **Tests** : ce qui n'est pas couvert et devrait l'être.

## Rendu
- Liste du plus grave au moins grave : fichier:ligne, problème, conséquence concrète, correction proposée.
- Séparer « bloquant », « à corriger », « suggestion ».
- Ne rien modifier sans accord quand la demande est une revue.
- Code, identifiants et commentaires proposés en anglais.
