"""Import of skills and instructions already on the PC: a COPY in the studio, which then takes care of them.

- Sources: skills of the subscription tools (~/.claude/skills, ~/.agents/skills, ~/.codex/skills); global
  instructions ~/.claude/CLAUDE.md and ~/.codex/AGENTS.md.
- Copied into the studio workspace: Skills/<name>/ (and Regles/importes/ for the .md files). The originals are never
  modified, moved or deleted: the user removes them if they want.
- Nothing is overwritten: name already taken in the studio → « <name>-importe ». Copies made by the studio (« studio-… »)
  and links are not imported. Automatically only once (data/import-initial.json), then on request.
"""
from __future__ import annotations

import json
import shutil
import time
from pathlib import Path
from .paths import StudioPaths

SOURCES_SKILLS = (".claude/skills", ".agents/skills", ".codex/skills")
SOURCES_MD = ((".claude/CLAUDE.md", "CLAUDE (Claude Code).md"), (".codex/AGENTS.md", "AGENTS (Codex).md"))
STUDIO_MARKER = "genere-par-ai-workspace"
IGNORED = shutil.ignore_patterns("__pycache__", "node_modules", ".git", "*.pyc")
MAX_SKILL_BYTES = 50 * 2**20
MANIFEST = ".import.json"


def _size(d: Path) -> int:
    total = 0
    for p in d.rglob("*"):
        try:
            if p.is_file() and not p.is_symlink():
                total += p.stat().st_size
        except OSError:
            pass
    return total


def _from_studio(d: Path) -> bool:
    if d.name.startswith("studio-"):
        return True
    try:
        return STUDIO_MARKER in (d / "SKILL.md").read_text(encoding="utf-8", errors="replace")[:2000]
    except OSError:
        return False


def import_(root_dir: Path, home: Path | None = None) -> dict:
    """Copies what is not yet in the studio. Returns {skills, instructions, ignores}."""
    root_dir, home = Path(root_dir), Path(home or Path.home())
    dest_skills = root_dir / "Skills"
    dest_skills.mkdir(parents=True, exist_ok=True)
    report = {"skills": [], "instructions": [], "ignores": []}
    already: dict[str, Path] = {}                       # SKILL.md content → studio skill (same skill seen in both tools)
    for d in dest_skills.iterdir():
        f = d / MANIFEST
        if f.is_file():
            try:
                for o in json.loads(f.read_text(encoding="utf-8")).get("origines", []):
                    already[o] = d
            except (OSError, ValueError):
                pass
    contents: dict[str, Path] = {}
    for rel in SOURCES_SKILLS:
        base = home / rel
        if not base.is_dir():
            continue
        for d in sorted(base.iterdir()):
            try:
                if d.is_symlink() or not d.is_dir() or not (d / "SKILL.md").is_file() or _from_studio(d):
                    continue
                origin = str(d)
                if origin in already:
                    continue
                texte = (d / "SKILL.md").read_text(encoding="utf-8", errors="replace")
                if texte in contents:                 # same skill already copied from the other tool: record the origin
                    cible = contents[texte]
                    _add_origin(cible, origin)
                    continue
                if _size(d) > MAX_SKILL_BYTES:
                    report["ignores"].append(f"{d.name} (plus de 50 Mo)")
                    continue
                nom, n = d.name, 1
                cible = dest_skills / nom
                while cible.exists():
                    if (cible / "SKILL.md").is_file() and (cible / "SKILL.md").read_text(encoding="utf-8", errors="replace") == texte:
                        break                         # the same skill is already in the studio: nothing to copy
                    n += 1
                    cible = dest_skills / (f"{d.name}-importe" if n == 2 else f"{d.name}-importe-{n - 1}")
                if cible.exists():
                    _add_origin(cible, origin)
                    contents[texte] = cible
                    continue
                shutil.copytree(d, cible, symlinks=False, ignore=IGNORED, ignore_dangling_symlinks=True)
                _add_origin(cible, origin)
                h, recent = folder_fingerprint(cible)
                sheet = _manifest(cible)
                sheet.update(empreinte=h, date_origine=folder_date(d))
                _write_manifest(cible, sheet)
                contents[texte] = cible
                report["skills"].append(cible.name)
            except OSError as e:
                report["ignores"].append(f"{d.name} ({type(e).__name__})")
    from .paths import StudioPaths
    dest_md = StudioPaths(Path(root_dir)).imported_rules
    for rel, nom in SOURCES_MD:
        src = home / rel
        cible = dest_md / nom
        try:
            if src.is_file() and not cible.exists():
                dest_md.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src, cible)
                report["instructions"].append(nom)
        except OSError as e:
            report["ignores"].append(f"{rel} ({type(e).__name__})")
    return report


def _add_origin(skill: Path, origin: str) -> None:
    f = skill / MANIFEST
    try:
        d = json.loads(f.read_text(encoding="utf-8")) if f.exists() else {}
    except (OSError, ValueError):
        d = {}
    d.setdefault("importe", time.strftime("%Y-%m-%d %H:%M"))
    d["origines"] = sorted(set(d.get("origines", [])) | {origin})
    f.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")


def import_once(root_dir: Path, data: Path, home: Path | None = None) -> dict | None:
    """On first launch (or the first opening after the update): only once."""
    marker = Path(data) / "import-initial.json"
    if marker.exists():
        return None
    r = import_(root_dir, home)
    marker.parent.mkdir(parents=True, exist_ok=True)
    marker.write_text(json.dumps({"date": time.strftime("%Y-%m-%d %H:%M"), **r}, ensure_ascii=False, indent=1), encoding="utf-8")
    return r


def origins(skill: Path) -> set[str]:
    try:
        return set(json.loads((Path(skill) / MANIFEST).read_text(encoding="utf-8")).get("origines", []))
    except (OSError, ValueError):
        return set()


# ------------------------------------------------------------------ tracking the originals after the copy
def folder_fingerprint(d: Path) -> tuple[str, float]:
    """(content fingerprint, most recent date) of a skill, excluding the studio's card and ignored heavy files."""
    import hashlib
    h, recent = hashlib.sha256(), 0.0
    for p in sorted(Path(d).rglob("*")):
        rel = p.relative_to(d).as_posix()
        if not p.is_file() or p.name == MANIFEST or any(x in ("__pycache__", "node_modules", ".git") for x in p.parts):
            continue
        try:
            st = p.stat()
            recent = max(recent, st.st_mtime)
            h.update(rel.encode() + b"\0" + hashlib.sha256(p.read_bytes()).digest())
        except OSError:
            continue
    return h.hexdigest()[:24], recent


def folder_date(d: Path) -> float:
    """Most recent date of a skill: a few stat() calls, no file read."""
    recent = 0.0
    for p in Path(d).rglob("*"):
        if p.name == MANIFEST or any(x in ("__pycache__", "node_modules", ".git") for x in p.parts):
            continue
        try:
            if p.is_file():
                recent = max(recent, p.stat().st_mtime)
        except OSError:
            pass
    return recent


def _manifest(skill: Path) -> dict:
    try:
        return json.loads((skill / MANIFEST).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def _write_manifest(skill: Path, d: dict) -> None:
    (skill / MANIFEST).write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")


def _replace_copy(root_dir: Path, skill: Path, origin: Path) -> None:
    """IN-PLACE update of the studio's copy from the original: new or changed files copied again, files
    gone from the original removed from the copy. No other copy is made (no archive on each update)."""
    sheet = _manifest(skill)
    ignores = ("__pycache__", "node_modules", ".git")
    desired = set()
    for p in Path(origin).rglob("*"):
        if p.is_symlink() or not p.is_file() or any(x in ignores for x in p.parts) or p.suffix == ".pyc":
            continue
        rel = p.relative_to(origin)
        desired.add(rel.as_posix())
        d = skill / rel
        try:
            if d.is_file() and d.stat().st_size == p.stat().st_size and d.read_bytes() == p.read_bytes():
                continue
            d.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(p, d)
        except OSError:
            pass
    for p in sorted(skill.rglob("*"), reverse=True):        # what the original no longer has (except the studio's card)
        rel = p.relative_to(skill).as_posix()
        try:
            if p.is_file() and p.name != MANIFEST and rel not in desired:
                p.unlink()
            elif p.is_dir() and not any(p.iterdir()):
                p.rmdir()
        except OSError:
            pass
    h, recent = folder_fingerprint(skill)
    sheet.update(empreinte=h, date_origine=folder_date(origin), maj=time.strftime("%Y-%m-%d %H:%M"))
    sheet.pop("conflit", None)
    sheet.pop("conflit_origine", None)
    _write_manifest(skill, sheet)


def track(root_dir: Path, data: Path | None = None, home: Path | None = None) -> dict:
    """Skills and instructions imported from the PC: if the original changed outside the studio, NOTHING is replaced
    automatically: an update is offered (« Mettre à jour dans le studio » / « Garder la version du studio »), only once
    per version. Fast: an original is read again only if its date changed."""
    report = {"propositions": []}
    base = Path(root_dir) / "Skills"
    for skill in (sorted(base.iterdir()) if base.is_dir() else []):
        sheet = _manifest(skill)
        if not sheet.get("origines"):
            continue
        existing = [Path(o) for o in sheet["origines"] if (Path(o) / "SKILL.md").is_file()]
        if not existing:
            continue
        if "empreinte" not in sheet:                       # skill imported before tracking existed: starting point = now
            sheet.update(empreinte=folder_fingerprint(skill)[0], date_origine=max(folder_date(o) for o in existing))
            _write_manifest(skill, sheet)
            continue
        dates = {o: folder_date(o) for o in existing}
        origin = max(existing, key=dates.get)
        if dates[origin] <= float(sheet.get("date_origine", 0)):
            continue                                       # original untouched: nothing to read
        h_orig, recent = folder_fingerprint(origin)
        sheet["date_origine"] = recent
        if h_orig not in (sheet["empreinte"], sheet.get("refusee")) and (sheet.get("proposition") or {}).get("empreinte") != h_orig:
            two = folder_fingerprint(skill)[0] != sheet["empreinte"]          # also modified in the studio
            sheet["proposition"] = {"empreinte": h_orig, "origine": str(origin), "deux_cotes": two}
            report["propositions"].append(f"skill « {skill.name} »")
        _write_manifest(skill, sheet)
    if data is not None:                                   # imported CLAUDE.md / AGENTS.md
        report["propositions"] += _track_md(Path(root_dir), Path(data), Path(home or Path.home()))
    return report


def _tracking_md(data: Path) -> dict:
    try:
        return json.loads((data / "import-md.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def _track_md(root_dir: Path, data: Path, home: Path) -> list[str]:
    import hashlib
    tracking, change, out = _tracking_md(data), False, []
    for rel, nom in SOURCES_MD:
        src, copy_dir = home / rel, StudioPaths(Path(root_dir)).imported_rules / nom
        if not src.is_file() or not copy_dir.is_file():
            continue
        e = tracking.get(nom)
        try:
            mt = src.stat().st_mtime
            if e is None:                                  # starting point: the current copy
                tracking[nom] = {"empreinte": hashlib.sha256(copy_dir.read_bytes()).hexdigest()[:24], "date": mt}
                change = True
                continue
            if mt <= e.get("date", 0):
                continue
            h = hashlib.sha256(src.read_bytes()).hexdigest()[:24]
            e["date"] = mt
            change = True
            if h not in (e["empreinte"], e.get("refusee")) and (e.get("proposition") or {}).get("empreinte") != h:
                e["proposition"] = {"empreinte": h, "origine": str(src),
                                    "deux_cotes": hashlib.sha256(copy_dir.read_bytes()).hexdigest()[:24] != e["empreinte"]}
                out.append(f"instructions « {nom} »")
        except OSError:
            continue
    if change:
        (data / "import-md.json").write_text(json.dumps(tracking, ensure_ascii=False, indent=1), encoding="utf-8")
    return out


def proposals(root_dir: Path, data: Path | None = None) -> list[dict]:
    """Updates waiting for the user's answer."""
    out = []
    base = Path(root_dir) / "Skills"
    for skill in (sorted(base.iterdir()) if base.is_dir() else []):
        p = _manifest(skill).get("proposition")
        if p:
            out.append({"id": f"skill:{skill.name}", "nom": skill.name, "genre": "skill", "origine": p["origine"],
                        "deux_cotes": bool(p.get("deux_cotes"))})
    for nom, e in (_tracking_md(Path(data)) if data is not None else {}).items():
        p = e.get("proposition")
        if p:
            out.append({"id": f"md:{nom}", "nom": nom, "genre": "instructions", "origine": p["origine"],
                        "deux_cotes": bool(p.get("deux_cotes"))})
    return out


def settle(root_dir: Path, ident: str, choice: str, data: Path | None = None) -> dict:
    """« original »: the studio takes the version from the source folder (in-place update);
    « studio »: keep the studio's version and stop asking for THIS version of the original."""
    import hashlib
    genre, _, nom = ident.partition(":")
    if not nom or "/" in nom or "\\" in nom or ".." in nom:
        raise ValueError("Élément inconnu.")
    if genre == "skill":
        skill = Path(root_dir) / "Skills" / nom
        f = _manifest(skill)
        p = f.get("proposition")
        if not p:
            raise ValueError("Aucune mise à jour en attente pour cette skill.")
        if choice == "original":
            if not (Path(p["origine"]) / "SKILL.md").is_file():
                raise ValueError("L'original n'existe plus.")
            _replace_copy(root_dir, skill, Path(p["origine"]))
            f = _manifest(skill)
            f.pop("proposition", None)
            _write_manifest(skill, f)
            return {"ok": True, "message": f"Skill {nom} mise à jour dans le studio."}
        f.pop("proposition", None)
        f["refusee"] = p["empreinte"]
        _write_manifest(skill, f)
        return {"ok": True, "message": f"Skill {nom} : la version du studio est gardée."}
    if genre == "md" and data is not None:
        tracking = _tracking_md(Path(data))
        e = tracking.get(nom) or {}
        p = e.get("proposition")
        if not p:
            raise ValueError("Aucune mise à jour en attente pour ce fichier.")
        copy_dir = StudioPaths(Path(root_dir)).imported_rules / nom
        if choice == "original":
            shutil.copy2(p["origine"], copy_dir)
            e["empreinte"] = hashlib.sha256(copy_dir.read_bytes()).hexdigest()[:24]
            msg = f"{nom} mis à jour dans le studio."
        else:
            msg = f"{nom} : la version du studio est gardée."
        e.pop("proposition", None)
        e["refusee"] = p["empreinte"]
        (Path(data) / "import-md.json").write_text(json.dumps(tracking, ensure_ascii=False, indent=1), encoding="utf-8")
        return {"ok": True, "message": msg}
    raise ValueError("Élément inconnu.")
