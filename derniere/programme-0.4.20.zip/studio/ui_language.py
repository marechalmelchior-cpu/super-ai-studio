"""Studio language (Réglages › Langue): the Supervisor and the agents reply in the chosen language."""
from __future__ import annotations

INSTRUCTIONS = {
    "en": ("\n\n# Language\nThe user chose ENGLISH. Always write to the user in English (answers, proposals, reports, summaries), "
           "even though these instructions are in French. File names and code stay as they are."),
}


def ui_language(cfg: dict) -> str:
    v = str((cfg.get("utilisateur") or {}).get("langue") or "fr")
    return v if v in ("fr", "en") else "fr"


def instruction(cfg: dict) -> str:
    return INSTRUCTIONS.get(ui_language(cfg), "")
