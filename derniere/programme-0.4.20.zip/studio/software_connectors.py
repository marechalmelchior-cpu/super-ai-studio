"""Connectors: PC software the agents can use (Blender, Unreal Editor, Krita, ffmpeg…).

Empty by default: everyone adds their own (Accueil › Réglages › Connecteurs). Blender and Unreal keep their place in
studio.config.toml ([outils]) because studio features use them; the others go in
data/connecteurs.json. Only the name and path are passed to agents.
"""
from __future__ import annotations

import json
import re
import secrets
from pathlib import Path

TYPES = {"blender": ("Blender", "outils", "blender"), "unreal": ("Unreal Editor (UnrealEditor-Cmd.exe)", "outils", "unreal_editor_cmd")}
SUGGESTIONS = ["Blender", "Unreal Editor", "Godot", "Unity", "Krita", "GIMP", "Inkscape", "ffmpeg", "Audacity", "OBS Studio",
               "DaVinci Resolve", "Visual Studio Code", "Node.js", "Docker"]


def _file(studio) -> Path:
    return studio.paths.data / "connecteurs.json"


def _personal(studio) -> list[dict]:
    try:
        l = json.loads(_file(studio).read_text(encoding="utf-8"))
        return [c for c in l if isinstance(c, dict) and c.get("id") and c.get("nom")]
    except (OSError, ValueError):
        return []


def list_all(studio) -> list[dict]:
    out = []
    for t, (nom, section, cle) in TYPES.items():
        chemin = str(studio.cfg.get(section, {}).get(cle, "") or "")
        if chemin:
            out.append({"id": t, "nom": nom, "chemin": chemin, "type": t, "ok": Path(chemin).exists()})
    for c in _personal(studio):
        out.append({**c, "type": "autre", "ok": Path(c.get("chemin", "")).exists()})
    return out


def _validate_path(chemin: str) -> str:
    chemin = (chemin or "").strip().strip('"')
    if not chemin or "\n" in chemin or "'" in chemin or len(chemin) > 400:
        raise ValueError("Indique le chemin complet du programme (ex. C:\\Program Files\\Krita\\bin\\krita.exe).")
    if not (re.match(r"^[A-Za-z]:[\\/]", chemin) or chemin.startswith("/")):
        raise ValueError("Chemin complet attendu (ex. C:\\…\\programme.exe).")
    return chemin


def add_item(studio, nom: str, chemin: str) -> list[dict]:
    from . import settings
    nom = re.sub(r"[\r\n]", " ", (nom or "").strip())[:60]
    if not nom:
        raise ValueError("Donne un nom au connecteur.")
    chemin = _validate_path(chemin)
    bottom = nom.lower()
    t = "blender" if "blender" in bottom else "unreal" if "unreal" in bottom else ""
    if t:
        _, section, cle = TYPES[t]
        settings.store_file(studio.paths.config_file, section, cle, chemin)
        studio.cfg.setdefault(section, {})[cle] = chemin
    else:
        l = _personal(studio)
        l.append({"id": f"c-{secrets.token_hex(3)}", "nom": nom, "chemin": chemin})
        _file(studio).write_text(json.dumps(l, ensure_ascii=False, indent=1), encoding="utf-8")
    return list_all(studio)


def retire(studio, ident: str) -> list[dict]:
    from . import settings
    if ident in TYPES:
        _, section, cle = TYPES[ident]
        settings.store_file(studio.paths.config_file, section, cle, "")
        studio.cfg.setdefault(section, {})[cle] = ""
    else:
        _file(studio).write_text(json.dumps([c for c in _personal(studio) if c["id"] != ident], ensure_ascii=False, indent=1),
                                    encoding="utf-8")
    return list_all(studio)


def for_agents(studio) -> str:
    """Mission note: declared software (name and path only)."""
    l = [c for c in list_all(studio) if c["type"] == "autre" and c["ok"]]
    return ("Logiciels du PC déclarés par l'utilisateur (utilisables si ton outil le permet, sinon cite-les dans le compte rendu) : "
            + " ; ".join(f"{c['nom']} ({c['chemin']})" for c in l)) if l else ""
