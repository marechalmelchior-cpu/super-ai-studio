"""Per-project team: roles stay shared (Studio/roles), each project tunes its own.

For each project (data/equipes.json):
- per role: enabled or not, model, effort, project-specific instructions (added to the mission);
- MCP servers enabled in this project (empty = no setting: all those from Extensions);
- project-specific agents: roles whose card has ``projets = ["project:x"]`` (offered only there).
Order of choices for a task: the request > the project team > the role setting > the preset.
"""
from __future__ import annotations

import json
import os
import re
from pathlib import Path

EFFORTS = ("", "low", "medium", "high", "xhigh", "max")


def _f(data: Path) -> Path:
    return Path(data) / "equipes.json"


def read_file(data: Path) -> dict:
    try:
        d = json.loads(_f(data).read_text(encoding="utf-8"))
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def _write(data: Path, d: dict) -> None:
    f = _f(data)
    f.parent.mkdir(parents=True, exist_ok=True)
    t = f.with_suffix(".tmp")
    t.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
    os.replace(t, f)


def setting(data: Path, cible: str, role_id: str) -> dict:
    return ((read_file(data).get(cible) or {}).get("roles") or {}).get(role_id) or {}


def active(data: Path, cible: str, role) -> bool:
    if role.projects_list and cible not in role.projects_list:
        return False
    return setting(data, cible, role.id).get("actif", True) is not False


def project_roles(roles: dict, data: Path, cible: str) -> dict:
    """Roles offered for this project (the auditor always stays)."""
    return {k: r for k, r in roles.items() if k == "auditeur" or active(data, cible, r)}


def project_mcp(data: Path, cible: str) -> list[str] | None:
    v = (read_file(data).get(cible) or {}).get("mcp")
    return [str(x) for x in v] if isinstance(v, list) else None


def configure_role(studio, cible: str, role_id: str, field_values: dict) -> dict:
    if role_id not in studio.roles or role_id == "auditeur":
        raise ValueError("Métier inconnu.")
    d = read_file(studio.paths.data)
    r = d.setdefault(cible, {}).setdefault("roles", {}).setdefault(role_id, {})
    if "actif" in field_values:
        r["actif"] = bool(field_values["actif"])
    if "modele" in field_values:
        m = str(field_values["modele"] or "")
        if not re.fullmatch(r"[A-Za-z0-9._:/@-]{0,100}", m):
            raise ValueError("Modèle invalide.")
        r["modele"] = m
    if "effort" in field_values:
        if field_values["effort"] not in EFFORTS:
            raise ValueError("Effort invalide.")
        r["effort"] = field_values["effort"]
    if "consignes" in field_values:
        c = str(field_values["consignes"] or "").strip()
        if len(c) > 4000:
            raise ValueError("Consignes trop longues (4000 caractères).")
        r["consignes"] = c
    d[cible]["roles"][role_id] = {k: v for k, v in r.items() if v not in ("", None) or k == "actif"}
    if d[cible]["roles"][role_id] == {"actif": True}:
        d[cible]["roles"].pop(role_id)
    _write(studio.paths.data, d)
    return project_view(studio, cible)


def configure_mcp(studio, cible: str, names: list[str] | None) -> dict:
    d = read_file(studio.paths.data)
    if names is None:
        d.setdefault(cible, {}).pop("mcp", None)
    else:
        d.setdefault(cible, {})["mcp"] = [str(n) for n in names if re.fullmatch(r"[a-z0-9-]{1,60}", str(n))]
    _write(studio.paths.data, d)
    return project_view(studio, cible)


def project_view(studio, cible: str) -> dict:
    """Project team: each role with its settings (project and shared), and the enabled MCP servers."""
    from .library import installed_mcp
    eq = (read_file(studio.paths.data).get(cible) or {})
    out = []
    for r in sorted(studio.roles.values(), key=lambda x: x.nom.lower()):
        if r.id == "auditeur" or (r.projects_list and cible not in r.projects_list):
            continue
        g = (eq.get("roles") or {}).get(r.id) or {}
        out.append({"id": r.id, "nom": r.nom, "outil": r.executeur, "actif": g.get("actif", True) is not False,
                    "modele": g.get("modele", ""), "effort": g.get("effort", ""), "consignes": g.get("consignes", ""),
                    "modele_commun": studio.model_list().get(r.id, "") or r.modele, "effort_commun": studio.efforts().get(r.id, "") or r.effort,
                    "propre": bool(r.projects_list), "personnalise": bool({k for k in g if k != "actif"} or g.get("actif") is False)})
    servers = sorted(installed_mcp(studio.paths.data))
    choice = eq.get("mcp")
    return {"cible": cible, "roles": out, "mcp": [{"nom": n, "actif": choice is None or n in choice} for n in servers],
            "mcp_regle": isinstance(choice, list)}


def board(studio) -> dict:
    """Management view: projects × roles (enabled, customized, working)."""
    act = {}
    for a in studio.activity():
        act.setdefault(a["target"], {})[a["role"]] = a["etat"]
    projects_list = [t for t in studio.registry.all()]
    cols = []
    for t in projects_list:
        cle = f"{t.kind}:{t.id}"
        v = project_view(studio, cle)
        enc = act.get(cle, {}) or act.get(t.id, {})
        cols.append({"cle": cle, "nom": t.nom, "profil": studio.profile(cle), "roles": {r["id"]: {"actif": r["actif"], "personnalise": r["personnalise"],
                                                                  "propre": r["propre"], "etat": enc.get(r["id"], "")} for r in v["roles"]}})
    roles = [{"id": r.id, "nom": r.nom} for r in sorted(studio.roles.values(), key=lambda x: x.nom.lower()) if r.id != "auditeur"]
    return {"projets": cols, "roles": roles}
