"""Local studio interface (http://127.0.0.1:8765), standard library only.

Security:
- listens on 127.0.0.1 only (otherwise the configuration is rejected at load time);
- Host header checked (against DNS rebinding);
- POST requests require the ``X-Studio: 1`` header (a third-party site cannot add it);
- with the launcher (desktop shortcut): random single-use session key, exchanged for an
  HttpOnly/SameSite=Strict cookie; without that cookie nothing is served. The key changes at every start.
Starts only on explicit request (shortcut or ``python -m studio interface``); no permanent service:
with the launcher, the server stops by itself when no window is open and no task is running.
"""
from __future__ import annotations

import hmac
import json
import re
import threading
import time
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

from ..orchestrator.store import TERMINAL
from ..security import redact

STATIC = Path(__file__).parent / "static"
_TID = re.compile(r"^T\d{8}-\d{6}-[0-9a-f]{6}$")
_BACKUP = re.compile(r"^studio-\d{8}T\d{6}Z\.(dpapi|zip)$")
COOKIE = "studio_session"


class Control:
    """Window presence, tasks started from the interface, clean shutdown."""

    def __init__(self, absence_delay_s: float | None = None, grace_s: float = 120.0):
        self.absence_delay_s = absence_delay_s        # None = no automatic shutdown (manual « interface » mode)
        self.last_seen = time.monotonic() + grace_s
        self.jobs = 0
        self.stop_request = threading.Event()
        self._lock = threading.Lock()
        self.keep = lambda: False                   # true = stay open without a window (phone access active)

    def presence(self):
        self.last_seen = max(self.last_seen, time.monotonic())

    def begin(self):
        with self._lock:
            self.jobs += 1

    def finish(self):
        with self._lock:
            self.jobs -= 1

    def should_stop(self) -> bool:
        if self.stop_request.is_set():
            return self.jobs == 0
        if self.absence_delay_s is None or self.keep():
            return False
        return self.jobs == 0 and time.monotonic() - self.last_seen > self.absence_delay_s


_FOLDER_KEYS = ("backups", "tasks", "archives", "deliverables", "rules", "projects", "topics")   # folders the UI may open
_GROUPS = [  # (group label shown in the UI, patterns relative to the root; {key} = localized folder name) — display order
    # One place per kind of file, nothing twice: the studio's skills are the single source (each AI gets them,
    # copied into the tools that have their own skills folder), the rules are shared by every AI.
    ("Skills", ["Skills/*/SKILL.md"]),
    ("Règles communes", ["{rules}/*.md", "{rules}/{imported}/*.md"]),
    ("Projets et sujets", ["{projects}/*/*.md", "{projects}/*/*.toml", "{topics}/*/*.md", "{topics}/*/*.toml"]),
    ("Rôles de l'équipe", ["Studio/roles/*.toml"]),
]
_SUBGROUP_FOLDERS = ("Projets et sujets",)          # sub-heading = the project or topic folder
_PROJECT_SKILL_DIRS = (".claude/skills", ".agents/skills")   # where agent tools look for a project's own skills


def _title(p: Path) -> str:
    """Readable title: « name: » of a SKILL.md, else first Markdown heading, else TOML « nom = », else the file name."""
    try:
        head = p.read_text(encoding="utf-8", errors="replace").splitlines()[:40]
    except OSError:
        return p.name
    for l in head:
        if p.name == "SKILL.md" and l.startswith("name:"):
            return l.split(":", 1)[1].strip()
        if l.startswith("# "):
            return l[2:].strip()
        if p.suffix == ".toml" and l.startswith("nom ="):
            return l.split("=", 1)[1].strip().strip('"')
    return p.name


def _home() -> Path:
    return Path.home()


def _documents(root: Path, studio=None) -> list[dict]:
    """Documents grouped: the studio's own (Markdown and TOML settings, excluding templates and data), then installed
    skills (global ones of each subscription tool) and those of registered projects. Read-only; never any other file."""
    seen_items, out = set(), []

    def add_item(group: str, src_files: list[tuple[str, Path, str]]):
        task_files = []
        from ..agent_tools import is_rules_copy
        for chemin, p, subdir in src_files:
            if subdir == "Importées de ton PC" and is_rules_copy(p.read_text(encoding="utf-8", errors="replace")):
                continue                                   # a mere copy of the common rules: not listed twice
            if p.is_file() and p not in seen_items:
                seen_items.add(p)
                task_files.append({"chemin": chemin, "titre": _title(p), "sous_groupe": subdir, "_p": p})
        if task_files:
            out.append({"groupe": group, "fichiers": task_files})

    from ..paths import StudioPaths
    folder_names = StudioPaths(root).names
    for group, patterns in _GROUPS:
        src = []
        for m in (x.format(**folder_names) for x in patterns):
            for p in sorted(root.glob(m)):
                if "_modele" in p.parts:
                    continue
                rel = p.relative_to(root).as_posix()
                parts = rel.split("/")
                sub = parts[1] if group in _SUBGROUP_FOLDERS and len(parts) > 2 else \
                    "Importées de ton PC" if group == "Règles communes" and len(parts) > 2 else ""
                src.append((rel, p, sub))
        add_item(group, src)
    if studio is not None:                  # a project's own skills, in its repository (one entry per skill name)
        for t in studio.registry.all():
            if t.kind == "project" and t.has_path and t.path().is_dir():
                names, entries = set(), []
                for d in _PROJECT_SKILL_DIRS:
                    for p in sorted((t.path() / d).glob("*/SKILL.md")):
                        if p.parent.name not in names:
                            names.add(p.parent.name)
                            entries.append((f"projet:{t.id}/{d}/{p.parent.name}/SKILL.md", p, ""))
                add_item(f"Skills du projet {t.nom}", entries)
    return out


def _public(groups: list[dict]) -> list[dict]:
    return [{"groupe": g["groupe"], "fichiers": [{k: v for k, v in f.items() if k != "_p"} for f in g["fichiers"]]} for g in groups]


def _doc_paths(root: Path, studio=None) -> dict[str, Path]:
    return {f["chemin"]: f["_p"] for g in _documents(root, studio) for f in g["fichiers"]}


def _pairing_page(message: str = "") -> bytes:
    """Page shown to a phone not yet paired: it types the 6-digit code displayed on the PC."""
    import html
    m = f"<p style='color:#b42318'>{html.escape(message)}</p>" if message else ""
    return ("<!doctype html><html lang=fr><meta charset=utf-8><meta name=viewport content='width=device-width,initial-scale=1'>"
            "<meta name=theme-color content='#0f1115'><title>Super AI Agent Pro Station Max 2000</title>"
            "<body style='font:17px system-ui;margin:0;padding:32px 20px;background:#0f1115;color:#e8eaed'>"
            "<img src='/icon-192.png' alt='' width=64 height=64 style='border-radius:14px'>"
            "<h1 style='font-size:21px'>Associer ce téléphone</h1>"
            "<p style='color:#9aa0a6'>Sur le PC : Superviseur › Réglages › Téléphone › « Associer un téléphone ». "
            "Tape ici le code affiché.</p>" + m +
            "<form method=post action='/associer' style='display:flex;gap:10px;margin-top:18px'>"
            "<input name=code inputmode=numeric autocomplete=one-time-code pattern='[0-9 ]*' maxlength=7 required autofocus "
            "placeholder='123456' style='flex:1;min-width:0;width:100%;box-sizing:border-box;font:24px ui-monospace,monospace;letter-spacing:4px;padding:12px;"
            "border-radius:10px;border:1px solid #3c4043;background:#1b1e24;color:inherit'>"
            "<button style='font:600 17px system-ui;padding:0 20px;border:0;border-radius:10px;background:#8ab4f8;"
            "color:#0f1115'>OK</button></form></body></html>").encode()


def make_handler(studio, port: int, token: str | None = None, controller: Control | None = None):
    allowed_hosts = {f"127.0.0.1:{port}", f"localhost:{port}"}
    # Runs from the interface: up to N tasks in parallel (limites.taches_simultanees), one per project.
    parallel_slots = threading.BoundedSemaphore(max(1, int(studio.cfg["limites"].get("taches_simultanees", 1))))
    locks: dict[str, threading.Lock] = {}
    locks_guard = threading.Lock()
    ctl = controller or Control()
    from .. import actions, chains
    jobs = actions.Jobs(ctl)
    root = studio.paths.root
    from ..supervisor import Supervisor
    sup = getattr(studio, "supervisor", None) or Supervisor(studio)
    studio.supervisor = sup

    def target_key(target: str) -> str:
        try:
            t = studio.registry.get(target)
            return f"{t.kind}:{t.id}"
        except (KeyError, ValueError):
            return target

    def team(t, cle: str, act: list[dict]) -> list[dict]:
        """All roles for this target: suitable ones first; what each one does here or elsewhere."""
        types = {t.type, "topic"} if t.kind == "topic" else {t.type}
        model_list = studio.model_list()
        out = []
        for r in studio.roles.values():
            here = [a for a in act if a["role"] == r.id and target_key(a["target"]) == cle]
            elsewhere = [{**a, "cible": target_key(a["target"])} for a in act
                        if a["role"] == r.id and a["etat"] == "travaille" and target_key(a["target"]) != cle]
            etat = ("travaille" if any(a["etat"] == "travaille" for a in here) else "attend_mel" if any(a["etat"] == "attend_mel" for a in here)
                    else "en_pause" if here else "ailleurs" if elsewhere else "libre")
            out.append({"id": r.id, "nom": r.nom, "outil": r.executeur, "modele": model_list.get(r.id, ""),
                        "adapte": r.id == "auditeur" or bool(types & set(r.domains)), "etat": etat,
                        "ici": here, "ailleurs": elsewhere})
        order = {"travaille": 0, "attend_mel": 1, "en_pause": 2, "ailleurs": 3, "libre": 4}
        return sorted(out, key=lambda x: (order[x["etat"]], not x["adapte"], x["id"] == "auditeur", x["nom"]))   # who is working first

    def projects_list(act: list[dict] | None = None) -> list[dict]:
        tasks = studio.store.list(1000)
        act = studio.activity() if act is None else act
        out = []
        studio_t = studio.registry.studio_target()             # the studio itself: only once it has tasks (audits), never a tab
        extra = [studio_t] if any(x["target"] == f"project:{studio_t.id}" for x in tasks) else []
        for t in [*studio.registry.all(), *extra]:
            cle = f"{t.kind}:{t.id}"
            mine = [x for x in tasks if target_key(x["target"]) == cle]
            cpt = {"a_valider": 0, "en_cours": 0, "terminees": 0}
            for x in mine:
                s = x["status"]
                cpt["a_valider" if s.startswith("a_approuver") else "terminees" if s in TERMINAL else "en_cours"] += 1
            at_work = sorted({studio.roles[a["role"]].nom for a in act if a["etat"] == "travaille"
                                 and target_key(a["target"]) == cle and a["role"] in studio.roles})
            out.append({**t.to_public(), "cle": cle, "interne": bool(t.extra.get("interne")),
                        "dossier": str(t.path()) if t.has_path else "", "compteurs": cpt,
                        "derniere": mine[0] if mine else None, "au_travail": at_work, "cree": str(t.extra.get("cree", ""))})
        return sorted(out, key=lambda p: p["cree"], reverse=True)          # stable sort: undated items keep their original order

    def with_action(tasks: list[dict]) -> list[dict]:
        """Running tasks: the agent's last action in plain words (« Modifie EnemyBase.cpp »), for the list card.
        Tasks awaiting approval: a preview of what they produced (first images, file count), to approve without opening."""
        from .. import activity
        from ..task_files import IMAGES
        for x in tasks:
            if str(x["status"]).startswith("a_approuver"):
                try:
                    paths = sorted({a["path"] for a in studio.store.artifacts(x["id"])})
                    x["apercus"] = [p for p in paths if p.lower().endswith(tuple(IMAGES))][:3]
                    x["nb_fichiers"] = len(paths)
                except Exception:                 # noqa: BLE001 — optional
                    pass
            if x["status"] in ("creee", "en_cours") and x.get("etape_nom") in ("execution", "audit", "verification"):
                try:
                    a = activity.actions(studio.details_dir(x["id"], create_new=False), 1)
                    x["derniere_action"] = a[0]["texte"] if a else ""
                except Exception:                 # noqa: BLE001 — optional
                    pass
        return tasks

    def usage_summary() -> dict:
        """Usage of ALL AIs (subscriptions, API keys, the API aggregator, local AIs): calls, working
        time and tokens over 5 h (subscription window), today, 7 days; pay-per-use cost (API keys:
        actual cost from the aggregator or estimate at today's price), « inclus » for a subscription, free when local.
        Only calls started by the studio are counted."""
        from datetime import timedelta
        from .. import ai
        current_time = datetime.now()
        day = current_time.strftime("%Y-%m-%d")
        five_hours_ago = (current_time - timedelta(hours=5)).isoformat(timespec="seconds")
        week = (current_time - timedelta(days=6)).strftime("%Y-%m-%d")
        month = (current_time - timedelta(days=29)).strftime("%Y-%m-%d")
        monthly_calls = studio.store.api_calls(month)
        api_calls = [x for x in monthly_calls if x["day"] >= week]
        names = {f"{t.kind}:{t.id}": t.nom for t in studio.registry.all()}

        def total(batch):
            return {"appels": len(batch), "duree_s": round(sum(x["duree_s"] or 0 for x in batch)),
                    "entree": sum(x["jetons_entree"] or 0 for x in batch), "cache": sum(x["jetons_cache"] or 0 for x in batch),
                    "sortie": sum(x["jetons_sortie"] or 0 for x in batch),
                    "cout_usd": round(sum(x["cout_usd"] or 0 for x in batch), 4), "echecs": sum(1 for x in batch if not x["ok"])}

        def access(fam: str) -> str:
            return "abonnement" if fam in ("Claude", "Codex") else "local" if "(local)" in fam else "cle"
        # every connected or installed AI, even with no usage yet
        known = ["Claude", "Codex"] + [ai.family(c) for c in ai.read_file(studio.paths.data)["connexions"]]
        try:
            from .. import local_models
            if local_models.ollama_executable() and "Ollama (local)" not in known:
                known.append("Ollama (local)")
        except Exception:                                # noqa: BLE001
            pass
        order = list(dict.fromkeys(known + sorted({x["famille"] for x in monthly_calls})))
        families = {}
        for fam in order:
            a = [x for x in monthly_calls if x["famille"] == fam]
            families[fam] = {"acces": access(fam), "jour": total([x for x in a if x["day"] == day]),
                             "fenetre": total([x for x in a if x["at"] >= five_hours_ago]),
                             "semaine": total([x for x in a if x["day"] >= week]), "mois": total(a)}
        paid_calls = [x for x in monthly_calls if access(x["famille"]) == "cle"]
        paid_cost = {"jour": round(sum(x["cout_usd"] or 0 for x in paid_calls if x["day"] == day), 4),
                     "semaine": round(sum(x["cout_usd"] or 0 for x in paid_calls if x["day"] >= week), 4),
                     "mois": round(sum(x["cout_usd"] or 0 for x in paid_calls), 4),
                     "sans_prix": sum(1 for x in paid_calls if x["cout_usd"] is None)}
        todays = [x for x in api_calls if x["day"] == day]
        by = lambda cle: sorted(({"nom": k, **total([x for x in todays if cle(x) == k])}       # noqa: E731
                                  for k in {cle(x) for x in todays}), key=lambda d: -d["duree_s"])
        kept_days = []
        for i in range(6, -1, -1):
            d = (current_time - timedelta(days=i)).strftime("%Y-%m-%d")
            kept_days.append({"jour": d, "familles": {fam: total([x for x in api_calls if x["day"] == d and x["famille"] == fam])["duree_s"]
                                                  for fam in order}})
        old_items = [x for x in studio.store.usage(30) if x["day"] >= week]     # counters from before the detailed log
        return {"familles": families, "ordre": order, "jours": kept_days, "cout_paye": paid_cost,
                "par_usage": by(lambda x: x["usage"]),
                "par_projet": by(lambda x: names.get(x["cible"] or "", x["cible"] or "toutes les conversations")),
                "derniers": [{"heure": x["at"][11:16], "famille": x["famille"], "usage": x["usage"],
                              "projet": names.get(x["cible"] or "", x["cible"] or ""), "role": x["role"], "modele": x["modele"],
                              "duree_s": round(x["duree_s"] or 0), "entree": x["jetons_entree"], "cache": x["jetons_cache"],
                              "sortie": x["jetons_sortie"], "cout_usd": x["cout_usd"], "ok": bool(x["ok"])} for x in api_calls[:15]],
                "debut_journal": (api_calls[-1]["day"] if api_calls else day),
                "anciens_compteurs": [x for x in old_items if not any(a["day"] == x["day"] for a in api_calls)],
                "seuils": studio.cfg.get("usage", {})}

    def mutex(cle: str) -> threading.Lock:
        with locks_guard:
            return locks.setdefault(cle, threading.Lock())

    def git_single(cle: str, fn, *args):
        """Commit or merge on the main folder: allowed even while a task works in ITS copy (git
        protects its own files); two git operations on the same project never overlap."""
        v = mutex("git:" + cle)
        if not v.acquire(timeout=120):
            raise RuntimeError("Une autre opération git est en cours sur ce projet : réessaie dans un instant.")
        try:
            return fn(*args)
        finally:
            v.release()

    def exclusive(cle: str, fn, *args):
        """Immediate action on a project (merge, removal, build): refused if the project is already busy."""
        v = mutex(cle)
        if not v.acquire(blocking=False):
            raise RuntimeError("Ce projet est occupé (une tâche, une fusion ou un retrait est en cours) : réessaie dans un instant.")
        try:
            return fn(*args)
        finally:
            v.release()

    def update_in_progress() -> str:
        return next((j["titre"] for k, j in jobs.etat().items() if k.startswith("maj:") and j.get("etat") == "en_cours"), "")

    def following(tid: str) -> None:
        """After a decision, cancellation, resume or merge: starts the next step of a chain if everything
        is ready. While a subscription tool is being updated nothing starts: « Continuer » afterwards."""
        if update_in_progress():
            cid = (studio.store.get(tid).get("options") or {}).get("chaine")
            if cid:
                studio.store.update_chain(cid, note=f"{update_in_progress()} : clique « Continuer » une fois terminée.")
            return
        try:
            new_name = chains.advance(studio, tid)
        except Exception as e:                   # noqa: BLE001 — visible in the task log
            studio.store.event(tid, f"Chaîne : étape suivante non lancée ({type(e).__name__})")
            return
        if new_name:
            background(execute, new_name, tid=new_name)

    def execute(tid: str):
        """Runs a task; if it ends on its own (report with no files), the chain continues."""
        r = studio.run(tid)
        after_run(tid)
        return r

    def after_run(tid: str) -> None:
        """After a team pass: automatic merge (autonomous mode), next chain step, summary."""
        t = studio.store.get(tid)
        if t["status"] in ("approuvee", "appliquee"):
            if studio.autonomous() and studio._branch_info(tid, t).get("worktree") and not (studio.run_dir(tid) / "rien-a-appliquer.json").exists():
                try:                                  # autonomous mode: local merge (never a push), cleanly refused otherwise
                    f = actions.merge(studio, tid)
                    studio.store.event(tid, f"Fusion automatique : {f['message']}")
                    compile_after_merge(tid, t)
                except Exception as e:                # noqa: BLE001 — modified repo, conflict…: the button stays
                    studio.store.event(tid, f"Fusion automatique non faite : {str(e)[:300]} — bouton « Fusionner » disponible")
            following(tid)
        debrief_after(tid)
        from .. import cleanup
        cleanup.after_task(studio, tid)                 # task finished: its working copy is removed right away
    def compile_after_merge(tid: str, t: dict) -> None:
        """A game-engine project's C++ was just merged: closes the editor cleanly, builds the real project, reopens it
        (before the next chain step, which can then use the new fields). Never a forced close."""
        from .. import unreal
        try:
            cible = studio.registry.get(t["target"])
            up = unreal.unreal_project(cible.path()) if cible.has_path else None
            diffs = sorted(studio.details_dir(tid, create_new=False).glob("diff-*.patch"), key=lambda p: int(re.sub(r"\D", "", p.stem) or 0))
            cpp = bool(diffs) and re.search(r"^\+\+\+ b/Source/|^diff --git a/Source/", diffs[-1].read_text(encoding="utf-8", errors="replace"), re.M)
            if not up or not cpp:
                return
            r = unreal.run_compile(up, studio.cfg, lambda m: studio.store.event(tid, m), rouvrir=up,
                                journal=studio.details_dir(tid) / "build-apres-fusion.log")
            studio.store.event(tid, f"Compilation après fusion : {r['message']}" + (" — " + " | ".join(r.get("erreurs", [])[:3]) if r["code"] == 2 else ""))
        except Exception as e:                        # noqa: BLE001 — never blocking: the « Compiler » button stays
            studio.store.event(tid, f"Compilation après fusion non faite : {str(e)[:300]}")

    def debrief_after(tid: str) -> None:
        """When the team is done (done, to validate, failed): the Supervisor posts a short summary in the conversation."""
        t = studio.store.get(tid)
        if t["status"] in ("creee", "en_cours", "en_attente_creneau", "interrompue", "annulee"):
            return
        if not bool(studio.cfg.get("superviseur", {}).get("bilan", True)):
            return
        threading.Thread(target=sup.debrief, args=(tid,), daemon=True).start()

    def decide_task(tid: str, decision: str, empreinte: str, commentaire: str, task_files=None):
        r = studio.decide(tid, decision, empreinte, commentaire, task_files)
        if decision == "corriger":                    # the team redid the work: same follow-up as a run
            after_run(tid)
        else:
            following(tid)
            from .. import cleanup
            cleanup.after_task(studio, tid)             # validated or cancelled: the studio stays tidy as it goes
        return r

    def cancel_task(tid: str):
        r = studio.cancel(tid)
        following(tid)
        from .. import cleanup
        cleanup.after_task(studio, tid)
        return r

    def resume_task(tid: str):
        r = studio.resume(tid)
        after_run(tid)
        return r

    def background(fn, *args, tid: str = "", free: bool = False):
        """libre=True: cancellation or validation (short), never queued behind another task of the project."""
        if not free and update_in_progress():          # the tool is being replaced: no work starts
            raise RuntimeError(f"{update_in_progress()} : attends la fin de la mise à jour, puis relance.")
        cible = ""
        if tid:
            try:
                cible = target_key(studio.store.get(tid)["target"])
            except KeyError:
                pass

        def run():
            try:
                if free:
                    fn(*args)
                else:
                    with mutex(cible or "_"), parallel_slots:   # one task at a time per project, N in total
                        fn(*args)
            except Exception as e:                  # the state is already saved by the studio
                if tid:
                    studio.store.event(tid, f"Erreur interface : {type(e).__name__}")
            finally:
                ctl.finish()
        ctl.begin()
        threading.Thread(target=run, daemon=True).start()

    class H(BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def _send(self, code: int, obj=None, ctype="application/json", raw: bytes | None = None, extra=()):
            data = raw if raw is not None else json.dumps(obj, ensure_ascii=False, default=str).encode()
            self.send_response(code)
            self.send_header("Content-Type", ctype if ctype.startswith(("font/", "image/", "audio/", "video/")) else f"{ctype}; charset=utf-8")   # no charset on binary content
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("X-Frame-Options", "DENY")
            self.send_header("Referrer-Policy", "no-referrer")
            self.send_header("Content-Security-Policy",
                             "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self'; frame-ancestors 'none'")
            for k, v in extra:
                self.send_header(k, v)
            self.end_headers()
            self.wfile.write(data)

        def _remote(self) -> bool:
            """Request that came through the VPN relay (phone) rather than from this PC."""
            from .. import mobile
            return mobile.host_allowed(self.headers.get("Host") or "")

        def _ok_host(self) -> bool:
            if self.headers.get("Host") not in allowed_hosts and not self._remote():
                self._send(403, {"erreur": "hôte refusé"})
                return False
            return True

        def _cookie(self, nom: str = COOKIE) -> str:
            for part in (self.headers.get("Cookie") or "").split(";"):
                k, _, v = part.strip().partition("=")
                if k == nom:
                    return v
            return ""

        def _ok_device(self, path: str) -> bool:
            """Phone: device key required (cookie), otherwise pairing page (6-digit code)."""
            from .. import mobile
            if mobile.check(studio.paths.data, self._cookie(mobile.DEVICE_COOKIE)):
                return True
            if path in ("/", "/index.html"):
                self._send(200, ctype="text/html", raw=_pairing_page())
            else:
                self._send(403, {"erreur": "Téléphone non associé."})
            return False

        def _pair_device(self):
            from .. import mobile
            n = int(self.headers.get("Content-Length", 0) or 0)
            field_values = parse_qs(self.rfile.read(min(n, 2000)).decode("utf-8", "replace"))
            cle = mobile.use_code(studio.paths.data, (field_values.get("code") or [""])[0])
            if not cle:
                return self._send(403, ctype="text/html", raw=_pairing_page("Code incorrect ou expiré. Demande un nouveau "
                                                                                 "code sur le PC."))
            self.send_response(303)
            self.send_header("Set-Cookie", f"{mobile.DEVICE_COOKIE}={cle}; HttpOnly; Secure; SameSite=Lax; Path=/; "
                                           "Max-Age=31536000")
            self.send_header("Location", "/")
            self.send_header("Content-Length", "0")
            self.send_header("Cache-Control", "no-store")
            self.end_headers()

        def _ok_session(self, path: str, query: dict) -> bool:
            """Without launcher (token None): local protections only. With launcher: session cookie required.
            Through the VPN relay (phone): device key required in every case."""
            if self._remote():
                return self._ok_device(path)
            if token is None:
                return True
            if hmac.compare_digest(self._cookie(), token):
                return True
            given = (query.get("t") or [""])[0]
            if path == "/" and given and hmac.compare_digest(given, token):
                # Exchange the key for a cookie, then clean the address (the key does not stay in the address bar).
                self.send_response(303)
                self.send_header("Set-Cookie", f"{COOKIE}={token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=31536000")
                self.send_header("Location", "/")
                self.send_header("Content-Length", "0")
                self.send_header("Cache-Control", "no-store")
                self.send_header("Referrer-Policy", "no-referrer")
                self.end_headers()
                return False
            page = ("<!doctype html><meta charset=utf-8><title>Super AI Agent Pro Station Max 2000</title><body style='font:16px system-ui;"
                    "padding:40px'><h1>Super AI Agent Pro Station Max 2000</h1><p>Session non reconnue. Ouvre le studio avec le raccourci "
                    "« Super AI Agent Pro Station Max 2000 » du bureau.</p>").encode()
            self._send(403, ctype="text/html", raw=page)
            return False

        def _body(self) -> dict:
            n = int(self.headers.get("Content-Length", 0) or 0)
            return json.loads(self.rfile.read(n) or b"{}") if n < 1_000_000 else {}

        # ------------------------------------------------------------------ GET
        def do_GET(self):
            if not self._ok_host():
                return
            u = urlparse(self.path)
            path, query = u.path, parse_qs(u.query)
            if path == "/api/ping":                     # no data: lets the launcher detect an open instance
                return self._send(200, {"studio": True})
            m_font = re.fullmatch(r"/fonts/([a-z0-9-]+\.woff2)", path)
            if m_font and (STATIC / "fonts" / m_font.group(1)).is_file():     # local fonts (OFL), never a CDN
                return self._send(200, ctype="font/woff2", raw=(STATIC / "fonts" / m_font.group(1)).read_bytes())
            m_logo = re.fullmatch(r"/logos/([a-z0-9-]+\.svg)", path)
            if m_logo and (STATIC / "logos" / m_logo.group(1)).is_file():           # logos of AIs and tools (MIT/CC0 licences)
                return self._send(200, ctype="image/svg+xml", raw=(STATIC / "logos" / m_logo.group(1)).read_bytes())
            if path == "/favicon.ico":
                ico = STATIC / "logo-boom-2000.ico"
                return self._send(200, ctype="image/x-icon", raw=(ico if ico.is_file() else STATIC / "station-max-2000.ico").read_bytes())
            if path in ("/header-logo.png", "/logo-boom-2000.png"):          # studio logo (public, like the favicon)
                return self._send(200, ctype="image/png", raw=(STATIC / path.lstrip("/")).read_bytes())
            if path in ("/icon-192.png", "/icon-512.png"):                   # app icons (phone)
                return self._send(200, ctype="image/png", raw=(STATIC / path.lstrip("/")).read_bytes())
            if path in ("/icone-192.png", "/icone-512.png", "/logo-entete.png"):  # older names, still asked by installed phone apps
                new = {"/icone-192.png": "icon-192.png", "/icone-512.png": "icon-512.png", "/logo-entete.png": "header-logo.png"}[path]
                return self._send(200, ctype="image/png", raw=(STATIC / new).read_bytes())
            if path == "/manifest.webmanifest":                               # install the studio on the phone
                return self._send(200, ctype="application/manifest+json", raw=(STATIC / "manifest.webmanifest").read_bytes())
            if path == "/sw.js":
                return self._send(200, ctype="text/javascript", raw=(STATIC / "sw.js").read_bytes(), extra=(("Service-Worker-Allowed", "/"),))
            if not self._ok_session(path, query):
                return
            try:
                if path in ("/", "/index.html"):
                    return self._send(200, ctype="text/html", raw=(STATIC / "index.html").read_bytes())
                if path == "/app.js":
                    return self._send(200, ctype="text/javascript", raw=(STATIC / "app.js").read_bytes())
                if path == "/api/session":
                    from .. import mobile
                    from ..user_workspace import nom as workspace_name
                    return self._send(200, {"lanceur": token is not None, "arret_auto": ctl.absence_delay_s is not None,
                                            "travaux": ctl.jobs, "distant": self._remote(), "nom": workspace_name(),
                                            "reste_ouvert": mobile.relay_active(),
                                            "langue": str((studio.cfg.get("utilisateur") or {}).get("langue") or "fr")})
                if path == "/api/accueil":               # first launch: AIs ready, local model runner, Git/GitHub, models suited to the PC
                    from .. import welcome
                    return self._send(200, {**welcome.etat(studio), "distant": self._remote()})
                if path == "/api/systeme":               # header: processor, memory, graphics card, loaded local AI
                    from .. import system
                    return self._send(200, system.survey())
                if path == "/api/etat":
                    from ..health import check_all
                    if query.get("leger"):                  # top banner every 30 s: memory only
                        h = studio.memory.health()
                        return self._send(200, {"memoire": {"etat": h.etat, "backend": h.backend, "detail": h.detail, "en_attente": h.en_attente}})
                    return self._send(200, check_all(studio, probe_tools=True))
                if path == "/api/cibles":
                    return self._send(200, [t.to_public() for t in studio.registry.all()])
                if path == "/api/organisation":
                    return self._send(200, studio.organization())
                if path == "/api/conversation":
                    # each conversation is separate: home shows only its own, a project only its own
                    project = (query.get("projet") or [""])[0]
                    msgs = [m for m in studio.store.messages(400) if (m["proposition"].get("projet") or "") == project
                            and not m["proposition"].get("retire")][-80:]
                    from ..supervisor import readable_names
                    for m in msgs:                    # including old replies: never a task identifier on screen
                        if m["auteur"] != "mel":
                            m["texte"] = readable_names(studio, m["texte"])
                    launched = {m["proposition"].get("tache") for m in msgs if m["proposition"].get("etat") == "lancee"} - {None, ""}
                    if launched:                      # live tracking in the bubble: stage, time, cost
                        rows = {x["id"]: x for x in studio.store.list(500) if x["id"] in launched}
                        for m in msgs:
                            x = rows.get(m["proposition"].get("tache"))
                            if x:
                                m["proposition"]["suivi"] = {k: x.get(k) for k in (
                                    "status", "etape_nom", "created_at", "updated_at", "duree_s", "etape_depuis", "cout_usd", "titre")}
                    return self._send(200, msgs)
                if path == "/api/piece":
                    rel = (query.get("chemin") or [""])[0]
                    base = studio.paths.attachments.resolve()
                    if rel.startswith("Runs/pieces/"):          # messages from before the cleanup (maj75)
                        rel = studio.paths.attachments.relative_to(studio.paths.root).as_posix() + "/" + rel[len("Runs/pieces/"):]
                    f = (studio.paths.root / rel).resolve()
                    types = {".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".gif": "image/gif", ".webp": "image/webp"}
                    if base not in f.parents or not f.is_file() or f.suffix.lower() not in types:
                        return self._send(404, {"erreur": "introuvable"})
                    return self._send(200, ctype=types[f.suffix.lower()], raw=f.read_bytes())
                if path == "/api/skills/conflits":       # proposed updates (skills and .md changed outside the studio)
                    from ..initial_import import proposals
                    return self._send(200, proposals(studio.paths.root, studio.paths.data))
                if path == "/api/usage":
                    return self._send(200, usage_summary())
                if path == "/api/menage":                 # Gestion › Entretien: last automatic cleanup
                    from .. import cleanup
                    try:
                        d = json.loads((studio.paths.data / "menage.json").read_text(encoding="utf-8"))
                    except (OSError, ValueError):
                        d = {}
                    return self._send(200, {**d, "texte": cleanup.resume(d) if d else "", "actif": (studio.cfg.get("entretien") or {}).get("menage_auto") is not False})
                if path == "/api/resultats":              # Usage › Tes résultats: what your tasks say about each model
                    from .. import learning
                    return self._send(200, learning.results(studio))
                if path == "/api/push":                 # phone notifications: VAPID public key, number of subscribers
                    from .. import push
                    return self._send(200, {"cle": push.server_key(studio.paths.data), "abonnes": len(push.read_file(studio.paths.data)["abonnements"])})
                if path == "/api/push/en-attente":      # read by the phone when it wakes up
                    from .. import push
                    return self._send(200, push.en_attente(studio))
                if path == "/api/nuit":                  # night queue and time window
                    from .. import night
                    d = night.read_file(studio.paths.data)
                    return self._send(200, {"file": d["file"], "plage": night.time_window(studio.cfg)})
                if path == "/api/bibliotheque":         # Personnalisation: skills, connectors, packs
                    from .. import library
                    return self._send(200, library.etat(studio))
                if path == "/api/bibliotheque/exporter":
                    from .. import library
                    ident = (query.get("id") or [""])[0]
                    return self._send(200, raw=library.export_skill(studio, ident), ctype="application/zip",
                                      extra=(("Content-Disposition", f'attachment; filename="{ident}.zip"'),))
                if path == "/api/equipes":              # Gestion: projects × roles
                    from .. import teams
                    return self._send(200, teams.board(studio))
                if path == "/api/equipes/projet":
                    from .. import teams
                    return self._send(200, teams.project_view(studio, target_key((query.get("cible") or [""])[0])))
                if path == "/api/raccourcis":           # « / » in the message to the Supervisor
                    from .. import shortcuts
                    return self._send(200, shortcuts.entries(studio.paths.code, studio.paths.data))
                if path == "/api/mentions":             # « @ » in the message to the Supervisor: files and functions
                    from .. import mentions
                    project = sup.project((query.get("projet") or [""])[0])
                    return self._send(200, mentions.lookup(studio, project, (query.get("q") or [""])[0][:100]))
                if path == "/api/audits":               # last skills / memories audit per project (Gestion)
                    from .. import audits
                    return self._send(200, audits.latest(studio))
                if path == "/api/mobile":               # « Téléphone » card: VPN, relay, paired devices
                    from .. import mobile
                    return self._send(200, {"reglage": bool(studio.cfg["interface"].get("acces_mobile")),
                                            "tailscale": mobile.tailscale_state(), **mobile.relay_state(),
                                            "adresse": mobile.remote_host(), "code": mobile.code_in_progress(),
                                            "appareils": mobile.public(studio.paths.data), "distant": self._remote()})
                if path == "/api/ia":                   # connections to AIs (never the keys)
                    from .. import ai
                    from ..connectors.base import find_exe
                    from ..connectors.claude_code import WIN_CANDIDATES
                    actor, c = ai.choice(studio, "superviseur")
                    return self._send(200, {**ai.public(studio.paths.data), "locales": ai.detect_local_models(),
                                            "claude": bool(find_exe(studio.cfg["outils"].get("claude", "claude"), WIN_CANDIDATES)),
                                            "codex": bool(find_exe(studio.cfg["outils"].get("codex", "codex"))),
                                            "actif": actor, "distant": self._remote()})
                if path == "/api/agents/catalogue":     # create an agent: domains, roles, connected AIs, recommendations
                    from .. import agents
                    cat = agents.catalog()
                    return self._send(200, {**cat, "sources": agents.connected_sources(studio),
                                            "recommandations": {c: agents.recommend(studio, c)
                                                                for c in ("texte", "code", "image", "video", "voix")}})
                if path == "/api/benchmarks":
                    from .. import agents
                    return self._send(200, {**agents.benchmarks(studio.paths.data),
                                            "connectes": sorted({s["fournisseur"] for s in agents.connected_sources(studio)})})
                if path == "/api/modeles-locaux/details":   # Outils: installed local models (size, date)
                    from .. import local_models
                    return self._send(200, local_models.details())
                if path == "/api/modeles-locaux":       # benchmarks: models installable on the PC (local runner)
                    from .. import agents, local_models
                    return self._send(200, local_models.etat(agents.benchmarks(studio.paths.data)["modeles"]))
                if path == "/api/mise-a-jour":
                    from .. import updates
                    updates.check()
                    return self._send(200, updates.etat())
                if path == "/api/connecteurs":
                    from .. import software_connectors
                    return self._send(200, {"connecteurs": software_connectors.list_all(studio), "suggestions": software_connectors.SUGGESTIONS})
                if path == "/api/packs":                # skill and role packs (base always present)
                    from ..user_workspace import packs_state
                    return self._send(200, packs_state(studio.paths.root))
                if path == "/api/reglages":             # studio settings editable from Gestion (closed list)
                    from .. import settings
                    return self._send(200, settings.entries(studio.cfg))
                if path == "/api/limites":              # subscription limits in % (read-only, one tool's figures cached 60 s)
                    from .. import limits
                    return self._send(200, limits.limits(studio.cfg))
                if path == "/api/alertes":
                    # Alert when, at the current pace, the subscription limit (same % as /usage) will be reached
                    # within less than the configured threshold (default 1 h). No alert if limits are unavailable.
                    from .. import limits
                    u = studio.cfg.get("usage", {})
                    thresholds = {"Claude": u.get("alerte_claude_5h_min", 60), "Codex": u.get("alerte_codex_5h_min", 60)}
                    return self._send(200, limits.alerts(limits.limits(studio.cfg), thresholds))
                if path == "/api/choix":
                    from .. import ai
                    return self._send(200, {**studio.choice(), "profil": studio.profile(),
                                            "efforts_ia": {k: [list(x) for x in v] for k, v in ai.AI_EFFORTS.items()}})
                if path == "/api/outils/versions":
                    return self._send(200, actions.versions(studio))
                if path == "/api/outils/installes":
                    return self._send(200, actions.installed())
                if path == "/api/travaux":
                    return self._send(200, jobs.etat())
                if path == "/api/git":                  # git state of each project (« Git et GitHub » tab, project page)
                    from .. import project_git
                    return self._send(200, project_git.entries(studio))
                if path.startswith("/api/git/") and path.endswith("/a-commiter"):    # files to commit, checked boxes
                    from .. import project_git
                    try:
                        return self._send(200, project_git.to_commit(studio, unquote(path[len("/api/git/"):-len("/a-commiter")])))
                    except ValueError as e:
                        return self._send(404, {"erreur": str(e)})
                if path.startswith("/api/git/"):
                    from .. import project_git
                    try:
                        return self._send(200, project_git.detail(studio, unquote(path[len("/api/git/"):])))
                    except ValueError as e:
                        return self._send(404, {"erreur": str(e)})
                if path == "/api/espaces":
                    return self._send(200, actions.workspaces(studio))
                if path == "/api/projets":
                    return self._send(200, projects_list())
                if path.startswith("/api/projets/"):
                    cle = unquote(path[len("/api/projets/"):])
                    act = studio.activity()
                    p = next((x for x in projects_list(act) if x["cle"] == cle), None)
                    if p is None:
                        return self._send(404, {"erreur": "projet inconnu"})
                    p["equipe"] = team(studio.registry.get(cle), cle, act)
                    p["compilable"] = bool(studio.registry.get(cle).extra.get("build"))
                    base = studio.paths.projects if p["kind"] == "project" else studio.paths.topics
                    ctx = base / p["id"] / "CONTEXTE.md"
                    tasks = with_action([x for x in studio.store.list(1000) if target_key(x["target"]) == cle])
                    return self._send(200, {**p, "taches": tasks, "profil": studio.project_profiles().get(cle, ""),
                                            "profil_accueil": studio.profile(),
                                            "contexte": ctx.read_text(encoding="utf-8", errors="replace") if ctx.exists() else "",
                                            "contexte_chemin": ctx.relative_to(root).as_posix() if ctx.exists() else ""})
                if path == "/api/taches":
                    return self._send(200, with_action(studio.store.list()))
                if path == "/api/memoire":
                    return self._memory_get(query)
                if path == "/api/sauvegardes":
                    files = sorted((p for p in studio.paths.backups.glob("studio-*") if _BACKUP.match(p.name)), reverse=True)
                    return self._send(200, [{"nom": p.name, "octets": p.stat().st_size,
                                             "date": datetime.fromtimestamp(p.stat().st_mtime, timezone.utc).isoformat()}
                                            for p in files[:50]])
                if path == "/api/documents":
                    return self._send(200, _public(_documents(root, studio)))
                if path == "/api/document":
                    rel = (query.get("chemin") or [""])[0]
                    allowed = _doc_paths(root, studio)
                    if rel not in allowed:
                        return self._send(404, {"erreur": "document inconnu"})
                    return self._send(200, {"chemin": rel, "texte": allowed[rel].read_text(encoding="utf-8", errors="replace")[:400_000]})
                m = re.match(r"^/api/taches/([^/]+)/activite$", path)
                if m and _TID.match(m.group(1)):       # live: what the agent is doing, files touched, applications
                    from .. import activity, unreal
                    from ..orchestrator.processes import processes
                    tid = m.group(1)
                    t = studio.store.get(tid)
                    details = studio.details_dir(tid, create_new=False)
                    work = studio.run_dir(tid, create_new=False) / "copie-de-travail"
                    active = t["status"] in ("creee", "en_cours", "en_attente_creneau")
                    out = {"actions": activity.actions(details, 8), "fichiers": activity.task_files(work, details, studio.cfg["outils"].get("git", "git")),
                           "applications": []}
                    if active:
                        try:
                            c = studio.registry.get(t["target"])
                            ue = c.has_path and (c.extra.get("type") == "unreal" or bool(unreal.unreal_project(c.path())))
                        except KeyError:
                            ue = False
                        pids = [p["pid"] for p in processes(studio.store, tid) if p["status"] == "en_cours" and p["pid"]]
                        out["applications"] = activity.applications(pids, ue)
                    return self._send(200, out)
                if path == "/api/fichiers":            # Fichiers tab: what agents created for this project
                    from .. import task_files
                    return self._send(200, task_files.entries(studio, target_key((query.get("cible") or [""])[0])))
                if path == "/api/fichiers/voir":
                    from .. import task_files
                    tid, rel = (query.get("tid") or [""])[0], (query.get("chemin") or [""])[0]
                    if not _TID.match(tid) or not task_files.permitted(studio, tid, rel):
                        return self._send(404, {"erreur": "fichier inconnu"})
                    f, _ = task_files.place(studio, tid, rel)
                    if f is None:
                        return self._send(404, {"erreur": "fichier introuvable (copie retirée ?)"})
                    ext = f.suffix.lower()
                    if ext in task_files.IMAGES and f.stat().st_size <= task_files.MAX_IMAGE:
                        return self._send(200, raw=f.read_bytes(), ctype=task_files.IMAGES[ext])
                    if ext in (".md", ".txt", ".csv", ".json") and f.stat().st_size <= task_files.MAX_TEXT:
                        return self._send(200, raw=f.read_bytes(), ctype="text/plain")
                    if ext in task_files.MEDIA and f.stat().st_size <= task_files.MAX_MEDIA:     # sounds and videos: played in the gallery
                        return self._send(200, raw=f.read_bytes(), ctype=task_files.MEDIA[ext])
                    return self._send(415, {"erreur": "aperçu impossible : ouvre-le avec « Ouvrir »"})
                m = re.match(r"^/api/taches/([^/]+)/captures(?:/([A-Za-z0-9._ -]{1,120}))?$", path)
                if m and _TID.match(m.group(1)):       # images saved by the agent in Taches/<tâche>/captures
                    dossier = studio.run_dir(m.group(1), create_new=False) / "captures"
                    types = {".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".webp": "image/webp", ".gif": "image/gif"}
                    if not m.group(2):
                        names = sorted(p.name for p in dossier.glob("*") if p.is_file() and p.suffix.lower() in types) if dossier.is_dir() else []
                        return self._send(200, names[:60])
                    f = dossier / unquote(m.group(2))
                    if f.parent != dossier or f.suffix.lower() not in types or not f.is_file() or f.stat().st_size > 40_000_000:
                        return self._send(404, {"erreur": "capture inconnue"})
                    return self._send(200, raw=f.read_bytes(), ctype=types[f.suffix.lower()])
                m = re.match(r"^/api/taches/([^/]+)(?:/(resultat|diff|processus|annulable))?$", path)
                if m and _TID.match(m.group(1)):
                    tid, what = m.group(1), m.group(2)
                    if what == "annulable":
                        return self._send(200, actions.cancellable(studio, tid))
                    if what == "resultat":
                        f = studio.run_dir(tid, create_new=False) / "RESULTAT.md"
                        b = studio.run_dir(tid, create_new=False) / "BRANCHE.md"
                        texte = (b.read_text(encoding="utf-8") + "\n\n---\n\n" if b.exists() else "") \
                            + (f.read_text(encoding="utf-8") if f.exists() else "")
                        return self._send(200, {"texte": texte})
                    if what == "diff":
                        diffs = sorted(studio.details_dir(tid, create_new=False).glob("diff-*.patch"),
                                       key=lambda p: int(re.sub(r"\D", "", p.stem) or 0))
                        return self._send(200, {"texte": diffs[-1].read_text(encoding="utf-8")[:200_000] if diffs else ""})
                    if what == "processus":
                        from ..orchestrator.processes import processes
                        return self._send(200, processes(studio.store, tid))
                    st_ = studio.status(tid)
                    cid = (studio.store.get(tid).get("options") or {}).get("chaine")
                    if cid:
                        st_["chaine"] = chains.resume(studio, cid)
                    return self._send(200, st_)
                if path == "/api/chaines":
                    cible = (query.get("cible") or [""])[0]
                    return self._send(200, [chains.resume(studio, c["id"]) for c in studio.store.chains(target_key(cible) if cible else "")])
                self._send(404, {"erreur": "introuvable"})
            except KeyError as e:
                self._send(404, {"erreur": str(e)})

        def _memory_get(self, query: dict):
            from ..memory import MemoryUnavailable, Scope
            scope_list = [Scope.parse(x) for x in query.get("portee", []) if x]
            q = (query.get("q") or [""])[0]
            try:
                recs = studio.memory.recall(q, scope_list, include_general=True, limit=100)
                return self._send(200, {"etat": "OK", "souvenirs": [r.to_dict() for r in recs],
                                        "en_attente": studio.memory.pending_count()})
            except MemoryUnavailable as e:
                return self._send(503, {"erreur": f"MÉMOIRE EN PANNE — {e}"})

        def _receive_attachment(self, q: dict):
            """File dropped or pasted into the Demande window → Studio/data/pieces-jointes/<lot>/<relative path>. 50 MB max per file."""
            batch = (q.get("lot") or [""])[0]
            rel = (q.get("rel") or q.get("nom") or [""])[0].replace("\\", "/")
            n = int(self.headers.get("Content-Length", 0) or 0)
            if not re.fullmatch(r"[A-Za-z0-9_-]{6,64}", batch) or not rel or n <= 0:
                return self._send(400, {"erreur": "pièce invalide"})
            if n > 50 * 1024 * 1024:
                return self._send(413, {"erreur": "fichier trop gros (50 Mo maximum)"})
            parts = [re.sub(r'[<>:"|?*\x00-\x1f]', "_", p).strip(" .") for p in rel.split("/") if p not in ("", ".", "..")]
            if not parts or not all(parts):
                return self._send(400, {"erreur": "nom de fichier invalide"})
            base = (studio.paths.attachments / batch).resolve()
            dest = base.joinpath(*parts).resolve()
            if base not in dest.parents:
                return self._send(400, {"erreur": "chemin refusé"})
            if sum(1 for _ in base.rglob("*")) > 500 if base.exists() else False:
                return self._send(413, {"erreur": "trop de fichiers dans ce message"})
            data = self.rfile.read(n)
            dest.parent.mkdir(parents=True, exist_ok=True)
            if dest.exists():                           # never overwrite: add a suffix
                dest = dest.with_name(f"{dest.stem}-{int(time.time() * 1000) % 100000}{dest.suffix}")
            dest.write_bytes(data)
            return self._send(201, {"chemin": dest.relative_to(studio.paths.root).as_posix(), "octets": len(data)})

        # ------------------------------------------------------------------ POST
        def do_POST(self):
            if not self._ok_host():
                return
            u = urlparse(self.path)
            path = u.path
            if path == "/associer" and self._remote():   # pairing page form (phone)
                return self._pair_device()
            if self.headers.get("X-Studio") != "1":
                return self._send(403, {"erreur": "en-tête X-Studio manquant"})
            if not self._ok_session(path, {}):
                return
            if path == "/api/pieces":
                return self._receive_attachment(parse_qs(u.query))
            if path == "/api/bibliotheque/importer":    # skill as .zip: preview and review, then install
                n = int(self.headers.get("Content-Length", 0) or 0)
                from .. import library
                try:
                    return self._send(200, library.import_skill(studio, self.rfile.read(min(n, library.MAX_IMPORT + 1)),
                                                                       (parse_qs(u.query).get("confirmer") or ["0"])[0] == "1"))
                except ValueError as e:
                    return self._send(400, {"erreur": str(e)})
            if path == "/api/dicter":                   # microphone: speech → text, transcribed on the PC (local speech-to-text)
                n = int(self.headers.get("Content-Length", 0) or 0)
                if n <= 0 or n > 25 * 1024 * 1024:
                    return self._send(413, {"erreur": "enregistrement vide ou trop long"})
                data = self.rfile.read(n)
                from .. import attachments
                ext = {"audio/ogg": ".ogg", "audio/mp4": ".m4a", "audio/wav": ".wav"}.get((self.headers.get("Content-Type") or "").split(";")[0], ".webm")
                try:
                    return self._send(200, {"texte": attachments.dictate(data, studio.cfg.get("pieces", {}), ext)})
                except ValueError as e:
                    return self._send(400, {"erreur": str(e)})
                except Exception as e:                  # noqa: BLE001 — model still downloading, unreadable audio…
                    return self._send(500, {"erreur": f"Dictée impossible ({type(e).__name__})."})
            b = self._body()
            try:
                if path == "/api/conversation":
                    batch, project = str(b.get("lot", "")), str(b.get("projet", ""))
                    choice = studio.choice()
                    supervisor_model = str(b.get("modele", "")) if b.get("modele") in choice["modeles"] else ""
                    supervisor_effort = str(b.get("effort", "")) if b.get("effort") in choice["efforts"] else ""
                    sup.remember_choice(supervisor_model, supervisor_effort)
                    mid, rid = sup.ask(b.get("texte", ""), batch, project)
                    texte = b.get("texte", "")

                    def reply():
                        try:
                            sup.reply(texte, rid, batch, project, supervisor_model, supervisor_effort)
                        finally:
                            ctl.finish()
                    ctl.begin()
                    threading.Thread(target=reply, daemon=True).start()
                    return self._send(202, {"id": mid, "reponse": rid})
                m = re.match(r"^/api/conversation/(\d+)/(arreter|modifier)$", path)
                if m:                                   # the user stops a reply, or takes back their last message to fix it
                    return self._send(200, sup.halt(int(m.group(1))) if m.group(2) == "arreter" else sup.modify(int(m.group(1))))
                m = re.match(r"^/api/conversation/(\d+)/(lancer|ignorer|nuit)$", path)
                if m:
                    rid = int(m.group(1))
                    if m.group(2) == "ignorer":
                        sup.ignore(rid)
                        return self._send(200, {"ok": True})
                    if m.group(2) == "nuit":            # « Cette nuit »: queued, starts during the night window
                        from .. import night
                        return self._send(200, night.schedule(studio, rid, b.get("cible", ""), b.get("demande", ""), b.get("modele", ""),
                                                              b.get("mode", "") if b.get("mode") in ("rapide", "max") else "",
                                                              b.get("effort", "") if b.get("effort") in studio.choice()["efforts"] else ""))
                    tid = sup.lancer(rid, b.get("cible", ""), b.get("demande", ""), b.get("modele", ""),
                                     b.get("mode", "") if b.get("mode") in ("rapide", "max") else "",
                                     b.get("effort", "") if b.get("effort") in studio.choice()["efforts"] else "")
                    background(execute, tid, tid=tid)
                    return self._send(201, {"tid": tid})
                if path == "/api/modeles-locaux/demarrer":
                    from .. import local_models
                    if self._remote():
                        return self._send(403, {"erreur": "Ollama s'ouvre sur le PC."})
                    return self._send(200, local_models.startup())
                if path == "/api/modeles-locaux/desinstaller":
                    from .. import local_models
                    if self._remote():
                        return self._send(403, {"erreur": "À faire depuis le PC."})
                    return self._send(200, local_models.uninstall(str(b.get("nom", ""))))
                if path == "/api/modeles-locaux/installer":
                    from .. import agents, local_models
                    return self._send(202, local_models.install(str(b.get("nom", "")), agents.benchmarks(studio.paths.data)["modeles"],
                                                                    open_=not self._remote()))
                if path in ("/api/push/abonner", "/api/push/desabonner", "/api/push/test"):
                    from .. import push
                    if path.endswith("abonner") and not path.endswith("desabonner"):
                        return self._send(200, push.subscribe(studio.paths.data, b.get("abonnement") or {}, str(b.get("appareil", ""))))
                    if path.endswith("desabonner"):
                        return self._send(200, push.unsubscribe(studio.paths.data, str(b.get("endpoint", ""))))
                    return self._send(200, {"envoyes": push.send(studio.paths.data)})
                if path == "/api/menage":
                    from .. import cleanup
                    r = cleanup.lancer(studio, forced=True)
                    return self._send(200, {**r, "texte": cleanup.resume(r)})
                if path == "/api/accueil/noter":
                    from .. import welcome
                    return self._send(200, welcome.jot(studio.paths.data, **{k: b[k] for k in ("fini", "visite") if k in b}))
                if path in ("/api/accueil/installer", "/api/accueil/github"):
                    from .. import welcome
                    if self._remote():
                        return self._send(403, {"erreur": "À faire depuis le PC (une fenêtre s'y ouvre)."})
                    if path.endswith("github"):
                        return self._send(200, welcome.connect_github())
                    return self._send(200, welcome.install(str(b.get("outil", ""))))
                if path == "/api/codex/connexion":       # Benchmarks: sign in with a chat subscription
                    from .. import limits
                    if self._remote():
                        return self._send(403, {"erreur": "La connexion se fait sur le PC (une fenêtre s'y ouvre)."})
                    return self._send(200, limits.codex_connection(studio.cfg))
                if path in ("/api/claude/reconnecter", "/api/claude/connexion"):   # Usage: subscription tool login expired
                    from .. import limits
                    if path.endswith("reconnecter"):
                        return self._send(200, limits.reconnect_claude(studio.cfg))
                    if self._remote():
                        return self._send(403, {"erreur": "La connexion se fait sur le PC (une fenêtre s'y ouvre)."})
                    return self._send(200, limits.claude_connection(studio.cfg))
                if path.startswith("/api/bibliotheque/"):
                    from .. import library
                    if path.endswith("/installer"):
                        value_map = b.get("valeurs") if isinstance(b.get("valeurs"), dict) else {}
                        if self._remote() and any(v for v in value_map.values() if isinstance(v, str)):
                            return self._send(403, {"erreur": "Une clé se saisit sur le PC."})
                        return self._send(200, library.install(studio, str(b.get("id", "")), value_map))
                    if path.endswith("/retirer"):
                        return self._send(200, library.retire(studio, str(b.get("id", "")), str(b.get("type", ""))))
                    if path.endswith("/mcp-perso"):
                        if self._remote():
                            return self._send(403, {"erreur": "À faire depuis le PC."})
                        return self._send(200, library.add_custom_mcp(studio, str(b.get("nom", "")), str(b.get("commande", "")),
                                                                               str(b.get("arguments", "")), str(b.get("url", ""))))
                    return self._send(404, {"erreur": "inconnu"})
                if path in ("/api/equipes/role", "/api/equipes/mcp"):   # project team: its own settings
                    from .. import teams
                    cible = target_key(str(b.get("cible", "")))
                    studio.registry.get(cible)
                    if path.endswith("/role"):
                        return self._send(200, teams.configure_role(studio, cible, str(b.get("role", "")),
                                                                   {k: b[k] for k in ("actif", "modele", "effort", "consignes") if k in b}))
                    return self._send(200, teams.configure_mcp(studio, cible, b.get("noms") if isinstance(b.get("noms"), list) else None))
                if path == "/api/nuit/retirer":
                    from .. import night
                    return self._send(200, night.retire(studio, str(b.get("id", ""))))
                if path == "/api/modeles":
                    return self._send(200, studio.set_model(b.get("role", ""), b.get("modele", "")))
                if path == "/api/ia-role":                 # Gestion › Agents: any connected AI for this role
                    return self._send(200, studio.set_ai_role(str(b.get("role", "")), str(b.get("ia", ""))))
                if path == "/api/profil":
                    if b.get("cible"):                    # project-specific preset (empty = the home one)
                        return self._send(200, {"profil": studio.set_project_profile(target_key(str(b["cible"])), str(b.get("profil", "")))})
                    return self._send(200, {"profil": studio.set_profile(str(b.get("profil", "")))})
                if path.startswith("/api/mise-a-jour/"):
                    from .. import updates
                    if self._remote():
                        return self._send(403, {"erreur": "À faire depuis le PC."})
                    if path.endswith("/verifier"):
                        updates.check(force=True)
                        return self._send(200, updates.etat())
                    if path.endswith("/installer"):
                        return self._send(200, updates.install())
                    if path.endswith("/redemarrer"):
                        if ctl.jobs:
                            return self._send(409, {"erreur": "Un travail tourne encore : redémarre quand il est fini."})
                        updates.restart_later()
                        ctl.stop_request.set()
                        return self._send(202, {"ok": True})
                    return self._send(404, {"erreur": "inconnu"})
                if path == "/api/agents/creer":
                    from .. import agents
                    return self._send(200, agents.create_new(studio, b))
                if path in ("/api/connecteurs/ajouter", "/api/connecteurs/retirer"):
                    from .. import software_connectors
                    if self._remote():
                        return self._send(403, {"erreur": "À faire depuis le PC."})
                    l = (software_connectors.add_item(studio, str(b.get("nom", "")), str(b.get("chemin", ""))) if path.endswith("ajouter")
                         else software_connectors.retire(studio, str(b.get("id", ""))))
                    return self._send(200, {"connecteurs": l})
                if path == "/api/benchmarks/actualiser":
                    from .. import agents
                    return self._send(200, agents.refresh(studio.paths.data, str(studio.cfg.get("benchmarks", {}).get("url", "")), force=True))
                if path.startswith("/api/ia/"):
                    from .. import ai
                    if self._remote():                 # a key can only be entered on the PC
                        return self._send(403, {"erreur": "À faire depuis le PC."})
                    try:
                        if path == "/api/ia/ajouter":
                            return self._send(200, ai.add_item(studio.paths.data, str(b.get("fournisseur", "")), str(b.get("cle", "")),
                                                              str(b.get("modele", "")), str(b.get("url", ""))))
                        if path == "/api/ia/modeles":
                            c = ai.connection(studio.paths.data, str(b.get("id", "")))
                            if not c:
                                return self._send(404, {"erreur": "Connexion inconnue."})
                            return self._send(200, {"modeles": ai.list_models(c)})
                        if path == "/api/ia/choisir":
                            ai.modify(studio.paths.data, str(b.get("id", "")), **{k: b[k] for k in ("superviseur", "agents", "modele") if k in b})
                            return self._send(200, ai.public(studio.paths.data))
                        if path == "/api/ia/retirer":
                            ai.retire(studio.paths.data, str(b.get("id", "")))
                            return self._send(200, ai.public(studio.paths.data))
                    except ai.AIError as e:
                        return self._send(400, {"erreur": str(e)})
                    return self._send(404, {"erreur": "inconnu"})
                if path == "/api/packs/installer":      # adds a pack (nothing existing is replaced)
                    from ..user_workspace import packs_state, install_pack, nom
                    from ..orchestrator.roles import load_roles
                    created = install_pack(studio.paths.root, str(b.get("id", "")), nom())
                    studio.roles = load_roles(studio.paths.roles)
                    return self._send(200, {"ajoutes": len(created), "packs": packs_state(studio.paths.root)})
                if path.startswith("/api/mobile/"):
                    from .. import mobile, settings
                    if self._remote():                 # pair, disconnect or revoke: only from the PC
                        return self._send(403, {"erreur": "À faire depuis le PC."})
                    if path == "/api/mobile/acces":
                        yes = b.get("oui") is True
                        settings.modify(studio.cfg, studio.paths.config_file, "interface", "acces_mobile", yes)
                        e = mobile.start_relay(port, studio.paths.logs) if yes else (mobile.stop_relay() or {"ok": True})
                        return self._send(200, {"ok": e["ok"], "info": e.get("info", "")})
                    if path == "/api/mobile/code":
                        return self._send(200, mobile.new_code(str(b.get("nom", ""))))
                    if path == "/api/mobile/revoquer":
                        mobile.revoke(studio.paths.data, str(b.get("id", "")))
                        return self._send(200, {"appareils": mobile.public(studio.paths.data)})
                    return self._send(404, {"erreur": "inconnu"})
                if path == "/api/reglages":
                    from .. import settings
                    r = settings.modify(studio.cfg, studio.paths.config_file, str(b.get("section", "")),
                                          str(b.get("cle", "")), b.get("valeur"))
                    if b.get("section") == "utilisateur":
                        from ..user_workspace import set_name
                        set_name(studio.cfg)
                    return self._send(200, r)
                if path == "/api/efforts":
                    return self._send(200, studio.set_effort(b.get("role", ""), b.get("effort", "")))
                if path == "/api/skills/conflit":         # proposed update: folder or studio version
                    from ..initial_import import settle
                    return self._send(200, settle(studio.paths.root, str(b.get("nom", "")), str(b.get("choix", "")), studio.paths.data))
                if path == "/api/skills/importer":       # « Reprendre mes skills »: copy what is missing, nothing overwritten
                    from ..initial_import import import_
                    if self._remote():
                        return self._send(403, {"erreur": "À faire depuis le PC."})
                    return self._send(200, import_(studio.paths.root, _home()))
                if path == "/api/skills/synchroniser":
                    from ..agent_tools import signature_skills
                    from ..supervisor import sync_all
                    r = sync_all(studio, _home())
                    (studio.paths.data / "skills-signature.txt").write_text(signature_skills(studio.paths.root), encoding="utf-8")
                    return self._send(200, {"rapport": r})
                if path == "/api/fenetre":            # window size, restored at next launch
                    e = {"plein_ecran": bool(b.get("plein_ecran")), "agrandie": bool(b.get("agrandie"))}
                    try:
                        prev = json.loads((studio.paths.data / "fenetre.json").read_text(encoding="utf-8"))
                    except (OSError, ValueError):
                        prev = {}
                    for k in ("x", "y", "l", "h"):        # maximized or full screen: keep the last normal size
                        v = b.get(k) if not (e["plein_ecran"] or e["agrandie"]) else prev.get(k)
                        if isinstance(v, (int, float)) and -20000 < v < 20000:
                            e[k] = int(v)
                    (studio.paths.data / "fenetre.json").write_text(json.dumps(e), encoding="utf-8")
                    return self._send(200, {"ok": True})
                if path == "/api/presence":
                    ctl.presence()
                    return self._send(200, {"ok": True, "travaux": ctl.jobs})
                if path == "/api/arreter":
                    if self._remote():                 # from the phone it could not be reopened afterwards
                        return self._send(403, {"erreur": "Ferme le studio depuis le PC."})
                    if ctl.jobs and not b.get("apres_travaux"):
                        return self._send(409, {"erreur": "une tâche tourne encore", "travaux": ctl.jobs})
                    ctl.stop_request.set()
                    return self._send(202, {"ok": True, "travaux": ctl.jobs})
                if path == "/api/git/action":           # fetch / pull --ff-only / push / PR: one user click = their consent
                    from .. import project_git
                    return self._send(202, project_git.lancer(studio, jobs, b.get("cible", ""), b.get("action", "")))
                if path == "/api/git/nettoyer":         # all already-merged branches at once
                    from .. import project_git
                    return self._send(200, project_git.delete_merged(studio, b.get("cible", "")))
                if path == "/api/git/commit":           # LOCAL commit of the files checked by the user (never a push)
                    from .. import project_git
                    c = b.get("cible", "")
                    return self._send(200, git_single(c, project_git.do_commit, studio, c, list(b.get("fichiers") or []), str(b.get("message", ""))))
                if path == "/api/git/fusionner":        # task branch → current branch, from the Branches tab
                    from .. import project_git
                    c, br = b.get("cible", ""), str(b.get("branche", ""))
                    r = git_single(c, project_git.merge_branch, studio, c, br)
                    if br.startswith("studio/"):
                        following(br[len("studio/"):])
                    return self._send(200, r)
                if path == "/api/git/effacer-branche":     # red branch (blocked, cancelled…): user's Delete click
                    from .. import project_git
                    return self._send(200, project_git.erase_branch(studio, b.get("cible", ""), b.get("branche", "")))
                if path == "/api/git/supprimer-branche":   # only an already-merged branch (git branch -d)
                    from .. import project_git
                    return self._send(200, project_git.delete_branch(studio, b.get("cible", ""), b.get("branche", "")))
                if path == "/api/audits":               # Gestion buttons: audit, then apply a finished audit
                    from .. import audits
                    tid = audits.lancer(studio, b.get("cible", ""), b.get("quoi", ""), b.get("mode", "audit"), b.get("depuis", ""))
                    background(execute, tid, tid=tid)
                    return self._send(201, {"tid": tid})
                if path == "/api/taches":
                    opts = {k: b[k] for k in ("role", "executeur", "modele") if b.get(k)}
                    if b.get("titre"):
                        opts["titre"] = str(b["titre"])[:70]
                    if b.get("mode") in ("rapide", "max"):
                        opts["mode"] = b["mode"]
                    if b.get("effort") in studio.choice()["efforts"]:
                        opts["effort"] = b["effort"]
                    tid = studio.create(b["cible"], b["demande"], **opts)
                    background(execute, tid, tid=tid)
                    return self._send(201, {"tid": tid})
                if path == "/api/cibles":
                    kind = "project" if b.get("kind") == "project" else "topic"
                    fields = {k: b[k] for k in ("chemin", "type", "description") if b.get(k)}
                    modele = str(b.get("modele", ""))
                    if modele:
                        from .. import project_templates
                        if modele not in project_templates.MODELS:
                            return self._send(400, {"erreur": "Modèle de projet inconnu."})
                        fields.setdefault("type", project_templates.MODELS[modele]["type"])
                        if kind == "project" and fields.get("chemin") and not self._remote() and Path(fields["chemin"]).expanduser().is_absolute():
                            Path(fields["chemin"]).expanduser().mkdir(parents=True, exist_ok=True)   # new project: folder created if missing
                    t = studio.registry.add(kind, b["id"], b["nom"], **fields)
                    if modele:
                        project_templates.appliquer(studio, f"{t.kind}:{t.id}", modele)
                    return self._send(201, t.to_public())
                if path == "/api/memoire":
                    from ..memory import Provenance, Scope
                    texte = (b.get("texte") or "").strip()
                    if not texte:
                        return self._send(400, {"erreur": "texte vide"})
                    r = studio.memory.remember(Scope.parse(b["portee"]), texte, Provenance(outil="mel", agent="interface"))
                    return self._send(201, {"statut": r.status, "partage": r.shared, "detail": r.detail})
                if path == "/api/fichiers/reference":  # « référence » star set by the user on a file
                    from .. import task_files
                    tid, rel, target_r = str(b.get("tid", "")), str(b.get("chemin", "")), target_key(str(b.get("cible", "")))
                    if not _TID.match(tid) or not task_files.permitted(studio, tid, rel):
                        return self._send(404, {"erreur": "fichier inconnu"})
                    return self._send(200, task_files.mark_reference(studio, target_r, tid, rel, bool(b.get("oui"))))
                if path == "/api/fichiers/ouvrir":     # an agent-created file, or its folder, in the system file manager
                    import os
                    import sys
                    from .. import task_files
                    tid, rel = str(b.get("tid", "")), str(b.get("chemin", ""))
                    if not _TID.match(tid) or not task_files.permitted(studio, tid, rel):
                        return self._send(404, {"erreur": "fichier inconnu"})
                    f, _ = task_files.place(studio, tid, rel)
                    if f is None:
                        return self._send(404, {"erreur": "fichier introuvable"})
                    target_o = f.parent if b.get("dossier") else f
                    from ..os_support import open_
                    open_(target_o)                  # system file manager: path checked
                    return self._send(200, {"ok": True})
                if path == "/api/ouvrir":
                    # Opens a studio document, a result folder or a backup in the associated system application
                    # (editor, file manager). Allowlist: nothing outside the studio.
                    import os
                    import sys
                    rel = b.get("chemin", "")
                    allowed = _doc_paths(root, studio)
                    if rel in allowed:
                        target = allowed[rel]
                    elif _TID.match(rel):
                        target = studio.run_dir(rel, create_new=False)
                    elif rel == "Skills" or rel in _FOLDER_KEYS or rel in {studio.paths.names[k] for k in _FOLDER_KEYS}:
                        target = root / (studio.paths.names[rel] if rel in _FOLDER_KEYS else rel)   # folder key or its localized name
                        target.mkdir(exist_ok=True)
                    elif re.fullmatch(r"restauration-test-\d{8}T\d{6}Z", rel):
                        target = studio.paths.restores / rel
                    else:
                        return self._send(404, {"erreur": "emplacement non autorisé"})
                    if not target.exists():
                        return self._send(404, {"erreur": "introuvable"})
                    from ..os_support import open_
                    open_(target)                                  # allowlisted path
                    return self._send(200, {"ouvert": str(target)})
                if path == "/api/sauvegardes":
                    from ..backup import create_backup
                    out = create_backup(studio.paths)
                    return self._send(201, {"nom": out.name})
                m = re.match(r"^/api/sauvegardes/([^/]+)/(verifier|restaurer-test)$", path)
                if m and _BACKUP.match(m.group(1)):
                    from ..backup import restore_to_test, verify_backup
                    f = studio.paths.backups / m.group(1)
                    if m.group(2) == "verifier":
                        return self._send(200, verify_backup(f))
                    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
                    dest = studio.paths.restores / f"restauration-test-{stamp}"
                    return self._send(200, {**restore_to_test(f, dest), "dossier": str(dest)})
                if path == "/api/compiler":
                    c = target_key(str(b.get("cible", "")))
                    return self._send(202, exclusive(c, actions.run_compile, studio, jobs, c))
                if path == "/api/outils/tests":
                    return self._send(202, actions.run_tests(studio, jobs))
                if path == "/api/outils/mettre-a-jour":
                    if ctl.jobs:                       # task, Supervisor reply, installation…: the tool is in use
                        raise RuntimeError("Un travail est en cours (tâche, réponse du Superviseur, installation) : "
                                           "attends qu'il finisse avant de mettre à jour.")
                    return self._send(202, actions.apply_update(studio, jobs, str(b.get("outil", ""))))
                if path == "/api/outils/installer":
                    return self._send(202, actions.install(studio, jobs, str(b.get("quoi", ""))))
                if path == "/api/chaines":
                    opts = {k: b.get(k) for k in ("modele", "mode", "effort") if b.get(k)}
                    if opts.get("mode") not in (None, "rapide", "max"):
                        opts.pop("mode")
                    if opts.get("effort") and opts["effort"] not in studio.choice()["efforts"]:
                        opts.pop("effort")
                    cid, tid = chains.create_new(studio, str(b.get("cible", "")), str(b.get("titre", "")), b.get("etapes") or [], opts)
                    background(execute, tid, tid=tid)
                    return self._send(201, {"chaine": cid, "tid": tid})
                m = re.match(r"^/api/chaines/([A-Za-z0-9-]+)/(reprendre|arreter|continuer)$", path)
                if m:
                    if m.group(2) == "arreter":
                        chains.halt(studio, m.group(1))
                        return self._send(200, {"ok": True})
                    if m.group(2) == "continuer":
                        if update_in_progress():
                            raise RuntimeError(f"{update_in_progress()} : attends la fin de la mise à jour.")
                        tid = chains.proceed(studio, m.group(1))
                        if tid:
                            background(execute, tid, tid=tid)
                        return self._send(200, {"tid": tid or ""})
                    tid = chains.resume_run(studio, m.group(1))
                    background(execute, tid, tid=tid)
                    return self._send(201, {"tid": tid})
                m = re.match(r"^/api/cibles/([^/]+)/retirer$", path)
                if m:
                    c = target_key(unquote(m.group(1)))
                    t = studio.registry.get(c)
                    def remove_target():
                        open_tasks = [x for x in studio.store.list(1000) if target_key(x["target"]) == c and x["status"] not in TERMINAL]
                        if open_tasks:
                            raise RuntimeError(f"{len(open_tasks)} tâche(s) de « {t.nom} » ne sont pas terminées : valide-les ou "
                                               "annule-les d'abord. Rien n'a été retiré.")
                        try:
                            dest = studio.registry.retire(c)
                        except PermissionError:
                            raise RuntimeError(f"Impossible de ranger la fiche de « {t.nom} » : un de ses fichiers est sans doute "
                                               "ouvert (éditeur, Explorateur). Ferme-le et réessaie ; rien n'a été retiré.")
                        return {"ok": True, "message": f"« {t.nom} » est retiré du studio. Sa fiche est rangée dans "
                                f"{dest.relative_to(studio.paths.root).as_posix()} ; rien n'a été supprimé."}
                    return self._send(200, exclusive(c, remove_target))
                m = re.match(r"^/api/espaces/([^/]+)/retirer$", path)
                if m and _TID.match(m.group(1)):
                    c = target_key(studio.store.get(m.group(1))["target"])
                    return self._send(200, exclusive(c, actions.remove_workspace, studio, m.group(1)))
                m = re.match(r"^/api/taches/([^/]+)/defaire$", path)
                if m and _TID.match(m.group(1)):       # « Annuler ce qui a été appliqué » (copy restored, or git revert)
                    c = target_key(studio.store.get(m.group(1))["target"])
                    return self._send(200, git_single(c, actions.cancel_apply, studio, m.group(1)))
                m = re.match(r"^/api/taches/([^/]+)/fusionner$", path)
                if m and _TID.match(m.group(1)):
                    c = target_key(studio.store.get(m.group(1))["target"])
                    r = git_single(c, actions.merge, studio, m.group(1))
                    following(m.group(1))                 # chain: the next step starts from the merged work
                    return self._send(200, r)
                m = re.match(r"^/api/taches/([^/]+)/(decision|annuler|reprendre|arreter|copier|chatgpt)$", path)
                if m and _TID.match(m.group(1)):
                    tid, action = m.groups()
                    if action in ("copier", "chatgpt"):
                        return self._send(200, {"fichier": str(studio.export_copy_paste(tid))})
                    if action == "annuler":
                        studio.store.request_cancel(tid)
                        background(cancel_task, tid, tid=tid, free=True)
                    elif action == "arreter":            # « Stop »: stops the agent, the task can be resumed
                        return self._send(200, studio.stop(tid))
                    elif action == "reprendre":
                        background(resume_task, tid, tid=tid)
                    else:
                        if b.get("decision") not in ("approuver", "corriger", "annuler", "retirer"):
                            return self._send(400, {"erreur": "décision : approuver, corriger, annuler ou retirer"})
                        if b["decision"] == "approuver" and not b.get("empreinte"):
                            return self._send(400, {"erreur": "empreinte du résultat présenté requise"})
                        task_files = b.get("fichiers") or []
                        if b["decision"] == "retirer":
                            if not isinstance(task_files, list) or not task_files or not all(isinstance(f, str) for f in task_files):
                                return self._send(400, {"erreur": "fichiers à retirer : liste de chemins"})
                            if studio.store.get(tid)["status"] not in ("a_approuver", "a_approuver_avec_defauts"):
                                return self._send(409, {"erreur": "la tâche n'attend pas ta validation"})
                        background(decide_task, tid, b["decision"], b.get("empreinte", ""), b.get("commentaire", ""), task_files,
                                   tid=tid, free=b["decision"] != "corriger")   # fixing restarts work: it waits its turn
                    return self._send(202, {"ok": True})
                self._send(404, {"erreur": "introuvable"})
            except (KeyError, ValueError, FileExistsError, FileNotFoundError) as e:
                self._send(400, {"erreur": redact(str(e))[:800]})
            except RuntimeError as e:                # work already running, git refusal…: clear message, nothing done
                self._send(409, {"erreur": redact(str(e))[:600]})
            except Exception as e:                   # noqa: BLE001 — message without secrets, details in the studio state
                from ..memory import MemoryUnavailable
                if isinstance(e, MemoryUnavailable):
                    return self._send(503, {"erreur": f"MÉMOIRE EN PANNE — {e}"})
                self._send(500, {"erreur": type(e).__name__})

    if controller is not None:                             # studio launched for real (not a test): night queue
        from .. import night

        def skills_at_launch():                       # import the PC's skills (once), then copies for each subscription tool
            try:
                from ..initial_import import import_once
                r = import_once(studio.paths.root, studio.paths.data)
                if r and (r["skills"] or r["instructions"]):
                    studio.store.message("superviseur", "### Skills repris de ton PC\n" + (f"Skills copiés dans le studio : {', '.join(r['skills'])}.\n" if r["skills"] else "")
                                         + (f"Instructions générales copiées : {', '.join(r['instructions'])} ({studio.paths.imported_rules.relative_to(studio.paths.root).as_posix()}).\n" if r["instructions"] else "")
                                         + "\nTes dossiers d'origine ne sont pas modifiés : le studio gère maintenant ses copies. "
                                           "Tu peux supprimer les originaux toi-même si tu le souhaites.")
            except Exception as e:                       # noqa: BLE001
                print(f"[import] {type(e).__name__}: {redact(str(e))[:200]}", flush=True)
            try:
                from ..agent_tools import skills_up_to_date
                to_flag = [x for x in skills_up_to_date(studio.paths.root, studio.paths.data) if "ton dossier" in x]
                if to_flag:
                    studio.store.message("superviseur", "### Changements dans tes dossiers\n" + "\n".join(f"- {x}" for x in to_flag)
                                         + "\n\nRien n'est remplacé sans ton accord : choisis dans Gestion › Skills et documents.")
            except Exception as e:                       # noqa: BLE001
                print(f"[skills] {type(e).__name__}: {redact(str(e))[:200]}", flush=True)
        threading.Thread(target=skills_at_launch, daemon=True).start()

        def daily_cleanup():                            # catch-up at most once a day: reopening the studio restarts nothing
            from .. import cleanup
            try:
                cleanup.migrate_deliverables(studio)          # Livrables/ (before 0.4.18) moves into Sujets/
                cleanup.lancer(studio)
            except Exception as e:                       # noqa: BLE001
                print(f"[menage] {type(e).__name__}", flush=True)
        threading.Thread(target=daily_cleanup, daemon=True).start()

        def watch_night():
            while not ctl.should_stop():
                try:
                    night.tick(studio, sup, lambda tid: background(execute, tid, tid=tid))
                except Exception as e:                   # noqa: BLE001 — retries the next minute
                    print(f"[nuit] {type(e).__name__}: {redact(str(e))[:200]}", flush=True)
                for _ in range(60):
                    if ctl.should_stop():
                        return
                    time.sleep(1)
        threading.Thread(target=watch_night, daemon=True).start()

        def watch_push():                               # task to validate or blocked → wake subscribed phones
            from .. import push
            while not ctl.should_stop():
                try:
                    push.tick(studio)
                except Exception as e:                   # noqa: BLE001
                    print(f"[push] {type(e).__name__}: {redact(str(e))[:200]}", flush=True)
                time.sleep(15)
        threading.Thread(target=watch_push, daemon=True).start()
    return H


class StudioServer(ThreadingHTTPServer):
    """A page closed mid-send (phone asleep, tab closed) is not an error: nothing in the log."""

    def handle_error(self, request, client_address):
        import sys
        if isinstance(sys.exc_info()[1], (ConnectionAbortedError, ConnectionResetError, BrokenPipeError, TimeoutError)):
            return
        super().handle_error(request, client_address)


def serve(studio=None, token: str | None = None, controller: Control | None = None, on_ready=None):
    from ..orchestrator.runner import Studio
    studio = studio or Studio()
    host, port = studio.cfg["interface"]["hote"], int(studio.cfg["interface"]["port"])
    ctl = controller or Control()
    httpd = StudioServer((host, port), make_handler(studio, port, token, ctl))
    httpd.daemon_threads = True

    def watcher():
        while not ctl.should_stop():
            time.sleep(2)
        httpd.shutdown()

    threading.Thread(target=watcher, daemon=True).start()
    print(f"Studio : http://{host}:{port}  (Ctrl+C pour arrêter)", flush=True)
    from .. import mobile

    def watch_benchmarks():                             # rankings: at most one update per day
        from .. import agents
        while not ctl.stop_request.is_set():
            agents.refresh(studio.paths.data, str(studio.cfg.get("benchmarks", {}).get("url", "")))
            try:                                         # Personnalisation page catalogue, published in the repo
                from .. import library, updates
                library.refresh_catalog(studio.paths.data, updates.depot())
            except Exception:                            # noqa: BLE001
                pass
            ctl.stop_request.wait(6 * 3600)
    threading.Thread(target=watch_benchmarks, daemon=True).start()

    def watch_updates():                           # at launch then daily; minor ones install themselves
        from .. import updates
        ctl.stop_request.wait(20)
        while not ctl.stop_request.is_set():
            updates.automatic()
            ctl.stop_request.wait(24 * 3600)
    if token is not None:
        threading.Thread(target=watch_updates, daemon=True).start()
    from .. import night as _night
    # phone access active, or tasks planned tonight: closing the window does not close the studio
    ctl.keep = lambda: mobile.relay_active() or bool(_night.read_file(studio.paths.data)["file"])
    if token is not None:                                # launcher: VPN relay if the user enabled it, monitored
        def watch_phone():                          # VPN down or relay dropped: reconnect (every 60 s)
            while not ctl.stop_request.is_set():
                if studio.cfg["interface"].get("acces_mobile") and not mobile.relay_active():
                    mobile.start_relay(port, studio.paths.logs)
                ctl.stop_request.wait(60)
        threading.Thread(target=watch_phone, daemon=True).start()
    if on_ready:
        on_ready(host, port)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        ctl.stop_request.set()                                 # the phone watcher stops too
        mobile.stop_relay()                          # the relay stops with the studio
        httpd.server_close()
        studio.close()
