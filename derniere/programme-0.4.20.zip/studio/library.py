"""Extensions: skills, connectors (MCP servers and PC software) and packs, to discover and install.

Rules:
- Curated catalogue (modeles/catalogue.json, updated with the studio). Anthropic skills come from a pinned commit
  of github.com/anthropics/skills: every file is checked (SHA-256) before being written.
- Nothing is ever overwritten: a skill already present is not replaced. "Remove" moves it to Archives, deletes nothing.
- MCP servers: configuration added to data/mcp.json, used by the agents. Keys are encrypted
  (DPAPI on Windows) in data/mcp-secrets.json and passed to agents through environment variables, never in plain text
  in a file. The server package (npx, uvx) downloads on first use: the studio says so before installing.
- Software: detected on the PC and declared to agents; never installed by the studio (official link and winget
  command to run yourself).
- Imported skill (.zip): checked (paths, size, SKILL.md) and reviewed (scripts, web addresses, suspicious instructions).
"""
from __future__ import annotations

import glob
import hashlib
import io
import json
import os
import re
import shutil
import time
import urllib.parse
import urllib.request
import zipfile
from pathlib import Path

from .user_workspace import CODE, MODELS

MAX_IMPORT = 30 * 1024 * 1024
_ID = re.compile(r"^[a-z0-9][a-z0-9-]{0,60}$")
PREREQUISITES = {"node": ("npx", "Node.js", "https://nodejs.org/fr/download"),
             "uv": ("uvx", "uv (Astral)", "https://docs.astral.sh/uv/getting-started/installation/")}


_DATA: dict = {}


def catalog() -> dict:
    """Catalogue shipped with the studio, or the one published since (data/catalogue-maj.json, updated daily) if
    it is newer."""
    try:
        base = json.loads((MODELS / "catalogue.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        base = {"categories": {}, "nouveaux": [], "elements": []}
    d = _DATA.get("data")
    if d:
        update_info = _read_json(Path(d) / "catalogue-maj.json", {})
        if isinstance(update_info, dict) and isinstance(update_info.get("elements"), list) and str(update_info.get("version", "")) > str(base.get("version", "")):
            return update_info
    return base


def refresh_catalog(data: Path, depot: str, force: bool = False) -> dict:
    """Daily: catalogue published in the studio repository (catalogue/catalogue.json). Nothing is installed."""
    _DATA["data"] = str(data)
    f = Path(data) / "catalogue-maj.json"
    if not depot or (not force and f.exists() and time.time() - f.stat().st_mtime < 24 * 3600):
        return {"ok": True, "frais": True}
    try:
        d = json.loads(_download(f"https://raw.githubusercontent.com/{depot}/main/catalogue/catalogue.json", 20))
        if not isinstance(d.get("elements"), list):
            raise ValueError("format inattendu")
        _write_json(f, d)
        return {"ok": True}
    except Exception as e:                               # noqa: BLE001 — offline: shipped catalogue kept
        return {"ok": False, "erreur": type(e).__name__}


def _element(ident: str) -> dict:
    e = next((x for x in catalog()["elements"] if x["id"] == ident), None)
    if not e:
        raise ValueError("Élément inconnu du catalogue.")
    return e


# ------------------------------------------------------------------ state files
def _read_json(f: Path, fallback):
    try:
        return json.loads(f.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return fallback


def _write_json(f: Path, d) -> None:
    f.parent.mkdir(parents=True, exist_ok=True)
    t = f.with_suffix(f.suffix + ".tmp")
    t.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
    os.replace(t, f)


def mcp_file(data: Path) -> Path:
    return Path(data) / "mcp.json"


def installed_mcp(data: Path) -> dict:
    d = _read_json(mcp_file(data), {})
    return d.get("mcpServers", {}) if isinstance(d, dict) else {}


def env_mcp(data: Path) -> dict:
    """MCP server variables (decrypted keys) for the agent process, never written anywhere else."""
    from .ai import _decrypt
    out = {}
    for k, v in _read_json(Path(data) / "mcp-secrets.json", {}).items():
        try:
            out[k] = _decrypt(v)
        except Exception:                                # noqa: BLE001 — unreadable key: the server will report it missing
            pass
    return out


# ------------------------------------------------------------------ what is installed
def _present_skills(root_dir: Path) -> dict[str, dict]:
    out = {}
    d = Path(root_dir) / "Skills"
    for s in sorted(d.glob("*/SKILL.md")) if d.is_dir() else []:
        if s.parent.name == "superviseur":                # Supervisor method: reserved, never listed
            continue
        meta = _read_json(s.parent / ".bibliotheque.json", {})
        texte = s.read_text(encoding="utf-8", errors="replace")
        desc = re.search(r"(?mi)^description:\s*[\"']?(.+?)[\"']?\s*$", texte)
        title = re.search(r"(?m)^#\s+(.+?)\s*$", texte.split("---", 2)[-1] if texte.startswith("---") else texte)
        out[s.parent.name] = {"source": meta.get("source", "studio"), "description": desc.group(1)[:200] if desc else "",
                              "titre": title.group(1)[:60] if title else "", "socle": (MODELS / "espace" / "Skills" / s.parent.name).is_dir()}
    return out


def detect_software(e: dict) -> str:
    for exe in e.get("executables", []):
        p = shutil.which(exe)
        if p:
            return p
    for pattern in e.get("chemins", []):
        candidates = sorted(glob.glob(os.path.expanduser(pattern)))
        if candidates:
            return candidates[-1]
    return ""


def etat(studio) -> dict:
    from . import software_connectors
    _DATA["data"] = str(studio.paths.data)
    cat = catalog()
    skills = _present_skills(studio.paths.root)
    mcp = installed_mcp(studio.paths.data)
    software_items = {c["nom"].lower(): c for c in software_connectors.list_all(studio)}
    from .user_workspace import packs_state
    local_packs = {p["id"]: p for p in packs_state(studio.paths.root)}
    elements = []
    for e in cat["elements"]:
        x = {k: v for k, v in e.items() if k not in ("source", "config", "chemins", "executables")}
        if e["type"] == "skill":
            x["installe"] = e["id"] in skills
        elif e["type"] == "mcp":
            x["installe"] = e["id"] in mcp
            x["manque"] = [PREREQUISITES[p][1] for p in e.get("prerequis", []) if not shutil.which(PREREQUISITES[p][0])]
        elif e["type"] == "logiciel":
            x["installe"] = e["nom"].lower() in software_items
            x["trouve"] = bool(detect_software(e)) if not x["installe"] else True
        elif e["type"] == "pack":
            x["membres_etat"] = {m: _member_installed(m, skills, mcp, software_items, local_packs) for m in e["membres"]}
            x["installe"] = all(x["membres_etat"][m] for m in (e.get("base") or e["membres"]))
        x["nouveau"] = e["id"] in cat.get("nouveaux", [])
        elements.append(x)
    known = {e["id"] for e in cat["elements"]}
    for nom, s in skills.items():                         # your skills outside the catalogue (base, personal, imported)
        if nom not in known:
            elements.append({"id": nom, "type": "skill", "nom": s["titre"] or nom.replace("-", " ").capitalize(), "description": s["description"],
                             "socle": s["socle"],
                             "auteur": {"import": "Importée", "studio": "Le studio"}.get(s["source"], "Toi"), "verifie": s["source"] == "studio",
                             "categorie": "perso", "installe": True, "hors_catalogue": True})
    for nom in mcp:
        if nom not in known:
            elements.append({"id": nom, "type": "mcp", "nom": nom, "description": "Serveur MCP ajouté à la main.", "auteur": "Toi",
                             "verifie": False, "categorie": "perso", "installe": True, "hors_catalogue": True})
    category_names = {e["nom"].lower() for e in cat["elements"] if e["type"] == "logiciel"}
    for c in software_items.values():
        if c["nom"].lower() not in category_names:
            elements.append({"id": c["id"], "type": "logiciel", "nom": c["nom"], "description": c.get("chemin", ""), "auteur": "Toi",
                             "verifie": False, "categorie": "perso", "installe": True, "hors_catalogue": True, "trouve": c.get("ok", False)})
    return {"elements": elements, "categories": cat.get("categories", {}), "pour_vous": for_you(studio, elements)}


def _member_installed(m: str, skills, mcp, software_items, local_packs) -> bool:
    if m.startswith("pack:"):
        return bool(local_packs.get(m[5:], {}).get("installe"))
    e = next((x for x in catalog()["elements"] if x["id"] == m), None)
    if not e:
        return True
    return (m in skills if e["type"] == "skill" else m in mcp if e["type"] == "mcp"
            else e["nom"].lower() in software_items if e["type"] == "logiciel" else False)


def for_you(studio, elements: list[dict]) -> list[str]:
    """Recommendations based on your projects and your PC (never what is already installed)."""
    desired: list[str] = []
    for t in studio.registry.all():
        if not t.has_path:
            continue
        try:
            p = t.path()
            names = {x.name.lower() for x in p.iterdir()} if p.is_dir() else set()
        except OSError:
            continue
        if any(n.endswith(".uproject") for n in names) or t.extra.get("type") == "unreal" or "project.godot" in names:
            desired += ["domaine-jeu-video", "game-design-document", "level-design"]
        if {"package.json", "index.html", "vite.config.js", "vite.config.ts"} & names:
            desired += ["domaine-web", "playwright", "seo-web-content"]
        if any(n.endswith((".blend", ".fbx", ".glb")) for n in names):
            desired += ["domaine-3d", "3d-asset-pipeline"]
        if (p / ".git").exists():
            desired += ["git"]
    if studio.cfg.get("outils", {}).get("blender"):
        desired += ["blender-mcp"]
    desired += ["domaine-bureau", "context7", "skill-creator", "domaine-design", "code-review", "research-digest"]
    installed = {e["id"] for e in elements if e.get("installe")}
    out = []
    for v in desired:
        if v not in installed and v not in out:
            out.append(v)
    return out[:6]


# ------------------------------------------------------------------ install
def _download(url: str, delay: float = 60) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": "SuperAIStudio"})
    with urllib.request.urlopen(req, timeout=delay) as r:
        return r.read()


def install(studio, ident: str, value_map: dict | None = None, download=None) -> dict:
    e = _element(ident)
    value_map = value_map or {}
    if e["type"] == "skill":
        return _install_skill(studio, e, download or _download)
    if e["type"] == "mcp":
        return _install_mcp(studio, e, value_map)
    if e["type"] == "logiciel":
        return _install_software(studio, e, str(value_map.get("chemin", "")))
    if e["type"] == "pack":
        done_items, notes = [], []
        choice = value_map.get("selection")
        members = [m for m in e["membres"] if m in choice] if isinstance(choice, list) else list(e.get("base") or e["membres"])
        for m in members:
            try:
                if m.startswith("pack:"):
                    from .user_workspace import install_pack, nom
                    install_pack(studio.paths.root, m[5:], nom())
                    done_items.append(m)
                    continue
                r = install(studio, m, value_map.get(m) if isinstance(value_map.get(m), dict) else {}, download)
                if r.get("ok"):
                    done_items.append(m)
            except ValueError as ex:
                notes.append(f"{_element(m)['nom'] if not m.startswith('pack:') else m} : {ex}")
        _reload_roles(studio)
        return {"ok": True, "installes": done_items, "notes": notes,
                "message": f"Pack installé ({len(done_items)} élément(s))" + (" — à compléter : " + " ; ".join(notes) if notes else ".")}
    raise ValueError("Type inconnu.")


def _reload_roles(studio) -> None:
    try:
        from .orchestrator.roles import load_roles
        studio.roles = load_roles(studio.paths.roles)
    except Exception:                                    # noqa: BLE001
        pass


def _install_skill(studio, e: dict, download) -> dict:
    dest = Path(studio.paths.root) / "Skills" / e["id"]
    if (dest / "SKILL.md").exists():
        return {"ok": True, "deja": True, "message": f"« {e['nom']} » est déjà installée."}
    src = e["source"]
    if src["type"] == "studio":
        from .user_workspace import install_pack, nom
        install_pack(studio.paths.root, src["pack"], nom())
        _reload_roles(studio)
    elif src["type"] == "studio-skill":
        orig = MODELS / src["dossier"]
        if not (orig / "SKILL.md").is_file():
            raise ValueError("Skill absente de cette version du studio : mets le studio à jour.")
        for f in sorted(orig.rglob("*")):
            if f.is_file():
                (dest / f.relative_to(orig)).parent.mkdir(parents=True, exist_ok=True)
                (dest / f.relative_to(orig)).write_bytes(f.read_bytes())
        _write_json(dest / ".bibliotheque.json", {"source": "catalogue", "installe": time.strftime("%Y-%m-%d %H:%M")})
    elif src["type"] == "github":
        contents = {}
        for f in src["fichiers"]:
            if ".." in f["chemin"].split("/") or f["chemin"].startswith("/"):
                raise ValueError("Chemin refusé dans le catalogue.")
            url = (f"https://raw.githubusercontent.com/{src['depot']}/{src['commit']}/"
                   + urllib.parse.quote(f"{src['dossier']}/{f['chemin']}"))
            try:
                b = download(url)
            except OSError as ex:
                raise ValueError(f"Téléchargement impossible ({type(ex).__name__}) : vérifie la connexion internet.") from None
            if hashlib.sha256(b).hexdigest() != f["sha256"]:
                raise ValueError(f"Fichier altéré ({f['chemin']}) : rien n'est installé.")
            contents[f["chemin"]] = b
        tmp = dest.with_name(f".{e['id']}.installation")
        if tmp.exists():
            shutil.rmtree(tmp)
        for chemin, b in contents.items():                # everything checked before writing, then folder replaced in one go
            (tmp / chemin).parent.mkdir(parents=True, exist_ok=True)
            (tmp / chemin).write_bytes(b)
        _write_json(tmp / ".bibliotheque.json", {"source": "catalogue", "depot": src["depot"], "commit": src["commit"],
                                                  "installe": time.strftime("%Y-%m-%d %H:%M"), "licence": e.get("licence", "")})
        tmp.rename(dest)
    _synchronize(studio)
    return {"ok": True, "message": f"« {e['nom']} » installée : les agents l'utilisent dès maintenant."}


def _synchronize(studio) -> None:
    try:
        from .supervisor import sync_skills
        sync_skills(studio.paths.root)
    except Exception:                                    # noqa: BLE001 — « Synchroniser les skills » is still possible
        pass


def _install_mcp(studio, e: dict, value_map: dict) -> dict:
    needs = [p for p in e.get("prerequis", []) if not shutil.which(PREREQUISITES[p][0])]
    if needs:
        n, link = PREREQUISITES[needs[0]][1], PREREQUISITES[needs[0]][2]
        raise ValueError(f"Il faut d'abord {n} sur le PC : {link} (installe-le, puis réessaie).")
    from .ai import _encrypt
    secrets_f = Path(studio.paths.data) / "mcp-secrets.json"
    secrets = _read_json(secrets_f, {})
    for v in e.get("variables", []):
        val = str(value_map.get(v["nom"], "")).strip()
        if not val and v.get("secret"):
            raise ValueError(f"{v['libelle']} : obligatoire.")
        if val:
            if "\n" in val or len(val) > 2000:
                raise ValueError(f"{v['libelle']} : valeur invalide.")
            secrets[v["nom"]] = _encrypt(val)
    _write_json(secrets_f, secrets)
    d = _read_json(mcp_file(studio.paths.data), {})
    d = d if isinstance(d, dict) else {}
    d.setdefault("mcpServers", {})[e["id"]] = e["config"]
    _write_json(mcp_file(studio.paths.data), d)
    return {"ok": True, "message": f"« {e['nom']} » ajouté : les agents Claude Code l'utilisent dès la prochaine tâche."
                                   + (" Le serveur se télécharge à sa première utilisation." if e.get("prerequis") else "")}


def _install_software(studio, e: dict, chemin: str) -> dict:
    from . import software_connectors
    chemin = chemin or detect_software(e)
    if not chemin:
        raise ValueError(f"{e['nom']} n'est pas trouvé sur le PC. Installe-le depuis {e['site']}"
                         + (f" (ou dans PowerShell : winget install --id {e['winget']} -e)" if e.get("winget") else "")
                         + ", puis réessaie.")
    software_connectors.add_item(studio, e["nom"], chemin)
    return {"ok": True, "message": f"{e['nom']} déclaré aux agents ({chemin})."}


# ------------------------------------------------------------------ remove (nothing is deleted)
def retire(studio, ident: str, type_: str) -> dict:
    from . import software_connectors
    if not _ID.match(ident or ""):
        raise ValueError("Identifiant invalide.")
    if type_ == "skill":
        src = Path(studio.paths.root) / "Skills" / ident
        if not (src / "SKILL.md").exists():
            raise ValueError("Skill introuvable.")
        if ident == "superviseur" or (MODELS / "espace" / "Skills" / ident).is_dir():
            raise ValueError("Cette skill fait partie de la méthode du studio : elle reste.")
        archive = studio.paths.archives / "skills-retires" / f"{ident}-{time.strftime('%Y%m%d-%H%M%S')}"
        archive.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(src), str(archive))
        home = Path.home()
        for outil in (".claude", ".codex"):               # copies made by the studio: archived with it
            copy_dir = home / outil / "skills" / f"studio-{ident}"
            if (copy_dir / "SKILL.md").exists() and "genere-par-ai-workspace" in (copy_dir / "SKILL.md").read_text(encoding="utf-8", errors="replace"):
                shutil.move(str(copy_dir), str(archive / f"copie-{outil.strip('.')}"))
        return {"ok": True, "message": f"Skill rangée dans Archives\\skills-retires ({archive.name})."}
    if type_ == "mcp":
        d = _read_json(mcp_file(studio.paths.data), {})
        cfg = (d.get("mcpServers") or {}).pop(ident, None) if isinstance(d, dict) else None
        if cfg is None:
            raise ValueError("Serveur MCP introuvable.")
        _write_json(mcp_file(studio.paths.data), d)
        names = set(re.findall(r"\$\{([A-Z0-9_]+)\}", json.dumps(cfg)))
        others = set(re.findall(r"\$\{([A-Z0-9_]+)\}", json.dumps(d.get("mcpServers", {}))))
        sec_f = Path(studio.paths.data) / "mcp-secrets.json"
        sec = _read_json(sec_f, {})
        _write_json(sec_f, {k: v for k, v in sec.items() if k not in names - others})
        return {"ok": True, "message": "Serveur MCP retiré (les agents ne l'utilisent plus)."}
    if type_ == "logiciel":
        e = next((x for x in catalog()["elements"] if x["id"] == ident), None)
        nom = (e or {}).get("nom", "").lower()
        c = next((x for x in software_connectors.list_all(studio) if (x["nom"].lower() == nom if e else x["id"] == ident)), None)
        if not c:
            raise ValueError("Logiciel non déclaré.")
        software_connectors.retire(studio, c["id"])
        return {"ok": True, "message": f"{c['nom']} n'est plus déclaré aux agents (rien n'est désinstallé)."}
    raise ValueError("Ce type ne se retire pas d'un bloc : retire ses éléments un par un.")


# ------------------------------------------------------------------ import a skill (.zip)
SUSPECTS = [(r"(?i)ignore (all |the )?(previous|prior) instructions|ignore les instructions", "demande d'ignorer des consignes"),
            (r"(?i)(curl|wget|iwr|invoke-webrequest)[^\n|]*\|\s*(sh|bash|iex|powershell)", "télécharge puis exécute"),
            (r"(?i)(api[_-]?key|token|password|mot de passe)\s*[:=]", "parle de clés ou mots de passe"),
            (r"[A-Za-z0-9+/]{400,}={0,2}", "long bloc encodé")]


def review(task_files: dict[str, bytes]) -> list[str]:
    """Points to check before installing a skill from elsewhere (nothing is executed)."""
    notes = []
    scripts = [c for c in task_files if c.lower().endswith((".py", ".ps1", ".sh", ".bat", ".cmd", ".js", ".exe", ".dll"))]
    if scripts:
        notes.append(f"Contient {len(scripts)} script(s) que les agents pourront lancer : " + ", ".join(scripts[:5]))
    for c, b in task_files.items():
        if not c.lower().endswith((".md", ".txt", ".py", ".ps1", ".sh", ".js", ".json", ".yaml", ".yml", ".toml")):
            continue
        t = b.decode("utf-8", errors="ignore")
        for pattern, reason in SUSPECTS:
            if re.search(pattern, t):
                notes.append(f"{c} : {reason}")
        urls = set(re.findall(r"https?://[^\s)\"'>]+", t))
        if urls:
            notes.append(f"{c} : {len(urls)} adresse(s) web")
    return notes[:12]


def import_skill(studio, archive: bytes, confirm: bool = False) -> dict:
    if len(archive) > MAX_IMPORT:
        raise ValueError("Archive trop lourde (30 Mo maximum).")
    try:
        z = zipfile.ZipFile(io.BytesIO(archive))
    except zipfile.BadZipFile:
        raise ValueError("Ce n'est pas un fichier .zip.") from None
    names = [i for i in z.infolist() if not i.is_dir()]
    if sum(i.file_size for i in names) > 100 * 1024 * 1024 or len(names) > 2000:
        raise ValueError("Archive trop grosse une fois décompressée.")
    skill_md = sorted((i.filename for i in names if i.filename.replace("\\", "/").split("/")[-1] == "SKILL.md"), key=len)
    if not skill_md:
        raise ValueError("Pas de SKILL.md dans l'archive : ce n'est pas une skill.")
    base = skill_md[0].replace("\\", "/")[: -len("SKILL.md")]
    task_files = {}
    for i in names:
        n = i.filename.replace("\\", "/")
        if not n.startswith(base) or ".." in n.split("/") or n.startswith("/") or ":" in n:
            continue
        task_files[n[len(base):]] = z.read(i)
    texte = task_files["SKILL.md"].decode("utf-8", errors="replace")
    m = re.search(r"(?mi)^name:\s*[\"']?([A-Za-z0-9 _-]+?)[\"']?\s*$", texte)
    ident = re.sub(r"[^a-z0-9-]+", "-", (m.group(1) if m else base.strip("/").split("/")[-1] or "skill").lower()).strip("-")[:60] or "skill"
    notes = review(task_files)
    dest = Path(studio.paths.root) / "Skills" / ident
    if (dest / "SKILL.md").exists():
        raise ValueError(f"Une skill « {ident} » existe déjà : rien n'est remplacé (renomme-la dans son SKILL.md).")
    if not confirm:
        return {"ok": True, "apercu": True, "id": ident, "fichiers": len(task_files), "notes": notes,
                "extrait": texte[:1500]}
    for c, b in task_files.items():
        (dest / c).parent.mkdir(parents=True, exist_ok=True)
        (dest / c).write_bytes(b)
    _write_json(dest / ".bibliotheque.json", {"source": "import", "installe": time.strftime("%Y-%m-%d %H:%M"), "relecture": notes})
    _synchronize(studio)
    return {"ok": True, "id": ident, "message": f"Skill « {ident} » importée ({len(task_files)} fichier(s))."}


def export_skill(studio, ident: str) -> bytes:
    """One of your skills as a .zip, to share it."""
    if not _ID.match(ident or ""):
        raise ValueError("Identifiant invalide.")
    d = Path(studio.paths.root) / "Skills" / ident
    if not (d / "SKILL.md").exists():
        raise ValueError("Skill introuvable.")
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for f in sorted(d.rglob("*")):
            if f.is_file() and f.name != ".bibliotheque.json":
                z.write(f, f"{ident}/{f.relative_to(d).as_posix()}")
    return buf.getvalue()


def add_custom_mcp(studio, nom: str, command: str, arguments: str = "", url: str = "") -> dict:
    """MCP server added by hand (command or address) — at your own risk: it has not been reviewed by the studio."""
    ident = re.sub(r"[^a-z0-9-]+", "-", (nom or "").lower()).strip("-")[:40]
    if not ident:
        raise ValueError("Donne un nom au serveur.")
    if url:
        if not re.match(r"^https://|^http://(127\.0\.0\.1|localhost)(:\d+)?/", url):
            raise ValueError("Adresse https (ou http://127.0.0.1 pour un serveur local) attendue.")
        cfg = {"type": "http", "url": url}
    else:
        command = (command or "").strip()
        if not command or any(c in command for c in "|&;<>`\n"):
            raise ValueError("Commande simple attendue (ex. npx).")
        import shlex
        cfg = {"command": command, "args": shlex.split(arguments or "", posix=os.name != "nt")}
    d = _read_json(mcp_file(studio.paths.data), {})
    d = d if isinstance(d, dict) else {}
    if ident in d.get("mcpServers", {}):
        raise ValueError("Un serveur porte déjà ce nom.")
    d.setdefault("mcpServers", {})[ident] = cfg
    _write_json(mcp_file(studio.paths.data), d)
    return {"ok": True, "message": f"Serveur « {ident} » ajouté pour les agents Claude Code."}
