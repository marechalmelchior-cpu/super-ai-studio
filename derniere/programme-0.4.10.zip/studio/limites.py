"""Limites des abonnements Claude et Codex, en pourcentage (fenêtre de 5 h et semaine).

- **Codex** : chaque session de Codex (CLI, application, tâches du studio) écrit ses limites dans
  ``~/.codex/sessions/AAAA/MM/JJ/rollout-*.jsonl`` (événement ``token_count`` → ``rate_limits``). On lit la dernière
  valeur, sans réseau. Elle date de la dernière utilisation de Codex : si sa remise à zéro est passée, la fenêtre est à 0 %.
- **Claude** : les mêmes chiffres que la commande ``/usage`` de Claude Code, demandés à Anthropic avec la connexion déjà
  enregistrée par Claude Code (``~/.claude/.credentials.json``). Point d'accès non documenté : il peut changer ; en cas
  d'échec, le studio affiche « indisponible » et rien d'autre ne casse. Le jeton n'est jamais affiché, écrit ni journalisé.

Rien n'est installé, rien n'est modifié : lecture seule. Désactivable dans studio.config.toml, [usage] limites_claude /
limites_codex = false.
"""
from __future__ import annotations

import json
import threading
import time
import urllib.error
import urllib.request
from datetime import datetime
from pathlib import Path

URL_CLAUDE = "https://api.anthropic.com/api/oauth/usage"
_cache: dict[str, tuple[float, dict]] = {}
_verrou = threading.Lock()


def _epoch(v) -> float | None:
    """Horodatage en secondes depuis 1970 : nombre (s ou ms) ou texte ISO 8601."""
    if v is None or v == "":
        return None
    if isinstance(v, (int, float)):
        return float(v) / (1000 if v > 1e12 else 1)
    try:
        return datetime.fromisoformat(str(v).replace("Z", "+00:00")).timestamp()
    except ValueError:
        return None


def _nom_fenetre(minutes: float | None, defaut: str) -> str:
    if not minutes:
        return defaut
    return "5 h" if minutes <= 6 * 60 else "Semaine" if minutes >= 6 * 24 * 60 else f"{round(minutes / 60)} h"


def _fenetre(nom: str, pct, reinit, maintenant: float) -> dict:
    pct = max(0.0, min(100.0, float(pct or 0)))
    r = _epoch(reinit)
    passe = r is not None and r <= maintenant
    return {"nom": nom, "pct": 0.0 if passe else round(pct, 1), "reinit": r, "remise_a_zero": passe}


# ---------------------------------------------------------------- Codex
def _dernier_rate_limits(fichier: Path) -> tuple[dict | None, str]:
    """Dernier bloc ``rate_limits`` non vide d'un journal de session Codex (lu par la fin, morceau par morceau)."""
    try:
        with fichier.open("rb") as f:
            f.seek(0, 2)
            fin = f.tell()
            reste = b""
            pos = fin
            while pos > 0:
                pas = min(256 * 1024, pos)
                pos -= pas
                f.seek(pos)
                bloc = f.read(pas) + reste
                lignes = bloc.split(b"\n")
                reste = lignes[0] if pos > 0 else b""
                for ligne in reversed(lignes[1:] if pos > 0 else lignes):
                    if b'"rate_limits"' not in ligne:
                        continue
                    try:
                        d = json.loads(ligne)
                    except ValueError:
                        continue
                    p = d.get("payload") if isinstance(d.get("payload"), dict) else d
                    rl = p.get("rate_limits") or (p.get("info") or {}).get("rate_limits") if isinstance(p, dict) else None
                    if isinstance(rl, dict) and (rl.get("primary") or rl.get("secondary")):
                        return rl, str(d.get("timestamp") or "")
                if fin - pos > 64 * 1024 * 1024:          # journal énorme : on n'y passe pas la journée
                    break
    except OSError:
        pass
    return None, ""


def limites_codex(home: Path | None = None, maintenant: float | None = None) -> dict:
    maintenant = maintenant or time.time()
    racine = Path(home or Path.home()) / ".codex" / "sessions"
    if not racine.is_dir():
        return {"ok": False, "info": "Aucune session Codex trouvée sur ce PC."}
    jours = sorted((d for a in racine.iterdir() if a.is_dir() and a.name.isdigit()
                    for m in a.iterdir() if m.is_dir() for d in m.iterdir() if d.is_dir()), reverse=True)
    for d in jours[:14]:                                  # deux semaines au plus : au-delà, plus rien d'utile
        for f in sorted(d.glob("rollout-*.jsonl"), key=lambda p: p.stat().st_mtime, reverse=True)[:20]:
            rl, quand = _dernier_rate_limits(f)
            if not rl:
                continue
            vu = _epoch(quand) or f.stat().st_mtime
            fen = []
            for cle, defaut in (("primary", "5 h"), ("secondary", "Semaine")):
                w = rl.get(cle)
                if not isinstance(w, dict):
                    continue
                reinit = w.get("resets_at")
                if reinit is None and w.get("resets_in_seconds") is not None:
                    reinit = vu + float(w["resets_in_seconds"])
                fen.append(_fenetre(_nom_fenetre(w.get("window_minutes"), defaut), w.get("used_percent"), reinit, maintenant))
            fen.sort(key=lambda x: x["nom"] != "5 h")
            if fen:
                return {"ok": True, "fenetres": fen, "vu": vu, "offre": str(rl.get("plan_type") or ""),
                        "info": "Dernière valeur relevée par Codex (mise à jour à chaque utilisation de Codex)."}
    return {"ok": False, "info": "Codex n'a encore enregistré aucune limite (utilise-le une fois)."}


# ---------------------------------------------------------------- Claude
def _jeton_claude(home: Path) -> tuple[str, str]:
    f = home / ".claude" / ".credentials.json"
    try:
        d = json.loads(f.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return "", "Connexion de Claude Code introuvable sur ce PC."
    o = d.get("claudeAiOauth") if isinstance(d, dict) else None
    if not isinstance(o, dict) or not o.get("accessToken"):
        return "", "Claude Code n'est pas connecté avec un abonnement."
    exp = _epoch(o.get("expiresAt"))
    if exp and exp < time.time():
        return "", EXPIREE
    return str(o["accessToken"]), ""


EXPIREE = "Reconnexion de Claude Code en cours…"
_reconnexion = {"t": 0.0, "en_cours": False}


def reconnecter_claude(cfg: dict, home: Path | None = None, lancer=None) -> dict:
    """Connexion de Claude Code expirée (jeton de quelques heures) : Claude Code la renouvelle lui-même.
    1) « claude auth status » (sans appel au modèle) ; 2) si besoin, une réponse d'un mot avec Haiku (coût infime).
    Le studio ne lit, n'écrit ni n'affiche jamais le jeton. Renvoie {"ok", "info", "connexion"}."""
    import subprocess
    from .connectors.base import SANS_FENETRE, find_exe
    from .connectors.claude_code import WIN_CANDIDATES
    home = Path(home or Path.home())
    exe = find_exe(cfg.get("outils", {}).get("claude", "claude"), WIN_CANDIDATES)
    if not exe:
        return {"ok": False, "info": "Claude Code n'est pas installé sur ce PC.", "connexion": False}
    lancer = lancer or (lambda cmd, delai: subprocess.run(cmd, capture_output=True, text=True, timeout=delai, cwd=str(home),
                                                          stdin=subprocess.DEVNULL, **SANS_FENETRE))
    for cmd, delai in (([exe, "auth", "status"], 30),
                       ([exe, "-p", "Réponds seulement : ok", "--model", "haiku", "--max-turns", "1"], 120)):
        try:
            lancer(cmd, delai)
        except (OSError, subprocess.TimeoutExpired):
            continue
        jeton, raison = _jeton_claude(home)
        if jeton:
            with _verrou:
                _cache.pop("claude", None)
            return {"ok": True, "info": "Claude Code reconnecté.", "connexion": True}
    jeton, raison = _jeton_claude(home)
    return {"ok": False, "info": "Claude Code demande de te reconnecter : clique « Se connecter ».", "connexion": True}


def connexion_claude(cfg: dict) -> dict:
    """Ouvre « claude auth login » dans une fenêtre sur le PC (navigateur pour te connecter). Rien d'autre."""
    import subprocess
    import sys
    from .connectors.base import find_exe
    from .connectors.claude_code import WIN_CANDIDATES
    exe = find_exe(cfg.get("outils", {}).get("claude", "claude"), WIN_CANDIDATES)
    if not exe:
        raise ValueError("Claude Code n'est pas installé sur ce PC.")
    if sys.platform == "win32":
        subprocess.Popen(["cmd", "/c", "start", "Connexion Claude Code", "cmd", "/k", exe, "auth", "login"],
                         creationflags=0x00000010)                    # nouvelle console visible
    else:
        subprocess.Popen([exe, "auth", "login"], start_new_session=True)
    with _verrou:
        _cache.pop("claude", None)
    return {"ok": True, "info": "Une fenêtre de connexion Claude Code s'est ouverte sur le PC : suis-la, puis reviens ici."}


def _reconnecter_en_fond(cfg: dict, home: Path | None) -> None:
    """Au plus une tentative automatique toutes les 30 min, jamais deux en même temps."""
    with _verrou:
        if _reconnexion["en_cours"] or time.monotonic() - _reconnexion["t"] < 1800 and _reconnexion["t"]:
            return
        _reconnexion.update(en_cours=True, t=time.monotonic())

    def faire():
        try:
            reconnecter_claude(cfg, home)
        finally:
            with _verrou:
                _reconnexion["en_cours"] = False
                _cache.pop("claude", None)
    threading.Thread(target=faire, daemon=True).start()


def lire_reponse_claude(d: dict, maintenant: float | None = None) -> list[dict]:
    """Deux formes connues : ``{"five_hour": {"utilization", "resets_at"}, "seven_day": …}`` et
    ``{"limits": [{"kind", "percent", "resets_at", "scope": {"model": {"display_name"}}}]}``."""
    maintenant = maintenant or time.time()
    fen = []
    if isinstance(d.get("limits"), list):
        noms = {"session": "5 h", "five_hour": "5 h", "weekly_all": "Semaine", "seven_day": "Semaine"}
        for x in d["limits"]:
            if not isinstance(x, dict) or x.get("percent") is None:
                continue
            modele = ((x.get("scope") or {}).get("model") or {}).get("display_name") if isinstance(x.get("scope"), dict) else None
            nom = f"Sem. {modele}" if modele else noms.get(str(x.get("kind")), str(x.get("kind") or "?"))
            fen.append(_fenetre(nom, x["percent"], x.get("resets_at"), maintenant))
    else:
        for cle, nom in (("five_hour", "5 h"), ("seven_day", "Semaine"), ("seven_day_opus", "Sem. Opus"),
                         ("seven_day_sonnet", "Sem. Sonnet")):
            w = d.get(cle)
            if isinstance(w, dict) and w.get("utilization") is not None:
                fen.append(_fenetre(nom, w["utilization"], w.get("resets_at"), maintenant))
        if not fen:                                     # autre forme : toute fenêtre {utilization | percent | used_percentage}
            for cle, w in d.items():
                if isinstance(w, dict):
                    v = next((w[k] for k in ("utilization", "percent", "used_percentage") if w.get(k) is not None), None)
                    if v is not None:
                        fen.append(_fenetre(str(cle).replace("_", " "), v, w.get("resets_at"), maintenant))
    return fen


def limites_claude(home: Path | None = None, delai_s: float = 8, ouvrir=urllib.request.urlopen) -> dict:
    jeton, raison = _jeton_claude(Path(home or Path.home()))
    if not jeton:
        return {"ok": False, "info": raison}
    req = urllib.request.Request(URL_CLAUDE, headers={"Authorization": f"Bearer {jeton}", "anthropic-beta": "oauth-2025-04-20",
                                                      "Accept": "application/json", "User-Agent": "super-ai-agent-pro-station"})
    del jeton
    try:
        with ouvrir(req, timeout=delai_s) as r:
            d = json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:                  # message sans en-têtes ni jeton
        return {"ok": False, "info": "Connexion refusée : relance Claude Code une fois." if e.code in (401, 403)
                else f"Anthropic ne donne pas les limites pour l'instant (code {e.code})."}
    except (urllib.error.URLError, TimeoutError, OSError, ValueError) as e:
        return {"ok": False, "info": f"Limites Claude indisponibles ({type(e).__name__})."}
    fen = lire_reponse_claude(d if isinstance(d, dict) else {})
    if not fen:
        return {"ok": False, "info": "Réponse d'Anthropic sans limites lisibles (format changé ?)."}
    return {"ok": True, "fenetres": fen, "vu": time.time(), "info": "Mêmes chiffres que /usage dans Claude Code."}


def _duree_fenetre(nom: str) -> float | None:
    if nom.startswith("Sem"):
        return 7 * 86400.0
    m = __import__("re").match(r"(\d+) h", nom)
    return float(m.group(1)) * 3600 if m else None


def alertes(lim: dict, seuils: dict, maintenant: float | None = None) -> list[dict]:
    """Alerte quand, au rythme actuel, la limite sera atteinte dans moins de ``seuil`` minutes (et avant sa remise à zéro).

    Rythme = pourcentage utilisé depuis le début de la fenêtre (remise à zéro − durée). Rien si les limites sont
    indisponibles : mieux vaut pas d'alerte qu'une alerte qui ne veut rien dire."""
    maintenant = maintenant or time.time()
    out = []
    for outil in ("Claude", "Codex"):
        seuil = int(seuils.get(outil, 0) or 0)
        l = lim.get(outil) or {}
        if not seuil or not l.get("ok"):
            continue
        for f in l.get("fenetres", []):
            pct, reinit, duree = f.get("pct") or 0, f.get("reinit"), _duree_fenetre(f.get("nom", ""))
            if not reinit or not duree or f.get("remise_a_zero") or reinit <= maintenant:
                continue
            base = {"outil": outil, "fenetre": f["nom"], "pct": pct, "reinit": reinit, "seuil": seuil}
            if pct >= 100:
                out.append({**base, "minutes": 0})
                continue
            ecoule = maintenant - (reinit - duree)
            if pct <= 0 or ecoule < 600:                  # moins de 10 min de recul : rythme pas fiable
                continue
            restant = (100 - pct) / (pct / ecoule)
            if restant <= seuil * 60 and maintenant + restant < reinit:
                out.append({**base, "minutes": max(1, round(restant / 60))})
    return out


def limites(cfg: dict, home: Path | None = None, cache_s: float = 60) -> dict:
    """Limites des deux outils ; Claude est mis en cache 60 s (une requête par minute au plus)."""
    u = cfg.get("usage", {})
    out = {}
    if u.get("limites_claude", True):
        with _verrou:
            t, v = _cache.get("claude", (0.0, {}))
            if time.monotonic() - t > cache_s or not v:
                v = limites_claude(home)
                _cache["claude"] = (time.monotonic(), v)
        if not v.get("ok") and v.get("info") == EXPIREE and u.get("reconnexion_auto", True):
            _reconnecter_en_fond(cfg, home)               # connexion expirée : renouvelée seule, en arrière-plan
            v = {**v, "reconnexion": "en_cours" if _reconnexion["en_cours"] else "bouton"}
            if not _reconnexion["en_cours"]:
                v["info"] = "Connexion de Claude Code expirée."
        elif not v.get("ok") and ("refusée" in v.get("info", "") or "pas connecté" in v.get("info", "")):
            v = {**v, "reconnexion": "bouton"}
        out["Claude"] = v
    else:
        out["Claude"] = {"ok": False, "info": "Désactivé ([usage] limites_claude)."}
    out["Codex"] = limites_codex(home) if u.get("limites_codex", True) else {"ok": False, "info": "Désactivé ([usage] limites_codex)."}
    out["maintenant"] = time.time()
    return out
