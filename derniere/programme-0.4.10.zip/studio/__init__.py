"""Studio IA personnel de Mel — orchestration, mémoire partagée, connecteurs.

Le paquet est volontairement sans dépendance pour tout ce qui n'est pas
l'orchestration (LangGraph). Les connecteurs utilisent la bibliothèque standard.
"""

import os

__version__ = "0.1.0"

# Données locales par défaut : aucun traçage LangSmith/LangChain vers Internet.
for _var in ("LANGSMITH_TRACING", "LANGCHAIN_TRACING_V2", "LANGCHAIN_TRACING"):
    os.environ[_var] = "false"
