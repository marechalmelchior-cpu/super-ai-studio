"""Connecteur Claude Code — exécution programmatique ``claude -p``.

Choix (doc : https://code.claude.com/docs/en/headless) :
- ``-p --output-format json`` : champs ``result``, ``session_id``, ``is_error``,
  ``total_cost_usd`` (estimation côté client), ``structured_output`` si ``--json-schema`` ;
- pas de ``--bare`` : ce mode n'utilise pas l'abonnement (clé API requise) ;
  sans lui, CLAUDE.md, skills et hooks du dossier sont chargés comme en interactif ;
- permissions : ``--permission-mode acceptEdits`` limité à l'espace isolé +
  ``--allowedTools`` par mission ; jamais de contournement global des protections ;
- ``--permission-prompts none`` seulement si la version installée le permet (≥ 2.1.259) ;
- reprise : chaque mission reçoit un identifiant de conversation fixe (``--session-id``). Si Mel l'arrête puis la reprend,
  le studio relance la même conversation (``--resume``) : l'agent garde tout ce qu'il a lu et fait, et continue.
"""
from __future__ import annotations

import json
import re
from pathlib import Path

from ..orchestrator.processes import run_process
from .base import CONSIGNE_REPRISE, SANS_FENETRE, ExecResult, Mission, fiche_conversation, find_exe, niveau_effectif, noter

WIN_CANDIDATES = [str(Path.home() / ".local/bin/claude.exe"), str(Path.home() / "AppData/Roaming/npm/claude.cmd")]


def parse_version(text: str) -> tuple[int, ...]:
    m = re.search(r"(\d+)\.(\d+)\.(\d+)", text or "")
    return tuple(int(x) for x in m.groups()) if m else ()


class ClaudeCodeExecutor:
    name = "claude-code"

    def __init__(self, exe: str = "claude", permission_mode: str = "acceptEdits", timeout_s: float = 900,
                 json_schema: dict | None = None):
        if permission_mode in ("bypassPermissions",):
            raise ValueError("Le studio ne désactive pas les protections de Claude Code.")
        self.exe = find_exe(exe, WIN_CANDIDATES)
        self.permission_mode = permission_mode
        self.timeout_s = timeout_s
        self.json_schema = json_schema
        self._version: tuple[int, ...] | None = None
        self.mcp_unreal = "tout"                      # [outils] mcp_unreal : « tout » ou « lecture »

    def version(self, store=None) -> tuple[int, ...]:
        if self._version is None:
            if not self.exe:
                self._version = ()
            else:
                import subprocess
                try:
                    out = subprocess.run([self.exe, "--version"], capture_output=True, text=True, timeout=30, **SANS_FENETRE).stdout
                except (OSError, subprocess.TimeoutExpired):
                    out = ""
                self._version = parse_version(out)
        return self._version

    def connait_effort(self) -> bool:
        """--effort (low, medium, high, xhigh, max) : seulement si l'aide de la version installée le mentionne."""
        if getattr(self, "_effort", None) is None:
            import subprocess
            try:
                aide = subprocess.run([self.exe, "--help"], capture_output=True, text=True, timeout=30, encoding="utf-8",
                                      errors="replace", **SANS_FENETRE).stdout if self.exe else ""
            except (OSError, subprocess.TimeoutExpired):
                aide = ""
            self._effort = "--effort" in aide
            self._settings = "--settings" in aide
            self._reprise = "--session-id" in aide and "--resume" in aide
        return self._effort

    def connait_settings(self) -> bool:
        """--settings (réglages en plus pour cette exécution) : seulement si l'aide de la version installée le mentionne."""
        if getattr(self, "_settings", None) is None:
            self._effort = None
            self.connait_effort()
        return bool(self._settings)

    def connait_reprise(self) -> bool:
        """--session-id et --resume : seulement si l'aide de la version installée les mentionne."""
        if getattr(self, "_reprise", None) is None:
            self._effort = None
            self.connait_effort()
        return bool(getattr(self, "_reprise", False))

    @staticmethod
    def conversation_existe(sid: str, home: Path | None = None) -> bool:
        """Conversation enregistrée par Claude Code (~/.claude/projects/<dossier>/<id>.jsonl), non vide."""
        if not re.fullmatch(r"[0-9a-f-]{36}", sid or ""):
            return False
        base = Path(home or Path.home()) / ".claude" / "projects"
        return any(f.stat().st_size > 0 for f in base.glob(f"*/{sid}.jsonl"))

    @staticmethod
    def reglages_garde() -> dict:
        """Hook PreToolUse (studio/garde_mcp.py) : unreal-mcp et commandes shell, autorisés et notés ; seules les commandes
        qui détruisent ou publient sont refusées. Sans ce garde, call_tool et le shell restent refusés (aucune fenêtre)."""
        import sys
        script = (Path(__file__).resolve().parents[1] / "garde_mcp.py").as_posix()
        py = Path(sys.executable).as_posix()
        return {"hooks": {"PreToolUse": [{"matcher": "mcp__unreal-mcp__.*|Bash|PowerShell|Edit|Write|MultiEdit|NotebookEdit",
                                          "hooks": [{"type": "command", "command": f'"{py}" "{script}"', "timeout": 15}]}]}}

    def options_effort(self, niveau: str) -> list[str]:
        return ["--effort", niveau] if niveau and self.connait_effort() else []

    def available(self) -> tuple[bool, str]:
        if not self.exe:
            return False, "Claude Code introuvable (commande « claude »)."
        v = self.version()
        return bool(v), f"Claude Code {'.'.join(map(str, v)) or 'version illisible'} ({self.exe})"

    def build_command(self, mission: Mission, prompt_file: Path, session: str = "", reprise: bool = False,
                      mcp: tuple[str, list[str]] | None = None) -> list[str]:
        consigne = (CONSIGNE_REPRISE.format(ref=f" ({prompt_file.name})") if reprise
                    else f"Lis et exécute la mission décrite dans {prompt_file.name}.")
        cmd = [self.exe or "claude", "-p", consigne,
               "--output-format", "json", "--permission-mode", self.permission_mode,
               "--append-system-prompt-file", str(prompt_file)]
        if session:
            cmd += ["--resume", session] if reprise else ["--session-id", session]
        if mcp and mcp[1]:                             # serveurs MCP ajoutés dans Personnalisation (data/mcp.json)
            cmd += ["--mcp-config", mcp[0]]
        if mission.outils:
            cmd += ["--allowedTools", ",".join(list(mission.outils) + [f"mcp__{n}" for n in (mcp[1] if mcp else [])])]
        if mission.modele:
            cmd += ["--model", mission.modele]
        for d in mission.dossiers:                     # ex. Taches\<tâche>\captures : l'agent peut y enregistrer ses images
            cmd += ["--add-dir", d]
        cmd += self.options_effort(niveau_effectif(mission.niveau, mission.effort))
        if self.version() >= (2, 1, 259):
            cmd += ["--permission-prompts", "none"]
        if self.json_schema:
            cmd += ["--json-schema", json.dumps(self.json_schema)]
        reglages = prompt_file.with_name(prompt_file.stem + "-reglages.json")
        if reglages.exists():
            cmd += ["--settings", str(reglages)]
        return cmd

    def execute(self, mission: Mission, workdir: Path, runner) -> ExecResult:
        ok, info = self.available()
        if not ok:
            return ExecResult(False, info, self.name, error=info)
        prompt_file = workdir / f".mission-{mission.task_id}-{mission.tentative}.md"
        prompt_file.write_text(mission.prompt(), encoding="utf-8")
        reglages = prompt_file.with_name(prompt_file.stem + "-reglages.json")
        if self.connait_settings():                # garde unreal-mcp (lecture seule) pour cette exécution
            reglages.write_text(json.dumps(self.reglages_garde(), ensure_ascii=False), encoding="utf-8")
        import os
        env = {**os.environ, "STUDIO_MCP_UNREAL": self.mcp_unreal}
        try:                                          # journal des actions unreal-mcp de cette tâche (compte rendu)
            env["STUDIO_ACTIONS_UNREAL"] = str(runner.details_dir(mission.task_id) / "actions-unreal.log")
            env["STUDIO_COMMANDES"] = str(runner.details_dir(mission.task_id) / "commandes.log")
            env["STUDIO_ACTIVITE"] = str(runner.details_dir(mission.task_id) / "activite.log")
            env["STUDIO_TACHE_DOSSIER"] = str(runner.run_dir(mission.task_id))
        except Exception:                             # noqa: BLE001 — exécutant utilisé hors du studio
            pass
        if niveau_effectif(mission.niveau, mission.effort) == "max" and not self.connait_effort():
            env["MAX_THINKING_TOKENS"] = "31999"      # ancienne version sans --effort : réflexion étendue
        session, reprise, fiche = self._session(mission, runner)
        mcp = None
        try:                                          # Personnalisation : serveurs MCP des agents, clés par variables
            from ..bibliotheque import env_mcp, fichier_mcp, mcp_installes
            data = runner.paths.data
            tous = mcp_installes(data)
            noms = sorted(n for n in tous if mission.mcp is None or n in mission.mcp)
            if noms:
                chemin = str(fichier_mcp(data))
                if len(noms) < len(tous):                 # projet : seulement ses serveurs (fichier sans clé, ${VAR})
                    f = runner.details_dir(mission.task_id) / "mcp-projet.json"
                    f.write_text(json.dumps({"mcpServers": {n: tous[n] for n in noms}}, ensure_ascii=False), encoding="utf-8")
                    chemin = str(f)
                mcp = (chemin, noms)
                env.update(env_mcp(data))
        except Exception:                             # noqa: BLE001 — sans studio (tests, hors tâche) : aucun serveur ajouté
            mcp = None
        try:
            res = run_process(runner.store, mission.task_id, self.build_command(mission, prompt_file, session, reprise, mcp),
                              workdir, self.timeout_s, env=env)
        finally:
            prompt_file.unlink(missing_ok=True)
            reglages.unlink(missing_ok=True)
        if fiche is not None and res.status == "termine":    # conversation menée à son terme : plus rien à reprendre
            fiche.unlink(missing_ok=True)
        return self.parse(res.stdout, res.stderr, res.returncode, res.status)

    def _session(self, mission: Mission, runner) -> tuple[str, bool, Path | None]:
        """Identifiant de conversation de la mission. Fiche présente + conversation enregistrée = la mission avait été
        arrêtée : on la reprend. Sinon nouvel identifiant, noté dans la fiche avant le lancement."""
        import uuid
        fiche = fiche_conversation(runner, mission, "claude", "txt") if self.connait_reprise() else None
        if fiche is None:
            return "", False, None
        try:
            ancien = fiche.read_text(encoding="utf-8").strip() if fiche.exists() else ""
            if ancien and self.conversation_existe(ancien):
                noter(runner, mission.task_id, f"{mission.role} reprend sa conversation là où il s'était arrêté")
                return ancien, True, fiche
            sid = str(uuid.uuid4())
            fiche.write_text(sid, encoding="utf-8")
            return sid, False, fiche
        except OSError:
            return "", False, None

    def parse(self, stdout: str, stderr: str, code: int | None, status: str) -> ExecResult:
        if status != "termine":
            return ExecResult(False, f"Claude Code : {status}", self.name, error=status)
        try:
            data = json.loads(stdout.strip().splitlines()[-1]) if stdout.strip() else {}
        except json.JSONDecodeError:
            return ExecResult(False, "Sortie JSON illisible", self.name, error=(stderr or stdout)[-2000:])
        is_err = bool(data.get("is_error")) or code not in (0, None)
        return ExecResult(ok=not is_err, summary=str(data.get("result", ""))[:8000], executor=self.name,
                          session_id=str(data.get("session_id", "")), cost_estimate_usd=data.get("total_cost_usd"),
                          raw={k: data.get(k) for k in ("session_id", "num_turns", "duration_ms", "structured_output",
                                                        "permission_denials", "usage") if k in data},
                          error=str(data.get("result", ""))[:2000] if is_err else "")
