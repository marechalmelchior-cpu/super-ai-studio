"""Agent par IA connectée (clé API ou IA locale) : boucle d'outils limitée à la copie isolée de la tâche.

Outils : lister, lire, chercher, écrire (pas d'écriture pour un relecteur), et « commande » selon le réglage
« Commandes des agents API » :
- « non » : aucune commande ;
- « sures » (par défaut) : tests, compilation, lint (python, pytest, node, npm test, dotnet, cargo, go, git en lecture…),
  sans enchaînement (&&, |, ;, >), sans chemin hors du dossier, sans installation de paquets ;
- « toutes » : comme Claude Code, toute commande sauf celles qui détruisent ou publient (règles du garde du studio).
Chaque commande tourne dans la copie de la tâche, avec un délai, arrêtée si la tâche est annulée, notée dans le
journal de la tâche. Chaque action est aussi notée dans le fil d'activité (vue en direct). Aucun accès hors du
dossier de la tâche pour les outils de fichiers, aucun réseau autre que l'appel au fournisseur choisi. Les clés ne
passent jamais dans la mission, les commandes ni le compte rendu.
"""
from __future__ import annotations

import json
import os
import re
import shlex
import shutil
import sys
from datetime import datetime
from pathlib import Path

from ..orchestrator.processes import Cancelled
from .base import ExecResult, Mission

MAX_TOURS = 40
MAX_LECTURE = 60_000
IGNORES = {".git", "node_modules", "Binaries", "Intermediate", "Saved", "DerivedDataCache", ".venv", "__pycache__"}
DELAI_COMMANDE_S = 600
MAX_SORTIE = 12_000
# mode « sures » : programmes de test, compilation et vérification
SURES = {"python", "python3", "py", "pytest", "node", "npm", "npx", "pnpm", "yarn", "bun", "deno", "tsc", "eslint",
         "prettier", "jest", "vitest", "ruff", "mypy", "black", "flake8", "pylint", "dotnet", "msbuild", "cargo", "rustc",
         "go", "make", "cmake", "ninja", "javac", "java", "gradle", "gradlew", "mvn", "php", "composer", "ruby",
         "bundle", "rake", "swift", "gcc", "g++", "clang", "clang++", "cl", "godot", "git"}
GIT_LECTURE = {"status", "diff", "log", "show", "branch", "ls-files", "blame", "grep", "rev-parse"}
INSTALLATION = {"install", "i", "ci", "add", "remove", "uninstall", "publish", "update", "upgrade", "link", "login"}
_SECRET_ENV = re.compile(r"(KEY|TOKEN|SECRET|PASSWORD|PASSWD|CREDENTIAL|AUTH)", re.I)


def mode_commandes(cfg: dict | None) -> str:
    m = str(((cfg or {}).get("agents_api") or {}).get("commandes", "sures"))
    return m if m in ("non", "sures", "toutes") else "sures"


def verifier_commande(cmd: str, mode: str) -> tuple[list[str] | None, str]:
    """(arguments à lancer, "") si la commande passe ; (None, raison) sinon. Mode « toutes » : lancée par le shell."""
    from ..garde_mcp import decision_shell
    cmd = (cmd or "").strip()
    if not cmd:
        return None, "commande vide"
    if mode == "non":
        return None, "les commandes sont désactivées (réglage « Commandes des agents API »)"
    dec, raison = decision_shell(cmd)
    if dec == "deny":
        return None, raison
    if mode == "toutes":
        shell = (["powershell", "-NoProfile", "-NonInteractive", "-Command", cmd] if sys.platform == "win32"
                 else ["sh", "-c", cmd])
        return shell, ""
    if re.search(r"[&|;<>`\n\r]|\$\(", cmd):
        return None, "enchaînement ou redirection refusés en mode « sures » : une commande simple à la fois"
    try:
        args = [a.strip('"\'') for a in shlex.split(cmd, posix=sys.platform != "win32")]
    except ValueError:
        return None, "commande mal formée"
    prog = Path(args[0].replace("\\", "/")).name.lower()
    prog = re.sub(r"\.(exe|cmd|bat)$", "", prog)
    if prog not in SURES:
        return None, (f"« {prog} » n'est pas dans la liste des commandes sûres (tests, compilation, lint) ; "
                      "l'utilisateur peut choisir « toutes » dans Réglages › Commandes des agents API")
    for a in args[1:]:
        b = a.replace("\\", "/")
        if (b.startswith("/") and not re.fullmatch(r"/[A-Za-z?]{1,3}(:\S*)?", b) or re.search(r"(^|[=:])[A-Za-z]:[/]", b)
                or b.startswith("~") or re.search(r"(^|[=/])\.\.(/|$)", b)):
            return None, f"chemin hors du dossier de la tâche refusé : {a[:80]}"
    bas = [a.lower() for a in args[1:]]
    if prog == "git" and (not bas or bas[0] not in GIT_LECTURE):
        return None, "git : lecture seulement (status, diff, log, show…) en mode « sures »"
    if prog in ("npm", "pnpm", "yarn", "bun", "composer", "bundle", "cargo", "go", "dotnet") and bas and bas[0] in INSTALLATION:
        return None, "installation de paquets refusée : demande-la à l'utilisateur dans ton compte rendu"
    if "pip" in bas and any(x in INSTALLATION for x in bas):
        return None, "installation de paquets refusée : demande-la à l'utilisateur dans ton compte rendu"
    return args, ""


def _env_sans_secret() -> dict:
    return {k: v for k, v in os.environ.items() if not _SECRET_ENV.search(k)}


def _outils(lecture_seule: bool, capacites: list[str] | None = None, commandes: str = "non") -> list[dict]:
    def f(nom, desc, props, req):
        return {"type": "function", "function": {"name": nom, "description": desc,
                                                 "parameters": {"type": "object", "properties": props, "required": req}}}
    out = [f("lister", "Liste les fichiers et dossiers d'un dossier de l'espace (chemin relatif, « . » = racine).",
             {"chemin": {"type": "string"}}, ["chemin"]),
           f("lire", "Lit un fichier texte de l'espace (chemin relatif).", {"chemin": {"type": "string"}}, ["chemin"]),
           f("chercher", "Cherche un texte dans les fichiers de l'espace ; renvoie fichier:ligne: extrait.",
             {"texte": {"type": "string"}}, ["texte"])]
    if not lecture_seule:
        out.append(f("ecrire", "Crée ou remplace un fichier texte de l'espace (chemin relatif, contenu complet).",
                     {"chemin": {"type": "string"}, "contenu": {"type": "string"}}, ["chemin", "contenu"]))
        if "image" in (capacites or []):
            out.append(f("generer_image", "Génère une image PNG à partir d'une description détaillée et l'enregistre (chemin relatif .png).",
                         {"prompt": {"type": "string"}, "chemin": {"type": "string"}}, ["prompt", "chemin"]))
        if "voix" in (capacites or []):
            out.append(f("generer_voix", "Synthétise un texte en voix (fichier .mp3, chemin relatif).",
                         {"texte": {"type": "string"}, "chemin": {"type": "string"}}, ["texte", "chemin"]))
        if commandes != "non":
            desc = ("Lance une commande dans le dossier de la tâche (tests, compilation, lint) et renvoie sa sortie. "
                    + ("Une commande simple à la fois, sans &&, | ni redirection ; pas d'installation de paquets."
                       if commandes == "sures" else "Les commandes qui détruisent ou publient sont refusées."))
            out.append(f("commande", desc, {"commande": {"type": "string"}}, ["commande"]))
    return out


class ApiExecutor:
    name = "api"

    def __init__(self, data: Path, pour: str = "agents", lecture_seule: bool = False, studio=None):
        self.data = Path(data)
        self.pour = pour
        self.lecture_seule = lecture_seule
        self.studio = studio
        self._c: dict | None = None
        self._runner = None
        self._tid = ""
        self._commandes = "non"

    # -- fil d'activité (vue en direct) et journal des commandes de la tâche
    def _details(self) -> Path | None:
        dd = getattr(self._runner, "details_dir", None)
        if not dd or not self._tid:
            return None
        try:
            return dd(self._tid)
        except Exception:                                   # noqa: BLE001 — jamais bloquant
            return None

    def _noter(self, genre: str, texte: str) -> None:
        d = self._details()
        if d is None:
            return
        from ..security import redact
        try:
            with (d / "activite.log").open("a", encoding="utf-8") as h:
                h.write(f"{datetime.now().isoformat(timespec='seconds')}\t{genre}\t{redact(re.sub(r'[\t\r\n]+', ' ', texte))[:400]}\n")
        except OSError:
            pass

    def _noter_commande(self, dec: str, cmd: str) -> None:
        d = self._details()
        if d is None:
            return
        from ..security import redact
        try:
            with (d / "commandes.log").open("a", encoding="utf-8") as h:
                h.write(f"{datetime.now().isoformat(timespec='seconds')}  {dec:5}  {'Commande':10}  {redact(' '.join(cmd.split()))[:300]}\n")
        except OSError:
            pass

    def _connexion(self, propre: str = "") -> dict | None:
        from .. import ia
        d = ia.lire(self.data)
        ident = propre if any(x["id"] == propre for x in d["connexions"]) else (d.get(self.pour) or "")
        c = next((x for x in d["connexions"] if x["id"] == ident), None)
        return c or (d["connexions"][0] if d["connexions"] else None)

    def available(self) -> tuple[bool, str]:
        c = self._connexion()
        if not c:
            return False, "Aucune IA connectée (Accueil › Réglages › IA)."
        return True, f"{c['fournisseur']} · {c.get('modele') or '?'}"

    # -- outils, confinés à l'espace
    @staticmethod
    def _chemin(racine: Path, rel: str) -> Path:
        rel = (rel or ".").replace("\\", "/").strip()
        if rel.startswith("/") or re.match(r"^[A-Za-z]:", rel) or ".." in Path(rel).parts:
            raise ValueError("chemin hors de l'espace")
        p = (racine / rel).resolve()
        p.relative_to(racine.resolve())
        return p

    def _executer_outil(self, racine: Path, nom: str, args: dict, ecrits: list[str]) -> str:
        try:
            if nom == "lister":
                d = self._chemin(racine, args.get("chemin", "."))
                if not d.is_dir():
                    return "Dossier introuvable."
                noms = sorted((x.name + ("/" if x.is_dir() else "")) for x in d.iterdir() if x.name not in IGNORES)
                self._noter("liste", str(args.get("chemin", ".")))
                return "\n".join(noms[:500]) or "(vide)"
            if nom == "lire":
                p = self._chemin(racine, args.get("chemin", ""))
                if not p.is_file():
                    return "Fichier introuvable."
                t = p.read_text(encoding="utf-8", errors="replace")
                self._noter("lit", p.relative_to(racine.resolve()).as_posix())
                return t[:MAX_LECTURE] + ("\n… (tronqué)" if len(t) > MAX_LECTURE else "")
            if nom == "chercher":
                motif = str(args.get("texte", ""))[:200]
                if not motif:
                    return "Texte vide."
                self._noter("cherche", motif[:80])
                import os
                out, base = [], racine.resolve()
                fichiers = []
                for dossier, sous, noms in os.walk(racine, followlinks=False):     # jonctions et liens jamais suivis
                    sous[:] = [d for d in sous if d not in IGNORES and not Path(dossier, d).is_symlink()
                               and not getattr(Path(dossier, d), "is_junction", lambda: False)()]
                    fichiers += [Path(dossier, n) for n in noms]
                for p in fichiers:
                    if len(out) >= 200:
                        break
                    try:
                        if not p.is_file() or p.is_symlink() or p.stat().st_size > 2_000_000:
                            continue
                        p.resolve().relative_to(base)
                    except (OSError, ValueError):
                        continue
                    try:
                        for i, ligne in enumerate(p.read_text(encoding="utf-8", errors="ignore").splitlines(), 1):
                            if motif.lower() in ligne.lower():
                                out.append(f"{p.relative_to(racine).as_posix()}:{i}: {ligne.strip()[:200]}")
                    except OSError:
                        continue
                return "\n".join(out) or "Aucun résultat."
            if nom in ("generer_image", "generer_voix") and not self.lecture_seule and self._c is not None:
                from .. import ia
                ext = ".png" if nom == "generer_image" else ".mp3"
                rel = str(args.get("chemin", "")) or f"sortie{ext}"
                p = self._chemin(racine, rel if rel.lower().endswith(ext) else rel + ext)
                data = (ia.generer_image(self._c, str(args.get("prompt", ""))) if nom == "generer_image"
                        else ia.generer_voix(self._c, str(args.get("texte", ""))))
                p.parent.mkdir(parents=True, exist_ok=True)
                p.write_bytes(data)
                ecrits.append(p.relative_to(racine.resolve()).as_posix())
                self._noter("image" if nom == "generer_image" else "voix", ecrits[-1])
                return f"Fichier créé : {ecrits[-1]} ({len(data) // 1024} Ko)"
            if nom == "ecrire" and not self.lecture_seule:
                p = self._chemin(racine, args.get("chemin", ""))
                existait = p.exists()
                p.parent.mkdir(parents=True, exist_ok=True)
                p.write_text(str(args.get("contenu", "")), encoding="utf-8")
                ecrits.append(p.relative_to(racine.resolve()).as_posix())
                self._noter("fichier", f"{'modifie' if existait else 'crée'}  {p}")
                return f"Écrit : {ecrits[-1]}"
            if nom == "commande" and not self.lecture_seule:
                return self._commande(racine, str(args.get("commande", "")))
            return "Outil inconnu."
        except (ValueError, OSError) as e:
            return f"Refusé : {e}"
        except Cancelled:
            raise
        except Exception as e:                  # noqa: BLE001 — erreur du fournisseur : l'agent la voit et s'adapte
            return f"Échec : {e}"

    def _commande(self, racine: Path, cmd: str) -> str:
        from ..orchestrator.processes import run_process
        lancer, raison = verifier_commande(cmd, self._commandes)
        if lancer is None:
            self._noter("refus", cmd)
            self._noter_commande("deny", cmd)
            return f"Refusé : {raison}. Dis-le dans ton compte rendu, sans contourner."
        if self._runner is None:
            return "Refusé : commandes disponibles seulement dans une tâche du studio."
        if self._commandes == "sures":                     # npm, gradlew… : le programme réel (.cmd compris)
            vrai = shutil.which(lancer[0]) or (str(racine / lancer[0]) if (racine / lancer[0]).is_file() else None)
            if not vrai:
                self._noter_commande("allow", cmd)
                return f"Programme introuvable sur ce PC : {lancer[0]}"
            lancer = [vrai, *lancer[1:]]
        self._noter("commande", cmd)
        self._noter_commande("allow", cmd)
        r = run_process(self._runner.store, self._tid, lancer, racine, DELAI_COMMANDE_S, env=_env_sans_secret())
        sortie = ((r.stdout or "") + ("\n" + r.stderr if r.stderr else "")).strip()
        if len(sortie) > MAX_SORTIE:
            sortie = "… (début coupé)\n" + sortie[-MAX_SORTIE:]
        etat = {"delai_depasse": f"arrêtée après {DELAI_COMMANDE_S // 60} min", "introuvable": "programme introuvable"}.get(r.status)
        from ..security import redact
        return f"Code de sortie : {r.returncode}{' (' + etat + ')' if etat else ''}\n{redact(sortie) or '(aucune sortie)'}"

    def execute(self, mission: Mission, workdir: Path, runner) -> ExecResult:
        from .. import ia
        from ..orchestrator.processes import Cancelled
        c = self._connexion(mission.connexion)
        if not c:
            return ExecResult(False, "Aucune IA connectée.", self.name, error="aucune connexion")
        if mission.modele_api:
            c = {**c, "modele": mission.modele_api}
        self._c = c
        self._runner, self._tid = runner, mission.task_id
        self._commandes = "non" if self.lecture_seule or runner is None else mode_commandes(getattr(runner, "cfg", None))
        cmd_txt = {"non": "Pas de commande système. ",
                   "sures": "L'outil commande lance une commande simple (tests, compilation, lint) dans ce dossier. ",
                   "toutes": "L'outil commande lance une commande dans ce dossier (rien de destructif ni de publication). "}
        consigne = (mission.prompt() + "\n\n## Outils\nTu travailles avec les outils lister, lire, chercher"
                    + ("" if self.lecture_seule else ", ecrire") + ("" if self._commandes == "non" else ", commande")
                    + " dans le dossier courant de la tâche (chemins relatifs). " + cmd_txt[self._commandes]
                    + "Quand tu as fini, réponds sans appeler d'outil : ta réponse est ton compte rendu."
                    + (" Pour produire une image, appelle generer_image (prompt détaillé, en anglais de préférence)."
                       if "image" in mission.capacites and not self.lecture_seule else "")
                    + (" Pour produire une voix, appelle generer_voix." if "voix" in mission.capacites and not self.lecture_seule else ""))
        messages = [{"role": "system", "content": consigne}, {"role": "user", "content": "Exécute la mission."}]
        outils, ecrits, usage = _outils(self.lecture_seule, mission.capacites, self._commandes), [], {}
        self._noter("pense", f"{mission.role} · {c.get('modele') or c['fournisseur']}")
        for _ in range(MAX_TOURS):
            if runner is not None and runner.store.cancel_requested(mission.task_id):
                raise Cancelled("Tâche annulée.")
            try:
                r = ia.discuter(c, messages, outils)
            except ia.ErreurIA as e:
                texte = str(e)
                if "tool" in texte.lower():
                    texte += " — ce modèle ne sait pas utiliser d'outils : choisis-en un autre pour les agents."
                return ExecResult(False, texte, self.name, error=texte)
            for k, v in (r.get("usage") or {}).items():
                if isinstance(v, int):
                    usage[k] = usage.get(k, 0) + v
            m = r["message"]
            appels = m.get("tool_calls") or []
            messages.append({"role": "assistant", "content": m.get("content") or "", **({"tool_calls": appels} if appels else {})})
            if not appels:
                self._noter("fin", "")
                texte = m.get("content") or ""
                if isinstance(texte, list):
                    texte = "".join(b.get("text", "") for b in texte if isinstance(b, dict))
                return ExecResult(bool(texte.strip()), texte[:8000] or "Réponse vide.", self.name,
                                  raw={"usage": usage, "fichiers": ecrits, "modele": c.get("modele")})
            for a in appels:
                fn = a.get("function") or {}
                brut = fn.get("arguments") or "{}"
                try:
                    args = brut if isinstance(brut, dict) else json.loads(brut)
                except (TypeError, ValueError):
                    args = {}
                resultat = self._executer_outil(workdir, fn.get("name", ""), args if isinstance(args, dict) else {}, ecrits)
                messages.append({"role": "tool", "tool_call_id": a.get("id", ""), "content": resultat})
        return ExecResult(False, f"Trop d'étapes ({MAX_TOURS}) sans conclusion.", self.name, error="trop d'étapes",
                          raw={"usage": usage, "fichiers": ecrits})
