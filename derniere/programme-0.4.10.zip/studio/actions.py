"""Actions lancées d'un clic depuis l'interface : fusionner, compiler, tests, installation des modules de lecture,
rangement des espaces de travail. Rien ne part sans le clic de Mel ; chaque action vérifie ses conditions avant
d'écrire et s'arrête proprement sinon. Les travaux longs tournent en arrière-plan (un seul de chaque sorte à la fois).
"""
from __future__ import annotations

import json
import re
import os
import subprocess
import sys
import threading
import time
from datetime import datetime, timezone
from pathlib import Path

from .connectors import workspace as ws
from .connectors.base import SANS_FENETRE, sha256_file
from .orchestrator.store import TERMINAL
from .security import redact


def _maintenant() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


class Travaux:
    """Travaux d'arrière-plan visibles dans l'interface (état, durée, fin de la sortie)."""

    def __init__(self, controle=None):
        self._t: dict[str, dict] = {}
        self._garde = threading.Lock()
        self.controle = controle

    def etat(self) -> dict:
        with self._garde:
            return {k: dict(v) for k, v in self._t.items()}

    def lancer(self, nom: str, titre: str, cmd: list[str], cwd: Path, timeout_s: float = 3600,
               apres=None) -> dict:
        with self._garde:
            if self._t.get(nom, {}).get("etat") == "en_cours":
                raise RuntimeError(f"« {titre} » tourne déjà.")
            self._t[nom] = {"titre": titre, "etat": "en_cours", "debut": _maintenant(), "fin": "", "code": None,
                            "sortie": "", "commande": redact(" ".join(str(c) for c in cmd))[:300]}
        if self.controle:
            self.controle.debut()

        def run():
            sortie, code = "", None
            try:
                r = subprocess.run([str(c) for c in cmd], cwd=str(cwd), capture_output=True, text=True, encoding="utf-8",
                                   errors="replace", stdin=subprocess.DEVNULL, timeout=timeout_s, **SANS_FENETRE)
                sortie, code = (r.stdout or "") + (r.stderr or ""), r.returncode
            except subprocess.TimeoutExpired:
                sortie, code = "Délai dépassé : arrêté.", -1
            except OSError as e:
                sortie, code = f"Impossible de lancer : {e}", -1
            finally:
                with self._garde:
                    self._t[nom].update(etat="ok" if code == 0 else "echec", fin=_maintenant(), code=code,
                                        sortie=redact(sortie)[-20000:])
                if apres:
                    try:
                        apres(code, sortie)
                    except Exception:            # noqa: BLE001 — un rappel ne casse pas le travail
                        pass
                if self.controle:
                    self.controle.fin()
        threading.Thread(target=run, daemon=True).start()
        return self.etat()[nom]


# ------------------------------------------------------------------ fusion
def _tache_worktree(studio, tid: str):
    t = studio.store.get(tid)
    cible = studio.registry.get(t["target"])
    base = studio.details_dir(tid) / "base.json"
    info = json.loads(base.read_text(encoding="utf-8")) if base.exists() else {}
    if "_worktree" not in info:
        raise ValueError("Cette tâche n'a pas été faite dans un worktree : rien à fusionner.")
    return t, cible, info


OPERATIONS = ("MERGE_HEAD", "CHERRY_PICK_HEAD", "REVERT_HEAD", "rebase-merge", "rebase-apply", "sequencer", "BISECT_LOG")


def _operation_en_cours(git: str, depot: Path) -> str:
    """Fusion, rebase, cherry-pick… déjà commencés par Mel dans le dépôt (jamais touchés par le studio)."""
    for nom in OPERATIONS:
        p = Path(ws._git(git, depot, "rev-parse", "--path-format=absolute", "--git-path", nom).strip())
        if p.exists():
            return nom
    return ""


COMPTES_RENDUS = re.compile(r"(^|/)RESULTAT[^/]*\.md$", re.I)


def _regler_comptes_rendus(git: str, depot: Path) -> bool:
    """Fusion en conflit : si TOUS les fichiers en conflit sont des comptes rendus d'agent (RESULTAT*.md), ils sont
    retirés (git rm) et la fusion peut continuer ; sinon rien n'est touché (la fusion sera annulée)."""
    conflits = [l for l in ws._git(git, depot, "diff", "--name-only", "--diff-filter=U").splitlines() if l.strip()]
    if not conflits or not all(COMPTES_RENDUS.search(c) for c in conflits):
        return False
    ws._git(git, depot, "rm", "-q", "--", *conflits)
    return not ws._git(git, depot, "diff", "--name-only", "--diff-filter=U").strip()


def fusionner(studio, tid: str) -> dict:
    """Fusionne la branche studio/<tâche> dans la branche de départ, avec --no-ff et un message déjà rempli.
    Refuse si : la tâche n'est pas validée ; la branche ne correspond plus au commit validé ; le dépôt n'est pas sur
    la branche de départ (HEAD détaché compris) ; une fusion, un rebase… est déjà en cours ; des fichiers suivis sont
    modifiés (ton travail en cours n'est jamais mélangé). En cas de conflit, seule NOTRE fusion est annulée."""
    from .orchestrator.runner import titre_commit
    git = studio.cfg["outils"].get("git", "git")
    t, cible, info = _tache_worktree(studio, tid)
    if t["status"] not in ("approuvee", "appliquee"):
        raise ValueError("Valide d'abord la tâche : seule une tâche validée peut être fusionnée.")
    depot, branche = cible.path(), f"studio/{tid}"
    bj = studio.details_dir(tid) / "branche.json"
    valide = json.loads(bj.read_text(encoding="utf-8")) if bj.exists() else {}
    if not ws._git(git, depot, "branch", "--list", branche).strip():
        raise ValueError(f"Branche {branche} introuvable.")
    pointe = ws._git(git, depot, "rev-parse", branche).strip()
    if not valide.get("commit") or pointe != valide["commit"]:
        raise ValueError(f"La branche {branche} ne correspond pas au commit validé : rien n'est fusionné.")
    base = valide.get("base") or info.get("_worktree", "")
    if base and ws._git(git, depot, "rev-list", "--count", f"{base}..{branche}").strip() == "0":
        return {"etat": "vide", "message": "Aucun changement validé sur cette branche : rien à fusionner."}
    attendue = info.get("branche", "")
    if not attendue or attendue == "HEAD":
        raise ValueError("La tâche est partie d'un HEAD détaché : fusionne-la toi-même (voir BRANCHE.md).")
    if not ws._vrai(git, depot, "symbolic-ref", "-q", "HEAD"):
        raise ValueError("Le dépôt est en HEAD détaché : repasse sur ta branche puis réessaie.")
    courante = ws._git(git, depot, "rev-parse", "--abbrev-ref", "HEAD").strip()
    if courante != attendue:
        raise ValueError(f"Le dépôt est sur « {courante} », la tâche est partie de « {attendue} » : rien n'est fait.")
    op = _operation_en_cours(git, depot)
    if op:
        raise ValueError(f"Une opération git est déjà en cours dans le dépôt ({op}) : termine-la, puis réessaie.")
    if ws._vrai(git, depot, "merge-base", "--is-ancestor", branche, "HEAD"):
        return {"etat": "deja", "message": f"{branche} est déjà fusionnée dans {courante}."}
    sale = ws._git(git, depot, "status", "--porcelain", "--untracked-files=no").strip()
    if sale:
        raise ValueError("Le dépôt a des modifications non commitées ; commite-les ou mets-les de côté, puis réessaie : "
                         + ", ".join(l[3:] for l in sale.splitlines()[:5]))
    message = f"Fusion studio {tid} : {titre_commit(t.get('request') or '', 60)}"
    try:
        ws._git(git, depot, "merge", "--no-ff", "--no-verify", branche, "-m", message, timeout=900)
    except ws.WorktreeError as e:
        mh = Path(ws._git(git, depot, "rev-parse", "--path-format=absolute", "--git-path", "MERGE_HEAD").strip())
        notre = mh.exists() and mh.read_text(encoding="utf-8").split()[:1] == [pointe]
        regle = False
        if notre and _regler_comptes_rendus(git, depot):     # seul un compte rendu d'agent (RESULTAT.md) bloquait
            try:
                ws._git(git, depot, "commit", "--no-verify", "--no-edit", timeout=300)
                regle = not mh.exists()
            except ws.WorktreeError:
                regle = False
        if not regle:
            if notre:
                try:
                    ws._git(git, depot, "merge", "--abort")      # notre fusion seulement
                except ws.WorktreeError:
                    pass
                raise ValueError(f"Fusion impossible (conflit) : annulée, ton dépôt est comme avant. {e}") from None
            raise ValueError(f"Fusion refusée par git, rien n'a été fusionné : {e}") from None
        studio.store.event(tid, "Conflit sur un RESULTAT.md d'agent : laissé retiré du dépôt, fusion terminée")
    sha = ws._git(git, depot, "rev-parse", "--short", "HEAD").strip()
    studio.store.event(tid, f"Fusionnée dans {courante} ({sha})")
    (studio.details_dir(tid) / "fusion.json").write_text(json.dumps({"branche": courante, "commit": sha, "at": _maintenant()}),
                                                      encoding="utf-8")
    return {"etat": "ok", "message": f"Fusionnée dans {courante} : commit {sha}. Rien n'est poussé vers GitHub.", "commit": sha}


# ------------------------------------------------------------------ annuler une tâche déjà appliquée ou fusionnée
def annulable(studio, tid: str) -> dict:
    """Ce que « Annuler ce qui a été appliqué » ferait pour cette tâche (rien n'est fait ici)."""
    t = studio.store.get(tid)
    d = studio.details_dir(tid, creer=False)
    if (d / "annulation.json").exists():
        return {"possible": False, "mode": "", "texte": "Déjà annulée."}
    if (d / "fusion.json").exists():
        return {"possible": True, "mode": "fusion",
                "texte": "Un commit inverse (git revert) annule la fusion. L'historique est gardé, rien n'est poussé vers GitHub."}
    if t["status"] == "appliquee" and (d / "application.json").exists():
        return {"possible": True, "mode": "application",
                "texte": "Les fichiers du projet reviennent comme avant la tâche. Ce que la tâche avait ajouté ou changé est "
                         "mis de côté dans le dossier de la tâche (rien n'est effacé)."}
    return {"possible": False, "mode": "", "texte": ""}


def annuler_application(studio, tid: str) -> dict:
    """Défait une tâche appliquée (copie) ou fusionnée (worktree). Vérifie tout avant d'écrire ; refuse si le projet a
    changé depuis sur ces fichiers (ton travail n'est jamais écrasé)."""
    import shutil
    a = annulable(studio, tid)
    if not a["possible"]:
        raise ValueError(a["texte"] or "Rien à annuler pour cette tâche : elle n'a rien appliqué à ton projet.")
    d = studio.details_dir(tid)
    t = studio.store.get(tid)
    if a["mode"] == "fusion":
        git = studio.cfg["outils"].get("git", "git")
        cible = studio.registry.get(t["target"])
        depot = cible.path()
        fj = json.loads((d / "fusion.json").read_text(encoding="utf-8"))
        op = _operation_en_cours(git, depot)
        if op:
            raise ValueError(f"Une opération git est déjà en cours dans le dépôt ({op}) : termine-la, puis réessaie.")
        courante = ws._git(git, depot, "rev-parse", "--abbrev-ref", "HEAD").strip()
        if fj.get("branche") and courante != fj["branche"]:
            raise ValueError(f"Le dépôt est sur « {courante} », la fusion a été faite sur « {fj['branche']} » : rien n'est fait.")
        if ws._git(git, depot, "status", "--porcelain", "--untracked-files=no").strip():
            raise ValueError("Le dépôt a des modifications non commitées : commite-les ou mets-les de côté, puis réessaie.")
        sha = ws._git(git, depot, "rev-parse", fj["commit"]).strip()
        parents = ws._git(git, depot, "rev-list", "--parents", "-n", "1", sha).split()
        try:
            if len(parents) > 2:
                ws._git(git, depot, "revert", "--no-edit", "-m", "1", sha, timeout=600)
            else:
                ws._git(git, depot, "revert", "--no-edit", sha, timeout=600)
        except ws.WorktreeError as e:
            try:
                ws._git(git, depot, "revert", "--abort")
            except ws.WorktreeError:
                pass
            raise ValueError(f"Annulation impossible (conflit avec des changements faits depuis) : rien n'est modifié. {e}") from None
        nouveau = ws._git(git, depot, "rev-parse", "--short", "HEAD").strip()
        info = {"mode": "fusion", "commit_inverse": nouveau, "fusion": fj["commit"], "at": _maintenant()}
        message = f"Fusion annulée par un commit inverse ({nouveau}) sur {courante}. Rien n'est poussé vers GitHub."
    else:
        m = json.loads((d / "application.json").read_text(encoding="utf-8"))
        racine, avant = Path(m["cible"]), Path(m.get("sauvegarde") or d / "avant-application")
        change = [rel for rel, h in m["fichiers"].items()
                  if not (racine / rel).is_file() or sha256_file(racine / rel) != h]
        if change:
            raise ValueError("Ces fichiers ont changé dans ton projet depuis la tâche : rien n'est modifié. "
                             + ", ".join(change[:8]) + (f" (+{len(change) - 8})" if len(change) > 8 else ""))
        garde = d / "annulation"
        for rel in m["fichiers"]:                        # la version de la tâche est gardée, jamais effacée
            (garde / rel).parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(racine / rel, garde / rel)
        remis, retires = [], []
        for rel in m["fichiers"]:
            cible_f = racine / rel
            if (avant / rel).is_file():
                tmp = cible_f.with_name(f".studio-tmp-{cible_f.name}")
                shutil.copy2(avant / rel, tmp)
                os.replace(tmp, cible_f)
                remis.append(rel)
            else:
                cible_f.unlink()                             # sa copie est déjà dans annulation/
                retires.append(rel)
        info = {"mode": "application", "remis": remis, "retires": retires, "gardes": str(garde), "at": _maintenant()}
        message = (f"{len(remis)} fichier(s) remis comme avant" + (f", {len(retires)} ajouté(s) par la tâche mis de côté" if retires else "")
                   + f". Version de la tâche gardée dans {garde}.")
    (d / "annulation.json").write_text(json.dumps(info, ensure_ascii=False, indent=1), encoding="utf-8")
    studio.store.event(tid, "Annulée après coup : " + message)
    studio.store.set_status(tid, "annulee", "Annulée après application — " + message)
    return {"ok": True, "message": message}


# ------------------------------------------------------------------ compilation
def editeur_ouvert() -> bool:
    if sys.platform != "win32":
        return False
    try:
        r = subprocess.run(["tasklist", "/FI", "IMAGENAME eq UnrealEditor.exe", "/NH"], capture_output=True, text=True,
                           timeout=15, **SANS_FENETRE)
        return "UnrealEditor.exe" in (r.stdout or "")
    except (OSError, subprocess.TimeoutExpired):
        return False


def compiler(studio, travaux: Travaux, cle: str) -> dict:
    from .orchestrator.runner import Studio
    cible = studio.registry.get(cle)
    cmd = Studio._commande_build(cible, cible.path()) if cible.has_path else None
    if not cmd:
        raise ValueError("Pas de commande de compilation pour ce projet (« build » dans project.toml).")
    from . import unreal
    up = unreal.projet_unreal(cible.path()) or next(iter(sorted(cible.path().glob("*.uproject"))), None)
    if up and cible.extra.get("type") == "unreal":
        # Unreal : l'outil du studio ferme l'éditeur proprement (jamais de force), compile, puis le rouvre
        cmd = [python_console(), str(studio.paths.code / "scripts" / "outils" / "unreal_compiler.py"),
               "--uproject", str(up), "--rouvrir", str(up)]
    elif editeur_ouvert():
        raise ValueError("Unreal Editor est ouvert : ferme-le (en enregistrant) puis relance la compilation.")
    return travaux.lancer(f"compiler:{cible.kind}:{cible.id}", f"Compilation de {cible.nom}", cmd, cible.path(), 3600)


# ------------------------------------------------------------------ tests et installation
def python_console() -> str:
    """Le studio tourne sous pythonw.exe (sans console) : pip et pytest passent par python.exe à côté."""
    exe = Path(sys.executable)
    if exe.name.lower() == "pythonw.exe" and (exe.parent / "python.exe").exists():
        return str(exe.parent / "python.exe")
    return sys.executable


def lancer_tests(studio, travaux: Travaux) -> dict:
    return travaux.lancer("tests", "Tests du studio", [python_console(), "-X", "utf8", "-m", "pytest", "-q", "tests"],
                          studio.paths.code, 1800)


PAQUETS = {"lecture": ("Lecture des PDF et des images (~140 Mo)", ("PyMuPDF", "pillow")),
           "parole": ("Lecture des sons et vidéos (~550 Mo, + modèle ~480 Mo à la 1re pièce sonore)", ("faster-whisper", "av")),
           "retro": ("Outils de rétro-ingénierie (~25 Mo)", ("pefile", "capstone", "lief", "kaitaistruct"))}
VERROUS = {"retro": "requirements-retro.lock.txt"}          # sinon requirements-pieces.lock.txt
MODULES = {"lecture": (("pymupdf", "fitz"), ("PIL",)), "parole": (("faster_whisper",), ("av",)),
           "retro": (("pefile",), ("capstone",), ("lief",), ("kaitaistruct",))}      # chaque groupe : un des noms suffit


def installes() -> dict:
    """Modules optionnels déjà présents (sans les importer) : un bouton d'installation déjà utilisé disparaît."""
    import importlib
    import importlib.util
    importlib.invalidate_caches()                        # voit aussi ce qui vient d'être installé, sans redémarrer
    return {quoi: all(any(importlib.util.find_spec(n) for n in groupe) for groupe in groupes)
            for quoi, groupes in MODULES.items()}


def installer(studio, travaux: Travaux, quoi: str) -> dict:
    if quoi not in PAQUETS:
        raise ValueError("Installation inconnue.")
    if installes().get(quoi):
        raise ValueError("Déjà installé : rien à faire.")
    titre, noms = PAQUETS[quoi]
    lock = studio.paths.code / VERROUS.get(quoi, "requirements-pieces.lock.txt")
    figes = [l.strip() for l in lock.read_text(encoding="utf-8").splitlines() if l.strip() and not l.startswith("#")]
    paquets = [l for l in figes if l.split("==")[0].lower() in {n.lower() for n in noms}]
    if quoi == "parole":
        paquets = [l for l in figes if l.split("==")[0].lower() in {"pymupdf", "pillow"}] + paquets   # images du son
    return travaux.lancer(f"installer:{quoi}", titre, [python_console(), "-m", "pip", "install", "--disable-pip-version-check",
                                                        *paquets], studio.paths.code, 1800)


# ------------------------------------------------------------------ rangement des espaces de travail
def _taille(d: Path) -> int:
    total = 0
    for racine, _, fichiers in os.walk(d):
        for f in fichiers:
            try:
                total += os.path.getsize(os.path.join(racine, f))
            except OSError:
                pass
    return total


def _base(studio, tid: str) -> str:
    try:
        return json.loads((studio.details_dir(tid) / "base.json").read_text(encoding="utf-8")).get("_worktree", "")
    except (OSError, ValueError):
        return ""


def espaces(studio) -> list[dict]:
    """Espaces de travail (worktrees) des tâches, avec taille, état de la tâche et fusion."""
    git = studio.cfg["outils"].get("git", "git")
    runs = studio.paths.runs.resolve()
    out = []
    for cible in studio.registry.all():
        if cible.kind != "project" or cible.extra.get("isolation") != "worktree" or not cible.has_path or not cible.path().is_dir():
            continue
        try:
            liste = ws._git(git, cible.path(), "worktree", "list", "--porcelain")
        except ws.WorktreeError:
            continue
        for bloc in liste.strip().split("\n\n"):
            champs = dict(l.split(" ", 1) for l in bloc.splitlines() if " " in l)
            chemin = Path(champs.get("worktree", ""))
            try:
                rel = chemin.resolve().relative_to(runs)
            except (ValueError, OSError):
                continue                             # pas un espace du studio (ton dossier, ou un autre outil)
            tid = studio.tache_du_dossier(rel.parts[0]) if rel.parts else ""
            try:
                statut = studio.store.get(tid)["status"]
            except KeyError:
                statut = "inconnue"
            if any(o["chemin"] == str(chemin) for o in out):
                continue                             # deux cibles sur le même dépôt : une seule ligne
            branche = f"studio/{tid}"
            base = _base(studio, tid)
            a_du_contenu = bool(base) and ws._vrai(git, cible.path(), "rev-parse", "--verify", "-q", branche) and \
                ws._git(git, cible.path(), "rev-list", "--count", f"{base}..{branche}").strip() != "0"
            fusionnee = a_du_contenu and ws._vrai(git, cible.path(), "merge-base", "--is-ancestor", branche, "HEAD")
            copies = [p for p in studio.details_dir(tid, creer=False).glob("relecture-*") if p.is_dir()] if tid else []
            out.append({"tache": tid, "projet": cible.nom, "chemin": str(chemin), "statut": statut, "fusionnee": fusionnee,
                        "vide": not a_du_contenu,
                        "octets": (_taille(chemin) if chemin.is_dir() else 0) + sum(_taille(p) for p in copies),
                        "retirable": statut in TERMINAL})
    return out


def retirer_espace(studio, tid: str) -> dict:
    """Retire l'espace de travail d'une tâche terminée (après le clic de Mel). Le travail validé est déjà dans sa
    branche ; la branche n'est supprimée que si elle est fusionnée (git branch -d, jamais -D). Le dossier Taches\\<tâche>
    (résultat, diff, journal) est conservé."""
    git = studio.cfg["outils"].get("git", "git")
    t = studio.store.get(tid)
    if t["status"] not in TERMINAL:
        raise ValueError("La tâche n'est pas terminée : son espace reste.")
    cible = studio.registry.get(t["target"])
    espace = studio.run_dir(tid) / ws.ESPACE
    if not (espace / ".git").is_file():
        raise ValueError("Pas d'espace de travail git pour cette tâche.")
    if t["status"] in ("approuvee", "appliquee"):
        restes = [l[3:] for l in ws._git(git, espace, "status", "--porcelain", "--untracked-files=all").splitlines()
                  if l.strip() and not ws._skipped(l[3:].strip('"'), [])
                  and not l[3:].startswith(".agents/skills/")]
        if restes:
            raise ValueError("L'espace contient des fichiers qui ne sont pas dans la branche validée : rien n'est retiré ("
                             + ", ".join(restes[:5]) + ").")
        bj = studio.details_dir(tid) / "branche.json"
        valide = json.loads(bj.read_text(encoding="utf-8")).get("commit", "") if bj.exists() else ""
        if valide and not ws._vrai(git, cible.path(), "merge-base", "--is-ancestor", valide, f"studio/{tid}"):
            raise ValueError("Le commit validé n'est plus sur la branche de la tâche : rien n'est retiré.")
    ws._git(git, cible.path(), "worktree", "remove", "--force", str(espace), timeout=600)
    import shutil
    for copie in studio.details_dir(tid).glob("relecture-*"):
        if copie.is_dir():
            shutil.rmtree(copie, ignore_errors=True)     # copies jetables de l'auditeur, recréables
    (studio.run_dir(tid) / ws.MARQUE_PRET).unlink(missing_ok=True)
    msg = "Espace retiré."
    base = _base(studio, tid)
    contenu = bool(base) and ws._git(git, cible.path(), "rev-list", "--count", f"{base}..studio/{tid}").strip() != "0"
    fusionnee = contenu and ws._vrai(git, cible.path(), "merge-base", "--is-ancestor", f"studio/{tid}", "HEAD")
    if fusionnee or not contenu:
        try:
            ws._git(git, cible.path(), "branch", "-d", f"studio/{tid}")
            msg += f" Branche studio/{tid} supprimée ({'déjà fusionnée' if fusionnee else 'vide'})."
        except ws.WorktreeError:
            msg += f" Branche studio/{tid} conservée."
    else:
        msg += f" Branche studio/{tid} conservée (pas fusionnée)."
    studio.store.event(tid, msg + " (par Mel depuis l'interface)")
    return {"etat": "ok", "message": msg}


# ------------------------------------------------------------------ versions de Claude Code et Codex, mise à jour
PAQUETS_NPM = {"claude": "@anthropic-ai/claude-code", "codex": "@openai/codex"}
_dernieres: dict[str, tuple[float, str]] = {}


def derniere_version(outil: str) -> str:
    """Dernière version publiée (registre npm, lecture publique, rien n'est envoyé) ; gardée une heure ; vide hors ligne."""
    import json as _json
    import urllib.request
    paquet = PAQUETS_NPM[outil]
    t, v = _dernieres.get(outil, (0.0, ""))
    if time.time() - t < 3600:
        return v
    v = ""
    for _ in range(2):                             # un échec passager ne laisse pas « inconnue » pendant une heure
        try:
            req = urllib.request.Request(f"https://registry.npmjs.org/{paquet}/latest", headers={"User-Agent": "SuperAIStudio"})
            with urllib.request.urlopen(req, timeout=12) as r:
                v = str(_json.loads(r.read().decode("utf-8")).get("version", ""))
            break
        except Exception:                          # noqa: BLE001 — hors ligne ou registre indisponible : pas d'info
            v = ""
    if v:
        _dernieres[outil] = (time.time(), v)
    return v


def version_ollama() -> dict:
    """Ollama : version installée (API locale, sinon commande) et dernière publiée (GitHub). Lecture seule."""
    import json as _json
    import shutil
    import urllib.request
    from .modeles_locaux import OLLAMA, executable_ollama
    inst = ""
    try:
        with urllib.request.urlopen(OLLAMA + "/api/version", timeout=2) as r:
            inst = str(_json.loads(r.read()).get("version", ""))
    except Exception:                              # noqa: BLE001 — fermé : on lit la version de la commande
        exe = executable_ollama()
        if exe:
            try:
                out = subprocess.run([exe, "--version"], capture_output=True, text=True, timeout=20, stdin=subprocess.DEVNULL, **SANS_FENETRE)
                m = re.search(r"(\d+\.\d+\.\d+)", out.stdout + out.stderr)
                inst = m.group(1) if m else ""
            except (OSError, subprocess.TimeoutExpired):
                pass
    t, dern = _dernieres.get("ollama", (0.0, ""))
    if time.time() - t > 3600:
        try:
            req = urllib.request.Request("https://api.github.com/repos/ollama/ollama/releases/latest", headers={"User-Agent": "SuperAIStudio"})
            with urllib.request.urlopen(req, timeout=12) as r:
                dern = str(_json.loads(r.read()).get("tag_name", "")).lstrip("v")
            if dern:
                _dernieres["ollama"] = (time.time(), dern)
        except Exception:                          # noqa: BLE001
            dern = ""
    a_jour = None
    if inst and dern:
        a_jour = tuple(int(x) for x in re.findall(r"\d+", inst)[:3]) >= tuple(int(x) for x in re.findall(r"\d+", dern)[:3])
    winget = shutil.which("winget")
    return {"nom": "Ollama (modèles locaux)", "chemin": executable_ollama() or "", "installee": inst, "derniere": dern, "a_jour": a_jour,
            "methode": "Ollama se met à jour seul (icône Ollama › Restart to update)" + (" ou : winget upgrade --id Ollama.Ollama -e" if winget else ""),
            "possible": False}


def _version_installee(exe: str | None) -> str:
    from .connectors.claude_code import parse_version
    if not exe:
        return ""
    try:
        out = subprocess.run([exe, "--version"], capture_output=True, text=True, timeout=30, encoding="utf-8",
                             errors="replace", stdin=subprocess.DEVNULL, **SANS_FENETRE)
        return ".".join(map(str, parse_version(out.stdout or out.stderr)))
    except (OSError, subprocess.TimeoutExpired):
        return ""


def _commande_maj(outil: str, exe: str | None) -> tuple[list[str] | None, str]:
    """Comment mettre à jour l'outil tel qu'il est installé sur ce PC (sans jamais deviner au hasard)."""
    import shutil
    if not exe:
        return None, "introuvable"
    bas = exe.replace("\\", "/").lower()
    if outil == "claude":
        return [exe, "update"], "claude update"
    if "/openai/codex/bin/" in bas:
        return None, "mis à jour par l'application Codex (ouvre-la : elle se met à jour seule)"
    npm = shutil.which("npm")
    if npm and ("/npm/" in bas or bas.endswith(".cmd")):
        return [npm, "install", "-g", f"{PAQUETS_NPM['codex']}@latest"], "npm install -g @openai/codex@latest"
    return None, "installation non reconnue : mets Codex à jour comme tu l'as installé"


def versions(studio) -> dict:
    from .connectors.base import find_exe
    from .connectors.claude_code import WIN_CANDIDATES as CC
    from .connectors.codex import WIN_CANDIDATES as CX
    out = {}
    for outil, cand, nom in (("claude", CC, "Claude Code"), ("codex", CX, "Codex")):
        exe = find_exe(studio.cfg["outils"].get(outil, outil), cand)
        inst, dern = _version_installee(exe), derniere_version(outil)
        cmd, methode = _commande_maj(outil, exe)
        a_jour = None
        if inst and dern:
            a_jour = tuple(int(x) for x in inst.split(".")) >= tuple(int(x) for x in re.findall(r"\d+", dern)[:3])
        out[outil] = {"nom": nom, "chemin": exe or "", "installee": inst, "derniere": dern, "a_jour": a_jour,
                      "methode": methode, "possible": bool(cmd)}
    o = version_ollama()
    if o["installee"] or o["chemin"]:                 # affiché seulement si Ollama est sur le PC
        out["ollama"] = o
    return out


def mettre_a_jour(studio, travaux: Travaux, outil: str) -> dict:
    """Met à jour Claude Code ou Codex en arrière-plan. Refusé pendant qu'une tâche tourne (l'outil serait remplacé
    en plein travail). Les alias de modèles (opus, sonnet, haiku) suivent automatiquement les nouveaux modèles."""
    from .connectors.base import find_exe
    from .connectors.claude_code import WIN_CANDIDATES as CC
    from .connectors.codex import WIN_CANDIDATES as CX
    if outil not in PAQUETS_NPM:
        raise ValueError("Outil inconnu.")
    with studio.store.db() as c:                  # créneaux occupés = agents réellement au travail (corrections comprises)
        from .orchestrator.store import pid_alive         # un créneau laissé par un processus disparu ne bloque pas
        occupes = sum(1 for r in c.execute("SELECT pid FROM slots WHERE task_id IS NOT NULL") if pid_alive(r[0]))
    actives = [t for t in studio.store.list(200) if t["status"] in ("creee", "en_cours", "en_attente_creneau")]
    if occupes or actives:
        raise RuntimeError(f"{max(occupes, len(actives))} tâche(s) en cours : attends qu'elles finissent avant de mettre à jour.")
    exe = find_exe(studio.cfg["outils"].get(outil, outil), CC if outil == "claude" else CX)
    cmd, methode = _commande_maj(outil, exe)
    if not cmd:
        raise ValueError(f"Mise à jour automatique impossible : {methode}.")

    def apres(code, sortie):                       # la nouvelle version est relue au prochain appel
        for ex in list(getattr(studio, "executors", {}).values()) + list(getattr(studio, "auditors", {}).values()):
            for attr in ("_version", "_effort"):
                if hasattr(ex, attr):
                    setattr(ex, attr, None)
        _dernieres.pop(outil, None)
    nom = "Claude Code" if outil == "claude" else "Codex"
    return travaux.lancer(f"maj:{outil}", f"Mise à jour de {nom}", cmd, studio.paths.code, 900, apres=apres)
