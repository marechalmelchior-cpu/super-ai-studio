/* Assistant de premier lancement : prénom → dossier → packs → outils trouvés → création, puis ouverture du studio. */
const $ = (s) => document.querySelector(s);
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
async function api(path, body) {
  const opt = body === undefined ? {} : { method: "POST", headers: { "Content-Type": "application/json", "X-Studio": "1" }, body: JSON.stringify(body) };
  const r = await fetch(path, opt);
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.erreur || r.status);
  return j;
}
let etape = 1, infos = { packs: [], outils: [] }, cible = "";
function montrer(n) {
  etape = n;
  document.querySelectorAll("section[data-etape]").forEach((s) => (s.hidden = +s.dataset.etape !== n));
  document.querySelectorAll(".etapes span").forEach((s, i) => s.classList.toggle("fait", i < n));
  const champ = document.querySelector(`section[data-etape="${n}"] input[type=text]`);
  if (champ) champ.focus();
}
document.addEventListener("click", (e) => {
  if (e.target.closest("[data-retour]")) montrer(etape - 1);
  if (e.target.closest("[data-suivant]")) suivant();
});
document.addEventListener("keydown", (e) => { if (e.key === "Enter" && e.target.matches("input[type=text]")) suivant(); });
async function suivant() {
  if (etape === 1) {
    if (!$("#nom").value.trim()) { $("#nom").focus(); return; }
    return montrer(2), verifier();
  }
  if (etape === 2) {
    const v = await verifier();
    if (v && v.ok) montrer(v.rejoindre ? 4 : 3);
    return;
  }
  if (etape === 3) return montrer(4);
}
let minuterie = 0;
async function verifier() {
  const d = $("#dossier").value.trim();
  try {
    const v = await api("/api/verifier", { dossier: d });
    cible = v.cible || d;
    $("#info-dossier").textContent = v.info || "";
    $("#info-dossier").className = "info " + (v.ok ? "ok" : "warn");
    $("#ok-dossier").disabled = !v.ok;
    $("#creer").textContent = v.rejoindre ? "Reprendre ce studio" : "Créer mon studio";
    return v;
  } catch (e) { $("#info-dossier").textContent = e.message; $("#info-dossier").className = "info warn"; }
}
$("#dossier").addEventListener("input", () => { clearTimeout(minuterie); minuterie = setTimeout(verifier, 300); });
$("#parcourir").onclick = async () => {
  $("#parcourir").disabled = true;
  try { const r = await api("/api/parcourir", { dossier: $("#dossier").value }); if (r.dossier) { $("#dossier").value = r.dossier; verifier(); } }
  finally { $("#parcourir").disabled = false; }
};
$("#creer").onclick = async () => {
  $("#creer").disabled = true; $("#info-creer").textContent = "Création…"; $("#info-creer").className = "info";
  const packs = [...document.querySelectorAll("#packs input:checked")].map((x) => x.value);
  try {
    const r = await api("/api/creer", { nom: $("#nom").value.trim(), dossier: $("#dossier").value.trim(), packs });
    montrer(5);
    $("#titre-fin").textContent = r.rejoint ? "Studio repris" : `Ton studio est prêt, ${$("#nom").value.trim()}`;
    $("#texte-fin").textContent = `${r.racine} — ouverture du studio…`;
    ouvrirStudio(r.suite);
  } catch (e) { $("#info-creer").textContent = e.message; $("#info-creer").className = "info warn"; $("#creer").disabled = false; }
};
async function ouvrirStudio(suite) {                  // le studio démarre sur le même port : on attend qu'il réponde
  for (let i = 0; i < 120; i++) {
    await new Promise((r) => setTimeout(r, 1000));
    try { const p = await (await fetch("/api/ping", { cache: "no-store" })).json(); if (p.studio) { location.href = suite; return; } } catch { /* pas encore */ }
  }
  $("#texte-fin").textContent = "Le studio tarde à démarrer : relance-le depuis son icône.";
}
(async () => {
  try {
    infos = await api("/api/infos");
    $("#dossier").value = infos.dossier;
    $("#packs").innerHTML = infos.packs.map((p) => `<label class="pack"><input type="checkbox" value="${esc(p.id)}"><span><b>${esc(p.nom)}</b><small>${esc(p.description)}</small></span></label>`).join("");
    $("#outils").innerHTML = infos.outils.map((o) => `<div class="outil"><span>${esc(o.nom)}</span><span class="${o.present ? "oui" : "non"}">${esc(o.detail)}</span></div>`).join("");
  } catch (e) { $("#outils").textContent = e.message; }
  montrer(1);
})();
setInterval(() => api("/api/presence", {}).catch(() => {}), 20000);
