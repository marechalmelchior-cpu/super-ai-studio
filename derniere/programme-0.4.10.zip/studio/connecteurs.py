"""Connecteurs : logiciels du PC que les agents peuvent utiliser (Blender, Unreal Editor, Krita, ffmpeg…).

Vide à la base : chacun ajoute les siens (Accueil › Réglages › Connecteurs). Blender et Unreal gardent leur place dans
studio.config.toml ([outils]) parce que des fonctions du studio s'en servent ; les autres vont dans
data/connecteurs.json. Seuls le nom et le chemin sont transmis aux agents.
"""
from __future__ import annotations

import json
import re
import secrets
from pathlib import Path

TYPES = {"blender": ("Blender", "outils", "blender"), "unreal": ("Unreal Editor (UnrealEditor-Cmd.exe)", "outils", "unreal_editor_cmd")}
SUGGESTIONS = ["Blender", "Unreal Editor", "Godot", "Unity", "Krita", "GIMP", "Inkscape", "ffmpeg", "Audacity", "OBS Studio",
               "DaVinci Resolve", "Visual Studio Code", "Node.js", "Docker"]


def _fichier(studio) -> Path:
    return studio.paths.data / "connecteurs.json"


def _perso(studio) -> list[dict]:
    try:
        l = json.loads(_fichier(studio).read_text(encoding="utf-8"))
        return [c for c in l if isinstance(c, dict) and c.get("id") and c.get("nom")]
    except (OSError, ValueError):
        return []


def lister(studio) -> list[dict]:
    out = []
    for t, (nom, section, cle) in TYPES.items():
        chemin = str(studio.cfg.get(section, {}).get(cle, "") or "")
        if chemin:
            out.append({"id": t, "nom": nom, "chemin": chemin, "type": t, "ok": Path(chemin).exists()})
    for c in _perso(studio):
        out.append({**c, "type": "autre", "ok": Path(c.get("chemin", "")).exists()})
    return out


def _valider_chemin(chemin: str) -> str:
    chemin = (chemin or "").strip().strip('"')
    if not chemin or "\n" in chemin or "'" in chemin or len(chemin) > 400:
        raise ValueError("Indique le chemin complet du programme (ex. C:\\Program Files\\Krita\\bin\\krita.exe).")
    if not (re.match(r"^[A-Za-z]:[\\/]", chemin) or chemin.startswith("/")):
        raise ValueError("Chemin complet attendu (ex. C:\\…\\programme.exe).")
    return chemin


def ajouter(studio, nom: str, chemin: str) -> list[dict]:
    from . import reglages
    nom = re.sub(r"[\r\n]", " ", (nom or "").strip())[:60]
    if not nom:
        raise ValueError("Donne un nom au connecteur.")
    chemin = _valider_chemin(chemin)
    bas = nom.lower()
    t = "blender" if "blender" in bas else "unreal" if "unreal" in bas else ""
    if t:
        _, section, cle = TYPES[t]
        reglages.ecrire(studio.paths.config_file, section, cle, chemin)
        studio.cfg.setdefault(section, {})[cle] = chemin
    else:
        l = _perso(studio)
        l.append({"id": f"c-{secrets.token_hex(3)}", "nom": nom, "chemin": chemin})
        _fichier(studio).write_text(json.dumps(l, ensure_ascii=False, indent=1), encoding="utf-8")
    return lister(studio)


def retirer(studio, ident: str) -> list[dict]:
    from . import reglages
    if ident in TYPES:
        _, section, cle = TYPES[ident]
        reglages.ecrire(studio.paths.config_file, section, cle, "")
        studio.cfg.setdefault(section, {})[cle] = ""
    else:
        _fichier(studio).write_text(json.dumps([c for c in _perso(studio) if c["id"] != ident], ensure_ascii=False, indent=1),
                                    encoding="utf-8")
    return lister(studio)


def pour_agents(studio) -> str:
    """Note de mission : logiciels déclarés (nom et chemin seulement)."""
    l = [c for c in lister(studio) if c["type"] == "autre" and c["ok"]]
    return ("Logiciels du PC déclarés par Mel (utilisables si ton outil le permet, sinon cite-les dans le compte rendu) : "
            + " ; ".join(f"{c['nom']} ({c['chemin']})" for c in l)) if l else ""
