"""Chaînes de tâches : plusieurs étapes (un rôle + une demande chacune) sur une même cible, lancées l'une après l'autre.

Chaque étape est une tâche ordinaire : elle attend la validation de Mel. Si le projet travaille en branche (worktree),
l'étape suivante attend aussi la fusion ; si le projet s'applique à la main, elle attend que Mel confirme l'application
(« Continuer ») — elle part toujours du travail validé, avec le compte rendu de l'étape précédente. Une étape annulée ou en échec met la chaîne en
pause : Mel la reprend (l'étape est relancée) ou l'arrête. Rien ne part sans un clic de Mel au départ, et chaque étape
reste soumise à sa validation.
"""
from __future__ import annotations

import threading
import uuid
from datetime import datetime

_verrou = threading.Lock()
MAX_ETAPES = 8


def creer(studio, cible: str, titre: str, etapes: list[dict], options: dict | None = None) -> tuple[str, str]:
    """Enregistre la chaîne et crée la tâche de la 1re étape (à lancer par l'appelant). Retourne (chaîne, tâche)."""
    propres = []
    for e in etapes or []:
        demande = str((e or {}).get("demande", "")).strip()
        role = str((e or {}).get("role", "")).strip()
        if not demande:
            continue
        if role and (role not in studio.roles or role == "auditeur"):
            raise ValueError(f"Rôle inconnu pour une étape : {role}")
        propres.append({"role": role, "demande": demande[:4000]})
    if len(propres) < 2:
        raise ValueError("Une chaîne demande au moins deux étapes.")
    if len(propres) > MAX_ETAPES:
        raise ValueError(f"{MAX_ETAPES} étapes au plus par chaîne.")
    t = studio.registry.get(cible)
    cible = f"{t.kind}:{t.id}"
    titre = (str(titre or "").strip() or propres[0]["demande"].splitlines()[0])[:120]
    opts = {k: v for k, v in (options or {}).items() if k in ("modele", "mode", "effort", "pieces") and v}   # pièces : 1re étape
    cid = "C" + datetime.now().strftime("%Y%m%d-%H%M%S-") + uuid.uuid4().hex[:4]
    studio.store.creer_chaine(cid, cible, titre, propres, opts)
    return cid, _lancer_etape(studio, cid, 0, "")


def _lancer_etape(studio, cid: str, i: int, precedent: str) -> str:
    ch = studio.store.chaine(cid)
    e = ch["etapes"][i]
    texte = (e["demande"] + f"\n\n---\nÉtape {i + 1}/{len(ch['etapes'])} de la chaîne « {ch['titre']} »."
             + (f"\nÉtape précédente, validée par Mel :\n{precedent}" if precedent else ""))
    opts = {**{k: v for k, v in ch["options"].items() if k != "pieces" or i == 0}, "chaine": cid, "etape": i,
            **({"role": e["role"]} if e["role"] else {})}
    tid = studio.create(ch["cible"], texte, **opts)
    ch["etapes"][i]["tache"] = tid
    ch["etapes"][i]["contexte"] = precedent              # gardé : une reprise de l'étape repart avec le même contexte
    studio.store.maj_chaine(cid, etapes=ch["etapes"], courant=i, statut="en_cours", note="")
    studio.store.event(tid, f"Chaîne {cid} — étape {i + 1}/{len(ch['etapes'])}")
    return tid


def _compte_rendu(studio, tid: str) -> str:
    """Ce que l'étape a vraiment produit : résumé de l'exécutant (dernière tentative) et fichiers touchés."""
    import json
    import re
    t = studio.store.get(tid)
    rd = studio.details_dir(tid)
    resume = ""
    execs = sorted(rd.glob("execution-*.json"), key=lambda p: int(re.sub(r"\D", "", p.stem) or 0))
    if execs:
        try:
            resume = json.loads(execs[-1].read_text(encoding="utf-8")).get("summary", "")
        except (OSError, ValueError):
            resume = ""
    fichiers = []
    try:
        fichiers = [a.get("path") or a.get("chemin") or "" for a in studio.store.artifacts(tid)][:30]
    except Exception:                              # noqa: BLE001 — facultatif
        fichiers = []
    role = studio.roles.get((t.get("options") or {}).get("role", ""))
    lignes = [f"- Rôle : {role.nom if role else 'choisi par le studio'} ; tâche {tid} ; statut : {t['status']}"]
    if any(fichiers):
        lignes.append("- Fichiers produits ou modifiés : " + ", ".join(f for f in fichiers if f))
    lignes.append("- Compte rendu de l'exécutant :\n" + (" ".join(resume.split())[:2500] or "(vide)"))
    return "\n".join(lignes)


def _suivante(studio, ch: dict, tid: str) -> str | None:
    """Étape courante validée et son travail en place : lance la suivante, ou termine la chaîne."""
    suivante = ch["courant"] + 1
    if suivante >= len(ch["etapes"]):
        studio.store.maj_chaine(ch["id"], statut="terminee", note="")
        return None
    return _lancer_etape(studio, ch["id"], suivante, _compte_rendu(studio, tid))


def avancer(studio, tid: str) -> str | None:
    """Après une décision, une annulation, une reprise ou une fusion : crée la tâche de l'étape suivante si tout est
    prêt. Retourne son identifiant (à lancer par l'appelant), sinon None. Sans effet hors chaîne ou appelé deux fois."""
    t = studio.store.get(tid)
    o = t.get("options") or {}
    cid = o.get("chaine")
    if not cid:
        return None
    with _verrou:
        ch = studio.store.chaine(cid)
        if not ch or ch["statut"] in ("terminee", "arretee") or ch["courant"] != o.get("etape"):
            return None
        statut = t["status"]
        if statut in ("annulee", "echec"):
            studio.store.maj_chaine(cid, statut="en_pause", note=f"Étape {ch['courant'] + 1} {'annulée' if statut == 'annulee' else 'en échec'} : relance-la ou arrête la chaîne.")
            return None
        if statut not in ("approuvee", "appliquee"):
            return None
        if (studio.details_dir(tid) / "rien-a-appliquer.json").exists():    # compte rendu sans fichier : rien à fusionner
            return _suivante(studio, ch, tid)
        infos = studio._infos_branche(tid, t)
        if infos.get("worktree") and not infos.get("fusion"):
            studio.store.maj_chaine(cid, statut="attente_fusion",
                                    note="Fusionne cette étape : la suivante partira de son travail. Rien à fusionner, ou fusionnée par toi-même ? Clique « Continuer ».")
            return None
        if not infos.get("worktree") and statut == "approuvee" and studio.registry.get(ch["cible"]).has_path:
            studio.store.maj_chaine(cid, statut="attente_application",
                                    note="Ce projet s'applique à la main : applique le résultat de cette étape dans le projet, puis clique « Continuer ».")
            return None
        return _suivante(studio, ch, tid)


def continuer(studio, cid: str) -> str | None:
    """Mel confirme que le travail de l'étape courante est en place (fusionné, appliqué, ou rien à reporter)."""
    with _verrou:
        ch = studio.store.chaine(cid)
        if not ch:
            raise KeyError(f"Chaîne inconnue : {cid}")
        if ch["statut"] not in ("en_cours", "attente_fusion", "attente_application"):
            raise RuntimeError("Cette chaîne ne peut pas continuer (en pause, terminée ou arrêtée).")
        tid = ch["etapes"][ch["courant"]].get("tache", "")
        if not tid or studio.store.get(tid)["status"] not in ("approuvee", "appliquee"):
            raise RuntimeError(f"Valide d'abord l'étape {ch['courant'] + 1}.")
        return _suivante(studio, ch, tid)


def reprendre(studio, cid: str) -> str:
    """Chaîne en pause : relance l'étape courante (nouvelle tâche, même demande, même contexte)."""
    with _verrou:
        ch = studio.store.chaine(cid)
        if not ch:
            raise KeyError(f"Chaîne inconnue : {cid}")
        if ch["statut"] != "en_pause":
            raise RuntimeError("Cette chaîne n'est pas en pause.")
        return _lancer_etape(studio, cid, ch["courant"], ch["etapes"][ch["courant"]].get("contexte", ""))


def arreter(studio, cid: str) -> None:
    with _verrou:                                         # jamais écrasé par une étape suivante en train de partir
        if not studio.store.chaine(cid):
            raise KeyError(f"Chaîne inconnue : {cid}")
        studio.store.maj_chaine(cid, statut="arretee", note="Arrêtée par Mel.")


def resume(studio, cid: str) -> dict | None:
    """Pour l'interface : titre, statut, étapes (rôle lisible, demande, tâche, état)."""
    ch = studio.store.chaine(cid)
    if not ch:
        return None
    etapes = []
    for e in ch["etapes"]:
        r = studio.roles.get(e["role"])
        etat = ""
        if e.get("tache"):
            try:
                etat = studio.store.get(e["tache"])["status"]
            except KeyError:
                etat = ""
        etapes.append({"role": e["role"], "nom_role": r.nom if r else "choisi par le studio", "demande": e["demande"],
                       "tache": e.get("tache", ""), "etat": etat})
    courante = etapes[ch["courant"]] if ch["courant"] < len(etapes) else {}
    return {"id": ch["id"], "titre": ch["titre"], "statut": ch["statut"], "courant": ch["courant"], "note": ch["note"],
            "etapes": etapes, "peut_continuer": ch["statut"] in ("en_cours", "attente_fusion", "attente_application")
            and courante.get("etat") in ("approuvee", "appliquee")}
