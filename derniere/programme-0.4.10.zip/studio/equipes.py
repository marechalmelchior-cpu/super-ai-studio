"""Équipe par projet : les métiers restent communs (Studio/roles), chaque projet règle les siens.

Pour chaque projet (data/equipes.json) :
- par métier : actif ou non, modèle, effort, consignes propres au projet (ajoutées à la mission) ;
- serveurs MCP actifs dans ce projet (vide = aucun réglage : tous ceux de Personnalisation) ;
- agents propres au projet : rôles dont la fiche porte ``projets = ["project:x"]`` (proposés seulement là).
Ordre des choix pour une tâche : la demande > l'équipe du projet > le réglage du métier > le préréglage.
"""
from __future__ import annotations

import json
import os
import re
from pathlib import Path

EFFORTS = ("", "low", "medium", "high", "xhigh", "max")


def _f(data: Path) -> Path:
    return Path(data) / "equipes.json"


def lire(data: Path) -> dict:
    try:
        d = json.loads(_f(data).read_text(encoding="utf-8"))
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def _ecrire(data: Path, d: dict) -> None:
    f = _f(data)
    f.parent.mkdir(parents=True, exist_ok=True)
    t = f.with_suffix(".tmp")
    t.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
    os.replace(t, f)


def reglage(data: Path, cible: str, role_id: str) -> dict:
    return ((lire(data).get(cible) or {}).get("roles") or {}).get(role_id) or {}


def actif(data: Path, cible: str, role) -> bool:
    if role.projets and cible not in role.projets:
        return False
    return reglage(data, cible, role.id).get("actif", True) is not False


def roles_du_projet(roles: dict, data: Path, cible: str) -> dict:
    """Métiers proposés pour ce projet (l'auditeur reste toujours)."""
    return {k: r for k, r in roles.items() if k == "auditeur" or actif(data, cible, r)}


def mcp_du_projet(data: Path, cible: str) -> list[str] | None:
    v = (lire(data).get(cible) or {}).get("mcp")
    return [str(x) for x in v] if isinstance(v, list) else None


def regler_role(studio, cible: str, role_id: str, champs: dict) -> dict:
    if role_id not in studio.roles or role_id == "auditeur":
        raise ValueError("Métier inconnu.")
    d = lire(studio.paths.data)
    r = d.setdefault(cible, {}).setdefault("roles", {}).setdefault(role_id, {})
    if "actif" in champs:
        r["actif"] = bool(champs["actif"])
    if "modele" in champs:
        m = str(champs["modele"] or "")
        if not re.fullmatch(r"[A-Za-z0-9._-]{0,48}", m):
            raise ValueError("Modèle invalide.")
        r["modele"] = m
    if "effort" in champs:
        if champs["effort"] not in EFFORTS:
            raise ValueError("Effort invalide.")
        r["effort"] = champs["effort"]
    if "consignes" in champs:
        c = str(champs["consignes"] or "").strip()
        if len(c) > 4000:
            raise ValueError("Consignes trop longues (4000 caractères).")
        r["consignes"] = c
    d[cible]["roles"][role_id] = {k: v for k, v in r.items() if v not in ("", None) or k == "actif"}
    if d[cible]["roles"][role_id] == {"actif": True}:
        d[cible]["roles"].pop(role_id)
    _ecrire(studio.paths.data, d)
    return vue_projet(studio, cible)


def regler_mcp(studio, cible: str, noms: list[str] | None) -> dict:
    d = lire(studio.paths.data)
    if noms is None:
        d.setdefault(cible, {}).pop("mcp", None)
    else:
        d.setdefault(cible, {})["mcp"] = [str(n) for n in noms if re.fullmatch(r"[a-z0-9-]{1,60}", str(n))]
    _ecrire(studio.paths.data, d)
    return vue_projet(studio, cible)


def vue_projet(studio, cible: str) -> dict:
    """Équipe du projet : chaque métier avec ses réglages (projet et commun), et les MCP actifs."""
    from .bibliotheque import mcp_installes
    eq = (lire(studio.paths.data).get(cible) or {})
    out = []
    for r in sorted(studio.roles.values(), key=lambda x: x.nom.lower()):
        if r.id == "auditeur" or (r.projets and cible not in r.projets):
            continue
        g = (eq.get("roles") or {}).get(r.id) or {}
        out.append({"id": r.id, "nom": r.nom, "outil": r.executeur, "actif": g.get("actif", True) is not False,
                    "modele": g.get("modele", ""), "effort": g.get("effort", ""), "consignes": g.get("consignes", ""),
                    "modele_commun": studio.modeles().get(r.id, "") or r.modele, "effort_commun": studio.efforts().get(r.id, "") or r.effort,
                    "propre": bool(r.projets), "personnalise": bool({k for k in g if k != "actif"} or g.get("actif") is False)})
    serveurs = sorted(mcp_installes(studio.paths.data))
    choix = eq.get("mcp")
    return {"cible": cible, "roles": out, "mcp": [{"nom": n, "actif": choix is None or n in choix} for n in serveurs],
            "mcp_regle": isinstance(choix, list)}


def tableau(studio) -> dict:
    """Gestion : projets × métiers (actif, personnalisé, au travail)."""
    act = {}
    for a in studio.activite():
        act.setdefault(a["target"], {})[a["role"]] = a["etat"]
    projets = [t for t in studio.registry.all()]
    cols = []
    for t in projets:
        cle = f"{t.kind}:{t.id}"
        v = vue_projet(studio, cle)
        enc = act.get(cle, {}) or act.get(t.id, {})
        cols.append({"cle": cle, "nom": t.nom, "profil": studio.profil(cle), "roles": {r["id"]: {"actif": r["actif"], "personnalise": r["personnalise"],
                                                                  "propre": r["propre"], "etat": enc.get(r["id"], "")} for r in v["roles"]}})
    roles = [{"id": r.id, "nom": r.nom} for r in sorted(studio.roles.values(), key=lambda x: x.nom.lower()) if r.id != "auditeur"]
    return {"projets": cols, "roles": roles}
