"""Modèles sur ton PC (Gestion › Benchmarks › « Installer ») : téléchargement par Ollama, avec progression.

- Seuls les modèles locaux du catalogue des benchmarks s'installent ici (nom vérifié), au clic de l'utilisateur.
- Ollama doit être installé : le studio ne l'installe jamais lui-même (lien de téléchargement sinon).
- Ollama fermé : il s'ouvre tout seul au moment où il sert (installer un modèle, un agent ou le Superviseur qui utilise un
  modèle local), jamais à l'ouverture du studio. Ollama libère la mémoire d'un modèle 5 min après sa dernière utilisation.
- Le téléchargement passe par l'API locale d'Ollama (127.0.0.1:11434) ; rien d'autre n'est lancé.
"""
from __future__ import annotations

import json
import re
import threading
import urllib.request

OLLAMA = "http://127.0.0.1:11434"
TELECHARGER_OLLAMA = "https://ollama.com/download"
_NOM = re.compile(r"^[a-z0-9][a-z0-9._-]{0,80}(:[a-z0-9._-]{1,40})?$")
_en_cours: dict[str, dict] = {}
_verrou = threading.Lock()


def _get(chemin: str, delai: float = 2):
    with urllib.request.urlopen(OLLAMA + chemin, timeout=delai) as r:
        return json.loads(r.read() or b"{}")


def executable_ollama() -> str:
    """Ollama installé sur ce PC (même fermé) : chemin de la commande, sinon vide."""
    import glob
    import os
    import shutil
    p = shutil.which("ollama")
    if p:
        return p
    for motif in ("~/AppData/Local/Programs/Ollama/ollama.exe", "C:/Program Files/Ollama/ollama.exe"):
        t = glob.glob(os.path.expanduser(motif))
        if t:
            return t[0]
    return ""


def demarrer() -> dict:
    """Ouvre Ollama (sur clic de l'utilisateur) : l'application de la barre des tâches si elle existe, sinon le serveur."""
    import os
    import subprocess
    import sys
    exe = executable_ollama()
    if not exe:
        raise ValueError(f"Ollama n'est pas installé. Installe-le ({TELECHARGER_OLLAMA}), puis réessaie.")
    appli = os.path.join(os.path.dirname(exe), "ollama app.exe")
    opts = {"creationflags": 0x00000008 | 0x00000200 | 0x08000000} if sys.platform == "win32" else {"start_new_session": True}
    cmd = [appli] if os.path.exists(appli) else [exe, "serve"]
    subprocess.Popen(cmd, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, close_fds=True, **opts)
    import time
    for _ in range(20):
        time.sleep(0.5)
        if installes() is not None:
            return {"ok": True, "message": "Ollama est ouvert."}
    return {"ok": True, "message": "Ollama démarre…"}


def assurer() -> bool:
    """Ollama prêt à servir : l'ouvre s'il est installé mais fermé (au moment où un modèle local sert). Vrai s'il répond."""
    if installes() is not None:
        return True
    if not executable_ollama():
        return False
    try:
        demarrer()
    except (OSError, ValueError):
        return False
    return installes() is not None


def details() -> list[dict]:
    """Modèles installés avec taille et date (Gestion › Outils : mise à jour des modèles locaux)."""
    try:
        return [{"nom": m.get("name", ""), "taille_go": round((m.get("size") or 0) / 1e9, 1), "modifie": str(m.get("modified_at", ""))[:10]}
                for m in _get("/api/tags").get("models", []) if m.get("name")]
    except (OSError, ValueError):
        return []


def installes() -> list[str] | None:
    """Modèles déjà présents dans Ollama ; None si Ollama ne répond pas."""
    try:
        return sorted(m.get("name", "") for m in _get("/api/tags").get("models", []) if m.get("name"))
    except (OSError, ValueError):
        return None


def nom_ollama(m: dict) -> str:
    return str(m.get("ollama") or m.get("cle") or "")


def present(nom: str, liste: list[str]) -> bool:
    """« qwen3.6 » est présent si « qwen3.6:latest » ou « qwen3.6:27b » l'est."""
    base = nom if ":" in nom else nom + ":"
    return any(x == nom or x.startswith(base) for x in liste)


def etat(catalogue: list[dict]) -> dict:
    liste = installes()
    with _verrou:
        en_cours = {k: dict(v) for k, v in _en_cours.items()}
    modeles = {}
    for m in catalogue:
        n = nom_ollama(m)
        if m.get("local") and n:
            modeles[n] = {"installe": bool(liste) and present(n, liste), **({"progression": en_cours[n]} if n in en_cours else {})}
    return {"ollama": liste is not None, "installe": liste is not None or bool(executable_ollama()),
            "telecharger": TELECHARGER_OLLAMA, "modeles": modeles}


def installer(nom: str, catalogue: list[dict], note=lambda m: None, ouvrir: bool = True) -> dict:
    nom = (nom or "").strip().lower()
    if not _NOM.match(nom) or nom not in {nom_ollama(m) for m in catalogue if m.get("local")} | set(installes() or []):
        raise ValueError("Modèle inconnu du catalogue : rien n'est installé.")
    if not (assurer() if ouvrir else installes() is not None):
        raise ValueError(f"Ollama ne répond pas sur le PC. Installe-le ({TELECHARGER_OLLAMA}) s'il ne l'est pas, puis réessaie."
                         if not executable_ollama() else "Ollama ne répond pas : ouvre-le sur le PC, puis réessaie.")
    with _verrou:
        if nom in _en_cours and _en_cours[nom].get("etat") == "telechargement":
            return {"ok": True, "deja": True}
        _en_cours[nom] = {"etat": "telechargement", "pct": 0, "message": "Démarrage…"}

    def tirer():
        try:
            req = urllib.request.Request(OLLAMA + "/api/pull", data=json.dumps({"model": nom, "stream": True}).encode(),
                                         headers={"Content-Type": "application/json"})
            with urllib.request.urlopen(req, timeout=300) as r:
                for ligne in r:
                    try:
                        d = json.loads(ligne)
                    except ValueError:
                        continue
                    if d.get("error"):
                        raise RuntimeError(str(d["error"])[:300])
                    with _verrou:
                        p = _en_cours[nom]
                        if d.get("total"):
                            p["pct"] = int(100 * (d.get("completed") or 0) / d["total"])
                        p["message"] = str(d.get("status", ""))[:80]
            with _verrou:
                _en_cours[nom] = {"etat": "fini", "pct": 100, "message": "Installé."}
            note(f"modèle local installé : {nom}")
        except Exception as e:                             # noqa: BLE001 — affiché à côté du modèle
            with _verrou:
                _en_cours[nom] = {"etat": "erreur", "pct": 0, "message": f"Échec : {str(e)[:200]}"}
    threading.Thread(target=tirer, daemon=True).start()
    return {"ok": True}
