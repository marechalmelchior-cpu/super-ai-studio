"""Mises à jour du programme depuis les versions publiées par Mel (dépôt GitHub public, dossier derniere/).

- Vérification au lancement puis une fois par jour, et bouton « Rechercher une mise à jour » (Gestion › Outils).
- Mise à jour mineure (manifest « mineure »: true) : installée seule, puis le studio propose de redémarrer.
  Mise à jour majeure : le studio affiche les nouveautés et attend « Installer ».
- Seuls les fichiers du programme changent (studio/, modeles/, scripts/, docs/, installeur/, studio.cmd, listes de
  composants). Jamais les données, les réglages, les rôles, la mémoire ni l'environnement Python. Avant d'écrire,
  la version actuelle est sauvegardée (anciennes-versions/<version>.zip) ; l'archive est vérifiée (SHA-256).
"""
from __future__ import annotations

import hashlib
import io
import json
import re
import threading
import time
import urllib.request
import zipfile
from pathlib import Path

from .espace import CODE

AUTORISES = ("studio/", "modeles/", "scripts/", "docs/", "installeur/", "wheels/")
FICHIERS_RACINE = {"studio.cmd", "VERSION", "requirements.lock.txt", "requirements-pieces.lock.txt", "requirements-retro.lock.txt"}
_etat: dict = {"verifie": 0.0, "disponible": None, "installee": "", "erreur": "", "en_cours": False}
_verrou = threading.Lock()


def version_actuelle(code: Path = CODE) -> str:
    try:
        return (code / "VERSION").read_text(encoding="utf-8").strip() or "0.0.0"
    except OSError:
        return "0.0.0"


def depot() -> str:
    try:
        d = (CODE / "DEPOT").read_text(encoding="utf-8").strip()
        return d if re.fullmatch(r"[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+", d) else ""
    except OSError:
        return ""


def _v(t: str) -> tuple[int, ...]:
    return tuple(int(x) for x in re.findall(r"\d+", t)[:3]) or (0,)


def _get(url: str, delai: float = 30) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": "SuperAIStudio", "Accept": "application/octet-stream, application/json"})
    with urllib.request.urlopen(req, timeout=delai) as r:
        return r.read()


def verifier(force: bool = False) -> dict:
    """Dernière version publiée : {"version", "mineure", "notes"} si elle est plus récente, sinon None."""
    d = depot()
    if not d:
        return {"actuelle": version_actuelle(), "disponible": None, "info": "Mises à jour non configurées."}
    with _verrou:
        if not force and time.time() - _etat["verifie"] < 3600:
            return {"actuelle": version_actuelle(), "disponible": _etat["disponible"], "installee": _etat["installee"]}
    try:
        # dernière version : dossier « derniere/ » du dépôt public (manifest.json + archive du programme)
        base = f"https://raw.githubusercontent.com/{d}/main/derniere/"
        man = json.loads(_get(base + "manifest.json"))
        dispo = None
        fichier = str(man.get("fichier", ""))
        if man.get("version") and _v(man["version"]) > _v(version_actuelle()) and re.fullmatch(r"[A-Za-z0-9_.-]+\.zip", fichier):
            dispo = {"version": man["version"], "mineure": bool(man.get("mineure")), "notes": str(man.get("notes", ""))[:2000],
                     "url": base + fichier, "sha256": man.get("sha256", "")}
        with _verrou:
            _etat.update(verifie=time.time(), disponible=dispo, erreur="")
    except Exception as e:                                 # noqa: BLE001 — hors ligne : on réessaiera plus tard
        with _verrou:
            _etat.update(verifie=time.time(), erreur=type(e).__name__)
    return {"actuelle": version_actuelle(), "disponible": _etat["disponible"], "installee": _etat["installee"], "erreur": _etat["erreur"]}


def _membres_surs(z: zipfile.ZipFile) -> list[zipfile.ZipInfo]:
    out = []
    for m in z.infolist():
        n = m.filename.replace("\\", "/")
        if m.is_dir():
            continue
        if n.startswith("/") or ".." in n.split("/") or ":" in n:
            raise ValueError(f"chemin refusé dans l'archive : {n}")
        if not (n.startswith(AUTORISES) or n in FICHIERS_RACINE):
            raise ValueError(f"fichier hors du programme dans l'archive : {n}")
        out.append(m)
    return out


def appliquer(archive: bytes, attendu: str, cible: Path = CODE) -> dict:
    """Vérifie puis installe une archive de programme ; sauvegarde d'abord les fichiers remplacés."""
    if attendu and hashlib.sha256(archive).hexdigest() != attendu:
        raise ValueError("archive altérée (empreinte différente) : rien n'est installé")
    z = zipfile.ZipFile(io.BytesIO(archive))
    membres = _membres_surs(z)
    ancienne = version_actuelle(cible)
    sauvegardes = cible.parent / "anciennes-versions" if cible.name == "app" else cible / "data" / "anciennes-versions"
    sauvegardes.mkdir(parents=True, exist_ok=True)
    copie = sauvegardes / f"{ancienne}-{time.strftime('%Y%m%d-%H%M%S')}.zip"
    with zipfile.ZipFile(copie.with_suffix(".partiel"), "w", zipfile.ZIP_DEFLATED) as s:
        for m in membres:
            f = cible / m.filename
            if f.is_file():
                s.write(f, m.filename)
    copie.with_suffix(".partiel").replace(copie)
    for m in membres:
        f = cible / m.filename
        f.parent.mkdir(parents=True, exist_ok=True)
        t = f.with_name(f.name + ".maj")
        t.write_bytes(z.read(m))
        t.replace(f)
    composants = any(m.filename.startswith("wheels/") for m in membres)
    if composants:
        _installer_composants(cible)
    return {"ok": True, "ancienne": ancienne, "nouvelle": version_actuelle(cible), "sauvegarde": str(copie), "fichiers": len(membres)}


def _installer_composants(cible: Path) -> None:
    """Nouveaux composants Python fournis avec la mise à jour (hors ligne, depuis wheels/)."""
    import subprocess
    from .actions import python_console
    from .connectors.base import SANS_FENETRE
    r = subprocess.run([python_console(), "-m", "pip", "install", "--disable-pip-version-check", "--no-index", "--find-links",
                        str(cible / "wheels"), "-r", str(cible / "requirements.lock.txt")], capture_output=True, text=True,
                       timeout=900, stdin=subprocess.DEVNULL, **SANS_FENETRE)
    if r.returncode:
        raise RuntimeError("composants de la mise à jour non installés : " + (r.stderr or r.stdout)[-300:])


def installer(note=lambda m: None) -> dict:
    with _verrou:
        dispo = _etat["disponible"]
        if _etat["en_cours"]:
            raise RuntimeError("Une mise à jour est déjà en cours.")
        _etat["en_cours"] = True
    try:
        if not dispo:
            raise ValueError("Aucune mise à jour disponible.")
        r = appliquer(_get(dispo["url"], 600), dispo.get("sha256", ""))
        with _verrou:
            _etat.update(installee=r["nouvelle"], disponible=None)
        note(f"mise à jour installée : {r['ancienne']} → {r['nouvelle']}")
        return r
    finally:
        with _verrou:
            _etat["en_cours"] = False


def automatique(note=lambda m: None) -> None:
    """Au lancement puis chaque jour : vérifie ; une mise à jour mineure s'installe seule."""
    v = verifier(force=True)
    d = v.get("disponible")
    if d and d.get("mineure"):
        try:
            installer(note)
        except Exception as e:                             # noqa: BLE001 — affichée dans Gestion › Outils
            with _verrou:
                _etat["erreur"] = str(e)[:300]


def etat() -> dict:
    with _verrou:
        return {"actuelle": version_actuelle(), "depot": depot(), "disponible": _etat["disponible"],
                "installee": _etat["installee"], "erreur": _etat["erreur"], "en_cours": _etat["en_cours"]}


def redemarrer_plus_tard() -> None:
    """Relance le studio quelques secondes après son arrêt (même programme, même espace)."""
    import subprocess
    import sys
    code = ("import time, subprocess, sys; time.sleep(5); "
            f"subprocess.Popen([sys.executable, '-m', 'studio', 'lanceur'], cwd={str(CODE)!r})")
    subprocess.Popen([sys.executable, "-c", code], cwd=str(CODE), stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                     stderr=subprocess.DEVNULL, close_fds=True,
                     **({"creationflags": 0x00000008 | 0x00000200} if sys.platform == "win32" else {"start_new_session": True}))
