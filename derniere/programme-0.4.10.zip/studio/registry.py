"""Registre des projets et sujets.

Un projet = ``Projets/<id>/project.toml`` ; un sujet = ``Sujets/<id>/topic.toml``.
Ajouter un projet ou un sujet ne demande aucune modification du code :
créer le dossier et son fichier (ou ``python -m studio projet-ajouter``).
Les projets restent à leur emplacement réel : le registre pointe vers eux.
"""
from __future__ import annotations

import re
import tomllib
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .memory.models import Scope

_ID = re.compile(r"^[a-z0-9][a-z0-9._-]{0,63}$")
APPLICATIONS = ("manuel", "auto_apres_approbation")


@dataclass
class Target:
    kind: str                       # "project" | "topic"
    id: str
    nom: str
    type: str = "doc"
    chemin: str = ""                # vide pour un sujet sans dépôt
    depot: str = ""
    outils: list[str] = field(default_factory=list)
    regles: list[str] = field(default_factory=list)
    documents: list[str] = field(default_factory=list)
    verifications: list[str] = field(default_factory=list)
    application: str = "manuel"
    description: str = ""
    extra: dict[str, Any] = field(default_factory=dict)
    fichier: Path | None = None

    @property
    def scope(self) -> Scope:
        return Scope(self.kind, self.id)  # type: ignore[arg-type]

    @property
    def has_path(self) -> bool:
        return bool(self.chemin)

    def path(self) -> Path | None:
        if not self.chemin:
            return None
        if re.match(r"^[A-Za-z]:[\\/]", self.chemin):      # chemin Windows absolu
            return Path(self.chemin)
        p = Path(self.chemin)
        if not p.is_absolute() and self.fichier is not None:   # chemin relatif au fichier toml
            p = (self.fichier.parent / p).resolve()
        return p

    def to_public(self) -> dict:
        return {"kind": self.kind, "id": self.id, "nom": self.nom, "type": self.type, "chemin": self.chemin,
                "depot": self.depot, "outils": self.outils, "application": self.application,
                "description": self.description, "memoire": self.scope.label}


KNOWN = {"id", "nom", "type", "chemin", "depot", "outils", "regles", "documents", "verifications",
         "application", "description"}


def _load(kind: str, f: Path) -> Target:
    with open(f, "rb") as fh:
        d = tomllib.load(fh)
    tid = d.get("id", f.parent.name)
    if not _ID.match(tid):
        raise ValueError(f"Identifiant invalide dans {f}")
    if d.get("application", "manuel") not in APPLICATIONS:
        raise ValueError(f"Politique d'application inconnue dans {f}")
    return Target(kind=kind, id=tid, nom=d.get("nom", tid), type=d.get("type", "doc"),
                  chemin=d.get("chemin", ""), depot=d.get("depot", ""), outils=list(d.get("outils", [])),
                  regles=list(d.get("regles", [])), documents=list(d.get("documents", [])),
                  verifications=list(d.get("verifications", [])), application=d.get("application", "manuel"),
                  description=d.get("description", ""), extra={k: v for k, v in d.items() if k not in KNOWN},
                  fichier=f)


class Registry:
    def __init__(self, projects_dir: Path, topics_dir: Path, archives_dir: Path | None = None):
        self.projects_dir, self.topics_dir = Path(projects_dir), Path(topics_dir)
        self.archives_dir = Path(archives_dir) if archives_dir else None

    def all(self) -> list[Target]:
        out = []
        for kind, d, name in (("project", self.projects_dir, "project.toml"), ("topic", self.topics_dir, "topic.toml")):
            if d.exists():
                for f in sorted(d.glob(f"*/{name}")):
                    out.append(_load(kind, f))
        return out

    def get(self, ref: str) -> Target:
        """``rpg3d``, ``project:rpg3d`` ou ``topic:veille-ia``."""
        kind, _, ident = ref.partition(":") if ":" in ref else ("", "", ref)
        kind = {"projet": "project", "sujet": "topic"}.get(kind, kind)
        matches = [t for t in self.all() if t.id == ident and (not kind or t.kind == kind)]
        if not matches:
            raise KeyError(f"Projet ou sujet inconnu : {ref}")
        if len(matches) > 1:
            raise KeyError(f"Référence ambiguë : {ref} (préciser project: ou topic:)")
        return matches[0]

    def retirer(self, ref: str) -> Path:
        """Retire un projet ou un sujet du studio SANS rien supprimer : sa fiche (dossier Projets/<id> ou Sujets/<id>,
        avec project.toml, CONTEXTE.md, lore…) est déplacée dans Archives/projets-retires/ ou Archives/sujets-retires/<id> <date>. Le vrai dossier du
        projet (chemin) n'est jamais touché. Pour le remettre : redéplacer le dossier à sa place."""
        import shutil
        from datetime import datetime
        t = self.get(ref)
        if t.fichier is None:
            raise FileNotFoundError(f"Fiche introuvable : {ref}")
        src = t.fichier.parent
        base = self.projects_dir if t.kind == "project" else self.topics_dir
        if src.parent.resolve() != base.resolve():
            raise ValueError(f"Fiche hors de {base.name} : rien n'est déplacé.")
        if self.archives_dir:
            dest = self.archives_dir / ("projets-retires" if t.kind == "project" else "sujets-retires") / \
                f"{t.id} {datetime.now().strftime('%Y-%m-%d %Hh%M')}"
        else:
            dest = base / "_retires" / f"{t.id}-{datetime.now().strftime('%Y%m%d-%H%M%S')}"
        if dest.exists():
            raise FileExistsError(f"{dest} existe déjà : rien n'est écrasé.")
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(src), str(dest))
        return dest

    def add(self, kind: str, tid: str, nom: str, **fields) -> Target:
        if not _ID.match(tid):
            raise ValueError("Identifiant : minuscules, chiffres, . _ - (64 max).")
        base = self.projects_dir if kind == "project" else self.topics_dir
        d = base / tid
        f = d / ("project.toml" if kind == "project" else "topic.toml")
        if f.exists():
            raise FileExistsError(f"{f} existe déjà : rien n'est écrasé.")
        if kind == "project" and not fields.get("chemin"):
            raise ValueError("Un projet doit indiquer son chemin réel.")
        d.mkdir(parents=True, exist_ok=True)
        from datetime import datetime
        data = {"id": tid, "nom": nom, **{k: v for k, v in fields.items() if v not in (None, "", [])},
                "cree": datetime.now().isoformat(timespec="seconds")}          # ordre de l'accueil : le plus récent d'abord
        f.write_text(dump_toml(data), encoding="utf-8")
        (d / "CONTEXTE.md").exists() or (d / "CONTEXTE.md").write_text(
            f"# {nom}\n\nContexte validé du {('projet' if kind == 'project' else 'sujet')}. "
            "À compléter par Mel ; les agents le lisent avant toute tâche.\n", encoding="utf-8")
        return _load(kind, f)


def _toml_value(v) -> str:
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, (int, float)):
        return str(v)
    if isinstance(v, list):
        return "[" + ", ".join(_toml_value(x) for x in v) + "]"
    s = str(v)
    if "'" not in s and "\n" not in s:
        return f"'{s}'"                       # chaîne littérale : pas d'échappement des \ Windows
    return '"' + s.replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n") + '"'


def dump_toml(d: dict) -> str:
    return "".join(f"{k} = {_toml_value(v)}\n" for k, v in d.items() if not isinstance(v, dict))
