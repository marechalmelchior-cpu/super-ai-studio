"""Garde des outils unreal-mcp pour les tâches du studio (hook PreToolUse de Claude Code).

Mode « tout » (par défaut, choix de Mel du 24/10) : les agents utilisent unreal-mcp comme Claude en interactif ; chaque
action est notée dans le journal de la tâche (lecture / écriture) pour qu'elle apparaisse dans le compte rendu.
Mode « lecture » (Superviseur › Réglages) : seules les actions de lecture passent, comme décrit ci-dessous.

unreal-mcp passe TOUTES ses actions par un seul outil, ``call_tool`` : lire le niveau et supprimer un acteur utilisent le
même outil, donc une permission « outil par outil » ne suffit pas. Ce garde regarde l'action demandée et :

- autorise ``list_toolsets`` et ``describe_toolset`` (ils ne font que décrire) ;
- autorise ``call_tool`` seulement pour une action de LECTURE : son nom commence par un verbe de lecture
  (get, find, list, describe, search, query, read, count, has, is, snapshot, inspect, dump) ET ne contient aucun mot
  d'écriture (set, create, delete, spawn, save, compile, press, run…) ;
- refuse tout le reste, avec la raison (l'agent la voit et le dit dans son compte rendu).

Sûr par défaut : ``call_tool`` n'est PAS dans les outils autorisés des rôles ; seul ce garde peut l'ouvrir, au cas par
cas. Si le garde ne se lance pas, Claude Code refuse l'appel (aucune fenêtre d'approbation dans une tâche).
Chaque décision est notée dans ``Studio/data/garde-unreal-mcp.log`` (action et décision, jamais les arguments).

Commandes shell (Bash, PowerShell) des tâches : autorisées comme dans une session normale (lancer l'éditeur, les
scripts du projet, les tests, git status…), notées dans le journal de la tâche ; seules les commandes qui détruisent
ou publient sont refusées (push, reset --hard, clean, suppression récursive, formatage, arrêt de Windows, taskkill
global…). La relecture (mode « lecture ») n'a pas de shell.

Lancé par Claude Code avec le JSON de l'appel sur l'entrée standard ; répond un JSON sur la sortie standard.
"""
from __future__ import annotations

import json
import re
import sys
from datetime import datetime
from pathlib import Path

PREFIXE = "mcp__unreal-mcp__"
DESCRIPTION = {"list_toolsets", "describe_toolset"}
VERBES_LECTURE = ("get", "find", "list", "describe", "search", "query", "read", "count", "has", "is", "snapshot",
                  "inspect", "dump")
MOTS_ECRITURE = ("set", "create", "delete", "remove", "destroy", "spawn", "add", "save", "compile", "build", "move",
                 "rename", "import", "export", "execute", "exec", "run", "start", "stop", "press", "click", "type",
                 "focus", "open", "close", "load", "unload", "apply", "modify", "write", "edit", "update", "change",
                 "duplicate", "copy", "paste", "attach", "detach", "select", "play", "simulate", "restart", "quit",
                 "reset", "clear", "replace", "assign", "bind", "register", "enable", "disable", "toggle", "fix",
                 "generate", "bake", "migrate", "commit", "submit", "send", "post", "invoke", "call")


def mots(nom: str) -> list[str]:
    """« get_current_level », « GetCurrentLevel », « SceneTools.find_actors » → mots en minuscules."""
    nom = nom.split(".")[-1]
    nom = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", nom)
    return [m for m in re.split(r"[^A-Za-z0-9]+", nom.lower()) if m]


def decision(entree: dict) -> tuple[str, str]:
    outil = str(entree.get("tool_name") or "")
    if not outil.startswith(PREFIXE):
        return "", ""                                   # pas un outil unreal-mcp : le garde ne dit rien
    court = outil[len(PREFIXE):]
    if court in DESCRIPTION:
        return "allow", f"{court} : description des outils, lecture seule"
    if court != "call_tool":
        return "deny", f"{court} : outil unreal-mcp non prévu pour les tâches du studio"
    ti = entree.get("tool_input") or {}
    action = str(ti.get("tool_name") or ti.get("tool") or ti.get("name") or "")
    if not action:
        return "deny", "call_tool sans nom d'action : refusé"
    m = mots(action)
    if not m or m[0] not in VERBES_LECTURE:
        return "deny", f"action « {action} » refusée : les tâches du studio n'ont que les actions de lecture (get, find, list…)"
    ecrit = [x for x in m if x in MOTS_ECRITURE]
    if ecrit:
        return "deny", f"action « {action} » refusée : contient « {ecrit[0]} » (écriture possible)"
    return "allow", f"action « {action} » en lecture seule"


SHELL = {"Bash", "PowerShell"}
EDITION = {"Edit", "Write", "MultiEdit", "NotebookEdit"}     # seulement notés (activité en direct) ; la permission ne change pas
INTERDITS = [
    (r"\bgit\s+push\b", "git push : la publication passe par Gestion › Branches"),
    (r"\bgit\s+reset\s+--hard\b", "git reset --hard"),
    (r"\bgit\s+clean\b", "git clean"),
    (r"\bgit\s+(checkout|restore)\s+(--\s+)?\.(\s|$)", "annulation de tous les fichiers"),
    (r"\bgit\s+branch\s+-D\b", "suppression forcée de branche"),
    (r"\bgit\s+(rebase|filter-branch|filter-repo)\b", "réécriture d'historique"),
    (r"\bgit\s+stash\s+(drop|clear)\b", "suppression de remises"),
    (r"\brm\s+(-[a-zA-Z]*[rR][a-zA-Z]*|--recursive)\b", "suppression récursive"),
    (r"\b(remove-item|ri|rm|del|erase|rd|rmdir)\b[^|;&]*\s-(r|recurse)\b", "suppression récursive"),
    (r"\b(rd|rmdir|del|erase)\b[^|;&]*\s/s\b", "suppression récursive"),
    # le formatage de DISQUE seulement (« format D: ») : jamais -Format, Format-List ni .format( en Python
    (r"(^|[;&|(]|\bcmd(\.exe)?\s+/[ck])\s*format(\.com)?\s+[a-z]:", "formatage de disque"),
    (r"\b(diskpart|bcdedit|vssadmin\s+delete|cipher\s+/w)\b", "commande système destructrice"),
    (r"\b(shutdown|restart-computer|stop-computer|logoff)\b", "arrêt de Windows"),
    (r"\btaskkill\b[^|;&]*/im\b", "taskkill global (cibler un processus précis)"),
    (r"\bstop-process\b[^|;&]*-name\b", "arrêt de processus par nom (cibler un PID)"),
    (r"\b(reg\s+delete|remove-itemproperty|set-executionpolicy|netsh|sc(\.exe)?\s+delete)\b", "réglage système"),
    (r"(iwr|irm|invoke-webrequest|invoke-restmethod|curl|wget)[^|]*\|\s*(iex|invoke-expression|sh|bash|powershell)\b",
     "télécharger puis exécuter"),
]


def decision_shell(commande: str) -> tuple[str, str]:
    c = (commande or "").lower()
    for motif, raison in INTERDITS:
        if re.search(motif, c):
            return "deny", f"commande refusée par le studio ({raison}). Dis-le dans ton compte rendu, sans contourner."
    return "allow", "commande autorisée et notée par le studio"


def est_lecture(entree: dict) -> bool:
    return decision(entree)[0] == "allow"


def noter(action: str, dec: str, genre: str) -> None:
    """Journal global (data/garde-unreal-mcp.log) et journal de la tâche (STUDIO_ACTIONS_UNREAL), sans les arguments."""
    import os
    ligne = f"{datetime.now().isoformat(timespec='seconds')}  {dec:5}  {genre:8}  {action}\n"
    for f in (Path(__file__).resolve().parents[1] / "data" / "garde-unreal-mcp.log", os.environ.get("STUDIO_ACTIONS_UNREAL")):
        if not f:
            continue
        try:
            f = Path(f); f.parent.mkdir(parents=True, exist_ok=True)
            with f.open("a", encoding="utf-8") as h:
                h.write(ligne)
        except OSError:
            pass


def main() -> int:
    try:
        brut = sys.stdin.buffer.read() if hasattr(sys.stdin, "buffer") else sys.stdin.read().encode("utf-8")
        entree = json.loads(brut.decode("utf-8", errors="replace") or "{}")     # Claude Code envoie de l'UTF-8 (accents des chemins)
    except ValueError:
        entree = {}
    import os
    entree = entree if isinstance(entree, dict) else {}
    outil = str(entree.get("tool_name") or "")
    ti0 = entree.get("tool_input") or {}
    if outil in EDITION:                                # noté pour l'activité en direct, AUCUNE décision : la règle du rôle s'applique
        chemin = str(ti0.get("file_path") or ti0.get("notebook_path") or "")
        tache = os.environ.get("STUDIO_TACHE_DOSSIER", "")
        if tache and chemin:
            norme = lambda x: x.replace("\\", "/").rstrip("/").lower()
            c, t = norme(chemin), norme(tache)
            if c.startswith(t + "/") and not any(c.startswith(f"{t}/{d}/") for d in ("copie-de-travail", "captures")):
                noter_activite("refus", f"écrire {Path(chemin).name} dans le dossier de la tâche")
                return repondre("deny", "Fichier du studio (compte rendu, journaux) : le studio l'écrit lui-même. Mets ton "
                                        "compte rendu dans ta réponse finale et tes preuves dans captures/.")
        noter_activite("fichier", f"{'crée' if outil == 'Write' else 'modifie'}  {_masquer(chemin)[:300]}")
        return 0
    if outil in SHELL:
        cmd = str((entree.get("tool_input") or {}).get("command") or "")
        if os.environ.get("STUDIO_MCP_UNREAL", "tout") == "lecture":
            dec, raison = "deny", "relecture : pas de commande shell"
        else:
            dec, raison = decision_shell(cmd)
        noter_commande(f"{dec:5}  {outil:10}  {_masquer(' '.join(cmd.split()))[:300]}")
        noter_activite("commande" if dec == "allow" else "refus", _masquer(' '.join(cmd.split()))[:300])
        return repondre(dec, raison)
    dec, raison = decision(entree)
    if not dec:
        return 0
    lecture = dec == "allow"
    if os.environ.get("STUDIO_MCP_UNREAL", "tout") != "lecture":
        dec, raison = "allow", "unreal-mcp : accès complet (réglage du studio)"
    ti = entree.get("tool_input") or {}
    court = str(entree.get("tool_name", ""))[len(PREFIXE):]
    action = f"{ti.get('toolset_name', '')}.{ti.get('tool_name', '')}".strip(".") if court == "call_tool" else court
    noter(action, dec, "lecture" if lecture else "écriture")
    noter_activite("unreal", f"{'lecture' if lecture else 'écriture'}  {action}")
    return repondre(dec, raison)


def _masquer(texte: str) -> str:
    """Pas de secret dans le journal : redaction du studio, ou masque simple si le paquet n'est pas importable."""
    try:
        sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
        from studio.security import redact
        return redact(texte)
    except Exception:                                   # noqa: BLE001
        return re.sub(r"(?i)(token|key|secret|password|passwd|pwd|bearer)\S*\s*[=:]?\s*\S+", r"\1=***", texte)


def noter_commande(ligne: str) -> None:
    import os
    f = os.environ.get("STUDIO_COMMANDES")
    if not f:
        return
    try:
        f = Path(f); f.parent.mkdir(parents=True, exist_ok=True)
        with f.open("a", encoding="utf-8") as h:
            h.write(f"{datetime.now().isoformat(timespec='seconds')}  {ligne}\n")
    except OSError:
        pass


def noter_activite(genre: str, texte: str) -> None:
    """Fil d'activité de la tâche (STUDIO_ACTIVITE) : ce que fait l'agent, affiché en direct à Mel, jamais un secret."""
    import os
    f = os.environ.get("STUDIO_ACTIVITE")
    if not f:
        return
    try:
        f = Path(f); f.parent.mkdir(parents=True, exist_ok=True)
        with f.open("a", encoding="utf-8") as h:
            h.write(f"{datetime.now().isoformat(timespec='seconds')}\t{genre}\t{texte}\n")
    except OSError:
        pass


def repondre(dec: str, raison: str) -> int:
    sortie = json.dumps({"hookSpecificOutput": {"hookEventName": "PreToolUse", "permissionDecision": dec,
                                                "permissionDecisionReason": raison}}, ensure_ascii=False)
    flux = sys.stdout if sys.stdout is not None else open(1, "w", encoding="utf-8", closefd=False)
    flux.write(sortie)
    flux.flush()
    return 0


if __name__ == "__main__":
    sys.exit(main())
