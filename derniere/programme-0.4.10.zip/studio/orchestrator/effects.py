"""Journal des effets : une écriture, une publication ou une application n'est
jamais rejouée aveuglément lors d'une reprise.

- effet terminé  -> le résultat enregistré est renvoyé, rien n'est relancé ;
- effet commencé mais non terminé (interruption pendant l'action) -> état
  INCERTAIN : on appelle ``verify`` si elle existe (l'effet a-t-il eu lieu ?),
  sinon la tâche est bloquée pour décision de Mel.
"""
from __future__ import annotations

import json
from typing import Any, Callable

from .store import TaskStore, now


class EffectUncertain(RuntimeError):
    pass


def run_effect(store: TaskStore, task_id: str, key: str, kind: str, fn: Callable[[], Any],
               verify: Callable[[], Any | None] | None = None) -> Any:
    full = f"{task_id}:{key}"
    with store.db() as c:
        row = c.execute("SELECT status, result FROM effects WHERE key=?", (full,)).fetchone()
        if row is None:
            c.execute("INSERT INTO effects(key,task_id,kind,status,started_at) VALUES (?,?,?,?,?)",
                      (full, task_id, kind, "commence", now()))
        elif row["status"] == "termine":
            store.event(task_id, f"Effet déjà réalisé, non rejoué : {key}")
            return json.loads(row["result"]) if row["result"] else None
        elif row["status"] == "echec" and verify is not None and verify() is None:
            # échec connu et propre (verrou git, refus…) : la vérification confirme que rien n'a eu lieu → nouvel essai
            c.execute("UPDATE effects SET status='commence', started_at=? WHERE key=?", (now(), full))
            store.event(task_id, f"Nouvel essai après échec : {key}")
        else:
            found = verify() if verify else None
            if found is None:
                c.execute("UPDATE effects SET status='incertain' WHERE key=?", (full,))
                raise EffectUncertain(
                    f"L'effet « {key} » a commencé sans confirmation de fin. "
                    "Vérification manuelle nécessaire avant toute nouvelle tentative.")
            c.execute("UPDATE effects SET status='termine', result=?, ended_at=? WHERE key=?",
                      (json.dumps(found, ensure_ascii=False), now(), full))
            store.event(task_id, f"Effet confirmé après reprise (non rejoué) : {key}")
            return found
    try:
        result = fn()
    except Exception as e:
        with store.db() as c:
            c.execute("UPDATE effects SET status='echec', result=? WHERE key=?", (json.dumps({"erreur": str(e)[:500]}), full))
        raise
    with store.db() as c:
        c.execute("UPDATE effects SET status='termine', result=?, ended_at=? WHERE key=?",
                  (json.dumps(result, ensure_ascii=False, default=str), now(), full))
    return result


def effects(store: TaskStore, task_id: str) -> list[dict]:
    with store.db() as c:
        return [dict(r) for r in c.execute(
            "SELECT key,kind,status,started_at,ended_at FROM effects WHERE task_id=?", (task_id,))]
