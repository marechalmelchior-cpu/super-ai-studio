"""Éditeur Unreal et serveur unreal-mcp, prêts AVANT la session de l'agent.

Claude Code ne se connecte à un serveur MCP qu'au démarrage de sa session (quelques essais sur ~10 s, puis plus
jamais). Or unreal-mcp est hébergé par l'éditeur lui-même (http://127.0.0.1:8000/mcp). Si l'éditeur n'est pas
ouvert — ou finit de charger — quand la tâche démarre, l'agent n'a pas Unreal pour toute la tâche (ECONNREFUSED).
C'est ce que fait Scripts/editor/start_session.ps1 de RPG3D pour une session à la main ; le studio fait pareil :

1. vraie poignée de main MCP (« initialize ») : un port ouvert ne suffit pas ;
2. si elle échoue et qu'aucun éditeur n'est ouvert sur ce projet : lance UnrealEditor.exe "<projet>.uproject" ;
   un éditeur déjà ouvert n'est jamais relancé (il finit de charger) ;
3. attend que le MCP réponde (7 min au plus, comme le script) ; l'agent démarre ensuite.
"""
from __future__ import annotations

import json
import os
import re
import subprocess
import time
import urllib.request
from pathlib import Path

URL = "http://127.0.0.1:8000/mcp"
EDITEUR_DEFAUT = r"C:\Program Files\Epic Games\UE_5.8\Engine\Binaries\Win64\UnrealEditor.exe"
MOTS = ("unreal", "mcp", "éditeur", "editeur", "editor", "niveau", "level", "carte", " map", "acteur", "actor", "blueprint",
        "pie", "asset", "matériau", "materiau", "material", "widget", "umg", "mesh", "lumière", "éclairage", "eclairage",
        "spawn", "scène", "scene", "landscape", "niagara", "montage", "animation", "personnage", "caméra", "camera",
        "ouvre le projet", "ouvrir le projet", "uproject", "viewport", "capture")


def projet_unreal(dossier: Path | None) -> Path | None:
    """Le .uproject du projet s'il déclare unreal-mcp dans .mcp.json, sinon None."""
    if not dossier or not (dossier / ".mcp.json").exists():
        return None
    try:
        if "unreal-mcp" not in (dossier / ".mcp.json").read_text(encoding="utf-8", errors="replace"):
            return None
    except OSError:
        return None
    up = sorted(dossier.glob("*.uproject"))
    return up[0] if up else None


def demande_unreal(texte: str) -> bool:
    t = " " + (texte or "").lower()
    return any(m in t for m in MOTS)


def mcp_pret(url: str = URL, delai: float = 10) -> bool:
    corps = json.dumps({"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {
        "protocolVersion": "2025-06-18", "capabilities": {}, "clientInfo": {"name": "studio", "version": "1"}}}).encode()
    req = urllib.request.Request(url, data=corps, method="POST", headers={
        "Content-Type": "application/json", "Accept": "application/json, text/event-stream"})
    try:
        with urllib.request.urlopen(req, timeout=delai) as r:
            return r.status == 200 and b"protocolVersion" in r.read(65536)
    except Exception:                                   # noqa: BLE001 — refus, délai, éditeur occupé : pas prêt
        return False


def editeur_ouvert(nom_projet: str) -> bool:
    """Un UnrealEditor.exe dont la ligne de commande cite ce projet (Windows)."""
    if os.name != "nt":
        return False
    from .connectors.base import SANS_FENETRE
    ps = ("Get-CimInstance Win32_Process -Filter \"Name = 'UnrealEditor.exe'\" | "
          f"Where-Object {{ $_.CommandLine -like '*{re.sub(r'[^A-Za-z0-9_-]', '', nom_projet)}*' }} | "
          "Select-Object -First 1 -ExpandProperty ProcessId")
    try:
        r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", ps], capture_output=True,
                           text=True, timeout=30, stdin=subprocess.DEVNULL, **SANS_FENETRE)
        return bool(r.stdout.strip())
    except (OSError, subprocess.TimeoutExpired):
        return False


def chemin_editeur(cfg: dict) -> Path:
    """UnrealEditor.exe à côté de l'UnrealEditor-Cmd.exe réglé dans Superviseur › Réglages, sinon le chemin habituel."""
    c = str(cfg.get("outils", {}).get("unreal_editor_cmd", "") or cfg.get("outils", {}).get("unreal", "") or "")
    if c:
        from pathlib import PureWindowsPath
        w = PureWindowsPath(c)
        if w.name.lower().startswith("unrealeditor"):
            w = w.with_name("UnrealEditor.exe")
        return Path(str(w))
    return Path(EDITEUR_DEFAUT)


def preparer(uproject: Path, cfg: dict, noter, annule=lambda: False, attente_s: float = 420) -> bool:
    """Rend unreal-mcp joignable avant la session. noter(texte) écrit dans le journal de la tâche. Vrai si prêt."""
    if mcp_pret():
        noter("Unreal : serveur unreal-mcp déjà en ligne")
        return True
    if os.name != "nt":
        noter("Unreal : serveur unreal-mcp injoignable (pas sous Windows : éditeur non lancé)")
        return False
    if editeur_ouvert(uproject.stem):
        noter("Unreal : éditeur déjà ouvert sur le projet, attente de son serveur MCP (il finit de charger)")
    else:
        exe = chemin_editeur(cfg)
        if not exe.exists():
            noter(f"Unreal : UnrealEditor.exe introuvable ({exe}) — règle le chemin dans Superviseur › Réglages")
            return False
        from .connectors.base import SANS_FENETRE
        drapeaux = {k: v for k, v in SANS_FENETRE.items() if k != "creationflags"}
        subprocess.Popen([str(exe), str(uproject)], cwd=str(uproject.parent), stdin=subprocess.DEVNULL,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                         creationflags=getattr(subprocess, "DETACHED_PROCESS", 0) | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0),
                         close_fds=True, **drapeaux)
        noter(f"Unreal : éditeur lancé sur {uproject.name}, attente du serveur MCP (7 min au plus)")
    debut = time.monotonic()
    while time.monotonic() - debut < attente_s:
        if annule():
            return False
        time.sleep(3)
        if mcp_pret():
            noter(f"Unreal : serveur unreal-mcp en ligne après {int(time.monotonic() - debut)} s")
            return True
    noter("Unreal : le serveur unreal-mcp ne répond toujours pas — la tâche démarre sans lui")
    return False


# ------------------------------------------------------------------ fermer proprement, compiler, rouvrir
def _pids_editeur(nom_projet: str) -> list[int]:
    if os.name != "nt":
        return []
    from .connectors.base import SANS_FENETRE
    ps = ("Get-CimInstance Win32_Process -Filter \"Name = 'UnrealEditor.exe'\" | "
          f"Where-Object {{ $_.CommandLine -like '*{re.sub(r'[^A-Za-z0-9_-]', '', nom_projet)}*' }} | "
          "Select-Object -ExpandProperty ProcessId")
    try:
        r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", ps], capture_output=True,
                           text=True, timeout=30, stdin=subprocess.DEVNULL, **SANS_FENETRE)
        return [int(x) for x in r.stdout.split() if x.strip().isdigit()]
    except (OSError, subprocess.TimeoutExpired):
        return []


PIE_DEBUT = re.compile(r"PIE: Created PIE world")
PIE_FIN = re.compile(r"Shutting down PIE online subsystems|BeginTearingDown for \S*UEDPIE_")


def pie_en_cours(uproject: Path) -> bool:
    """Un PIE tourne dans l'éditeur de ce projet : son dernier début dans le journal est plus récent que sa dernière fin.
    Lecture seule de la fin de Saved/Logs/<projet>.log."""
    log = Path(uproject).parent / "Saved" / "Logs" / f"{Path(uproject).stem}.log"
    try:
        with log.open("rb") as f:
            f.seek(0, 2)
            f.seek(max(0, f.tell() - 4_000_000))
            texte = f.read().decode("utf-8", errors="replace")
    except OSError:
        return False
    debuts = [m.start() for m in PIE_DEBUT.finditer(texte)]
    fins = [m.start() for m in PIE_FIN.finditer(texte)]
    return bool(debuts) and debuts[-1] > (fins[-1] if fins else -1)


def fermer_editeur(nom_projet: str, noter, attente_s: float = 120) -> bool:
    """Ferme l'éditeur ouvert sur ce projet comme un clic sur sa croix (CloseMainWindow). JAMAIS de fermeture forcée :
    s'il reste des modifications non enregistrées, Unreal demande quoi faire et reste ouvert → False, rien n'est perdu."""
    pids = _pids_editeur(nom_projet)
    if not pids:
        noter("Unreal : éditeur déjà fermé")
        return True
    from .connectors.base import SANS_FENETRE
    ps = "; ".join(f"$p = Get-Process -Id {p} -ErrorAction SilentlyContinue; if ($p) {{ [void]$p.CloseMainWindow() }}" for p in pids)
    subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", ps], capture_output=True, text=True,
                   timeout=30, stdin=subprocess.DEVNULL, **SANS_FENETRE)
    noter("Unreal : fermeture demandée à l'éditeur (comme la croix de sa fenêtre)")
    debut = time.monotonic()
    while time.monotonic() - debut < attente_s:
        time.sleep(3)
        if not _pids_editeur(nom_projet):
            noter(f"Unreal : éditeur fermé après {int(time.monotonic() - debut)} s")
            return True
    noter("Unreal : l'éditeur est resté ouvert — il demande sans doute d'enregistrer des modifications. Rien n'a été "
          "forcé : réponds dans l'éditeur (ou ferme-le toi-même), puis relance la compilation.")
    return False


def commande_build(cfg: dict, uproject: Path, cible: str = "") -> list[str]:
    """Build.bat <Projet>Editor Win64 Development -project=… (moteur déduit du chemin d'UnrealEditor réglé)."""
    from pathlib import PureWindowsPath
    moteur = PureWindowsPath(str(chemin_editeur(cfg))).parents[2]          # …\Engine
    bat = moteur / "Build" / "BatchFiles" / "Build.bat"
    return [str(bat), cible or f"{uproject.stem}Editor", "Win64", "Development", f"-project={uproject}", "-waitmutex"]


def compiler(uproject: Path, cfg: dict, noter, cible: str = "", rouvrir: Path | None = None,
             journal: Path | None = None, delai_s: float = 3600) -> dict:
    """Ferme l'éditeur proprement, compile, puis (si ``rouvrir``) rouvre l'éditeur sur ce projet et attend unreal-mcp.
    Codes : 0 compilé ; 2 compilation en échec ; 3 éditeur resté ouvert (modifications à enregistrer) ; 4 outil absent ;
    5 un PIE tourne : rien n'est fermé (le studio n'arrête jamais un PIE)."""
    for up in {Path(uproject), *([Path(rouvrir)] if rouvrir else [])}:
        if editeur_ouvert(up.stem) and pie_en_cours(up):
            noter("Unreal : un PIE tourne dans l'éditeur — rien n'est fermé ni compilé. Arrêter le PIE d'abord (un agent : "
                  "seulement si Mel l'a autorisé), puis relancer la compilation.")
            return {"code": 5, "message": "un PIE tourne : l'éditeur n'a pas été fermé (arrêter le PIE d'abord)"}
    if not fermer_editeur(uproject.stem, noter) or (rouvrir and not fermer_editeur(Path(rouvrir).stem, noter)):
        return {"code": 3, "message": "éditeur resté ouvert (modifications non enregistrées ?) : rien n'a été forcé"}
    cmd = commande_build(cfg, uproject, cible)
    if os.name == "nt" and not Path(cmd[0]).exists():
        noter(f"Unreal : Build.bat introuvable ({cmd[0]})")
        return {"code": 4, "message": f"Build.bat introuvable : {cmd[0]}"}
    noter(f"Unreal : compilation de {cmd[1]} ({uproject.name})")
    from .connectors.base import SANS_FENETRE
    debut = time.monotonic()
    try:
        r = subprocess.run(cmd, cwd=str(uproject.parent), capture_output=True, text=True, encoding="utf-8",
                           errors="replace", timeout=delai_s, stdin=subprocess.DEVNULL, **SANS_FENETRE)
        sortie, code_build = (r.stdout or "") + (r.stderr or ""), r.returncode
    except subprocess.TimeoutExpired:
        sortie, code_build = "délai dépassé", -1
    except OSError as e:
        sortie, code_build = str(e), -1
    if journal:
        Path(journal).parent.mkdir(parents=True, exist_ok=True)
        Path(journal).write_text(sortie, encoding="utf-8")
    erreurs = [l.strip() for l in sortie.splitlines() if re.search(r"\berror\b|Result: Failed|Unable to build", l)][:12]
    ok = code_build == 0
    noter(f"Unreal : compilation {'réussie' if ok else 'en échec (code ' + str(code_build) + ')'} en {int(time.monotonic() - debut)} s")
    res = {"code": 0 if ok else 2, "message": "compilé" if ok else "compilation en échec", "erreurs": erreurs,
           "journal": str(journal or "")}
    if rouvrir:
        res["mcp"] = preparer(Path(rouvrir), cfg, noter)
    return res
