# Espace du studio de Mel

Ici vivent les données du studio : règles, skills, projets déclarés, tâches, mémoire et sauvegardes.
Le programme lui-même est installé ailleurs ; une mise à jour du studio ne touche jamais ce dossier.

- `Regles/` : règles communes des agents.
- `Skills/` : skills du studio (socle et packs).
- `Projets/`, `Sujets/` : ce que le studio suit. Tes projets restent à leur place.
- `Taches/` : un dossier par tâche (compte rendu, fichiers produits).
- `Sauvegardes/` : sauvegardes automatiques (une par jour) et copies avant chaque changement de réglage.
- `Studio/` : réglages (`studio.config.toml`), rôles des agents, décisions, base de données.
