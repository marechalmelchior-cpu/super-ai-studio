---
name: ajouter-projet-ou-sujet
description: Déclarer un nouveau projet ou sujet dans le studio sans modifier le code de l'orchestrateur.
---

# ajouter-projet-ou-sujet

- **Domaine** : studio

## Objectif
Rendre un projet ou sujet utilisable par le studio.

## Quand l'utiliser
Nouveau projet, nouveau dépôt, nouveau thème de travail.

## Prérequis
Chemin réel vérifié (projet) ; dépôt vérifié avant d'être inscrit.

## Étapes
1. `{{STUDIO_CMD}} projet-ajouter <id> "<Nom>" --chemin "<chemin>" --type <type>` ou `sujet-ajouter`.
2. Compléter `CONTEXTE.md` avec des faits vérifiés.
3. Laisser `application = "manuel"` et `isolation` par défaut tant que Mel n'a rien autorisé.

## Vérifications
- `{{STUDIO_CMD}} cibles` liste la nouvelle entrée.
- Aucun chemin ni version inventés.
