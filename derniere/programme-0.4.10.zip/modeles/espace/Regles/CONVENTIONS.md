# Conventions communes

- Identifiants de projets et sujets : minuscules, chiffres, `.`, `_`, `-` (ex. `mon-jeu`, `veille-ia`).
- Dates : ISO 8601 (UTC dans les fichiers techniques, heure de Paris dans les comptes rendus).
- Décisions : `Studio/Decisions/ADR-NNNN-titre.md` avec date, portée, statut (proposée / validée / remplacée), justification.
- Tâches du studio : `Taches/<date titre>/` (RESULTAT.md, diff, exécutions, export ChatGPT).
- Les projets restent à leur emplacement ; le studio y pointe via `Projets/<id>/project.toml`.
- Scripts Windows : PowerShell, UTF-8 avec BOM, lecture seule par défaut, `-Confirmer` pour toute action.
