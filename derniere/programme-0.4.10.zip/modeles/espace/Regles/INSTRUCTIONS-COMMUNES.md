# Instructions communes — tous les agents du studio

Source unique. Les points d'entrée propres à chaque outil (`CLAUDE.md`, `AGENTS.md`) renvoient ici ; ne pas les
modifier à la main.

## Rôles dans le studio
- Mel dirige : objectifs, arbitrages, validation finale.
- Le Superviseur trie les demandes et prépare les tâches ; les agents (Claude Code, Codex ou autre IA connectée)
  produisent ; le studio enchaîne les étapes, isole chaque tâche et fait relire le résultat.
- Mémoire durable partagée : base locale du studio, via le serveur MCP `studio-memoire`, portée obligatoire.

## Manière de travailler
- Français, style direct et concis.
- Lire les règles du projet avant d'agir (voir `Regles/PRIORITES.md`).
- Vérifier avant d'annoncer : un résultat est « fait » seulement avec une preuve (commande et sortie, fichier produit,
  journal). Distinguer **construit**, **testé**, **connecté**, **en attente**. Une simulation est nommée comme telle.
- Préserver le travail non enregistré de Mel : ne jamais écraser, réinitialiser ou supprimer sans demande explicite.
- Pas de push, publication, installation, service permanent ou démarrage automatique sans accord explicite.
- Aucune donnée secrète (clé, jeton, mot de passe, contenu privé de mémoire) dans les réponses, journaux, prompts
  enregistrés ou Git.

## Mémoire partagée
- Toujours indiquer une portée : `general`, `project:<id>`, `topic:<id>`, `task:<id>`.
- Outils MCP `studio-memoire` (`memoire_chercher`, `memoire_ajouter`, `memoire_corriger`, `memoire_conflits`,
  `memoire_etat`) ; en ligne de commande : `{{STUDIO_CMD}} memoire-chercher "<requête>" --portee project:<id>`.
- Si la mémoire est en panne : le dire, ne pas prétendre que l'information est partagée.

## Skills communs
Dans `Skills/` de l'espace du studio (copiés sous le préfixe `studio-` pour chaque outil). Charger uniquement ceux
utiles à la tâche.
