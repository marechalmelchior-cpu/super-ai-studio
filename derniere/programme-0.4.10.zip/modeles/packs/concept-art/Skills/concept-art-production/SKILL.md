---
name: concept-art-production
description: Produire des concept arts utilisables par de vrais artistes (fiches personnage A-pose et idle, objets, décors, palettes) avec le générateur d'images intégré de Codex, et le brief qui les accompagne. Pour toute demande de concept art, character sheet, turnaround, prop sheet ou paysage de jeu.
---

# concept-art-production

- **Domaine** : jeux et projets visuels. Rôles : `illustrateur` (images), `directeur-artistique` (briefs, relecture).
- **But** : des planches **de référence pour des artistes humains** (modeleurs, animateurs, peintres), pas des images finales.

## Règles communes à toutes les planches
1. Lire le CONTEXTE.md et le lore du projet (style, univers, contraintes). Aucun personnage, logo ou œuvre protégés ; aucun artiste vivant cité comme style ; les images de référence de tiers servent d'ambiance, jamais de modèle à copier.
2. Fond neutre uni (gris moyen), éclairage neutre et doux, pas d'effet dramatique sur les planches techniques ; perspective **orthographique** (ou très longue focale) pour les vues de face, profil et dos.
3. Cohérence entre vues : générer d'abord la **vue de face validée**, puis l'utiliser comme **image de référence** (mode édition / référence d'image_gen) pour profil, dos et 3/4. Vérifier chaque vue contre la face : silhouette, couleurs, accessoires, proportions. Refaire une vue incohérente plutôt que la livrer.
4. Noms versionnés : `<sujet>-<type>-v1.png` ; jamais d'écrasement. Chaque image retenue est copiée dans le dossier de la tâche.
5. Chaque planche a sa fiche dans `PLANCHE.md` (prompt exact, variantes, ce qui est validé, ce qui reste à l'artiste).

## Types de planches

### Personnage
- **A-pose turnaround** : face, profil gauche, dos, 3/4 avant — bras à ~45°, jambes légèrement écartées, mains ouvertes doigts visibles, regard droit, expression neutre ; même échelle et même ligne de sol sur toutes les vues ; barre d'échelle ou hauteur en cm indiquée dans la fiche.
- **Idle pose** : pose de repos caractéristique (poids sur une jambe, attitude du personnage), 3/4 avant, en pied.
- **Détails** : gros plans tête, mains, accessoires, matériaux (tissu, cuir, métal), avec annotations dans PLANCHE.md.
- **Expressions** (si demandé) : 4 à 6 visages même cadrage (neutre, joie, colère, peur, surprise, douleur).
- **Palette** : 6 à 8 couleurs nommées (hex) relevées sur la vue de face.

### Objet / accessoire (prop)
- Vues orthographiques face, profil, dessus + une vue 3/4 de présentation ; détails (ferrures, gravures, usure) en encarts ; dimensions en cm et matériaux dans la fiche ; états si utile (fermé/ouvert, neuf/abîmé).

### Décor / paysage
- **Keyframe** : plan large d'ambiance (heure, météo, lumière) au format 16:9.
- **Variantes de lumière** (jour, crépuscule, nuit) sur le même cadrage.
- **Vue de dessus schématique** (layout) pour le level design : chemins, points d'intérêt, zones de combat (chemin principal, raccourcis, zones de combat).
- **Éléments modulaires** : planche des pièces réutilisables (rochers, arbres, murs, sols) pour le kit 3D.

## Brief pour l'artiste (fichier BRIEF-ARTISTE.md, rédigé par `directeur-artistique` ou l'illustrateur)
- Ce qu'on attend (modèle 3D, texture, animation), usage en jeu, caméra (vue à la 3ᵉ personne, distance), plateforme.
- Contraintes techniques Unreal : échelle (1 unité = 1 cm), budget polygones indicatif, densité de texels, PBR (BaseColor/Normal/ORM), squelette (UE5 Manny/Quinn ou propre), LOD.
- Références : les planches de cette tâche + ce qui est **validé** vs **à interpréter**.
- Livrables attendus, formats (FBX/GLB, textures PNG/TGA), conventions de nommage du projet, calendrier si connu.
- Droits : cession ou licence à préciser (à valider par Mel) ; pas d'asset tiers sans licence compatible.

## Vérifications
- Toutes les vues d'un personnage cohérentes entre elles (vérification écrite par vue dans PLANCHE.md).
- Aucune ressemblance avec un personnage ou une œuvre protégés (dire honnêtement si un doute existe).
- Les planches sont des **références** : le dire dans le brief (les mains, le texte et les petits détails générés peuvent être faux).
