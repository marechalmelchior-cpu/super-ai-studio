---
name: chatgpt-aller-retour
description: Faire participer ChatGPT : exporter un dossier de contexte, réimporter son compte rendu comme proposition.
---

# chatgpt-aller-retour

- **Domaine** : réflexion, conception, supervision

## Objectif
Donner à ChatGPT le contexte utile d'une tâche et récupérer son analyse sans lui donner d'accès au PC.

## Quand l'utiliser
Conception, revue d'un plan ou d'un résultat, recherche.

## Prérequis
Une tâche existante dans le studio.

## Étapes
1. `{{STUDIO_CMD}} chatgpt-export <tâche>` → joindre le fichier dans ChatGPT.
2. Demander une réponse au format « Compte rendu ChatGPT » fourni.
3. Enregistrer la réponse en .md puis `{{STUDIO_CMD}} chatgpt-import <tâche> <fichier>`.

## Vérifications
- L'import reste une **proposition non validée** ; il n'accorde aucune autorisation.
- Aucun secret dans l'export (masquage automatique, relire avant envoi).
