"""Connections to AIs: subscription tools, API key (cloud providers) or local AI (e.g. Ollama, LM Studio).

All key-based or local AIs go through the same "chat completions" interface (OpenAI format, which all these
providers accept). Keys are encrypted by Windows (DPAPI, current account) in data/connexions.json, never
displayed, never written to a log or a prompt. Nothing is sent anywhere but to the chosen provider.
"""
from __future__ import annotations

import base64
import json
import re
import secrets
import sys
import threading
import urllib.error
import urllib.request
from pathlib import Path

PROVIDERS: dict[str, dict] = {
    "openai": {"nom": "OpenAI (GPT, par clé API)", "url": "https://api.openai.com/v1", "cle": True, "conseil": "gpt-4.1"},
    "anthropic": {"nom": "Anthropic (Claude)", "url": "https://api.anthropic.com/v1", "cle": True, "conseil": "claude-sonnet"},
    "gemini": {"nom": "Google Gemini", "url": "https://generativelanguage.googleapis.com/v1beta/openai", "cle": True, "conseil": "gemini-2.5-flash"},
    "mistral": {"nom": "Mistral", "url": "https://api.mistral.ai/v1", "cle": True, "conseil": "mistral-large-latest"},
    "openrouter": {"nom": "OpenRouter (beaucoup de modèles, une clé)", "url": "https://openrouter.ai/api/v1", "cle": True, "conseil": ""},
    "deepseek": {"nom": "DeepSeek", "url": "https://api.deepseek.com/v1", "cle": True, "conseil": "deepseek-chat"},
    "groq": {"nom": "Groq", "url": "https://api.groq.com/openai/v1", "cle": True, "conseil": ""},
    "xai": {"nom": "xAI (Grok)", "url": "https://api.x.ai/v1", "cle": True, "conseil": "grok"},
    "moonshot": {"nom": "Moonshot (Kimi)", "url": "https://api.moonshot.ai/v1", "cle": True, "conseil": "kimi"},
    "autre": {"nom": "Autre IA (compatible OpenAI : adresse + clé)", "url": "", "cle": False, "conseil": ""},
    "elevenlabs": {"nom": "ElevenLabs (voix)", "url": "https://api.elevenlabs.io/v1", "cle": True, "conseil": "", "seulement": "voix"},
    "ollama": {"nom": "Ollama (IA locale)", "url": "http://127.0.0.1:11434/v1", "cle": False, "conseil": "qwen2.5-coder"},
    "lmstudio": {"nom": "LM Studio (IA locale)", "url": "http://127.0.0.1:1234/v1", "cle": False, "conseil": ""},
}
_lock = threading.Lock()


class AIError(RuntimeError):
    pass


# ------------------------------------------------------------------ storage (encrypted keys)
def _file(data: Path) -> Path:
    return Path(data) / "connexions.json"


def _encrypt(cle: str) -> str:
    from .vault import encrypt
    return encrypt(cle)


def _decrypt(v: str) -> str:
    from .vault import decrypt
    return decrypt(v)


def read_file(data: Path) -> dict:
    try:
        d = json.loads(_file(data).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        d = {}
    d.setdefault("connexions", [])
    d.setdefault("superviseur", "")
    d.setdefault("agents", "")
    return d


def _write(data: Path, d: dict) -> None:
    f = _file(data)
    f.parent.mkdir(parents=True, exist_ok=True)
    t = f.with_suffix(".partiel")
    t.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
    t.replace(f)


def public(data: Path) -> dict:
    """For the UI: never the key, only « clé enregistrée »."""
    d = read_file(data)
    return {"connexions": [{"id": c["id"], "fournisseur": c["fournisseur"], "nom": PROVIDERS.get(c["fournisseur"], {}).get("nom", c["fournisseur"]),
                            "modele": c.get("modele", ""), "url": c.get("url", ""), "cle": bool(c.get("cle"))} for c in d["connexions"]],
            "superviseur": d["superviseur"], "agents": d["agents"],
            "fournisseurs": [{"id": k, **{x: v[x] for x in ("nom", "cle", "conseil")}} for k, v in PROVIDERS.items()]}


def safe_address(url: str) -> bool:
    """https to any host, or http only to this PC (127.0.0.1, localhost, ::1)."""
    from urllib.parse import urlparse
    try:
        u = urlparse(url)
    except ValueError:
        return False
    if u.scheme == "https" and u.hostname:
        return True
    return u.scheme == "http" and u.hostname in ("127.0.0.1", "localhost", "::1")


def add_item(data: Path, provider: str, cle: str = "", modele: str = "", url: str = "") -> dict:
    if provider not in PROVIDERS:
        raise ValueError("Fournisseur inconnu.")
    f = PROVIDERS[provider]
    cle = (cle or "").strip()
    if f["cle"] and not cle:
        raise ValueError("Colle ta clé API.")
    if provider == "autre" and not (url or "").strip():
        raise ValueError("Indique l'adresse de l'IA (ex. https://api.exemple.com/v1).")
    if url and not safe_address(url):
        raise ValueError("Adresse refusée : https, ou une IA locale sur 127.0.0.1.")
    c = {"id": f"{provider}-{secrets.token_hex(3)}", "fournisseur": provider, "modele": modele.strip(),
         "url": url.strip(), "cle": _encrypt(cle) if cle else ""}
    model_list = list_models(c)                         # check the key before saving (clear error otherwise)
    if not c["modele"] and model_list:
        c["modele"] = choose_advice(provider, model_list)
    with _lock:
        d = read_file(data)
        d["connexions"].append(c)
        if not f.get("seulement"):                          # a voice-only AI never becomes the Supervisor
            d["superviseur"] = d["superviseur"] or c["id"]
            d["agents"] = d["agents"] or c["id"]
        _write(data, d)
    return {"id": c["id"], "modeles": model_list, "modele": c["modele"]}


def modify(data: Path, ident: str, **field_values) -> None:
    with _lock:
        d = read_file(data)
        for k in ("superviseur", "agents"):
            if k in field_values:
                v = str(field_values[k] or "")
                if v and v not in ("claude-code", "codex") and v not in {c["id"] for c in d["connexions"]}:
                    raise ValueError("Connexion inconnue.")
                d[k] = v
        if ident and "modele" in field_values:
            for c in d["connexions"]:
                if c["id"] == ident:
                    c["modele"] = str(field_values["modele"] or "")
        _write(data, d)


def retire(data: Path, ident: str) -> None:
    with _lock:
        d = read_file(data)
        d["connexions"] = [c for c in d["connexions"] if c["id"] != ident]
        for k in ("superviseur", "agents"):
            if d[k] == ident:
                d[k] = d["connexions"][0]["id"] if d["connexions"] else ""
        _write(data, d)


def connection(data: Path, ident: str) -> dict | None:
    return next((c for c in read_file(data)["connexions"] if c["id"] == ident), None)


# ------------------------------------------------------------------ HTTP calls (chat completions format)
def _base(c: dict) -> str:
    return (c.get("url") or PROVIDERS[c["fournisseur"]]["url"]).rstrip("/")


def _headers(c: dict) -> dict:
    h = {"Content-Type": "application/json", "User-Agent": "SuperAIStudio"}
    cle = _decrypt(c.get("cle", ""))
    if cle:
        h["Authorization"] = f"Bearer {cle}"
        if c["fournisseur"] == "anthropic":
            h["x-api-key"] = cle
            h["anthropic-version"] = "2023-06-01"
        elif c["fournisseur"] == "elevenlabs":
            h["xi-api-key"] = cle
    return h


def _ollama_closed(c: dict, e: Exception) -> bool:
    """Connection refused by this PC's Ollama (closed): the request never arrived, so it can be started and retried."""
    from urllib.parse import urlparse
    reason = getattr(e, "reason", e)
    return (c.get("fournisseur") == "ollama" and isinstance(reason, ConnectionRefusedError)
            and (urlparse(_base(c)).hostname or "") in ("127.0.0.1", "localhost", "::1"))


def _request(c: dict, chemin: str, content_body: dict | None = None, delay: float = 300, _retry: bool = True) -> dict:
    req = urllib.request.Request(_base(c) + chemin, headers=_headers(c), method="POST" if content_body is not None else "GET",
                                 data=json.dumps(content_body).encode() if content_body is not None else None)
    try:
        with urllib.request.urlopen(req, timeout=delay) as r:
            raw_text = r.read() or b"{}"
        try:
            d = json.loads(raw_text)
        except ValueError:
            raise AIError(f"{PROVIDERS[c['fournisseur']]['nom']} : réponse illisible") from None
        return d if isinstance(d, dict) else {"data": d}
    except urllib.error.HTTPError as e:
        try:
            detail = json.loads(e.read() or b"{}")
            if isinstance(detail, list):                     # Gemini: [{"error": {...}}]
                detail = detail[0] if detail and isinstance(detail[0], dict) else {}
            err = detail.get("error") if isinstance(detail, dict) else None
            msg = err.get("message") if isinstance(err, dict) else (err or "")
        except (ValueError, AttributeError):
            msg = ""
        from .security import redact
        texte = {401: "clé refusée", 403: "accès refusé", 404: "adresse ou modèle introuvable", 429: "limite atteinte (quota)"}.get(e.code, f"erreur {e.code}")
        raise AIError(f"{PROVIDERS[c['fournisseur']]['nom']} : {texte}" + (f" — {redact(str(msg))[:200]}" if msg else "")) from None
    except (urllib.error.URLError, OSError, TimeoutError) as e:
        if _retry and _ollama_closed(c, e):
            from . import local_models
            if local_models.assurer():                       # Ollama is started when it is needed
                return _request(c, chemin, content_body, delay, _retry=False)
        local = not PROVIDERS[c["fournisseur"]]["cle"]
        raise AIError(f"{PROVIDERS[c['fournisseur']]['nom']} ne répond pas"
                       + (" : lance-le sur ce PC." if local else f" ({type(e).__name__}).")) from None


def list_models(c: dict) -> list[str]:
    d = _request(c, "/models", delay=20)
    ids = [str(m.get("id") or m.get("model_id") or "") for m in (d.get("data") or d.get("models") or []) if isinstance(m, dict)]
    return sorted({i.removeprefix("models/") for i in ids if i})


def choose_advice(provider: str, model_list: list[str]) -> str:
    advice = PROVIDERS[provider]["conseil"]
    return next((m for m in model_list if advice and m.startswith(advice)), model_list[0] if model_list else "")


FAMILIES = {"openai": "OpenAI (clé API)", "anthropic": "Anthropic (clé API)", "gemini": "Gemini", "mistral": "Mistral",
            "openrouter": "OpenRouter", "deepseek": "DeepSeek", "groq": "Groq", "xai": "xAI (Grok)", "moonshot": "Moonshot (Kimi)",
            "ollama": "Ollama (local)", "lmstudio": "LM Studio (local)"}


def family(c: dict) -> str:
    """AI name in Gestion › Usage (the subscription tools keep their own names)."""
    if c.get("fournisseur") == "autre":                 # custom AI: named after its address; local = free
        from urllib.parse import urlparse
        host = urlparse(c.get("url", "")).hostname or "IA"
        return f"{host} (local)" if host in ("127.0.0.1", "localhost", "::1") else host
    return FAMILIES.get(c.get("fournisseur", ""), c.get("fournisseur", "") or "IA connectée")


# ------------------------------------------------------------------ Ollama: native API (context size set)
_contexts: dict[str, int] = {}


def _ollama_host(c: dict) -> str:
    b = _base(c)
    return b[:-3] if b.endswith("/v1") else b


def max_context(c: dict) -> int:
    """Maximum context of the local model (read once per model from Ollama); 0 if unknown."""
    m = c.get("modele", "")
    if m in _contexts:
        return _contexts[m]
    n = 0
    if c.get("fournisseur") == "ollama":
        try:
            req = urllib.request.Request(_ollama_host(c) + "/api/show", data=json.dumps({"model": m}).encode(),
                                         headers={"Content-Type": "application/json"}, method="POST")
            with urllib.request.urlopen(req, timeout=10) as r:
                info = json.loads(r.read() or b"{}").get("model_info") or {}
            n = max((int(v) for k, v in info.items() if k.endswith(".context_length") and isinstance(v, (int, float))), default=0)
        except (OSError, ValueError):
            n = 0
    if n:                                               # Ollama closed: ask again next time
        _contexts[m] = n
    return n


def _chat_ollama(c: dict, messages: list[dict], allowed_tools: list[dict] | None, delay: float, context: int, effort: str = "") -> dict:
    """Ollama's native API (/api/chat): the only way to choose the context size (num_ctx). Without this setting,
    Ollama keeps its small default context and cuts the start of the mission WITHOUT WARNING. Same return format
    as "chat completions"."""
    names = {}
    natives = []
    for m in messages:
        m = dict(m)
        if m.get("role") == "assistant" and m.get("tool_calls"):
            api_calls = []
            for a in m["tool_calls"]:
                f = a.get("function") or {}
                args = f.get("arguments")
                if isinstance(args, str):
                    try:
                        args = json.loads(args or "{}")
                    except ValueError:
                        args = {}
                names[a.get("id", "")] = f.get("name", "")
                api_calls.append({"function": {"name": f.get("name", ""), "arguments": args or {}}})
            m["tool_calls"] = api_calls
        elif m.get("role") == "tool":
            m = {"role": "tool", "content": m.get("content", ""), "tool_name": names.get(m.get("tool_call_id", ""), "")}
        natives.append(m)
    content_body = {"model": c["modele"], "messages": natives, "stream": False, "keep_alive": "10m"}
    if allowed_tools:
        content_body["tools"] = allowed_tools
    if effort and (c.get("fournisseur"), c.get("modele")) not in _without_effort:   # reasoning models (Qwen3, DeepSeek-R1…)
        content_body["think"] = effort != "low"
    if context:
        content_body["options"] = {"num_ctx": int(context)}
    host = {**c, "url": _ollama_host(c)}
    d = _request(host, "/api/chat", content_body, delay)
    msg = d.get("message") or {}
    api_calls = [{"id": f"appel_{i}", "type": "function", "function": {"name": (a.get("function") or {}).get("name", ""),
                                                                   "arguments": json.dumps((a.get("function") or {}).get("arguments") or {}, ensure_ascii=False)}}
              for i, a in enumerate(msg.get("tool_calls") or [])]
    return {"message": {"role": "assistant", "content": msg.get("content") or "", **({"tool_calls": api_calls} if api_calls else {})},
            "usage": {"prompt_tokens": int(d.get("prompt_eval_count") or 0), "completion_tokens": int(d.get("eval_count") or 0)},
            "fin": d.get("done_reason", "")}


# Effort levels each AI understands, with ITS own names (internal value → displayed label). Empty list: not adjustable.
_THREE = [("low", "Bas (low)"), ("medium", "Moyen (medium)"), ("high", "Élevé (high)")]
AI_EFFORTS: dict[str, list[tuple[str, str]]] = {
    "claude-code": [*_THREE, ("xhigh", "Très élevé (xhigh)"), ("max", "Max (max)")],
    "codex": [*_THREE, ("xhigh", "Très élevé (xhigh)")],
    "openai": _THREE, "gemini": _THREE, "openrouter": _THREE, "autre": _THREE,
    "xai": [("low", "Bas (low)"), ("high", "Élevé (high)")],
    "ollama": [("low", "Sans réflexion"), ("high", "Avec réflexion (think)")],
}


def efforts_for(actor: str) -> list[tuple[str, str]]:
    """``claude-code``, ``codex`` or a provider (openai, gemini, ollama…)."""
    return AI_EFFORTS.get(actor, [])


_powerful: dict[str, tuple[float, str]] = {}


def strongest_model(c: dict) -> str:
    """Max / Performance mode: among this AI's models, the best ranked one (« global » ranking); empty if unknown."""
    import time as _t
    k = c.get("id", "")
    if k in _powerful and _t.time() - _powerful[k][0] < 3600:
        return _powerful[k][1]
    try:
        from .agents import _normalize, benchmarks
        scores: dict[str, float] = {}
        for m in benchmarks()["modeles"]:
            if m.get("categorie") == "global" and m.get("score") is not None:
                for nom in {m.get("cle", ""), m.get("ollama", "")} - {""}:
                    scores[_normalize(nom)] = max(scores.get(_normalize(nom), 0), float(m["score"]))
        jot = lambda x: scores.get(_normalize(x.split("/")[-1].removesuffix(":free")), -1)   # noqa: E731
        best = max(list_models(c), key=jot, default="")
        choice = best if best and jot(best) >= 0 else ""
    except Exception:                                   # noqa: BLE001 — no list or ranking: the connection's model
        choice = ""
    _powerful[k] = (_t.time(), choice)
    return choice


_without_effort: set[tuple] = set()                       # models that reject the effort setting: not asked again
_API_LEVEL = {"low": "low", "medium": "medium", "high": "high", "xhigh": "high", "max": "high"}


def discuss(c: dict, messages: list[dict], allowed_tools: list[dict] | None = None, delay: float = 300, context: int = 0,
             effort: str = "") -> dict:
    """One conversation turn; returns the AI's message (content, tool_calls) and the usage.
    contexte: context size to reserve (local Ollama models; ignored elsewhere).
    effort: reasoning depth (low | medium | high…) translated for each provider that supports it
    (OpenRouter for all its models, OpenAI, Gemini, Ollama "think"); a model that rejects it is retried without."""
    effort = _API_LEVEL.get(effort, "")
    if effort and (c.get("fournisseur"), c.get("modele")) not in _without_effort:
        try:
            return _chat(c, messages, allowed_tools, delay, context, effort)
        except AIError as e:
            if not re.search(r"reason|think|effort|unsupported|not support|unknown|invalid|400", str(e), re.I):
                raise
            _without_effort.add((c.get("fournisseur"), c.get("modele")))
    return _chat(c, messages, allowed_tools, delay, context, "")


def _chat(c: dict, messages: list[dict], allowed_tools: list[dict] | None, delay: float, context: int, effort: str) -> dict:
    if not c.get("modele"):
        raise AIError("Aucun modèle choisi pour cette connexion (Accueil › Réglages › IA).")
    if c.get("fournisseur") == "ollama":
        if not context:                                # Supervisor, one-off calls: just what is needed, in steps
            size = sum(len(str(m.get("content") or "")) for m in messages) + len(json.dumps(allowed_tools or []))
            context = min(max_context(c) or 32768, 32768, max(8192, -(-(size // 3 + 4096) // 4096) * 4096))
        return _chat_ollama(c, messages, allowed_tools, delay, context, effort)
    content_body: dict = {"model": c["modele"], "messages": messages}
    if allowed_tools:
        content_body["tools"] = allowed_tools
    if effort:
        if c.get("fournisseur") == "openrouter":
            content_body["reasoning"] = {"effort": effort}
        elif c.get("fournisseur") in ("openai", "gemini", "xai", "autre"):
            content_body["reasoning_effort"] = effort          # rejected by a model: retried without it (see discuter)
    if c.get("fournisseur") == "openrouter":            # OpenRouter then returns the actual cost of the call (usage.cost)
        content_body["usage"] = {"include": True}
    d = _request(c, "/chat/completions", content_body, delay)
    choice = (d.get("choices") or [{}])[0]
    return {"message": choice.get("message") or {}, "usage": d.get("usage") or {}, "fin": choice.get("finish_reason", "")}


def _raw(c: dict, chemin: str, content_body: dict, delay: float = 300) -> bytes:
    req = urllib.request.Request(_base(c) + chemin, headers=_headers(c), method="POST", data=json.dumps(content_body).encode())
    try:
        with urllib.request.urlopen(req, timeout=delay) as r:
            return r.read()
    except urllib.error.HTTPError as e:
        raise AIError(f"{PROVIDERS[c['fournisseur']]['nom']} : erreur {e.code} ({chemin})") from None
    except (urllib.error.URLError, OSError, TimeoutError) as e:
        raise AIError(f"{PROVIDERS[c['fournisseur']]['nom']} ne répond pas ({type(e).__name__}).") from None


# ------------------------------------------------------------------ images and voice: any AI that can do it
CAPABLE_PROVIDERS = {"image": ("openai", "gemini", "xai", "openrouter", "autre"),
            "voix": ("openai", "elevenlabs", "groq", "autre")}
_NAME_PATTERNS = {"image": ("gpt-image", "imagen", "flash-image", "image", "dall-e", "flux", "sdxl", "stable-diffusion"),
           "voix": ("tts", "speech", "eleven", "voice", "kokoro")}


def _model_for(c: dict, genre: str) -> str:
    if c.get(f"modele_{genre}"):
        return c[f"modele_{genre}"]
    try:
        names = list_models(c)
    except AIError:
        names = []
    for pattern in _NAME_PATTERNS[genre]:
        found = sorted((m for m in names if pattern in m.lower()), reverse=True)
        if found:
            return found[0]
    return {("openai", "image"): "gpt-image-1", ("gemini", "image"): "imagen-4.0-generate-001", ("xai", "image"): "grok-2-image",
            ("openrouter", "image"): "google/gemini-2.5-flash-image", ("openai", "voix"): "gpt-4o-mini-tts",
            ("elevenlabs", "voix"): "eleven_multilingual_v2"}.get((c.get("fournisseur"), genre), "")


def image_model(c: dict) -> str:
    return _model_for(c, "image")


def connection_for(data: Path, genre: str, preferred: dict | None = None) -> dict | None:
    """Connection able to produce this kind (« image » or « voix »): the agent's if it can, otherwise the
    first connected one that can. As permissive as possible: any OpenAI-compatible AI (cloud or local) is tried."""
    if preferred and preferred.get("fournisseur") in CAPABLE_PROVIDERS[genre]:
        return preferred
    return next((c for c in read_file(data)["connexions"] if c["fournisseur"] in CAPABLE_PROVIDERS[genre]), None)


def _image_bytes(item: dict) -> bytes:
    if item.get("b64_json"):
        return base64.b64decode(item["b64_json"])
    url = str(item.get("url") or (item.get("image_url") or {}).get("url") or "")
    if url.startswith("data:image") and "," in url:
        return base64.b64decode(url.split(",", 1)[1])
    if url.startswith("https://"):
        with urllib.request.urlopen(url, timeout=120) as r:
            return r.read()
    raise AIError("Aucune image renvoyée.")


def generate_image(c: dict, prompt: str, size: str = "1024x1024") -> bytes:
    """PNG image generated by the connected AI: OpenAI, Gemini, xAI, OpenRouter (image models through chat), or
    any OpenAI-compatible AI (/images/generations, e.g. LocalAI on the PC). Nothing is published."""
    modele = image_model(c)
    if c.get("fournisseur") == "openrouter":            # OpenRouter: image models through chat
        d = _request(c, "/chat/completions", {"model": modele, "messages": [{"role": "user", "content": prompt[:4000]}],
                                              "modalities": ["image", "text"]}, 300)
        images = ((d.get("choices") or [{}])[0].get("message") or {}).get("images") or []
        if not images:
            raise AIError("Ce modèle n'a pas renvoyé d'image : choisis un modèle d'image (OpenRouter).")
        return _image_bytes(images[0])
    content_body = {"model": modele, "prompt": prompt[:4000], "n": 1}
    if c.get("fournisseur") != "xai":
        content_body["size"] = size
    if not str(modele).startswith("gpt-image"):
        content_body["response_format"] = "b64_json"
    d = json.loads(_raw(c, "/images/generations", content_body) or b"{}")
    return _image_bytes((d.get("data") or [{}])[0])


def generate_voice(c: dict, texte: str, voice: str = "") -> bytes:
    """Text-to-speech MP3 file: OpenAI, Groq, ElevenLabs, or any OpenAI-compatible AI (/audio/speech,
    e.g. a local voice server)."""
    if c.get("fournisseur") == "elevenlabs":
        if not voice:
            voice = (_request(c, "/voices", delay=20).get("voices") or [{}])[0].get("voice_id", "")
        if not voice:
            raise AIError("ElevenLabs : aucune voix disponible sur ce compte.")
        return _raw(c, f"/text-to-speech/{voice}", {"text": texte[:5000], "model_id": _model_for(c, "voix")})
    return _raw(c, "/audio/speech", {"model": _model_for(c, "voix"), "voice": voice or "alloy", "input": texte[:4000],
                                      "response_format": "mp3"})


def detect_local_models() -> list[str]:
    """Local AIs answering right now (nothing is started or installed)."""
    out = []
    for k in ("ollama", "lmstudio"):
        try:
            with urllib.request.urlopen(PROVIDERS[k]["url"] + "/models", timeout=1):
                out.append(k)
        except OSError:
            pass
    return out


# ------------------------------------------------------------------ who answers: Supervisor and agents
def choice(studio, audience: str) -> tuple[str, dict | None]:
    """("claude-code" | "codex" | "api" | "", connection) for « superviseur » or « agents ».
    Explicit setting first; otherwise the subscription tool (claude-code) if installed; otherwise the first connection."""
    d = read_file(studio.paths.data)
    v = d.get(audience, "")
    if v in ("claude-code", "codex"):
        return v, None
    if v:
        c = next((x for x in d["connexions"] if x["id"] == v), None)
        if c:
            return "api", c
    from .connectors.claude_code import WIN_CANDIDATES
    from .connectors.base import find_exe
    if find_exe(studio.cfg["outils"].get("claude", "claude"), WIN_CANDIDATES):
        return "claude-code", None
    if d["connexions"]:
        return "api", d["connexions"][0]
    return "", None


def call_supervisor(studio, c: dict, instruction: str, message: str) -> tuple[bool, str, dict]:
    from .user_workspace import custom
    try:
        r = discuss(c, [{"role": "system", "content": custom(instruction)}, {"role": "user", "content": custom(message)}],
                     delay=float(studio.cfg.get("superviseur", {}).get("delai_s", 300)))
    except AIError as e:
        return False, str(e), {}
    texte = r["message"].get("content") or ""
    if isinstance(texte, list):                         # some providers return blocks
        texte = "".join(b.get("text", "") for b in texte if isinstance(b, dict))
    return bool(texte.strip()), texte or "Réponse vide.", {"jetons": r["usage"], "appel": True, "modele": c["modele"],
                                                           "famille": family(c), "cout_usd": (r["usage"] or {}).get("cost")}
