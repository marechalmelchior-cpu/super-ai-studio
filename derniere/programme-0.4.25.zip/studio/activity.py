"""Live activity of a task, in plain French: what the agent is doing, files touched, applications open.

- actions: the feed recorded by the guard (details/activite.log: commands, actions in Unreal, modified files),
  turned into short sentences (« Compile le projet », « Modifie EnemyBase.cpp »);
- files: the git state of the working copy (everything that changed, scripts included), otherwise the activity feed;
- applications: Unreal, Blender and whatever the agent launched, with their status (open, building, closed…).
Read-only, nothing is ever launched or closed here. No command line is shown as is.
"""
from __future__ import annotations

import os
import re
import subprocess
import time
from pathlib import Path

# ------------------------------------------------------------------ actions in plain words
_RULES = [
    (r"unreal_compiler\.py", "Ferme Unreal, compile le projet et le rouvre"),
    (r"Build\.bat|UnrealBuildTool|RunUAT", "Compile le projet"),
    (r"run_in_editor\.py\s+\S*?([\w-]+)\.py", lambda m: f"Lance le script « {m.group(1)} » dans Unreal"),
    (r"UnrealEditor(-Cmd)?(\.exe)?", "Lance Unreal"),
    (r"blender(\.exe)?[\"']?\s.*(--background|\s-b\s)", "Lance Blender en arrière-plan"),
    (r"blender(\.exe)?\b", "Ouvre Blender"),
    (r"\bgit\s+(diff|status|log|show)\b", "Regarde les changements"),
    (r"\bpytest\b", "Lance les tests"),
    (r"(?:\bpython3?|\bpy)(?:\.exe)?\s+(?:-\S+\s+)*\S*?([\w-]+)\.py", lambda m: f"Lance le script « {m.group(1)} »"),
    (r"\b(mkdir|New-Item)\b", "Crée un dossier"),
    (r"\b(cp|copy|Copy-Item|mv|move|Move-Item)\b", "Copie ou déplace des fichiers"),
    (r"\b(grep|rg|sed\s+-n|cat|head|tail|ls|find|Get-Content|Select-String|Get-ChildItem|type|dir|wc)\b", "Lit des fichiers"),
]
_UNREAL = [
    (r"list_toolsets|describe_toolset", "regarde les outils disponibles"),
    (r"load_level|open_level", "ouvre un niveau"), (r"save", "enregistre"), (r"spawn", "place un acteur"),
    (r"delete|destroy|remove", "supprime un élément"), (r"screenshot|capture", "fait une capture"),
    (r"(play|pie|simulate)", "lance le jeu (PIE)"), (r"compile", "compile un Blueprint"),
    (r"set_|update|modify|edit", "modifie un élément"), (r"create|add_", "crée un élément"),
    (r"get_|list_|find|describe|search|query|read|snapshot|inspect", "lit l'état de l'éditeur"),
]


def _command(cmd: str) -> str:
    c = re.sub(r"^\s*(cd\s+(\"[^\"]*\"|'[^']*'|\S+)\s*(&&|;)\s*)+", "", cmd)        # « cd folder && … »: not interesting
    c = re.sub(r"^\s*\$\w+\s*=\s*[^;]+;\s*", "", c)
    for pattern, output in _RULES:
        m = re.search(pattern, c, re.I)
        if m:
            return output(m) if callable(output) else output
    word = (c.split() or ["commande"])[0].strip("&\"'")
    return f"Lance une commande ({Path(word).name[:30]})"


def _unreal(texte: str) -> str:
    genre, _, action = texte.partition("  ")
    nom = action.split(".")[-1]
    for pattern, output in _UNREAL:
        if re.search(pattern, nom, re.I):
            return f"Dans Unreal : {output}"
    return f"Dans Unreal : {nom.replace('_', ' ')}"


def phrase(genre: str, texte: str, base: Path | None = None) -> str:
    if genre == "fichier":
        verb, _, chemin = texte.partition("  ")
        return f"{'Crée' if verb == 'crée' else 'Modifie'} {Path(chemin.replace(chr(92), '/')).name}"
    if genre == "unreal":
        return _unreal(texte)
    nom = lambda t: Path(t.replace(chr(92), "/")).name or t
    simple_kinds = {"lit": lambda t: f"Lit {nom(t)}", "liste": lambda t: "Parcourt les dossiers" if t in ("", ".") else f"Parcourt {nom(t)}",
               "cherche": lambda t: f"Cherche « {t[:40]} » dans le projet", "image": lambda t: f"Génère l'image {nom(t)}",
               "voix": lambda t: f"Génère la voix {nom(t)}", "pense": lambda t: f"Démarre ({t})" if t else "Démarre",
               "fin": lambda t: "Écrit son compte rendu"}
    if genre in simple_kinds:
        return simple_kinds[genre](texte)
    if genre == "refus":
        return f"Commande refusée par le studio : {_command(texte).lower()}"
    return _command(texte)


def actions(details: Path, n: int = 5) -> list[dict]:
    f = details / "activite.log"
    if not f.exists():
        return []
    try:
        rows = f.read_text(encoding="utf-8", errors="replace").splitlines()[-200:]
    except OSError:
        return []
    out = []
    for l in rows:
        p = l.split("\t", 2)
        if len(p) < 3:
            continue
        texte = phrase(p[1], p[2])
        if out and out[-1]["texte"] == texte:                 # « Lit des fichiers » ×10: a single line
            out[-1]["fois"] += 1
            out[-1]["heure"] = p[0]
            continue
        out.append({"heure": p[0], "texte": texte, "genre": p[1], "fois": 1})
    return out[-n:][::-1]


# ------------------------------------------------------------------ files touched
_CACHES = (".mission-", ".studio-", "_pieces/", "Saved/", "Intermediate/", "Binaries/", "DerivedDataCache/")


def task_files(work: Path, details: Path, git: str = "git") -> list[dict]:
    out: dict[str, str] = {}
    if (work / ".git").exists():
        try:
            from .connectors.base import NO_WINDOW
            r = subprocess.run([git, "-C", str(work), "status", "--porcelain=v1", "-z", "--untracked-files=all"],
                               capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=20,
                               stdin=subprocess.DEVNULL, **NO_WINDOW)
            chunks, i = r.stdout.split("\0"), 0
            while i < len(chunks):
                m = chunks[i]; i += 1
                if len(m) < 4:
                    continue
                if m[0] in "RC":
                    i += 1
                xy, chemin = m[:2], m[3:]
                out[chemin] = "nouveau" if xy == "??" or "A" in xy else "supprimé" if "D" in xy else "modifié"
        except (OSError, subprocess.TimeoutExpired):
            pass
    if not out and (details / "activite.log").exists():
        base = str(work).replace("\\", "/").rstrip("/") + "/"
        for l in (details / "activite.log").read_text(encoding="utf-8", errors="replace").splitlines():
            p = l.split("\t", 2)
            if len(p) == 3 and p[1] == "fichier":
                verb, _, chemin = p[2].partition("  ")
                chemin = chemin.replace("\\", "/")
                rel = chemin[len(base):] if chemin.lower().startswith(base.lower()) else Path(chemin).name
                out[rel] = "nouveau" if verb == "crée" and rel not in out else out.get(rel, "modifié")
    return [{"chemin": k, "etat": v} for k, v in out.items() if not any(c in k for c in _CACHES)][:40]


# ------------------------------------------------------------------ open applications
_APPS = {"unrealeditor.exe": "Unreal Editor", "unrealeditor-cmd.exe": "Unreal (sans fenêtre)", "blender.exe": "Blender",
         "unrealbuildtool.exe": "Compilation Unreal", "devenv.exe": "Visual Studio", "code.exe": "VS Code",
         "photoshop.exe": "Photoshop", "krita.exe": "Krita", "gimp.exe": "GIMP", "substancepainter.exe": "Substance Painter",
         "houdini.exe": "Houdini", "maya.exe": "Maya", "audacity.exe": "Audacity", "obs64.exe": "OBS"}
_TOOLS = {"cmd.exe", "conhost.exe", "powershell.exe", "pwsh.exe", "bash.exe", "sh.exe", "node.exe", "python.exe",
           "pythonw.exe", "py.exe", "git.exe", "claude.exe", "codex.exe", "rg.exe", "uv.exe", "npx.exe", "npm.exe",
           "timeout.exe", "find.exe", "findstr.exe", "where.exe", "tasklist.exe", "openconsole.exe", "git-remote-https.exe",
           "ssh.exe", "less.exe", "cat.exe", "grep.exe", "sed.exe", "head.exe", "tail.exe", "ls.exe", "wc.exe", "sort.exe"}
_cache: dict = {"t": 0.0, "liste": []}


def _processes() -> list[tuple[int, int, str, str]]:
    """(pid, parent, name, command line) — Windows; the command line is only used for recognition, never shown."""
    if os.name != "nt":
        return []
    if time.monotonic() - _cache["t"] < 4:
        return _cache["liste"]
    from .connectors.base import NO_WINDOW
    ps = ("Get-CimInstance Win32_Process | ForEach-Object { \"$($_.ProcessId)`t$($_.ParentProcessId)`t$($_.Name)`t$($_.CommandLine)\" }")
    try:
        r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", ps], capture_output=True, text=True,
                           encoding="utf-8", errors="replace", timeout=20, stdin=subprocess.DEVNULL, **NO_WINDOW)
        entries = []
        for l in r.stdout.splitlines():
            p = l.split("\t", 3)
            if len(p) >= 3 and p[0].isdigit() and p[1].isdigit():
                entries.append((int(p[0]), int(p[1]), p[2], p[3] if len(p) > 3 else ""))
    except (OSError, subprocess.TimeoutExpired):
        entries = []
    _cache.update(t=time.monotonic(), liste=entries)
    return entries


def applications(pids_agent: list[int], unreal_project: bool, procs: list | None = None) -> list[dict]:
    procs = _processes() if procs is None else procs
    children: dict[int, list] = {}
    for pid, parent, nom, cl in procs:
        children.setdefault(parent, []).append((pid, nom, cl))
    descendants, to_view = set(), list(pids_agent)
    while to_view:
        p = to_view.pop()
        for pid, _, _ in children.get(p, []):
            if pid not in descendants:
                descendants.add(pid)
                to_view.append(pid)
    seen_items: dict[str, dict] = {}
    ubt = [pid for pid, _, n, cl in procs if n.lower() == "unrealbuildtool.exe" or (n.lower() == "dotnet.exe" and "unrealbuildtool" in cl.lower())]
    compile_ = bool(ubt)
    for pid, _, nom, cl in procs:
        n = nom.lower()
        per_agent = pid in descendants
        if n in _APPS:
            lib = _APPS[n]
            task_status = "en arrière-plan" if n == "blender.exe" and re.search(r"(--background|\s-b\s)", cl) else "ouvert"
            if n == "unrealbuildtool.exe":
                task_status = "en cours"
            seen_items.setdefault(lib, {"nom": lib, "statut": task_status, "par_agent": per_agent})
            seen_items[lib]["par_agent"] = seen_items[lib]["par_agent"] or per_agent
        elif per_agent and n not in _TOOLS and not (n == "dotnet.exe" and "unrealbuildtool" in cl.lower()):
            lib = Path(nom).stem
            seen_items.setdefault(lib, {"nom": lib, "statut": "ouvert", "par_agent": True})
    if compile_:
        seen_items.setdefault("Compilation Unreal", {"nom": "Compilation Unreal", "statut": "en cours", "par_agent": any(p in descendants for p in ubt)})
    if unreal_project and "Unreal Editor" not in seen_items:
        seen_items["Unreal Editor"] = {"nom": "Unreal Editor", "statut": "fermé", "par_agent": False}
    order = {"Unreal Editor": 0, "Compilation Unreal": 1, "Blender": 2}
    return sorted(seen_items.values(), key=lambda a: (order.get(a["nom"], 9), a["nom"]))
