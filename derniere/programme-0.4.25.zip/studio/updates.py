"""Program updates from published releases (public GitHub repo, derniere/ folder).

- Check at startup then once a day, plus the « Rechercher une mise à jour » button (Gestion › Outils).
- Minor update (manifest « mineure »: true): installed on its own, then the studio offers to restart.
  Major update: the studio shows what's new and waits for « Installer ».
- Only program files change (studio/, modeles/, scripts/, docs/, installeur/, studio.cmd, component
  lists). Never the data, settings, roles, memory or Python environment. Before writing, the
  current version is backed up (anciennes-versions/<version>.zip); the archive is verified (SHA-256).
"""
from __future__ import annotations

import hashlib
import io
import json
import re
import threading
import time
import urllib.request
import zipfile
from pathlib import Path

from .user_workspace import CODE

ALLOWED = ("studio/", "modeles/", "templates/", "scripts/", "docs/", "installeur/", "installer/", "wheels/")   # templates/, installer/: English folder names of a later version
ROOT_FILES = {"studio.cmd", "VERSION", "requirements.lock.txt", "requirements-pieces.lock.txt", "requirements-retro.lock.txt"}
_state: dict = {"verifie": 0.0, "disponible": None, "installee": "", "erreur": "", "en_cours": False}
_lock = threading.Lock()


def current_version(code: Path = CODE) -> str:
    try:
        return (code / "VERSION").read_text(encoding="utf-8").strip() or "0.0.0"
    except OSError:
        return "0.0.0"


def depot() -> str:
    try:
        d = (CODE / "DEPOT").read_text(encoding="utf-8").strip()
        return d if re.fullmatch(r"[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+", d) else ""
    except OSError:
        return ""


def _v(t: str) -> tuple[int, ...]:
    return tuple(int(x) for x in re.findall(r"\d+", t)[:3]) or (0,)


def _get(url: str, delay: float = 30) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": "SuperAIStudio", "Accept": "application/octet-stream, application/json"})
    with urllib.request.urlopen(req, timeout=delay) as r:
        return r.read()


def check(force: bool = False) -> dict:
    """Latest published version: {"version", "mineure", "notes"} if it is newer, otherwise None."""
    d = depot()
    if not d:
        return {"actuelle": current_version(), "disponible": None, "info": "Mises à jour non configurées."}
    with _lock:
        if not force and time.time() - _state["verifie"] < 3600:
            return {"actuelle": current_version(), "disponible": _state["disponible"], "installee": _state["installee"]}
    try:
        # latest version: « derniere/ » folder of the public repo (manifest.json + program archive)
        base = f"https://raw.githubusercontent.com/{d}/main/derniere/"
        man = json.loads(_get(base + "manifest.json"))
        usable = None
        fichier = str(man.get("fichier", ""))
        if man.get("version") and _v(man["version"]) > _v(current_version()) and re.fullmatch(r"[A-Za-z0-9_.-]+\.zip", fichier):
            usable = {"version": man["version"], "mineure": bool(man.get("mineure")), "notes": str(man.get("notes", ""))[:2000],
                     "url": base + fichier, "sha256": man.get("sha256", "")}
        with _lock:
            _state.update(verifie=time.time(), disponible=usable, erreur="")
    except Exception as e:                                 # noqa: BLE001 — offline: try again later
        with _lock:
            _state.update(verifie=time.time(), erreur=type(e).__name__)
    return {"actuelle": current_version(), "disponible": _state["disponible"], "installee": _state["installee"], "erreur": _state["erreur"]}


def _safe_members(z: zipfile.ZipFile) -> list[zipfile.ZipInfo]:
    out = []
    for m in z.infolist():
        n = m.filename.replace("\\", "/")
        if m.is_dir():
            continue
        if n.startswith("/") or ".." in n.split("/") or ":" in n:
            raise ValueError(f"chemin refusé dans l'archive : {n}")
        if not (n.startswith(ALLOWED) or n in ROOT_FILES):
            raise ValueError(f"fichier hors du programme dans l'archive : {n}")
        out.append(m)
    return out


def appliquer(archive: bytes, expected: str, cible: Path = CODE) -> dict:
    """Verifies then installs a program archive; backs up the replaced files first."""
    if expected and hashlib.sha256(archive).hexdigest() != expected:
        raise ValueError("archive altérée (empreinte différente) : rien n'est installé")
    z = zipfile.ZipFile(io.BytesIO(archive))
    members = _safe_members(z)
    previous = current_version(cible)
    backup_root = cible.parent / "anciennes-versions" if cible.name == "app" else cible / "data" / "anciennes-versions"
    backup_root.mkdir(parents=True, exist_ok=True)
    copy_dir = backup_root / f"{previous}-{time.strftime('%Y%m%d-%H%M%S')}.zip"
    with zipfile.ZipFile(copy_dir.with_suffix(".partiel"), "w", zipfile.ZIP_DEFLATED) as s:
        for m in members:
            f = cible / m.filename
            if f.is_file():
                s.write(f, m.filename)
    copy_dir.with_suffix(".partiel").replace(copy_dir)
    try:                                                # the last 3 versions kept for rolling back
        from .cleanup import cap, cleanup_enabled
        if cleanup_enabled(cible / "studio.config.toml") if (cible / "studio.config.toml").exists() else True:
            cap(backup_root, "*.zip", 3)
    except Exception:                                   # noqa: BLE001 — cleanup never blocks an update
        pass
    for m in members:
        f = cible / m.filename
        f.parent.mkdir(parents=True, exist_ok=True)
        t = f.with_name(f.name + ".maj")
        t.write_bytes(z.read(m))
        t.replace(f)
    components = any(m.filename.startswith("wheels/") for m in members)
    if components:
        _install_components(cible)
    return {"ok": True, "ancienne": previous, "nouvelle": current_version(cible), "sauvegarde": str(copy_dir), "fichiers": len(members)}


def _install_components(cible: Path) -> None:
    """New Python components shipped with the update (offline, from wheels/)."""
    import subprocess
    from .actions import python_console
    from .connectors.base import NO_WINDOW
    import sys
    source = ["--no-index", "--find-links", str(cible / "wheels")] if sys.platform == "win32" else []   # bundled components: Windows; elsewhere, PyPI
    r = subprocess.run([python_console(), "-m", "pip", "install", "--disable-pip-version-check", *source,
                        "-r", str(cible / "requirements.lock.txt")], capture_output=True, text=True,
                       timeout=900, stdin=subprocess.DEVNULL, **NO_WINDOW)
    if r.returncode:
        raise RuntimeError("composants de la mise à jour non installés : " + (r.stderr or r.stdout)[-300:])


def install(note=lambda m: None) -> dict:
    with _lock:
        usable = _state["disponible"]
        if _state["en_cours"]:
            raise RuntimeError("Une mise à jour est déjà en cours.")
        _state["en_cours"] = True
    try:
        if not usable:
            raise ValueError("Aucune mise à jour disponible.")
        r = appliquer(_get(usable["url"], 600), usable.get("sha256", ""))
        with _lock:
            _state.update(installee=r["nouvelle"], disponible=None)
        note(f"mise à jour installée : {r['ancienne']} → {r['nouvelle']}")
        return r
    finally:
        with _lock:
            _state["en_cours"] = False


def automatic(note=lambda m: None) -> None:
    """At startup then daily: checks; a minor update installs itself."""
    v = check(force=True)
    d = v.get("disponible")
    if d and d.get("mineure"):
        try:
            install(note)
        except Exception as e:                             # noqa: BLE001 — shown in Gestion › Outils
            with _lock:
                _state["erreur"] = str(e)[:300]


def etat() -> dict:
    with _lock:
        return {"actuelle": current_version(), "depot": depot(), "disponible": _state["disponible"],
                "installee": _state["installee"], "erreur": _state["erreur"], "en_cours": _state["en_cours"]}


def restart_later() -> None:
    """Restarts the studio a few seconds after it stops (same program, same workspace)."""
    import subprocess
    import sys
    code = ("import time, subprocess, sys; time.sleep(5); "
            f"subprocess.Popen([sys.executable, '-m', 'studio', 'lanceur'], cwd={str(CODE)!r})")
    subprocess.Popen([sys.executable, "-c", code], cwd=str(CODE), stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                     stderr=subprocess.DEVNULL, close_fds=True,
                     **({"creationflags": 0x00000008 | 0x00000200} if sys.platform == "win32" else {"start_new_session": True}))
