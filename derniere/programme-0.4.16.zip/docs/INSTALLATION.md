# Installer le studio IA

**Super AI Agent Pro Station Max 2000** est une plateforme IA tout-en-un : toutes tes IA (Claude, ChatGPT, Gemini, Grok, modèles gratuits sur ton PC…) réunies dans une seule application, avec une équipe d'agents, une mémoire et des compétences partagées par toutes. Fini les tutos et les réglages compliqués : tu installes en deux clics, tu connectes ton IA, et tu demandes ce que tu veux.

Il te faut : Windows 10 ou 11, et une IA (clé API, IA locale ou abonnement).

## 1. Installer
1. Double-clique sur `Super AI Agent Pro Station Max 2000 - Installation.exe`.
2. Message « Windows a protégé votre ordinateur » ? Clique **Informations complémentaires**, puis **Exécuter quand même**.
3. Clique **Installer**. Attends 2 à 5 minutes.

Rien de ce que tu as déjà n'est modifié.

## 2. Premier lancement
1. Ouvre **Super AI Agent Pro Station Max 2000** (icône du bureau).
2. Tape ton prénom.
3. Garde le dossier proposé.
4. Coche des packs si tu veux.
5. Clique **Créer mon studio**.

## 3. Connecter ton IA
1. Clique **Connecter une IA**.
2. Choisis ton fournisseur et colle ta clé API.
3. IA locale (Ollama, LM Studio) : lance-la, puis clique **Connecter**.

## 4. Travailler
- Écris ta demande au Superviseur, à droite.
- Ajoute un projet avec le bouton **+**.
- Crée un agent : Gestion › **Créer un agent**.

## 5. Téléphone (facultatif)
1. Installe **Tailscale** sur le PC et le téléphone (même compte).
2. Studio : Accueil › Réglages › Téléphone › **Activé** › **Associer un téléphone**.
3. Sur le téléphone : ouvre l'adresse affichée et tape le code.

## Bon à savoir
- Tout reste sur ton PC.
- Rien n'est supprimé ni publié sans ton clic.
- Fermer : bouton **Fermer**, en haut à droite.
- Désinstaller : menu Démarrer › Super AI Agent Pro Station Max 2000 › Désinstaller. Ton dossier est gardé.
