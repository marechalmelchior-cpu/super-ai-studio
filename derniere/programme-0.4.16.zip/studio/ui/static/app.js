"use strict";
const $ = (s) => document.querySelector(s);
const $$ = (s) => document.querySelectorAll(s);
const esc = (t) => String(t ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

let vue = "projets", chatProjet = null, cibles = [], projetCourant = null, selection = null, derniereVue = "";

async function api(path, body) {
  const opt = body === undefined ? {} : { method: "POST", headers: { "Content-Type": "application/json", "X-Studio": "1" }, body: JSON.stringify(body) };
  const r = await fetch(path, opt);
  const j = await r.json().catch(() => ({}));
  if (!r.ok) { const e = new Error(j.erreur || r.status); e.code = r.status; throw e; }
  return j;
}

const LIBELLES = {
  creee: "en cours", en_cours: "en cours", a_approuver: "à valider", a_approuver_avec_defauts: "à valider · défauts",
  approuvee: "validée", appliquee: "appliquée", annulee: "annulée", bloquee: "bloquée", interrompue: "interrompue",
  en_attente_creneau: "en attente", echec: "échec",
};
const OUTILS = { "claude-code": "Claude Code", codex: "Codex", simulation: "simulation" };
const libelleTache = (t) => t.status === "approuvee" && (t.summary || "").startsWith("Faite") ? "terminée" : (LIBELLES[t.status] || t.status);
const A_VALIDER = ["a_approuver", "a_approuver_avec_defauts"];
const EN_COURS = ["creee", "en_cours", "en_attente_creneau", "interrompue", "bloquee"];
let MODELES = [["", "Auto"], ["opus", "Opus"], ["sonnet", "Sonnet"], ["haiku", "Haiku"]];   // remplacé par [choix] modeles_claude
const EFFORTS = [["", "Auto"], ["low", "Bas"], ["medium", "Moyen"], ["high", "Élevé"], ["xhigh", "Très élevé"], ["max", "Max"]];
const LIB_EFFORT = Object.fromEntries(EFFORTS);
const MODES = [["rapide", "Rapide"], ["", "Normal"], ["max", "Max"]];
let MODELES_SUP = [["", "Auto"], ["haiku", "Haiku"], ["sonnet", "Sonnet"], ["opus", "Opus"]];
const lireSup = (k) => { try { return localStorage.getItem(k) || ""; } catch { return ""; } };
const garderSup = (k, v) => { try { localStorage.setItem(k, v); } catch {} };
let modeleSup = lireSup("sup-modele"), effortSup = lireSup("sup-effort");   // réglage du Superviseur gardé d'une session à l'autre
const nomModele = (m) => m.charAt(0).toUpperCase() + m.slice(1);
// Couleurs des états : en cours = bleu, à valider = jaune, validée = vert, annulée / échec / bloquée = rouge
const couleur = (s) => (["approuvee", "appliquee"].includes(s) ? "ok"
  : ["creee", "en_cours", "en_attente_creneau"].includes(s) ? "info"
  : ["a_approuver", "a_approuver_avec_defauts"].includes(s) ? "warn" : "bad");
const nomCible = (target) => { const c = cibles.find((x) => `${x.kind}:${x.id}` === target || x.id === String(target).split(":").pop()); return c ? c.nom : target; };

/* Markdown minimal, appliqué APRÈS échappement : aucun HTML d'un document n'est interprété. */
function md(texte) {
  let entete = "";
  const fm = String(texte).match(/^---\r?\n([\s\S]*?)\r?\n---\r?\n?/);
  if (fm) {
    texte = texte.slice(fm[0].length);
    const desc = (fm[1].match(/^description:\s*(.*)$/m) || [])[1];
    if (desc) entete = `<p class="vide">${esc(desc)}</p>`;
  }
  const lignes = esc(texte).replace(/\r/g, "").split("\n");
  let html = "", liste = false, code = false;
  const inline = (l) => l.replace(/`([^`]+)`/g, "<code>$1</code>").replace(/\*\*([^*]+)\*\*/g, "<b>$1</b>");
  const cellules = (l) => l.trim().replace(/^\||\|$/g, "").split("|").map((c) => c.trim());
  for (let i = 0; i < lignes.length; i++) {
    const l = lignes[i];
    if (l.startsWith("```")) { html += code ? "</pre>" : "<pre>"; code = !code; continue; }
    if (code) { html += l + "\n"; continue; }
    if (/^\s*\|.*\|\s*$/.test(l) && /^\s*\|?\s*:?-{2,}/.test(lignes[i + 1] || "")) {   // tableau Markdown
      if (liste) { html += "</ul>"; liste = false; }
      let t = `<div class="table-md"><table><thead><tr>${cellules(l).map((c) => `<th>${inline(c)}</th>`).join("")}</tr></thead><tbody>`;
      i += 2;
      while (i < lignes.length && /^\s*\|.*\|\s*$/.test(lignes[i])) { t += `<tr>${cellules(lignes[i]).map((c) => `<td>${inline(c)}</td>`).join("")}</tr>`; i++; }
      i--; html += t + "</tbody></table></div>"; continue;
    }
    const m = l.match(/^(#{1,4})\s+(.*)$/);
    const li = l.match(/^\s*(?:[-*]|\d+\.)\s+(.*)$/);
    if (!li && liste) { html += "</ul>"; liste = false; }
    if (/^-{3,}$/.test(l.trim())) { html += "<hr>"; continue; }
    if (m) html += `<h${m[1].length + 1}>${inline(m[2])}</h${m[1].length + 1}>`;
    else if (li) { if (!liste) { html += "<ul>"; liste = true; } html += `<li>${inline(li[1])}</li>`; }
    else if (l.trim()) html += `<p>${inline(l)}</p>`;
  }
  return `<div class="contenu">${entete}${html}${liste ? "</ul>" : ""}${code ? "</pre>" : ""}</div>`;
}

/* Durées : « 42 s », « 3 min 05 s », « 1 h 12 min ». */
function duree(s) {
  s = Math.max(0, Math.round(+s || 0));
  if (s < 60) return `${s} s`;
  if (s < 3600) return `${Math.floor(s / 60)} min ${String(s % 60).padStart(2, "0")} s`;
  return `${Math.floor(s / 3600)} h ${String(Math.floor((s % 3600) / 60)).padStart(2, "0")} min`;
}
const secondes = (a, b) => (Date.parse(b || new Date().toISOString()) - Date.parse(a)) / 1000;
/* Chrono vivant : base (secondes déjà comptées) + temps écoulé depuis data-depuis. */
const chrono = (depuis, base = 0) => `<span class="chrono" data-depuis="${esc(depuis)}" data-base="${Math.round(base || 0)}">${duree((base || 0) + secondes(depuis))}</span>`;

function puces(el, items, actif, onclick) {
  el.innerHTML = items.map(([v, t]) => `<button class="puce ${v === actif ? "sel" : ""}" data-v="${esc(v)}">${esc(t)}</button>`).join("");
  el.querySelectorAll(".puce").forEach((b) => (b.onclick = () => { el.querySelectorAll(".puce").forEach((x) => x.classList.remove("sel")); b.classList.add("sel"); onclick(b.dataset.v); }));
}

function montrer(v) {
  vue = v;
  document.body.dataset.vue = v;
  document.body.classList.add("fixe");
  $$(".vue").forEach((el) => (el.hidden = el.id !== `vue-${v}`));
  rendreOnglets();
  if (v === "projets") (projetCourant ? ouvrirProjet(projetCourant) : chargerProjets());
  if (v === "gestion") afficherGestion();
  if (v === "perso") afficherPerso(!biblio || Date.now() - biblioQuand > 120000);   // catalogue gardé 2 min : onglets instantanés
}
/* En-tête : Projets / Gestion. Dans Projets : onglets « Tous », un par projet, « + » ; puis deux blocs. */
let projetsListe = [], blocCourant = "ensemble";
const BLOCS_TOUS = ["ensemble"], BLOCS_PROJET = ["taches", "detail", "equipe", "branches", "projet"];
let gitProjet = {};                                         // clé du projet → dépôt git ? (onglet Branches)
/* Ordre des onglets : celui d'ajout (un nouveau projet va à la fin), gardé d'une ouverture à l'autre */
function ordreProjets(liste) {
  let ordre = [];
  try { ordre = JSON.parse(localStorage.getItem("ordre-projets") || "[]"); } catch (e) { ordre = []; }
  if (!Array.isArray(ordre)) ordre = [];
  const cles = liste.map((x) => x.cle);
  if (!ordre.length) ordre = [...liste].sort((a, b) => (a.kind === b.kind ? 0 : a.kind === "project" ? -1 : 1)).map((x) => x.cle);
  ordre = ordre.filter((c) => cles.includes(c));
  cles.forEach((c) => { if (!ordre.includes(c)) ordre.push(c); });
  try { localStorage.setItem("ordre-projets", JSON.stringify(ordre)); } catch (e) { /* facultatif */ }
  return ordre.map((c) => liste.find((x) => x.cle === c));
}
function rendreOnglets() {
  $$("nav button[data-vue]").forEach((b) => b.classList.toggle("actif", b.dataset.vue === vue));
  const el = $("#onglets-p");
  if (!el) return;
  $("#btn-sup").classList.toggle("actif", vue === "projets" && !projetCourant);
  const liste = projetsListe.length ? projetsListe : cibles.map((c) => ({ cle: `${c.kind}:${c.id}`, nom: c.nom, kind: c.kind, compteurs: {} }));
  const ordre = ordreProjets(liste);
  const badge = (n) => n ? `<span class="badge-onglet" title="${n} à valider">${n}</span>` : "";
  el.innerHTML = ordre.map((x) => `<button role="tab" data-p="${esc(x.cle)}" aria-selected="${projetCourant === x.cle}" title="${esc(x.nom)}${x.kind === "topic" ? " (sujet)" : ""}">${esc(x.nom)}${badge((x.compteurs || {}).a_valider)}</button>`).join("")
;
  // onglet choisi rendu visible en faisant défiler LA LIGNE d'onglets seulement (jamais la page : sur téléphone,
  // scrollIntoView ramenait la page en haut à chaque actualisation), et seulement quand le choix change
  const a = el.querySelector('[aria-selected="true"]');
  if (a && el.dataset.vu !== projetCourant) {
    el.dataset.vu = projetCourant || "";
    const ra = a.getBoundingClientRect(), re = el.getBoundingClientRect();
    if (ra.left < re.left || ra.right > re.right) el.scrollLeft += ra.left - re.left - (re.width - ra.width) / 2;
  }
  bordsOnglets();
}
function bordsOnglets() {                                     // fondu à gauche / à droite quand des onglets sont cachés
  const el = $("#onglets-p");
  if (!el) return;
  el.classList.toggle("cache-g", el.scrollLeft > 2);
  el.classList.toggle("cache-d", el.scrollLeft + el.clientWidth < el.scrollWidth - 2);
}
$("#onglets-p").addEventListener("scroll", bordsOnglets);
window.addEventListener("resize", bordsOnglets);
$("#onglets-p").addEventListener("wheel", (e) => {                // beaucoup de projets : la molette fait défiler les onglets
  const el = e.currentTarget; if (el.scrollWidth <= el.clientWidth) return;
  e.preventDefault(); el.scrollLeft += e.deltaY || e.deltaX;
}, { passive: false });
$("#onglets-p").onclick = (e) => {
  const b = e.target.closest("button");
  if (!b) return;
  const cle = b.dataset.p || null;
  if (cle !== projetCourant) selection = null;
  if (cle) ouvrirProjet(cle);
};
$("#plus-p").onclick = () => nouveauProjet();
$("#btn-sup").onclick = () => { selection = null; ouvrirSuperviseur(); };
/* Bouton Accueil : conversation générale à droite, travail en cours de tous les projets à gauche */
async function ouvrirSuperviseur() {
  projetCourant = null; blocCourant = "ensemble";
  try { localStorage.setItem("projet-courant", ""); } catch (e) { /* facultatif */ }
  rendreOnglets(); rendreOngletsBloc();
  placerSuperviseur(null);
  const ps = await api("/api/projets");
  projetsListe = ps; rendreOnglets(); rendreOngletsBloc();
  resumeTravail(ps);
}
/* Bloc de travail : ses onglets changent selon « Tous » ou un projet */
function rendreOngletsBloc() {
  const el = $("#onglets-bloc");
  const p = projetsListe.find((x) => x.cle === projetCourant) || {};
  const c = p.compteurs || {};
  const aValiderTous = projetsListe.reduce((n, x) => n + ((x.compteurs || {}).a_valider || 0), 0);
  const items = !projetCourant
    ? [["ensemble", `Tâches${aValiderTous ? `<span class="badge-onglet">${aValiderTous}</span>` : ""}`], ["sup-reglages", "Réglages"]]
    : [["taches", `Tâches${c.a_valider ? `<span class="badge-onglet">${c.a_valider}</span>` : ""}`],
       ...(selection ? [["detail", `Détail<span class="fermer-b" data-fermer-detail="1" role="button" title="Fermer la tâche" aria-label="Fermer la tâche">×</span>`]] : []),
       ["equipe", "Équipe"], ["fichiers", "Fichiers"], ...(gitProjet[projetCourant] ? [["branches", "Branches"]] : []), ["projet", "Réglages"]];
  if (!items.some(([k]) => k === blocCourant)) blocCourant = items[0][0];
  el.innerHTML = items.map(([k, t]) => `<button role="tab" data-b="${k}" aria-selected="${k === blocCourant}">${t}</button>`).join("");
  $$("#bloc-travail .volet").forEach((v) => (v.hidden = v.dataset.b !== blocCourant));
}
function choisirBloc(b) {
  blocCourant = b; rendreOngletsBloc();
  if (b === "branches" && projetCourant) { depotG = projetCourant; detailGit(); }
  if (b === "fichiers" && projetCourant) fichiersProjet();
  if (b === "equipe" && projetCourant) equipeReglages();
  if (b === "sup-reglages") gReglages().catch((e) => GB("reglages", `<div class="alerte">${esc(e.message)}</div>`));
  if (b === "sup-reglages") gTelephone().catch((e) => GB("telephone", `<div class="alerte">${esc(e.message)}</div>`));
  if (b === "sup-reglages") gIA().catch((e) => GB("ia", `<div class="alerte">${esc(e.message)}</div>`));
}
$("#onglets-bloc").onclick = (e) => {
  if (e.target.closest("[data-fermer-detail]")) { selection = null; derniereVue = ""; blocCourant = "taches"; rendreOngletsBloc(); listesTaches(tachesProjet); return; }
  const b = e.target.closest("button[data-b]");
  if (b) choisirBloc(b.dataset.b);
};
$("nav").onclick = (e) => {
  const b = e.target.closest("button[data-vue]");
  if (!b) return;
  montrer(b.dataset.vue);
};
async function ouvrir(chemin) { if (sessionInfo.distant) { alert("Ça s'ouvre sur le PC : fais-le depuis le PC."); return; } try { await api("/api/ouvrir", { chemin }); } catch (e) { alert(e.message); } }

/* ================================================================ DEMANDE */
let signatureFil = "";
async function chargerConversation(defiler) {
  const portee = chatProjet;
  const msgs = await api("/api/conversation" + (portee ? `?projet=${encodeURIComponent(portee)}` : ""));
  if (portee !== chatProjet) return;                      // la page a changé pendant la requête
  const sig = (portee || "") + "#" + nomUtilisateur + "#" + (iaEtat ? (iaEtat.actif || "aucune") : "") + "#" + msgs.map((m) => `${m.id}:${m.etat}:${m.proposition.etat || ""}`).join("|");
  if (sig === signatureFil && !defiler) return;
  const fil = $("#fil");
  const enBas = fil.scrollHeight - fil.scrollTop - fil.clientHeight < 40;
  signatureFil = sig;
  dernierMel = (msgs.filter((m) => m.auteur === "mel").pop() || {}).id;
  const fin = msgs[msgs.length - 1];
  dernierSupId = fin && fin.auteur !== "mel" ? fin.id : 0;   // l'utilisateur a déjà répondu : plus de boutons
  fil.innerHTML = msgs.length ? msgs.map(bulle).join("") : (portee
    ? `<div class="vide-chat"><p class="vide">Pose une question sur ce projet ou décris un travail :<br>le Superviseur répond ou propose une tâche ici.</p></div>`
    : `<div class="vide-chat"><div class="accueil"><div class="grand">Salut${nomUtilisateur ? " " + esc(nomUtilisateur) : ""}.</div>
      <p class="vide">Demande-moi où en est un projet, pose une question, ou décris un travail :<br>je réponds ou je le confie à la bonne équipe.</p>${iaEtat && !iaEtat.actif ? `<div class="cta-ia"><p class="warn">Aucune IA connectée pour l'instant.</p><button class="btn principal" data-connecter-ia>Connecter une IA</button></div>` : ""}</div></div>`);
  $$("[data-connecter-ia]").forEach((b) => (b.onclick = ouvrirReglagesIA));
  msgs.filter((m) => m.proposition.etat === "proposee").forEach(brancherProposition);
  $$("#fil [data-modifier]").forEach((b) => (b.onclick = async () => {
    try {
      const r = await api(`/api/conversation/${b.dataset.modifier}/modifier`, {});
      if (r.lance) bulleInfo("La tâche déjà lancée continue");
      $("#message").value = r.texte; ajusterSaisie(); $("#message").focus(); signatureFil = ""; chargerConversation(true);
    } catch (e) { alert(e.message); }
  }));
  $$("#fil [data-arreter]").forEach((b) => (b.onclick = async () => {
    b.disabled = true;
    try { await api(`/api/conversation/${b.dataset.arreter}/arreter`, {}); signatureFil = ""; chargerConversation(); } catch (e) { alert(e.message); }
  }));
  if (defiler || enBas) fil.scrollTop = fil.scrollHeight;  // défile DANS le bloc, jamais la page
}
function placerSuperviseur(cle) {
  chatProjet = cle || null;
  $("#sup-portee").textContent = cle ? "conversation de ce projet" : "conversation générale";
  $("#message").placeholder = cle ? "Question ou travail pour ce projet · @ fichier · / raccourci" : "Pose une question ou décris un travail · @ fichier · / raccourci";
  signatureFil = "";
  chargerConversation(true);
}

let dernierMel = null, nomUtilisateur = "";
function bulle(m) {
  if (m.auteur === "mel") {
    const pj = (m.proposition && m.proposition.pieces) || [];
    const vues = pj.map((c) => /\.(png|jpe?g|gif|webp)$/i.test(c) ? `<img src="/api/piece?chemin=${encodeURIComponent(c)}" alt="">` : `<span>${esc(c.split("/").slice(3).join("/"))}</span>`).join("");
    return `<div class="bulle mel">${esc(m.texte)}${pj.length ? `<div class="pj">${vues}</div>` : ""}${m.id === dernierMel ? `<button class="lien modifier-msg" data-modifier="${m.id}" title="Arrête la réponse si elle est en cours et remet ton texte dans la zone de saisie">Modifier</button>` : ""}</div>`;
  }
  if (m.etat === "en_cours") return `<div class="bulle sup attente"><div class="qui">Superviseur</div>réfléchit… <span class="chrono" data-depuis="${esc(m.at)}"></span> <button class="lien arreter-msg" data-arreter="${m.id}">Arrêter</button></div>`;
  if (m.etat === "annule") return `<div class="bulle sup attente"><div class="qui">Superviseur</div>${esc(m.texte)}</div>`;
  const p = m.proposition || {};
  let prop = "";
  if (p.etat === "proposee") {
    prop = `<div class="proposition" data-id="${m.id}">
      ${p.titre ? `<div class="titre-prop"><b>${esc(p.titre)}</b></div>` : ""}<small>Je propose de confier à</small> <b>${esc(p.nom_cible || p.cible)}</b>${p.nouvelle_cible ? ' <span class="etat warn">nouveau sujet, créé au lancement</span>' : ""}${p.role ? ` <small>· rôle ${esc(p.role)}</small>` : ""}
      ${p.erreur ? `<div class="alerte">${esc(p.erreur)}</div>` : ""}
      <div class="demande-prop">${md(p.demande)}</div>
      <textarea class="demande-edit" hidden>${esc(p.demande)}</textarea>
      ${p.etapes ? `<div class="chaine-bloc"><b>Chaîne de ${p.etapes.length} étapes</b> <small class="discret">— chacune attend ta validation avant la suivante</small><ol>${p.etapes.map((e) => `<li><b>${esc(e.role || "rôle choisi par le studio")}</b> — ${esc(e.demande)}</li>`).join("")}</ol></div>` : ""}
      <div class="bas-prop"><label>Modèle <select class="p-mod"></select></label><label>Effort <select class="p-eff"></select></label><label>Mode <select class="p-mode"></select></label>
        <span class="boutons-prop"><button class="lien modifier-dem">Modifier la demande</button><button class="btn discret ignorer">Ignorer</button><button class="btn discret nuit-b" title="En file : part pendant la nuit, rapport le matin">Cette nuit</button><button class="btn principal lancer">Lancer</button></span></div>
      <span class="warn msg"></span></div>`;
  } else if (p.etat === "lancee") {
    prop = `<div class="proposition"><span class="ok">Lancé</span> dans <b>${esc(p.nom_cible || p.cible)}</b> — <button class="lien" data-voir="${esc(p.tache)}" data-cible="${esc(p.cible)}">suivre la tâche</button></div>`;
  } else if (p.etat === "nuit") {
    prop = `<div class="proposition"><span class="info">Prévue cette nuit</span> dans <b>${esc(p.nom_cible || p.cible)}</b> — part à ${esc(plageNuit[0])}, rapport le matin. Laisse le PC allumé. <button class="lien" data-nuit-retirer="${esc(p.nuit)}">Ne pas la faire</button></div>`;
  } else if (p.etat === "ignoree") {
    prop = `<div class="discret" style="margin-top:8px">Proposition ignorée.</div>`;
  }
  if (p.question && m.id === dernierSupId && !p.repondu) {         // question du Superviseur : réponse en un clic
    const q = p.question;
    const nomF = (o) => o.split(/[\\/]/).pop();
    prop += `<div class="reponses-rapides" data-q="${m.id}">${q.type === "texte"
      ? `<input class="champ" placeholder="Ta réponse…" maxlength="500"><button class="btn principal petit" data-rep-texte="1">Répondre</button>`
      : q.options.map((o) => `<button class="btn${/^oui$/i.test(o) ? " principal" : ""} petit" data-rep="${esc(o)}" title="${esc(o)}">${esc(q.type === "fichier" ? "📄 " + nomF(o) : o)}</button>`).join("")
        + (q.type === "fichier" ? `<button class="btn discret petit" data-rep-joindre="1">Autre fichier…</button>` : "")}</div>`;
  }
  return `<div class="bulle sup ${m.etat === "erreur" ? "erreur" : ""}"><div class="qui">Superviseur${p.bilan ? ` · <button class="lien" data-voir="${esc(p.bilan)}" data-cible="${esc(p.projet || "")}">bilan de « ${esc(p.bilan_titre || "la tâche")} »</button>` : ""}${p.duree_s != null ? `<span class="temps">répondu en ${duree(p.duree_s)}${p.modele_sup ? " · " + esc(p.modele_sup) : ""}</span>` : ""}</div>${m.etat === "erreur" ? esc(m.texte) : md(m.texte)}${prop}${p.rapport_nuit && p.rapport_nuit.length ? `<div class="rapport-nuit">${p.rapport_nuit.map((x) => `<button class="btn discret petit" data-voir="${esc(x.tid)}" data-cible="${esc(x.cible)}">${esc(x.titre.slice(0, 40))} · ${esc(x.etat)}</button>`).join("")}</div>` : ""}</div>`;
}

function brancherProposition(m) {
  const el = document.querySelector(`.proposition[data-id="${m.id}"]`);
  if (!el) return;
  let modele = m.proposition.modele || "";        // choix proposés par le Superviseur, modifiables avant de lancer
  choixListe(el.querySelector(".p-mod"), MODELES, modele, (v) => (modele = v));
  let mode = m.proposition.mode || "";
  choixListe(el.querySelector(".p-mode"), MODES, mode, (v) => (mode = v));
  let effort = m.proposition.effort || "";
  choixListe(el.querySelector(".p-eff"), EFFORTS, effort, (v) => (effort = v));
  const zone = el.querySelector(".demande-edit");
  const ajuster = () => { zone.style.height = "auto"; zone.style.height = zone.scrollHeight + 4 + "px"; };
  el.querySelector(".modifier-dem").onclick = (ev) => {
    zone.hidden = !zone.hidden; el.querySelector(".demande-prop").hidden = !zone.hidden;
    ev.currentTarget.textContent = zone.hidden ? "Modifier la demande" : "Voir la demande";
    if (!zone.hidden) { ajuster(); zone.focus(); }
  };
  zone.oninput = ajuster;
  el.querySelector(".lancer").onclick = async (ev) => {
    if (ev.currentTarget.disabled) return;
    const b = ev.currentTarget; b.disabled = true;
    try {
      const r = await api(`/api/conversation/${m.id}/lancer`, { demande: zone.value, modele, mode, effort });
      signatureFil = ""; chargerConversation(); majBadge(); cibles = await api("/api/cibles");
      el.querySelector(".msg").textContent = `Lancé : ${r.tid}`;
    } catch (e) { el.querySelector(".msg").textContent = e.message; b.disabled = false; }
  };
  el.querySelector(".nuit-b").onclick = async (ev) => {
    const b = ev.currentTarget; b.disabled = true;
    try {
      await api(`/api/conversation/${m.id}/nuit`, { demande: zone.value, modele, mode, effort });
      signatureFil = ""; chargerConversation();
    } catch (e) { el.querySelector(".msg").textContent = e.message; b.disabled = false; }
  };
  el.querySelector(".ignorer").onclick = async () => { await api(`/api/conversation/${m.id}/ignorer`, {}); signatureFil = ""; chargerConversation(); };
}

let plageNuit = ["01:00", "07:00"];
api("/api/nuit").then((n) => (plageNuit = n.plage)).catch(() => {});
document.addEventListener("click", async (ev) => {
  const n = ev.target.closest("[data-nuit-retirer]");
  if (!n) return;
  try { await api("/api/nuit/retirer", { id: n.dataset.nuitRetirer }); signatureFil = ""; chargerConversation(); } catch (e) { alert(e.message); }
});
document.addEventListener("click", async (ev) => {
  const b = ev.target.closest("[data-voir]");
  if (!b) return;
  ev.preventDefault();
  let cible = b.dataset.cible;
  if (!cible || !cible.includes(":")) {                    // lien sans projet (ancien message) : celui de la tâche
    try {
      const t = (await api(`/api/taches/${b.dataset.voir}`)).tache.target;
      const c = (cibles || []).find((k) => k.id === String(t).split(":").pop() && (!String(t).includes(":") || `${k.kind}:${k.id}` === t));
      cible = c ? `${c.kind}:${c.id}` : cible;
    } catch { /* la tâche s'ouvrira quand même si le projet est connu */ }
  }
  selection = b.dataset.voir; derniereVue = ""; blocCourant = "detail"; projetCourant = cible || projetCourant; montrer("projets");
  if (document.body.dataset.mob === "sup") vueMobile("travail");   // téléphone : on quitte le Superviseur pour la tâche
  if (window.innerWidth <= 900) window.scrollTo({ top: 0 });
});

/* Pièces jointes : glisser-déposer (fichiers et dossiers), coller une image, bouton ＋. Envoyées au moment d'« Envoyer ». */
let jointes = [];                       // { fichier, rel, apercu }
const MAX_FICHIERS = 200, MAX_TOTAL = 300 * 1024 * 1024;
function ajouterJointe(fichier, rel) {
  if (jointes.length >= MAX_FICHIERS) return;
  if (jointes.reduce((s, j) => s + j.fichier.size, 0) + fichier.size > MAX_TOTAL) { alert("Trop lourd : 300 Mo au total par message."); return; }
  const apercu = /^image\//.test(fichier.type) ? URL.createObjectURL(fichier) : "";
  jointes.push({ fichier, rel: rel || fichier.name, apercu });
  dessinerJointes();
}
function dessinerJointes() {
  $("#jointes").innerHTML = jointes.map((j, i) => `<div class="jointe">${j.apercu ? `<img src="${j.apercu}" alt="">` : "📄"}<span>${esc(j.rel)}</span><button class="x" data-i="${i}">✕</button></div>`).join("");
  $$("#jointes .x").forEach((b) => (b.onclick = () => { jointes.splice(+b.dataset.i, 1); dessinerJointes(); }));
}
async function lireEntree(entree, chemin) {
  if (entree.isFile) return new Promise((ok) => entree.file((f) => { ajouterJointe(f, chemin + f.name); ok(); }, ok));
  if (!entree.isDirectory) return;
  const lecteur = entree.createReader();
  let lot;
  do {
    lot = await new Promise((ok) => lecteur.readEntries(ok, () => ok([])));
    for (const e of lot) await lireEntree(e, chemin + entree.name + "/");
  } while (lot.length);
}
let compteurDepot = 0;
document.addEventListener("dragenter", (e) => { if (vue !== "projets") return; e.preventDefault(); if (compteurDepot++ === 0) { const d = document.createElement("div"); d.className = "depot"; d.id = "depot"; d.textContent = "Dépose tes fichiers ici"; document.body.appendChild(d); } });
document.addEventListener("dragleave", () => { if (--compteurDepot <= 0) { compteurDepot = 0; $("#depot")?.remove(); } });
document.addEventListener("dragover", (e) => { if (vue === "projets") e.preventDefault(); });
document.addEventListener("drop", async (e) => {
  if (vue !== "projets") return;
  e.preventDefault(); compteurDepot = 0; $("#depot")?.remove();
  const items = [...(e.dataTransfer.items || [])];
  if (items.length && items[0].webkitGetAsEntry) { for (const it of items) { const en = it.webkitGetAsEntry(); if (en) await lireEntree(en, ""); } }
  else [...e.dataTransfer.files].forEach((f) => ajouterJointe(f));
});
$("#message").addEventListener("paste", (e) => {
  let n = 0;
  for (const it of e.clipboardData.items) {
    if (it.kind === "file") { const f = it.getAsFile(); if (f) { n++; ajouterJointe(f, f.name && f.name !== "image.png" ? f.name : `image-collee-${Date.now()}-${n}.png`); } }
  }
  if (n) e.preventDefault();
});
/* Comme dans un terminal : surligner à la souris copie ; clic droit colle (ou copie s'il y a une sélection).
   Maj + clic droit garde le menu habituel. Coller du texte demande une fois l'autorisation du navigateur. */
function bulleInfo(texte) {
  let b = $("#bulle-info");
  if (!b) { b = document.createElement("div"); b.id = "bulle-info"; b.setAttribute("role", "status"); document.body.appendChild(b); }
  b.textContent = texte; b.classList.add("visible");
  clearTimeout(bulleInfo.t); bulleInfo.t = setTimeout(() => b.classList.remove("visible"), 1200);
}
const champTexte = (el) => el && ((el.tagName === "TEXTAREA") || (el.tagName === "INPUT" && /^(text|search|url|email|)$/i.test(el.type || ""))) && !el.readOnly && !el.disabled;
function selectionCourante() {
  const a = document.activeElement;
  if (champTexte(a) && a.selectionStart !== a.selectionEnd) return a.value.slice(a.selectionStart, a.selectionEnd);
  return String(window.getSelection() || "");
}
async function copier(texte) {
  try { await navigator.clipboard.writeText(texte); return true; }
  catch { try { return document.execCommand("copy"); } catch { return false; } }
}
document.addEventListener("mouseup", async (e) => {
  if (e.button !== 0) return;
  const t = selectionCourante();
  if (t.trim() && await copier(t)) bulleInfo("Copié");
});
function insererTexte(champ, texte) {
  champ.focus();
  if (!document.execCommand("insertText", false, texte)) champ.setRangeText(texte, champ.selectionStart, champ.selectionEnd, "end");
  champ.dispatchEvent(new Event("input", { bubbles: true }));
}
document.addEventListener("contextmenu", async (e) => {
  if (e.shiftKey) return;                                       // Maj + clic droit : menu habituel
  e.preventDefault();
  const t = selectionCourante();
  if (t.trim()) {                                               // une sélection : clic droit la copie
    if (await copier(t)) bulleInfo("Copié");
    const a = document.activeElement; if (champTexte(a)) a.setSelectionRange(a.selectionEnd, a.selectionEnd); else window.getSelection().removeAllRanges();
    return;
  }
  const champ = champTexte(e.target) ? e.target : (vue === "projets" && $("#message") && $("#message").offsetParent ? $("#message") : null);
  if (!champ) { bulleInfo("Rien où coller ici"); return; }
  try {                                                         // images copiées → pièces jointes du Superviseur
    if (champ.id === "message" && navigator.clipboard.read) {
      let n = 0;
      for (const it of await navigator.clipboard.read()) {
        const type = it.types.find((x) => x.startsWith("image/"));
        if (type) { const blob = await it.getType(type); n++; ajouterJointe(new File([blob], `image-collee-${Date.now()}-${n}.png`, { type }), `image-collee-${Date.now()}-${n}.png`); }
      }
      if (n) { bulleInfo(n > 1 ? `${n} images jointes` : "Image jointe"); return; }
    }
  } catch { /* pas d'image ou lecture refusée : on tente le texte */ }
  try {
    const texte = await navigator.clipboard.readText();
    if (texte) { insererTexte(champ, texte); bulleInfo("Collé"); } else bulleInfo("Presse-papiers vide");
  } catch { bulleInfo("Autorise le presse-papiers (ou Ctrl+V)"); champ.focus(); }
});
$("#joindre").onclick = () => ($("#menu-joindre").hidden = !$("#menu-joindre").hidden);
$("#j-fichiers").onclick = () => $("#fichiers").click();
$("#j-dossier").onclick = () => $("#dossier").click();
$("#fichiers").onchange = (e) => { [...e.target.files].forEach((f) => ajouterJointe(f)); e.target.value = ""; $("#menu-joindre").hidden = true; };
$("#dossier").onchange = (e) => { [...e.target.files].forEach((f) => ajouterJointe(f, f.webkitRelativePath || f.name)); e.target.value = ""; $("#menu-joindre").hidden = true; };

let dernierSupId = 0;                                 // seule la dernière question du Superviseur garde ses boutons
document.addEventListener("click", (e) => {
  const zone = e.target.closest(".reponses-rapides"); if (!zone) return;
  const b = e.target.closest("button"); if (!b) return;
  if (b.dataset.repJoindre) { $("#joindre").click(); return; }
  const texte = b.dataset.repTexte ? zone.querySelector("input").value.trim() : b.dataset.rep;
  if (!texte) return;
  zone.querySelectorAll("button").forEach((x) => (x.disabled = true));
  $("#message").value = texte; envoyer();
});
document.addEventListener("keydown", (e) => {
  if (e.key === "Enter" && e.target.closest(".reponses-rapides input")) { e.preventDefault(); e.target.parentElement.querySelector("[data-rep-texte]").click(); }
});
async function envoyer() {
  const t = $("#message").value.trim();
  if (!t && !jointes.length) return;
  let lot = "";
  try {
    if (jointes.length) {
      lot = "L" + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
      $("#envoyer").textContent = "Envoi…";
      for (const j of jointes) {
        const r = await fetch(`/api/pieces?lot=${lot}&rel=${encodeURIComponent(j.rel)}`, { method: "POST", headers: { "X-Studio": "1", "Content-Type": "application/octet-stream" }, body: j.fichier });
        if (!r.ok) throw new Error((await r.json().catch(() => ({}))).erreur || `envoi de ${j.rel} refusé`);
      }
    }
    await api("/api/conversation", { texte: t, lot, projet: chatProjet || "", modele: modeleSup, effort: effortSup });
    $("#message").value = ""; ajusterSaisie(); jointes = []; dessinerJointes();
    signatureFil = ""; await chargerConversation(true);
  } catch (e) { alert(e.message); }
  finally { $("#envoyer").textContent = "Envoyer"; }
}
$("#envoyer").onclick = envoyer;
/* Dictée (micro à gauche d'Envoyer) : reconnaissance vocale du navigateur, texte écrit en direct dans la saisie ;
   sinon enregistrement transcrit sur le PC (faster-whisper). Rien ne part avant « Envoyer ». */
const Reco = window.SpeechRecognition || window.webkitSpeechRecognition;
let dictee = null, enregistreur = null;
function etatMicro(etat) {                                  // "" | "ecoute" | "attente"
  const b = $("#micro");
  b.classList.toggle("actif", etat === "ecoute"); b.classList.toggle("attente", etat === "attente");
  b.setAttribute("aria-pressed", String(etat === "ecoute"));
  b.title = etat === "ecoute" ? "J'écoute… clique pour arrêter" : etat === "attente" ? "Transcription…" : "Dicter à la voix";
}
function ecrireDictee(base, texte) { const t = $("#message"); t.value = base + texte; ajusterSaisie(); t.scrollTop = t.scrollHeight; }
async function enregistrerPourPC(base) {
  if (!navigator.mediaDevices || !window.MediaRecorder) { bulleInfo("Dictée indisponible sur cet appareil."); return; }
  let flux;
  try { flux = await navigator.mediaDevices.getUserMedia({ audio: true }); }
  catch { bulleInfo("Autorise le micro pour dicter."); return; }
  const morceaux = [], rec = new MediaRecorder(flux);
  rec.ondataavailable = (e) => e.data.size && morceaux.push(e.data);
  rec.onstop = async () => {
    flux.getTracks().forEach((x) => x.stop()); enregistreur = null; etatMicro("attente");
    try {
      const blob = new Blob(morceaux, { type: rec.mimeType || "audio/webm" });
      const r = await fetch("/api/dicter", { method: "POST", headers: { "X-Studio": "1", "Content-Type": blob.type }, body: blob });
      const j = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(j.erreur || "dictée impossible");
      if (j.texte) ecrireDictee(base, j.texte); else bulleInfo("Rien entendu.");
    } catch (e) { bulleInfo(e.message); }
    etatMicro(""); $("#message").focus();
  };
  enregistreur = rec; rec.start(); etatMicro("ecoute");
}
$("#micro").onclick = () => {
  if (dictee) { dictee.stop(); return; }
  if (enregistreur) { enregistreur.stop(); return; }
  if ($("#micro").classList.contains("attente")) return;
  const v = $("#message").value, base = v && !/\s$/.test(v) ? v + " " : v;
  if (!Reco) return enregistrerPourPC(base);
  const r = new Reco(), android = /Android/i.test(navigator.userAgent);
  r.lang = navigator.language || "fr-FR"; r.interimResults = true; r.continuous = !android;   // Android : une phrase à la fois (sinon doublons)
  let final = "", repli = false;
  r.onresult = (e) => {
    let provisoire = "";
    for (let i = e.resultIndex; i < e.results.length; i++) { const x = e.results[i]; if (x.isFinal) final += x[0].transcript; else provisoire += x[0].transcript; }
    ecrireDictee(base, (final + provisoire).replace(/^\s+/, ""));
  };
  r.onerror = (e) => {
    if (e.error === "not-allowed" || e.error === "service-not-allowed") bulleInfo("Autorise le micro pour dicter.");
    else if (e.error === "network" || e.error === "language-not-supported") repli = true;   // service du navigateur injoignable : le PC transcrit
    else if (e.error !== "no-speech" && e.error !== "aborted") bulleInfo("Dictée interrompue.");
  };
  r.onend = () => { dictee = null; etatMicro(""); if (repli) enregistrerPourPC(base); else $("#message").focus(); };
  dictee = r;
  try { r.start(); etatMicro("ecoute"); } catch { dictee = null; enregistrerPourPC(base); }
};

/* « @ » : mentionner un fichier ou une fonction du projet ; son contenu part avec le message */
let mentionsListe = [], mentionsIndex = 0, mentionsMinuteur = null, mentionsDemande = 0;
function boiteMentions() {
  let b = $("#mentions");
  if (!b) { b = document.createElement("ul"); b.id = "mentions"; b.className = "mentions"; b.hidden = true; b.setAttribute("role", "listbox"); $(".saisie").appendChild(b); }
  return b;
}
function fermerMentions() { mentionsListe = []; boiteMentions().hidden = true; }
function jetonEnCours() {
  const t = $("#message"), avant = t.value.slice(0, t.selectionStart);
  const r = avant.match(/^\/([a-z0-9-]*)$/i);                // « / » en tout début de message : raccourcis
  if (r) return { q: r[1], debut: 0, raccourci: true };
  const m = avant.match(/(?:^|\s)@("?)([^\s"@]*)$/);
  return m ? { q: m[2], debut: avant.length - m[2].length - 1 - m[1].length } : null;
}
let raccourcisCache = null;
async function chercherRaccourcis(q) {
  if (!raccourcisCache) raccourcisCache = await api("/api/raccourcis");
  q = q.toLowerCase();
  return raccourcisCache.filter((r) => !q || r.nom.includes(q) || r.titre.toLowerCase().includes(q))
    .map((r) => ({ type: "raccourci", jeton: r.texte, libelle: "/" + r.nom, detail: r.titre }));
}
function dessinerMentions() {
  const b = boiteMentions();
  if (!mentionsListe.length) { b.hidden = true; return; }
  b.innerHTML = mentionsListe.map((m, i) => `<li role="option" data-mention="${i}" class="${i === mentionsIndex ? "actif" : ""}"><span class="type-m">${m.type === "fonction" ? "ƒ" : m.type === "raccourci" ? "⚡" : "📄"}</span><b>${esc(m.libelle)}</b><small>${esc(m.detail)}</small></li>`).join("")
    + (mentionsListe[0].type === "raccourci" ? '<li class="aide-m discret">↑ ↓ pour choisir · Entrée : la demande s\'écrit, tu peux la modifier avant d\'envoyer</li>'
      : '<li class="aide-m discret">↑ ↓ pour choisir · Entrée pour ajouter · le contenu part avec ton message</li>');
  b.hidden = false;
}
function choisirMention(i) {
  const m = mentionsListe[i], j = jetonEnCours();
  if (!m || !j) return fermerMentions();
  const t = $("#message"), fin = t.selectionStart;
  const ajout = m.type === "raccourci" ? m.jeton : m.jeton + " ";
  t.value = t.value.slice(0, j.debut) + ajout + t.value.slice(fin);
  const crochet = m.type === "raccourci" ? ajout.indexOf("[") : -1;      // « [décris…] » : sélectionné, prêt à remplacer
  const pos = j.debut + ajout.length;
  if (crochet >= 0) { t.setSelectionRange(j.debut + crochet, j.debut + ajout.indexOf("]", crochet) + 1); t.focus(); fermerMentions(); ajusterSaisie(); return; }
  t.setSelectionRange(pos, pos); t.focus(); fermerMentions(); ajusterSaisie();
}
$("#message").addEventListener("input", () => {
  clearTimeout(mentionsMinuteur);
  const j = jetonEnCours();
  if (!j) return fermerMentions();
  mentionsMinuteur = setTimeout(async () => {
    const n = ++mentionsDemande;
    let l = [];
    try { l = j.raccourci ? await chercherRaccourcis(j.q) : await api(`/api/mentions?projet=${encodeURIComponent(chatProjet || "")}&q=${encodeURIComponent(j.q)}`); } catch { return; }
    if (n !== mentionsDemande || !jetonEnCours()) return;
    mentionsListe = l; mentionsIndex = 0; dessinerMentions();
  }, 150);
});
document.addEventListener("mousedown", (e) => {
  const li = e.target.closest("[data-mention]");
  if (li) { e.preventDefault(); choisirMention(+li.dataset.mention); }
  else if (!e.target.closest("#mentions, #message")) fermerMentions();
});
$("#message").addEventListener("keydown", (e) => {
  if (mentionsListe.length && !boiteMentions().hidden) {
    if (e.key === "ArrowDown" || e.key === "ArrowUp") { e.preventDefault(); mentionsIndex = (mentionsIndex + (e.key === "ArrowDown" ? 1 : -1) + mentionsListe.length) % mentionsListe.length; dessinerMentions(); return; }
    if (e.key === "Enter" || e.key === "Tab") { e.preventDefault(); choisirMention(mentionsIndex); return; }
    if (e.key === "Escape") { e.preventDefault(); fermerMentions(); return; }
  }
  if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); envoyer(); }
});
function ajusterSaisie() { const t = $("#message"); t.style.height = "auto"; t.style.height = Math.min(t.scrollHeight, 200) + "px"; }
$("#message").addEventListener("input", ajusterSaisie);

/* ================================================================ PROJETS */
async function chargerProjets() {
  const ps = await api("/api/projets");
  projetsListe = ps;
  let cle = null;
  try { cle = localStorage.getItem("projet-courant"); } catch (e) { /* stockage indisponible */ }
  if (cle === "") return ouvrirSuperviseur();                // dernier écran ouvert : le Superviseur
  const ordre = ordreProjets(ps);
  if (!ps.some((x) => x.cle === cle)) cle = ordre.length ? ordre[0].cle : null;
  if (cle) return ouvrirProjet(cle);
  projetCourant = null; blocCourant = "ensemble";            // aucun projet : invitation à en ajouter un
  rendreOnglets(); rendreOngletsBloc();
  placerSuperviseur(null);
  tachesEnsemble = { t: [], ps: [] }; listesEnsemble();
}
/* Accueil, centre : ce qui est en cours ou à valider, projet par projet, puis les dernières tâches terminées */
async function resumeTravail(ps) {
  let t = [];
  try { t = await api("/api/taches"); } catch { return; }
  if (projetCourant) return;
  ps = ps || await api("/api/projets");
  tachesEnsemble = { t, ps };
  listesEnsemble();
}
let tachesEnsemble = { t: [], ps: [] }, rechercheE = "", statutE = "";
function listesEnsemble() {
  const { t, ps } = tachesEnsemble;
  const cleDe = (x) => { const c = (cibles || []).find((k) => k.id === String(x.target).split(":").pop() && (!String(x.target).includes(":") || `${k.kind}:${k.id}` === x.target)); return c ? `${c.kind}:${c.id}` : x.target; };
  const nomDe = (x) => (ps.find((p) => p.cle === cleDe(x)) || {}).nom || nomCible(x.target);
  const item = (x) => `<li data-voir="${esc(x.id)}" data-cible="${esc(cleDe(x))}">
    <div class="ligne1"><span class="etat ${couleur(x.status)}">${esc(libelleTache(x))}</span><small class="temps">${tempsTache(x)}</small></div>
    <small title="${esc(sansChaine(x.request || ""))}"><b>${esc(nomDe(x))}</b> · ${x.chaine ? "⛓ " : ""}${esc(nomTache(x))}</small>${barrePhases(x)}${actionsRapides(x)}</li>`;
  const valider = t.filter((x) => A_VALIDER.includes(x.status)), cours = t.filter((x) => EN_COURS.includes(x.status));
  const toutes = t.filter((x) => !A_VALIDER.includes(x.status) && !EN_COURS.includes(x.status));
  const sansAccent = (x) => (x || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  const q = sansAccent(rechercheE.trim());
  const filtrees = toutes.filter((x) => (!statutE || (statutE === "ok" ? ["approuvee", "appliquee"].includes(x.status) : x.status === statutE))
    && (!q || sansAccent(`${nomDe(x)} ${nomTache(x)} ${x.request} ${x.summary}`).includes(q)));
  $("#e-valider").innerHTML = valider.map(item).join("") || '<li class="vide" style="cursor:default">Rien à valider.</li>';
  $("#e-cours").innerHTML = cours.map(item).join("") || `<li class="vide" style="cursor:default">${ps.length ? "Rien en cours." : "Aucun projet pour l'instant : ajoute-en un avec ＋."}</li>`;
  $("#e-finies").innerHTML = filtrees.slice(0, 50).map(item).join("") || (toutes.length ? '<li class="vide" style="cursor:default">Aucune tâche ne correspond.</li>' : "");
  $("#e-t-finies").textContent = `Terminées (${toutes.length})`;
  $("#e-compte").textContent = (q || statutE) && toutes.length ? `${filtrees.length} sur ${toutes.length}` : "";
  if (!$("#e-statut").childElementCount) puces($("#e-statut"), STATUTS_FINIES, statutE, (v) => { statutE = v; listesEnsemble(); });
}
$("#e-recherche").oninput = () => { rechercheE = $("#e-recherche").value; listesEnsemble(); };

/* Accueil, gauche : préréglage des agents, accès directs aux réglages internes, état du studio */
function reinitLisible(t) {
  if (!t) return "";
  const s = t - Date.now() / 1000;
  if (s <= 0) return "remis à zéro";
  if (s < 3600) return `remise à zéro dans ${Math.max(1, Math.round(s / 60))} min`;
  if (s < 86400) return `remise à zéro dans ${Math.floor(s / 3600)} h ${String(Math.round((s % 3600) / 60)).padStart(2, "0")}`;
  return "remise à zéro " + new Date(t * 1000).toLocaleString("fr-FR", { weekday: "short", hour: "2-digit", minute: "2-digit" });
}
async function limitesAccueil() {
  const el = $("#limites");
  if (!el) return;
  const l = await api("/api/limites").catch(() => null);
  if (!l) { el.innerHTML = '<p class="lim-info">Limites indisponibles.</p>'; return; }
  el.innerHTML = ["Claude", "Codex"].map((nom) => {
    const x = l[nom] || {};
    if (!x.ok && x.reconnexion === "en_cours") { setTimeout(limitesAccueil, 8000); return `<div class="lim-outil"><div class="lim-tete">${nom}</div><p class="lim-info">Reconnexion de Claude Code…</p></div>`; }
    if (!x.ok && x.reconnexion === "bouton") return `<div class="lim-outil"><div class="lim-tete">${nom}</div><p class="lim-info">${esc(x.info || "Connexion expirée.")} <button class="btn petit" data-reco-claude="1">Reconnecter</button></p></div>`;
    if (!x.ok) return `<div class="lim-outil"><div class="lim-tete">${nom}</div><p class="lim-info">${esc(x.info || "Indisponible.")}</p></div>`;
    const vu = x.vu && Date.now() / 1000 - x.vu > 600 ? `relevé ${new Date(x.vu * 1000).toLocaleString("fr-FR", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" })}` : "à l'instant";
    return `<div class="lim-outil" title="${esc(x.info || "")}"><div class="lim-tete">${nom}<small>${esc(vu)}</small></div>` + x.fenetres.map((f) => {
      const c = f.pct >= 85 ? "haut" : f.pct >= 60 ? "moyen" : "";
      return `<div class="lim-ligne"><span>${esc(f.nom)}</span><span class="lim-barre"><i class="${c}" style="width:${Math.max(f.pct, 1.5)}%"></i></span><b>${Math.round(f.pct)} %</b>`
        + (f.reinit ? `<span class="lim-reinit">${esc(reinitLisible(f.reinit))}</span>` : "") + "</div>";
    }).join("") + "</div>";
  }).join("");
}
document.addEventListener("click", async (ev) => {      // Usage : reconnecter Claude Code (seulement s'il le demande)
  const b = ev.target.closest("[data-reco-claude]");
  if (!b) return;
  b.disabled = true; b.textContent = "Reconnexion…";
  try {
    const r = await api(b.dataset.recoClaude === "login" ? "/api/claude/connexion" : "/api/claude/reconnecter", {});
    if (r.ok) { bulleInfo(r.info); limitesAccueil(); majAlertes && majAlertes(); return; }
    b.closest(".lim-info").innerHTML = `${esc(r.info)} <button class="btn petit" data-reco-claude="login">Se connecter</button>`;
  } catch (e) { b.closest(".lim-info").textContent = e.message; }
});
async function retirerProjet(cle, nom) {
  if (!confirm(`Retirer « ${nom} » du studio ?\n\nRien n'est supprimé : sa fiche est rangée dans Archives\\${cle.startsWith("project:") ? "projets" : "sujets"}-retires, ses fichiers, ses tâches passées et sa mémoire restent intacts.`)) return;
  try { const r = await api(`/api/cibles/${encodeURIComponent(cle)}/retirer`, {}); cibles = await api("/api/cibles"); selection = null; chargerProjets(); alert(r.message); }
  catch (e) { alert(e.message); }
}
function nouveauProjet() {
  const d = $("#dlg-nouveau");
  formulaireNouveau($("#dlg-corps"));
  if (!d.open) d.showModal();
  $("#nv-nom").focus();
}
$("#dlg-nouveau").addEventListener("click", (e) => { if (e.target === e.currentTarget) e.currentTarget.close(); });   // clic hors de la fenêtre
function formulaireNouveau(nv) {
  nv.innerHTML = `<p class="titre" style="margin:0 0 10px">Ajouter un projet ou un sujet</p><div class="puces" id="nv-kind"></div>
    <input class="champ" id="nv-nom" placeholder="Nom (ex. Mon site web)"><input class="champ" id="nv-chemin" placeholder="Dossier du projet (C:\\…)" hidden>
    <div class="actions" style="margin:0"><button class="btn principal" id="nv-ok">Ajouter</button><button class="btn discret" id="nv-annuler">Annuler</button></div><small id="nv-msg" class="warn"></small>`;
  let kind = "project";
  puces($("#nv-kind"), [["project", "Projet (avec dossier)"], ["topic", "Sujet (sans dossier)"]], kind, (v) => { kind = v; $("#nv-chemin").hidden = v !== "project"; });
  $("#nv-chemin").hidden = false;
  $("#nv-nom").focus();
  $("#nv-annuler").onclick = (ev) => { ev.stopPropagation(); $("#dlg-nouveau").close(); };
  $("#nv-ok").onclick = async (ev) => {
    ev.stopPropagation();
    const nom = $("#nv-nom").value.trim();
    const id = nom.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
    if (!id) { $("#nv-msg").textContent = "Donne un nom."; return; }
    if (kind === "project" && !$("#nv-chemin").value.trim()) { $("#nv-msg").textContent = "Indique le dossier du projet."; return; }
    try { await api("/api/cibles", { kind, id, nom, chemin: kind === "project" ? $("#nv-chemin").value.trim() : "" }); cibles = await api("/api/cibles"); projetsListe = await api("/api/projets"); $("#dlg-nouveau").close(); selection = null; ouvrirProjet(`${kind}:${id}`); }
    catch (e) { $("#nv-msg").textContent = e.message; }
  };
}

let tachesProjet = [];
async function ouvrirProjet(cle) {
  const change = projetCourant !== cle;
  projetCourant = cle;
  try { localStorage.setItem("projet-courant", cle); } catch (e) { /* facultatif */ }
  if (selection && (change || !BLOCS_PROJET.includes(blocCourant))) blocCourant = "detail";
  else if (change || !BLOCS_PROJET.includes(blocCourant)) blocCourant = "taches";
  rendreOnglets(); rendreOngletsBloc();
  if (chatProjet !== cle) placerSuperviseur(cle);
  const p = await api(`/api/projets/${encodeURIComponent(cle)}`);
  if (projetCourant !== cle) return;
  $("#p-retirer").onclick = () => retirerProjet(cle, p.nom);
  $("#p-nom").textContent = p.nom;
  $("#p-info").textContent = `${p.kind === "project" ? "projet" : "sujet"}${p.dossier ? " · " + p.dossier : " · sans dossier"} · mémoire ${p.memoire.replace(/^studio:/, "")}`;
  $("#p-contexte").innerHTML = p.contexte ? md(p.contexte) : '<p class="vide">Pas encore de contexte.</p>';
  dessinerProfilProjet(cle, p.profil || "", p.profil_accueil || "normal");
  $("#p-modifier-ctx").hidden = !p.contexte_chemin;
  $("#p-modifier-ctx").onclick = () => ouvrir(p.contexte_chemin);
  infoCompilation(p);
  listesTaches(p.taches);
  equipeProjet(p.equipe);
  rendreOngletsBloc();
  if (selection) afficher();
}

const ETAT_CHAINE = { en_cours: "en cours", attente_fusion: "attend ta fusion", attente_application: "attend que tu appliques le résultat", en_pause: "en pause", terminee: "terminée", arretee: "arrêtée" };
function blocChaine(c) {
  if (!c) return "";
  return `<div class="chaine-bloc"><b>⛓ Chaîne « ${esc(c.titre)} »</b> · <span class="${c.statut === "en_pause" ? "warn" : c.statut === "terminee" ? "ok" : ""}">${ETAT_CHAINE[c.statut] || esc(c.statut)}</span>
    ${c.note ? `<div class="discret">${esc(c.note)}</div>` : ""}
    <ol>${c.etapes.map((e, i) => `<li class="${i === c.courant ? "courante" : ""}">${esc(e.nom_role)} — ${esc(e.demande.slice(0, 120))}${e.etat ? ` <span class="etat ${couleur(e.etat)}">${LIBELLES[e.etat] || esc(e.etat)}</span>` : ""}${e.tache && e.tache !== selection ? ` <button class="lien" data-voir="${esc(e.tache)}" data-cible="${esc(projetCourant || "")}">voir</button>` : ""}</li>`).join("")}</ol>
    ${["en_cours", "attente_fusion", "attente_application", "en_pause"].includes(c.statut) ? `<div class="actions">${c.statut === "en_pause" ? `<button class="btn" data-chaine-reprendre="${esc(c.id)}">Relancer l'étape ${c.courant + 1}</button>` : ""}${c.peut_continuer ? `<button class="btn principal" data-chaine-continuer="${esc(c.id)}">Continuer : lancer l'étape ${c.courant + 2 > c.etapes.length ? "finale" : c.courant + 2}</button>` : ""}<button class="btn discret danger" data-chaine-arreter="${esc(c.id)}">Arrêter la chaîne</button></div>` : ""}</div>`;
}
document.addEventListener("click", async (ev) => {
  const r = ev.target.closest("[data-chaine-reprendre]"), a = ev.target.closest("[data-chaine-arreter]"), c = ev.target.closest("[data-chaine-continuer]");
  if (!r && !a && !c) return;
  const bouton = r || a || c;
  if (bouton.disabled) return;
  bouton.disabled = true;
  try {
    if (c) { if (!confirm("Le travail de cette étape est-il en place (fusionné, appliqué, ou rien à reporter) ? L'étape suivante va partir.")) { bouton.disabled = false; return; } const x = await api(`/api/chaines/${c.dataset.chaineContinuer}/continuer`, {}); if (x.tid) selection = x.tid; }
    else if (a) { if (!confirm("Arrêter cette chaîne ? Les étapes déjà faites restent ; les suivantes ne partiront pas.")) return; await api(`/api/chaines/${a.dataset.chaineArreter}/arreter`, {}); }
    else { const x = await api(`/api/chaines/${r.dataset.chaineReprendre}/reprendre`, {}); selection = x.tid; }
    derniereVue = ""; setTimeout(() => ouvrirProjet(projetCourant), 300);
  } catch (e) { alert(e.message); bouton.disabled = false; }
});

/* « Retirer » un fichier des changements avant de valider : il revient à son état de départ */
document.addEventListener("click", async (ev) => {
  const b = ev.target.closest("[data-retirer]");
  if (!b) return;
  ev.preventDefault(); ev.stopPropagation();
  const nom = b.dataset.retirer;
  if (!confirm(`Retirer « ${nom.split("/").pop()} » ?\nCe changement ne sera pas appliqué. La version de l'agent reste gardée dans le dossier de la tâche.`)) return;
  b.disabled = true; b.textContent = "Retrait…";
  try {
    await api(`/api/taches/${selection}/decision`, { decision: "retirer", fichiers: [nom] });
    setTimeout(() => { derniereVue = ""; ouvrirProjet(projetCourant); }, 700);
  } catch (e) { alert(e.message); b.disabled = false; b.textContent = "Retirer"; }
}, true);

/* Diff lisible : fichier par fichier, ajouts en vert, suppressions en rouge, numéros de ligne */
function rendreDiff(texte, retirable = false) {
  if (!texte || !texte.trim()) return "";
  const lignes = texte.split("\n"), fichiers = [];
  let f = null, a = 0, b = 0;
  for (let i = 0; i < lignes.length; i++) {
    const l = lignes[i];
    if (l.startsWith("--- ") && (lignes[i + 1] || "").startsWith("+++ ")) {
      const plus = lignes[i + 1].slice(4).trim(), moins = l.slice(4).trim();
      const nom = (plus === "/dev/null" ? moins.replace(/^a\//, "") : plus.replace(/^b\//, "")).replace(/\t.*$/, "");
      f = { nom, plus: 0, moins: 0, rangs: [], nouveau: false, supprime: false, fonctions: [] }; fichiers.push(f); i++; continue;
    }
    if (!f || l.startsWith("diff --git") || l.startsWith("index ")) continue;
    const h = l.match(/^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@/);
    if (h) {
      a = +h[1]; b = +h[3]; if (h[1] === "0" && h[2] === "0") f.nouveau = true; if (h[3] === "0" && h[4] === "0") f.supprime = true;
      const ctx = l.replace(/^@@[^@]*@@\s*/, "").trim();          // fonction ou classe où se trouve la modification
      const fn = (ctx.match(/([A-Za-z_][\w:~]*)\s*\(/) || ctx.match(/(?:class|struct|def|function)\s+([\w:]+)/) || [])[1];
      if (fn && !f.fonctions.includes(fn)) f.fonctions.push(fn);
      f.rangs.push(["hunk", "", "", l]); continue;
    }
    if (l.startsWith("+")) { f.plus++; f.rangs.push(["add", "", b++, l.slice(1)]); }
    else if (l.startsWith("-")) { f.moins++; f.rangs.push(["del", a++, "", l.slice(1)]); }
    else if (l.startsWith(" ")) { f.rangs.push(["ctx", a++, b++, l.slice(1)]); }
  }
  if (!fichiers.length) return "";
  let budget = 4000;
  const tp = fichiers.reduce((n, x) => n + x.plus, 0), tm = fichiers.reduce((n, x) => n + x.moins, 0);
  const nbFn = new Set(fichiers.flatMap((x) => x.fonctions.map((fn) => x.nom + fn))).size;
  return `<section class="compte-rendu changements"><p class="titre">Changements · ${fichiers.length} fichier${fichiers.length > 1 ? "s" : ""}${nbFn ? ` · ${nbFn} fonction${nbFn > 1 ? "s" : ""}` : ""} · <span class="ok">+${tp}</span> <span class="bad">−${tm}</span></p>
    <p class="discret aide-diff">Clique sur un fichier pour voir ce qui a changé.${retirable ? " « Retirer » : le fichier n'est pas gardé (la version de l'agent reste dans le dossier de la tâche)." : ""}</p>
    ${fichiers.map((x) => {
      const rangs = x.rangs.slice(0, Math.max(0, budget)); budget -= rangs.length;
      return `<details class="fichier-diff"><summary><span class="nom-f">${esc(x.nom)}</span>${x.nouveau ? '<span class="type">nouveau</span>' : x.supprime ? '<span class="type">supprimé</span>' : ""}<span class="plus">+${x.plus}</span><span class="moins">−${x.moins}</span>${x.fonctions.length ? `<small class="fonctions">${x.fonctions.slice(0, 6).map(esc).join(" · ")}${x.fonctions.length > 6 ? ` · +${x.fonctions.length - 6}` : ""}</small>` : ""}${retirable ? `<button type="button" class="retirer-f" data-retirer="${esc(x.nom)}" title="Ne pas garder ce changement">Retirer</button>` : ""}</summary>
        <div class="diff-lignes"><table>${rangs.map(([k, n1, n2, t]) => `<tr class="${k}"><td class="n">${n1}</td><td class="n">${n2}</td><td class="t">${esc(t) || " "}</td></tr>`).join("")}</table>
        ${rangs.length < x.rangs.length ? `<p class="discret" style="padding:4px 8px">… ${x.rangs.length - rangs.length} lignes de plus : « Ouvrir le dossier » pour le diff complet.</p>` : ""}</div></details>`;
    }).join("")}</section>`;
}

const ETATS_ROLE = { travaille: "travaille", attend_mel: "attend ton accord", en_pause: "en pause", ailleurs: "occupé ailleurs", libre: "libre" };
function voirDetail() {
  const d = $("#detail");
  if (!d) return;
  if (projetCourant) choisirBloc("detail");
  d.scrollTop = 0;                                          // la tâche choisie s'affiche depuis son début, dans son bloc
  if (window.innerWidth <= 900) d.scrollIntoView({ behavior: matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth", block: "start" });
}
function equipeProjet(eq) {
  if (!eq) return;
  const nomCible = (c) => c.replace(/^(project|topic):/, "");
  const carte = (r) => {
    const ici = r.ici[0], ailleurs = r.ailleurs[0];
    const quoi = ici ? `<a href="#" data-tache="${esc(ici.tache)}" title="${esc(sansChaine(ici.demande))}">${esc(ici.titre || court(ici.demande))}</a>${ici.etape ? `<small>étape : ${esc(ici.etape)}</small>` : ""}`
      : ailleurs ? `<small>sur ${esc(nomCible(ailleurs.cible))}</small>` : "";
    return `<div class="agent ${r.etat}${r.adapte ? "" : " sur-demande"}" title="${esc(r.nom)}${r.adapte ? "" : " — sur demande pour ce projet"}">
      <div class="tete"><span class="point ${r.etat}"></span><b>${esc(r.nom)}</b></div>
      <small>${esc(OUTILS[r.outil] || r.outil)}${r.modele ? " · " + esc(r.modele) : ""}${r.adapte ? "" : " · sur demande"}</small>
      ${quoi}
      <span class="etat-a ${r.etat === "libre" ? "ok" : r.etat === "en_pause" ? "bad" : "warn"}">${ETATS_ROLE[r.etat]}</span></div>`;
  };
  const n = eq.filter((r) => r.etat === "travaille").length;
  const rang = { travaille: 0, attend_mel: 1, en_pause: 2, ailleurs: 3, libre: 4 };
  const ordre = [...eq].sort((x, y) => (rang[x.etat] - rang[y.etat]) || (y.adapte - x.adapte));   // qui travaille d'abord
  const rangee = $("#p-equipe");
  rangee.innerHTML = ordre.map(carte).join("");
  $$("#p-equipe a[data-tache]").forEach((a) => (a.onclick = (ev) => { ev.preventDefault(); selection = a.dataset.tache; derniereVue = ""; afficher(); voirDetail(); }));
}

/* Équipe du projet : les métiers communs, réglés pour ce projet (actif, modèle, effort, consignes) + ses serveurs MCP */
async function equipeReglages() {
  const el = $("#p-equipe-reglages"), cle = projetCourant;
  if (!el || !cle) return;
  let v;
  try { v = await api(`/api/equipes/projet?cible=${encodeURIComponent(cle)}`); } catch (e) { el.innerHTML = `<p class="warn">${esc(e.message)}</p>`; return; }
  if (projetCourant !== cle) return;
  const opt = (items, sel) => items.map(([k, t]) => `<option value="${esc(k)}"${k === sel ? " selected" : ""}>${esc(t)}</option>`).join("");
  const nomM = (m) => (MODELES_SUP.find(([k]) => k === m) || [m, m || "auto"])[1];
  const nomE = (e) => (EFFORTS.find(([k]) => k === e) || [e, e || "auto"])[1];
  const lignes = v.roles.map((r) => `<tr class="${r.actif ? "" : "inactif"}" data-role="${esc(r.id)}">
      <td><label style="display:flex;gap:8px;align-items:center"><input type="checkbox" data-eq="actif" ${r.actif ? "checked" : ""}><span><b>${esc(r.nom)}</b>${r.propre ? '<span class="pastille">propre au projet</span>' : ""}${r.personnalise ? '<span class="pastille perso">réglé ici</span>' : ""}<br><small class="discret">${esc(OUTILS[r.outil] || r.outil)}</small></span></label></td>
      <td>${r.outil === "claude-code" ? `<select data-eq="modele">${opt([["", `Commun (${nomM(r.modele_commun)})`], ...MODELES_SUP.filter(([k]) => k)], r.modele)}</select>` : '<small class="discret">celui de l\'outil</small>'}</td>
      <td class="col-effort"><select data-eq="effort">${opt([["", `Commun (${nomE(r.effort_commun)})`], ...EFFORTS.filter(([k]) => k)], r.effort)}</select></td>
      <td><button class="btn discret petit" data-eq-consignes="1" title="${esc(r.consignes || "Consignes propres à ce projet")}">${r.consignes ? "Consignes ●" : "Consignes"}</button></td></tr>`).join("");
  const mcp = v.mcp.length ? `<p class="sous-titre-g" style="margin-top:14px">Serveurs MCP de ce projet</p><div class="puces petites">${v.mcp.map((m) => `<label class="puce${m.actif ? " sel" : ""}" style="cursor:pointer"><input type="checkbox" data-mcp-p="${esc(m.nom)}" ${m.actif ? "checked" : ""} hidden>${esc(m.nom)}</label>`).join("")}</div>
      <small class="discret">${v.mcp_regle ? "Choix propre à ce projet." : "Tous actifs (aucun choix propre)."} Ajoute des serveurs dans Extensions › Connecteurs.</small>` : "";
  el.innerHTML = `<p class="sous-titre-g" style="margin-top:16px">Réglages de l'équipe pour ce projet</p>
    <p class="aide-g discret">Les métiers sont communs à tous les projets. Ici, tu choisis ceux qui servent à ce projet, leur modèle, leur effort et des consignes propres. Une demande précise passe toujours avant.</p>
    <div class="matrice-defile"><table class="equipe-reglages"><thead><tr><th>Métier</th><th>Modèle</th><th class="col-effort">Effort</th><th></th></tr></thead><tbody>${lignes}</tbody></table></div>
    <div class="actions" style="margin:10px 0 0"><button class="btn" id="eq-creer">Créer un agent pour ce projet</button></div>${mcp}`;
  const regler = async (role, champs) => { try { await api("/api/equipes/role", { cible: cle, role, ...champs }); equipeReglages(); } catch (e) { alert(e.message); } };
  $$("#p-equipe-reglages tr[data-role]").forEach((tr) => {
    const role = tr.dataset.role;
    tr.querySelector('[data-eq="actif"]').onchange = (ev) => regler(role, { actif: ev.target.checked });
    const m = tr.querySelector('[data-eq="modele"]'); if (m) m.onchange = (ev) => regler(role, { modele: ev.target.value });
    tr.querySelector('[data-eq="effort"]').onchange = (ev) => regler(role, { effort: ev.target.value });
    tr.querySelector("[data-eq-consignes]").onclick = () => {
      const r = v.roles.find((x) => x.id === role);
      $("#perso-fiche-corps").innerHTML = `<h2>${esc(r.nom)}</h2><div class="meta">Consignes propres à ce projet (ajoutées à chaque mission de ce métier ici)</div>
        <div class="consignes-p"><textarea id="eq-consignes" placeholder="Ex. : Unreal 5.6, C++ seulement, suis les conventions du CLAUDE.md, teste en PIE.">${esc(r.consignes)}</textarea></div>
        <p class="warn" id="fiche-msg"></p><div class="bas"><button class="btn discret" data-fermer-fiche="1">Annuler</button><button class="btn principal" id="eq-consignes-ok">Enregistrer</button></div>`;
      $("#perso-fiche").hidden = false;
      $("#eq-consignes-ok").onclick = async () => { try { await api("/api/equipes/role", { cible: cle, role, consignes: $("#eq-consignes").value }); $("#perso-fiche").hidden = true; equipeReglages(); } catch (e) { $("#fiche-msg").textContent = e.message; } };
    };
  });
  $$("#p-equipe-reglages [data-mcp-p]").forEach((c) => (c.onchange = async () => {
    const noms = [...$$("#p-equipe-reglages [data-mcp-p]")].filter((x) => x.checked).map((x) => x.dataset.mcpP);
    try { await api("/api/equipes/mcp", { cible: cle, noms }); equipeReglages(); } catch (e) { alert(e.message); }
  }));
  $("#eq-creer").onclick = () => { agentProjet = cle; $("#creer-agent").onclick(); };
}
let agentProjet = "";
document.addEventListener("click", (ev) => { if (ev.target.closest("[data-fermer-fiche]") && vue !== "perso") $("#perso-fiche").hidden = true; });

const ACTIVES = ["creee", "en_cours", "en_attente_creneau"];
function tempsTache(x) {
  if (ACTIVES.includes(x.status) && x.etape_depuis) return `⏱ ${chrono(x.etape_depuis, x.duree_s)}`;
  return x.duree_s ? `⏱ ${duree(x.duree_s)}` : "";
}
const sansChaine = (t) => String(t || "").split("\n\n---\nÉtape ")[0];
/* Nom court d'une tâche (même règle que studio/titres.py) : le titre donné, sinon la 1re phrase de la demande, 60 car. */
function court(demande, maxi = 60) {
  let t = sansChaine(demande).replace(/[`*#>]+/g, "").replace(/(?<!\w)_+|_+(?!\w)/g, "");   // garde L_Exploration
  const a = /\$audit-(skills|memories)\s+(audit|fix|clean)\b/.exec(t);
  if (a) return (a[2] === "audit" ? "Audit des " : "Appliquer l'audit des ") + (a[1] === "skills" ? "skills" : "mémoires");
  t = t.split(/\s+/).join(" ").replace(/^(objectif|but|tâche|tache|demande|mission|contexte|résumé|resume|titre|todo|à faire|a faire)\s*[:：\-–—]\s*/i, "");
  t = t.split(/(?<=[.!?])\s|\s(?:où|ou|contexte|lis|lire|cible|livrable|critères?|périmètre)\s*:\s/i)[0].replace(/^[\s.;:\-–—]+|[\s.;:\-–—]+$/g, "");
  if (t.length > maxi) { const v = t.lastIndexOf(", ", maxi); if (v >= 25) t = t.slice(0, v); }
  if (t.length > maxi) t = (t.slice(0, maxi).replace(/\s+\S*$/, "").replace(/[\s,;:\-–—(]+$/, "") || t.slice(0, maxi)) + "…";
  return t ? t[0].toUpperCase() + t.slice(1) : "Tâche";
}
/* Le nom du projet ne sert à rien dans le titre : on voit déjà l'onglet (« … sur RPG3D » → « … ») */
function sansProjet(t, noms) {
  for (const n of [...new Set(noms.filter((x) => x && x.length >= 2))].sort((a, b) => b.length - a.length)) {
    const e = n.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    t = t.replace(new RegExp(`\\s*\\b(sur|dans|de|du|pour|à|au)\\s+(le\\s+projet\\s+|le\\s+)?${e}(?![\\w-])`, "gi"), "")
      .replace(new RegExp(`^\\s*${e}\\s*[:：\\-–—]\\s*`, "i"), "").replace(new RegExp(`\\s*\\(\\s*${e}\\s*\\)`, "gi"), "");
  }
  return t.split(/\s+/).join(" ").replace(/^[\s,;:\-–—]+|[\s,;:\-–—]+$/g, "");
}
const nomTache = (x) => {
  const cible = String(x.target || ""), id = cible.split(":").pop();
  const t = x.titre || (x.options && x.options.titre) || court(x.request || x.summary || "", 400);
  return court(sansProjet(t, [nomCible(cible), id]) || t, 50);
};   // le rappel de chaîne reste pour l'agent, pas pour la liste
/* Carte de tâche : barre d'avancement (Plan → Agent → Vérif → Relecture → Fini) et dernière action quand elle tourne,
   boutons directs quand elle attend l'utilisateur (Valider, Corriger, Reprendre) : une décision en un clic, sans ouvrir le détail. */
const PHASES = [["Plan", ["demande", "choix_cible", "contexte", "plan", "unreal"]], ["Agent", ["execution"]], ["Vérif", ["verification"]],
  ["Relecture", ["audit"]], ["Fini", ["presentation", "approbation", "application", "fusion", "finalisation", "memoire"]]];
function barrePhases(x) {
  if (!["creee", "en_cours"].includes(x.status)) return "";
  const i = Math.max(0, PHASES.findIndex(([, noms]) => noms.includes(x.etape_nom)));
  return `<div class="phases" role="img" aria-label="Étape : ${PHASES[i][0]}">${PHASES.map(([n], k) => `<span class="${k < i ? "faite" : k === i ? "active" : ""}">${n}</span>`).join("")}</div>
    ${x.derniere_action ? `<small class="action-en-cours">${esc(x.derniere_action)}${(+x.essai || 1) > 1 ? ` · essai ${x.essai}` : ""}</small>` : ""}`;
}
function actionsRapides(x) {
  if (A_VALIDER.includes(x.status)) return `<div class="rapides"><button class="btn principal petit" data-rapide="valider" data-tid="${esc(x.id)}" title="Valider sans ouvrir la tâche">Valider</button><button class="btn petit" data-rapide="corriger" data-tid="${esc(x.id)}">Corriger</button></div>`;
  if (["bloquee", "interrompue", "echec"].includes(x.status)) return `<div class="rapides">${x.summary ? `<small class="raison-blocage">${esc(String(x.summary).split("\n")[0].slice(0, 120))}</small>` : ""}<button class="btn principal petit" data-rapide="reprendre" data-tid="${esc(x.id)}">Reprendre</button></div>`;
  return "";
}
function itemTache(x) {
  return `<li data-id="${x.id}" class="${x.id === selection ? "sel" : ""}">
    <div class="ligne1"><span class="etat ${couleur(x.status)}">${esc(libelleTache(x))}${x.chaine ? `</span><span class="badge-chaine" title="Étape d'une chaîne">⛓ ${(+x.etape || 0) + 1}` : ""}</span><small class="temps">${tempsTache(x)}</small></div>
    <small title="${esc(sansChaine(x.request || ""))}">${esc(nomTache(x))}</small>${barrePhases(x)}${actionsRapides(x)}</li>`;
}
document.addEventListener("click", async (e) => {         // boutons directs des cartes : avant le clic qui ouvre la tâche
  const b = e.target.closest("[data-rapide]");
  if (!b) return;
  e.stopPropagation(); e.preventDefault();
  const tid = b.dataset.tid, a = b.dataset.rapide;
  try {
    if (a === "valider") {
      const s = await api(`/api/taches/${tid}`);
      await api(`/api/taches/${tid}/decision`, { decision: "approuver", empreinte: s.empreinte });
      bulleInfo("Validée");
    } else if (a === "corriger") {
      const c = prompt("Que faut-il corriger ?"); if (!c) return;
      await api(`/api/taches/${tid}/decision`, { decision: "corriger", commentaire: c }); bulleInfo("Correction demandée");
    } else if (a === "annuler") {
      if (!confirm("Annuler cette tâche ?")) return;
      await api(`/api/taches/${tid}/annuler`, {}); bulleInfo("Tâche annulée");
    } else if (a === "stop") {
      b.disabled = true; b.textContent = "Arrêt…";
      await api(`/api/taches/${tid}/arreter`, {}); bulleInfo("Arrêtée : « Reprendre » la relance là où elle en était");
    } else if (a === "reprendre") {
      b.disabled = true; b.textContent = "Reprise…";
      await api(`/api/taches/${tid}/reprendre`, {});
      setTimeout(async () => { const x = await api(`/api/taches/${tid}`).catch(() => null); if (x && x.tache.status === "bloquee") bulleInfo("Toujours bloquée : " + (x.tache.summary || "").split("\n")[0].slice(0, 120)); }, 1500);
    }
  } catch (er) { bulleInfo(er.message); }
  setTimeout(() => { derniereVue = ""; if (projetCourant) ouvrirProjet(projetCourant); else resumeTravail(); majBadge(); if (blocCourant === "branches") detailGit(); }, 600);
}, true);
let rechercheFinies = "", statutFinies = "";
const STATUTS_FINIES = [["", "Toutes"], ["ok", "Validées"], ["annulee", "Annulées"]];
function listesTaches(t) {
  tachesProjet = t;
  const valider = t.filter((x) => A_VALIDER.includes(x.status)), cours = t.filter((x) => EN_COURS.includes(x.status));
  const toutes = t.filter((x) => !A_VALIDER.includes(x.status) && !EN_COURS.includes(x.status));
  const q = rechercheFinies.trim().toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  const sansAccent = (x) => (x || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  const filtrees = toutes.filter((x) => (!statutFinies || (statutFinies === "ok" ? ["approuvee", "appliquee"].includes(x.status) : x.status === statutFinies))
    && (!q || sansAccent(`${x.request} ${x.summary} ${x.id}`).includes(q)));
  const finies = filtrees.slice(0, 50);
  $("#l-valider").innerHTML = valider.map(itemTache).join("") || '<li class="vide" style="cursor:default">Rien à valider.</li>';
  $("#l-cours").innerHTML = cours.map(itemTache).join("") || '<li class="vide" style="cursor:default">Rien en cours.</li>';
  $("#l-finies").innerHTML = finies.map(itemTache).join("") || (toutes.length ? '<li class="vide" style="cursor:default">Aucune tâche ne correspond.</li>' : "");
  $("#t-finies").textContent = `Terminées (${toutes.length})`;
  $("#f-compte").textContent = filtrees.length > finies.length ? `${finies.length} affichées sur ${filtrees.length} : précise la recherche.` : (q || statutFinies) && toutes.length ? `${filtrees.length} sur ${toutes.length}` : "";
  if (!$("#f-statut").childElementCount) puces($("#f-statut"), STATUTS_FINIES, statutFinies, (v) => { statutFinies = v; listesTaches(tachesProjet); });
  $$("#volet-taches li[data-id]").forEach((li) => (li.onclick = () => { selection = li.dataset.id; derniereVue = ""; afficher(); listesTaches(t); voirDetail(); }));
  rendreOngletsBloc();
}
$("#f-recherche").oninput = () => { rechercheFinies = $("#f-recherche").value; listesTaches(tachesProjet); };

$(".logo").onclick = (e) => { e.preventDefault(); montrer("projets"); };

async function afficher() {
  if (!selection) return;
  const s = await api(`/api/taches/${selection}`);
  const t = s.tache;
  const cle = `${t.id}|${t.status}|${t.updated_at}|${s.etapes.length}|${s.attend_decision}|${s.chaine ? s.chaine.statut + s.chaine.courant + s.chaine.note : ""}`;
  if (cle === derniereVue) return;
  derniereVue = cle;
  const [res, dif] = await Promise.all([api(`/api/taches/${selection}/resultat`),
    ACTIVES.includes(t.status) ? Promise.resolve({ texte: "" }) : api(`/api/taches/${selection}/diff`).catch(() => ({ texte: "" }))]);
  const eq = s.equipe || {};
  const qui = eq.producteur ? `${esc(eq.producteur.role)} via ${esc(OUTILS[eq.producteur.outil] || eq.producteur.outil)} · relu par ${esc(OUTILS[eq.auditeur.outil] || eq.auditeur.outil)}` : "";
  const enCours = EN_COURS.includes(t.status);
  // Le résultat (RESULTAT.md) est découpé : compte rendu en avant, le reste replié
  const SECTIONS = ["Résumé de l'exécutant", "Fichiers", "Vérifications", "Audit", "Actions dans l'éditeur Unreal", "Commandes lancées", "Tentatives précédentes"];
  const sec = { _tete: "" };
  let courante = "_tete";
  (res.texte || "").replace(/\r\n/g, "\n").split("\n").forEach((l) => {
    const m = /^## (.+)$/.exec(l);
    if (m && SECTIONS.some((k) => m[1].trim() === k || m[1].startsWith(k + " ") || m[1].startsWith(k + " —"))) { courante = m[1].trim(); sec[courante] = ""; }
    else sec[courante] += l + "\n";
  });
  Object.keys(sec).forEach((k) => (sec[k] = sec[k].trim()));
  const basTitres = (txt) => txt.replace(/^#{1,3}(?=[ \t])/gm, "####");   // titres de l'agent : jamais au niveau du studio
  const cleCR = Object.keys(sec).find((k) => k.startsWith("Résumé de l'exécutant"));
  const compteRendu = cleCR ? basTitres(sec[cleCR]) : "";
  const fichiers = (sec["Fichiers"] || "").split("\n").filter((l) => l.startsWith("- ")).map((l) => l.slice(2).split(" : ")).filter(([, v]) => v && v !== "—");
  const nbFichiers = fichiers.reduce((n, [, v]) => n + v.split(", ").length, 0);
  const verifs = (sec["Vérifications"] || "").split("\n").filter((l) => l.startsWith("- "));
  const defauts = (sec["Audit"] || "").split("\n").filter((l) => l.startsWith("- ") && !l.includes("Aucun défaut"));
  const verifOk = verifs.length && verifs.every((l) => l.includes("✔"));
  const actionsUE = (sec["Actions dans l'éditeur Unreal"] || "").split("\n").filter((l) => l.startsWith("- ")).map((l) => l.slice(2));
  const ecrituresUE = actionsUE.filter((l) => l.startsWith("écriture")).length;
  const rienAppliquer = !nbFichiers;
  const puce = (ok, texte) => `<span class="puce-etat ${ok ? "ok" : "bad"}">${ok ? "✔" : "✘"} ${esc(texte)}</span>`;
  const verdict = res.texte ? `<div class="verdict-tache"><span class="puce-etat">${rienAppliquer ? "aucun fichier modifié" : `${nbFichiers} fichier${nbFichiers > 1 ? "s" : ""} modifié${nbFichiers > 1 ? "s" : ""}`}</span>
      ${actionsUE.length ? `<span class="puce-etat${ecrituresUE ? " ue" : ""}">Unreal : ${actionsUE.length} action${actionsUE.length > 1 ? "s" : ""}${ecrituresUE ? ` dont ${ecrituresUE} modification${ecrituresUE > 1 ? "s" : ""}` : ", lecture"}</span>` : ""}
      ${verifs.length ? puce(verifOk, verifOk ? "vérifications OK" : "vérifications en échec") : ""}${puce(!defauts.length, defauts.length ? `${defauts.length} défaut${defauts.length > 1 ? "s" : ""} à la relecture` : "relecture OK")}</div>` : "";
  const fautif = t.status === "a_approuver_avec_defauts";
  const BTN_DOSSIER = `<button class="btn discret dossier-bas" id="dossier" title="Ouvre le dossier de la tâche dans l'Explorateur">Ouvrir le dossier</button>`;
  const decision = s.attend_decision
    ? `<div class="decision-bas"><p class="aide-decision">${rienAppliquer
        ? (ecrituresUE ? `Aucun fichier du dépôt modifié, mais ${ecrituresUE} modification${ecrituresUE > 1 ? "s" : ""} faite${ecrituresUE > 1 ? "s" : ""} directement dans l'éditeur Unreal (voir Détails). Classe la tâche, ou demande une correction.`
          : "Rien à appliquer : ce compte rendu ne modifie aucun fichier. Classe-le, ou demande une correction.")
        : nbFichiers > 1 ? `Valider applique exactement ces ${nbFichiers} fichiers au projet.` : "Valider applique exactement ce fichier au projet."}${fautif ? " <b class=\"warn\">La relecture a relevé des défauts.</b>" : ""}</p>
       <div class="decision"><button class="btn principal" id="ok">${rienAppliquer ? "Classer" : "Valider"}</button><button class="btn" id="corr">Demander une correction</button><button class="btn discret danger" id="ann">Annuler</button>${BTN_DOSSIER}</div></div>`
    : ACTIVES.includes(t.status) ? `<div class="decision-bas"><div class="decision"><button class="btn" id="stop" title="Arrête l'agent ; « Reprendre » le relance là où il en était (même conversation, rien n'est refait)">Stop</button><button class="btn discret danger" id="ann">Annuler</button>${BTN_DOSSIER}</div></div>`
    : enCours ? `<div class="decision-bas">${["bloquee", "interrompue", "echec"].includes(t.status) && t.summary ? `<p class="raison-blocage">${esc(t.status === "bloquee" ? "Bloquée : " : "")}${esc(t.summary.split("\n")[0].slice(0, 220))}</p>` : ""}<div class="decision"><button class="btn principal" id="rep">Reprendre</button><button class="btn discret danger" id="ann">Annuler</button>${BTN_DOSSIER}</div></div>`
    : `<div class="decision-bas"><div class="decision">${BTN_DOSSIER}</div></div>`;
  const demande = sansChaine(t.request || "");
  const titreCourt = nomTache(t);
  const actif = ACTIVES.includes(t.status);
  const dureeEtape = (e) => e.ended_at ? duree(secondes(e.started_at, e.ended_at)) : (actif && e.status === "en_cours" ? chrono(e.started_at) : "—");
  const travail = s.etapes.filter((e) => e.ended_at).reduce((n, e) => n + secondes(e.started_at, e.ended_at), 0);
  const enCoursE = s.etapes.find((e) => !e.ended_at && e.status === "en_cours");
  const parType = {};
  s.etapes.filter((e) => e.ended_at).forEach((e) => (parType[e.name] = (parType[e.name] || 0) + secondes(e.started_at, e.ended_at)));
  const detailTemps = ["execution", "audit", "verification"].filter((k) => parType[k] >= 1).map((k) => `${k} ${duree(parType[k])}`).join(" · ");
  const temps = `<small class="temps-tache">⏱ Temps de travail : <b>${actif && enCoursE ? chrono(enCoursE.started_at, travail) : duree(travail)}</b>${detailTemps ? ` (${detailTemps})` : ""}</small>`;
  // Étapes et journal en français simple : ce qui s'est passé, dans l'ordre, sans jargon
  const NOM_ETAPE = { demande: "Demande reçue", choix_cible: "Projet choisi", contexte: "Contexte et mémoire lus", plan: "Plan préparé",
    unreal: "Unreal ouvert", execution: "L'agent travaille", verification: "Vérifications", audit: "Relecture par un 2e agent",
    approbation: "En attente de ta décision", application: "Résultat appliqué", fusion: "Fusion", graphe: "Studio" };
  const ETAT_ETAPE = { termine: "✔ fini", en_cours: "en cours…", echec: "✘ échec", erreur: "✘ erreur", annule: "annulé" };
  const clair = (t) => String(t || "").replace("serveur unreal-mcp déjà en ligne", "déjà connecté").replace("unreal-mcp prêt", "connexion prête")
    .replace("unreal-mcp injoignable", "connexion impossible").replace(/serveur unreal-mcp|unreal-mcp/g, "connexion à Unreal").replace(/\bMCP\b/g, "connexion")
    .replace(/worktree/gi, "copie de travail").replace(/\bcommit\b/g, "commit");
  const DETAIL_ETAPE = (e) => clair( e.name === "choix_cible" ? nomCible(e.detail) : e.name === "plan" ? "" : e.name === "contexte" ? (e.detail.includes("OK") ? "OK" : e.detail) : e.detail);
  const ordreEtapes = [...s.etapes].sort((a, b) => (a.started_at < b.started_at ? -1 : 1));
  const etapes = ordreEtapes.map((e) => `<tr><td>${esc(NOM_ETAPE[e.name] || e.name)}${e.attempt > 1 ? ` <small class="discret">(essai ${e.attempt})</small>` : ""}</td>
    <td class="nowrap ${e.status === "termine" ? "ok" : e.status === "en_cours" ? "info" : "bad"}">${esc(ETAT_ETAPE[e.status] || e.status)}</td>
    <td class="nowrap">${dureeEtape(e)}</td><td>${esc(DETAIL_ETAPE(e)).slice(0, 140)}</td></tr>`).join("");
  const heure = (iso) => { try { return new Date(iso).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit", second: "2-digit" }); } catch { return iso; } };
  const journal = s.evenements.map((e) => `<li><span class="heure">${esc(heure(e.at))}</span>${esc(clair(e.message.replace(/^Statut : (\w+)/, (m, x) => "Statut : " + (LIBELLES[x] || x))))}</li>`).join("");
  // Actualisation de la même tâche : la page garde sa hauteur et ses parties chargées à part (en direct, captures,
  // fichiers dépliés) le temps qu'elles se rechargent, sinon le téléphone remonte tout seul.
  const dEl = $("#detail"), memeTache = dEl.dataset.tid === t.id;
  const ancienDirect = memeTache && $("#direct-tache") ? $("#direct-tache").innerHTML : "";
  const ancienCaptures = memeTache && $("#captures-tache") ? $("#captures-tache").innerHTML : "";
  const ouverts = memeTache ? [...$$("#detail details[open]")].map((x) => x.querySelector("summary") && x.querySelector("summary").textContent) : [];
  if (memeTache) { dEl.style.minHeight = dEl.offsetHeight + "px"; clearTimeout(dEl._libre); dEl._libre = setTimeout(() => (dEl.style.minHeight = ""), 3000); }
  else dEl.style.minHeight = "";
  dEl.dataset.tid = t.id;
  $("#detail").innerHTML = `<div class="entete-tache"><span class="etat ${couleur(t.status)}">${libelleTache(t)}</span>
      <h2 title="${esc(demande)}">${esc(titreCourt)}</h2>${demande.trim() !== titreCourt ? `<details class="pli demande-complete"><summary>Demande complète</summary><p>${esc(demande)}</p></details>` : ""}
      ${qui ? `<small>${qui}${t.options && t.options.modele ? " · modèle " + esc(t.options.modele) : ""}${t.options && t.options.effort ? " · effort " + esc(LIB_EFFORT[t.options.effort] || t.options.effort) : ""}</small>` : ""}${temps}</div>
    ${s.simulation ? '<div class="alerte">Simulation : aucun modèle n\'a été appelé. Ce résultat montre le parcours, pas une capacité réelle.</div>' : ""}
    ${s.memoire && s.memoire !== "OK" ? `<div class="alerte">Mémoire partagée : ${esc(s.memoire)}</div>` : ""}
    ${blocChaine(s.chaine)}
    ${actionsBranche(s, t)}
    ${["bloquee", "interrompue", "echec"].includes(t.status) && t.summary ? `<div class="alerte">${esc(t.summary)}</div>` : ""}
    ${verdict}
    ${compteRendu ? `<section class="compte-rendu"><p class="titre">Résumé</p>${md(compteRendu.replace(/^\s*[*_]*En bref[*_]*\s*:?[*_]*\s*/i, ""))}</section>`
      : res.texte ? md(res.texte) : `<p class="vide">${t.status === "bloquee" ? "Bloquée : rien n'a été produit." : enCours ? "L'équipe travaille… la page se met à jour toute seule." : "Pas de résultat."}</p>`}
    ${boutonAudit(t)}
    <div id="captures-tache">${ancienCaptures}</div>
    ${defauts.length ? `<details class="pli defauts-pli"><summary>Défauts relevés à la relecture (${defauts.length})</summary><ul>${defauts.map((l) => `<li>${esc(l.slice(2)).slice(0, 400)}</li>`).join("")}</ul></details>` : ""}
    ${rendreDiff(dif.texte, ["a_approuver", "a_approuver_avec_defauts"].includes(t.status))}
    <section class="direct-tache" id="direct-tache"${ancienDirect ? "" : " hidden"}>${ancienDirect}</section>
    <section class="details-tache">
      <p class="sous-titre-g">Étapes</p><table class="etapes-tache">${etapes}</table>
      <p class="sous-titre-g">Journal</p><ul class="journal-tache">${journal || '<li class="discret">Rien pour l\'instant.</li>'}</ul>
    </section>
    <div id="annuler-app"></div>
    ${decision}`;
  if (ouverts.length) $$("#detail details").forEach((x) => { const su = x.querySelector("summary"); if (su && ouverts.includes(su.textContent)) x.open = true; });
  activiteTache(t.id, ACTIVES.includes(t.status));
  if (["appliquee", "approuvee"].includes(t.status)) api(`/api/taches/${t.id}/annulable`).then((a) => {
    const el = $("#annuler-app");
    if (!el || !a.possible || selection !== t.id) return;
    el.innerHTML = `<div class="annuler-app"><button class="btn discret danger" id="defaire">Annuler ce qui a été appliqué</button><small class="discret">${esc(a.texte)}</small></div>`;
    $("#defaire").onclick = async (ev) => {
      if (!confirm(`Annuler ce que cette tâche a appliqué à ton projet ?\n\n${a.texte}`)) return;
      ev.currentTarget.disabled = true;
      try { const r = await api(`/api/taches/${t.id}/defaire`, {}); bulleInfo(r.message); derniereVue = ""; afficher(); }
      catch (e) { alert(e.message); ev.currentTarget.disabled = false; }
    };
  }).catch(() => {});
  api(`/api/taches/${t.id}/captures`).then((l) => {
    const el = $("#captures-tache");
    if (!el || !l.length) return;
    el.innerHTML = `<details class="pli captures"${l.length <= 6 ? " open" : ""}><summary>Captures (${l.length})</summary><div class="grille-captures">${l.map((n) => `<a href="/api/taches/${esc(t.id)}/captures/${encodeURIComponent(n)}" target="_blank" rel="noopener" title="${esc(n)} — ouvrir en grand"><img src="/api/taches/${esc(t.id)}/captures/${encodeURIComponent(n)}" alt="${esc(n)}" loading="lazy"><small>${esc(n)}</small></a>`).join("")}</div></details>`;
  }).catch(() => {});
  const act = (sel, fn) => { const b = $(sel); if (b) b.onclick = fn; };
  const apres = () => setTimeout(() => { derniereVue = ""; ouvrirProjet(projetCourant); majBadge(); }, 400);
  act("#ok", () => api(`/api/taches/${selection}/decision`, { decision: "approuver", empreinte: s.empreinte }).then(apres));
  act("#corr", () => { const c = prompt("Que faut-il corriger ?"); if (c) api(`/api/taches/${selection}/decision`, { decision: "corriger", commentaire: c }).then(apres); });
  act("#ann", () => confirm("Annuler cette tâche ?") && api(`/api/taches/${selection}/annuler`, {}).then(apres));
  act("#rep", () => { $("#rep").disabled = true; $("#rep").textContent = "Reprise…";
    api(`/api/taches/${selection}/reprendre`, {}).then(() => setTimeout(async () => {
      const x = await api(`/api/taches/${selection}`).catch(() => null);
      if (x && x.tache.status === "bloquee") bulleInfo("Toujours bloquée : " + (x.tache.summary || "").split("\n")[0].slice(0, 120));
      apres();
    }, 1500)).catch((e) => { bulleInfo(e.message); apres(); }); });
  act("#stop", () => { $("#stop").disabled = true; $("#stop").textContent = "Arrêt…"; api(`/api/taches/${selection}/arreter`, {}).then(apres).catch((e) => alert(e.message)); });
  act("#dossier", () => ouvrir(t.id));
  act("#fusionner", async () => {
    $("#f-msg").textContent = "Fusion…";
    try { const r = await api(`/api/taches/${selection}/fusionner`, {}); $("#f-msg").textContent = r.message; derniereVue = ""; setTimeout(afficher, 600); }
    catch (e) { $("#f-msg").textContent = e.message; }
  });
  act("#compiler-t", () => compilerProjet(t.target, "#f-msg"));
  act("#commit-d", () => choisirBloc("branches"));
  act("#appliquer-audit", () => confirm("Appliquer les corrections de cet audit ? Rien n'est supprimé : ce qui part va en archive, dans la copie du projet.")
    && lancerAudit({ cible: t.target, quoi: $("#appliquer-audit").dataset.quoi, mode: "appliquer", depuis: t.id }));

}

/* Audit fini (compte rendu) : bouton pour appliquer ses corrections dans une nouvelle tâche */
function boutonAudit(t) {
  const m = /^\$audit-(skills|memories) audit/.exec(t.request || "");
  if (!m || !["approuvee", "appliquee"].includes(t.status)) return "";
  const quoi = m[1] === "skills" ? "skills" : "memoires";
  return `<div class="actions-branche"><button class="btn principal" id="appliquer-audit" data-quoi="${quoi}">Appliquer les corrections</button>
    <span class="discret">${quoi === "skills" ? "Corrections sûres dans le projet ; les skills globaux restent listés pour toi." : "Dans la copie du projet ; rien n'est supprimé (archives)."}</span></div>`;
}

/* Fusion et compilation (tâches faites dans une branche, projets avec une commande « build ») */
function actionsBranche(s, t) {
  if (!s.worktree || s.rien_a_appliquer || !["approuvee", "appliquee"].includes(t.status)) return "";
  const f = s.fusion;
  const sale = !f && s.depot_modifie;                // fusion impossible tant que des fichiers suivis sont modifiés
  const fusion = f ? `<span class="ok">✔ Fusionnée dans ${esc(f.branche)} (${esc(f.commit)})</span>`
    : sale ? `<button class="btn principal" id="commit-d" title="Ouvre l'onglet Branches : coche les fichiers, clique Commit, puis reviens fusionner">Commit d'abord (${s.depot_modifie} fichier${s.depot_modifie > 1 ? "s" : ""})</button><button class="btn" id="fusionner" disabled title="Possible après le commit">Fusionner dans ${esc(s.branche_depart || "la branche de départ")}</button>`
    : `<button class="btn principal" id="fusionner">Fusionner dans ${esc(s.branche_depart || "la branche de départ")}</button>`;
  const comp = s.compilable ? `<button class="btn" id="compiler-t">Compiler</button>` : "";
  return `<div class="actions-branche">${fusion}${comp}<span id="f-msg" class="discret">${f ? "Rien n'est poussé vers GitHub." : "Fusion locale, rien n'est poussé vers GitHub."}</span></div>`;
}
async function ligneGit(cle) {
  const el = $("#p-git");
  if (!el) return;
  el.innerHTML = "";
  if (!cle.startsWith("project:")) return;
  try {
    const d = await api(`/api/git/${encodeURIComponent(cle)}`);
    if (projetCourant !== cle) return;
    el.innerHTML = `${resumeGit(d)} · <button class="lien" id="p-branches">${d.branches.length} branche${d.branches.length > 1 ? "s" : ""} →</button>`;
    $("#p-branches").onclick = () => choisirBloc("branches");
    if (!gitProjet[cle]) { gitProjet[cle] = true; rendreOngletsBloc(); }
  } catch { gitProjet[cle] = false; if (blocCourant === "branches") choisirBloc("taches"); else rendreOngletsBloc(); }
}
function infoCompilation(p) {
  $("#p-build").innerHTML = p.compilable ? `<div class="actions-branche" style="margin:10px 0 0"><button class="btn" id="compiler-p">Compiler</button><span id="p-build-msg" class="discret"></span></div>` : "";
  if (p.compilable) { $("#compiler-p").onclick = () => compilerProjet(p.cle, "#p-build-msg"); majTravaux(); }
  ligneGit(p.cle);
}
async function compilerProjet(cible, sel) {
  try { await api("/api/compiler", { cible }); $(sel).textContent = "Compilation lancée…"; $(sel).dataset.compile = "1"; majTravaux(); }
  catch (e) { $(sel).textContent = e.message; }
}

/* Travaux d'arrière-plan (compilation, tests, installation) : indicateur dans l'en-tête */
let travauxEtat = {}, travauxVus = {};
const travauxActifs = () => Object.values(travauxEtat || {}).some((j) => j.etat === "en_cours");
async function majTravaux() {
  try { travauxEtat = await api("/api/travaux"); } catch { return; }
  const liste = Object.entries(travauxEtat);
  const enCours = liste.filter(([, j]) => j.etat === "en_cours");
  const b = $("#travaux");
  if (enCours.length) {
    const [, j] = enCours[0];
    b.hidden = false; b.className = "lien";
    b.innerHTML = `⚙ ${esc(j.titre)} ${chrono(j.debut)}${enCours.length > 1 ? ` (+${enCours.length - 1})` : ""}`;
  } else {
    const fini = liste.filter(([k, j]) => j.fin && travauxVus[k] !== j.fin).sort((a, c) => (a[1].fin < c[1].fin ? 1 : -1))[0];
    if (fini) {
      const [k, j] = fini; travauxVus[k] = j.fin;
      b.hidden = false; b.className = "lien " + (j.etat === "ok" ? "ok" : "echec");
      b.textContent = `${j.etat === "ok" ? "✔" : "✖"} ${j.titre} : ${j.etat === "ok" ? "réussi" : "échec"} (voir)`;
    }
  }
  const jp = projetCourant && travauxEtat[`compiler:${projetCourant}`];
  const texte = jp && (jp.etat === "en_cours" ? `compilation en cours… ${chrono(jp.debut)}` : `<span class="${jp.etat === "ok" ? "ok" : "bad"}">${jp.etat === "ok" ? "✔ compilé" : "✖ échec de compilation (Gestion › Outils)"}</span> · ${duree(secondes(jp.debut, jp.fin))}`);
  if (texte) ["#p-build-msg", "#f-msg"].forEach((sel) => { const el = $(sel); if (el && (sel === "#p-build-msg" || el.dataset.compile)) el.innerHTML = texte; });
}
$("#travaux").onclick = () => ouvrirGestion("outils");
$("#etat-memoire").onclick = () => ouvrirGestion("outils");

/* Jauges de limite (en-tête) : un anneau par outil, % de la fenêtre de 5 h (mêmes chiffres que /usage). Bleu, jaune, rouge ;
   il pulse quand la limite sera atteinte avant le seuil au rythme actuel. Un clic ouvre Gestion › Usage. */
async function majAlertes() {
  let l, a = [];
  try { [l, a] = await Promise.all([api("/api/limites"), api("/api/alertes").catch(() => [])]); } catch { return; }
  const h = (t) => new Date(t * 1000).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" });
  const quand = (t) => (t - Date.now() / 1000 > 86400 ? new Date(t * 1000).toLocaleDateString("fr-FR", { weekday: "long" }) + " " : "") + h(t);
  const jauges = ["Claude", "Codex"].filter((o) => l[o] && l[o].ok && (l[o].fenetres || []).length).map((o) => {
    const fs = l[o].fenetres, f = fs.find((x) => x.nom === "5 h") || fs[0], pct = Math.round(f.pct || 0);
    const al = a.find((x) => x.outil === o);
    const teinte = al || pct >= 85 ? "rouge" : pct >= 60 ? "jaune" : "bleu";
    const R = 9, C = 2 * Math.PI * R;
    const titre = fs.map((x) => `${x.nom} : ${Math.round(x.pct)} %${x.reinit ? " · remise à zéro " + quand(x.reinit) : ""}`).join("\n")
      + (al ? `\n${al.minutes === 0 ? "Limite atteinte" : `Au rythme actuel : limite dans ~${minutes(al.minutes * 60)}`}` : "");
    return `<button class="jauge ${teinte}${al ? " en-alerte" : ""}" data-jauge="1" title="${esc(o)}\n${esc(titre)}" aria-label="${esc(o)} : ${pct} % de la limite de 5 h">
      <svg width="22" height="22" viewBox="0 0 22 22" aria-hidden="true"><circle cx="11" cy="11" r="${R}" class="fond"/><circle cx="11" cy="11" r="${R}" class="plein" stroke-dasharray="${(C * Math.min(pct, 100) / 100).toFixed(1)} ${C.toFixed(1)}" transform="rotate(-90 11 11)"/></svg>
      <span>${esc(o)} ${pct} %${al ? ` · ${al.minutes === 0 ? "atteinte" : "~" + minutes(al.minutes * 60)}` : ""}</span></button>`;
  });
  $("#alertes").hidden = !jauges.length;
  $("#alertes").innerHTML = jauges.join("");
}
$("#alertes").onclick = (e) => { if (e.target.closest("[data-jauge]")) ouvrirGestion("usage"); };

/* ================================================================ GESTION */
/* Gestion : un tableau de bord. Chaque réglage interne a son bloc, tout est visible et modifiable sur place. */
const BLOCS_G = { equipe: "agents", outils: "outils", usage: "usage", memoire: "memoire", entretien: "entretien", skills: "docs", documents: "docs", audits: "audits", };
let ongletG = "equipe";
try { ongletG = localStorage.getItem("onglet-gestion") || "equipe"; } catch (e) { /* stockage indisponible */ }
function choisirOngletG(og) {
  if (!$(`#vue-gestion .panneau-g[data-og="${og}"]`)) og = "equipe";      // onglet disparu (ex. « Modèles et benchmarks ») : le premier
  ongletG = og;
  if (vue === "gestion") chargerOngletG(og);
  try { localStorage.setItem("onglet-gestion", og); } catch (e) { /* idem */ }
  $$("#vue-gestion .onglets-g [data-og]").forEach((b) => b.setAttribute("aria-selected", String(b.dataset.og === og)));
  $$("#vue-gestion .panneau-g").forEach((x) => (x.hidden = x.dataset.og !== og));
}
$$("#vue-gestion .onglets-g [data-og]").forEach((b) => (b.onclick = () => choisirOngletG(b.dataset.og)));
choisirOngletG(ongletG);
const GB = (id, html) => { const el = $(`#g-${id}`); if (el) el.innerHTML = html; };
/* Gestion : seul l'onglet affiché se charge (l'autre au premier clic), puis à chaque retour sur la page. */
const BLOCS_ONGLET_G = { equipe: { equipe: gEquipe, bench: gBench, usage: gUsage, reglages: gReglages, outils: gOutils, entretien: gEntretien },
  savoir: { memoire: gMemoire, docs: gDocs, audits: gAudits } };
let ongletsCharges = new Set();
async function chargerOngletG(og) {
  if (ongletsCharges.has(og)) return;
  ongletsCharges.add(og);
  if (og === "equipe") limitesAccueil();
  await Promise.all(Object.entries(BLOCS_ONGLET_G[og] || {}).map(([k, f]) => f().catch((e) => GB(k, `<div class="alerte">${esc(e.message)}</div>`))));
  if (og === "equipe") setTimeout(ajusterUsage, 300);
}
async function afficherGestion() {
  ongletsCharges = new Set();
  await chargerOngletG(ongletG);
}
function ouvrirGestion(section) {
  montrer("gestion");
  const z = $(`#zone-${BLOCS_G[section] || section}`);
  if (z && z.closest(".panneau-g")) choisirOngletG(z.closest(".panneau-g").dataset.og);
  if (z) { z.scrollIntoView({ behavior: matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth", block: "start" }); z.classList.add("repere"); setTimeout(() => z.classList.remove("repere"), 1600); }
}

/* --- Agents : modèle et effort de chaque rôle, d'un coup d'œil */
async function gEquipe() {
  const o = await api("/api/organisation");
  const ACTIF = ["creee", "en_cours", "en_attente_creneau"];
  const opt = (items, sel) => items.map(([v, t]) => `<option value="${esc(v)}"${v === sel ? " selected" : ""}>${esc(t)}</option>`).join("");
  const rang = { travaille: 0, attend_mel: 1, libre: 2 };
  const tuiles = o.equipe.map((r) => {
    const travail = r.taches.some((x) => ACTIF.includes(x.status)), attente = r.taches.length && !travail;
    return { r, etat: travail ? "travaille" : attente ? "attend_mel" : "libre" };
  }).sort((a, b) => rang[a.etat] - rang[b.etat] || a.r.nom.localeCompare(b.r.nom)).map(({ r, etat }) => {   // au travail en premier
    const defaut = r.modele_preset || r.modele_defaut || "";
    const mods = r.outil === "claude-code" ? [["", `Auto · ${defaut ? nomModele(defaut) : "outil"}`], ...MODELES.slice(1)] : [["", "Auto · Codex"]];
    if (r.modele && !mods.some(([v]) => v === r.modele)) mods.push([r.modele, r.modele]);
    const effs = [["", `Auto · ${LIB_EFFORT[r.effort_defaut] || "outil"}`], ...EFFORTS.slice(1)];
    return `<div class="agent-g${r.modele || r.effort ? " regle" : ""}"><div class="tete-g"><span class="point ${etat}" title="${ETATS_ROLE[etat]}"></span>
      <span class="nom"><b title="${esc(r.nom)}">${esc(r.nom)}</b><small>${esc(OUTILS[r.outil] || r.outil)}${r.lecture_seule ? " · lecture seule" : ""}</small></span></div>
      <div class="reglages-g"><select data-modele="${esc(r.id)}" title="Modèle" aria-label="Modèle de ${esc(r.nom)}" ${r.outil === "claude-code" ? "" : "disabled"}>${opt(mods, r.modele || "")}</select>
      <select data-effort="${esc(r.id)}" title="Effort" aria-label="Effort de ${esc(r.nom)}">${opt(effs, r.effort || "")}</select></div></div>`;
  }).join("");
  GB("equipe", `<div class="agents-g">${tuiles}</div><details class="pli" id="pli-matrice"><summary>Agents par projet</summary><div id="g-matrice"><p class="vide">…</p></div></details>`);
  $("#pli-matrice").addEventListener("toggle", () => { if ($("#pli-matrice").open) matriceEquipes(); });
  $("#aide-equipe").innerHTML = "« Auto » suit le mode de chaque projet (Rapide, Normal, Performance : sur la page du projet ou dans « Agents par projet ») ; un choix ici passe avant, une demande passe avant tout.";
  $$("#g-equipe [data-modele]").forEach((x) => (x.onchange = () => api("/api/modeles", { role: x.dataset.modele, modele: x.value }).then(gEquipe).catch((e) => alert(e.message))));
  $$("#g-equipe [data-effort]").forEach((x) => (x.onchange = () => api("/api/efforts", { role: x.dataset.effort, effort: x.value }).then(gEquipe).catch((e) => alert(e.message))));
}

/* --- Outils et mises à jour */
const INSTALLATIONS = {
  lecture: { libelle: "Lecture des PDF et images (~140 Mo)", question: "Installer PyMuPDF et Pillow (~140 Mo) dans l'environnement du studio ?" },
  parole: { libelle: "Lecture des sons et vidéos (~550 Mo + modèle ~480 Mo)", question: "Installer faster-whisper et PyAV (~550 Mo) ? Le modèle de parole (~480 Mo) se téléchargera à la première pièce sonore." },
  retro: { libelle: "Outils de rétro-ingénierie (~25 Mo)", question: "Installer pefile, capstone, lief et kaitaistruct (~25 Mo) dans l'environnement du studio ? Ils servent au Rétro-ingénieur (lecture de binaires et de formats)." },
};
async function gOutils() {
  const e = await api("/api/etat");
  const pt = (v) => v.etat === "OK" ? "libre" : v.etat === "MANUEL" || v.etat === "PARTIEL" ? "attend_mel" : "en_pause";
  GB("outils", `<p class="sous-titre-g">Studio</p><div class="reglage"><span id="o-studio">Version…</span><button class="btn discret" id="o-maj">Rechercher une mise à jour</button></div>
    <p class="sous-titre-g">Versions</p><div id="o-versions"><p class="vide">Vérification des versions…</p></div>
    <p class="sous-titre-g">Connexions</p>
    <div class="etats-g">${Object.entries(e).map(([k, v]) => `<span class="etat-g" title="${esc(v.etat)} — ${esc(v.detail)}"><span class="point ${pt(v)}"></span>${esc(k)}</span>`).join("")}</div>
    <p class="discret aide-g" style="margin-top:8px">Survole une pastille pour le détail.</p>`);
  versionsOutils();
  const studioVersion = (m) => { const x = $("#o-studio"); if (x && m) x.textContent = `Version ${m.actuelle}` + (m.disponible ? ` · ${m.disponible.version} disponible` : m.installee ? ` · ${m.installee} installée (redémarrer)` : m.depot ? " · à jour" : "") + (m.erreur ? ` · ${m.erreur}` : ""); };
  majVersion().then(studioVersion);
  $("#o-maj").onclick = async () => { $("#o-maj").disabled = true; try { await api("/api/mise-a-jour/verifier", {}); majMasquee = ""; studioVersion(await majVersion()); } catch (x) { alert(x.message); } $("#o-maj").disabled = false; };
}

async function matriceEquipes() {
  const el = $("#g-matrice");
  if (!el) return;
  const m = await api("/api/equipes").catch(() => null);
  if (!m) { el.innerHTML = '<p class="warn">Indisponible.</p>'; return; }
  const cellule = (p, r) => { const x = p.roles[r.id];
    if (!x) return '<td class="discret">·</td>';
    const k = x.etat === "travaille" ? "travaille" : !x.actif ? "off" : x.personnalise ? "perso" : "on";
    const t = { travaille: "▶", off: "—", perso: "◆", on: "●" }[k];
    return `<td class="c ${k}" data-mat-p="${esc(p.cle)}" title="${esc(p.nom)} · ${esc(r.nom)}${x.etat ? " · " + (ETATS_ROLE[x.etat] || x.etat) : ""}${x.personnalise ? " · réglé pour ce projet" : ""}${x.propre ? " · propre au projet" : ""}">${t}</td>`; };
  el.innerHTML = `<p class="aide-g discret">● actif · ◆ réglé pour ce projet · ▶ au travail · — pas utilisé. Clique une case pour régler l'équipe du projet, ou un mode pour le changer.</p>
    <div class="matrice-defile"><table class="matrice"><thead><tr><th>Métier</th>${m.projets.map((p) => `<th>${esc(p.nom.slice(0, 18))}</th>`).join("")}</tr></thead>
    <tbody><tr class="ligne-mode"><td>Mode</td>${m.projets.map((p) => `<td class="c" data-mode-p="${esc(p.cle)}" title="Se règle dans Projets › ${esc(p.nom)} › Réglages"><span class="mode-p ${esc(p.profil)}">${esc((PROFILS.find(([v]) => v === p.profil) || ["", "Normal"])[1])}</span></td>`).join("")}</tr>
    ${m.roles.map((r) => `<tr><td>${esc(r.nom)}</td>${m.projets.map((p) => cellule(p, r)).join("")}</tr>`).join("")}</tbody></table></div>`;
  $$("#g-matrice [data-mode-p]").forEach((c) => (c.onclick = () => { projetCourant = c.dataset.modeP; blocCourant = "projet"; montrer("projets"); setTimeout(() => choisirBloc("projet"), 500); }));
  $$("#g-matrice [data-mat-p]").forEach((c) => (c.onclick = () => { projetCourant = c.dataset.matP; blocCourant = "equipe"; montrer("projets"); setTimeout(() => choisirBloc("equipe"), 500); }));
}

/* --- Entretien (colonne Réglages) : tests du studio, fonctions en option, travaux en arrière-plan */
async function gEntretien() {
  const [inst, tr] = await Promise.all([api("/api/outils/installes"), api("/api/travaux")]);
  const reste = Object.keys(INSTALLATIONS).filter((q) => !inst[q]);       // une installation faite ne se propose plus
  const enCours = (q) => (tr[`installer:${q}`] || {}).etat === "en_cours";
  const travaux = Object.values(tr).sort((a, b) => (a.debut < b.debut ? 1 : -1));
  GB("entretien", `<div class="actions colonne" style="margin:0"><button class="btn" id="o-tests">Lancer les tests du studio</button></div>
    ${reste.length ? `<p class="sous-titre-g">Fonctions en option</p><div class="actions colonne" style="margin:0">${reste.map((q) => enCours(q) ? `<button class="btn" disabled>Installation en cours…</button>` : `<button class="btn" data-installer="${q}">Installer : ${INSTALLATIONS[q].libelle}</button>`).join("")}</div>` : ""}
    ${travaux.length ? `<details class="pli" style="margin-top:10px"${travaux.some((j) => j.etat === "en_cours") ? " open" : ""}><summary>Travaux depuis l'ouverture (${travaux.length})</summary>${travaux.map((j) => `<details class="pli"><summary>${j.etat === "en_cours" ? "⚙" : j.etat === "ok" ? "✔" : "✖"} ${esc(j.titre)} · ${j.fin ? duree(secondes(j.debut, j.fin)) : chrono(j.debut)}</summary><pre class="sortie">${esc(j.sortie || "…")}</pre></details>`).join("")}</details>` : ""}`);
  const lancer = async (url, corps) => { try { await api(url, corps); majTravaux(); setTimeout(gEntretien, 800); } catch (x) { alert(x.message); } };
  $("#o-tests").onclick = () => lancer("/api/outils/tests", {});
  $$("#g-entretien [data-installer]").forEach((b) => (b.onclick = () => confirm(INSTALLATIONS[b.dataset.installer].question) && lancer("/api/outils/installer", { quoi: b.dataset.installer })));
  if (travaux.some((j) => j.etat === "en_cours")) setTimeout(() => { if (vue === "gestion") gEntretien(); }, 4000);
}

/* --- Audits des skills et des mémoires des agents (skills globaux audit-skills / audit-memories, exécutés par Codex) */
async function gAudits() {
  const aud = await api("/api/audits").catch(() => []);
  GB("audits", blocAudits(aud));
  const selA = $("#a-cible");
  if (selA) {
    try { const m = localStorage.getItem("audit-cible"); if (m && aud.some((p) => p.cible === m)) selA.value = m; } catch (e) { /* stockage indisponible */ }
    const majA = () => { const p = aud.find((x) => x.cible === selA.value) || {}; $$("#g-audits [data-audit]").forEach((b) => { const d = p[`${b.dataset.audit}_audit`]; b.nextElementSibling.textContent = d ? `dernier : ${ilYa(d.date)}${ACTIVES.includes(d.statut) ? " (en cours)" : ""}` : "jamais lancé"; }); };
    selA.onchange = () => { try { localStorage.setItem("audit-cible", selA.value); } catch (e) { /* idem */ } majA(); };
    majA();
    $$("#g-audits [data-audit]").forEach((b) => (b.onclick = () => lancerAudit({ cible: selA.value, quoi: b.dataset.audit, mode: "audit" })));
  }
}

function blocAudits(aud) {
  if (!aud.length) return '<p class="vide">Aucun projet avec un dossier.</p>';
  return `<p class="explique-g">Relit les skills ou les fichiers d'instructions des agents (CLAUDE.md, règles, plans) et dit ce qui est faux, en double ou chargé pour rien. Rapport d'abord ; « Appliquer » ensuite, depuis le rapport.</p>
    <select id="a-cible" class="champ" style="width:100%;margin-bottom:6px">${aud.map((p) => `<option value="${esc(p.cible)}">${esc(p.nom)}</option>`).join("")}</select>
    <div class="audits-g">
      <button class="btn" data-audit="skills" title="Quels skills servent, lesquels se chevauchent ou chargent du texte pour rien">Auditer les skills</button><small class="discret"></small>
      <button class="btn" data-audit="memoires" title="CLAUDE.md, règles, plans : ce qui est faux, en double ou périmé">Auditer les mémoires</button><small class="discret"></small>
    </div>`;
}
function ilYa(d) {
  const j = Math.floor((Date.now() - new Date(d.replace(" ", "T") + (/[zZ+]/.test(d.slice(10)) ? "" : "Z")).getTime()) / 864e5);
  return j <= 0 ? "aujourd'hui" : j === 1 ? "hier" : `il y a ${j} jours`;
}
async function lancerAudit(corps) {
  try { const r = await api("/api/audits", corps); selection = r.tid; derniereVue = ""; projetCourant = corps.cible; montrer("projets"); }
  catch (e) { alert(e.message); }
}

/* --- Réglages du studio : liste fermée, enregistrés dans studio.config.toml (copie de l'ancien gardée) */
let msgReglage = { t: "↻ = pris en compte au prochain démarrage du studio.", c: "discret" };
/* --- Mises à jour : bandeau quand une version est installée (redémarrer) ou disponible (installer) */
let majMasquee = "";
async function majVersion() {
  let e;
  try { e = await api("/api/mise-a-jour"); } catch { return; }
  const b = $("#bandeau-maj");
  const cle = e.installee || (e.disponible && e.disponible.version) || "";
  if (!cle || cle === majMasquee || sessionInfo.distant) { b.hidden = true; return e; }
  if (e.installee) {
    $("#maj-texte").textContent = `Mise à jour ${e.installee} installée.`;
    $("#maj-action").textContent = "Redémarrer le studio";
    $("#maj-action").onclick = async () => {
      try { await api("/api/mise-a-jour/redemarrer", {}); document.body.innerHTML = '<div class="ferme"><h1>Mise à jour</h1><p class="vide">Le studio redémarre…</p></div>'; }
      catch (x) { alert(x.message); }
    };
  } else {
    $("#maj-texte").textContent = `Nouvelle version ${e.disponible.version} disponible${e.disponible.notes ? " : " + e.disponible.notes.split("\n")[0].slice(0, 120) : ""}`;
    $("#maj-action").textContent = "Installer";
    $("#maj-action").onclick = async () => {
      $("#maj-action").disabled = true; $("#maj-action").textContent = "Installation…";
      try { await api("/api/mise-a-jour/installer", {}); } catch (x) { alert(x.message); }
      $("#maj-action").disabled = false; majVersion();
    };
  }
  $("#maj-fermer").onclick = () => { majMasquee = cle; b.hidden = true; };
  b.hidden = false;
  return e;
}
setTimeout(majVersion, 4000);
setInterval(majVersion, 30 * 60 * 1000);

/* --- Connecteurs : logiciels du PC ajoutés par l'utilisateur (vides à la base) */
/* --- Créer un agent : domaine → rôle proposé → réglages et modèle recommandé → création */
let catalogueAgents = null;
const NOMS_CAT = { texte: "texte", code: "code", image: "images", video: "vidéo", voix: "voix" };
function fermerAssistantAgent() { $("#assistant-agent").hidden = true; }
$("#aa-fermer").onclick = () => { agentProjet = ""; fermerAssistantAgent(); };
$("#assistant-agent").onclick = (e) => { if (e.target.id === "assistant-agent") fermerAssistantAgent(); };
document.addEventListener("keydown", (e) => { if (e.key === "Escape" && !$("#assistant-agent").hidden) fermerAssistantAgent(); });
$("#creer-agent").onclick = async () => {
  $("#assistant-agent").hidden = false;
  $("#aa-corps").innerHTML = '<p class="vide">…</p>';
  try { catalogueAgents = await api("/api/agents/catalogue"); etapeDomaine(); }
  catch (e) { $("#aa-corps").innerHTML = `<p class="warn">${esc(e.message)}</p>`; }
};
function etapeDomaine() {
  $("#aa-titre").textContent = "Créer un agent · 1/3 · ton domaine";
  $("#aa-corps").innerHTML = `<div class="grille-domaines">${catalogueAgents.domaines.map((d) => `<button data-dom="${esc(d.id)}"><b>${esc(d.nom)}</b><br><small class="discret">${d.roles.length} rôles proposés</small></button>`).join("")}<button data-dom=""><b>Autre</b><br><small class="discret">partir de zéro</small></button></div>`;
  $$("[data-dom]").forEach((b) => (b.onclick = () => (b.dataset.dom ? etapeRole(b.dataset.dom) : etapeReglages(null, ""))));
}
function etapeRole(dom) {
  const d = catalogueAgents.domaines.find((x) => x.id === dom);
  $("#aa-titre").textContent = `Créer un agent · 2/3 · ${d.nom}`;
  $("#aa-corps").innerHTML = `<div class="grille-domaines">${d.roles.map((r, i) => `<div class="carte-role" role="button" tabindex="0" data-role="${i}"><b>${esc(r.nom)}</b><small>${esc(r.mission)}</small><br><small class="discret">type : ${NOMS_CAT[r.categorie] || r.categorie}</small></div>`).join("")}
    <div class="carte-role" role="button" tabindex="0" data-role="-1"><b>Partir de zéro</b><small>Un rôle à toi, dans ce domaine.</small></div></div>
    <div class="actions" style="margin-top:12px"><button class="btn discret" id="aa-retour">Retour</button></div>`;
  $("#aa-retour").onclick = etapeDomaine;
  $$("[data-role]").forEach((c) => (c.onclick = c.onkeydown = (e) => { if (e.type === "keydown" && e.key !== "Enter") return; etapeReglages(+c.dataset.role >= 0 ? d.roles[+c.dataset.role] : null, dom); }));
}
function etapeReglages(r, dom) {
  const cat = (r && r.categorie) || "texte";
  $("#aa-titre").textContent = "Créer un agent · 3/3 · réglages";
  const lignes = (l) => esc((l || []).join("\n"));
  const sources = catalogueAgents.sources;
  const reco = () => catalogueAgents.recommandations[$("#aa-cat").value] || {};
  $("#aa-corps").innerHTML = `<div class="form-agent">
    <label for="aa-nom">Nom</label><input class="champ" id="aa-nom" maxlength="60" value="${esc(r ? r.nom : "")}">
    <label for="aa-mission">Mission (ce qu'il fait)</label><textarea id="aa-mission">${esc(r ? r.mission : "")}</textarea>
    <label for="aa-livrables">Ce qu'il livre (une ligne par livrable)</label><textarea id="aa-livrables">${lignes(r && r.livrables)}</textarea>
    <label for="aa-limites">Ce qu'il ne doit jamais faire (une ligne par règle)</label><textarea id="aa-limites">${lignes(r && r.limites)}</textarea>
    <label for="aa-cat">Type de travail</label><select id="aa-cat">${Object.entries(NOMS_CAT).map(([k, t]) => `<option value="${k}"${k === cat ? " selected" : ""}>${t}</option>`).join("")}</select>
    <div class="reco" id="aa-reco"></div>
    <label for="aa-source">IA de cet agent</label><select id="aa-source">${sources.length ? sources.map((x) => `<option value="${esc(x.id)}">${esc(x.nom)}${x.modele ? " · " + esc(x.modele) : ""}</option>`).join("") : '<option value="">Aucune IA connectée</option>'}</select>
    <p class="warn aide-g" id="aa-msg"></p>
    <div class="actions" style="margin-top:12px;justify-content:space-between"><button class="btn discret" id="aa-retour">Retour</button><button class="btn principal" id="aa-creer">Créer l'agent</button></div></div>`;
  const majReco = () => {
    const x = reco();
    const m = (o) => o ? `${esc(o.nom)} (${esc(o.fournisseur)}${o.score ? ", " + o.score + " " + esc(o.unite) : ""}${o.prix ? ", " + o.prix + " $" : ""})` : "—";
    $("#aa-reco").innerHTML = `${x.connecte ? `<div><b>Recommandé avec tes IA :</b> ${esc(x.connecte.nom)}${x.connecte.modele_conseille ? " → " + m(x.connecte.modele_conseille) : ""}</div>` : "<div><b>Aucune de tes IA ne convient encore.</b></div>"}
      <div><b>Meilleur du marché :</b> ${m(x.marche)}</div>${x.remarque ? `<div class="discret" style="margin-top:4px">${esc(x.remarque)}</div>` : ""}`;
    if (x.connecte && $("#aa-source").querySelector(`option[value="${x.connecte.id}"]`)) $("#aa-source").value = x.connecte.id;
  };
  $("#aa-cat").onchange = majReco; majReco();
  $("#aa-retour").onclick = () => (dom ? etapeRole(dom) : etapeDomaine());
  $("#aa-creer").onclick = async () => {
    const liste = (id) => $(id).value.split("\n").map((x) => x.trim()).filter(Boolean);
    try {
      const res = await api("/api/agents/creer", { nom: $("#aa-nom").value, mission: $("#aa-mission").value, livrables: liste("#aa-livrables"),
        limites: liste("#aa-limites"), categorie: $("#aa-cat").value, source: $("#aa-source").value, domaine: dom,
        mots_cles: r ? r.mots_cles : [], outils: r ? r.outils : undefined, criteres: r ? r.criteres : [], id: r ? r.id : "", projet: agentProjet });
      if (agentProjet) { agentProjet = ""; setTimeout(equipeReglages, 300); }
      $("#aa-titre").textContent = "Agent créé";
      $("#aa-corps").innerHTML = `<p class="ok">« ${esc($("#aa-nom") ? $("#aa-nom").value : "")} » rejoint l'équipe. Le Superviseur peut maintenant lui confier des tâches.</p><div class="actions"><button class="btn principal" id="aa-ok">OK</button></div>`;
      $("#aa-ok").onclick = fermerAssistantAgent;
      gEquipe();
    } catch (e) { $("#aa-msg").textContent = e.message; }
  };
}

/* --- Benchmarks : classement global puis classements par usage (cloud et local mêlés), mis à jour chaque jour */
let benchTri = { cat: "global", col: "score", lieu: "tous" };
let minuteurBench = null, benchCache = null;
/* Modèles et benchmarks : cloud et local dans le même tableau, plus « Installés ». Données chargées une fois, les
   onglets s'affichent tout de suite (rechargement seulement pendant un téléchargement ou après une action). */
async function gBench(recharger = true) {
  clearTimeout(minuteurBench);
  if (recharger || !benchCache) {
    const [b, loc, inst, ia] = await Promise.all([api("/api/benchmarks"), api("/api/modeles-locaux").catch(() => null), api("/api/modeles-locaux/details").catch(() => []),
      api("/api/ia").catch(() => ({ connexions: [] }))]);
    benchCache = { b, loc, inst, ia };
  }
  dessinerBench();
}
function dessinerBench() {
  const { b, loc, inst, ia } = benchCache;
  const cats = Object.entries(b.categories).filter(([k]) => k !== "local");
  const co = new Set(b.connectes);
  const estCo = (m) => m.local ? co.has("local") : co.has(m.fournisseur) || (m.fournisseur === "openai" && co.has("codex"))
    || (co.has("openrouter") && !DIRECTS_CLOUD.includes(m.fournisseur) && TEXTE_CLOUD.includes(m.categorie));
  const installes = benchTri.cat === "installes";
  if (!installes && !cats.some(([k]) => k === benchTri.cat)) benchTri.cat = cats[0][0];
  const inverse = (b.inverses || []).includes(benchTri.cat);              // transcription : taux d'erreur, plus bas = mieux
  const parScore = (x, y) => x.score == null ? 1 : y.score == null ? -1 : inverse ? x.score - y.score : y.score - x.score;
  const tri = (l) => [...l].sort((x, y) => benchTri.col === "prix" ? (x.local ? 0 : x.prix ?? 1e9) - (y.local ? 0 : y.prix ?? 1e9) || parScore(x, y)
    : benchTri.col === "vitesse" ? (y.vitesse || 0) - (x.vitesse || 0) || parScore(x, y) : parScore(x, y));
  const tous = b.modeles.filter((m) => m.categorie === benchTri.cat);
  const lignes = tri(tous.filter((m) => benchTri.lieu === "tous" || (benchTri.lieu === "local") === !!m.local));
  const rang = new Map([...tous].sort(parScore).map((m, i) => [m, m.score == null ? "" : i + 1]));   // rang au classement, cloud et local ensemble
  const aLocaux = tous.some((m) => m.local);
  let masque = ""; try { masque = localStorage.getItem("ollama-plus-tard") || ""; } catch {}
  let note = "";
  if (loc && (aLocaux || installes)) {
    if (!loc.installe) note = `<div class="note-ollama">Modèles locaux : installe <a href="${esc(loc.telecharger)}" target="_blank" rel="noopener">Ollama</a> (gratuit) pour les installer en un clic ici.</div>`;
    else if (!co.has("local") && !masque) note = `<div class="note-ollama">Connecter Ollama pour que le Superviseur ou les agents utilisent tes modèles locaux ? <button class="btn petit principal" id="ollama-connecter">Connecter</button><button class="lien" id="ollama-plus-tard">Plus tard</button></div>`;
  }
  const acces = (m) => m.local ? (loc ? celluleLocale(m, loc) : "—") : estCo(m) ? `<span class="ok">● connecté${co.has(m.fournisseur) || m.fournisseur === "openai" ? "" : " (OpenRouter)"}</span>`
    : connectable(m) ? `<button class="btn petit" data-connecter-cloud="${esc(m.fournisseur)}" data-nom-modele="${esc(m.nom)}">Connecter</button>` : '<small class="discret">sur son site</small>';
  const ligne = (m) => `<tr class="${estCo(m) ? "connecte" : ""}"><td class="rang">${rang.get(m) || "—"}</td><td>${esc(m.nom)}<span class="badge-lc ${m.local ? "local" : "cloud"}">${m.local ? "LOCAL" : "CLOUD"}</span></td>
    <td><b>${m.score ?? "—"}</b></td><td class="nowrap">${acces(m)}</td><td>${m.local ? '<span class="ok">Gratuit</span>' : m.prix != null ? m.prix + " $" : "—"}</td>
    <td>${m.vitesse ? m.vitesse + " t/s" : m.local ? '<small class="discret">selon le PC</small>' : "—"}</td><td>${esc(m.fournisseur)}</td><td><small class="discret">${esc(m.note || "")}</small></td></tr>`;
  const unite = ((tous[0] || {}).unite || "score").replace(/^./, (c) => c.toUpperCase());
  let corps;
  if (installes) {
    // Connectés et installés : les vrais modèles utilisables, cloud (abonnement ou clé) et locaux (Ollama)
    const NOMS_F = { anthropic: "Anthropic", openai: "OpenAI", gemini: "Google Gemini", mistral: "Mistral", deepseek: "DeepSeek", openrouter: "OpenRouter", groq: "Groq" };
    const viaCle = (f) => (ia.connexions || []).find((c) => c.fournisseur === f);
    const accesCloud = (m) => m.fournisseur === "anthropic" && co.has("anthropic") && !viaCle("anthropic") ? "Abonnement Claude (Claude Code)"
      : m.fournisseur === "openai" && co.has("codex") && !viaCle("openai") ? "Abonnement ChatGPT (Codex)"
      : viaCle(m.fournisseur) ? `Clé API ${NOMS_F[m.fournisseur] || m.fournisseur}` : viaCle("openrouter") ? "Clé API OpenRouter" : "Abonnement";
    const vus = new Set();
    const cloud = b.modeles.filter((m) => m.categorie === "global" && !m.local && estCo(m) && !vus.has(m.nom) && vus.add(m.nom)).sort(parScore);
    const cles = (ia.connexions || []).filter((c) => !["ollama", "lmstudio"].includes(c.fournisseur));
    const scoreLocal = (nom) => (b.modeles.find((m) => m.local && m.categorie === "global" && (nom === (m.ollama || m.cle) || nom.startsWith((m.ollama || m.cle) + ":"))) || {}).score;
    corps = `${note}<p class="sous-titre-g">Modèles cloud connectés (${cloud.length})</p>${cloud.length ? `<div class="bench-defile"><table class="table-bench"><thead><tr><th>Modèle</th><th>Indice global</th><th>Accès</th><th>Vitesse</th><th>Prix</th></tr></thead><tbody>${cloud.map((m) =>
        `<tr><td>${esc(m.nom)}<span class="badge-lc cloud">CLOUD</span></td><td><b>${m.score ?? "—"}</b></td><td>${esc(accesCloud(m))}</td><td>${m.vitesse ? m.vitesse + " t/s" : "—"}</td><td>${m.prix != null ? m.prix + " $" : "—"}</td></tr>`).join("")}</tbody></table></div>`
        : '<p class="discret">Aucun : clique « Connecter » sur un modèle du classement.</p>'}
      ${cles.length ? `<p class="aide-g discret">Clés API enregistrées : ${cles.map((c) => `${esc(NOMS_F[c.fournisseur] || c.fournisseur)}${c.modele ? ` (${esc(c.modele)})` : ""} <button class="lien" data-deco-ia="${esc(c.id)}">déconnecter</button>`).join(" · ")}. Abonnements : ils se gèrent dans Claude Code ou Codex.</p>` : ""}
      <p class="sous-titre-g" style="margin-top:14px">Modèles locaux installés (${inst.length})</p>${inst.length ? `<div class="bench-defile"><table class="table-bench"><thead><tr><th>Modèle</th><th>Indice global</th><th>Taille</th><th>Installé le</th><th></th></tr></thead><tbody>${inst.map((m) =>
        `<tr><td>${esc(m.nom)}<span class="badge-lc local">LOCAL</span></td><td><b>${scoreLocal(m.nom) ?? "—"}</b></td><td>${m.taille_go} Go</td><td>${esc(m.modifie)}</td><td class="nowrap"><button class="btn discret petit" data-maj-local="${esc(m.nom)}">Mettre à jour</button><button class="btn discret petit danger" data-desinstaller-local="${esc(m.nom)}">Désinstaller</button></td></tr>`).join("")}</tbody></table></div>
      <div class="reglage"><small class="discret">Ollama ne télécharge que ce qui a changé. « — » : modèle absent des classements publics.</small><button class="btn discret" id="maj-locaux">Tout mettre à jour</button></div>` : '<p class="discret">Aucun pour l\'instant : choisis-en un dans le classement (lignes LOCAL, bouton Installer).</p>'}`;
  } else {
    const aide = (b.aides || {})[benchTri.cat] || "";
    corps = `${aide ? `<p class="aide-bench discret">${esc(aide)}${aLocaux ? "" : " Aucun modèle local mesuré par cette source."}</p>` : ""}${note}<div class="bench-defile"><table class="table-bench"><thead><tr><th>#</th><th>Modèle</th><th data-bcol="score" title="${esc((tous[0] || {}).unite || "")}">${esc(unite)} ${inverse ? "▴" : "▾"}</th><th>Accès</th><th data-bcol="prix">Prix</th><th data-bcol="vitesse">Vitesse</th><th>Fournisseur</th><th>Remarque</th></tr></thead><tbody>
      ${lignes.length ? lignes.map(ligne).join("") : '<tr><td colspan="8" class="discret">Aucun modèle ici.</td></tr>'}</tbody></table></div>`;
  }
  GB("bench", `<div class="bench-modes"><div class="puces petites" id="bench-cats">${cats.map(([k, t]) => `<button class="puce${k === benchTri.cat ? " sel" : ""}" data-bcat="${k}">${esc(t)}</button>`).join("")}<button class="puce${installes ? " sel" : ""}" data-bcat="installes">Connectés et installés</button></div>
      ${installes ? "" : `<div class="seg" id="bench-lieu">${[["tous", "Tous"], ["cloud", "Cloud"], ["local", "Local"]].map(([k, t]) => `<button data-blieu="${k}" class="${benchTri.lieu === k ? "sel" : ""}">${t}</button>`).join("")}</div>`}</div>
    ${corps}
    <p class="aide-g discret" style="margin-top:6px">● = utilisable avec tes IA. Prix cloud : $ par million de jetons d'entrée (images : par image). ${esc(b.note)}<br>Classements du ${esc(b.date)}${b.actualise ? ` · vérifiés le ${esc(b.actualise.slice(0, 10))}` : ""} (mise à jour automatique une fois par jour) · ${b.sources.map((x) => `<a href="${esc(x.url)}" target="_blank" rel="noopener">${esc(x.nom)}</a>`).join(" · ")}</p>`);
  $$("[data-blieu]").forEach((x) => (x.onclick = () => { benchTri.lieu = x.dataset.blieu; dessinerBench(); }));
  $$("[data-bcat]").forEach((x) => (x.onclick = async () => {
    benchTri.cat = x.dataset.bcat; dessinerBench();
    if (x.dataset.bcat === "installes" && loc && loc.installe && !loc.ollama && !sessionInfo.distant) {   // la liste vient d'Ollama : il s'ouvre pour la donner
      try { await api("/api/modeles-locaux/demarrer", {}); } catch (e) { /* liste vide, rien de grave */ }
      gBench();
    }
  }));
  $$("[data-bcol]").forEach((x) => (x.onclick = () => { benchTri.col = x.dataset.bcol; dessinerBench(); }));
  $$("[data-connecter-cloud]").forEach((x) => (x.onclick = () => connecterCloud(x.dataset.connecterCloud, x.dataset.nomModele)));
  $$("[data-installer-modele]").forEach((x) => (x.onclick = async () => {
    const nom = x.dataset.installerModele, m = b.modeles.find((y) => (y.ollama || y.cle) === nom);
    if (!confirm(`Installer ${m ? m.nom : nom} sur ce PC avec Ollama ?\n${m && m.note ? m.note + "\n" : ""}Le téléchargement peut prendre du temps (plusieurs Go).`)) return;
    x.disabled = true;
    try { await api("/api/modeles-locaux/installer", { nom }); } catch (e) { alert(e.message); }
    gBench();
  }));
  $$("#g-bench [data-maj-local]").forEach((x) => (x.onclick = async () => { x.disabled = true; try { await api("/api/modeles-locaux/installer", { nom: x.dataset.majLocal }); bulleInfo("Mise à jour lancée."); } catch (e) { alert(e.message); } }));
  $$("#g-bench [data-desinstaller-local]").forEach((x) => (x.onclick = async () => {
    const nom = x.dataset.desinstallerLocal;
    if (!confirm(`Désinstaller ${nom} ? Le modèle est retiré d'Ollama et libère sa place sur le disque (il se réinstalle en un clic).`)) return;
    x.disabled = true;
    try { bulleInfo((await api("/api/modeles-locaux/desinstaller", { nom })).message); } catch (e) { alert(e.message); }
    gBench();
  }));
  $$("#g-bench [data-deco-ia]").forEach((x) => (x.onclick = async () => {
    if (!confirm("Déconnecter cette clé API ? Elle est effacée de ce PC (tu pourras la recoller).")) return;
    try { await api("/api/ia/retirer", { id: x.dataset.decoIa }); } catch (e) { alert(e.message); }
    gBench();
  }));
  if ($("#maj-locaux")) $("#maj-locaux").onclick = async (ev) => { ev.currentTarget.disabled = true;
    for (const m of inst) { try { await api("/api/modeles-locaux/installer", { nom: m.nom }); } catch (e) { alert(`${m.nom} : ${e.message}`); } }
    bulleInfo("Mise à jour lancée."); };
  if ($("#ollama-connecter")) $("#ollama-connecter").onclick = async (ev) => { ev.currentTarget.disabled = true; try { await api("/api/ia/ajouter", { fournisseur: "ollama" }); bulleInfo("Ollama connecté."); } catch (e) { alert(e.message); } gBench(); };
  if ($("#ollama-plus-tard")) $("#ollama-plus-tard").onclick = () => { try { localStorage.setItem("ollama-plus-tard", "1"); } catch {} dessinerBench(); };
  if (loc && Object.values(loc.modeles).some((x) => x.progression && x.progression.etat === "telechargement"))
    minuteurBench = setTimeout(() => { if (vue === "gestion") gBench().catch(() => {}); }, 2000);
}
/* Connexion d'un modèle cloud depuis les benchmarks : aussi simple qu'installer un modèle local. Abonnement (Claude Code,
   Codex) quand il existe, sinon clé API du fournisseur ; les autres modèles passent par OpenRouter (une clé, tous les modèles). */
const DIRECTS_CLOUD = ["anthropic", "openai", "gemini", "mistral", "deepseek", "xai", "moonshot"];
const TEXTE_CLOUD = ["global", "agents", "code", "web", "raisonnement", "connaissances", "conversation", "vision"];
const CLES_CLOUD = {
  anthropic: ["Anthropic (Claude)", "https://console.anthropic.com/settings/keys"], openai: ["OpenAI", "https://platform.openai.com/api-keys"],
  gemini: ["Google Gemini", "https://aistudio.google.com/apikey"], mistral: ["Mistral", "https://console.mistral.ai/api-keys"],
  deepseek: ["DeepSeek", "https://platform.deepseek.com/api_keys"], openrouter: ["OpenRouter", "https://openrouter.ai/keys"],
  xai: ["xAI (Grok)", "https://console.x.ai"], moonshot: ["Moonshot (Kimi)", "https://platform.moonshot.ai/console/api-keys"],
};
const connectable = (m) => TEXTE_CLOUD.includes(m.categorie) || (m.categorie === "image" && ["openai", "gemini"].includes(m.fournisseur));
async function connecterCloud(fournisseur, nomModele) {
  const f = DIRECTS_CLOUD.includes(fournisseur) ? fournisseur : "openrouter";
  const [nom, lienCle] = CLES_CLOUD[f];
  const el = $("#perso-fiche-corps");
  el.innerHTML = '<p class="vide">…</p>'; $("#perso-fiche").hidden = false;
  let d = {};
  try { d = await api("/api/ia"); } catch (e) { /* sans détail : clé seulement */ }
  if (d.distant) { el.innerHTML = `<h2>Connecter ${esc(nom)}</h2><p class="aide-g">La connexion se fait sur le PC (la clé ne passe jamais par le téléphone).</p><div class="bas"><button class="btn discret" data-fermer-fiche="1">Fermer</button></div>`; return; }
  const abo = f === "anthropic" ? (d.claude ? `<button class="btn principal" id="cc-abo">Se connecter avec mon abonnement Claude</button>`
      : `<p class="aide-g">Abonnement Claude (Pro ou Max) : installe d'abord Claude Code. Dans PowerShell :<br><code>irm https://claude.ai/install.ps1 | iex</code><br>puis reviens ici.</p>`)
    : f === "openai" ? (d.codex ? `<button class="btn principal" id="cc-abo">Se connecter avec mon abonnement ChatGPT</button>`
      : `<p class="aide-g">Abonnement ChatGPT : installe d'abord Codex (Node.js requis). Dans PowerShell :<br><code>npm install -g @openai/codex</code><br>puis reviens ici.</p>`) : "";
  el.innerHTML = `<h2>Connecter ${esc(nom)}</h2><div class="meta">pour utiliser ${esc(nomModele)}${f === "openrouter" ? " et des centaines d'autres modèles avec une seule clé" : ""}</div>
    ${abo ? `<p class="sous-titre-g">Avec ton abonnement</p>${abo}<p class="sous-titre-g" style="margin-top:16px">Ou avec une clé API (paiement à l'usage)</p>` : `<p class="sous-titre-g">Clé API</p>`}
    <p class="aide-g">1. <a href="${esc(lienCle)}" target="_blank" rel="noopener">Crée une clé sur le site de ${esc(nom)}</a> · 2. colle-la ici. Elle est vérifiée puis chiffrée par Windows, jamais affichée.</p>
    <label for="cc-cle">Clé API</label><input id="cc-cle" type="password" autocomplete="off" spellcheck="false">
    <p class="warn" id="fiche-msg"></p><div class="bas"><button class="btn discret" data-fermer-fiche="1">Annuler</button><button class="btn" id="cc-ok">Connecter avec la clé</button></div>`;
  if ($("#cc-abo")) $("#cc-abo").onclick = async (ev) => {
    ev.currentTarget.disabled = true;
    try { const r = await api(f === "anthropic" ? "/api/claude/connexion" : "/api/codex/connexion", {}); bulleInfo(r.info); $("#perso-fiche").hidden = true; }
    catch (e) { $("#fiche-msg").textContent = e.message; ev.currentTarget.disabled = false; }
  };
  $("#cc-ok").onclick = async (ev) => {
    const b = ev.currentTarget; b.disabled = true; b.textContent = "Vérification…";
    try { await api("/api/ia/ajouter", { fournisseur: f, cle: $("#cc-cle").value }); bulleInfo(`${nom} connecté.`); $("#perso-fiche").hidden = true; gBench(); }
    catch (e) { $("#fiche-msg").textContent = e.message; b.disabled = false; b.textContent = "Connecter avec la clé"; }
  };
  $("#cc-cle").onkeydown = (e) => { if (e.key === "Enter") $("#cc-ok").click(); };
}
function celluleLocale(m, loc) {
  const nom = m.ollama || m.cle, e = loc.modeles[nom];
  if (!e) return "—";
  const p = e.progression;
  if (p && p.etat === "telechargement") return `<span class="info" title="${esc(p.message)}">${p.pct} %</span>`;
  if (e.installe) return '<span class="ok">Installé</span>';
  if (p && p.etat === "erreur") return `<span class="bad">Échec</span> <button class="btn discret petit" data-installer-modele="${esc(nom)}">Réessayer</button><small class="erreur-local">${esc(p.message)}</small>`;
  return loc.installe ? `<button class="btn petit" data-installer-modele="${esc(nom)}">Installer</button>` : '<small class="discret">Ollama requis</small>';
}

/* --- IA : abonnement (Claude Code, Codex), clé API ou IA locale ; une pour le Superviseur, une pour les agents */
let iaEtat = null, msgIA = "";
function ouvrirReglagesIA() {
  if (projetCourant) ouvrirSuperviseur();
  if (document.body.dataset.mob) vueMobile("travail");
  choisirBloc("sup-reglages");
  setTimeout(() => $("#g-ia") && $("#g-ia").scrollIntoView({ block: "start" }), 300);
}
async function gIA() {
  const d = (iaEtat = await api("/api/ia"));
  if (d.distant) { GB("ia", `<p class="aide-g discret">Les IA se connectent depuis le PC.</p>`); return; }
  const options = (pour) => {
    const items = pour === "superviseur" ? [] : [["", "Auto : l'outil de chaque rôle, sinon l'IA ci-dessous"]];
    if (d.claude) items.push(["claude-code", "Claude Code (abonnement)"]);
    if (d.codex && pour === "agents") items.push(["codex", "Codex (abonnement ChatGPT)"]);
    d.connexions.forEach((c) => items.push([c.id, `${c.nom} · ${c.modele || "?"}`]));
    const actuel = d[pour] || (pour === "superviseur" ? (d.actif === "claude-code" ? "claude-code" : (d.connexions[0] || {}).id || "") : "");
    return items.length ? items.map(([v, t]) => `<option value="${esc(v)}"${v === actuel ? " selected" : ""}>${esc(t)}</option>`).join("") : '<option value="">Aucune IA</option>';
  };
  const locales = d.locales.filter((l) => !d.connexions.some((c) => c.fournisseur === l));
  const etat = d.actif ? `<p class="ok aide-g">Prêt : le Superviseur répond avec ${d.actif === "claude-code" ? "Claude Code" : "l'IA connectée"}.</p>`
    : `<p class="warn aide-g">Aucune IA : connecte-en une ci-dessous (clé API, ou IA locale comme Ollama).</p>`;
  GB("ia", `${etat}${msgIA ? `<p class="warn aide-g">${esc(msgIA)}</p>` : ""}
    <div class="reglage"><span>Superviseur</span><select data-ia-pour="superviseur">${options("superviseur")}</select></div>
    <div class="reglage"><span>Agents</span><select data-ia-pour="agents">${options("agents")}</select></div>
    ${d.connexions.map((c) => `<div class="ia-ligne"><b>${esc(c.nom)}</b><select data-ia-modele="${esc(c.id)}"><option>${esc(c.modele || "?")}</option></select><button class="btn discret" data-ia-retirer="${esc(c.id)}">Retirer</button></div>`).join("")}
    ${locales.map((l) => `<div class="ia-ligne"><b>${esc((d.fournisseurs.find((f) => f.id === l) || {}).nom || l)} — détectée sur ce PC</b><button class="btn" data-ia-locale="${esc(l)}">Connecter</button></div>`).join("")}
    <div class="ia-ajout"><select id="ia-fournisseur">${d.fournisseurs.map((f) => `<option value="${esc(f.id)}" data-cle="${f.cle}">${esc(f.nom)}</option>`).join("")}</select>
      <input class="champ" id="ia-cle" type="password" autocomplete="off" placeholder="Clé API (gardée chiffrée sur ce PC)" spellcheck="false">
      <button class="btn principal" id="ia-ajouter">Connecter</button></div>
    <p class="aide-g discret" style="margin-top:8px">La clé est vérifiée puis chiffrée par Windows ; elle n'est jamais affichée ni envoyée ailleurs qu'au fournisseur choisi. IA locale : lance Ollama ou LM Studio, elle apparaît ici.</p>`);
  const fournisseur = $("#ia-fournisseur");
  if (!$("#ia-url")) $("#ia-cle").insertAdjacentHTML("beforebegin", '<input class="champ" id="ia-url" placeholder="Adresse de l\'IA (https://…/v1)" spellcheck="false" hidden>');
  const majCle = () => { const o = fournisseur.selectedOptions[0], autre = o && o.value === "autre";
    $("#ia-cle").hidden = o && o.dataset.cle === "false" && !autre; $("#ia-url").hidden = !autre;
    $("#ia-cle").placeholder = autre ? "Clé API (si l'IA en demande une)" : "Clé API (gardée chiffrée sur ce PC)"; };
  fournisseur.onchange = majCle; majCle();
  const ajouter = async (f, cle, url = "") => {
    msgIA = "";
    try { await api("/api/ia/ajouter", { fournisseur: f, cle, url }); } catch (e) { msgIA = e.message; }
    gIA(); chargerConversation(false);
  };
  $("#ia-ajouter").onclick = (e) => { e.target.disabled = true; e.target.textContent = "Vérification…"; ajouter(fournisseur.value, $("#ia-cle").value, fournisseur.value === "autre" ? $("#ia-url").value : ""); };
  $$("[data-ia-locale]").forEach((b) => (b.onclick = () => { b.disabled = true; ajouter(b.dataset.iaLocale, ""); }));
  $$("[data-ia-pour]").forEach((s) => (s.onchange = async () => { try { await api("/api/ia/choisir", { [s.dataset.iaPour]: s.value }); } catch (e) { msgIA = e.message; } gIA(); }));
  $$("[data-ia-retirer]").forEach((b) => (b.onclick = async () => { await api("/api/ia/retirer", { id: b.dataset.iaRetirer }); gIA(); }));
  $$("[data-ia-modele]").forEach((s) => (s.onfocus = async () => {         // liste des modèles chargée à l'ouverture
    if (s.dataset.charge) return; s.dataset.charge = "1";
    try {
      const r = await api("/api/ia/modeles", { id: s.dataset.iaModele });
      const actuel = s.value;
      s.innerHTML = r.modeles.map((m) => `<option${m === actuel ? " selected" : ""}>${esc(m)}</option>`).join("");
    } catch (e) { msgIA = e.message; }
  }));
  $$("[data-ia-modele]").forEach((s) => (s.onchange = () => api("/api/ia/choisir", { id: s.dataset.iaModele, modele: s.value }).then(gIA)));
}

/* --- Téléphone : relais Tailscale (s'arrête avec le studio) et appareils associés par code à 6 chiffres */
let codeTel = null, msgTel = "";
/* Notifications sur ce téléphone : tâche à valider ou bloquée → notification, « Valider » dedans si la relecture est OK */
async function blocNotifs(msg = "") {
  const el = $("#notifs-tel");
  if (!el) return;
  if (location.protocol !== "https:" || !("serviceWorker" in navigator) || !("PushManager" in window)) {
    el.innerHTML = '<p class="aide-g discret">Notifications : ouvre le studio dans Chrome, à l\'adresse https du PC, puis « Ajouter à l\'écran d\'accueil ».</p>'; return;
  }
  const reg = await navigator.serviceWorker.ready;
  const abo = await reg.pushManager.getSubscription();
  const refuse = Notification.permission === "denied";
  el.innerHTML = `<div class="reglage"><span>Notifications sur ce téléphone<br><small class="discret">Tâche à valider ou bloquée. « Valider » directement depuis la notification quand la relecture est OK.</small></span>
    <div class="puces petites" id="notif-choix">${[[true, "Activées"], [false, "Coupées"]].map(([v, t]) => `<button class="puce${!!abo === v ? " sel" : ""}" data-v="${v}">${t}</button>`).join("")}</div></div>
    ${abo ? '<div class="reglage"><span></span><button class="btn discret" id="notif-test">Envoyer une notification de test</button></div>' : ""}
    ${refuse ? '<p class="warn aide-g">Notifications bloquées pour ce site : autorise-les dans les réglages de Chrome (cadenas à gauche de l\'adresse).</p>' : ""}
    ${msg ? `<p class="aide-g">${esc(msg)}</p>` : ""}`;
  $$("#notif-choix .puce").forEach((b) => (b.onclick = async () => {
    b.disabled = true;
    try {
      if (b.dataset.v === "true") {
        if ((await Notification.requestPermission()) !== "granted") return blocNotifs("Autorise les notifications pour les recevoir.");
        const { cle } = await api("/api/push");
        const brut = atob(cle.replace(/-/g, "+").replace(/_/g, "/") + "===".slice((cle.length + 3) % 4));
        const s = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: Uint8Array.from(brut, (c) => c.charCodeAt(0)) });
        await api("/api/push/abonner", { abonnement: s.toJSON(), appareil: /Android/i.test(navigator.userAgent) ? "Android" : "Téléphone" });
        blocNotifs("Activées : tu seras prévenu dès qu'une tâche t'attend.");
      } else {
        const s = await reg.pushManager.getSubscription();
        if (s) { await api("/api/push/desabonner", { endpoint: s.endpoint }).catch(() => {}); await s.unsubscribe(); }
        blocNotifs("Coupées.");
      }
    } catch (e) { blocNotifs(e.message); }
  }));
  if ($("#notif-test")) $("#notif-test").onclick = async () => {
    try { const r = await api("/api/push/test", {}); blocNotifs(r.envoyes ? "Envoyée : elle arrive dans quelques secondes." : "Pas envoyée : le PC n'a pas pu joindre le service de notification."); }
    catch (e) { blocNotifs(e.message); }
  };
}
async function gTelephone() {
  const m = await api("/api/mobile");
  const ts = m.tailscale || {};
  const date = (d) => (d ? new Date(d).toLocaleString("fr-FR", { dateStyle: "short", timeStyle: "short" }) : "jamais");
  if (m.distant) { GB("telephone", `<p class="aide-g discret">Ce téléphone est associé. Les réglages d'accès se font depuis le PC.</p><div id="notifs-tel"></div>`); blocNotifs(); return; }
  let etat;
  if (!ts.ok) etat = `<p class="warn aide-g">${esc(ts.info || "Tailscale indisponible.")}</p>`;
  else if (m.actif) etat = `<p class="ok aide-g">Accessible sur le téléphone : <b>https://${esc(m.adresse || ts.dns)}</b></p>`;
  else etat = `<p class="aide-g discret">Tailscale est prêt (${esc(ts.dns)}). Accès coupé.</p>`;
  if (m.autoriser) etat += `<p class="warn aide-g">Tailscale demande d'autoriser « Serve » une fois : <a href="${esc(m.autoriser)}" target="_blank" rel="noopener">ouvrir le lien</a>, puis Couper / Activer.</p>`;
  else if (m.reglage && !m.actif && m.erreur) etat += `<p class="warn aide-g">${esc(m.erreur)}</p>`;
  const code = codeTel && codeTel.fin > Date.now()
    ? `<p class="aide-g">Sur le téléphone, ouvre <b>https://${esc(m.adresse || ts.dns)}</b> et tape :</p><div class="code-tel">${codeTel.code.replace(/(\d{3})(\d{3})/, "$1 $2")}</div><p class="aide-g discret">Valable 10 minutes, une seule fois.</p>` : "";
  const apps = (m.appareils || []).map((a) => `<div class="tel-app"><span><b>${esc(a.nom)}</b><br><small class="discret">associé le ${date(a.cree)} · vu ${date(a.vu)}</small></span><button class="btn discret" data-revoquer="${esc(a.id)}">Révoquer</button></div>`).join("");
  if (msgTel && msgTel !== ts.info) etat += `<p class="warn aide-g">${esc(msgTel)}</p>`;
  GB("telephone", `${etat}
    <div class="reglage"><span>Accès depuis le téléphone</span><div class="puces petites" id="tel-acces">${[[true, "Activé"], [false, "Coupé"]].map(([v, t]) => `<button class="puce${!!m.reglage === v ? " sel" : ""}" data-v="${v}">${t}</button>`).join("")}</div></div>
    ${m.actif ? `<div class="reglage"><span>Nouveau téléphone</span><button class="btn" id="tel-code">Associer un téléphone</button></div>` : ""}
    ${code}${apps ? `<p class="sous-titre-g" style="margin-top:12px">Appareils associés</p>${apps}` : ""}
    <p class="aide-g discret" style="margin-top:10px">Seuls tes appareils connectés à ton compte Tailscale voient cette adresse, et chacun doit être associé ici.${m.actif ? " Tant que l'accès est activé, fermer la fenêtre ne ferme plus le studio (le téléphone reste connecté) : pour l'arrêter, bouton « Fermer le studio »." : ""}</p>`);
  $$("#tel-acces .puce").forEach((b) => (b.onclick = async () => {
    b.disabled = true;
    if (b.dataset.v === "true") b.textContent = "Connexion…";
    try { const r = await api("/api/mobile/acces", { oui: b.dataset.v === "true" }); msgTel = !r.ok && r.info ? r.info : ""; }
    catch (e) { msgTel = e.message; }
    gTelephone();
  }));
  const bc = $("#tel-code");
  if (bc) bc.onclick = async () => { const r = await api("/api/mobile/code", { nom: "Téléphone" }); codeTel = { code: r.code, fin: Date.now() + r.minutes * 60000 }; gTelephone(); };
  $$("[data-revoquer]").forEach((b) => (b.onclick = async () => { await api("/api/mobile/revoquer", { id: b.dataset.revoquer }); gTelephone(); }));
}
async function gReglages() {
  const l = await api("/api/reglages");
  const groupes = [...new Set(l.map((r) => r.groupe))];
  const champ = (r) => {
    const id = `${r.section}.${r.cle}`;
    if (r.type === "bool") return `<div class="puces petites" data-r="${id}">${[[true, "Oui"], [false, "Non"]].map(([v, t]) => `<button class="puce${r.valeur === v ? " sel" : ""}" data-v="${v}">${t}</button>`).join("")}</div>`;
    if (r.choix) return `<select data-r="${id}">${r.choix.map((v) => `<option value="${esc(v)}"${String(v) === String(r.valeur) ? " selected" : ""}>${r.unite && v === 0 ? "Aucune" : esc(v)}${r.unite && v ? " " + r.unite : ""}</option>`).join("")}</select>`;
    return `<div class="ligne-chemin"><input class="champ" data-r="${id}" value="${esc(r.valeur || "")}" placeholder="${r.type === "texte" ? "Ton prénom" : "C:\\…"}" spellcheck="false"><button class="btn discret" data-enr="${id}" title="Enregistrer">OK</button></div>`;
  };
  const groupe = (g) => `<div class="groupe-r"><p class="sous-titre-g">${esc(g)}</p>` + l.filter((r) => r.groupe === g).map((r) =>
    `<div class="reglage${r.type === "chemin" ? " large" : ""}"><span>${esc(r.libelle)}${r.redemarrage ? ' <small class="discret" title="Pris en compte au prochain démarrage du studio">↻</small>' : ""}</span>${champ(r)}</div>`).join("") + "</div>";
  const place = (g) => /chemin/i.test(g) ? 3 : /limite|alerte/i.test(g) ? 2 : 1;   // à droite : limites en haut, chemins en bas
  const sans = (h) => h.replace(/<p class="sous-titre-g">[^<]*<\/p>/, "");          // le titre du bloc suffit
  GB("reglages", groupes.filter((g) => place(g) === 1).map(groupe).join("") + `<p class="${msgReglage.c} aide-g" id="r-msg" style="margin-top:10px">${esc(msgReglage.t)}</p>`);
  GB("reglages2", groupes.filter((g) => place(g) === 2).map((g) => sans(groupe(g))).join("") || '<p class="vide">Rien ici.</p>');
  const enregistrer = async (id, valeur) => {
    const [section, cle] = id.split(".");
    try { const r = await api("/api/reglages", { section, cle, valeur }); msgReglage = { t: r.message, c: "ok" }; gReglages(); if (section === "usage") limitesAccueil(); }
    catch (e) { msgReglage = { t: e.message, c: "warn" }; gReglages(); }
  };
  const Z = (q) => $$(`#g-reglages ${q}, #g-reglages2 ${q}`);                     // Réglages (Accueil) et Limites (Gestion › Usage)
  Z(".puces[data-r] .puce").forEach((b) => (b.onclick = () => enregistrer(b.parentElement.dataset.r, b.dataset.v === "true")));
  Z("select[data-r]").forEach((x) => (x.onchange = () => enregistrer(x.dataset.r, /^\d+$/.test(x.value) ? +x.value : x.value)));
  Z("[data-enr]").forEach((b) => (b.onclick = () => enregistrer(b.dataset.enr, Z(`input[data-r="${b.dataset.enr}"]`)[0].value)));
  Z("input[data-r]").forEach((x) => (x.onkeydown = (e) => { if (e.key === "Enter") enregistrer(x.dataset.r, x.value); }));
}
async function versionsOutils() {
  let v;
  try { v = await api("/api/outils/versions"); } catch (e) { if ($("#o-versions")) $("#o-versions").innerHTML = `<p class="warn">${esc(e.message)}</p>`; return; }
  if (!$("#o-versions")) return;
  const tr = await api("/api/travaux").catch(() => ({}));
  $("#o-versions").innerHTML = `<table class="versions">${Object.entries(v).map(([k, x]) => {
    const enCours = (tr[`maj:${k}`] || {}).etat === "en_cours";
    const etat = !x.installee ? '<span class="bad">introuvable</span>' : x.a_jour === true ? '<span class="ok">à jour</span>'
      : x.a_jour === false ? `<span class="warn">${esc(x.derniere)} disponible</span>` : '<span class="discret">dernière version inconnue</span>';
    const bouton = enCours ? '<button class="btn" disabled>Mise à jour…</button>'
      : x.a_jour === false && x.possible ? `<button class="btn principal" data-maj="${k}">Mettre à jour</button>`
      : x.a_jour === false ? `<small class="discret">${esc(x.methode)}</small>` : "";
    return `<tr><td><b>${esc(x.nom)}</b></td><td class="nowrap">${esc(x.installee || "—")}</td><td>${etat}</td><td>${bouton}</td></tr>`;
  }).join("")}</table><p class="discret aide-g">Opus, Sonnet et Haiku suivent seuls les nouveaux modèles : mettre l'outil à jour suffit.</p>`;
  $$("#o-versions [data-maj]").forEach((b) => (b.onclick = async () => {
    const x = v[b.dataset.maj];
    if (!confirm(`Mettre à jour ${x.nom} (${x.installee} → ${x.derniere}) ?\n\nCommande : ${x.methode}. Les tâches doivent être terminées.`)) return;
    try { await api("/api/outils/mettre-a-jour", { outil: b.dataset.maj }); majTravaux(); setTimeout(gOutils, 800); setTimeout(gEntretien, 800); } catch (e) { alert(e.message); }
  }));
}

/* --- Usage */
const USAGES = { "tâche": "Tâches", relecture: "Relectures (auditeur)", superviseur: "Superviseur" };
const nb = (n) => n >= 1e6 ? `${(n / 1e6).toFixed(1).replace(".", ",")} M` : n >= 1e3 ? `${Math.round(n / 1e3)} k` : String(n || 0);
const minutes = (s) => !s ? "0 min" : s < 60 ? `${s} s` : s < 3600 ? `${Math.round(s / 60)} min` : `${Math.floor(s / 3600)} h ${String(Math.round((s % 3600) / 60)).padStart(2, "0")}`;
function ajusterUsage() {                                       // « Détails du jour » ouverts seulement s'ils tiennent sans défiler
  const c = $("#g-usage") && $("#g-usage").closest(".corps-g"), d = $("#u-details");
  if (!c || !d || !c.clientHeight) return;
  d.open = true;
  if (c.scrollHeight > c.clientHeight + 1) d.open = false;
}
/* Usage de toutes les IA : abonnements (inclus), clés API (coût à l'usage), IA locales (gratuit) */
const COULEURS_IA = ["var(--cyan)", "var(--magenta)", "#ffc35c", "#5ee6a0", "#9b8cff", "#ff8a3d", "#4aa8ff", "#e6fbff"];
const dollars = (v) => v == null ? "—" : v < 0.01 && v > 0 ? "< 0,01 $" : `${v.toFixed(2).replace(".", ",")} $`;
async function gUsage() {
  const u = await api("/api/usage");
  const ordre = u.ordre || Object.keys(u.familles);
  const couleur = (fam) => COULEURS_IA[ordre.indexOf(fam) % COULEURS_IA.length];
  const max = Math.max(60, ...u.jours.map((d) => Object.values(d.familles).reduce((a, b) => a + b, 0)));
  const jourCourt = (d) => new Date(d + "T12:00:00").toLocaleDateString("fr-FR", { weekday: "short" });
  const ACCES = { abonnement: "abonnement", cle: "clé API", local: "local" };
  const cellule = (t) => t.appels ? `${minutes(t.duree_s)}<small class="discret"> · ${t.appels}</small>` : '<span class="discret">—</span>';
  const cout = (f) => f.acces === "abonnement" ? `<span class="discret" title="${f.semaine.cout_usd ? `≈ ${dollars(f.semaine.cout_usd)} si c'était facturé à l'API` : ""}">inclus</span>`
    : f.acces === "local" ? '<span class="ok">gratuit</span>' : `<b>${dollars(f.semaine.cout_usd)}</b>`;
  const lignes = ordre.map((fam) => { const f = u.familles[fam];
    return `<tr><td><span class="carre" style="background:${couleur(fam)}"></span> <b>${esc(fam)}</b></td><td class="discret">${ACCES[f.acces]}</td><td>${cellule(f.fenetre)}</td><td>${cellule(f.jour)}</td><td>${cellule(f.semaine)}</td><td class="nowrap">${cout(f)}</td></tr>`; }).join("");
  const tableau = (l, nom) => l.length ? `<table>${l.map((x) => `<tr><td>${esc(nom(x))}</td><td class="nowrap">${minutes(x.duree_s)}</td><td class="nowrap">${x.appels} appel${x.appels > 1 ? "s" : ""}</td></tr>`).join("")}</table>` : '<p class="vide">Rien aujourd\'hui.</p>';
  const cp = u.cout_paye || {};
  const paye = ordre.some((f) => u.familles[f].acces === "cle");
  GB("usage", `${paye ? `<div class="cout-usage"><span>Payé à l'usage (clés API)</span><b>${dollars(cp.jour)}</b><small>aujourd'hui</small><b>${dollars(cp.semaine)}</b><small>7 jours</small><b>${dollars(cp.mois)}</b><small>30 jours</small></div>
      <p class="discret aide-g">Coût réel donné par OpenRouter, sinon estimé au prix du jour${cp.sans_prix ? ` (${cp.sans_prix} appel(s) sans prix connu)` : ""}. Les abonnements sont inclus, les IA locales gratuites.</p>` : ""}
    <table class="usage-resume"><thead><tr><th>IA</th><th>Accès</th><th>5 h</th><th>Aujourd'hui</th><th>7 jours</th><th>Coût 7 j</th></tr></thead><tbody>${lignes}</tbody></table>
    <div class="usage-jours petit">${u.jours.map((d) => `<div class="usage-jour" title="${esc(d.jour)} · ${ordre.filter((f) => d.familles[f]).map((f) => `${f} ${minutes(d.familles[f])}`).join(" · ") || "rien"}">
      <div class="pile">${ordre.map((f) => d.familles[f] ? `<span style="height:${Math.round(d.familles[f] / max * 100)}%;background:${couleur(f)}"></span>` : "").join("")}</div><small class="discret">${jourCourt(d.jour)}</small></div>`).join("")}</div>
    <details class="pli" id="u-details" style="margin-top:10px"><summary>Détails du jour</summary>
      <div class="usage-duo">${tableau(u.par_usage, (x) => USAGES[x.nom] || x.nom)}${tableau(u.par_projet, (x) => x.nom)}</div>
      ${u.derniers.length ? `<p class="sous-titre-g">Derniers appels</p><table>${u.derniers.slice(0, 8).map((x) => `<tr><td class="nowrap">${esc(x.heure)}</td><td>${esc(x.famille)}${x.modele ? " · " + esc(x.modele) : ""}</td><td>${esc(USAGES[x.usage] || x.usage)}</td><td>${esc(x.projet)}</td><td class="nowrap">${minutes(x.duree_s)}</td><td class="nowrap">${nb((x.entree || 0) + (x.cache || 0) + (x.sortie || 0))} jetons${x.cout_usd != null && !["Claude", "Codex"].includes(x.famille) ? " · " + dollars(x.cout_usd) : ""}</td><td>${x.ok ? "" : '<span class="bad">échec</span>'}</td></tr>`).join("")}</table>` : ""}
      <p class="discret aide-g">Seul l'usage lancé par le studio est compté.</p></details>`);
  ajusterUsage();
}

/* --- Données : mémoire, sauvegardes, rangement */
let porteeMemoire = "general";
async function gMemoire() {
  if (!cibles.length) cibles = await api("/api/cibles");
  GB("memoire", `<div class="ligne-g"><select id="m-portee" aria-label="Portée de la mémoire">${[["general", "Général"], ...cibles.map((c) => [c.memoire.replace(/^studio:/, ""), c.nom])].map(([v, t]) => `<option value="${esc(v)}"${v === porteeMemoire ? " selected" : ""}>${esc(t)}</option>`).join("")}</select>
      <input class="recherche" id="m-q" placeholder="Chercher (Entrée)"></div><div id="m-res" class="defile-g court">…</div>
    <details class="pli"><summary>Ajouter un souvenir</summary>
      <textarea id="m-texte" class="zone-texte" placeholder="Un fait ou une décision à retenir — jamais de secret"></textarea>
      <div class="actions"><button class="btn" id="m-ajouter">Ajouter</button><span id="m-msg" class="discret"></span></div></details>`);
  $("#m-portee").onchange = () => { porteeMemoire = $("#m-portee").value; chercher(); };
  $("#m-q").onkeydown = (e) => { if (e.key === "Enter") chercher(); };
  $("#m-ajouter").onclick = async () => {
    try { const r = await api("/api/memoire", { portee: porteeMemoire, texte: $("#m-texte").value }); $("#m-msg").textContent = r.partage ? "Enregistré." : `Non partagé : ${r.statut}`; $("#m-texte").value = ""; chercher(); }
    catch (e) { $("#m-msg").textContent = e.message; }
  };
  chercher();
}
async function chercher() {
  try {
    const r = await api(`/api/memoire?${new URLSearchParams({ q: $("#m-q").value, portee: porteeMemoire })}`);
    $("#m-res").innerHTML = (r.en_attente ? `<div class="alerte">${r.en_attente} écriture(s) pas encore partagée(s).</div>` : "")
      + (r.souvenirs.map((x) => `<div class="souvenir">${esc(x.content)}<br><small>${esc(x.scope.replace(/^studio:/, ""))} · ${esc(x.provenance?.outil || "?")} · ${esc((x.created_at || "").slice(0, 10))}</small></div>`).join("") || '<p class="vide">Rien pour cette recherche.</p>');
  } catch (e) { $("#m-res").innerHTML = `<div class="alerte">${esc(e.message)}</div>`; }
}
/* --- Git et GitHub : état des dépôts, branches, copies de travail, actions sur un clic */
let depotG = "";                                            // dépôt affiché dans l'onglet Branches du projet
const resumeGit = (e) => e.erreur ? `<span class="bad">${esc(e.erreur)}</span>` : [
  e.detache ? '<span class="warn">HEAD détaché</span>' : `⎇ ${esc(e.branche)}`,
  e.modifies.length ? `<span class="warn">${e.modifies.length} fichier${e.modifies.length > 1 ? "s" : ""} modifié${e.modifies.length > 1 ? "s" : ""}</span>` : '<span class="ok">propre</span>',
  e.en_avance ? `<span class="warn">↑ ${e.en_avance} à pousser</span>` : "", e.en_retard ? `<span class="warn">↓ ${e.en_retard} à récupérer</span>` : "",
  !e.distant ? '<span class="discret">pas de GitHub</span>' : !e.amont && !e.detache ? '<span class="discret">branche pas sur GitHub</span>' : ""].filter(Boolean).join(" · ");
async function detailGit() {
  let d;
  try { d = await api(`/api/git/${encodeURIComponent(depotG)}`); } catch (e) { GB("git", `<div class="alerte">${esc(e.message)}</div>`); return; }
  const tr = await api("/api/travaux").catch(() => ({}));
  const enCours = (a) => (tr[`git:${depotG.split(":")[1]}:${a}`] || {}).etat === "en_cours";
  const bouton = (a, libelle, ok, aide) => `<button class="btn${a === "pousser" && d.en_avance ? " principal" : ""}" data-git="${a}" ${ok && !enCours(a) ? "" : "disabled"} title="${esc(aide)}">${enCours(a) ? "En cours…" : libelle}</button>`;
  const derniers = Object.entries(tr).filter(([k]) => k.startsWith(`git:${depotG.split(":")[1]}:`)).map(([, j]) => j).sort((a, b) => (a.debut < b.debut ? 1 : -1));
  GB("git-etat", `${d.detache ? '<div class="alerte">HEAD détaché : aucune branche courante.</div>' : ""}
    <div class="actions-git">${bouton("actualiser", "Fetch", !!d.distant, "Actualiser : git fetch --prune, regarde ce qu'il y a de neuf sur GitHub, ne change aucun fichier")}
      ${bouton("recuperer", d.en_retard ? `Pull ↓${d.en_retard}` : "Pull", !!d.amont && !d.detache, "Récupérer : git pull --ff-only, seulement si rien ne se mélange")}
      ${d.gh ? bouton("pr", "Pull request", !!d.amont && !d.en_avance && !d.detache, "Créer une pull request sur GitHub (gh pr create --fill)") : ""}
      ${d.distant ? (d.distant.startsWith("https://github.com/") ? `<a class="lien lien-depot" href="${esc(d.distant)}" target="_blank" rel="noopener">${esc(d.distant.replace("https://", ""))}</a>` : `<small class="discret">${esc(d.distant)}</small>`) : ""}
      <span id="git-msg" class="discret"></span></div>
    ${derniers.length ? `<p class="discret" style="margin:-6px 0 12px">Dernière action : ${derniers[0].etat === "en_cours" ? "⚙" : derniers[0].etat === "ok" ? "✔" : "✖"} ${esc(derniers[0].titre)}${derniers[0].etat === "echec" && derniers[0].sortie ? ` — <span class="bad">${esc(derniers[0].sortie.slice(-200))}</span>` : ""}</p>` : ""}
    `);
  blocCommit(d);
  arbreD = [d, bouton]; grapheBranches(d, bouton);
  const msg = (t) => { const m = $("#git-msg"); if (m) m.textContent = t; };
  const nbFus = d.branches.filter((b) => b.fusionnee && !b.courante).length;
  $("#g-git").onclick = async (e) => {
    const x = (sel) => e.target.closest(sel);
    let b;
    if ((b = x("[data-git]"))) {
      const a = b.dataset.git;
      if ((a === "pousser" || a === "pr") && !confirm(a === "pousser" ? `Pousser ${d.branche} vers GitHub ?` : `Créer une pull request pour ${d.branche} sur GitHub ?`)) return;
      try { const r = await api("/api/git/action", { cible: depotG, action: a }); msg(r.message); majTravaux(); suivreGit(); } catch (er) { msg(er.message); }
    } else if ((b = x("#git-nettoyer"))) {
      if (!confirm(`Supprimer les ${nbFus} branches déjà fusionnées ? Leurs commits sont dans ${d.branche} : rien n'est perdu.`)) return;
      try { const r = await api("/api/git/nettoyer", { cible: depotG }); msg(r.message); detailGit(); ligneGit(depotG); } catch (er) { msg(er.message); }
    } else if ((b = x("[data-fusion]"))) {
      b.disabled = true; b.textContent = "Merge…";
      try {
        const r = await api("/api/git/fusionner", { cible: depotG, branche: b.dataset.fusion }); msg(r.message);
        const ligne = b.closest(".act-b");
        if (ligne) ligne.classList.add("fusion");           // le bouton s'efface, puis l'arbre se redessine
        setTimeout(() => { detailGit(); ligneGit(depotG); }, ligne && !mouvementReduit() ? 650 : 0); derniereVue = "";
      } catch (er) { msg(er.message); b.disabled = false; b.textContent = "Merge"; }
    } else if ((b = x("[data-effacer]"))) {
      if (!confirm(`Effacer la branche ${b.dataset.effacer} ?\n\nSon travail non fusionné sera perdu. La tâche reste dans l'historique (annulée), avec son compte rendu.`)) return;
      try { const r = await api("/api/git/effacer-branche", { cible: depotG, branche: b.dataset.effacer }); msg(r.message); detailGit(); ligneGit(depotG); derniereVue = ""; } catch (er) { msg(er.message); }
    } else if ((b = x("[data-suppr]"))) {
      if (!confirm(`Supprimer la branche ${b.dataset.suppr} ? Elle est déjà fusionnée : aucun commit n'est perdu.`)) return;
      try { const r = await api("/api/git/supprimer-branche", { cible: depotG, branche: b.dataset.suppr }); msg(r.message); detailGit(); ligneGit(depotG); } catch (er) { msg(er.message); }
    } else if ((b = x("[data-retirer]"))) {
      if (!confirm("Retirer cette copie de travail ? Le résultat, le diff et le journal de la tâche restent.")) return;
      try { const r = await api(`/api/espaces/${b.dataset.retirer}/retirer`, {}); msg(r.message); detailGit(); } catch (er) { msg(er.message); }
    } else if ((b = x("[data-voir-tache]"))) {
      selection = b.dataset.voirTache; derniereVue = ""; blocCourant = "detail"; afficher(); rendreOngletsBloc();
    }
  };
  $$("#g-git-etat [data-git]").forEach((b) => (b.onclick = async () => {
    const a = b.dataset.git;
    if (a === "pr" && !confirm(`Créer une pull request pour ${d.branche} sur GitHub ?`)) return;
    try { const r = await api("/api/git/action", { cible: depotG, action: a }); msg(r.message); majTravaux(); suivreGit(); } catch (er) { msg(er.message); }
  }));
  if (Object.keys(tr).some((k) => k.startsWith("git:") && tr[k].etat === "en_cours")) suivreGit();
}
/* Branches en « ligne de métro » : main en ligne néon verticale ; chaque tâche s'en détache en courbe vers sa carte,
   couleur = état. L'action utile est sur la carte (Fusionner, Valider, Reprendre) : un clic. Clic sur la carte = la tâche. */
const mouvementReduit = () => matchMedia("(prefers-reduced-motion: reduce)").matches;
function teinteBranche(b) {
  const st = b.tache ? b.tache.statut : "";
  if (["creee", "en_cours", "en_attente_creneau"].includes(st)) return ["bleu", "en cours"];
  if (A_VALIDER.includes(st)) return ["jaune", "à valider"];
  if (["approuvee", "appliquee"].includes(st)) return ["vert", "prête à fusionner"];
  if (["bloquee", "echec", "interrompue"].includes(st)) return ["rouge", LIBELLES[st]];
  if (st === "annulee") return ["rouge", "annulée"];
  return ["gris", "branche"];
}
function depuisQuand(date) {
  const t = Date.parse(String(date).replace(" ", "T")); if (!t) return "";
  const m = Math.round((Date.now() - t) / 60000);
  return m < 1 ? "à l'instant" : m < 60 ? `il y a ${m} min` : m < 1440 ? `il y a ${Math.round(m / 60)} h` : `il y a ${Math.round(m / 1440)} j`;
}
function grapheBranches(d, bouton) {
  /* Arbre façon symbole USB / circuit imprimé, main à l'horizontale vers sa flèche. Un seul pas E partout le long de main :
     flèche → carrés des fusions → départs des branches (la plus ancienne près des fusions, les nouvelles vers la gauche).
     Chaque branche se détache à 45° puis file parallèle à main jusqu'à son symbole (même taille pour toutes).
     Au-dessus : bloquées et annulées. En dessous : en cours, à valider, prêtes. Le texte apparaît au survol ;
     le bouton d'action reste toujours visible au bout de la branche. */
  const el = $("#g-git"); if (!el) return;
  const vivantes = d.branches.filter((b) => !b.courante && !b.fusionnee).sort((a, b) => (a.date < b.date ? -1 : 1));
  // carrés : les fusions pas encore poussées sur GitHub (après Push, il n'en reste plus) ; sans GitHub, les 12 dernières
  const fusions = (d.a_pousser || d.historique || []).filter((c) => /^(Fusion studio|Merge branch)/.test(c.sujet)).slice(-12);
  const nbFus = d.branches.filter((b) => b.fusionnee && !b.courante).length;
  // E : pas des carrés de fusion ; EB : pas des branches, le même pour toutes, juste assez grand pour qu'une branche et
  // ses boutons ne touchent jamais la suivante du même côté (les deux côtés alternent librement)
  // Une branche = 45° (D) + trait parallèle (HZ) jusqu'à son symbole, ses boutons centrés dessous. E : pas des carrés
  // de fusion. EB : pas des branches, le même pour toutes ; chaque symbole tombe au milieu de l'écart entre son départ et
  // le départ suivant (ou la dernière fusion). Trop long pour le cadre : l'arbre défile à l'horizontale.
  const T = 12, C = 10, D = 22, HZ = 62, E = 56, GAP = 5, BTN = 21;   // boutons centrés sous le symbole
  const EB = 2 * (D + HZ);                                   // le symbole tombe pile au milieu de l'écart entre deux départs
  const cy = D + T / 2 + 7 + BTN + 10, H = cy * 2;
  const W = Math.max(el.clientWidth || 700, 60 + (fusions.length + 1) * E + vivantes.length * EB);
  const xA = W - 16;                                         // pointe de la flèche ; un pas E entre la flèche et chaque fusion
  const pos = (k) => xA - T / 2 - (k + 1) * E;               // k-ième fusion depuis la flèche
  const depart = (i) => pos(fusions.length - 1) - (i + 1) * EB;   // la plus ancienne : symbole au milieu entre son départ et la dernière fusion
  const forme = (cl, x, y, sens) => sens === "carre" ? `<rect class="${cl}" x="${x - C / 2}" y="${y - C / 2}" width="${C}" height="${C}"/>`
    : sens === "rond" ? `<circle class="${cl}" cx="${x}" cy="${y}" r="${T / 2}"/>`
    : `<path class="${cl}" d="M${x - T / 2} ${y - T / 2} L${x + T / 2} ${y} L${x - T / 2} ${y + T / 2} Z"/>`;   // flèche vers la droite
  const rel = vivantes.slice().reverse().map((b, i) => {      // la plus ancienne juste après la dernière fusion
    const [teinte, lib] = teinteBranche(b);
    const cote = ["rouge", "gris"].includes(teinte) ? -1 : 1, s0 = depart(i);
    return { b, teinte, lib, cote, s0, y: cy + cote * D, xp: s0 + D + HZ };
  });
  const x0 = Math.min(rel.length ? rel[rel.length - 1].s0 - 24 : pos(fusions.length), 20);
  let xs = x0, troncs = "", defs = "";
  for (const r of rel.slice().sort((a, b) => a.s0 - b.s0)) { troncs += `<line class="tronc" x1="${xs}" y1="${cy}" x2="${r.s0}" y2="${cy}"/>`; xs = r.s0 + GAP; }
  troncs += `<line class="tronc" x1="${xs}" y1="${cy}" x2="${xA - T}" y2="${cy}"/>`;
  let svg = `${troncs}${forme("fleche", xA - T / 2, cy, "droite")}${forme("pied", x0 - T / 2, cy, "rond")}`;
  svg += fusions.slice().reverse().map((c, i) => `<g><title>${esc(c.date)} · ${esc(c.sujet)}</title>${forme("carre-f", pos(i), cy, "carre")}</g>`).join("");
  const zones = rel.map((r, k) => {
    const { b, teinte, cote, s0, y, xp } = r, t = b.tache;
    const gid = `deg-${k}`;                                   // la diagonale passe en dégradé du cyan de main à la couleur de la branche
    defs += `<linearGradient id="${gid}" gradientUnits="userSpaceOnUse" x1="${s0}" y1="${cy}" x2="${s0 + D}" y2="${y}"><stop offset="0" class="arret-main"/><stop offset="1" class="arret-${teinte}"/></linearGradient>`;
    svg += `<g class="branche-svg" data-i="${k}"><line class="trace-d" stroke="url(#${gid})" x1="${s0}" y1="${cy}" x2="${s0 + D}" y2="${y}"/><line class="trace ${teinte}" x1="${s0 + D}" y1="${y}" x2="${xp - T / 2 - 1}" y2="${y}"/>`
      + forme(`pad ${teinte}${teinte === "bleu" ? " pulse" : ""}`, xp, y, teinte === "bleu" ? "rond" : teinte === "jaune" ? "droite" : "carre") + "</g>";
    // sous le symbole : seulement les actions git — Commit (grisé s'il n'y a rien à valider), Merge, ou Delete pour une
    // branche rouge ; Stop, Reprendre et Annuler sont dans la fiche qui s'ouvre au survol du symbole
    let act = "";
    if (teinte === "rouge" && t) act = `<button class="btn petit danger" data-effacer="${esc(b.nom)}" title="Supprimer : annule la tâche si besoin, retire sa copie et efface la branche (git branch -D)">Delete</button>`;
    else if (teinte === "vert") act = `<button class="btn principal petit" data-fusion="${esc(b.nom)}" title="Fusionner : git merge dans ${esc(d.branche)}, en local ; rien n'est poussé vers GitHub">Merge</button>`;
    else if (t) {
      const aValider = A_VALIDER.includes(t.statut);
      act = `<button class="btn${aValider ? " principal" : ""} petit" data-rapide="valider" data-tid="${esc(t.id)}" ${aValider ? "" : "disabled"} title="${aValider ? "Valider : le travail est enregistré (git commit) sur la branche de la tâche" : "Rien à valider pour l'instant"}">Commit</button>`;
    }
    const zone = `left:${xp - 15}px;top:${y - 15}px;width:30px;height:30px`;     // survol du symbole
    return `<div class="zone-b" data-i="${k}" ${t ? `data-voir-tache="${esc(t.id)}"` : ""} tabindex="0" role="button" aria-label="${esc(t ? t.titre : b.nom)}" style="${zone}"></div>
      ${act ? `<div class="act-b" style="left:${xp}px;top:${cote > 0 ? y + T / 2 + 8 : y - T / 2 - 8 - BTN}px">${act}</div>` : ""}`;
  });
  const peutPousser = !!d.distant && !d.detache && !d.en_retard && (d.en_avance || !d.amont);
  el.innerHTML = `<div class="arbre-tete"><span class="branche-c">⎇ ${esc(d.branche)}</span>
      <span class="meta-main">${d.en_avance ? `<b>${d.en_avance}</b> commit${d.en_avance > 1 ? "s" : ""} à pousser` : d.amont ? "à jour avec GitHub" : "pas encore sur GitHub"}${fusions.length ? ` · ${fusions.length} fusion${fusions.length > 1 ? "s" : ""} ${d.a_pousser ? "à pousser" : "récente" + (fusions.length > 1 ? "s" : "")}` : ""}</span>
      ${bouton("pousser", d.en_avance ? `Push ↑${d.en_avance}` : "Push", peutPousser, "Pousser : git push de la branche courante vers GitHub (jamais forcé)")}</div>
    <div class="arbre-cadre"><div class="arbre-defile"><div class="arbre" style="width:${W}px;height:${H}px"><svg width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" aria-hidden="true"><defs>${defs}</defs>${svg}</svg>${zones.join("")}
      ${!vivantes.length ? `<p class="arbre-vide" style="top:${cy + 14}px;right:${W - pos(fusions.length) + 10}px">Aucune branche ouverte : tout est dans main.</p>` : ""}</div></div>
      <div class="info-b" hidden></div></div>
    ${nbFus ? `<div class="metro-pied"><span>✓ ${nbFus} branche${nbFus > 1 ? "s" : ""} fusionnée${nbFus > 1 ? "s" : ""} encore présente${nbFus > 1 ? "s" : ""}</span><button class="lien" id="git-nettoyer" title="Supprimer : git branch -d sur chaque branche déjà fusionnée (copies de travail retirées avec) ; aucun commit perdu">Delete</button></div>` : ""}`;
  // survol (ou focus clavier) d'une branche : sa fiche apparaît au-dessus ou en dessous
  const info = el.querySelector(".info-b"), cadre = el.querySelector(".arbre-cadre");
  let minuteurInfo = 0, survolee = null;
  const cacher = () => { info.hidden = true; if (survolee) survolee.classList.remove("survol"); survolee = null; };
  const plusTard = () => { clearTimeout(minuteurInfo); minuteurInfo = setTimeout(cacher, 280); };
  const montrer = (z) => {
    clearTimeout(minuteurInfo);
    const r = rel[+z.dataset.i], t = r.b.tache, st = t ? t.statut : "";
    const meta = [r.b.devant != null ? `${r.b.devant} commit${r.b.devant > 1 ? "s" : ""}` : "", r.b.derriere ? `main a avancé de ${r.b.derriere}` : "", depuisQuand(r.b.date)].filter(Boolean).join(" · ");
    const tourne = ["creee", "en_cours", "en_attente_creneau"].includes(st), arretee = ["bloquee", "interrompue"].includes(st);
    const boutons = t ? [`<button class="btn principal petit" data-voir-tache="${esc(t.id)}">Voir la tâche</button>`,
      tourne ? `<button class="btn petit" data-rapide="stop" data-tid="${esc(t.id)}" title="Arrête l'agent ; Reprendre le relance là où il en était">Stop</button>` : "",
      arretee ? `<button class="btn petit" data-rapide="reprendre" data-tid="${esc(t.id)}">Reprendre</button>` : "",
      tourne || A_VALIDER.includes(st) ? `<button class="btn discret petit danger" data-rapide="annuler" data-tid="${esc(t.id)}">Annuler</button>` : ""].join("") : "";
    info.className = `info-b ${r.teinte}`;
    info.innerHTML = `<b>${esc(t ? (sansProjet(court(t.titre, 90), []) || "Tâche") : r.b.nom)}</b><span class="etat-b">${esc(r.lib)}</span><small>${esc(meta)}</small>${boutons ? `<div class="boutons-info">${boutons}</div>` : ""}`;
    info.hidden = false;
    const zc = z.getBoundingClientRect(), cc = cadre.getBoundingClientRect();
    info.style.left = Math.min(Math.max(0, zc.left - cc.left + zc.width / 2 - info.offsetWidth / 2), cc.width - info.offsetWidth) + "px";
    info.style.top = (r.cote > 0 ? zc.top - cc.top - info.offsetHeight - 6 : zc.bottom - cc.top + 6) + "px";   // côté main : ne cache pas les boutons
    if (survolee) survolee.classList.remove("survol");
    survolee = el.querySelector(`.branche-svg[data-i="${z.dataset.i}"]`); if (survolee) survolee.classList.add("survol");
  };
  info.onmouseenter = () => clearTimeout(minuteurInfo);
  info.onmouseleave = plusTard;
  info.onclick = (e) => { if (e.target.closest("button")) setTimeout(cacher, 50); };
  const tactile = matchMedia("(hover: none)").matches;      // téléphone : un toucher ouvre la fiche (pas de survol)
  el.querySelectorAll(".zone-b").forEach((z) => {
    z.onmouseenter = z.onfocus = () => { if (!tactile) montrer(z); };
    z.onmouseleave = z.onblur = () => { if (!tactile) plusTard(); };
    z.onkeydown = (e) => { if (e.key === "Enter") z.click(); };
    if (tactile) z.onclick = (e) => { e.stopPropagation(); montrer(z); };
  });
  if (tactile) cadre.onclick = (e) => { if (!e.target.closest(".info-b,.zone-b")) cacher(); };
  const defile = el.querySelector(".arbre-defile");
  if (defile) {
    defile.scrollLeft = defile.scrollWidth;                 // la flèche (le plus récent dans main) visible
    let tir = null;                                         // glisser à la souris pour faire défiler l'arbre
    defile.onpointerdown = (e) => { if (e.button || e.target.closest("button,.zone-b")) return; tir = { x: e.clientX, g: defile.scrollLeft }; defile.classList.add("tire"); };
    defile.onpointermove = (e) => { if (tir) defile.scrollLeft = tir.g - (e.clientX - tir.x); };
    defile.onpointerup = defile.onpointerleave = () => { tir = null; defile.classList.remove("tire"); };
    defile.onscroll = cacher;
  }
}
let minuteurArbre = 0, arbreD = null;
addEventListener("resize", () => { clearTimeout(minuteurArbre); minuteurArbre = setTimeout(() => { if (arbreD && blocCourant === "branches") grapheBranches(...arbreD); }, 200); });
/* Commit en un clic : fichiers cochés (les très gros décochés d'office), message rempli tout seul si vide */
async function blocCommit(d) {
  if (!d.modifies.length) { GB("git-fichiers", '<p class="vide">Rien à commiter : ton dossier est propre.</p>'); return; }
  let info;
  try { info = await api(`/api/git/${encodeURIComponent(depotG)}/a-commiter`); } catch (e) { GB("git-fichiers", `<div class="alerte">${esc(e.message)}</div>`); return; }
  const f = info.fichiers;
  const ligne = (x, i) => `<label class="ligne-commit${x.raison ? " exclu" : ""}"><input type="checkbox" data-i="${i}" ${x.coche ? "checked" : ""}>
      <span class="etat-f">${esc(x.etat)}</span><span class="chemin-f">${esc(x.chemin)}</span>${x.raison ? `<small class="warn">${esc(x.raison)}</small>` : ""}</label>`;
  GB("git-fichiers", `<div class="commit-bloc"><p class="aide-commit">${f.length} fichier${f.length > 1 ? "s" : ""} pas encore enregistré${f.length > 1 ? "s" : ""} dans <b>${esc(info.branche)}</b>. Tant qu'ils ne sont pas commités, aucune tâche ne peut être fusionnée.</p>
      <div class="liste-commit">${f.map(ligne).join("")}</div>
      <div class="actions-git"><input id="commit-msg" class="champ" placeholder="Message (facultatif : rempli tout seul)" maxlength="200">
        <button class="btn principal" id="commit-ok">Commit</button><span id="commit-info" class="discret"></span></div>
      <small class="discret">Commit local seulement : rien n'est envoyé sur GitHub (bouton « Pousser » pour ça).</small></div>`);
  const compte = () => { const n = $$("#g-git-fichiers input[data-i]:checked").length; $("#commit-ok").textContent = n ? `Commit (${n})` : "Commit"; $("#commit-ok").disabled = !n; };
  $$("#g-git-fichiers input[data-i]").forEach((c) => (c.onchange = compte)); compte();
  $("#commit-ok").onclick = async () => {
    const choisis = [...$$("#g-git-fichiers input[data-i]:checked")].map((c) => f[+c.dataset.i].chemin);
    $("#commit-ok").disabled = true; $("#commit-info").textContent = "Commit…";
    try { const r = await api("/api/git/commit", { cible: depotG, fichiers: choisis, message: $("#commit-msg").value }); $("#commit-info").textContent = r.message; derniereVue = ""; detailGit(); ligneGit(depotG); }
    catch (e) { $("#commit-info").textContent = e.message; $("#commit-ok").disabled = false; }
  };
}
/* En direct : ce que fait l'agent, fichiers touchés, applications ouvertes — mis à jour toutes les 4 s pendant la tâche */
let minuteurDirect = null;
async function activiteTache(tid, actif) {
  clearTimeout(minuteurDirect);
  const el = $("#direct-tache");
  if (!el || selection !== tid) return;
  let a;
  try { a = await api(`/api/taches/${tid}/activite`); } catch { return; }
  if (selection !== tid || !$("#direct-tache")) return;
  const heure = (iso) => { try { return new Date(iso).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" }); } catch { return ""; } };
  const actions = a.actions.length ? `<ul class="direct-liste">${a.actions.map((x, i) => `<li class="${i === 0 && actif ? "maintenant" : ""}${x.genre === "refus" ? " bad" : ""}"><span class="heure">${esc(heure(x.heure))}</span>${esc(x.texte)}${x.fois > 1 ? ` <small class="discret">×${x.fois}</small>` : ""}</li>`).join("")}</ul>`
    : `<p class="discret">${actif ? "Il lit le projet et prépare son travail…" : "Aucune action notée."}</p>`;
  const nomF = (c) => c.split("/").pop();
  const fichiers = a.fichiers.length ? `<ul class="direct-liste">${a.fichiers.slice(0, 12).map((f) => `<li title="${esc(f.chemin)}"><span class="etat-f ${f.etat === "nouveau" ? "ok" : f.etat === "supprimé" ? "bad" : "warn"}">${esc(f.etat)}</span>${esc(nomF(f.chemin))}</li>`).join("")}${a.fichiers.length > 12 ? `<li class="discret">… et ${a.fichiers.length - 12} autres</li>` : ""}</ul>`
    : '<p class="discret">Aucun fichier modifié pour l\'instant.</p>';
  const COUL = { "ouvert": "ok", "en cours": "info", "en arrière-plan": "info", "fermé": "bad" };
  const applis = a.applications.length ? `<ul class="direct-liste">${a.applications.map((x) => `<li><b>${esc(x.nom)}</b> — <span class="${COUL[x.statut] || ""}">${esc(x.statut)}</span></li>`).join("")}</ul>`
    : '<p class="discret">Aucune application ouverte par l\'agent.</p>';
  // tâche finie : « Changements » montre déjà les fichiers ; ses dernières actions seulement s'il y en a
  el.innerHTML = actif ? `<div class="direct-grille">
      <div><p class="sous-titre-g">Ce qu'il fait maintenant</p>${actions}</div>
      <div><p class="sous-titre-g">Fichiers touchés${a.fichiers.length ? ` (${a.fichiers.length})` : ""}</p>${fichiers}</div>
      <div><p class="sous-titre-g">Applications</p>${applis}</div></div>`
    : a.actions.length ? `<div class="direct-grille"><div><p class="sous-titre-g">Ses dernières actions</p>${actions}</div></div>` : "";
  el.hidden = !el.innerHTML;
  if (actif) minuteurDirect = setTimeout(() => activiteTache(tid, true), 2500);
}
let minuteurGit = null;
function suivreGit() { clearTimeout(minuteurGit); minuteurGit = setTimeout(() => { if (vue === "projets" && blocCourant === "branches") { detailGit(); ligneGit(projetCourant); } }, 2500); }

/* --- Skills et documents : une seule recherche, un seul lecteur */
let docs = [];
const estSkill = (g) => /skill/i.test(g);
function listeDocs(groupes, filtre) {
  const f = (filtre || "").toLowerCase();
  return groupes.map((g) => {
    const fichiers = g.fichiers.filter((x) => !f || (x.titre + " " + x.chemin).toLowerCase().includes(f));
    if (!fichiers.length) return "";
    let sous = null;
    const items = fichiers.map((x) => (x.sous_groupe && x.sous_groupe !== sous ? `<div class="sous">${esc((sous = x.sous_groupe))}</div>` : "")
      + `<div class="doc" data-c="${esc(x.chemin)}" tabindex="0">${esc(x.titre)}<small>${esc(x.chemin)}</small></div>`).join("");
    return `<details class="pli" ${f ? "open" : ""}><summary>${esc(g.groupe)} · ${fichiers.length}</summary>${items}</details>`;
  }).join("") || '<p class="vide">Rien ne correspond.</p>';
}
async function gDocs() {
  docs = await api("/api/documents");
  const groupes = [...docs.filter((g) => estSkill(g.groupe)), ...docs.filter((g) => !estSkill(g.groupe))];
  GB("docs", `<p class="discret aide-g">Tous les agents reçoivent les skills, quel que soit le modèle : Claude Code et Codex par leurs copies (tenues à jour seules, au lancement et avant chaque tâche si une skill a changé), les autres modèles directement. <button class="lien" id="g-sync">Vérifier maintenant</button> · <button class="lien" id="g-importer" title="Copie dans le studio les skills et instructions de tes dossiers Claude Code et Codex ; rien n'est écrasé, tes originaux ne sont pas touchés">Reprendre mes skills du PC</button> <span id="g-sync-msg" class="discret"></span></p>
    <p class="discret aide-g">Dans tes propres sessions : Claude Code <code>/studio-nom</code> · Codex <code>$studio-nom</code>.</p>
    <div class="actions dossiers-g">${[["Skills", "Skills"], ["Regles", "Règles"], ["Livrables", "Livrables"], ["Taches", "Tâches"], ["Sauvegardes", "Sauvegardes"]].map(([c, t]) => `<button class="btn discret" data-ouvrir-dossier="${c}" title="Ouvrir le dossier ${t} dans l'Explorateur">${t}</button>`).join("")}</div>
    <p class="discret aide-g">Ici : lire et modifier les fichiers. Ajouter ou retirer des skills : <button class="lien" id="g-vers-ext">Extensions</button>.</p>
    <input class="recherche" id="g-filtre" placeholder="Chercher un skill ou un document…"><div id="g-liste" class="defile-g court">${listeDocs(groupes, "")}</div>`);
  $("#g-vers-ext").onclick = () => { persoOnglet = "skill"; montrer("perso"); };
  $$("[data-ouvrir-dossier]").forEach((b) => (b.onclick = () => ouvrir(b.dataset.ouvrirDossier)));
  const brancher = () => $$("#g-liste .doc").forEach((d) => (d.onclick = d.onkeydown = async (ev) => {
    if (ev.type === "keydown" && ev.key !== "Enter") return;
    const r = await api(`/api/document?chemin=${encodeURIComponent(d.dataset.c)}`);
    $$("#g-liste .doc.sel").forEach((x) => x.classList.remove("sel")); d.classList.add("sel");
    $("#g-lecteur").innerHTML = `<div class="actions" style="margin:0 0 6px;justify-content:space-between"><small>${esc(d.dataset.c)}</small><span><button class="btn" id="g-mod">Modifier</button> <button class="btn discret" id="g-fermer">Fermer</button></span></div>
      ${/\.md$/.test(d.dataset.c) ? md(r.texte) : `<pre>${esc(r.texte)}</pre>`}`;
    $("#g-mod").onclick = () => ouvrir(d.dataset.c);
    $("#g-fermer").onclick = () => { d.classList.remove("sel"); $("#g-lecteur").innerHTML = '<p class="vide">Clique un skill ou un document pour le lire ici.</p>'; };
  }));
  $("#g-filtre").oninput = () => { $("#g-liste").innerHTML = listeDocs(groupes, $("#g-filtre").value); brancher(); };
  brancher();
  api("/api/skills/conflits").then((l) => {
    if (!l.length || !$("#g-docs")) return;
    $("#g-docs").insertAdjacentHTML("afterbegin", `<div class="alerte" id="g-conflits"><b>Modifiés dans tes dossiers, hors du studio</b>${l.map((x) =>
      `<div class="reglage"><span>${x.genre === "skill" ? "Skill" : "Instructions"} <b>${esc(x.nom)}</b>${x.deux_cotes ? " · modifiée aussi dans le studio" : ""}<br><small class="discret">${esc(x.origine)}</small></span><span><button class="btn discret petit" data-conflit="${esc(x.id)}" data-choix="original">Mettre à jour dans le studio</button><button class="btn discret petit" data-conflit="${esc(x.id)}" data-choix="studio">Garder la version du studio</button></span></div>`).join("")}</div>`);
    $$("#g-conflits [data-conflit]").forEach((b) => (b.onclick = async () => {
      try { bulleInfo((await api("/api/skills/conflit", { nom: b.dataset.conflit, choix: b.dataset.choix })).message); gDocs(); } catch (e) { alert(e.message); }
    }));
  }).catch(() => {});
  $("#g-importer").onclick = async () => {
    $("#g-sync-msg").textContent = "Copie…";
    try { const r = await api("/api/skills/importer", {});
      $("#g-sync-msg").textContent = r.skills.length || r.instructions.length ? `Copié : ${[...r.skills, ...r.instructions].join(", ")}.` : "Rien de nouveau à reprendre.";
      if (r.skills.length) gDocs(); }
    catch (e) { $("#g-sync-msg").textContent = e.message; }
  };
  $("#g-sync").onclick = async () => {
    $("#g-sync-msg").textContent = "Synchronisation…";
    try { const r = await api("/api/skills/synchroniser", {}); $("#g-sync-msg").textContent = r.rapport.join(" · ") === "Déjà à jour." ? "Tout est à jour." : r.rapport.join(" · "); }
    catch (e) { $("#g-sync-msg").textContent = e.message; }
  };
}

/* ================================================================ état, badge, notifications, fermeture */
let dejaNotifiees = null;
async function majBadge() {
  try {
    const t = await api("/api/taches");
    const av = t.filter((x) => A_VALIDER.includes(x.status));
    $("#nb-valider").hidden = !av.length; $("#nb-valider").textContent = av.length;
    $("#mob-badge").hidden = !av.length; $("#mob-badge").textContent = av.length;             // téléphone : onglet Travail
    const ids = new Set(av.map((x) => x.id));
    if (dejaNotifiees && "Notification" in window && Notification.permission === "granted") {
      av.filter((x) => !dejaNotifiees.has(x.id)).forEach((x) => new Notification("Super AI Agent Pro Station Max 2000", { body: `À valider : ${nomCible(x.target)} — ${(x.request || "").slice(0, 80)}`, icon: "/favicon.ico" }));
    }
    dejaNotifiees = ids;
  } catch (e) { /* facultatif */ }
}
async function chargerEtat() {
  try {
    const e = await api("/api/etat?leger=1");
    const ok = e.memoire.etat === "OK";
    $("#etat-memoire").hidden = ok;                    // rien en haut quand tout va bien ; un avertissement sinon
    if (!ok) $("#etat-memoire").textContent = `⚠ Mémoire : ${e.memoire.etat}`;
  } catch (err) { /* le studio ne répond pas : la vérification de présence s'en charge */ }
}
/* Onglet Fichiers : images, planches, textes et autres fichiers créés par les agents pour ce projet */
let fichiersListe = [], filtreF = "", rechercheF = "", modeComparer = false, choixComparer = [];
const OU_F = { copie: ["en attente de fusion", "attente"], projet: ["dans le projet", ""], capture: ["capture", ""], "": ["introuvable", "attente"] };
const urlF = (f) => `/api/fichiers/voir?tid=${encodeURIComponent(f.tid)}&chemin=${encodeURIComponent(f.chemin)}`;
async function fichiersProjet() {
  const cle = projetCourant;
  try { fichiersListe = await api(`/api/fichiers?cible=${encodeURIComponent(cle)}`); } catch (e) { $("#p-fichiers").innerHTML = `<div class="alerte">${esc(e.message)}</div>`; return; }
  if (projetCourant === cle) dessinerFichiers();
}
function dessinerFichiers() {
  const q = rechercheF.toLowerCase();
  const l = fichiersListe.filter((f) => (!filtreF || (filtreF === "ref" ? f.reference : f.genre === filtreF)) && (!q || `${f.nom} ${f.chemin} ${f.tache}`.toLowerCase().includes(q)));
  const n = (g) => fichiersListe.filter((f) => f.genre === g).length;
  const nRef = fichiersListe.filter((f) => f.reference).length;
  const chips = [["", `Tout (${fichiersListe.length})`], ...(nRef ? [["ref", `★ Références (${nRef})`]] : []), ["image", `Images (${n("image")})`], ["texte", `Textes (${n("texte")})`], ["autre", `Autres (${n("autre")})`]];
  const ou = (f) => `<span class="ou-f ${OU_F[f.ou][1]}">${OU_F[f.ou][0]}</span>`;
  const imgs = l.filter((f) => f.genre === "image"), autres = l.filter((f) => f.genre !== "image");
  $("#p-fichiers").innerHTML = `<div class="filtres-f"><div class="puces" id="f-genre"></div>
      <input class="champ" id="f-cherche" placeholder="Chercher (nom, tâche…)" value="${esc(rechercheF)}">
      <button class="btn discret" id="f-ranger" title="Lance l'archiviste : il déplace et renomme les fichiers des agents dans les bons dossiers, sans rien supprimer ; tu valides">Ranger le projet</button>
      ${imgsTotal() >= 2 ? `<button class="btn${modeComparer ? " principal" : " discret"}" id="f-comparer" title="Choisis deux images pour les comparer avec un curseur avant / après">${modeComparer ? `Comparer : choisis ${2 - choixComparer.length} image${choixComparer.length ? "" : "s"}` : "Comparer"}</button>` : ""}</div>
    ${!l.length ? `<p class="vide">${fichiersListe.length ? "Rien ne correspond." : "Aucun fichier créé par les agents pour ce projet pour l'instant."}</p>` : ""}
    ${imgs.length ? `<div class="grille-f">${imgs.map((f) => { const i = fichiersListe.indexOf(f); return `<div class="carte-f${choixComparer.includes(i) ? " choisie" : ""}" data-f="${i}" role="button" tabindex="0" title="${esc(f.chemin)}">${f.ou ? `<img src="${urlF(f)}" alt="${esc(f.nom)}" loading="lazy">` : ""}<button class="etoile${f.reference ? " oui" : ""}" data-etoile="${i}" title="${f.reference ? "Retirer des références" : "Marquer comme référence : le Superviseur la donnera aux agents"}" aria-label="Référence">${f.reference ? "★" : "☆"}</button><span class="infos"><b>${esc(f.nom)}</b>${esc(f.tache)}<br>${ou(f)}</span></div>`; }).join("")}</div>` : ""}
    ${autres.length ? `<p class="sous-titre-g sous-titre-f">Textes et autres</p><ul class="liste-f">${autres.map((f) => `<li data-f="${fichiersListe.indexOf(f)}" title="${esc(f.chemin)}"><b>${esc(f.nom)}</b><span class="discret">${esc(f.tache)}</span>${ou(f)}</li>`).join("")}</ul>` : ""}`;
  puces($("#f-genre"), chips, filtreF, (v) => { filtreF = v; dessinerFichiers(); });
  $("#f-cherche").oninput = (e) => { rechercheF = e.target.value; const pos = e.target.selectionStart; dessinerFichiers(); const c = $("#f-cherche"); c.focus(); c.setSelectionRange(pos, pos); };
  $$("#p-fichiers [data-f]").forEach((el) => {
    const ouvrirCarte = () => {
      const i = +el.dataset.f;
      if (!modeComparer) return voirFichier(fichiersListe[i]);
      choixComparer = choixComparer.includes(i) ? choixComparer.filter((x) => x !== i) : [...choixComparer, i].slice(-2);
      if (choixComparer.length === 2) { comparerImages(fichiersListe[choixComparer[0]], fichiersListe[choixComparer[1]]); modeComparer = false; choixComparer = []; }
      dessinerFichiers();
    };
    el.onclick = (e) => { if (!e.target.closest("[data-etoile]")) ouvrirCarte(); };
    el.onkeydown = (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); ouvrirCarte(); } };
  });
  $$("#p-fichiers [data-etoile]").forEach((b) => (b.onclick = async (e) => {
    e.stopPropagation();
    const f = fichiersListe[+b.dataset.etoile];
    try { await api("/api/fichiers/reference", { cible: projetCourant, tid: f.tid, chemin: f.chemin, oui: !f.reference }); f.reference = !f.reference; dessinerFichiers(); bulleInfo(f.reference ? "Référence : le Superviseur la donnera aux agents" : "Retirée des références"); }
    catch (er) { bulleInfo(er.message); }
  }));
  $("#f-ranger").onclick = async () => {
    if (!confirm("Lancer le rangement du projet ? L'archiviste déplace et renomme les fichiers produits par les agents (rien n'est supprimé), puis tu valides.")) return;
    try {
      const r = await api("/api/taches", { cible: projetCourant, role: "archiviste", titre: "Ranger les fichiers du projet", demande: RANGER_DEMANDE });
      selection = r.tid; derniereVue = ""; bulleInfo("Rangement lancé"); setTimeout(() => ouvrirProjet(projetCourant), 400);
    } catch (e) { bulleInfo(e.message); }
  };
  if ($("#f-comparer")) $("#f-comparer").onclick = () => { modeComparer = !modeComparer; choixComparer = []; dessinerFichiers(); };
}
const RANGER_DEMANDE = `Objectif : ranger les fichiers produits par les agents dans ce projet, pour que l'utilisateur retrouve tout facilement.
Où : tout le projet, en priorité les fichiers à la racine et dans les dossiers fourre-tout (captures/, references/, sources/, outputs/…).
Faire : déplacer chaque livrable dans le dossier prévu par le projet (voir CLAUDE.md / AGENTS.md ; images et planches dans Docs/art/<sujet>/, documents dans Docs/<sujet>/), renommer les noms illisibles (identifiant de tâche, longue suite de chiffres) en noms clairs, mettre à jour les liens Markdown.
Ne pas faire : ne rien supprimer (liste les copies inutiles dans ton compte rendu), ne pas toucher au code ni aux assets du moteur.
Compte rendu : un tableau avant → après, puis la liste des copies que l'utilisateur peut retirer.`;
const imgsTotal = () => fichiersListe.filter((f) => f.genre === "image" && f.ou).length;
function comparerImages(a, b) {                            // curseur avant / après : glisser pour révéler la seconde image
  const v = $("#visionneuse"), c = $("#v-contenu");
  $("#v-titre").textContent = `${a.nom}  ⟷  ${b.nom}`;
  c.innerHTML = `<div class="comparer"><img src="${urlF(a)}" alt="${esc(a.nom)}"><div class="haut" style="clip-path:inset(0 0 0 50%)"><img src="${urlF(b)}" alt="${esc(b.nom)}"></div>
    <div class="trait" style="left:50%"></div><span class="nom-g">${esc(a.nom)}</span><span class="nom-d">${esc(b.nom)}</span>
    <input type="range" min="0" max="100" value="50" aria-label="Position du curseur de comparaison"></div>`;
  const r = c.querySelector("input"), haut = c.querySelector(".haut"), trait = c.querySelector(".trait");
  r.oninput = () => { haut.style.clipPath = `inset(0 0 0 ${r.value}%)`; trait.style.left = r.value + "%"; };
  ["v-ouvrir", "v-dossier", "v-tache"].forEach((id) => ($("#" + id).hidden = true));
  v.hidden = false; r.focus();
}
async function voirFichier(f) {
  ["v-ouvrir", "v-dossier", "v-tache"].forEach((id) => ($("#" + id).hidden = false));
  const v = $("#visionneuse"), c = $("#v-contenu");
  $("#v-titre").textContent = `${f.nom} · ${f.tache}`;
  c.innerHTML = '<p class="vide">…</p>'; v.hidden = false; $("#v-fermer").focus();
  if (f.genre === "image") c.innerHTML = `<img src="${urlF(f)}" alt="${esc(f.nom)}">`;
  else {
    try {
      const r = await fetch(urlF(f));
      if (!r.ok) throw new Error((await r.json().catch(() => ({}))).erreur || r.status);
      const t = await r.text();
      c.innerHTML = `<div class="texte-v">${/\.md$/i.test(f.nom) ? md(t) : `<pre>${esc(t)}</pre>`}</div>`;
    } catch (e) { c.innerHTML = `<p class="vide">${esc(e.message)}</p>`; }
  }
  const ouvrirF = (dossier) => api("/api/fichiers/ouvrir", { tid: f.tid, chemin: f.chemin, dossier }).catch((e) => bulleInfo(e.message));
  $("#v-ouvrir").onclick = () => ouvrirF(false);
  $("#v-dossier").onclick = () => ouvrirF(true);
  $("#v-tache").onclick = () => { v.hidden = true; selection = f.tid; derniereVue = ""; afficher(); voirDetail(); };
}
$("#v-fermer").onclick = () => ($("#visionneuse").hidden = true);
document.addEventListener("keydown", (e) => { if (e.key === "Escape" && !$("#visionneuse").hidden) $("#visionneuse").hidden = true; });

/* Téléphone : barre du bas pour passer du bloc de travail au Superviseur (le choix est gardé) */
function vueMobile(v) {
  document.body.dataset.mob = v;
  $$("#barre-mobile button").forEach((b) => b.classList.toggle("actif", b.dataset.mob === v));
  try { localStorage.setItem("vue-mobile", v); } catch {}
  if (v === "sup") { const f = $("#fil"); if (f) f.scrollTop = f.scrollHeight; }
}
$("#barre-mobile").onclick = (e) => { const b = e.target.closest("button[data-mob]"); if (b) vueMobile(b.dataset.mob); };
vueMobile((() => { try { return localStorage.getItem("vue-mobile") || "travail"; } catch { return "travail"; } })());
function ouvrirTacheNotif(tid) {
  if (!tid) return;
  const lien = document.createElement("button"); lien.dataset.voir = tid; lien.hidden = true;
  document.body.appendChild(lien); lien.click(); lien.remove();
}
if ("serviceWorker" in navigator) navigator.serviceWorker.addEventListener("message", (e) => e.data && ouvrirTacheNotif(e.data.ouvrirTache));
{ const t = new URLSearchParams(location.search).get("tache"); if (t) { history.replaceState(null, "", "/"); setTimeout(() => ouvrirTacheNotif(t), 1200); } }
if ("serviceWorker" in navigator && location.protocol === "https:") navigator.serviceWorker.register("/sw.js").catch(() => {});

/* Taille de la fenêtre : notée à chaque changement, reprise au prochain lancement (plein écran, agrandie ou taille exacte) */
let minuteurFenetre = 0;
function noterFenetre() {
  clearTimeout(minuteurFenetre);
  minuteurFenetre = setTimeout(() => {
    const plein = !!document.fullscreenElement || (outerWidth >= screen.width && outerHeight >= screen.height);
    const agrandie = !plein && outerWidth >= screen.availWidth - 2 && outerHeight >= screen.availHeight - 2;
    fetch("/api/fenetre", { method: "POST", keepalive: true, headers: { "Content-Type": "application/json", "X-Studio": "1" },
      body: JSON.stringify({ plein_ecran: plein, agrandie, x: screenX, y: screenY, l: outerWidth, h: outerHeight }) }).catch(() => {});
  }, 700);
}
addEventListener("resize", noterFenetre);          // agrandir, plein écran, redimensionner : une seule requête par changement

/* Présence et reconnexion : si le PC ne répond plus (studio fermé, réseau coupé), un bandeau l'indique et la page se
   recharge toute seule dès qu'il revient. Au retour sur l'appli (téléphone, onglet), tout est rafraîchi tout de suite. */
let horsLigne = false, sessionInfo = {};
async function presence() {
  try {
    await api("/api/presence", {});
    if (horsLigne) location.reload();
  } catch (e) {
    if (e.code === 403) {
      if (sessionInfo.distant) { location.reload(); return; }       // téléphone révoqué : page du code
      document.body.innerHTML = '<div class="ferme"><h1>Game over</h1><p class="vide">Session terminée. Relance le raccourci du bureau.</p></div>';
      return;
    }
    if (!horsLigne && (e instanceof TypeError || e.code >= 502)) {
      horsLigne = true;
      const b = document.createElement("div");
      b.id = "hors-ligne"; b.setAttribute("role", "status");
      b.textContent = sessionInfo.distant ? "Studio fermé sur le PC ? Reconnexion…" : "Le studio ne répond pas. Reconnexion…";
      document.body.appendChild(b);
    }
  }
}
document.addEventListener("visibilitychange", () => {
  if (document.visibilityState !== "visible") return;
  presence(); chargerEtat(); majTravaux();
  if (vue === "projets") { chargerConversation(false); if (!projetCourant) resumeTravail(); }
});
api("/api/session").then((s) => {
  sessionInfo = s || {};
  if (sessionInfo.nom && sessionInfo.nom !== nomUtilisateur) { nomUtilisateur = sessionInfo.nom; chargerConversation(false); }
  api("/api/ia").then((d) => { const avant = iaEtat; iaEtat = d; if (!avant || !!avant.actif !== !!d.actif) chargerConversation(false); }).catch(() => {});
  if (sessionInfo.distant) { $("#fermer-studio").style.display = "none"; document.body.classList.add("distant"); }   // depuis le téléphone, on ne pourrait plus le rouvrir
}).catch(() => {});
$("#fermer-studio").onclick = async () => {
  try { await api("/api/arreter", {}); }
  catch (e) {
    if (e.code !== 409 || !confirm("Un travail tourne encore. Fermer dès qu'il sera terminé ?")) return;
    await api("/api/arreter", { apres_travaux: true });
  }
  document.body.innerHTML = '<div class="ferme"><h1>See you next mission</h1><p class="vide">Tu peux fermer cette fenêtre.</p></div>';
  setTimeout(() => window.close(), 800);
};
document.addEventListener("click", () => { if ("Notification" in window && Notification.permission === "default") Notification.requestPermission(); }, { once: true });

api("/api/cibles").then((c) => { cibles = c; majBadge(); });
document.body.classList.add("fixe");
function choixListe(el, items, actif, cb) {
  el.innerHTML = items.map(([v, t]) => `<option value="${esc(v)}"${v === actif ? " selected" : ""}>${esc(t)}</option>`).join("");
  el.onchange = () => cb(el.value);
}
choixListe($("#sup-modele"), MODELES_SUP, modeleSup, (v) => garderSup("sup-modele", (modeleSup = v)));
choixListe($("#sup-effort"), EFFORTS, effortSup, (v) => garderSup("sup-effort", (effortSup = v)));
const PROFILS = [["rapide", "Rapide"], ["normal", "Normal"], ["performance", "Performance"]];
const AIDE_PROFIL = {
  rapide: "Plus vite, quotas ménagés : Opus → Sonnet, rédaction sur Haiku, effort un cran plus bas.",
  normal: "Le réglage optimisé de chaque agent (recommandé).",
  performance: "Plus de raisonnement : Sonnet → Opus (hors rédaction), effort un cran plus haut. Plus lent, consomme plus.",
};
function dessinerProfilProjet(cle, propre, defaut) {          // mode propre à chaque projet (Rapide / Normal / Performance)
  const actuel = propre || defaut || "normal";
  $("#p-profil").innerHTML = PROFILS.map(([v, t]) => `<button data-p="${v}" class="${v === actuel ? "sel" : ""}" aria-pressed="${v === actuel}">${t}</button>`).join("");
  $("#p-profil-aide").textContent = AIDE_PROFIL[actuel] || "";
  $$("#p-profil button").forEach((b) => (b.onclick = async () => {
    try { const r = await api("/api/profil", { cible: cle, profil: b.dataset.p }); dessinerProfilProjet(cle, r.profil, defaut); } catch (e) { alert(e.message); }
  }));
}
api("/api/ia").then((d) => { const sup = $("#sup-modele") && $("#sup-modele").closest(".choix-sup"); if (sup) sup.hidden = !!d.actif && d.actif !== "claude-code"; }).catch(() => {});
api("/api/choix").then((c) => {                          // modèles proposés : [choix] modeles_claude (studio.config.toml)
  MODELES = [["", "Auto"], ...c.modeles.map((m) => [m, nomModele(m)])];
  MODELES_SUP = [["", "Auto"], ...[...c.modeles].reverse().map((m) => [m, nomModele(m)])];
  choixListe($("#sup-modele"), MODELES_SUP, modeleSup, (v) => garderSup("sup-modele", (modeleSup = v)));
}).catch(() => {});
/* Rafraîchissements : rien de lourd quand la fenêtre est cachée (réduite, autre onglet) ; tout se remet à jour dès
   qu'elle revient. Seuls le badge et les notifications « à valider » continuent, plus lentement. */
const chaque = (ms, f) => setInterval(() => { if (!document.hidden) f(); }, ms);
let tic = 0;
majTravaux(); majAlertes();
setInterval(() => { if (!document.hidden && (travauxActifs() || ++tic % 3 === 0)) majTravaux(); }, 4000);   // 4 s pendant un travail, sinon 12 s
chaque(60000, majAlertes);
chaque(60000, () => { if (vue === "gestion") limitesAccueil(); });
chaque(8000, () => { if (vue === "projets") api("/api/projets").then((ps) => { projetsListe = ps; rendreOnglets(); rendreOngletsBloc(); }).catch(() => {}); });
ouvrirSuperviseur();                                      // à l'ouverture : toujours le Superviseur (ensuite, chaque page revient où tu l'avais laissée)
chargerEtat(); presence();
function rafraichir() {
  if (vue === "projets") chargerConversation(false);
  if (vue === "projets" && !projetCourant) resumeTravail();
  if (vue === "projets" && projetCourant) { api(`/api/projets/${encodeURIComponent(projetCourant)}`).then((p) => { listesTaches(p.taches); equipeProjet(p.equipe); }).catch(() => {}); if (selection) afficher(); }
  majBadge();
}
let ticCache = 0;
setInterval(() => { if (!document.hidden) rafraichir(); else if (++ticCache % 4 === 0) majBadge(); }, 4000);
document.addEventListener("visibilitychange", () => { if (!document.hidden) { rafraichir(); majTravaux(); } });

/* Ressources du PC dans l'en-tête : utile surtout avec les modèles locaux (mémoire vidéo occupée par Ollama). */
async function majSysteme() {
  if (sessionInfo.distant) return;                         // téléphone : c'est le PC qui compte, pas affiché ici
  let s;
  try { s = await api("/api/systeme"); } catch { return; }
  const el = $("#systeme");
  const jauge = (nom, pct, texte, titre) => texte == null ? "" : `<span class="m${pct >= 90 ? " max" : pct >= 75 ? " haut" : ""}" title="${esc(titre)}"><b>${nom}</b>${pct == null ? "" : `<span class="barre"><i style="width:${Math.min(100, pct)}%"></i></span>`}<span class="v">${texte}</span></span>`;
  const r = s.ram || {}, g = s.gpu || {};
  const vramPct = g.vram_total_go ? 100 * g.vram_go / g.vram_total_go : null;
  const ia = (s.ollama || []).map((m) => `${m.nom} (${m.vram_go} Go)`).join(", ");
  el.innerHTML = jauge("CPU", s.cpu ?? 0, s.cpu == null ? "…" : `${Math.round(s.cpu)} %`, `Processeur : ${s.coeurs || "?"} cœurs`)
    + jauge("RAM", r.total_go ? 100 * r.utilise_go / r.total_go : null, r.total_go ? `${r.utilise_go}/${Math.round(r.total_go)} Go` : null, "Mémoire vive utilisée")
    + jauge("GPU", g.util ?? null, g.util == null ? null : `${Math.round(g.util)} %`, `${g.nom || "Carte graphique"}${ia ? " · IA locale chargée : " + ia : ""}`)
    + jauge("VRAM", vramPct, g.vram_go == null ? null : g.vram_total_go ? `${g.vram_go}/${Math.round(g.vram_total_go)} Go` : `${g.vram_go} Go`,
      `Mémoire de la carte graphique${ia ? " · IA locale : " + ia : ""}`);
  el.hidden = !el.innerHTML;
}
majSysteme();
chaque(3000, majSysteme);
setInterval(presence, 15000);
setInterval(() => $$(".chrono").forEach((el) => { el.textContent = duree((+el.dataset.base || 0) + secondes(el.dataset.depuis)); }), 1000);

/* Taille de la fenêtre : pas de zoom ; seuls les blocs s'adaptent (hauteur de l'en-tête pour remplir la fenêtre). */
function ajusterEchelle() {
  const h = document.querySelector("header");
  if (h) document.documentElement.style.setProperty("--entete", h.offsetHeight + "px");
}
window.addEventListener("resize", ajusterEchelle);
ajusterEchelle();
chaque(30000, chargerEtat);

/* Onde lumineuse au clic sur tout ce qui se clique (désactivée si l'animation est réduite dans Windows) */
const CLIQUABLES = ".btn,.puce,.projet,.liste li,.doc,.agent-g,.lien-g";
document.addEventListener("pointerdown", (e) => {
  if (matchMedia("(prefers-reduced-motion: reduce)").matches) return;
  const el = e.target.closest(CLIQUABLES);
  if (!el || el.disabled) return;
  const r = el.getBoundingClientRect(), o = document.createElement("span");
  o.className = "onde"; o.style.left = `${e.clientX - r.left}px`; o.style.top = `${e.clientY - r.top}px`;
  if (getComputedStyle(el).position === "static") el.style.position = "relative";
  if (getComputedStyle(el).overflow === "visible") el.style.overflow = "hidden";        // l'onde ne déborde jamais
  el.appendChild(o); o.addEventListener("animationend", () => o.remove());
  el.classList.remove("flash"); void el.offsetWidth; el.classList.add("flash");
  setTimeout(() => el.classList.remove("flash"), 500);
}, { passive: true });

/* ================================================================ EXTENSIONS
   Skills et connecteurs (serveurs MCP et logiciels du PC) : Découvrir, Connecteurs, Skills, Installé. Les domaines
   (jeu vidéo, 3D…) sont les catégories : aucun élément n'apparaît deux fois sur une même page. */
const ICONES = {
  jeu: '<path d="M6 11h4M8 9v4M15 12h.01M18 10h.01"/><rect x="2" y="6" width="20" height="12" rx="6"/>',
  "3d": '<path d="M12 2 3 7v10l9 5 9-5V7z"/><path d="m3 7 9 5 9-5M12 12v10"/>',
  design: '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-5-5L5 21"/>',
  code: '<path d="m16 18 6-6-6-6M8 6l-6 6 6 6"/>',
  web: '<circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a15 15 0 0 1 0 20M12 2a15 15 0 0 0 0 20"/>',
  documents: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M8 13h8M8 17h5"/>',
  audio: '<path d="M2 12h2M6 8v8M10 4v16M14 7v10M18 10v4M22 12h0"/>',
  "outils-ia": '<path d="M12 3v3M12 18v3M3 12h3M18 12h3M5.6 5.6l2.1 2.1M16.3 16.3l2.1 2.1M5.6 18.4l2.1-2.1M16.3 7.7l2.1-2.1"/><circle cx="12" cy="12" r="3"/>',
  donnees: '<path d="M3 3v18h18"/><path d="M7 15l4-4 3 3 5-6"/>',
  son: '<path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/>',
  video: '<rect x="2" y="5" width="15" height="14" rx="2"/><path d="m17 10 5-3v10l-5-3z"/>',
  ecriture: '<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/>',
  marketing: '<path d="m3 11 18-8v18L3 13z"/><path d="M11.6 16.8a3 3 0 1 1-5.8-1.6"/>',
  recherche: '<circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/>',
  perso: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
  pack: '<path d="m12 2 10 5-10 5L2 7z"/><path d="m2 12 10 5 10-5M2 17l10 5 10-5"/>',
};
const icone = (k) => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONES[k] || ICONES.code}</svg>`;
const TYPES_P = { skill: "Skill", mcp: "Serveur MCP", logiciel: "Logiciel" };
const TAG_P = { skill: "SKILL", mcp: "MCP", logiciel: "LOGICIEL" };
let biblio = null, biblioQuand = 0, persoOnglet = "decouvrir", persoCherche = "", persoCat = "", persoTri = "pertinence";
try { persoOnglet = localStorage.getItem("onglet-extensions") || "decouvrir"; } catch (e) { /* stockage indisponible */ }
async function afficherPerso(recharger = true) {
  if (recharger || !biblio) {
    try { biblio = await api("/api/bibliotheque"); biblioQuand = Date.now();
      if (biblio.elements.some((e) => e.categorie === "perso")) biblio.categories = { ...biblio.categories, perso: "Déjà dans ton studio" }; } catch (e) { $("#perso-corps").innerHTML = `<div class="alerte">${esc(e.message)}</div>`; return; }
  }
  const sel = $("#perso-cat");
  if (!sel.dataset.rempli) { sel.innerHTML = `<option value="">Toutes les catégories</option>` + Object.entries(biblio.categories || {}).map(([k, v]) => `<option value="${esc(k)}">${esc(v)}</option>`).join(""); sel.dataset.rempli = "1"; }
  sel.value = persoCat;
  if (!["decouvrir", "connecteur", "skill", "installe"].includes(persoOnglet)) persoOnglet = "decouvrir";
  $$("#perso-onglets [data-o]").forEach((b) => b.setAttribute("aria-selected", String(b.dataset.o === persoOnglet)));
  dessinerPerso();
}
const sansAccent = (t) => t.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
function persoFiltre() {
  const q = sansAccent(persoCherche.trim());
  const ongletOk = (e) => persoOnglet === "connecteur" ? ["mcp", "logiciel"].includes(e.type) : persoOnglet === "skill" ? e.type === "skill" : persoOnglet === "installe" ? e.installe : true;
  let l = biblio.elements.filter((e) => e.type !== "pack" && ongletOk(e) && (!persoCat || e.categorie === persoCat)        // domaines : vus par les catégories
    && (!q || sansAccent(`${e.nom} ${e.description} ${e.auteur}`).includes(q)));
  if (persoTri === "nom") l = [...l].sort((a, b) => a.nom.localeCompare(b.nom, "fr"));
  if (persoTri === "nouveau") l = [...l].sort((a, b) => (b.nouveau ? 1 : 0) - (a.nouveau ? 1 : 0));
  return l;
}
function cartePerso(e, avecCat) {
  const essai = e.installe && e.essai ? `<button data-essayer="${esc(e.id)}">Essayer</button>` : "";
  const action = e.installe ? `<button class="plus ok" data-fiche="${esc(e.id)}" title="Installé" aria-label="Installé">✓</button>` : `<button class="plus" data-installer-p="${esc(e.id)}" title="Ajouter" aria-label="Ajouter ${esc(e.nom)}">＋</button>`;
  const note = e.type === "mcp" && !e.installe && (e.manque || []).length ? ` · il faut ${esc(e.manque.join(", "))}`
    : e.type === "logiciel" && !e.installe ? (e.trouve ? " · trouvé sur le PC" : " · pas sur le PC") : "";
  const cat = avecCat && biblio.categories[e.categorie] ? ` · ${esc(biblio.categories[e.categorie])}` : "";
  return `<div class="carte-p${e.installe ? " installe" : ""}" data-fiche="${esc(e.id)}"><span class="ico">${icone(e.categorie)}</span>
    <span class="txt"><b>${esc(e.nom)}${e.verifie ? '<span class="verif" title="Source vérifiée">✔</span>' : ""}</b><span class="desc">${esc(e.description || "")}</span>
    <span class="meta"><span class="tag-p ${e.type}">${TAG_P[e.type] || ""}</span>par ${esc(e.auteur || "?")}${cat}${e.nouveau ? " · nouveau" : ""}${note}</span></span>
    <span class="acts">${essai}${action}</span></div>`;
}
function dessinerPerso() {
  const l = persoFiltre(), corps = $("#perso-corps");
  const grille = (items, avecCat) => `<div class="perso-grille">${items.map((e) => cartePerso(e, avecCat)).join("")}</div>`;
  const section = (titre, items, avecCat) => items.length ? `<div class="perso-section"><p class="titre">${esc(titre)} <span class="n">${items.length}</span></p></div>${grille(items, avecCat)}` : "";
  if (!l.length) {
    corps.innerHTML = `<p class="vide">${persoOnglet === "installe" && !persoCherche && !persoCat ? "Rien d'installé pour l'instant : va dans « Découvrir »." : "Rien ne correspond."}</p>`;
    return;
  }
  if (persoCherche || persoCat || persoTri !== "pertinence") { corps.innerHTML = section(`${l.length > 1 ? "Résultats" : "Résultat"}`, l, true); return; }
  if (persoOnglet === "installe") {
    corps.innerHTML = section("Skills", l.filter((e) => e.type === "skill"), true) + section("Connecteurs", l.filter((e) => e.type !== "skill"), true);
    return;
  }
  // Découvrir : d'abord ce qui sert à tes projets, puis chaque catégorie une seule fois (aucun élément en double)
  const pv = [];
  if (persoOnglet === "decouvrir") {
    for (const id of biblio.pour_vous || []) { const e = l.find((x) => x.id === id); if (e && !e.installe && pv.length < 6) pv.push(e); }
  }
  const reste = l.filter((e) => !pv.includes(e));
  const ordre = [...new Set([...pv.map((e) => e.categorie), ...Object.keys(biblio.categories)])];
  corps.innerHTML = section("Pour tes projets", pv, true)
    + ordre.map((k) => section(biblio.categories[k] || k, reste.filter((e) => e.categorie === k))).join("")
    + section("Autres", reste.filter((e) => !biblio.categories[e.categorie]));       // « Déjà dans ton studio » (skills du socle, tes ajouts) en dernier
}
function ficheElement(id) {
  const e = biblio.elements.find((x) => x.id === id);
  if (!e || e.type === "pack") return;
  const el = $("#perso-fiche-corps");
  const vars = e.type === "mcp" && !e.installe ? (e.variables || []).map((v) => `<label>${esc(v.libelle)}${v.aide ? ` <small>(${esc(v.aide)})</small>` : ""}</label><input data-var="${esc(v.nom)}" type="${v.secret ? "password" : "text"}" autocomplete="off">`).join("") : "";
  const avertir = e.type === "mcp" && (e.manque || []).length ? `<p class="warn">Il faut d'abord ${esc(e.manque.join(" et "))} sur le PC.</p>` : "";
  const mcpInfo = e.type === "mcp" ? `<p class="aide-g">Utilisé par les agents Claude Code de tes tâches (réglable par projet dans l'onglet Équipe). ${e.verifie ? "" : "Serveur de la communauté : vérifie qu'il te convient."} Le serveur se télécharge à sa première utilisation.</p>` : "";
  const logInfo = e.type === "logiciel" ? `<p class="aide-g">${e.installe ? "Déclaré aux agents." : e.trouve ? "Trouvé sur ce PC : un clic pour le déclarer aux agents." : `Pas trouvé sur ce PC. Le studio n'installe pas de logiciel : <a href="${esc(e.site)}" target="_blank" rel="noopener">site officiel</a>${e.winget ? ` ou dans PowerShell : <code>winget install --id ${esc(e.winget)} -e</code>` : ""}.`}</p>` : "";
  const chemin = e.type === "logiciel" && !e.installe && !e.trouve ? `<label>Chemin complet du programme, une fois installé</label><input data-var="chemin" placeholder="C:\\…\\programme.exe">` : "";
  const boutons = [`<button class="btn discret" data-fermer-fiche="1">Fermer</button>`];
  if (e.installe && e.type === "skill") boutons.unshift(`<a class="btn discret" href="/api/bibliotheque/exporter?id=${encodeURIComponent(e.id)}" download>Exporter (.zip)</a>`);
  if (e.installe && !e.socle) boutons.unshift(`<button class="btn discret danger" data-retirer-p="${esc(e.id)}" data-type="${esc(e.type)}">Retirer</button>`);
  if (e.installe && e.essai) boutons.push(`<button class="btn" data-essayer="${esc(e.id)}">Essayer</button>`);
  if (!e.installe) boutons.push(`<button class="btn principal" data-installer-p="${esc(e.id)}" data-depuis-fiche="1">Ajouter</button>`);
  el.innerHTML = `<div style="display:flex;gap:14px;align-items:center"><span class="ico-f">${icone(e.categorie)}</span>
      <div><h2>${esc(e.nom)}</h2><div class="meta"><span class="tag-p ${e.type}">${TAG_P[e.type]}</span>${esc(biblio.categories[e.categorie] || "")} · par ${esc(e.auteur || "?")}${e.verifie ? " · source vérifiée" : ""}${e.licence ? " · " + esc(e.licence) : ""}${e.taille ? ` · ${Math.max(1, Math.round(e.taille / 1024))} Ko` : ""}</div></div></div>
    <p>${esc(e.description || "")}</p>${e.essai ? `<p class="aide-g">Exemple : « ${esc(e.essai)} »</p>` : ""}${mcpInfo}${logInfo}${avertir}${vars}${chemin}
    <p class="warn" id="fiche-msg"></p><div class="bas">${boutons.join("")}</div>`;
  $("#perso-fiche").hidden = false;
}
async function installerPerso(id, depuisFiche) {
  const e = biblio.elements.find((x) => x.id === id);
  if (!e) return;
  if (!depuisFiche && ((e.type === "mcp" && (e.variables || []).length) || e.type === "logiciel" && !e.trouve)) return ficheElement(id);
  const valeurs = {};
  $$("#perso-fiche-corps [data-var]").forEach((i) => (valeurs[i.dataset.var] = i.value));
  if (e.type === "mcp" && !confirm(`Ajouter « ${e.nom} » pour tes agents ?\n${e.verifie ? "" : "Serveur de la communauté (non officiel).\n"}Son paquet se téléchargera à la première utilisation.`)) return;
  try {
    const r = await api("/api/bibliotheque/installer", { id, valeurs });
    bulleInfo(r.message || "Ajouté.");
    $("#perso-fiche").hidden = true;
    raccourcisCache = null;
    afficherPerso();
  } catch (err) { if (!$("#perso-fiche").hidden && $("#fiche-msg")) $("#fiche-msg").textContent = err.message; else { ficheElement(id); setTimeout(() => $("#fiche-msg") && ($("#fiche-msg").textContent = err.message), 50); } }
}
function essayerPerso(id) {
  const e = biblio.elements.find((x) => x.id === id);
  if (!e) return;
  $("#perso-fiche").hidden = true;
  montrer("projets");
  ouvrirSuperviseur();
  if (document.body.dataset.mob) vueMobile("sup");
  setTimeout(() => { const t = $("#message"); t.value = `${e.type === "skill" ? `Avec la skill « ${e.nom} » : ` : e.type === "mcp" ? `Avec ${e.nom} : ` : ""}${e.essai || ""}`; ajusterSaisie(); t.focus(); }, 400);
}
$("#perso-onglets").onclick = (ev) => { const b = ev.target.closest("[data-o]"); if (!b) return;
  persoOnglet = b.dataset.o; try { localStorage.setItem("onglet-extensions", persoOnglet); } catch (e) { /* idem */ } afficherPerso(false); };
$("#perso-cherche").oninput = (ev) => { persoCherche = ev.target.value; dessinerPerso(); };
$("#perso-cat").onchange = (ev) => { persoCat = ev.target.value; dessinerPerso(); };
$("#perso-tri").onchange = (ev) => { persoTri = ev.target.value; dessinerPerso(); };
$("#perso-ajouter").onclick = (ev) => { ev.stopPropagation(); $("#menu-perso").hidden = !$("#menu-perso").hidden; };
document.addEventListener("click", (ev) => { if (!ev.target.closest(".perso-ajouter")) $("#menu-perso").hidden = true; });
$("#menu-perso").onclick = (ev) => {
  const a = (ev.target.closest("[data-a]") || {}).dataset; if (!a || !a.a) return;
  $("#menu-perso").hidden = true;
  if (a.a === "importer") $("#perso-zip").click();
  if (a.a === "creer") { montrer("projets"); ouvrirSuperviseur(); if (document.body.dataset.mob) vueMobile("sup");
    setTimeout(() => { const t = $("#message"); t.value = "Crée une skill pour [décris ce que la skill doit faire et quand l'utiliser]. Utilise la skill « Créer une skill » si elle est installée, et range-la dans Skills."; ajusterSaisie(); t.focus(); t.setSelectionRange(t.value.indexOf("["), t.value.indexOf("]") + 1); }, 400); }
  if (a.a === "mcp") formulaireMcp();
  if (a.a === "logiciel") {
    $("#perso-fiche-corps").innerHTML = `<h2>Ajouter un logiciel du PC</h2><div class="meta">Les agents sauront qu'il existe et où il est (Godot, Krita, ffmpeg…).</div>
      <label>Nom</label><input id="lg-nom" placeholder="Krita"><label>Chemin complet du programme</label><input id="lg-chemin" placeholder="C:\\Program Files\\Krita (x64)\\bin\\krita.exe">
      <p class="warn" id="fiche-msg"></p><div class="bas"><button class="btn discret" data-fermer-fiche="1">Annuler</button><button class="btn principal" id="lg-ok">Ajouter</button></div>`;
    $("#perso-fiche").hidden = false;
    $("#lg-ok").onclick = async () => {
      try { await api("/api/connecteurs/ajouter", { nom: $("#lg-nom").value, chemin: $("#lg-chemin").value }); bulleInfo("Logiciel déclaré aux agents.");
        $("#perso-fiche").hidden = true; persoOnglet = "installe"; afficherPerso(); }
      catch (e) { $("#fiche-msg").textContent = e.message; }
    };
  }
};
$("#perso-zip").onchange = async (ev) => {
  const f = ev.target.files[0]; ev.target.value = "";
  if (!f) return;
  const envoyerZip = async (ok) => { const r = await fetch(`/api/bibliotheque/importer?confirmer=${ok ? 1 : 0}`, { method: "POST", headers: { "X-Studio": "1", "Content-Type": "application/zip" }, body: f });
    const j = await r.json().catch(() => ({})); if (!r.ok) throw new Error(j.erreur || "import refusé"); return j; };
  try {
    const a = await envoyerZip(false);
    $("#perso-fiche-corps").innerHTML = `<h2>Importer « ${esc(a.id)} »</h2><div class="meta">${a.fichiers} fichier(s) · skill venue d'ailleurs : relis-la avant de l'ajouter</div>
      ${a.notes.length ? `<p class="sous-titre-g">À vérifier</p><ul>${a.notes.map((n) => `<li class="warn">${esc(n)}</li>`).join("")}</ul>` : '<p class="ok">Rien de suspect relevé.</p>'}
      <p class="sous-titre-g">Début du SKILL.md</p><pre>${esc(a.extrait)}</pre><p class="warn" id="fiche-msg"></p>
      <div class="bas"><button class="btn discret" data-fermer-fiche="1">Annuler</button><button class="btn principal" id="zip-ok">Ajouter cette skill</button></div>`;
    $("#perso-fiche").hidden = false;
    $("#zip-ok").onclick = async () => { try { const r = await envoyerZip(true); bulleInfo(r.message); $("#perso-fiche").hidden = true; persoOnglet = "installe"; afficherPerso(); } catch (e) { $("#fiche-msg").textContent = e.message; } };
  } catch (e) { alert(e.message); }
};
function formulaireMcp() {
  $("#perso-fiche-corps").innerHTML = `<h2>Ajouter un serveur MCP</h2><div class="meta">Serveur pas relu par le studio : ajoute seulement ce que tu connais.</div>
    <label>Nom</label><input id="mp-nom" placeholder="mon-serveur">
    <label>Commande (serveur local)</label><input id="mp-cmd" placeholder="npx">
    <label>Arguments</label><input id="mp-args" placeholder="-y paquet-du-serveur@1.2.3">
    <label>…ou adresse (serveur distant)</label><input id="mp-url" placeholder="https://exemple.com/mcp">
    <p class="warn" id="fiche-msg"></p><div class="bas"><button class="btn discret" data-fermer-fiche="1">Annuler</button><button class="btn principal" id="mp-ok">Ajouter</button></div>`;
  $("#perso-fiche").hidden = false;
  $("#mp-ok").onclick = async () => {
    try { const r = await api("/api/bibliotheque/mcp-perso", { nom: $("#mp-nom").value, commande: $("#mp-cmd").value, arguments: $("#mp-args").value, url: $("#mp-url").value });
      bulleInfo(r.message); $("#perso-fiche").hidden = true; persoOnglet = "installe"; afficherPerso(); }
    catch (e) { $("#fiche-msg").textContent = e.message; }
  };
}
document.addEventListener("click", async (ev) => {
  if (vue !== "perso" && $("#perso-fiche").hidden) return;
  const t = ev.target;
  const ess = t.closest("[data-essayer]"); if (ess) { ev.stopPropagation(); return essayerPerso(ess.dataset.essayer); }
  const ins = t.closest("[data-installer-p]"); if (ins) { ev.stopPropagation(); ins.disabled = true; await installerPerso(ins.dataset.installerP, !!ins.dataset.depuisFiche); ins.disabled = false; return; }
  const ret = t.closest("[data-retirer-p]");
  if (ret) { if (!confirm("Retirer ? Rien n'est effacé : une skill est rangée dans Archives.")) return;
    try { const r = await api("/api/bibliotheque/retirer", { id: ret.dataset.retirerP, type: ret.dataset.type }); bulleInfo(r.message); $("#perso-fiche").hidden = true; afficherPerso(); } catch (e) { $("#fiche-msg").textContent = e.message; } return; }
  if (t.closest("[data-fermer-fiche]") || t.id === "perso-fiche") { $("#perso-fiche").hidden = true; return; }
  const f = t.closest("[data-fiche]"); if (f && !t.closest("#perso-fiche-corps")) return ficheElement(f.dataset.fiche);
});
document.addEventListener("keydown", (e) => { if (e.key === "Escape" && !$("#perso-fiche").hidden) $("#perso-fiche").hidden = true; });
