"""Préparation des changements de configuration (copies révisables, jamais appliquées ici).

Changement proposé pour AgentMemory (ADR-0003) :
- version épinglée identique au serveur : ``@agentmemory/mcp@<version>`` ;
- ``AGENTMEMORY_FORCE_PROXY=1`` : le client ne bascule plus en silence vers une
  mémoire locale (``standalone.json``) quand le serveur est absent ; l'absence
  devient une erreur visible ;
- ``AGENTMEMORY_URL`` explicite en boucle locale.
Le secret reste lu par le client officiel dans ``~/.agentmemory/.env`` : il
n'est jamais recopié dans une configuration.
"""
from __future__ import annotations

import difflib
import hashlib
import json
import re
from pathlib import Path

AGENTMEMORY_VERSION = "0.9.22"      # version du serveur global installé (journal du 2026-05-26)


def mcp_entry(version: str = AGENTMEMORY_VERSION) -> dict:
    return {"command": "npx", "args": ["-y", f"@agentmemory/mcp@{version}"],
            "env": {"AGENTMEMORY_URL": "http://localhost:3111", "AGENTMEMORY_FORCE_PROXY": "1"}}


_HEADER = re.compile(r"^\s*\[")


def _table_bounds(lines: list[str], name: str) -> tuple[int, int] | None:
    """(début, fin) d'une table TOML ; la fin exclut les lignes vides/commentaires
    qui précèdent la table suivante (elles lui appartiennent)."""
    head = re.compile(rf"^\s*\[{re.escape(name)}\]\s*(#.*)?$")
    for i, l in enumerate(lines):
        if head.match(l.rstrip("\r\n")):
            j = i + 1
            while j < len(lines) and not _HEADER.match(lines[j]):
                j += 1
            while j > i + 1 and (not lines[j - 1].strip() or lines[j - 1].lstrip().startswith("#")):
                j -= 1
            return i, j
    return None


def _set_key(lines: list[str], bounds: tuple[int, int], key: str, value_line: str) -> list[str]:
    """Remplace ``key = …`` (même sur plusieurs lignes) dans la table, sinon l'ajoute en fin de table."""
    i, j = bounds
    k_re = re.compile(rf"^\s*{re.escape(key)}\s*=")
    for n in range(i + 1, j):
        if k_re.match(lines[n]):
            m = n
            depth = lines[n].count("[") - lines[n].count("]")
            while depth > 0 and m + 1 < j:
                m += 1
                depth += lines[m].count("[") - lines[m].count("]")
            return lines[:n] + [value_line] + lines[m + 1:]
    return lines[:j] + [value_line] + lines[j:]


def patch_codex_config(text: str, version: str = AGENTMEMORY_VERSION) -> str:
    """Modifie uniquement ``command``/``args`` de ``[mcp_servers.agentmemory]`` et les clés
    ``AGENTMEMORY_URL``/``AGENTMEMORY_FORCE_PROXY`` de ``[mcp_servers.agentmemory.env]``.
    Toutes les autres lignes (clés, commentaires, tables) sont conservées."""
    nl = "\r\n" if "\r\n" in text else "\n"
    lines = text.splitlines(keepends=True)
    if lines and not lines[-1].endswith(("\n", "\r")):
        lines[-1] += nl
    e = mcp_entry(version)
    b = _table_bounds(lines, "mcp_servers.agentmemory")
    if b is None:
        raise ValueError("Aucune section [mcp_servers.agentmemory] : rien à modifier (à examiner).")
    lines = _set_key(lines, b, "command", f'command = "npx"{nl}')
    lines = _set_key(lines, _table_bounds(lines, "mcp_servers.agentmemory"), "args",
                     f"args = [{', '.join(json.dumps(a) for a in e['args'])}]{nl}")
    eb = _table_bounds(lines, "mcp_servers.agentmemory.env")
    if eb is None:
        _, end = _table_bounds(lines, "mcp_servers.agentmemory")
        lines = lines[:end] + [nl, f"[mcp_servers.agentmemory.env]{nl}"] + lines[end:]
        eb = _table_bounds(lines, "mcp_servers.agentmemory.env")
    for k, v in e["env"].items():
        lines = _set_key(lines, eb, k, f'{k} = "{v}"{nl}')
        eb = _table_bounds(lines, "mcp_servers.agentmemory.env")
    return "".join(lines)


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def diff(old: str, new: str, name: str) -> str:
    return "".join(difflib.unified_diff(old.splitlines(keepends=True), new.splitlines(keepends=True),
                                        f"actuel/{name}", f"propose/{name}"))


# --------------------------------------------------------------- application ---
# Exécutées seulement par l'utilisateur (Appliquer-Configs.ps1), jamais automatiquement.
def apply_codex(config: "Path", proposal_dir: "Path", backup_dir: "Path") -> dict:
    import tomllib
    from datetime import datetime, timezone
    from pathlib import Path
    config, proposal_dir, backup_dir = Path(config), Path(proposal_dir), Path(backup_dir)
    current = config.read_text(encoding="utf-8")
    base = (proposal_dir / "codex.config.toml.base.sha256").read_text(encoding="ascii").strip()
    if sha256_text(current) != base:
        raise RuntimeError("config.toml a changé depuis la préparation : relancer « config-preparer » puis relire le diff.")
    new = (proposal_dir / "codex.config.toml.propose").read_text(encoding="utf-8")
    tomllib.loads(new)                                    # la proposition doit être un TOML valide
    backup_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    saved = backup_dir / f"codex-config-{stamp}.toml"
    with open(saved, "xb") as fh:
        fh.write(config.read_bytes())
    config.write_text(new, encoding="utf-8", newline="")
    tomllib.loads(config.read_text(encoding="utf-8"))
    return {"applique": str(config), "sauvegarde": str(saved)}


def restore_codex(config: "Path", backup_dir: "Path", backup_file: "Path | None" = None) -> dict:
    from datetime import datetime, timezone
    from pathlib import Path
    config, backup_dir = Path(config), Path(backup_dir)
    candidates = sorted(backup_dir.glob("codex-config-*.toml"))
    src = Path(backup_file) if backup_file else (candidates[-1] if candidates else None)
    if src is None or not src.exists():
        raise FileNotFoundError("Aucune sauvegarde de config.toml trouvée.")
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    keep = backup_dir / f"avant-restauration-codex-config-{stamp}.toml"
    with open(keep, "xb") as fh:                         # l'état courant est conservé aussi
        fh.write(config.read_bytes())
    config.write_bytes(src.read_bytes())
    return {"restaure_depuis": str(src), "etat_precedent_conserve": str(keep)}


# ------------------------------------------------- serveur MCP du studio (mémoire cadrée) ---
def studio_mcp_entry(studio_dir: str, client: str) -> dict:
    py = studio_dir.rstrip("\\/") + "\\.venv\\Scripts\\python.exe"
    return {"command": py, "args": ["-m", "studio.mcp_server"],
            "env": {"PYTHONPATH": studio_dir, "STUDIO_MCP_CLIENT": client, "PYTHONUTF8": "1"}}


def add_studio_mcp_codex(text: str, studio_dir: str) -> str:
    """Ajoute [mcp_servers.studio-memoire] si absente et garantit que ses outils sont approuvés d'office
    (sinon ``codex exec`` les refuse : « requires approval, but approval policy is never »).
    Ce sont les outils du studio : portée imposée, secrets refusés."""
    nl = "\r\n" if "\r\n" in text else "\n"
    if re.search(r"^\s*\[mcp_servers\.studio-memoire\]", text, re.M):
        lines = text.splitlines(keepends=True)
        lines = _set_key(lines, _table_bounds(lines, "mcp_servers.studio-memoire"), "default_tools_approval_mode",
                         f'default_tools_approval_mode = "approve"{nl}')
        return "".join(lines)
    e = studio_mcp_entry(studio_dir, "codex")
    block = [f"{nl}[mcp_servers.studio-memoire]{nl}", f"command = '{e['command']}'{nl}",
             f"args = [{', '.join(json.dumps(a) for a in e['args'])}]{nl}", f"startup_timeout_sec = 30{nl}",
             f'default_tools_approval_mode = "approve"{nl}',
             f"{nl}[mcp_servers.studio-memoire.env]{nl}"]
    block += [f"{k} = '{v}'{nl}" for k, v in e["env"].items()]
    if not text.endswith(("\n", "\r")):
        text += nl
    return text + "".join(block)
