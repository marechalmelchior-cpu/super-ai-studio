"""Stockage persistant des tâches (SQLite, mode WAL).

Distinct :
- des points de reprise LangGraph (``checkpoints.db``) : où en est le graphe ;
- de la mémoire durable partagée (AgentMemory) : ce qui doit être retenu.
Ce fichier garde le suivi lisible : étapes, fichiers produits et versions,
erreurs et tentatives, effets déjà réalisés, processus lancés, approbations.
"""
from __future__ import annotations

import json
from ..espace import perso
import os
import sqlite3
import sys
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path

SCHEMA = """
CREATE TABLE IF NOT EXISTS tasks (
  id TEXT PRIMARY KEY, target TEXT NOT NULL, request TEXT NOT NULL, status TEXT NOT NULL,
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL, summary TEXT NOT NULL DEFAULT '',
  result_hash TEXT NOT NULL DEFAULT '', cancel_requested INTEGER NOT NULL DEFAULT 0,
  options TEXT NOT NULL DEFAULT '{}');
CREATE TABLE IF NOT EXISTS steps (
  task_id TEXT NOT NULL, name TEXT NOT NULL, status TEXT NOT NULL, detail TEXT NOT NULL DEFAULT '',
  started_at TEXT, ended_at TEXT, attempt INTEGER NOT NULL DEFAULT 1,
  PRIMARY KEY(task_id, name, attempt));
CREATE TABLE IF NOT EXISTS artifacts (
  task_id TEXT NOT NULL, path TEXT NOT NULL, version INTEGER NOT NULL, sha256 TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL, PRIMARY KEY(task_id, path, version));
CREATE TABLE IF NOT EXISTS errors (
  task_id TEXT NOT NULL, step TEXT NOT NULL, attempt INTEGER NOT NULL, message TEXT NOT NULL, at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS effects (
  key TEXT PRIMARY KEY, task_id TEXT NOT NULL, kind TEXT NOT NULL, status TEXT NOT NULL,
  result TEXT NOT NULL DEFAULT '', started_at TEXT NOT NULL, ended_at TEXT);
CREATE TABLE IF NOT EXISTS processes (
  id INTEGER PRIMARY KEY AUTOINCREMENT, task_id TEXT NOT NULL, pid INTEGER, command TEXT NOT NULL,
  started_at TEXT NOT NULL, ended_at TEXT, status TEXT NOT NULL, exit_code INTEGER);
CREATE TABLE IF NOT EXISTS approvals (
  task_id TEXT NOT NULL, decision TEXT NOT NULL, result_hash TEXT NOT NULL, comment TEXT NOT NULL DEFAULT '',
  at TEXT NOT NULL, valid INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS slots (slot INTEGER PRIMARY KEY, task_id TEXT, since TEXT, pid INTEGER);
CREATE TABLE IF NOT EXISTS events (
  id INTEGER PRIMARY KEY AUTOINCREMENT, task_id TEXT NOT NULL, at TEXT NOT NULL, message TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS usage (day TEXT NOT NULL, outil TEXT NOT NULL, appels INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (day, outil));
CREATE TABLE IF NOT EXISTS appels (
  id INTEGER PRIMARY KEY AUTOINCREMENT, at TEXT NOT NULL, day TEXT NOT NULL, famille TEXT NOT NULL, usage TEXT NOT NULL,
  cible TEXT, role TEXT, modele TEXT, duree_s REAL, jetons_entree INTEGER, jetons_sortie INTEGER, jetons_cache INTEGER,
  cout_usd REAL, ok INTEGER);
CREATE INDEX IF NOT EXISTS appels_at ON appels(at);
CREATE TABLE IF NOT EXISTS chaines (
  id TEXT PRIMARY KEY, cible TEXT NOT NULL, titre TEXT NOT NULL, etapes TEXT NOT NULL, courant INTEGER NOT NULL DEFAULT 0,
  statut TEXT NOT NULL, options TEXT NOT NULL DEFAULT '{}', note TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS demandes (
  id INTEGER PRIMARY KEY AUTOINCREMENT, cible TEXT NOT NULL, titre TEXT NOT NULL, demande TEXT NOT NULL,
  options TEXT NOT NULL DEFAULT '{}', retiree INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS conversation (
  id INTEGER PRIMARY KEY AUTOINCREMENT, at TEXT NOT NULL, auteur TEXT NOT NULL, texte TEXT NOT NULL,
  etat TEXT NOT NULL DEFAULT 'ok', proposition TEXT NOT NULL DEFAULT '{}');
"""

TERMINAL = ("approuvee", "annulee", "echec", "appliquee")


def pid_alive(pid) -> bool:
    if not pid:
        return False
    if pid == os.getpid():
        return True
    if sys.platform == "win32":
        import ctypes
        h = ctypes.windll.kernel32.OpenProcess(0x1000, False, int(pid))   # PROCESS_QUERY_LIMITED_INFORMATION
        if not h:
            return False
        code = ctypes.c_ulong()
        ctypes.windll.kernel32.GetExitCodeProcess(h, ctypes.byref(code))
        ctypes.windll.kernel32.CloseHandle(h)
        return code.value == 259                                           # STILL_ACTIVE
    try:
        os.kill(int(pid), 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        return True


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


class TaskStore:
    def __init__(self, path: Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.db() as c:
            c.executescript(SCHEMA)

    @contextmanager
    def db(self):
        c = sqlite3.connect(self.path, timeout=30, isolation_level=None)
        c.row_factory = sqlite3.Row
        c.execute("PRAGMA journal_mode=WAL")
        c.execute("PRAGMA busy_timeout=30000")
        try:
            yield c
        finally:
            c.close()

    # -- usage (appels aux outils, pour suivre les limites d'abonnement) ------
    def count_usage(self, outil: str) -> None:
        day = datetime.now().strftime("%Y-%m-%d")
        with self.db() as c:
            c.execute("INSERT INTO usage(day,outil,appels) VALUES (?,?,1) ON CONFLICT(day,outil) DO UPDATE SET appels=appels+1",
                      (day, outil))

    def noter_appel(self, famille: str, usage: str, *, cible: str = "", role: str = "", modele: str = "",
                    duree_s: float = 0.0, jetons: dict | None = None, cout_usd: float | None = None, ok: bool = True) -> None:
        """Un appel réel à Claude ou Codex (jamais une simulation) : de quoi lire l'usage en temps, en jetons et en
        coût équivalent API — les abonnements limitent l'usage par fenêtres de quelques heures et par semaine."""
        j = jetons or {}
        n = datetime.now()
        with self.db() as c:
            c.execute("INSERT INTO appels(at,day,famille,usage,cible,role,modele,duree_s,jetons_entree,jetons_sortie,"
                      "jetons_cache,cout_usd,ok) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                      (n.isoformat(timespec="seconds"), n.strftime("%Y-%m-%d"), famille, usage, cible, role, modele,
                       round(float(duree_s or 0), 1), j.get("entree"), j.get("sortie"), j.get("cache"), cout_usd, int(bool(ok))))

    # -- chaînes de tâches -----------------------------------------------------
    def creer_chaine(self, cid: str, cible: str, titre: str, etapes: list, options: dict) -> None:
        with self.db() as c:
            c.execute("INSERT INTO chaines(id,cible,titre,etapes,courant,statut,options,created_at,updated_at) "
                      "VALUES (?,?,?,?,0,'en_cours',?,?,?)", (cid, cible, titre, json.dumps(etapes, ensure_ascii=False),
                                                           json.dumps(options, ensure_ascii=False), now(), now()))

    def chaine(self, cid: str) -> dict | None:
        with self.db() as c:
            r = c.execute("SELECT * FROM chaines WHERE id=?", (cid,)).fetchone()
        if r is None:
            return None
        d = dict(r)
        d["etapes"], d["options"] = json.loads(d["etapes"]), json.loads(d["options"])
        return d

    def maj_chaine(self, cid: str, **champs) -> None:
        if "etapes" in champs:
            champs["etapes"] = json.dumps(champs["etapes"], ensure_ascii=False)
        cols = ",".join(f"{k}=?" for k in champs)
        with self.db() as c:
            c.execute(f"UPDATE chaines SET {cols},updated_at=? WHERE id=?", (*champs.values(), now(), cid))

    def chaines(self, cible: str = "") -> list[dict]:
        with self.db() as c:
            ids = [r[0] for r in c.execute("SELECT id FROM chaines WHERE ?='' OR cible=? ORDER BY created_at DESC LIMIT 50",
                                           (cible, cible))]
        return [self.chaine(i) for i in ids]

    # demandes enregistrées : boutons retirés (maj91) ; la table « demandes » reste dans la base, rien n'est effacé.

    def appels(self, depuis: str) -> list[dict]:
        """Appels détaillés depuis ``depuis`` (horodatage local ISO), du plus récent au plus ancien."""
        with self.db() as c:
            return [dict(r) for r in c.execute("SELECT * FROM appels WHERE at >= ? ORDER BY at DESC", (depuis,))]

    def usage(self, days: int = 7) -> list[dict]:
        with self.db() as c:
            return [dict(r) for r in c.execute("SELECT day,outil,appels FROM usage ORDER BY day DESC, outil LIMIT ?", (days * 4,))]

    # -- conversation avec le Superviseur -------------------------------------
    def message(self, auteur: str, texte: str, etat: str = "ok", proposition: dict | None = None) -> int:
        texte = perso(texte) if auteur != "mel" else texte
        with self.db() as c:
            cur = c.execute("INSERT INTO conversation(at,auteur,texte,etat,proposition) VALUES (?,?,?,?,?)",
                            (now(), auteur, texte, etat, json.dumps(proposition or {}, ensure_ascii=False)))
            return int(cur.lastrowid)

    def update_message(self, mid: int, **fields) -> None:
        if "texte" in fields:
            fields["texte"] = perso(fields["texte"])
        if "proposition" in fields:
            fields["proposition"] = json.dumps(fields["proposition"], ensure_ascii=False)
        cols = ",".join(f"{k}=?" for k in fields)
        with self.db() as c:
            c.execute(f"UPDATE conversation SET {cols} WHERE id=?", (*fields.values(), mid))

    def messages(self, limit: int = 60) -> list[dict]:
        with self.db() as c:
            rows = [dict(r) for r in c.execute("SELECT * FROM conversation ORDER BY id DESC LIMIT ?", (limit,))]
        for r in rows:
            r["proposition"] = json.loads(r["proposition"] or "{}")
        return rows[::-1]

    # -- tâches -------------------------------------------------------------
    def create(self, target: str, request: str, options: dict | None = None) -> str:
        tid = datetime.now(timezone.utc).strftime("T%Y%m%d-%H%M%S-") + uuid.uuid4().hex[:6]
        with self.db() as c:
            c.execute("INSERT INTO tasks(id,target,request,status,created_at,updated_at,options) VALUES (?,?,?,?,?,?,?)",
                      (tid, target, request, "creee", now(), now(), json.dumps(options or {}, ensure_ascii=False)))
        self.event(tid, "Tâche créée")
        return tid

    def get(self, tid: str) -> dict:
        with self.db() as c:
            row = c.execute("SELECT * FROM tasks WHERE id=?", (tid,)).fetchone()
        if row is None:
            raise KeyError(f"Tâche inconnue : {tid}")
        d = dict(row)
        d["options"] = json.loads(d["options"])
        return d

    def list(self, limit: int = 50) -> list[dict]:
        with self.db() as c:
            return [dict(r) for r in c.execute(
                "SELECT id,target,status,created_at,updated_at,summary,request,json_extract(options,'$.titre') AS titre,"
                " json_extract(options,'$.chaine') AS chaine, json_extract(options,'$.etape') AS etape,"
                # temps de travail réel = somme des étapes terminées (l'attente de la décision de l'utilisateur n'en fait pas partie)
                " (SELECT ROUND(SUM((julianday(s.ended_at)-julianday(s.started_at))*86400)) FROM steps s"
                "   WHERE s.task_id=tasks.id AND s.ended_at IS NOT NULL AND s.name<>'approbation') AS duree_s,"
                " (SELECT s.started_at FROM steps s WHERE s.task_id=tasks.id AND s.status='en_cours'"
                "   AND s.name<>'approbation' ORDER BY s.rowid DESC LIMIT 1) AS etape_depuis,"
                " (SELECT s.name FROM steps s WHERE s.task_id=tasks.id AND s.status='en_cours'"
                "   ORDER BY s.rowid DESC LIMIT 1) AS etape_nom,"
                " (SELECT MAX(s.attempt) FROM steps s WHERE s.task_id=tasks.id) AS essai"
                " FROM tasks ORDER BY created_at DESC LIMIT ?", (limit,))]

    def set_status(self, tid: str, status: str, summary: str | None = None) -> None:
        summary = perso(summary)
        with self.db() as c:
            if summary is None:
                c.execute("UPDATE tasks SET status=?,updated_at=? WHERE id=?", (status, now(), tid))
            else:
                c.execute("UPDATE tasks SET status=?,summary=?,updated_at=? WHERE id=?", (status, summary, now(), tid))
        self.event(tid, f"Statut : {status}")

    def set_hash(self, tid: str, h: str) -> None:
        with self.db() as c:
            c.execute("UPDATE tasks SET result_hash=?,updated_at=? WHERE id=?", (h, now(), tid))

    def request_cancel(self, tid: str) -> None:
        with self.db() as c:
            c.execute("UPDATE tasks SET cancel_requested=1,updated_at=? WHERE id=?", (now(), tid))
        self.event(tid, "Annulation demandée")

    def request_pause(self, tid: str) -> None:
        """« Stop » : arrête le travail en cours sans annuler la tâche (« Reprendre » la relance)."""
        with self.db() as c:
            c.execute("UPDATE tasks SET cancel_requested=2,updated_at=? WHERE id=? AND cancel_requested=0", (now(), tid))
        self.event(tid, "Arrêt demandé par l'utilisateur")

    def pause_requested(self, tid: str) -> bool:
        with self.db() as c:
            r = c.execute("SELECT cancel_requested FROM tasks WHERE id=?", (tid,)).fetchone()
        return bool(r and r[0] == 2)

    def clear_pause(self, tid: str) -> None:
        with self.db() as c:
            c.execute("UPDATE tasks SET cancel_requested=0 WHERE id=? AND cancel_requested=2", (tid,))

    def cancel_requested(self, tid: str) -> bool:
        with self.db() as c:
            r = c.execute("SELECT cancel_requested FROM tasks WHERE id=?", (tid,)).fetchone()
        return bool(r and r[0])

    def event(self, tid: str, msg: str) -> None:
        msg = perso(msg)
        with self.db() as c:
            c.execute("INSERT INTO events(task_id,at,message) VALUES (?,?,?)", (tid, now(), msg[:2000]))

    def events(self, tid: str) -> list[dict]:
        with self.db() as c:
            return [dict(r) for r in c.execute("SELECT at,message FROM events WHERE task_id=? ORDER BY id", (tid,))]

    # -- étapes, erreurs, fichiers -------------------------------------------
    def step(self, tid: str, name: str, status: str, detail: str = "", attempt: int = 1) -> None:
        with self.db() as c:
            if status == "en_cours":
                c.execute("INSERT OR REPLACE INTO steps(task_id,name,status,detail,started_at,attempt) VALUES (?,?,?,?,?,?)",
                          (tid, name, status, detail, now(), attempt))
            else:
                c.execute("INSERT OR IGNORE INTO steps(task_id,name,status,started_at,attempt) VALUES (?,?,?,?,?)",
                          (tid, name, status, now(), attempt))
                c.execute("UPDATE steps SET status=?,detail=?,ended_at=? WHERE task_id=? AND name=? AND attempt=?",
                          (status, detail[:4000], now(), tid, name, attempt))

    def steps(self, tid: str) -> list[dict]:
        with self.db() as c:
            return [dict(r) for r in c.execute(
                "SELECT name,status,detail,attempt,started_at,ended_at FROM steps WHERE task_id=? ORDER BY attempt, rowid",
                (tid,))]

    def error(self, tid: str, step: str, attempt: int, msg: str) -> None:
        with self.db() as c:
            c.execute("INSERT INTO errors VALUES (?,?,?,?,?)", (tid, step, attempt, msg[:4000], now()))

    def errors(self, tid: str) -> list[dict]:
        with self.db() as c:
            return [dict(r) for r in c.execute("SELECT step,attempt,message,at FROM errors WHERE task_id=?", (tid,))]

    def artifact(self, tid: str, path: str, sha: str, role: str = "") -> int:
        with self.db() as c:
            last = c.execute("SELECT version, sha256 FROM artifacts WHERE task_id=? AND path=? ORDER BY version DESC LIMIT 1",
                             (tid, path)).fetchone()
            if last and last["sha256"] == sha:
                return last["version"]
            v = (last["version"] + 1) if last else 1
            c.execute("INSERT INTO artifacts VALUES (?,?,?,?,?,?)", (tid, path, v, sha, role, now()))
            return v

    def artifacts(self, tid: str) -> list[dict]:
        with self.db() as c:
            return [dict(r) for r in c.execute(
                "SELECT path,version,sha256,role,created_at FROM artifacts WHERE task_id=? ORDER BY path,version", (tid,))]

    # -- approbations --------------------------------------------------------
    def approve(self, tid: str, decision: str, h: str, comment: str = "") -> None:
        with self.db() as c:
            c.execute("UPDATE approvals SET valid=0 WHERE task_id=?", (tid,))
            c.execute("INSERT INTO approvals VALUES (?,?,?,?,?,1)", (tid, decision, h, comment[:2000], now()))

    def invalidate_approvals(self, tid: str, reason: str) -> None:
        with self.db() as c:
            n = c.execute("UPDATE approvals SET valid=0 WHERE task_id=? AND valid=1", (tid,)).rowcount
        if n:
            self.event(tid, f"Approbation invalidée : {reason}")

    def approvals(self, tid: str) -> list[dict]:
        with self.db() as c:
            return [dict(r) for r in c.execute("SELECT * FROM approvals WHERE task_id=? ORDER BY at", (tid,))]

    # -- créneaux de concurrence ---------------------------------------------
    def acquire_slot(self, tid: str, max_slots: int):
        """Créneau de concurrence. Retourne True, False (limite atteinte) ou "deja_en_cours".
        Les créneaux d'un processus disparu (coupure, arrêt forcé) sont récupérés."""
        with self.db() as c:
            c.execute("BEGIN IMMEDIATE")
            try:
                rows = c.execute("SELECT slot, task_id, pid FROM slots").fetchall()
                for r in rows:
                    if r["task_id"] and not pid_alive(r["pid"]):
                        c.execute("DELETE FROM slots WHERE slot=?", (r["slot"],))
                rows = c.execute("SELECT slot, task_id, pid FROM slots").fetchall()
                if any(r["task_id"] == tid for r in rows):
                    c.execute("COMMIT")
                    return "deja_en_cours"
                busy = {r["slot"] for r in rows if r["task_id"]}
                free = [i for i in range(max_slots) if i not in busy]
                if not free:
                    c.execute("COMMIT")
                    return False
                c.execute("INSERT OR REPLACE INTO slots VALUES (?,?,?,?)", (free[0], tid, now(), os.getpid()))
                c.execute("COMMIT")
                return True
            except Exception:
                c.execute("ROLLBACK")
                raise

    def release_slot(self, tid: str) -> None:
        with self.db() as c:
            c.execute("DELETE FROM slots WHERE task_id=?", (tid,))
