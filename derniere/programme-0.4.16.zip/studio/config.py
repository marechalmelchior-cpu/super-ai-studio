"""Configuration du studio (TOML, lecture seule via tomllib)."""
from __future__ import annotations

import copy
import tomllib
from pathlib import Path
from typing import Any

DEFAULTS: dict[str, Any] = {
    "limites": {
        "taches_simultanees": 1,        # concurrence faible au départ
        "duree_max_etape_s": 900,       # délai d'un appel d'outil
        "duree_max_tache_s": 3600,      # par exécution (une attente d'approbation ne compte pas)
        "corrections_max": 2,           # reprises après audit
        "autonomie": "complete",        # « complete » : relecture OK → validée, appliquée, fusionnée seule ; « validation » : l'utilisateur valide
    },
    "memoire": {
        # "agentmemory" = technologie choisie ; "sqlite" = alternative locale explicite.
        "backend": "agentmemory",
        "url": "http://127.0.0.1:3111",
        "delai_s": 5.0,
        "en_cas_de_panne": "continuer_signale",   # ou "bloquer"
        "ttl_jours_tache": 14,
    },
    "outils": {
        "claude": "claude",
        "codex": "codex",
        "blender": "",
        "unreal_editor_cmd": "",
        "git": "git",
        "mcp_unreal": "tout",            # agents : accès complet à unreal-mcp ; « lecture » = actions de lecture seulement
    },
    "interface": {"hote": "127.0.0.1", "port": 8765, "acces_mobile": False},
    "utilisateur": {"nom": ""},         # prénom (Réglages › « Ton prénom ») ; vide = textes neutres
    "benchmarks": {"url": ""},          # classements complets à jour (même format que modeles/benchmarks.json) ; vide = prix du jour seulement
    "audit": {"auditeur_modele": True},
    "agents_api": {"commandes": "sures", "contexte_local": 32768},   # contexte_local : mémoire de travail max des modèles Ollama (jetons)
    "nuit": {"debut": "01:00", "fin": "07:00"},   # tâches « Cette nuit » : partent dans cette plage (heure du PC)  # commandes des agents par clé API / IA locale : non | sures | toutes
    "superviseur": {"web": True, "bilan": True, "modele": "", "modele_rapide": "haiku", "delai_s": 300},   # fenêtre Demande : Claude Code en lecture seule
    # Pièces jointes rendues lisibles (studio/pieces.py) ; modèle de parole stocké dans Studio/data/modeles-parole
    "pieces": {"modele_parole": "small", "dossier_modeles": ""},
    "usage": {"alerte_claude_5h_min": 60, "alerte_codex_5h_min": 60, "limites_claude": True, "limites_codex": True},   # alerte : limite atteinte dans moins de N min au rythme actuel
    "choix": {"modeles_claude": ["opus", "sonnet", "haiku"], "codex_effort_max": "high"},
}


def _merge(base: dict, extra: dict) -> dict:
    out = copy.deepcopy(base)
    for k, v in extra.items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _merge(out[k], v)
        else:
            out[k] = v
    return out


def load_config(path: Path | None) -> dict[str, Any]:
    cfg = copy.deepcopy(DEFAULTS)
    if path and Path(path).exists():
        with open(path, "rb") as fh:
            cfg = _merge(cfg, tomllib.load(fh))
    host = cfg["interface"]["hote"]
    if host not in ("127.0.0.1", "localhost"):
        raise ValueError("L'interface du studio doit rester locale (127.0.0.1).")
    return cfg


def set_outil(path: Path, cle: str, valeur: str) -> None:
    """Modifie une seule ligne ``cle = …`` de la section [outils] (commentaires et reste du fichier conservés)."""
    import re
    if "'" in valeur or "\n" in valeur:
        raise ValueError("Chemin invalide.")
    texte = Path(path).read_text(encoding="utf-8")
    debut = re.search(r"(?m)^\[outils\]\s*$", texte)
    if not debut:
        raise ValueError("Section [outils] absente.")
    fin = re.search(r"(?m)^\[", texte[debut.end():])
    zone = texte[debut.end(): debut.end() + fin.start()] if fin else texte[debut.end():]
    motif = re.compile(rf"(?m)^({re.escape(cle)}\s*=\s*)(\"[^\"]*\"|'[^']*')([ \t]*#.*)?$")
    if not motif.search(zone):
        raise ValueError(f"Clé « {cle} » absente de [outils].")
    zone2 = motif.sub(lambda m: f"{m.group(1)}'{valeur}'{m.group(3) or ''}", zone, count=1)
    nouveau = texte[: debut.end()] + zone2 + texte[debut.end() + len(zone):]
    tomllib.loads(nouveau)
    tmp = Path(path).with_suffix(".tmp")
    tmp.write_text(nouveau, encoding="utf-8", newline="")
    tmp.replace(path)


def trouver_blender() -> list[str]:
    """Cherche blender.exe : bibliothèques Steam (registre + libraryfolders.vdf), Program Files, PATH."""
    import os
    import re
    import shutil
    import sys
    vus: list[str] = []
    steam: list[Path] = []
    if sys.platform == "win32":
        try:
            import winreg
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Valve\Steam") as k:
                steam.append(Path(winreg.QueryValueEx(k, "SteamPath")[0]))
        except OSError:
            pass
    for base in (os.environ.get("ProgramFiles(x86)"), os.environ.get("ProgramFiles")):
        if base:
            steam.append(Path(base) / "Steam")
    libs: list[Path] = []
    for s in steam:
        libs.append(s)
        vdf = s / "steamapps" / "libraryfolders.vdf"
        if vdf.exists():
            libs += [Path(p.replace("\\\\", "\\")) for p in re.findall(r'"path"\s+"([^"]+)"', vdf.read_text(encoding="utf-8", errors="replace"))]
    candidats = [lib / "steamapps" / "common" / "Blender" / "blender.exe" for lib in libs]
    for base in (os.environ.get("ProgramFiles"),):
        if base:
            candidats += sorted((Path(base) / "Blender Foundation").glob("*/blender.exe"), reverse=True)
    w = shutil.which("blender")
    if w:
        candidats.append(Path(w))
    for c in candidats:
        if c.is_file() and str(c) not in vus:
            vus.append(str(c))
    return vus
