"""Créer un agent spécialisé : domaine → rôle proposé → modèle recommandé (classements du marché) → rôle ajouté.

Catalogue : modeles/agents.json (domaines et rôles prêts à l'emploi). Classements : modeles/benchmarks.json (datés,
sourcés). La recommandation prend d'abord la meilleure IA déjà connectée pour ce type de travail, et montre aussi le
meilleur du marché s'il est différent. Le rôle créé est un fichier Studio/roles/<id>.toml de l'espace (jamais écrasé).
"""
from __future__ import annotations

import json
import re
import tomllib
import unicodedata
from pathlib import Path

from .espace import MODELES

CAPACITES = {"image": {"openai", "gemini", "codex"}, "voix": {"openai"}}     # génération réelle possible depuis le studio


def catalogue() -> dict:
    return json.loads((MODELES / "agents.json").read_text(encoding="utf-8"))


_cache: dict = {}


def benchmarks(data: Path | None = None) -> dict:
    """Classements livrés avec le studio ; remplacés par ceux publiés depuis s'ils sont plus récents
    (data/benchmarks-maj.json, mis à jour chaque jour) ; prix du jour appliqués aux modèles cloud seulement."""
    base = json.loads((MODELES / "benchmarks.json").read_text(encoding="utf-8"))
    d = data or _cache.get("data")
    if d:
        try:
            maj = json.loads((Path(d) / "benchmarks-maj.json").read_text(encoding="utf-8"))
            if isinstance(maj.get("modeles"), list) and str(maj.get("date", "")) >= str(base.get("date", "")):
                base = {**base, **{k: v for k, v in maj.items() if k not in ("prix", "prix_complet", "contextes")}}
            for m in base["modeles"]:
                p = (maj.get("prix") or {}).get(_norme(m["cle"]))
                if p is not None and not m.get("local"):
                    m["prix"] = p
            base["actualise"] = maj.get("actualise", "")
        except (OSError, ValueError):
            pass
    for m in base["modeles"]:
        if m.get("local"):
            m["prix"] = None                              # local : gratuit (jamais le prix d'un service en ligne)
    return base


def _norme(t: str) -> str:
    return re.sub(r"[^a-z0-9]", "", t.lower())


def url_classements(url: str = "") -> str:
    """Classements complets publiés : réglage [benchmarks] url, sinon le dépôt du studio (catalogue/benchmarks.json)."""
    if url.startswith("https://"):
        return url
    from .mise_a_jour import depot
    d = depot()
    return f"https://raw.githubusercontent.com/{d}/main/catalogue/benchmarks.json" if d else ""


def actualiser(data: Path, url: str = "", force: bool = False) -> dict:
    """Chaque jour : classements publiés (si plus récents) puis prix du jour des modèles cloud (annuaire public
    d'OpenRouter, sans clé, rien n'est envoyé). En cas d'échec, les classements livrés restent utilisés."""
    import time
    import urllib.request
    from datetime import datetime, timezone
    _cache["data"] = str(data)
    f = Path(data) / "benchmarks-maj.json"
    if not force and f.exists() and time.time() - f.stat().st_mtime < 24 * 3600:
        return {"ok": True, "frais": True}
    quand = datetime.now(timezone.utc).isoformat(timespec="minutes")
    maj: dict = {}
    erreurs = []
    source = url_classements(url)
    if source:
        try:
            with urllib.request.urlopen(urllib.request.Request(source, headers={"User-Agent": "SuperAIStudio"}), timeout=20) as r:
                d = json.loads(r.read())
            if not isinstance(d.get("modeles"), list):
                raise ValueError("format inattendu")
            maj.update(d)
        except Exception as e:                            # noqa: BLE001
            erreurs.append(type(e).__name__)
    try:
        req = urllib.request.Request("https://openrouter.ai/api/v1/models", headers={"User-Agent": "SuperAIStudio"})
        with urllib.request.urlopen(req, timeout=20) as r:
            liste = json.loads(r.read()).get("data", [])
        modeles = maj.get("modeles") or json.loads((MODELES / "benchmarks.json").read_text(encoding="utf-8"))["modeles"]
        prix = {}
        for m in modeles:
            cle = _norme(m["cle"])
            if m.get("local") or not cle:
                continue
            ids = [(x, _norme(str(x.get("id", "")).split("/")[-1])) for x in liste]
            trouve = next((x for x, i in ids if i == cle), None) or next((x for x, i in ids if i.startswith(cle) and not i[len(cle):len(cle) + 1].isdigit()), None) \
                or next((x for x, i in ids if cle in i), None)          # « claude-opus-5 » ne prend pas le prix d'Opus 5.5
            if trouve:
                try:
                    prix[cle] = round(float((trouve.get("pricing") or {}).get("prompt", 0)) * 1_000_000, 3)
                except (TypeError, ValueError):
                    pass
        maj["prix"] = prix
        complet = {}                                      # coût à l'usage (Gestion › Usage) : entrée et sortie, par modèle
        for x in liste:
            try:
                pr = x.get("pricing") or {}
                complet[str(x.get("id", ""))] = [round(float(pr.get("prompt", 0)) * 1e6, 4), round(float(pr.get("completion", 0)) * 1e6, 4)]
            except (TypeError, ValueError):
                pass
        maj["prix_complet"] = complet
        maj["contextes"] = {str(x.get("id", "")): int(x["context_length"]) for x in liste
                            if isinstance(x.get("context_length"), (int, float)) and x.get("id")}
    except Exception as e:                                # noqa: BLE001
        erreurs.append(type(e).__name__)
    if not maj:
        return {"ok": False, "erreur": ", ".join(erreurs)}
    maj["actualise"] = quand
    t = f.with_suffix(".partiel")
    t.write_text(json.dumps(maj, ensure_ascii=False), encoding="utf-8")
    t.replace(f)
    return {"ok": True, "actualise": quand}


def cout_estime(data: Path, modele: str, j: dict) -> float | None:
    """Coût d'un appel payé à l'usage (clé API) d'après les prix du jour (annuaire OpenRouter, $ par million de jetons).
    Jetons relus depuis le cache : comptés au quart du prix d'entrée (ordre de grandeur des remises des fournisseurs)."""
    if not modele or not j:
        return None
    try:
        complet = json.loads((Path(data) / "benchmarks-maj.json").read_text(encoding="utf-8")).get("prix_complet") or {}
    except (OSError, ValueError):
        return None
    cle = _norme(modele.split("/")[-1].split(":")[0])
    if not cle:
        return None
    ids = [(k, _norme(k.split("/")[-1])) for k in complet]
    k = next((k for k, i in ids if i == cle), None) or next((k for k, i in ids if i.startswith(cle)), None)
    if not k:
        return None
    pin, pout = complet[k]
    return round((j.get("entree", 0) + 0.25 * j.get("cache", 0)) * pin / 1e6 + j.get("sortie", 0) * pout / 1e6, 5)


def sources_connectees(studio) -> list[dict]:
    """IA utilisables maintenant : abonnements installés et connexions (clé API ou locale)."""
    from . import ia
    from .connectors.base import find_exe
    from .connectors.claude_code import WIN_CANDIDATES
    out = []
    if find_exe(studio.cfg["outils"].get("claude", "claude"), WIN_CANDIDATES):
        out.append({"id": "claude-code", "fournisseur": "anthropic", "nom": "Claude Code (abonnement)", "modele": ""})
    if find_exe(studio.cfg["outils"].get("codex", "codex")):
        out.append({"id": "codex", "fournisseur": "codex", "nom": "Codex (abonnement ChatGPT)", "modele": ""})
    for c in ia.lire(studio.paths.data)["connexions"]:
        f = c["fournisseur"]
        out.append({"id": c["id"], "fournisseur": "local" if f in ("ollama", "lmstudio") else f,
                    "nom": ia.FOURNISSEURS.get(f, {}).get("nom", f), "modele": c.get("modele", "")})
    return out


def _classement(categorie: str) -> list[dict]:
    b = benchmarks()["modeles"]  # noqa
    cats = {"code": ["code", "global"], "texte": ["global"], "image": ["image"], "video": ["global"], "voix": ["voix"]}.get(categorie, ["global"])
    out, vus = [], set()
    for c in cats:
        for m in sorted((m for m in b if m["categorie"] == c), key=lambda m: -(m["score"] or 0)):
            if (m["cle"], m.get("local")) not in vus:
                vus.add((m["cle"], m.get("local")))
                out.append(m)
    return out


def recommander(studio, categorie: str) -> dict:
    """{"connecte": source + modèle conseillé (ou None), "marche": meilleur du marché, "remarque": texte}."""
    sources = sources_connectees(studio)
    classement = _classement(categorie)
    marche = next((m for m in classement if not m.get("local")), None)
    capables = sources
    if categorie in CAPACITES:
        capables = [s for s in sources if s["fournisseur"] in CAPACITES[categorie]]
    choix, modele = None, None
    for m in classement:
        f = "local" if m.get("local") else m["fournisseur"]       # GPT-OSS local ≠ abonnement Codex
        s = next((x for x in capables if x["fournisseur"] == f or (f == "openai" and x["fournisseur"] == "codex")), None)
        if s:
            choix, modele = s, m
            break
    if choix is None and capables:
        locale = [s for s in capables if s["fournisseur"] == "local"]
        choix = (locale or capables)[0]
        if choix["fournisseur"] == "local":
            modele = next((m for m in _classement("texte") if m.get("local")), None)
    remarque = ""
    if categorie in CAPACITES and not capables:
        remarque = ("Aucune IA connectée ne sait générer de " + ("images" if categorie == "image" else "voix")
                    + " : l'agent écrira les prompts et fiches ; connecte OpenAI ou Gemini (images) pour qu'il les produise.")
    elif categorie == "video":
        remarque = "La vidéo elle-même se génère sur l'outil choisi (Kling, Veo, Seedance…) : l'agent prépare scénario, storyboard et prompts."
    return {"connecte": ({**choix, "modele_conseille": modele} if choix else None), "marche": marche, "remarque": remarque}


def _slug(texte: str) -> str:
    t = unicodedata.normalize("NFKD", texte).encode("ascii", "ignore").decode().lower()
    return re.sub(r"[^a-z0-9]+", "-", t).strip("-")[:40] or "agent"


def _toml(v) -> str:
    return json.dumps(v, ensure_ascii=False)          # chaînes et listes JSON = TOML valide


def creer(studio, donnees: dict) -> dict:
    """Écrit le rôle dans l'espace (nouveau fichier uniquement) et recharge l'équipe."""
    from .espace import perso
    from .orchestrator.roles import load_roles
    nom = str(donnees.get("nom", "")).strip()[:60]
    if not nom:
        raise ValueError("Donne un nom à l'agent.")
    mission = str(donnees.get("mission", "")).strip()[:2000]
    if not mission:
        raise ValueError("Décris la mission de l'agent.")
    liste = lambda k: [str(x).strip()[:300] for x in (donnees.get(k) or []) if str(x).strip()][:12]
    source = str(donnees.get("source", "") or "")
    categorie = str(donnees.get("categorie", "texte"))
    base = _slug(str(donnees.get("id") or nom))
    ident, n = base, 2
    while (studio.paths.roles / f"{ident}.toml").exists() or ident in studio.roles:
        ident, n = f"{base}-{n}", n + 1
    if source in ("claude-code", "codex"):
        executeur, connexion = source, ""
    elif source:
        from . import ia
        if not ia.connexion(studio.paths.data, source):
            raise ValueError("IA inconnue : connecte-la d'abord (Accueil › Réglages › IA).")
        executeur, connexion = "api", source
    else:
        executeur, connexion = "claude-code", ""
    outils = [str(x) for x in (donnees.get("outils") or ["Read", "Edit", "Write", "Glob", "Grep"])][:20]
    lignes = [f"id = {_toml(ident)}", f"nom = {_toml(nom)}", f"domaines = {_toml([str(donnees.get('domaine') or 'general')])}",
              f"executeur = {_toml(executeur)}", f"mots_cles = {_toml(liste('mots_cles'))}", f"outils = {_toml(outils)}",
              f"livrables = {_toml(liste('livrables') or ['Résultat dans l espace isolé, compte rendu clair'])}",
              f"criteres = {_toml(liste('criteres') or ['Travail demandé fait et vérifié'])}",
              f"limites = {_toml(liste('limites'))}", f"consignes = {_toml(perso(mission))}",
              f"categorie = {_toml(categorie)}", "cree_par = \"assistant\""]
    if connexion:
        lignes.append(f"connexion = {_toml(connexion)}")
    if donnees.get("modele_api"):
        lignes.append(f"modele_api = {_toml(str(donnees['modele_api'])[:120])}")
    projet = str(donnees.get("projet", "") or "")
    if projet:                                          # agent propre à un projet : proposé seulement là
        t = studio.registry.get(projet)
        lignes.append(f"projets = {_toml([f'{t.kind}:{t.id}'])}")
    texte = "\n".join(lignes) + "\n"
    tomllib.loads(texte)                                # le fichier doit être valide avant d'être écrit
    f = studio.paths.roles / f"{ident}.toml"
    f.parent.mkdir(parents=True, exist_ok=True)
    with open(f, "x", encoding="utf-8") as fh:          # « x » : jamais d'écrasement
        fh.write(texte)
    studio.roles = load_roles(studio.paths.roles)
    return {"id": ident, "fichier": str(f), "executeur": executeur}
