/* Service worker : rend le studio installable sur le téléphone. Rien n'est mis en cache : tout vient du PC, en direct.
   Seule exception : si le PC ne répond pas (studio fermé, PC éteint, Tailscale coupé), une page d'attente s'affiche et
   réessaie toute seule ; le studio revient dès qu'il répond. */
const ATTENTE = `<!doctype html><html lang="fr"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="theme-color" content="#030810"><meta http-equiv="refresh" content="10"><title>Studio</title>
<body style="margin:0;min-height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:10px;
background:#030810;color:#e8eaed;font:16px system-ui;text-align:center;padding:24px;box-sizing:border-box">
<h1 style="font-size:20px;margin:0">Le studio ne répond pas</h1>
<p style="color:#9aa0a6;margin:0;max-width:320px">Il est peut-être fermé sur le PC, ou Tailscale est coupé sur ce téléphone.
Ouvre le studio sur le PC : cette page se reconnecte toute seule.</p>
<p style="color:#5f6368;font-size:13px">Nouvel essai toutes les 10 secondes…</p></body></html>`;
self.addEventListener("install", () => self.skipWaiting());
self.addEventListener("activate", (e) => e.waitUntil(self.clients.claim()));
self.addEventListener("fetch", (e) => {
  if (e.request.mode !== "navigate") return;
  e.respondWith(fetch(e.request).then((r) => (r.status >= 502 && r.status <= 504 ? attente() : r)).catch(attente));
});
function attente() {
  return new Response(ATTENTE, { status: 503, headers: { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store" } });
}
