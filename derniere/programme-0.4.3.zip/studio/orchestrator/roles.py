"""Rôles spécialisés (fichiers ``Studio/roles/*.toml``).

Un rôle reçoit une mission délimitée : contexte autorisé, outils, livrables,
critères de réussite, limites. La sélection ne mobilise que le rôle producteur
utile + l'auditeur ; les autres rôles ne sont pas lancés sans bénéfice concret.
"""
from __future__ import annotations

import re
import tomllib
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class Role:
    id: str
    nom: str
    domaines: list[str]
    mots_cles: list[str]
    executeur: str
    outils: list[str]
    livrables: list[str]
    criteres: list[str]
    limites: list[str]
    consignes: str = ""
    lecture_seule: bool = False
    modele: str = ""          # modèle par défaut du rôle (alias Claude Code), réglé pour l'efficacité et la vitesse
    effort: str = ""          # effort par défaut : low | medium | high | xhigh | max
    extra: dict = field(default_factory=dict)
    connexion: str = ""       # IA connectée propre au rôle (clé API ou locale) ; vide = celle des agents
    modele_api: str = ""      # modèle de cette IA pour le rôle
    categorie: str = ""       # texte | code | image | video | voix (rôles créés par l'assistant)


def load_roles(d: Path) -> dict[str, Role]:
    roles = {}
    for f in sorted(Path(d).glob("*.toml")):
        with open(f, "rb") as fh:
            x = tomllib.load(fh)
        r = Role(id=x["id"], nom=x["nom"], domaines=x.get("domaines", []), mots_cles=x.get("mots_cles", []),
                 executeur=x.get("executeur", "claude-code"), outils=x.get("outils", []),
                 livrables=x.get("livrables", []), criteres=x.get("criteres", []), limites=x.get("limites", []),
                 consignes=x.get("consignes", ""), lecture_seule=x.get("lecture_seule", False),
                 modele=str(x.get("modele", "")),
                 effort=str(x.get("effort", "")) if x.get("effort") in ("low", "medium", "high", "xhigh", "max") else "",
                 connexion=str(x.get("connexion", "")), modele_api=str(x.get("modele_api", "")), categorie=str(x.get("categorie", "")))
        roles[r.id] = r
    if "auditeur" not in roles:
        raise ValueError("Le rôle « auditeur » est obligatoire.")
    return roles


def select_producer(roles: dict[str, Role], target_type: str, request: str, forced: str = "") -> Role:
    if forced:
        if forced not in roles or forced == "auditeur":
            raise ValueError(f"Rôle producteur invalide : {forced}")
        return roles[forced]
    words = set(re.findall(r"[\wÀ-ÿ+#]+", request.lower()))
    best, best_score = None, -1.0
    for r in roles.values():
        if r.id == "auditeur":
            continue
        score = 2.0 * sum(1 for k in r.mots_cles if k.lower() in words or (" " in k and k.lower() in request.lower()))
        score += 1.5 if target_type in r.domaines else 0.0
        if score > best_score:
            best, best_score = r, score
    return best  # type: ignore[return-value]
