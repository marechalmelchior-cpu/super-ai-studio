"""Specialized roles (``Studio/roles/*.toml`` files).

A role receives a bounded mission: allowed context, tools, deliverables,
success criteria, limits. Selection only engages the useful producer role
+ the auditor; other roles are not launched without a concrete benefit.
"""
from __future__ import annotations

import re
import tomllib
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class Role:
    id: str
    nom: str
    domains: list[str]
    keywords: list[str]
    executeur: str
    allowed_tools: list[str]
    deliverables: list[str]
    criteria: list[str]
    limits: list[str]
    enabled: bool = True
    guidance: str = ""
    read_only: bool = False
    modele: str = ""          # role's default model (tool alias), tuned for efficiency and speed
    effort: str = ""          # default effort: low | medium | high | xhigh | max
    extra: dict = field(default_factory=dict)
    connection: str = ""       # role-specific connected AI (API key or local); empty = the agents' one
    api_model: str = ""      # this AI's model for the role
    category: str = ""       # text | code | image | video | voice (roles created by the assistant)
    projects_list: list[str] = field(default_factory=list)   # agent specific to these projects (« project:rpg3d »); empty = all


def load_roles(d: Path) -> dict[str, Role]:
    roles = {}
    for f in sorted(Path(d).glob("*.toml")):
        with open(f, "rb") as fh:
            x = tomllib.load(fh)
        r = Role(id=x["id"], nom=x["nom"], domains=x.get("domaines", []), keywords=x.get("mots_cles", []),
                 executeur=x.get("executeur", "claude-code"), allowed_tools=x.get("outils", []),
                 deliverables=x.get("livrables", []), criteria=x.get("criteres", []), limits=x.get("limites", []),
                 enabled=x.get("enabled", True) is not False,
                 guidance=x.get("consignes", ""), read_only=x.get("lecture_seule", False),
                 modele=str(x.get("modele", "")),
                 effort=str(x.get("effort", "")) if x.get("effort") in ("low", "medium", "high", "xhigh", "max") else "",
                 connection=str(x.get("connexion", "")), api_model=str(x.get("modele_api", "")), category=str(x.get("categorie", "")),
                 projects_list=[str(v) for v in x.get("projets", []) if isinstance(v, str)])
        roles[r.id] = r
    if "auditeur" not in roles:
        raise ValueError("Le rôle « auditeur » est obligatoire.")
    return roles


def select_producer(roles: dict[str, Role], target_type: str, request: str, forced: str = "") -> Role:
    if forced:
        if forced not in roles or forced == "auditeur":
            raise ValueError(f"Rôle producteur invalide : {forced}")
        return roles[forced]
    words = set(re.findall(r"[\wÀ-ÿ+#]+", request.lower()))
    best, best_score = None, -1.0
    for r in roles.values():
        if r.id == "auditeur":
            continue
        score = 2.0 * sum(1 for k in r.keywords if k.lower() in words or (" " in k and k.lower() in request.lower()))
        score += 1.5 if target_type in r.domains else 0.0
        if score > best_score:
            best, best_score = r, score
    return best  # type: ignore[return-value]
