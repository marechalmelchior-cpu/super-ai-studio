"""Unreal editor and unreal-mcp server, ready BEFORE the agent's session.

The agent tool only connects to an MCP server when its session starts (a few attempts over ~10 s, then never
again). But unreal-mcp is hosted by the editor itself (http://127.0.0.1:8000/mcp). If the editor is not
open — or is still loading — when the task starts, the agent has no Unreal for the whole task (ECONNREFUSED).
RPG3D's Scripts/editor/start_session.ps1 does this for a manual session; the studio does the same:

1. real MCP handshake (« initialize »): an open port is not enough;
2. if it fails and no editor is open on this project: launch UnrealEditor.exe "<projet>.uproject";
   an editor already open is never relaunched (it is still loading);
3. wait for the MCP to answer (7 min at most, like the script); then the agent starts.
"""
from __future__ import annotations

import json
import os
import re
import subprocess
import time
import urllib.request
from pathlib import Path

URL = "http://127.0.0.1:8000/mcp"
DEFAULT_EDITOR = r"C:\Program Files\Epic Games\UE_5.8\Engine\Binaries\Win64\UnrealEditor.exe"
WORDS = ("unreal", "mcp", "éditeur", "editeur", "editor", "niveau", "level", "carte", " map", "acteur", "actor", "blueprint",
        "pie", "asset", "matériau", "materiau", "material", "widget", "umg", "mesh", "lumière", "éclairage", "eclairage",
        "spawn", "scène", "scene", "landscape", "niagara", "montage", "animation", "personnage", "caméra", "camera",
        "ouvre le projet", "ouvrir le projet", "uproject", "viewport", "capture")


def unreal_project(dossier: Path | None) -> Path | None:
    """The project's .uproject if it declares unreal-mcp in .mcp.json, otherwise None."""
    if not dossier or not (dossier / ".mcp.json").exists():
        return None
    try:
        if "unreal-mcp" not in (dossier / ".mcp.json").read_text(encoding="utf-8", errors="replace"):
            return None
    except OSError:
        return None
    up = sorted(dossier.glob("*.uproject"))
    return up[0] if up else None


EDITOR_STRONG = ("unreal-mcp", " mcp", " pie ", "(pie)", "spawn", "viewport", "capture d'écran", "capture d'ecran",
                 "landscape", "ouvre le projet", "ouvrir le projet", "dans la scène", "dans la scene", "dans l'éditeur",
                 "dans l'editeur")
EDITOR_WORDS = EDITOR_STRONG + ("niveau", "level", "acteur", "actor", "blueprint")
CODE_WORDS = ("source/", "c++", ".cpp", ".h ", " code", "renomm", "compil", "sans interface", "headless", "coreredirect")


def _has(t: str, words) -> bool:
    return any(re.search(r"(?<![a-z0-9_])" + re.escape(w.strip()) + r"(?![a-z0-9_])", t) if w.strip().isalpha() else w in t
               for w in words)


def unreal_request(texte: str) -> bool:
    """Does the task need the open editor (unreal-mcp)? Then the studio opens it BEFORE the agent's session. A code task
    (C++, renaming, build, headless tests) does not: opening the editor would only make it close and reopen later.
    Only the task's own request counts (not the previous chain step's report), whole words only (« Niveau100 » in a
    test name is not a level); a clear editor action wins, otherwise a code task wins over a passing mention."""
    t = " " + (texte or "").split("\n---\nÉtape ", 1)[0].lower() + " "
    if _has(t, EDITOR_STRONG):
        return True
    if _has(t, CODE_WORDS):
        return False
    if _has(t, EDITOR_WORDS):
        return True
    return any(m in t for m in WORDS if m.strip() not in ("unreal", "uproject"))


def mcp_ready(url: str = URL, delay: float = 10) -> bool:
    content_body = json.dumps({"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {
        "protocolVersion": "2025-06-18", "capabilities": {}, "clientInfo": {"name": "studio", "version": "1"}}}).encode()
    req = urllib.request.Request(url, data=content_body, method="POST", headers={
        "Content-Type": "application/json", "Accept": "application/json, text/event-stream"})
    try:
        with urllib.request.urlopen(req, timeout=delay) as r:
            return r.status == 200 and b"protocolVersion" in r.read(65536)
    except Exception:                                   # noqa: BLE001 — refused, timeout, editor busy: not ready
        return False


def editor_open(project_name: str) -> bool:
    """An UnrealEditor.exe whose command line mentions this project (Windows)."""
    if os.name != "nt":
        return False
    from .connectors.base import NO_WINDOW
    ps = ("Get-CimInstance Win32_Process -Filter \"Name = 'UnrealEditor.exe'\" | "
          f"Where-Object {{ $_.CommandLine -like '*{re.sub(r'[^A-Za-z0-9_-]', '', project_name)}*' }} | "
          "Select-Object -First 1 -ExpandProperty ProcessId")
    try:
        r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", ps], capture_output=True,
                           text=True, timeout=30, stdin=subprocess.DEVNULL, **NO_WINDOW)
        return bool(r.stdout.strip())
    except (OSError, subprocess.TimeoutExpired):
        return False


def editor_path(cfg: dict) -> Path:
    """UnrealEditor.exe next to the UnrealEditor-Cmd.exe set in Superviseur › Réglages, otherwise the usual path."""
    c = str(cfg.get("outils", {}).get("unreal_editor_cmd", "") or cfg.get("outils", {}).get("unreal", "") or "")
    if c:
        from pathlib import PureWindowsPath
        w = PureWindowsPath(c)
        if w.name.lower().startswith("unrealeditor"):
            w = w.with_name("UnrealEditor.exe")
        return Path(str(w))
    return Path(DEFAULT_EDITOR)


def prepare(uproject: Path, cfg: dict, jot, cancelled=lambda: False, wait_s: float = 420) -> bool:
    """Makes unreal-mcp reachable before the session. noter(texte) writes to the task log. True if ready."""
    if mcp_ready():
        jot("Unreal : serveur unreal-mcp déjà en ligne")
        return True
    if os.name != "nt":
        jot("Unreal : serveur unreal-mcp injoignable (pas sous Windows : éditeur non lancé)")
        return False
    if editor_open(uproject.stem):
        jot("Unreal : éditeur déjà ouvert sur le projet, attente de son serveur MCP (il finit de charger)")
    else:
        exe = editor_path(cfg)
        if not exe.exists():
            jot(f"Unreal : UnrealEditor.exe introuvable ({exe}) — règle le chemin dans Superviseur › Réglages")
            return False
        from .connectors.base import NO_WINDOW
        flags = {k: v for k, v in NO_WINDOW.items() if k != "creationflags"}
        subprocess.Popen([str(exe), str(uproject)], cwd=str(uproject.parent), stdin=subprocess.DEVNULL,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                         creationflags=getattr(subprocess, "DETACHED_PROCESS", 0) | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0),
                         close_fds=True, **flags)
        jot(f"Unreal : éditeur lancé sur {uproject.name}, attente du serveur MCP (7 min au plus)")
    begin = time.monotonic()
    while time.monotonic() - begin < wait_s:
        if cancelled():
            return False
        time.sleep(3)
        if mcp_ready():
            jot(f"Unreal : serveur unreal-mcp en ligne après {int(time.monotonic() - begin)} s")
            return True
    jot("Unreal : le serveur unreal-mcp ne répond toujours pas — la tâche démarre sans lui")
    return False


# ------------------------------------------------------------------ close cleanly, build, reopen
def _editor_pids(project_name: str) -> list[int]:
    if os.name != "nt":
        return []
    from .connectors.base import NO_WINDOW
    ps = ("Get-CimInstance Win32_Process -Filter \"Name = 'UnrealEditor.exe'\" | "
          f"Where-Object {{ $_.CommandLine -like '*{re.sub(r'[^A-Za-z0-9_-]', '', project_name)}*' }} | "
          "Select-Object -ExpandProperty ProcessId")
    try:
        r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", ps], capture_output=True,
                           text=True, timeout=30, stdin=subprocess.DEVNULL, **NO_WINDOW)
        return [int(x) for x in r.stdout.split() if x.strip().isdigit()]
    except (OSError, subprocess.TimeoutExpired):
        return []


PIE_START = re.compile(r"PIE: Created PIE world")
PIE_END = re.compile(r"Shutting down PIE online subsystems|BeginTearingDown for \S*UEDPIE_")


def pie_running(uproject: Path) -> bool:
    """A PIE is running in this project's editor: its last start in the log is more recent than its last end.
    Read-only on the end of Saved/Logs/<projet>.log."""
    log = Path(uproject).parent / "Saved" / "Logs" / f"{Path(uproject).stem}.log"
    try:
        with log.open("rb") as f:
            f.seek(0, 2)
            f.seek(max(0, f.tell() - 4_000_000))
            texte = f.read().decode("utf-8", errors="replace")
    except OSError:
        return False
    starts = [m.start() for m in PIE_START.finditer(texte)]
    ends = [m.start() for m in PIE_END.finditer(texte)]
    return bool(starts) and starts[-1] > (ends[-1] if ends else -1)


def close_editor(project_name: str, jot, wait_s: float = 120) -> bool:
    """Closes the editor open on this project like clicking its close button (CloseMainWindow). NEVER a forced close:
    if unsaved changes remain, Unreal asks what to do and stays open → False, nothing is lost."""
    pids = _editor_pids(project_name)
    if not pids:
        jot("Unreal : éditeur déjà fermé")
        return True
    from .connectors.base import NO_WINDOW
    ps = "; ".join(f"$p = Get-Process -Id {p} -ErrorAction SilentlyContinue; if ($p) {{ [void]$p.CloseMainWindow() }}" for p in pids)
    subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", ps], capture_output=True, text=True,
                   timeout=30, stdin=subprocess.DEVNULL, **NO_WINDOW)
    jot("Unreal : fermeture demandée à l'éditeur (comme la croix de sa fenêtre)")
    begin = time.monotonic()
    while time.monotonic() - begin < wait_s:
        time.sleep(3)
        if not _editor_pids(project_name):
            jot(f"Unreal : éditeur fermé après {int(time.monotonic() - begin)} s")
            return True
    jot("Unreal : l'éditeur est resté ouvert — il demande sans doute d'enregistrer des modifications. Rien n'a été "
          "forcé : réponds dans l'éditeur (ou ferme-le toi-même), puis relance la compilation.")
    return False


def build_cmd(cfg: dict, uproject: Path, cible: str = "") -> list[str]:
    """Build.bat <Projet>Editor Win64 Development -project=… (engine derived from the configured UnrealEditor path)."""
    from pathlib import PureWindowsPath
    engine = PureWindowsPath(str(editor_path(cfg))).parents[2]          # …\Engine
    bat = engine / "Build" / "BatchFiles" / "Build.bat"
    return [str(bat), cible or f"{uproject.stem}Editor", "Win64", "Development", f"-project={uproject}", "-waitmutex"]


LIVE_CODING = re.compile(r"Live Coding is active|Unable to build while Live Coding", re.I)


def _same_file(a, b) -> bool | None:
    try:
        return Path(a).resolve() == Path(b).resolve()
    except OSError:
        return None


def editor_open_on(uproject: Path) -> bool:
    """An editor open on THIS .uproject (full path in its command line), not just a project with the same name."""
    if os.name != "nt":
        return False
    from .connectors.base import NO_WINDOW
    folder = str(Path(uproject).parent).replace("'", "''").replace("[", "`[").replace("]", "`]")
    ps = ("Get-CimInstance Win32_Process -Filter \"Name = 'UnrealEditor.exe'\" | "
          f"Where-Object {{ ($_.CommandLine -replace '/', '\\') -like '*{folder}*' }} | Select-Object -First 1 -ExpandProperty ProcessId")
    try:
        r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", ps], capture_output=True,
                           text=True, timeout=30, stdin=subprocess.DEVNULL, **NO_WINDOW)
        return bool(r.stdout.strip())
    except (OSError, subprocess.TimeoutExpired):
        return True                                     # unknown: the safe path (close first) is taken


def run_compile(uproject: Path, cfg: dict, jot, cible: str = "", rouvrir: Path | None = None,
             journal: Path | None = None, delay_s: float = 3600) -> dict:
    """Closes the editor cleanly, builds, then (if ``rouvrir``) reopens the editor on this project and waits for unreal-mcp.
    Codes: 0 built; 2 build failed; 3 editor stayed open (changes to save); 4 tool missing;
    5 a PIE is running: nothing is closed (the studio never stops a PIE)."""
    for up in {Path(uproject), *([Path(rouvrir)] if rouvrir else [])}:
        if editor_open(up.stem) and pie_running(up):
            jot("Unreal : un PIE tourne dans l'éditeur — rien n'est fermé ni compilé. Arrêter le PIE d'abord (un agent : "
                  "seulement si l'utilisateur l'a autorisé), puis relancer la compilation.")
            return {"code": 5, "message": "un PIE tourne : l'éditeur n'a pas été fermé (arrêter le PIE d'abord)"}
    cmd = build_cmd(cfg, uproject, cible)
    if os.name == "nt" and not Path(cmd[0]).exists():
        jot(f"Unreal : Build.bat introuvable ({cmd[0]})")
        return {"code": 4, "message": f"Build.bat introuvable : {cmd[0]}"}
    from .connectors.base import NO_WINDOW

    def build() -> tuple[str, int]:
        try:
            r = subprocess.run(cmd, cwd=str(uproject.parent), capture_output=True, text=True, encoding="utf-8",
                               errors="replace", timeout=delay_s, stdin=subprocess.DEVNULL, **NO_WINDOW)
            return (r.stdout or "") + (r.stderr or ""), r.returncode
        except subprocess.TimeoutExpired:
            return "délai dépassé", -1
        except OSError as e:
            return str(e), -1

    copy = bool(rouvrir) and _same_file(uproject, rouvrir) is False
    was_open = bool(rouvrir) and editor_open(Path(rouvrir).stem)      # reopened afterwards only if it was open
    begin = time.monotonic()
    output, code_build, closed = "", None, False
    if copy and was_open and not editor_open_on(uproject):
        # a task's copy has its own binaries: the user's editor is closed only if Unreal requires it (Live Coding active)
        jot(f"Unreal : compilation de {cmd[1]} ({uproject.name}, copie de la tâche) sans fermer ton éditeur")
        output, code_build = build()
        if code_build != 0 and LIVE_CODING.search(output):
            jot("Unreal : Live Coding actif dans ton éditeur, Unreal refuse de compiler pendant ce temps : fermeture propre puis nouvel essai")
            code_build = None
    if code_build is None:
        if not close_editor(uproject.stem, jot) or (rouvrir and not close_editor(Path(rouvrir).stem, jot)):
            return {"code": 3, "message": "éditeur resté ouvert (modifications non enregistrées ?) : rien n'a été forcé"}
        closed = True
        jot(f"Unreal : compilation de {cmd[1]} ({uproject.name})")
        output, code_build = build()
    if journal:
        Path(journal).parent.mkdir(parents=True, exist_ok=True)
        Path(journal).write_text(output, encoding="utf-8")
    error_list = [l.strip() for l in output.splitlines() if re.search(r"\berror\b|Result: Failed|Unable to build", l)][:12]
    ok = code_build == 0
    jot(f"Unreal : compilation {'réussie' if ok else 'en échec (code ' + str(code_build) + ')'} en {int(time.monotonic() - begin)} s")
    res = {"code": 0 if ok else 2, "message": "compilé" if ok else "compilation en échec", "erreurs": error_list,
           "journal": str(journal or "")}
    if rouvrir and was_open and closed:
        res["mcp"] = prepare(Path(rouvrir), cfg, jot)
    elif rouvrir and was_open:
        jot("Unreal : ton éditeur est resté ouvert pendant la compilation")
    elif rouvrir:
        jot("Unreal : l'éditeur n'était pas ouvert avant la compilation, il reste fermé")
    return res
