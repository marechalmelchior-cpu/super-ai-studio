"""Per-project team: roles stay shared (Studio/roles), each project tunes its own.

For each project (data/equipes.json):
- per role: enabled or not, model, effort, project-specific instructions (added to the mission);
- MCP servers enabled in this project (no setting: the general ones from Extensions, and an engine's server only
  for a project that uses that engine — e.g. unreal-mcp only for an Unreal project);
- project-specific agents: roles whose card has ``projets = ["project:x"]`` (offered only there).
Order of choices for a task: the request > the project team > the role setting > the preset.
"""
from __future__ import annotations

import json
import os
import re
from pathlib import Path

EFFORTS = ("", "low", "medium", "high", "xhigh", "max")


def _f(data: Path) -> Path:
    return Path(data) / "equipes.json"


def read_file(data: Path) -> dict:
    try:
        d = json.loads(_f(data).read_text(encoding="utf-8"))
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def _write(data: Path, d: dict) -> None:
    f = _f(data)
    f.parent.mkdir(parents=True, exist_ok=True)
    t = f.with_suffix(".tmp")
    t.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
    os.replace(t, f)


def setting(data: Path, cible: str, role_id: str) -> dict:
    return ((read_file(data).get(cible) or {}).get("roles") or {}).get(role_id) or {}


def active(data: Path, cible: str, role) -> bool:
    if role.projects_list and cible not in role.projects_list:
        return False
    return setting(data, cible, role.id).get("actif", role.enabled) is not False


def project_roles(roles: dict, data: Path, cible: str) -> dict:
    """Roles offered for this project (the auditor always stays)."""
    return {k: r for k, r in roles.items() if k == "auditeur" or active(data, cible, r)}


def project_mcp(data: Path, cible: str) -> list[str] | None:
    v = (read_file(data).get(cible) or {}).get("mcp")
    return [str(x) for x in v] if isinstance(v, list) else None


ENGINE_MCP = {"unreal": (".uproject",), "blender": (".blend",), "godot": ("project.godot",)}   # name part → marker files


def relevant_mcp(name: str, target) -> bool:
    """General servers are useful everywhere; an engine's server only where that engine is used."""
    engine = next((e for e in ENGINE_MCP if e in name.lower()), "")
    if not engine:
        return True
    if engine in str(getattr(target, "type", "")).lower():
        return True
    p = target.path() if getattr(target, "has_path", False) else None
    try:
        return bool(p and p.is_dir() and any(f.name.endswith(ENGINE_MCP[engine]) or f.name in ENGINE_MCP[engine] for f in p.iterdir()))
    except OSError:
        return False


def effective_mcp(studio, target) -> list[str]:
    """MCP servers a task of this project gets: the project's own choice, otherwise the relevant installed ones."""
    from .library import installed_mcp
    cible = f"{target.kind}:{target.id}"
    chosen = project_mcp(studio.paths.data, cible)
    if chosen is not None:
        return chosen
    return [n for n in sorted(installed_mcp(studio.paths.data)) if relevant_mcp(n, target)]


def configure_role(studio, cible: str, role_id: str, field_values: dict) -> dict:
    if role_id not in studio.roles or (role_id == "auditeur" and field_values.get("actif") is False):
        raise ValueError("Métier inconnu.")
    if "ai" in field_values:
        validate_ai(studio, str(field_values["ai"] or ""))
    d = read_file(studio.paths.data)
    r = d.setdefault(cible, {}).setdefault("roles", {}).setdefault(role_id, {})
    if "ai" in field_values:
        r["ai"] = str(field_values["ai"] or "")
    if "actif" in field_values:
        r["actif"] = bool(field_values["actif"])
    if "modele" in field_values:
        m = str(field_values["modele"] or "")
        if not re.fullmatch(r"[A-Za-z0-9._:/@-]{0,100}", m):
            raise ValueError("Modèle invalide.")
        r["modele"] = m
    if "effort" in field_values:
        if field_values["effort"] not in EFFORTS:
            raise ValueError("Effort invalide.")
        r["effort"] = field_values["effort"]
    if "consignes" in field_values:
        c = str(field_values["consignes"] or "").strip()
        if len(c) > 4000:
            raise ValueError("Consignes trop longues (4000 caractères).")
        r["consignes"] = c
    d[cible]["roles"][role_id] = {k: v for k, v in r.items() if v not in ("", None) or k == "actif"}
    if d[cible]["roles"][role_id] == {"actif": True} and studio.roles[role_id].enabled:
        d[cible]["roles"].pop(role_id)
    _write(studio.paths.data, d)
    return project_view(studio, cible)


def configure_mcp(studio, cible: str, names: list[str] | None) -> dict:
    d = read_file(studio.paths.data)
    if names is None:
        d.setdefault(cible, {}).pop("mcp", None)
    else:
        d.setdefault(cible, {})["mcp"] = [str(n) for n in names if re.fullmatch(r"[a-z0-9-]{1,60}", str(n))]
    _write(studio.paths.data, d)
    return project_view(studio, cible)


def project_view(studio, cible: str) -> dict:
    """Project team: each role with its settings (project and shared), and the enabled MCP servers."""
    from .library import installed_mcp
    eq = (read_file(studio.paths.data).get(cible) or {})
    out = []
    for r in sorted(studio.roles.values(), key=lambda x: x.nom.lower()):
        if r.projects_list and cible not in r.projects_list:
            continue
        g = (eq.get("roles") or {}).get(r.id) or {}
        out.append({"id": r.id, "nom": r.nom, "outil": r.executeur, "actif": r.id == "auditeur" or g.get("actif", r.enabled) is not False,
                    "modele": g.get("modele", ""), "effort": g.get("effort", ""), "consignes": g.get("consignes", ""),
                    "modele_commun": studio.execution_model(r, {}, cible, inherit_project=False),
                    "effort_commun": studio.efforts().get(r.id, "") or studio._preset_effort(r, cible),
                    **editor_view(studio, r, cible),
                    "propre": bool(r.projects_list), "personnalise": bool({k for k in g if k != "actif"} or g.get("actif") is False)})
    servers = sorted(installed_mcp(studio.paths.data))
    choice = eq.get("mcp")
    try:
        active_now = set(effective_mcp(studio, studio.registry.get(cible)))
    except (KeyError, ValueError):
        active_now = set(choice or [])
    return {"cible": cible, "roles": out, "mcp": [{"nom": n, "actif": n in active_now} for n in servers],
            "mcp_regle": isinstance(choice, list)}


def board(studio) -> dict:
    """Management view: projects × roles (enabled, customized, working)."""
    act = {}
    for a in studio.activity():
        act.setdefault(a["target"], {})[a["role"]] = a["etat"]
    projects_list = [t for t in studio.registry.all()]
    cols = []
    for t in projects_list:
        cle = f"{t.kind}:{t.id}"
        v = project_view(studio, cle)
        enc = act.get(cle, {}) or act.get(t.id, {})
        cols.append({"cle": cle, "nom": t.nom, "profil": studio.profile(cle), "roles": {r["id"]: {"actif": r["actif"], "personnalise": r["personnalise"],
                                                                  "propre": r["propre"], "etat": enc.get(r["id"], "")} for r in v["roles"]}})
    roles = [{"id": r.id, "nom": r.nom} for r in sorted(studio.roles.values(), key=lambda x: x.nom.lower()) if r.id != "auditeur"]
    return {"projets": cols, "roles": roles}


def validate_ai(studio, choice: str) -> None:
    """Même validation pour une sélection commune ou propre au projet."""
    from .agents import connected_sources
    if choice and choice not in {source["id"] for source in connected_sources(studio)}:
        raise ValueError("IA inconnue : connecte-la d'abord dans les réglages.")


def editor_view(studio, role, cible: str = "") -> dict:
    """Choix de l'éditeur issus des connexions et des capacités déjà déclarées."""
    from . import ai
    from .agents import connected_sources
    sources = connected_sources(studio)
    planned, connection = studio.role_ai(role, {}, cible)
    tool = studio._executor(planned)[0]
    if tool == "api" and not connection and planned != tool:
        connection = studio._best_connection(role)
    source = next((s for s in sources if s["id"] == (connection or tool)), {})
    executor = studio.executors.get(tool)
    models = list(executor.models()) if callable(getattr(executor, "models", None)) else []
    if not connection and not models:
        models = list(dict.fromkeys(r.modele for r in studio.roles.values() if r.executeur == tool and r.modele))
        models += [m for m in studio.choice()["modeles"] if m not in models]
    model = studio.execution_model(role, {}, cible)
    if connection and not model:
        model = role.api_model or source.get("modele", "")
    shared_model = studio.execution_model(role, {}, cible, inherit_project=False)
    model_label = studio.exact_name(tool, model) or model or source.get("modele", "") or "modèle de l'outil"
    shared_label = studio.exact_name(tool, shared_model) or shared_model or source.get("modele", "") or "modèle de l'outil"
    model_label = model_label[:1].upper() + model_label[1:] if model_label.islower() else model_label
    shared_label = shared_label[:1].upper() + shared_label[1:] if shared_label.islower() else shared_label
    source_options = {}
    for entry in sources:
        source_executor = studio.executors.get(entry["id"])
        entries = list(source_executor.models()) if callable(getattr(source_executor, "models", None)) else (
            studio.choice()["modeles"] if source_executor else [])
        source_options[entry["id"]] = {"models": [[m, m[:1].upper() + m[1:] if m.islower() else m] for m in entries],
                                       "efforts": [list(e) for e in ai.AI_EFFORTS.get(entry["id"] if source_executor else entry.get("fournisseur", ""), ())],
                                       "connection": "" if source_executor else entry["id"]}
    project = setting(studio.paths.data, cible, role.id) if cible else {}
    shared_tool, shared_connection = studio.role_ai(role)
    inherited = source_options.get(shared_connection or shared_tool) or {
        "models": [[m, m] for m in models], "efforts": [list(e) for e in ai.AI_EFFORTS.get(tool, ())], "connection": connection}
    return {"source_options": source_options, "default_source_options": inherited,"ai": project.get("ai", "") if cible else studio.ai_roles().get(role.id, ""),
            "ai_options": [[s["id"], s["nom"]] for s in sources],
            "model_options": [[m, m[:1].upper() + m[1:] if m.islower() else m] for m in models],
            "effort_options": [list(e) for e in ai.AI_EFFORTS.get(tool if not connection else source.get("fournisseur", ""), ())],
            "connection": connection, "effective_tool": tool, "effective_model": model,
            "model_label": model_label, "shared_model_label": shared_label,
            "locked_active": role.id == "auditeur"}


def configure_common_role(studio, role_id: str, field_values: dict) -> dict:
    """Consignes et activation dans la fiche TOML existante ; autres réglages sur leurs routes historiques."""
    import tomllib
    from dataclasses import replace
    if role_id not in studio.roles:
        raise ValueError("Métier inconnu.")
    role = studio.roles[role_id]
    if role_id == "auditeur" and field_values.get("actif") is False:
        raise ValueError("Le relecteur reste actif.")
    guidance = str(field_values.get("consignes", role.guidance) or "").strip()
    if len(guidance) > 4000:
        raise ValueError("Consignes trop longues (4000 caractères).")
    # Le fichier est retrouvé par son identifiant interne, jamais construit depuis une entrée utilisateur.
    path = next((p for p in studio.paths.roles.glob("*.toml")
                 if tomllib.loads(p.read_text(encoding="utf-8")).get("id") == role_id), None)
    if path is None:
        raise ValueError("Fiche du métier introuvable.")
    enabled = bool(field_values.get("actif", role.enabled))
    source = path.read_text(encoding="utf-8")
    # Le parseur délimite aussi les anciennes chaînes multilignes, sans toucher aux autres champs.
    lines = source.splitlines(keepends=True)
    for key, value in (("consignes", guidance), ("enabled", enabled)):
        start = next((i for i, line in enumerate(lines) if re.match(r"^" + key + r"\s*=", line)), None)
        replacement = key + " = " + json.dumps(value, ensure_ascii=False) + "\n"
        if start is None:
            table = next((i for i, line in enumerate(lines) if line.lstrip().startswith("[")), len(lines))
            if table and not lines[table - 1].endswith("\n"):
                lines[table - 1] += "\n"
            lines.insert(table, replacement)
        else:
            end = start + 1
            while True:
                try:
                    tomllib.loads("".join(lines[start:end]))
                    break
                except tomllib.TOMLDecodeError:
                    if end >= len(lines):
                        raise ValueError("Consignes de la fiche illisibles.")
                    end += 1
            lines[start:end] = [replacement]
    updated = "".join(lines)
    tomllib.loads(updated)
    temp = path.with_suffix(".tmp")
    temp.write_text(updated, encoding="utf-8")
    os.replace(temp, path)
    studio.roles[role_id] = replace(role, guidance=guidance, enabled=enabled)
    return {"ok": True}
