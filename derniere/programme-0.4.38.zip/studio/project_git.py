"""Git and GitHub for projects — Gestion tab and status line of the project page.

Everything goes through git directly (instant, no agent, no tokens used):
- reading: current branch, modified files, ahead / behind GitHub, local branches (merged or not,
  linked studio task, working copy), remote repo address without credentials;
- actions, each on a user click (the click is the consent): refresh (fetch), pull (pull --ff-only),
  push the current branch, create a pull request (if the gh tool is installed), delete an ALREADY
  merged branch (git branch -d, never -D: nothing is lost).
- LOCAL commit of the files checked by the user (never a push), merge of a task branch.
Never: force push, reset, rebase, deleting an unmerged branch, switching branches.
"""
from __future__ import annotations

import re
import shutil
from pathlib import Path

from .connectors import workspace as ws
from .orchestrator.store import TERMINAL
from .security import redact


def _git_exe(studio) -> str:
    return studio.cfg["outils"].get("git", "git")


def repositories(studio) -> list:
    """Projects whose folder is a git repository."""
    return [c for c in studio.registry.all()
            if c.kind == "project" and c.has_path and c.path().is_dir() and (c.path() / ".git").exists()]


def _target(studio, cle: str):
    for c in repositories(studio):
        if f"{c.kind}:{c.id}" == cle:
            return c
    raise ValueError("Ce projet n'est pas un dépôt git.")


def _check_task_target(studio, target, tid):
    task = studio.store.get(tid)
    actual = studio.registry.get(task["target"])
    if (actual.kind, actual.id) != (target.kind, target.id):
        raise ValueError("La tâche appartient à un autre projet.")


def public_address(url: str) -> str:
    """Remote repo address without identifier or token; https link for GitHub."""
    url = re.sub(r"//[^/@]+@", "//", url.strip())
    m = re.match(r"^(?:git@github\.com:|https://github\.com/)([^/]+/[^/]+?)(?:\.git)?/?$", url)
    return f"https://github.com/{m.group(1)}" if m else redact(url)


def _tracking(texte: str) -> tuple[int, int]:
    a = re.search(r"ahead (\d+)", texte or ""); b = re.search(r"behind (\d+)", texte or "")
    return (int(a.group(1)) if a else 0, int(b.group(1)) if b else 0)


def etat(studio, cible) -> dict:
    git, d = _git_exe(studio), cible.path()
    out = {"cible": f"{cible.kind}:{cible.id}", "nom": cible.nom, "branche": "", "detache": False, "modifies": [],
           "en_avance": 0, "en_retard": 0, "amont": "", "distant": "", "erreur": ""}
    try:
        st = ws._git(git, d, "status", "--porcelain=v1", "--branch", "--untracked-files=normal", timeout=60)
    except ws.WorktreeError as e:
        out["erreur"] = redact(str(e))[:300]
        return out
    rows = st.splitlines()
    head = rows[0][3:] if rows and rows[0].startswith("## ") else ""
    if head.startswith("HEAD (no branch)") or head.startswith("HEAD détachée"):
        out["detache"] = True
    else:
        nom = head.split("...")[0].split(" ")[0]
        out["branche"] = nom.replace("No commits yet on ", "")
        if "..." in head:
            out["amont"] = head.split("...")[1].split(" ")[0]
        out["en_avance"], out["en_retard"] = _tracking(head)
    out["modifies"] = [l[3:] for l in rows[1:] if l.strip()][:200]
    try:
        out["distant"] = public_address(ws._git(git, d, "remote", "get-url", "origin", timeout=20).strip())
    except ws.WorktreeError:
        pass
    return out


def _branch_origins(studio, git: str, repo: Path, branches: list[dict], base: str) -> None:
    """Départ réel de chaque branche ; les champs historiques du graphe restent inchangés."""
    names = {branch["nom"] for branch in branches}
    for branch in branches:
        name = branch["nom"]
        branch.update(parent_branch=base if name != base else "", fork_commit="",
                      own_commits=0, parent_commits_after_fork=0)
        try:
            branch["fork_commit"] = ws._git(git, repo, "merge-base", base, name, timeout=30).strip()
            task = branch.get("tache")
            if task:
                try:
                    options = studio.store.get(task["id"]).get("options") or {}
                except KeyError:
                    options = {}
                start = options.get("start_commit") or options.get("depart_commit")
                previous = options.get("start_task") or options.get("depart_tache")
                parent = f"studio/{previous}" if previous else ""
                if start and parent in names and parent != name and not ws._succeeds(
                        git, repo, "merge-base", "--is-ancestor", parent, base):
                    commit = ws._git(git, repo, "rev-parse", "--verify", f"{start}^{{commit}}").strip()
                    if ws._succeeds(git, repo, "merge-base", "--is-ancestor", commit, parent) and ws._succeeds(
                            git, repo, "merge-base", "--is-ancestor", commit, name):
                        branch["parent_branch"], branch["fork_commit"] = parent, commit
                        branch["parent_commits_after_fork"] = int(ws._git(
                            git, repo, "rev-list", "--count", f"{commit}..{parent}").strip())
            if branch["fork_commit"]:
                branch["own_commits"] = int(ws._git(
                    git, repo, "rev-list", "--count", f"{branch['fork_commit']}..{name}").strip())
        except (ws.WorktreeError, ValueError):
            # Une branche disparue pendant la lecture n'empêche pas l'affichage des autres.
            continue


def detail(studio, cle: str) -> dict:
    c = _target(studio, cle)
    git, d = _git_exe(studio), c.path()
    e = etat(studio, c)
    merged_branches = set()
    try:
        merged_branches = {l.strip(" *+") for l in ws._git(git, d, "branch", "--merged", "HEAD", timeout=60).splitlines()}
    except ws.WorktreeError:
        pass
    from . import actions
    copies = {x["tache"]: x for x in actions.workspaces(studio) if x["projet"] == c.nom}
    branches = []
    fmt = "%(refname:short)%09%(objectname:short)%09%(committerdate:iso8601)%09%(upstream:short)%09%(upstream:track)%09%(subject)"
    try:
        refs = ws._git(git, d, "for-each-ref", "--sort=-committerdate", f"--format={fmt}", "refs/heads", timeout=60)
    except ws.WorktreeError:
        refs = ""
    for l in refs.splitlines():
        p = (l.split("\t") + [""] * 6)[:6]
        nom = p[0]
        tache = None
        if nom.startswith("studio/"):
            tid = nom[len("studio/"):]
            try:
                t = studio.store.get(tid)
                tache = {"id": tid, "statut": t["status"], "titre": ((t.get("options") or {}).get("titre") or t["request"] or "")[:120]}
            except KeyError:
                tache = {"id": tid, "statut": "inconnue", "titre": ""}
        av, re_ = _tracking(p[4])
        branches.append({"nom": nom, "commit": p[1], "date": p[2][:16], "amont": p[3], "en_avance": av, "en_retard": re_,
                         "sujet": redact(p[5])[:160], "courante": nom == e["branche"],
                         "fusionnee": nom in merged_branches and nom != e["branche"], "tache": tache,
                         "copie": copies.get(tache["id"]) if tache else None})
    base = "main" if any(branch["nom"] == "main" for branch in branches) else (e["branche"] or "HEAD")
    _branch_origins(studio, git, d, branches, base)
    branches.sort(key=lambda b: (not b["courante"], b["fusionnee"]))   # current, then in progress, then merged (stable: most recent first)
    for b in branches:                          # graph: commits specific to the branch, and lead taken by the current branch
        if b["courante"] or b["fusionnee"]:
            continue
        try:
            g = ws._git(git, d, "rev-list", "--left-right", "--count", f"HEAD...{b['nom']}", timeout=30).split()
            b["derriere"], b["devant"] = int(g[0]), int(g[1])
        except (ws.WorktreeError, ValueError, IndexError):
            pass
    history_items = []
    try:
        for l in ws._git(git, d, "log", "-40", "--format=%h%x09%cs%x09%s", timeout=30).splitlines():
            h, date, sujet = (l.split("\t") + ["", ""])[:3]
            history_items.append({"commit": h, "date": date, "sujet": redact(sujet)[:120]})
    except ws.WorktreeError:
        pass
    to_push = None                            # commits not yet on GitHub (the merge squares disappear after Push)
    if e.get("amont"):
        try:
            to_push = []
            for l in ws._git(git, d, "log", "--format=%h%x09%cs%x09%s", "@{upstream}..HEAD", timeout=30).splitlines():
                h, date, sujet = (l.split("\t") + ["", ""])[:3]
                to_push.append({"commit": h, "date": date, "sujet": redact(sujet)[:120]})
            to_push.reverse()
        except ws.WorktreeError:
            to_push = None
    return {**e, "branches": branches, "historique": history_items[::-1], "a_pousser": to_push, "gh": bool(shutil.which("gh"))}


def entries(studio) -> list[dict]:
    return [etat(studio, c) for c in repositories(studio)]


# ---------------------------------------------------------------- actions (a user click = their consent)
NETWORK = {"actualiser": "Actualiser depuis GitHub", "recuperer": "Récupérer les nouveautés", "pousser": "Pousser vers GitHub",
          "pr": "Créer une pull request"}


def lancer(studio, jobs, cle: str, action: str) -> dict:
    """Network actions: in the background, visible in « Travaux ». Credentials stay Windows' own (never read)."""
    c = _target(studio, cle)
    git, d = _git_exe(studio), c.path()
    e = etat(studio, c)
    if action not in NETWORK:
        raise ValueError("Action inconnue.")
    if action != "actualiser" and (e["detache"] or not e["branche"]):
        raise ValueError("Le dépôt n'est pas sur une branche : rien n'est fait.")
    if action == "actualiser":
        cmd = [git, "fetch", "--prune", "origin"]
    elif action == "recuperer":
        if not e["amont"]:
            raise ValueError(f"La branche {e['branche']} ne suit aucune branche GitHub.")
        cmd = [git, "pull", "--ff-only"]                  # never a hidden merge or rebase
    elif action == "pousser":
        if e["en_retard"]:
            raise ValueError("GitHub a des commits que tu n'as pas : récupère d'abord (jamais de push forcé).")
        cmd = [git, "push"] if e["amont"] else [git, "push", "-u", "origin", e["branche"]]
    else:
        gh = shutil.which("gh")
        if not gh:
            raise ValueError("L'outil gh (GitHub CLI) n'est pas installé.")
        if not e["amont"] or e["en_avance"]:
            raise ValueError("Pousse d'abord la branche sur GitHub.")
        cmd = [gh, "pr", "create", "--fill", "--head", e["branche"]]
    nom = f"git:{c.id}:{action}"
    jobs.lancer(nom, f"{NETWORK[action]} — {c.nom} ({e['branche'] or 'origin'})", cmd, d, timeout_s=600)
    return {"travail": nom, "message": f"{NETWORK[action]} : lancé."}


FAILED_STATUSES = ("annulee", "echec", "bloquee", "interrompue")


def erase_branch(studio, cle: str, branch: str) -> dict:
    """Delete button of a red branch (task blocked, interrupted, failed or cancelled), on the user's click: the task is
    cancelled if needed, its working copy removed, then the branch deleted (git branch -D). Its unmerged work is
    lost: the interface says so beforehand. The Taches\\<tâche> folder (result, log) stays."""
    c = _target(studio, cle)
    git, d = _git_exe(studio), c.path()
    if not re.fullmatch(r"studio/[A-Za-z0-9._-]{1,120}", branch or ""):
        raise ValueError("Seules les branches des tâches du studio peuvent être effacées ici.")
    tid = branch[len("studio/"):]
    t = studio.store.get(tid)
    _check_task_target(studio, c, tid)
    if t["status"] not in FAILED_STATUSES:
        raise ValueError("Seule une tâche bloquée, interrompue, en échec ou annulée peut être effacée.")
    if t["status"] in ("bloquee", "interrompue"):
        studio.cancel(tid)
    user_workspace = studio.run_dir(tid) / ws.WORKSPACE
    if (user_workspace / ".git").is_file():
        ws._git(git, d, "worktree", "remove", "--force", str(user_workspace), timeout=600)
        (studio.run_dir(tid) / ws.READY_MARKER).unlink(missing_ok=True)
    if ws._git(git, d, "branch", "--list", branch).strip():
        ws._git(git, d, "branch", "-D", "--", branch, timeout=60)
    studio.store.event(tid, f"Branche {branch} effacée et copie retirée (par l'utilisateur depuis l'onglet Branches)")
    return {"message": f"Branche {branch} effacée ; la tâche reste dans l'historique (annulée)."}


def delete_branch(studio, cle: str, branch: str) -> dict:
    """Only a local branch already merged into the current branch (git branch -d): no commit lost."""
    c = _target(studio, cle)
    git, d = _git_exe(studio), c.path()
    if not re.fullmatch(r"[A-Za-z0-9._/-]{1,200}", branch or "") or branch.startswith("-"):
        raise ValueError("Nom de branche invalide.")
    e = etat(studio, c)
    if branch == e["branche"]:
        raise ValueError("C'est la branche courante.")
    if not ws._succeeds(git, d, "merge-base", "--is-ancestor", branch, "HEAD"):
        raise ValueError(f"{branch} n'est pas fusionnée : elle reste.")
    if branch.startswith("studio/"):
        tid = branch[len("studio/"):]
        try:
            t = studio.store.get(tid)
            _check_task_target(studio, c, tid)
            if t["status"] not in TERMINAL:
                raise ValueError("La tâche de cette branche n'est pas terminée.")
            if (studio.run_dir(tid) / ws.WORKSPACE / ".git").is_file():
                from . import actions
                return actions.remove_workspace(studio, tid)   # removes the copy then the merged branch
        except KeyError:
            pass
    ws._git(git, d, "branch", "-d", "--", branch, timeout=60)
    return {"message": f"Branche {branch} supprimée (elle était fusionnée : aucun commit perdu)."}


def delete_merged(studio, cle: str) -> dict:
    """All local branches already merged into the current branch, at once (git branch -d, never -D).
    A task branch with its working copy: the copy is removed along with it. A refused branch is left and reported."""
    d = detail(studio, cle)
    completed, left_over = [], []
    for b in d["branches"]:
        if not b["fusionnee"] or b["courante"]:
            continue
        try:
            delete_branch(studio, cle, b["nom"])
            completed.append(b["nom"])
        except (ValueError, ws.WorktreeError) as e:
            left_over.append(f"{b['nom']} ({str(e)[:120]})")
    msg = (f"{len(completed)} branche{'s' if len(completed) > 1 else ''} fusionnée{'s' if len(completed) > 1 else ''} supprimée{'s' if len(completed) > 1 else ''}"
           if completed else "Aucune branche fusionnée à supprimer")
    if left_over:
        msg += " ; laissées : " + ", ".join(left_over)
    return {"message": msg + ". Aucun commit perdu.", "supprimees": completed, "laissees": left_over}


# ---------------------------------------------------------------- commit and merge from the Branches tab
LARGE_FILE_DEFAULT = 50 * 1024 * 1024          # above this: unchecked by default (GitHub rejects files over 100 MB)
GITHUB_LIMIT = 100 * 1024 * 1024
_STATES = {"M": "modifié", "A": "ajouté", "D": "supprimé", "R": "renommé", "C": "copié", "?": "nouveau", "T": "modifié", "U": "en conflit"}


def to_commit(studio, cle: str) -> dict:
    """Modified or new files of the current branch, each with its size and a checked or unchecked box."""
    c = _target(studio, cle)
    git, d = _git_exe(studio), c.path()
    e = etat(studio, c)
    raw_text = ws._git(git, d, "status", "--porcelain=v1", "-z", "--untracked-files=all", timeout=120)
    chunks, task_files, i = raw_text.split("\0"), [], 0
    while i < len(chunks):
        m = chunks[i]
        i += 1
        if len(m) < 4:
            continue
        xy, chemin = m[:2], m[3:]
        if xy[0] in "RC":
            i += 1                                       # -z: the old name follows the new one
        code = (xy[1] if xy[1] not in " ?" else xy[0]) if xy != "??" else "?"
        p = d / chemin
        size_bytes = p.stat().st_size if p.is_file() else 0
        checked, reason = True, ""
        if size_bytes > LARGE_FILE_DEFAULT:
            checked, reason = False, (f"{size_bytes // (1024 * 1024)} Mo : " + ("trop gros pour GitHub (100 Mo max)"
                                                                          if size_bytes > GITHUB_LIMIT else "très gros, à confirmer"))
        if "U" in xy:
            checked, reason = False, "en conflit : à régler d'abord"
        task_files.append({"chemin": chemin, "etat": _STATES.get(code, code), "octets": size_bytes, "coche": checked, "raison": reason})
        if len(task_files) >= 500:
            break
    return {"branche": e["branche"], "detache": e["detache"], "fichiers": task_files}


def do_commit(studio, cle: str, paths: list[str], message: str = "") -> dict:
    """LOCAL commit of the files checked by the user on the current branch (never a push, never any other file)."""
    c = _target(studio, cle)
    git, d = _git_exe(studio), c.path()
    info = to_commit(studio, cle)
    if info["detache"] or not info["branche"]:
        raise ValueError("Le dépôt n'est pas sur une branche : rien n'est commité.")
    known = {f["chemin"]: f for f in info["fichiers"]}
    paths = [x for x in dict.fromkeys(paths or []) if x]
    if not paths:
        raise ValueError("Coche au moins un fichier.")
    unknown = [x for x in paths if x not in known]
    if unknown:
        raise ValueError("Fichiers qui ne sont plus modifiés (rafraîchis la liste) : " + ", ".join(unknown[:5]))
    too_big = [x for x in paths if known[x]["octets"] > GITHUB_LIMIT]
    if too_big:
        raise ValueError("Trop gros pour GitHub (plus de 100 Mo), décoche-les : " + ", ".join(too_big[:5]))
    message = " ".join((message or "").split())[:200] or (
        f"Studio : {len(paths)} fichier{'s' if len(paths) > 1 else ''} — " + ", ".join(Path(x).stem for x in paths[:3])
        + ("…" if len(paths) > 3 else ""))
    entries = "\0".join(paths) + "\0"
    ws.check_result_files(d, paths)
    ws._git(git, d, "add", "--pathspec-from-file=-", "--pathspec-file-nul", entry=entries, timeout=600)
    ws._git(git, d, "commit", "--no-verify", "-m", message, "--pathspec-from-file=-", "--pathspec-file-nul",
            entry=entries, timeout=600)
    sha = ws._git(git, d, "rev-parse", "--short", "HEAD").strip()
    return {"message": f"Commité sur {info['branche']} : {sha} — {message}. Rien n'est poussé vers GitHub.", "commit": sha}


def merge_branch(studio, cle: str, branch: str) -> dict:
    """Merge of a task branch (studio/…) into the current branch: same path as the task's button."""
    target = _target(studio, cle)
    if not re.fullmatch(r"studio/T\d{8}-\d{6}-[0-9a-f]{6}", branch or ""):
        raise ValueError("Seules les branches des tâches du studio se fusionnent ici.")
    from . import actions
    _check_task_target(studio, target, branch[len("studio/"):])
    return actions.merge(studio, branch[len("studio/"):])
