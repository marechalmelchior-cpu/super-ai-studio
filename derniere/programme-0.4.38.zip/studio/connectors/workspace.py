"""Isolated workspaces and consolidation.

- ``copie``: copy of the project in ``Taches/<tâche>/copie-de-travail`` (small projects, topics);
- ``worktree``: ``git worktree`` (large repositories) — modifies the .git metadata of the
  real project, so it requires per-project authorisation;
- ``lecture``: no writable space (real projects as long as nothing is authorised).
The result is a patch (diff) applied to the real project only after
approval, and only if the project's policy allows it.

A single exclusion list serves both the copy AND the fingerprint scans: a
folder that is not copied (Saved/, Binaries/…) never shows up as "deleted".
"""
from __future__ import annotations

import difflib
import fnmatch
import hashlib
import json
import os
import shutil
import stat
import tempfile
from datetime import datetime, timezone
from pathlib import Path

from .base import sha256_file

SKIP_NAMES = (".git", "__pycache__", ".pytest_cache", ".venv", "node_modules", "Binaries", "Intermediate",
              "DerivedDataCache", "Saved", ".mission-*", ".studio-tmp-*", "_pieces")
TEXT_MAX = 2_000_000


class ApplyRefused(RuntimeError):
    """Application refused before any write (project modified in the meantime, deletion…)."""


def _skipped(rel: str, exclude: list[str]) -> bool:
    parts = rel.split("/")
    if any(fnmatch.fnmatch(part, pat) for part in parts for pat in SKIP_NAMES):
        return True
    return any(rel == e.rstrip("/") or rel.startswith(e.rstrip("/") + "/") for e in exclude)


def snapshot(root: Path | None, exclude: list[str] | None = None) -> dict[str, str]:
    out: dict[str, str] = {}
    if root is None or not root.exists():
        return out
    exclude = exclude or []
    for dirpath, dirnames, filenames in os.walk(root):
        rel_dir = Path(dirpath).relative_to(root).as_posix()
        rel_dir = "" if rel_dir == "." else rel_dir + "/"
        dirnames[:] = [d for d in dirnames if not _skipped(rel_dir + d, exclude)]
        dirnames[:] = [d for d in dirnames if not _is_link(Path(dirpath) / d)]
        for f in filenames:
            rel = rel_dir + f
            if not _skipped(rel, exclude) and not _is_link(Path(dirpath) / f):
                out[rel] = sha256_file(Path(dirpath) / f)
    return dict(sorted(out.items()))


def prepare_copy(source: Path | None, dest: Path, exclude: list[str] | None = None) -> Path:
    if dest.exists():
        return dest
    if source is None:
        dest.mkdir(parents=True)
        return dest
    exclude = exclude or []

    def ignore(d, names):
        rel_dir = Path(d).relative_to(source).as_posix()
        return {n for n in names if _skipped(n if rel_dir == "." else f"{rel_dir}/{n}", exclude)
                or _is_link(Path(d) / n)}
    shutil.copytree(source, dest, ignore=ignore)
    return dest


def changes(before: dict[str, str], after: dict[str, str]) -> dict[str, list[str]]:
    return {"ajoutes": sorted(set(after) - set(before)),
            "supprimes": sorted(set(before) - set(after)),
            "modifies": sorted(k for k in set(before) & set(after) if before[k] != after[k])}


def unified_diff(src_root: Path | None, work_root: Path, ch: dict[str, list[str]]) -> str:
    chunks = []
    for rel in ch["modifies"] + ch["ajoutes"] + ch["supprimes"]:
        a = (src_root / rel) if src_root else None
        b = work_root / rel

        def lines(p):
            if p is None or not p.is_file() or p.stat().st_size > TEXT_MAX:
                return []
            try:
                return p.read_text(encoding="utf-8").splitlines(keepends=True)
            except UnicodeDecodeError:
                return [f"<fichier binaire {sha256_file(p)[:12]}>\n"]
        # a final line without a newline must not run into the next file's header (readable diff)
        chunks.extend(x if x.endswith("\n") else x + "\n" for x in difflib.unified_diff(lines(a), lines(b), f"a/{rel}", f"b/{rel}"))
    return "".join(chunks)


def result_hash(work_root: Path, files: list[str], summary: str) -> str:
    h = hashlib.sha256(summary.encode())
    for rel in sorted(files):
        p = work_root / rel
        h.update(rel.encode())
        h.update(sha256_file(p).encode() if p.is_file() else b"<supprime>")
    return h.hexdigest()


def check_result_files(root: Path, files: list[str]) -> None:
    """Refuse les secrets reconnaissables avant copie, archivage d'un livrable ou commit."""
    from ..project_page import safe_path
    from ..security import assert_no_secret
    for relative in files:
        try:
            path = safe_path(root, relative)
            with path.open("rb") as stream:
                previous = b""
                for chunk in iter(lambda: stream.read(1 << 20), b""):
                    combined = previous + chunk
                    assert_no_secret(combined.decode("utf-8", errors="ignore").replace("\x00", ""), "fichier du résultat")
                    previous = combined[-8192:]
        except ValueError as error:
            raise ApplyRefused(str(error)) from None


def apply_changes(work_root: Path, target_root: Path, ch: dict[str, list[str]], expected_base: dict[str, str],
                  run_dir: Path) -> dict:
    """Applies to the real project:
    - refuses any deletion and any file modified since the copy (the user's unsaved work);
    - backs up replaced files in ``Taches/<tâche>/details/avant-application`` and writes a manifest;
    - replaces each file atomically (temporary file + os.replace)."""
    from ..project_page import safe_path
    files = ch["modifies"] + ch["ajoutes"]
    # Vérifier tout le lot avant la première sauvegarde ou écriture.
    try:
        for rel in files:
            safe_path(work_root, rel)
            safe_path(target_root, rel)
            safe_path(run_dir, "avant-application/" + rel)
        safe_path(run_dir, "application.json")
    except ValueError as error:
        raise ApplyRefused(str(error)) from None
    check_result_files(work_root, files)
    if ch["supprimes"]:
        raise ApplyRefused("Suppression non autorisée par le studio : rien n'est appliqué ("
                           + ", ".join(ch["supprimes"][:5]) + ")")
    drift = [rel for rel in ch["modifies"]
             if not (target_root / rel).exists() or sha256_file(target_root / rel) != expected_base.get(rel)]
    drift += [rel for rel in ch["ajoutes"] if (target_root / rel).exists()]
    if drift:
        raise ApplyRefused("Le projet réel a changé depuis la préparation : " + ", ".join(drift[:10]))
    backup = run_dir / "avant-application"
    files = ch["modifies"] + ch["ajoutes"]
    manifest = {"debut": datetime.now(timezone.utc).isoformat(timespec="seconds"), "cible": str(target_root),
                "fichiers": {rel: sha256_file(work_root / rel) for rel in files}, "sauvegarde": str(backup)}
    for rel in ch["modifies"]:
        dst = backup / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(target_root / rel, dst)
    (run_dir / "application.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=1), encoding="utf-8")
    for rel in files:
        dst = target_root / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        descriptor, name = tempfile.mkstemp(dir=dst.parent, prefix=".studio-tmp-")
        os.close(descriptor)
        tmp = Path(name)
        try:
            shutil.copy2(work_root / rel, tmp)
            os.replace(tmp, dst)
        finally:
            tmp.unlink(missing_ok=True)
    return {"appliques": files, "sauvegarde_avant": str(backup)}


# ------------------------------------------------------------------ git worktree (large repositories, authorised per project)
class WorktreeError(RuntimeError):
    """Worktree cannot be created or read: nothing is written to the real project."""


WORKSPACE = "copie-de-travail"                      # copy (or worktree) of the project in the task folder
READY_MARKER = ".studio-worktree-pret"            # written next to the workspace when the checkout is complete


def _git(git: str, cwd: Path, *args: str, timeout: float = 600, entry: str | None = None) -> str:
    """git with no console or prompt (never asks for a password), paths taken literally (no patterns)."""
    import subprocess
    from .base import NO_WINDOW
    env = {**os.environ, "GIT_TERMINAL_PROMPT": "0", "GIT_LITERAL_PATHSPECS": "1"}
    try:
        r = subprocess.run([git, "-C", str(cwd), *args], capture_output=True, text=True, encoding="utf-8",
                           errors="replace", timeout=timeout, env=env, input=entry,
                           stdin=None if entry is not None else subprocess.DEVNULL, **NO_WINDOW)
    except subprocess.TimeoutExpired:
        raise WorktreeError(f"git {' '.join(args[:2])} : délai dépassé ({int(timeout)} s)") from None
    except OSError as e:
        raise WorktreeError(f"git {' '.join(args[:2])} : {e}") from None
    if r.returncode:
        raise WorktreeError(f"git {' '.join(args[:3])} : {(r.stderr or r.stdout).strip()[-400:]}")
    return r.stdout


def _succeeds(git: str, cwd: Path, *args: str) -> bool:
    """git command whose exit code is the answer (merge-base --is-ancestor, symbolic-ref -q…)."""
    try:
        _git(git, cwd, *args)
        return True
    except WorktreeError:
        return False


def _paths(task_files: list[str]) -> str:
    return "\0".join(task_files) + "\0"


def prepare_worktree(git: str, repo: Path, dest: Path, branch: str, folders: list[str] | None = None,
                     start: str = "HEAD") -> str:
    """Creates (or resumes) a worktree of the latest commit on a dedicated branch. The user's working folder,
    branch and uncommitted files are never touched; only the .git/worktrees metadata and the
    ``branch`` branch are added. ``dossiers``: partial checkout (sparse, cone mode); empty = everything.
    An interrupted checkout (stopped during checkout) is resumed, never mistaken for an empty workspace.
    ``start``: commit the new branch starts from (chain: previous step's validated commit, not merged yet)."""
    ready = dest.parent / READY_MARKER
    if (dest / ".git").is_file():
        if not ready.exists():                       # worktree created but checkout not finished: redo it
            if folders:
                _git(git, dest, "sparse-checkout", "set", "--cone", "--", *folders)
            _git(git, dest, "read-tree", "-mu", "HEAD", timeout=1800)
            ready.write_text("ok", encoding="utf-8")
        return _git(git, dest, "rev-parse", "HEAD").strip()
    if dest.exists() and any(dest.iterdir()):
        raise WorktreeError(f"Le dossier {dest} existe déjà sans être un worktree : rien n'est fait.")
    already_exists = bool(_git(git, repo, "branch", "--list", branch).strip())
    args = ["worktree", "add", "--no-checkout"] + ([str(dest), branch] if already_exists else ["-b", branch, str(dest), start or "HEAD"])
    _git(git, repo, *args)
    if folders:
        _git(git, dest, "sparse-checkout", "set", "--cone", "--", *folders)
    _git(git, dest, "read-tree", "-mu", "HEAD", timeout=1800)
    ready.write_text("ok", encoding="utf-8")
    return _git(git, dest, "rev-parse", "HEAD").strip()


def in_cone(rel: str, folders: list[str] | None) -> bool:
    """Partial checkout (cone mode): files at the root and inside the extracted folders. No folders = everything."""
    if not folders:
        return True
    rel = rel.replace("\\", "/")
    return "/" not in rel or any(rel == f or rel.startswith(f.rstrip("/") + "/") for f in folders)


def _is_link(p: Path) -> bool:
    try:
        info = p.lstat()
        return stat.S_ISLNK(info.st_mode) or bool(getattr(info, "st_file_attributes", 0) & 0x400)
    except OSError:
        return False


def remove_links(work: Path, folders: list[str] | None = None, git: str = "git") -> list[str]:
    """Links (symbolic, Windows junctions) an agent made in the task space towards other folders (e.g. Content/ of
    the real project, to run its tests): only the link is removed, never what it points to. Root and first level."""
    removed = []
    try:
        entries = [x for e in work.iterdir() for x in ([e] + (list(e.iterdir()) if e.is_dir() and not _is_link(e)
                                                              and e.name != ".git" else []))]
    except OSError:
        return removed
    for e in entries:
        if not _is_link(e):
            continue
        try:
            if e.is_symlink():
                e.unlink()
            else:
                os.rmdir(e)                         # a junction: rmdir removes the link only
            removed.append(e.relative_to(work).as_posix())
        except OSError:
            continue
    if removed and folders:
        try:                                        # files seen through the link lose their « outside the copy » mark
            _git(git, work, "sparse-checkout", "reapply")
        except (WorktreeError, OSError):
            pass
    return removed


def outside_snapshot(git: str, repo: Path, folders: list[str] | None) -> dict[str, list[int]]:
    """Size and date of the real project's tracked files that are NOT in the partial copy: the task must not touch
    them (compared after the run)."""
    if not folders:
        return {}
    out = {}
    for rel in _git(git, repo, "ls-files", "-z").split("\0"):
        if rel and not in_cone(rel, folders):
            try:
                st = (repo / rel).stat()
                out[rel] = [st.st_size, st.st_mtime_ns]
            except OSError:
                out[rel] = [-1, 0]
    return out


def outside_changed(repo: Path, before: dict[str, list[int]]) -> list[str]:
    changed = []
    for rel, (size, mtime) in before.items():
        try:
            st = (repo / rel).stat()
            now = [st.st_size, st.st_mtime_ns]
        except OSError:
            now = [-1, 0]
        if now != [size, mtime]:
            changed.append(rel)
    return changed


def git_changes(git: str, work: Path, exclude: list[str] | None = None, base: str = "HEAD", folders: list[str] | None = None
                ) -> tuple[dict[str, list[str]], dict[str, str]]:
    """Workspace changes relative to its STARTING commit (``base``): a commit made by the agent during
    execution therefore cannot hide files from the review. Untracked files included (except .gitignore and
    exclusions); a folder (nested repository…) is never treated as a file."""
    exclude = exclude or []
    ch: dict[str, list[str]] = {"ajoutes": [], "modifies": [], "supprimes": []}
    hashes: dict[str, str] = {}
    tracked = _git(git, work, "diff", "--name-status", "-z", "--no-renames", base).split("\0")
    i = 0
    while i + 1 < len(tracked):
        etat, rel = tracked[i], tracked[i + 1]
        i += 2
        if not etat or _skipped(rel, exclude):
            continue
        cle = "supprimes" if etat.startswith("D") else "ajoutes" if etat.startswith("A") else "modifies"
        if cle == "supprimes" and not in_cone(rel, folders):
            continue                                # never extracted (partial copy): absent, not deleted
        ch[cle].append(rel)
    for rel in _git(git, work, "ls-files", "--others", "--exclude-standard", "-z").split("\0"):
        if rel and not rel.endswith("/") and not _skipped(rel, exclude):
            ch["ajoutes"].append(rel)
    for rel in ch["ajoutes"] + ch["modifies"]:
        p = work / rel
        if p.is_file():
            hashes[rel] = sha256_file(p)
    ch = {k: sorted(set(v)) for k, v in ch.items()}
    ch["ajoutes"] = [r for r in ch["ajoutes"] if r in hashes]
    ch["modifies"] = [r for r in ch["modifies"] if r in hashes]
    return ch, hashes


def git_diff(git: str, work: Path, ch: dict[str, list[str]], base: str = "HEAD") -> str:
    """Full diff against the starting commit: tracked files (including anything the agent committed) via git,
    new untracked files via difflib. No paths on the command line."""
    tracked = {r for r in _git(git, work, "diff", "--name-only", "-z", "--no-renames", base).split("\0") if r}
    texte = _git(git, work, "diff", "--no-color", "--no-ext-diff", "--no-renames", base) if tracked else ""
    new_items = [r for r in ch["ajoutes"] if r not in tracked]
    return texte + unified_diff(None, work, {"modifies": [], "ajoutes": new_items, "supprimes": []})


def commit_worktree(git: str, work: Path, ch: dict[str, list[str]], message: str) -> str:
    """After the user's approval: commit only the presented files, on the worktree branch. Never pushes.
    Paths passed via standard input (no length limit, no pattern interpreted)."""
    task_files = ch["ajoutes"] + ch["modifies"] + ch["supprimes"]
    check_result_files(work, ch["ajoutes"] + ch["modifies"])
    if not task_files:
        return _git(git, work, "rev-parse", "HEAD").strip()
    _git(git, work, "reset", "-q")                  # nothing but the presented files goes into the commit
    try:                                            # --sparse: files outside the partial checkout (git ≥ 2.35)
        _git(git, work, "add", "-A", "--sparse", "--pathspec-from-file=-", "--pathspec-file-nul", entry=_paths(task_files))
    except WorktreeError as e:
        if "sparse" not in str(e).lower() or "unknown option" not in str(e).lower():
            raise
        _git(git, work, "add", "-A", "--pathspec-from-file=-", "--pathspec-file-nul", entry=_paths(task_files))
    if _succeeds(git, work, "diff", "--cached", "--quiet"):
        return _git(git, work, "rev-parse", "HEAD").strip()      # everything was already in the agent's commits
    _git(git, work, "commit", "--no-verify", "-m", message)
    return _git(git, work, "rev-parse", "HEAD").strip()
