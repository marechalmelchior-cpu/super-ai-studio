"""Reprise des skills et instructions déjà présents sur le PC : une COPIE dans le studio, puis le studio s'en occupe.

- Sources : skills de Claude Code (~/.claude/skills) et de Codex (~/.agents/skills, ~/.codex/skills) ; instructions
  globales ~/.claude/CLAUDE.md et ~/.codex/AGENTS.md.
- Copie dans l'espace du studio : Skills/<nom>/ (et Regles/importes/ pour les .md). Les originaux ne sont jamais
  modifiés, déplacés ni supprimés : l'utilisateur les retire lui-même s'il le souhaite.
- Rien n'est écrasé : nom déjà pris dans le studio → « <nom>-importe ». Les copies faites par le studio (« studio-… »)
  et les liens ne sont pas repris. Une seule fois automatiquement (data/import-initial.json), ensuite sur demande.
"""
from __future__ import annotations

import json
import shutil
import time
from pathlib import Path

SOURCES_SKILLS = (".claude/skills", ".agents/skills", ".codex/skills")
SOURCES_MD = ((".claude/CLAUDE.md", "CLAUDE (Claude Code).md"), (".codex/AGENTS.md", "AGENTS (Codex).md"))
MARQUE_STUDIO = "genere-par-ai-workspace"
IGNORES = shutil.ignore_patterns("__pycache__", "node_modules", ".git", "*.pyc")
MAX_SKILL_OCTETS = 50 * 2**20
FICHE = ".import.json"


def _taille(d: Path) -> int:
    total = 0
    for p in d.rglob("*"):
        try:
            if p.is_file() and not p.is_symlink():
                total += p.stat().st_size
        except OSError:
            pass
    return total


def _de_studio(d: Path) -> bool:
    if d.name.startswith("studio-"):
        return True
    try:
        return MARQUE_STUDIO in (d / "SKILL.md").read_text(encoding="utf-8", errors="replace")[:2000]
    except OSError:
        return False


def importer(racine: Path, home: Path | None = None) -> dict:
    """Copie ce qui n'est pas encore dans le studio. Renvoie {skills, instructions, ignores}."""
    racine, home = Path(racine), Path(home or Path.home())
    dest_skills = racine / "Skills"
    dest_skills.mkdir(parents=True, exist_ok=True)
    rapport = {"skills": [], "instructions": [], "ignores": []}
    deja: dict[str, Path] = {}                       # contenu SKILL.md → skill du studio (même skill vue chez Claude et Codex)
    for d in dest_skills.iterdir():
        f = d / FICHE
        if f.is_file():
            try:
                for o in json.loads(f.read_text(encoding="utf-8")).get("origines", []):
                    deja[o] = d
            except (OSError, ValueError):
                pass
    contenus: dict[str, Path] = {}
    for rel in SOURCES_SKILLS:
        base = home / rel
        if not base.is_dir():
            continue
        for d in sorted(base.iterdir()):
            try:
                if d.is_symlink() or not d.is_dir() or not (d / "SKILL.md").is_file() or _de_studio(d):
                    continue
                origine = str(d)
                if origine in deja:
                    continue
                texte = (d / "SKILL.md").read_text(encoding="utf-8", errors="replace")
                if texte in contenus:                 # même skill déjà copiée depuis l'autre outil : on note l'origine
                    cible = contenus[texte]
                    _ajouter_origine(cible, origine)
                    continue
                if _taille(d) > MAX_SKILL_OCTETS:
                    rapport["ignores"].append(f"{d.name} (plus de 50 Mo)")
                    continue
                nom, n = d.name, 1
                cible = dest_skills / nom
                while cible.exists():
                    if (cible / "SKILL.md").is_file() and (cible / "SKILL.md").read_text(encoding="utf-8", errors="replace") == texte:
                        break                         # déjà la même skill dans le studio : rien à copier
                    n += 1
                    cible = dest_skills / (f"{d.name}-importe" if n == 2 else f"{d.name}-importe-{n - 1}")
                if cible.exists():
                    _ajouter_origine(cible, origine)
                    contenus[texte] = cible
                    continue
                shutil.copytree(d, cible, symlinks=False, ignore=IGNORES, ignore_dangling_symlinks=True)
                _ajouter_origine(cible, origine)
                h, recent = empreinte_dossier(cible)
                fiche = _fiche(cible)
                fiche.update(empreinte=h, date_origine=date_dossier(d))
                _ecrire_fiche(cible, fiche)
                contenus[texte] = cible
                rapport["skills"].append(cible.name)
            except OSError as e:
                rapport["ignores"].append(f"{d.name} ({type(e).__name__})")
    dest_md = racine / "Regles" / "importes"
    for rel, nom in SOURCES_MD:
        src = home / rel
        cible = dest_md / nom
        try:
            if src.is_file() and not cible.exists():
                dest_md.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src, cible)
                rapport["instructions"].append(nom)
        except OSError as e:
            rapport["ignores"].append(f"{rel} ({type(e).__name__})")
    return rapport


def _ajouter_origine(skill: Path, origine: str) -> None:
    f = skill / FICHE
    try:
        d = json.loads(f.read_text(encoding="utf-8")) if f.exists() else {}
    except (OSError, ValueError):
        d = {}
    d.setdefault("importe", time.strftime("%Y-%m-%d %H:%M"))
    d["origines"] = sorted(set(d.get("origines", [])) | {origine})
    f.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")


def importer_une_fois(racine: Path, data: Path, home: Path | None = None) -> dict | None:
    """Au premier lancement (ou à la première ouverture après la mise à jour) : une seule fois."""
    marque = Path(data) / "import-initial.json"
    if marque.exists():
        return None
    r = importer(racine, home)
    marque.parent.mkdir(parents=True, exist_ok=True)
    marque.write_text(json.dumps({"date": time.strftime("%Y-%m-%d %H:%M"), **r}, ensure_ascii=False, indent=1), encoding="utf-8")
    return r


def origines(skill: Path) -> set[str]:
    try:
        return set(json.loads((Path(skill) / FICHE).read_text(encoding="utf-8")).get("origines", []))
    except (OSError, ValueError):
        return set()


# ------------------------------------------------------------------ suivi des originaux après la copie
def empreinte_dossier(d: Path) -> tuple[str, float]:
    """(empreinte du contenu, date la plus récente) d'une skill, sans la fiche du studio ni les fichiers lourds ignorés."""
    import hashlib
    h, recent = hashlib.sha256(), 0.0
    for p in sorted(Path(d).rglob("*")):
        rel = p.relative_to(d).as_posix()
        if not p.is_file() or p.name == FICHE or any(x in ("__pycache__", "node_modules", ".git") for x in p.parts):
            continue
        try:
            st = p.stat()
            recent = max(recent, st.st_mtime)
            h.update(rel.encode() + b"\0" + hashlib.sha256(p.read_bytes()).digest())
        except OSError:
            continue
    return h.hexdigest()[:24], recent


def date_dossier(d: Path) -> float:
    """Date la plus récente d'une skill : quelques stat(), aucun fichier lu."""
    recent = 0.0
    for p in Path(d).rglob("*"):
        if p.name == FICHE or any(x in ("__pycache__", "node_modules", ".git") for x in p.parts):
            continue
        try:
            if p.is_file():
                recent = max(recent, p.stat().st_mtime)
        except OSError:
            pass
    return recent


def _fiche(skill: Path) -> dict:
    try:
        return json.loads((skill / FICHE).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def _ecrire_fiche(skill: Path, d: dict) -> None:
    (skill / FICHE).write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")


def _remplacer_copie(racine: Path, skill: Path, origine: Path) -> None:
    """Ancienne copie rangée dans Archives (jamais effacée), puis nouvelle copie de l'original."""
    fiche = _fiche(skill)
    archive = Path(racine) / "Archives" / "skills-anciennes" / f"{skill.name}-{time.strftime('%Y%m%d-%H%M%S')}"
    archive.parent.mkdir(parents=True, exist_ok=True)
    shutil.move(str(skill), str(archive))
    shutil.copytree(origine, skill, symlinks=False, ignore=IGNORES, ignore_dangling_symlinks=True)
    h, recent = empreinte_dossier(skill)
    fiche.update(empreinte=h, date_origine=recent, maj=time.strftime("%Y-%m-%d %H:%M"))
    fiche.pop("conflit", None)
    _ecrire_fiche(skill, fiche)


def suivre(racine: Path) -> dict:
    """Skills reprises du PC : si l'original a changé et que la copie du studio n'a pas bougé, la copie est mise à
    jour (l'ancienne rangée dans Archives) ; si les deux ont changé, rien n'est touché et c'est signalé.
    Rapide : l'original n'est relu que si sa date a changé."""
    rapport = {"mises_a_jour": [], "conflits": []}
    base = Path(racine) / "Skills"
    if not base.is_dir():
        return rapport
    for skill in sorted(base.iterdir()):
        fiche = _fiche(skill)
        if not fiche.get("origines"):
            continue
        existants = [Path(o) for o in fiche["origines"] if (Path(o) / "SKILL.md").is_file()]
        if not existants:
            continue
        if "empreinte" not in fiche:                       # skill reprise avant le suivi : point de départ = maintenant
            h, recent = empreinte_dossier(skill)
            fiche.update(empreinte=h, date_origine=max(date_dossier(o) for o in existants))
            _ecrire_fiche(skill, fiche)
            continue
        dates = {o: date_dossier(o) for o in existants}
        origine = max(existants, key=dates.get)
        if dates[origine] <= float(fiche.get("date_origine", 0)):
            continue                                       # original pas touché : rien à lire
        h_orig, recent = empreinte_dossier(origine)
        if h_orig == fiche["empreinte"]:
            fiche["date_origine"] = recent
            _ecrire_fiche(skill, fiche)
            continue
        h_copie, _ = empreinte_dossier(skill)
        if h_copie == fiche["empreinte"]:
            _remplacer_copie(racine, skill, origine)
            rapport["mises_a_jour"].append(skill.name)
        else:                                              # modifiée des deux côtés : on ne touche à rien, on signale
            if fiche.get("conflit") != h_orig:
                rapport["conflits"].append(skill.name)
            fiche.update(conflit=h_orig, conflit_origine=str(origine), date_origine=recent)
            _ecrire_fiche(skill, fiche)
    return rapport


def conflits(racine: Path) -> list[dict]:
    base = Path(racine) / "Skills"
    out = []
    if base.is_dir():
        for skill in sorted(base.iterdir()):
            f = _fiche(skill)
            if f.get("conflit"):
                out.append({"nom": skill.name, "origine": f.get("conflit_origine", "")})
    return out


def resoudre(racine: Path, nom: str, choix: str) -> dict:
    """« original » : la copie prend la version du dossier d'origine (l'ancienne copie rangée dans Archives) ;
    « studio » : on garde la copie du studio et on ne signale plus ce changement."""
    skill = Path(racine) / "Skills" / nom
    f = _fiche(skill)
    if not f.get("conflit") or "/" in nom or "\\" in nom:
        raise ValueError("Aucun choix en attente pour cette skill.")
    origine = Path(f.get("conflit_origine", ""))
    if choix == "original":
        if not (origine / "SKILL.md").is_file():
            raise ValueError("L'original n'existe plus.")
        _remplacer_copie(racine, skill, origine)
        return {"ok": True, "message": f"{nom} : version de ton dossier reprise (ancienne copie dans Archives)."}
    h, recent = empreinte_dossier(origine) if (origine / "SKILL.md").is_file() else (f.get("conflit"), time.time())
    f.update(empreinte=empreinte_dossier(skill)[0], date_origine=recent)
    f.pop("conflit", None)
    f.pop("conflit_origine", None)
    _ecrire_fiche(skill, f)
    return {"ok": True, "message": f"{nom} : la version du studio est gardée."}
