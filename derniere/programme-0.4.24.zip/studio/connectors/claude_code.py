"""Claude Code connector — programmatic execution with ``claude -p``.

Choices (docs: https://code.claude.com/docs/en/headless):
- ``-p --output-format json``: fields ``result``, ``session_id``, ``is_error``,
  ``total_cost_usd`` (client-side estimate), ``structured_output`` with ``--json-schema``;
- no ``--bare``: that mode does not use the subscription (API key required);
  without it, the folder's CLAUDE.md, skills and hooks load as in interactive mode;
- permissions: ``--permission-mode acceptEdits`` limited to the isolated workspace +
  ``--allowedTools`` per mission; never a global bypass of protections;
- ``--permission-prompts none`` only if the installed version supports it (≥ 2.1.259);
- resume: each mission gets a fixed conversation id (``--session-id``). If the user stops and then resumes it,
  the studio relaunches the same conversation (``--resume``): the agent keeps everything it read and did, and continues.
"""
from __future__ import annotations

import json
import re
from pathlib import Path

from ..orchestrator.processes import run_process
from .base import SUMMARY_MAX, RESUME_INSTRUCTION, NO_WINDOW, ExecResult, Mission, conversation_sheet, find_exe, effective_level, jot

WIN_CANDIDATES = [str(Path.home() / ".local/bin/claude.exe"), str(Path.home() / "AppData/Roaming/npm/claude.cmd")]


def parse_version(text: str) -> tuple[int, ...]:
    m = re.search(r"(\d+)\.(\d+)\.(\d+)", text or "")
    return tuple(int(x) for x in m.groups()) if m else ()


class ClaudeCodeExecutor:
    name = "claude-code"

    def __init__(self, exe: str = "claude", permission_mode: str = "acceptEdits", timeout_s: float = 900,
                 json_schema: dict | None = None):
        if permission_mode in ("bypassPermissions",):
            raise ValueError("Le studio ne désactive pas les protections de Claude Code.")
        self.exe = find_exe(exe, WIN_CANDIDATES)
        self.permission_mode = permission_mode
        self.timeout_s = timeout_s
        self.json_schema = json_schema
        self._version: tuple[int, ...] | None = None
        self.mcp_unreal = "tout"                      # [outils] mcp_unreal: « tout » or « lecture »

    def version(self, store=None) -> tuple[int, ...]:
        if self._version is None:
            if not self.exe:
                self._version = ()
            else:
                import subprocess
                try:
                    out = subprocess.run([self.exe, "--version"], capture_output=True, text=True, timeout=30, **NO_WINDOW).stdout
                except (OSError, subprocess.TimeoutExpired):
                    out = ""
                self._version = parse_version(out)
        return self._version

    def knows_effort(self) -> bool:
        """--effort (low, medium, high, xhigh, max): only if the installed version's help mentions it."""
        if getattr(self, "_effort", None) is None:
            import subprocess
            try:
                help_text = subprocess.run([self.exe, "--help"], capture_output=True, text=True, timeout=30, encoding="utf-8",
                                      errors="replace", **NO_WINDOW).stdout if self.exe else ""
            except (OSError, subprocess.TimeoutExpired):
                help_text = ""
            self._effort = "--effort" in help_text
            self._settings = "--settings" in help_text
            self._resume = "--session-id" in help_text and "--resume" in help_text
        return self._effort

    def knows_settings(self) -> bool:
        """--settings (extra settings for this run): only if the installed version's help mentions it."""
        if getattr(self, "_settings", None) is None:
            self._effort = None
            self.knows_effort()
        return bool(self._settings)

    def knows_resume(self) -> bool:
        """--session-id and --resume: only if the installed version's help mentions them."""
        if getattr(self, "_resume", None) is None:
            self._effort = None
            self.knows_effort()
        return bool(getattr(self, "_resume", False))

    @staticmethod
    def conversation_exists(sid: str, home: Path | None = None) -> bool:
        """Conversation saved by Claude Code (~/.claude/projects/<folder>/<id>.jsonl), non-empty."""
        if not re.fullmatch(r"[0-9a-f-]{36}", sid or ""):
            return False
        base = Path(home or Path.home()) / ".claude" / "projects"
        return any(f.stat().st_size > 0 for f in base.glob(f"*/{sid}.jsonl"))

    @staticmethod
    def guard_settings() -> dict:
        """PreToolUse hook (studio/garde_mcp.py): unreal-mcp and shell commands, allowed and logged; only commands
        that destroy or publish are refused. Without this guard, call_tool and the shell stay refused (no window)."""
        import sys
        script = (Path(__file__).resolve().parents[1] / "garde_mcp.py").as_posix()
        py = Path(sys.executable).as_posix()
        return {"hooks": {"PreToolUse": [{"matcher": "mcp__unreal-mcp__.*|Bash|PowerShell|Edit|Write|MultiEdit|NotebookEdit",
                                          "hooks": [{"type": "command", "command": f'"{py}" "{script}"', "timeout": 15}]}]}}

    def options_effort(self, level: str) -> list[str]:
        return ["--effort", level] if level and self.knows_effort() else []

    def available(self) -> tuple[bool, str]:
        if not self.exe:
            return False, "Claude Code introuvable (commande « claude »)."
        v = self.version()
        return bool(v), f"Claude Code {'.'.join(map(str, v)) or 'version illisible'} ({self.exe})"

    def build_command(self, mission: Mission, prompt_file: Path, session: str = "", resumption: bool = False,
                      mcp: tuple[str, list[str]] | None = None) -> list[str]:
        instruction = (RESUME_INSTRUCTION.format(ref=f" ({prompt_file.name})") if resumption
                    else f"Lis et exécute la mission décrite dans {prompt_file.name}.")
        cmd = [self.exe or "claude", "-p", instruction,
               "--output-format", "json", "--permission-mode", self.permission_mode,
               "--append-system-prompt-file", str(prompt_file)]
        if session:
            cmd += ["--resume", session] if resumption else ["--session-id", session]
        if mcp and mcp[1]:                             # MCP servers added in Personnalisation (data/mcp.json)
            cmd += ["--mcp-config", mcp[0]]
        if mission.allowed_tools:
            allowed = [f"mcp__{n}" for n in (mcp[1] if mcp else []) if n != "studio-memoire"]
            if mcp and "studio-memoire" in mcp[1]:         # shared memory: search only (writes = studio)
                allowed += [f"mcp__studio-memoire__{o}" for o in ("memoire_chercher", "memoire_conflits", "memoire_etat",
                                                                 "image_creer", "voix_creer")]
            cmd += ["--allowedTools", ",".join(list(mission.allowed_tools) + allowed)]
        if mission.modele:
            cmd += ["--model", mission.modele]
        for d in mission.folders:                     # e.g. Taches\<tâche>\captures: the agent can save its images there
            cmd += ["--add-dir", d]
        cmd += self.options_effort(effective_level(mission.level, mission.effort))
        if self.version() >= (2, 1, 259):
            cmd += ["--permission-prompts", "none"]
        if self.json_schema:
            cmd += ["--json-schema", json.dumps(self.json_schema)]
        settings = prompt_file.with_name(prompt_file.stem + "-reglages.json")
        if settings.exists():
            cmd += ["--settings", str(settings)]
        return cmd

    def execute(self, mission: Mission, workdir: Path, runner) -> ExecResult:
        ok, info = self.available()
        if not ok:
            return ExecResult(False, info, self.name, error=info)
        prompt_file = workdir / f".mission-{mission.task_id}-{mission.try_count}.md"
        prompt_file.write_text(mission.prompt(), encoding="utf-8")
        settings = prompt_file.with_name(prompt_file.stem + "-reglages.json")
        if self.knows_settings():                # unreal-mcp guard (read-only) for this run
            settings.write_text(json.dumps(self.guard_settings(), ensure_ascii=False), encoding="utf-8")
        import os
        env = {**os.environ, "STUDIO_MCP_UNREAL": self.mcp_unreal}
        try:                                          # log of this task's unreal-mcp actions (report)
            env["STUDIO_ACTIONS_UNREAL"] = str(runner.details_dir(mission.task_id) / "actions-unreal.log")
            env["STUDIO_COMMANDES"] = str(runner.details_dir(mission.task_id) / "commandes.log")
            env["STUDIO_ACTIVITE"] = str(runner.details_dir(mission.task_id) / "activite.log")
            env["STUDIO_TACHE_DOSSIER"] = str(runner.run_dir(mission.task_id))
        except Exception:                             # noqa: BLE001 — runner used outside the studio
            pass
        if effective_level(mission.level, mission.effort) == "max" and not self.knows_effort():
            env["MAX_THINKING_TOKENS"] = "31999"      # older version without --effort: extended thinking
        session, resumption, sheet = self._session(mission, runner)
        mcp = None
        try:                                          # Extensions: project MCP servers + shared memory (read)
            from ..library import env_mcp, installed_mcp
            from ..mcp_client import memory_server
            data = runner.paths.data
            all_items = installed_mcp(data)
            chosen = {n: all_items[n] for n in sorted(all_items) if mission.mcp is None or n in mission.mcp}
            chosen["studio-memoire"] = memory_server()
            f = runner.details_dir(mission.task_id) / "mcp-agent.json"     # file without keys (${VAR}), specific to the task
            f.write_text(json.dumps({"mcpServers": chosen}, ensure_ascii=False), encoding="utf-8")
            mcp = (str(f), sorted(chosen))
            env.update(env_mcp(data))
        except Exception:                             # noqa: BLE001 — no studio (tests, outside a task): no server added
            mcp = None
        try:
            res = run_process(runner.store, mission.task_id, self.build_command(mission, prompt_file, session, resumption, mcp),
                              workdir, self.timeout_s, env=env)
        finally:
            prompt_file.unlink(missing_ok=True)
            settings.unlink(missing_ok=True)
        if sheet is not None and res.status == "termine":    # conversation run to completion: nothing left to resume
            sheet.unlink(missing_ok=True)
        return self.parse(res.stdout, res.stderr, res.returncode, res.status)

    def _session(self, mission: Mission, runner) -> tuple[str, bool, Path | None]:
        """Conversation id of the mission. Record present + saved conversation = the mission had been
        stopped: resume it. Otherwise a new id, written to the record before launch."""
        import uuid
        sheet = conversation_sheet(runner, mission, "claude", "txt") if self.knows_resume() else None
        if sheet is None:
            return "", False, None
        try:
            old = sheet.read_text(encoding="utf-8").strip() if sheet.exists() else ""
            if old and self.conversation_exists(old):
                jot(runner, mission.task_id, f"{mission.role} reprend sa conversation là où il s'était arrêté")
                return old, True, sheet
            sid = str(uuid.uuid4())
            sheet.write_text(sid, encoding="utf-8")
            return sid, False, sheet
        except OSError:
            return "", False, None

    def parse(self, stdout: str, stderr: str, code: int | None, status: str) -> ExecResult:
        if status != "termine":
            return ExecResult(False, f"Claude Code : {status}", self.name, error=status)
        try:
            data = json.loads(stdout.strip().splitlines()[-1]) if stdout.strip() else {}
        except json.JSONDecodeError:
            return ExecResult(False, "Sortie JSON illisible", self.name, error=(stderr or stdout)[-2000:])
        is_err = bool(data.get("is_error")) or code not in (0, None)
        return ExecResult(ok=not is_err, summary=str(data.get("result", ""))[:SUMMARY_MAX], executor=self.name,
                          session_id=str(data.get("session_id", "")), cost_estimate_usd=data.get("total_cost_usd"),
                          raw={k: data.get(k) for k in ("session_id", "num_turns", "duration_ms", "structured_output",
                                                        "permission_denials", "usage") if k in data},
                          error=str(data.get("result", ""))[:2000] if is_err else "")
