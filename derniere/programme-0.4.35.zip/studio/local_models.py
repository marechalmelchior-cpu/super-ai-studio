"""Models on your PC (Gestion › Benchmarks › « Installer »): downloaded by the local model runner, with progress.

- Only local models from the benchmarks catalogue install here (name checked), on the user's click.
- The runner must be installed: the studio never installs it itself (download link otherwise).
- Runner closed: it opens by itself when needed (installing a model, an agent or the Supervisor using a
  local model), never when the studio opens. The runner frees a model's memory 5 min after its last use.
- The download goes through the runner's local API (127.0.0.1:11434); nothing else is launched.
"""
from __future__ import annotations

import json
import re
import threading
import urllib.error
import urllib.request

OLLAMA = "http://127.0.0.1:11434"
DOWNLOAD_OLLAMA = "https://ollama.com/download"
_NAME = re.compile(r"^[a-z0-9][a-z0-9._-]{0,80}(:[a-z0-9._-]{1,40})?$")
_in_progress: dict[str, dict] = {}
_lock = threading.Lock()


def _get(chemin: str, delay: float = 2):
    with urllib.request.urlopen(OLLAMA + chemin, timeout=delay) as r:
        return json.loads(r.read() or b"{}")


def ollama_executable() -> str:
    """Runner installed on this PC (even closed): path of the command, else empty."""
    import glob
    import os
    import shutil
    p = shutil.which("ollama")
    if p:
        return p
    for pattern in ("~/AppData/Local/Programs/Ollama/ollama.exe", "C:/Program Files/Ollama/ollama.exe",
                  "/Applications/Ollama.app/Contents/Resources/ollama", "/usr/local/bin/ollama", "/opt/homebrew/bin/ollama"):
        t = glob.glob(os.path.expanduser(pattern))
        if t:
            return t[0]
    return ""


def startup() -> dict:
    """Opens the runner (on the user's click): the taskbar app if it exists, else the server."""
    import os
    import subprocess
    import sys
    exe = ollama_executable()
    if not exe:
        raise ValueError(f"Ollama n'est pas installé. Installe-le ({DOWNLOAD_OLLAMA}), puis réessaie.")
    app = os.path.join(os.path.dirname(exe), "ollama app.exe")
    opts = {"creationflags": 0x00000008 | 0x00000200 | 0x08000000} if sys.platform == "win32" else {"start_new_session": True}
    cmd = [app] if os.path.exists(app) else [exe, "serve"]
    if sys.platform == "darwin" and os.path.isdir("/Applications/Ollama.app"):
        cmd = ["open", "-a", "Ollama"]                    # macOS: the app (menu bar icon)
    subprocess.Popen(cmd, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, close_fds=True, **opts)
    import time
    for _ in range(20):
        time.sleep(0.5)
        if installed() is not None:
            return {"ok": True, "message": "Ollama est ouvert."}
    return {"ok": True, "message": "Ollama démarre…"}


def assurer() -> bool:
    """Runner ready to serve: opens it if installed but closed (when a local model is needed). True if it answers."""
    if installed() is not None:
        return True
    if not ollama_executable():
        return False
    try:
        startup()
    except (OSError, ValueError):
        return False
    return installed() is not None


def details() -> list[dict]:
    """Installed models with size and date (Gestion › Outils: local model updates)."""
    try:
        return [{"nom": m.get("name", ""), "taille_go": round((m.get("size") or 0) / 1e9, 1), "modifie": str(m.get("modified_at", ""))[:10]}
                for m in _get("/api/tags").get("models", []) if m.get("name")]
    except (OSError, ValueError):
        return []


def installed() -> list[str] | None:
    """Models already present in the runner; None if the runner does not answer."""
    try:
        return sorted(m.get("name", "") for m in _get("/api/tags").get("models", []) if m.get("name"))
    except (OSError, ValueError):
        return None


def ollama_name(m: dict) -> str:
    """Name to download: the « ollama » field, else the key only when it already looks like a runner name (name:tag);
    a repository id (« meta-llama/… ») is not installable as such."""
    import re
    if m.get("ollama"):
        return str(m["ollama"])
    cle = str(m.get("cle") or "")
    return cle if re.fullmatch(r"[a-z0-9][a-z0-9._-]*(:[a-z0-9._-]+)?", cle) and "/" not in cle else ""


def present(nom: str, entries: list[str]) -> bool:
    """« qwen3.6 » is present if « qwen3.6:latest » or « qwen3.6:27b » is."""
    base = nom if ":" in nom else nom + ":"
    return any(x == nom or x.startswith(base) for x in entries)


def etat(catalog: list[dict]) -> dict:
    entries = installed()
    with _lock:
        in_progress = {k: dict(v) for k, v in _in_progress.items()}
    model_list = {}
    for m in catalog:
        n = ollama_name(m)
        if m.get("local") and n:
            model_list[n] = {"installe": bool(entries) and present(n, entries), **({"progression": in_progress[n]} if n in in_progress else {})}
    return {"ollama": entries is not None, "installe": entries is not None or bool(ollama_executable()),
            "telecharger": DOWNLOAD_OLLAMA, "modeles": model_list}


def error_message(e: Exception) -> str:
    """Runner error in plain words, with what to do (most common: runner too old for a recent model)."""
    t = str(e)
    if isinstance(e, urllib.error.HTTPError):
        try:
            t = f"{e.code} {json.loads(e.read() or b'{}').get('error', '')}"
        except (OSError, ValueError):
            t = str(e.code)
    bottom = t.lower()
    if "412" in bottom or "newer version" in bottom:
        return "Ollama est trop ancien pour ce modèle : mets-le à jour (ollama.com/download ou l'icône Ollama › Update), puis réessaie."
    if "file does not exist" in bottom or "not found" in bottom or "404" in bottom:
        return "Ce modèle n'existe pas (ou plus) sous ce nom chez Ollama."
    if "no space" in bottom or "disk" in bottom:
        return "Plus assez de place sur le disque pour ce modèle."
    return f"Échec : {t[:200]}"


def uninstall(nom: str) -> dict:
    """Removes a model from the runner (on click, after confirmation): only actually installed models are accepted."""
    nom = (nom or "").strip()
    entries = installed()
    if entries is None:
        raise ValueError("Ollama ne répond pas : ouvre-le, puis réessaie.")
    if nom not in entries:
        raise ValueError("Ce modèle n'est pas installé.")
    req = urllib.request.Request(OLLAMA + "/api/delete", data=json.dumps({"model": nom}).encode(), method="DELETE",
                                 headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=60):
            pass
    except (OSError, urllib.error.HTTPError) as e:
        raise ValueError(error_message(e)) from None
    with _lock:
        _in_progress.pop(nom, None)
    return {"ok": True, "message": f"{nom} désinstallé."}


def install(nom: str, catalog: list[dict], note=lambda m: None, open_: bool = True) -> dict:
    nom = (nom or "").strip().lower()
    if not _NAME.match(nom) or nom not in {ollama_name(m) for m in catalog if m.get("local")} | set(installed() or []):
        raise ValueError("Modèle inconnu du catalogue : rien n'est installé.")
    if not (assurer() if open_ else installed() is not None):
        raise ValueError(f"Ollama ne répond pas sur le PC. Installe-le ({DOWNLOAD_OLLAMA}) s'il ne l'est pas, puis réessaie."
                         if not ollama_executable() else "Ollama ne répond pas : ouvre-le sur le PC, puis réessaie.")
    with _lock:
        if nom in _in_progress and _in_progress[nom].get("etat") == "telechargement":
            return {"ok": True, "deja": True}
        _in_progress[nom] = {"etat": "telechargement", "pct": 0, "message": "Démarrage…"}

    def pull():
        try:
            req = urllib.request.Request(OLLAMA + "/api/pull", data=json.dumps({"model": nom, "stream": True}).encode(),
                                         headers={"Content-Type": "application/json"})
            with urllib.request.urlopen(req, timeout=300) as r:
                for line in r:
                    try:
                        d = json.loads(line)
                    except ValueError:
                        continue
                    if d.get("error"):
                        raise RuntimeError(str(d["error"])[:300])
                    with _lock:
                        p = _in_progress[nom]
                        if d.get("total"):
                            p["pct"] = int(100 * (d.get("completed") or 0) / d["total"])
                        p["message"] = str(d.get("status", ""))[:80]
            with _lock:
                _in_progress[nom] = {"etat": "fini", "pct": 100, "message": "Installé."}
            note(f"modèle local installé : {nom}")
        except Exception as e:                             # noqa: BLE001 — shown next to the model
            with _lock:
                _in_progress[nom] = {"etat": "erreur", "pct": 0, "message": error_message(e)}
    threading.Thread(target=pull, daemon=True).start()
    return {"ok": True}
