"""Create a specialized agent: domain → suggested role → recommended model (market rankings) → role added.

Catalog: modeles/agents.json (ready-to-use domains and roles). Rankings: modeles/benchmarks.json (dated,
sourced). The recommendation first takes the best already-connected AI for this kind of work, and also shows the
market's best if it differs. The created role is a Studio/roles/<id>.toml file in the workspace (never overwritten).
"""
from __future__ import annotations

import json
import re
import tomllib
import unicodedata
from pathlib import Path

from .user_workspace import MODELS

# real generation possible from the studio (or via an MCP server from Extensions, for any model)
CAPABILITIES = {"image": {"openai", "gemini", "codex", "xai", "openrouter", "autre"}, "voix": {"openai", "elevenlabs", "groq", "autre"}}


def catalog() -> dict:
    return json.loads((MODELS / "agents.json").read_text(encoding="utf-8"))


_cache: dict = {}


def benchmarks(data: Path | None = None) -> dict:
    """Rankings shipped with the studio; replaced by those published since if they are newer
    (data/benchmarks-maj.json, updated daily); the day's prices applied to cloud models only."""
    base = json.loads((MODELS / "benchmarks.json").read_text(encoding="utf-8"))
    d = data or _cache.get("data")
    if d:
        try:
            update_info = json.loads((Path(d) / "benchmarks-maj.json").read_text(encoding="utf-8"))
            if isinstance(update_info.get("modeles"), list) and str(update_info.get("date", "")) >= str(base.get("date", "")):
                base = {**base, **{k: v for k, v in update_info.items() if k not in ("prix", "prix_complet", "contextes")}}
            for m in base["modeles"]:
                p = (update_info.get("prix") or {}).get(_normalize(m["cle"]))
                if p is not None and not m.get("local"):
                    m["prix"] = p
            base["actualise"] = update_info.get("actualise", "")
        except (OSError, ValueError):
            pass
    for m in base["modeles"]:
        if m.get("local"):
            m["prix"] = None                              # local: free (never the price of an online service)
    return base


def _normalize(t: str) -> str:
    return re.sub(r"[^a-z0-9]", "", t.lower())


def rankings_url(url: str = "") -> str:
    """Full published rankings: [benchmarks] url setting, otherwise the studio repository (catalogue/benchmarks.json)."""
    if url.startswith("https://"):
        return url
    from .updates import depot
    d = depot()
    return f"https://raw.githubusercontent.com/{d}/main/catalogue/benchmarks.json" if d else ""


def refresh(data: Path, url: str = "", force: bool = False) -> dict:
    """Every day: published rankings (if newer) then the day's prices for cloud models (public model
    directory, no key, nothing is sent). On failure, the shipped rankings stay in use."""
    import time
    import urllib.request
    from datetime import datetime, timezone
    _cache["data"] = str(data)
    f = Path(data) / "benchmarks-maj.json"
    if not force and f.exists() and time.time() - f.stat().st_mtime < 24 * 3600:
        return {"ok": True, "frais": True}
    when = datetime.now(timezone.utc).isoformat(timespec="minutes")
    update_info: dict = {}
    error_list = []
    source = rankings_url(url)
    if source:
        try:
            with urllib.request.urlopen(urllib.request.Request(source, headers={"User-Agent": "SuperAIStudio"}), timeout=20) as r:
                d = json.loads(r.read())
            if not isinstance(d.get("modeles"), list):
                raise ValueError("format inattendu")
            update_info.update(d)
        except Exception as e:                            # noqa: BLE001
            error_list.append(type(e).__name__)
    try:
        req = urllib.request.Request("https://openrouter.ai/api/v1/models", headers={"User-Agent": "SuperAIStudio"})
        with urllib.request.urlopen(req, timeout=20) as r:
            entries = json.loads(r.read()).get("data", [])
        model_list = update_info.get("modeles") or json.loads((MODELS / "benchmarks.json").read_text(encoding="utf-8"))["modeles"]
        prices = {}
        for m in model_list:
            cle = _normalize(m["cle"])
            if m.get("local") or not cle:
                continue
            ids = [(x, _normalize(str(x.get("id", "")).split("/")[-1])) for x in entries]
            found = next((x for x, i in ids if i == cle), None) or next((x for x, i in ids if i.startswith(cle) and not i[len(cle):len(cle) + 1].isdigit()), None) \
                or next((x for x, i in ids if cle in i), None)          # a shorter model ID must not take the price of a longer ID sharing its prefix
            if found:
                try:
                    prices[cle] = round(float((found.get("pricing") or {}).get("prompt", 0)) * 1_000_000, 3)
                except (TypeError, ValueError):
                    pass
        update_info["prix"] = prices
        complete = {}                                      # pay-per-use cost (Gestion › Usage): input and output, per model
        for x in entries:
            try:
                pr = x.get("pricing") or {}
                complete[str(x.get("id", ""))] = [round(float(pr.get("prompt", 0)) * 1e6, 4), round(float(pr.get("completion", 0)) * 1e6, 4)]
            except (TypeError, ValueError):
                pass
        update_info["prix_complet"] = complete
        update_info["contextes"] = {str(x.get("id", "")): int(x["context_length"]) for x in entries
                            if isinstance(x.get("context_length"), (int, float)) and x.get("id")}
    except Exception as e:                                # noqa: BLE001
        error_list.append(type(e).__name__)
    if not update_info:
        return {"ok": False, "erreur": ", ".join(error_list)}
    update_info["actualise"] = when
    t = f.with_suffix(".partiel")
    t.write_text(json.dumps(update_info, ensure_ascii=False), encoding="utf-8")
    t.replace(f)
    return {"ok": True, "actualise": when}


def estimated_cost(data: Path, modele: str, j: dict) -> float | None:
    """Cost of a pay-per-use call (API key) from the day's prices (public price directory, $ per million tokens).
    Tokens read from cache: counted at a quarter of the input price (typical size of provider discounts)."""
    if not modele or not j:
        return None
    try:
        complete = json.loads((Path(data) / "benchmarks-maj.json").read_text(encoding="utf-8")).get("prix_complet") or {}
    except (OSError, ValueError):
        return None
    cle = _normalize(modele.split("/")[-1].split(":")[0])
    if not cle:
        return None
    ids = [(k, _normalize(k.split("/")[-1])) for k in complete]
    k = next((k for k, i in ids if i == cle), None) or next((k for k, i in ids if i.startswith(cle)), None)
    if not k:
        return None
    pin, pout = complete[k]
    return round((j.get("entree", 0) + 0.25 * j.get("cache", 0)) * pin / 1e6 + j.get("sortie", 0) * pout / 1e6, 5)


def connected_sources(studio) -> list[dict]:
    """AIs usable right now: installed subscriptions and connections (API key or local)."""
    from . import ai
    from .connectors.base import find_exe
    from .connectors.claude_code import WIN_CANDIDATES
    out = []
    if find_exe(studio.cfg["outils"].get("claude", "claude"), WIN_CANDIDATES):
        out.append({"id": "claude-code", "fournisseur": "anthropic", "nom": "Claude Code (abonnement)", "modele": ""})
    if find_exe(studio.cfg["outils"].get("codex", "codex")):
        out.append({"id": "codex", "fournisseur": "codex", "nom": "Codex (abonnement ChatGPT)", "modele": ""})
    for c in ai.read_file(studio.paths.data)["connexions"]:
        f = c["fournisseur"]
        out.append({"id": c["id"], "fournisseur": "local" if f in ("ollama", "lmstudio") else f,
                    "nom": ai.PROVIDERS.get(f, {}).get("nom", f), "modele": c.get("modele", "")})
    return out


# Which leaderboards matter for a trade, best first (the next ones fill in models the first one does not rank)
_RANKING_RULES = [
    (("auditeur", "qa", "securite", "gardien"), ["raisonnement", "code", "global"]),
    (("designer-ui", "integrateur", "developpeur-web", "seo"), ["web", "code", "global"]),
    (("scenariste", "localisation", "documentation", "producteur", "chercheur", "ia-personnages"),
     ["conversation", "connaissances", "global"]),
    (("game-designer", "equilibrage", "level-designer", "directeur"), ["raisonnement", "global"]),
]


def role_rankings(role) -> list[str]:
    """Leaderboards used to pick this trade's AI and model: by trade, then by its domains (code → code + agents)."""
    cat = getattr(role, "category", "") or ""
    if cat in ("image", "video"):
        return [cat] if cat == "image" else ["global"]
    if cat in ("voix", "voice"):
        return ["voix"]
    rid = getattr(role, "id", "") or ""
    for keys, cats in _RANKING_RULES:
        if any(k in rid for k in keys):
            return cats
    if set(getattr(role, "domains", []) or []) & {"code", "python", "web", "unreal", "outillage"}:
        return ["code", "agents", "global"]
    return ["global"]


def tool_model(source: dict, m: dict | None) -> str:
    """The name a tool understands for a ranked model: subscription tool aliases (opus / sonnet / haiku), Codex's own
    list, a connection's model id. "" when this tool cannot use it (then its default model)."""
    if not m:
        return ""
    if source.get("id") == "claude-code":
        hit = re.search(r"\b(opus|sonnet|haiku)\b", m.get("nom", ""), re.I)
        return hit.group(1).lower() if hit and m.get("fournisseur") == "anthropic" else ""
    if source.get("id") == "codex":
        from .connectors.codex import CodexExecutor
        return m["cle"] if m.get("fournisseur") == "openai" and m.get("cle") in CodexExecutor.models() else ""
    return m.get("cle", "") if m.get("fournisseur") == source.get("fournisseur") else ""


def best_model(studio, role, source_id: str, margin: float = 0.0) -> str:
    """Model, for this trade, that the given AI can run (tool name), or "". margin 0 = the best-ranked one;
    margin 0.08 = the cheapest among those within 8 % of the best (same quality for less usage)."""
    src = next((s for s in connected_sources(studio) if s["id"] == source_id), None)
    if not src:
        return ""
    usable = [m for m in _ranking("", role_rankings(role)) if not m.get("local") and tool_model(src, m)]
    if not usable:
        return ""
    top = usable[0].get("_note") or usable[0].get("score") or 0
    near = [m for m in usable if (m.get("_note") or m.get("score") or 0) >= top * (1 - margin)] if margin and top else usable[:1]
    return tool_model(src, min(near, key=lambda m: (m.get("prix") if m.get("prix") is not None else 1e9)) if margin else usable[0])


def _blend(cats: list[str]) -> list[dict]:
    """Several leaderboards for one trade: each score is put on the same scale (share of the category's best), then
    averaged with decreasing weights (1, 0.6, 0.35…) over the leaderboards that rank the model. Best first."""
    b = benchmarks()["modeles"]  # noqa
    inverse = set(benchmarks().get("inverses") or [])
    best, weights = {}, [1.0, 0.6, 0.35, 0.2]
    for c in cats:
        vals = [m["score"] for m in b if m["categorie"] == c and m.get("score")]
        if vals:
            best[c] = min(vals) if c in inverse else max(vals)
    acc: dict = {}
    for i, c in enumerate(cats):
        if c not in best:
            continue
        for m in b:
            if m["categorie"] != c or not m.get("score"):
                continue
            share = (best[c] / m["score"]) if c in inverse else (m["score"] / best[c])
            k = (m["cle"], bool(m.get("local")))
            e = acc.setdefault(k, {"m": m, "s": 0.0, "w": 0.0, "main": False})
            e["main"] = e["main"] or i == 0
            w = weights[min(i, len(weights) - 1)]
            e["s"] += share * w
            e["w"] += w
    for e in acc.values():                       # a model ranked by the main leaderboard counts more than a fill-in
        e["m"] = {**e["m"], "_note": (e["s"] / e["w"]) * (1.0 if e["main"] else 0.85)}   # not ranked by the main board: less sure
    return [e["m"] for e in sorted(acc.values(), key=lambda e: -e["m"]["_note"])]


def _ranking(category: str, cats: list[str] | None = None) -> list[dict]:
    if cats and len(cats) > 1:
        return _blend(cats)
    b = benchmarks()["modeles"]  # noqa
    cats = cats or {"code": ["code", "global"], "texte": ["global"], "image": ["image"], "video": ["global"], "voix": ["voix"]}.get(category, ["global"])
    out, seen_items = [], set()
    for c in cats:
        for m in sorted((m for m in b if m["categorie"] == c), key=lambda m: -(m["score"] or 0)):
            if (m["cle"], m.get("local")) not in seen_items:
                seen_items.add((m["cle"], m.get("local")))
                out.append(m)
    return out


def recommend(studio, category: str, cats: list[str] | None = None) -> dict:
    """{"connecte": source + suggested model (or None), "marche": market's best, "remarque": text}."""
    sources = connected_sources(studio)
    ranking = _ranking(category, cats)
    market = next((m for m in ranking if not m.get("local")), None)
    capable_sources = sources
    if category in CAPABILITIES:
        capable_sources = [s for s in sources if s["fournisseur"] in CAPABILITIES[category]]
    choice, modele = None, None
    for m in ranking:
        f = "local" if m.get("local") else m["fournisseur"]       # local open model ≠ subscription tool
        s = next((x for x in capable_sources if x["fournisseur"] == f or (f == "openai" and x["fournisseur"] == "codex")), None)
        if s:
            choice, modele = s, m
            break
    if choice is None and capable_sources:
        locale = [s for s in capable_sources if s["fournisseur"] == "local"]
        choice = (locale or capable_sources)[0]
        if choice["fournisseur"] == "local":
            modele = next((m for m in _ranking("texte") if m.get("local")), None)
    remark = ""
    if category in CAPABILITIES and not capable_sources:
        remark = ("Aucune IA connectée ne sait générer de " + ("images" if category == "image" else "voix")
                    + " : l'agent écrira les prompts et fiches. Pour qu'il les produise : connecte une IA qui sait le faire ("
                    + ("OpenAI, Gemini, xAI, OpenRouter ou une IA compatible" if category == "image" else "OpenAI, ElevenLabs, Groq ou une IA compatible")
                    + "), ou ajoute un serveur MCP de création dans Extensions.")
    elif category == "video":
        remark = "La vidéo elle-même se génère sur l'outil choisi (Kling, Veo, Seedance…) : l'agent prépare scénario, storyboard et prompts."
    return {"connecte": ({**choice, "modele_conseille": modele} if choice else None), "marche": market, "remarque": remark}


def _slug(texte: str) -> str:
    t = unicodedata.normalize("NFKD", texte).encode("ascii", "ignore").decode().lower()
    return re.sub(r"[^a-z0-9]+", "-", t).strip("-")[:40] or "agent"


def _toml(v) -> str:
    return json.dumps(v, ensure_ascii=False)          # JSON strings and lists = valid TOML


def create_new(studio, payload: dict) -> dict:
    """Writes the role into the workspace (new file only) and reloads the team."""
    from .user_workspace import custom
    from .orchestrator.roles import load_roles
    nom = str(payload.get("nom", "")).strip()[:60]
    if not nom:
        raise ValueError("Donne un nom à l'agent.")
    mission = str(payload.get("mission", "")).strip()[:2000]
    if not mission:
        raise ValueError("Décris la mission de l'agent.")
    entries = lambda k: [str(x).strip()[:300] for x in (payload.get(k) or []) if str(x).strip()][:12]
    source = str(payload.get("source", "") or "")
    category = str(payload.get("categorie", "texte"))
    base = _slug(str(payload.get("id") or nom))
    ident, n = base, 2
    while (studio.paths.roles / f"{ident}.toml").exists() or ident in studio.roles:
        ident, n = f"{base}-{n}", n + 1
    if source in ("claude-code", "codex"):
        executeur, connection = source, ""
    elif source:
        from . import ai
        if not ai.connection(studio.paths.data, source):
            raise ValueError("IA inconnue : connecte-la d'abord (Accueil › Réglages › IA).")
        executeur, connection = "api", source
    else:
        executeur, connection = "claude-code", ""
    allowed_tools = [str(x) for x in (payload.get("outils") or ["Read", "Edit", "Write", "Glob", "Grep"])][:20]
    rows = [f"id = {_toml(ident)}", f"nom = {_toml(nom)}", f"domaines = {_toml([str(payload.get('domaine') or 'general')])}",
              f"executeur = {_toml(executeur)}", f"mots_cles = {_toml(entries('mots_cles'))}", f"outils = {_toml(allowed_tools)}",
              f"livrables = {_toml(entries('livrables') or ['Résultat dans l espace isolé, compte rendu clair'])}",
              f"criteres = {_toml(entries('criteres') or ['Travail demandé fait et vérifié'])}",
              f"limites = {_toml(entries('limites'))}", f"consignes = {_toml(custom(mission))}",
              f"categorie = {_toml(category)}", "cree_par = \"assistant\""]
    if connection:
        rows.append(f"connexion = {_toml(connection)}")
    if payload.get("modele_api"):
        rows.append(f"modele_api = {_toml(str(payload['modele_api'])[:120])}")
    project = str(payload.get("projet", "") or "")
    if project:                                          # project-specific agent: offered only there
        t = studio.registry.get(project)
        rows.append(f"projets = {_toml([f'{t.kind}:{t.id}'])}")
    texte = "\n".join(rows) + "\n"
    tomllib.loads(texte)                                # the file must be valid before being written
    f = studio.paths.roles / f"{ident}.toml"
    f.parent.mkdir(parents=True, exist_ok=True)
    with open(f, "x", encoding="utf-8") as fh:          # "x": never overwrite
        fh.write(texte)
    studio.roles = load_roles(studio.paths.roles)
    return {"id": ident, "fichier": str(f), "executeur": executeur}
