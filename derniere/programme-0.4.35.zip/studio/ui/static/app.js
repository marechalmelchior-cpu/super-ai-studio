"use strict";
const $ = (s) => document.querySelector(s);
const $$ = (s) => document.querySelectorAll(s);
const esc = (t) => String(t ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

let view = "projets", projectChat = null, targets = [], currentProject = null, selection = null, lastView = "";

async function api(path, body) {
  const opt = body === undefined ? {} : { method: "POST", headers: { "Content-Type": "application/json", "X-Studio": "1" }, body: JSON.stringify(body) };
  const r = await fetch(path, opt);
  const j = await r.json().catch(() => ({}));
  if (!r.ok) { const e = new Error(j.erreur || r.status); e.code = r.status; throw e; }
  if (j && j.avertissement) setTimeout(() => infoBubble(j.avertissement), 0);     // e.g. a local AI chosen while it is closed
  return j;
}

const LABELS = {
  creee: "en cours", en_cours: "en cours", a_approuver: "à valider", a_approuver_avec_defauts: "à valider · défauts",
  approuvee: "validée", appliquee: "appliquée", annulee: "annulée", bloquee: "bloquée", interrompue: "interrompue",
  en_attente_creneau: "en attente", echec: "échec",
};
const TOOL_LABELS = { "claude-code": "Claude Code", codex: "Codex", simulation: "simulation" };
const taskLabel = (t) => t.status === "approuvee" && (t.summary || "").startsWith("Faite") ? "terminée" : (LABELS[t.status] || t.status);
const TO_APPROVE = ["a_approuver", "a_approuver_avec_defauts"];
const IN_PROGRESS = ["creee", "en_cours", "en_attente_creneau", "interrompue", "bloquee"];
let MODELS = [["", "Auto"], ["opus", "Opus"], ["sonnet", "Sonnet"], ["haiku", "Haiku"]];   // replaced by [choix] modeles_claude
const EFFORTS = [["", "Auto"], ["low", "Bas"], ["medium", "Moyen"], ["high", "Élevé"], ["xhigh", "Très élevé"], ["max", "Max"]];
const EFFORT_LABELS = Object.fromEntries(EFFORTS);
const MODES = [["rapide", "Rapide"], ["", "Normal"], ["max", "Max"]];
let SUPERVISOR_MODELS = [["", "Auto"], ["haiku", "Haiku"], ["sonnet", "Sonnet"], ["opus", "Opus"]];
let CODEX_MODELS = [["", "Auto"]];                          // models of the second subscription CLI (its own list)
let supFamily = "claude-code";
const supModel = () => (supFamily === "codex" ? codexModel : supFamily === "claude-code" ? supervisorModel : "");
const readSup = (k) => { try { return localStorage.getItem(k) || ""; } catch { return ""; } };
const keepSup = (k, v) => { try { localStorage.setItem(k, v); } catch {} };
let supervisorModel = readSup("sup-modele"), supervisorEffort = readSup("sup-effort"), codexModel = readSup("sup-modele-codex");   // Supervisor setting kept from one session to the next
const modelName = (m) => m.charAt(0).toUpperCase() + m.slice(1);
// Status colors: running = blue, awaiting approval = yellow, approved = green, cancelled / failed / blocked = red
const couleur = (s) => (["approuvee", "appliquee"].includes(s) ? "ok"
  : ["creee", "en_cours", "en_attente_creneau"].includes(s) ? "info"
  : ["a_approuver", "a_approuver_avec_defauts"].includes(s) ? "warn" : "bad");
const targetName = (target) => { const c = targets.find((x) => `${x.kind}:${x.id}` === target || x.id === String(target).split(":").pop()) || projectList.find((p) => p.cle === target); return c ? c.nom : target; };

/* Minimal Markdown, applied AFTER escaping: no HTML from a document is ever interpreted. */
function md(text) {
  let header = "";
  const fm = String(text).match(/^---\r?\n([\s\S]*?)\r?\n---\r?\n?/);
  if (fm) {
    text = text.slice(fm[0].length);
    const desc = (fm[1].match(/^description:\s*(.*)$/m) || [])[1];
    if (desc) header = `<p class="vide">${esc(desc)}</p>`;
  }
  const rows = esc(text).replace(/\r/g, "").split("\n");
  let html = "", entries = false, code = false;
  const inline = (l) => l.replace(/`([^`]+)`/g, "<code>$1</code>").replace(/\*\*([^*]+)\*\*/g, "<b>$1</b>");
  const cells = (l) => l.trim().replace(/^\||\|$/g, "").split("|").map((c) => c.trim());
  for (let i = 0; i < rows.length; i++) {
    const l = rows[i];
    if (l.startsWith("```")) { html += code ? "</pre>" : "<pre>"; code = !code; continue; }
    if (code) { html += l + "\n"; continue; }
    if (/^\s*\|.*\|\s*$/.test(l) && /^\s*\|?\s*:?-{2,}/.test(rows[i + 1] || "")) {   // Markdown table
      if (entries) { html += "</ul>"; entries = false; }
      let t = `<div class="table-md"><table><thead><tr>${cells(l).map((c) => `<th>${inline(c)}</th>`).join("")}</tr></thead><tbody>`;
      i += 2;
      while (i < rows.length && /^\s*\|.*\|\s*$/.test(rows[i])) { t += `<tr>${cells(rows[i]).map((c) => `<td>${inline(c)}</td>`).join("")}</tr>`; i++; }
      i--; html += t + "</tbody></table></div>"; continue;
    }
    const m = l.match(/^(#{1,4})\s+(.*)$/);
    const li = l.match(/^\s*(?:[-*]|\d+\.)\s+(.*)$/);
    if (!li && entries) { html += "</ul>"; entries = false; }
    if (/^-{3,}$/.test(l.trim())) { html += "<hr>"; continue; }
    if (m) html += `<h${m[1].length + 1}>${inline(m[2])}</h${m[1].length + 1}>`;
    else if (li) { if (!entries) { html += "<ul>"; entries = true; } html += `<li>${inline(li[1])}</li>`; }
    else if (l.trim()) html += `<p>${inline(l)}</p>`;
  }
  return `<div class="contenu">${header}${html}${entries ? "</ul>" : ""}${code ? "</pre>" : ""}</div>`;
}

/* Durations: « 42 s », « 3 min 05 s », « 1 h 12 min ». */
function formatDuration(s) {
  s = Math.max(0, Math.round(+s || 0));
  if (s < 60) return `${s} s`;
  if (s < 3600) return `${Math.floor(s / 60)} min ${String(s % 60).padStart(2, "0")} s`;
  return `${Math.floor(s / 3600)} h ${String(Math.floor((s % 3600) / 60)).padStart(2, "0")} min`;
}
const seconds = (a, b) => (Date.parse(b || new Date().toISOString()) - Date.parse(a)) / 1000;
/* Live timer: base (seconds already counted) + time elapsed since data-depuis. */
const timer = (since, base = 0) => `<span class="chrono" data-depuis="${esc(since)}" data-base="${Math.round(base || 0)}">${formatDuration((base || 0) + seconds(since))}</span>`;

function chipList(el, items, active, onclick) {
  el.innerHTML = items.map(([v, t]) => `<button class="puce ${v === active ? "sel" : ""}" data-v="${esc(v)}">${esc(t)}</button>`).join("");
  el.querySelectorAll(".puce").forEach((b) => (b.onclick = () => { el.querySelectorAll(".puce").forEach((x) => x.classList.remove("sel")); b.classList.add("sel"); onclick(b.dataset.v); }));
}

function showView(v) {
  view = v;
  document.body.dataset.vue = v;
  document.body.classList.add("fixe");
  $$(".vue").forEach((el) => (el.hidden = el.id !== `vue-${v}`));
  renderTabs();
  if (v === "projets") (currentProject ? openProject(currentProject) : loadProjects());
  if (v === "gestion") showManagement();
  if (v === "perso") showCustom(!library || Date.now() - libraryLoadedAt > 120000);   // catalog cached for 2 min: instant tabs
}
/* Header: Projets / Gestion. In Projets: tabs « Tous », one per project, « + »; then two blocks. */
let projectList = [], currentBlock = "ensemble";
const ALL_BLOCKS = ["ensemble"], PROJECT_BLOCKS = ["taches", "detail", "equipe", "branches", "projet"];
let projectGit = {};                                         // project key → git repo? (Branches tab)
/* Tab order: order of addition (a new project goes last), kept between sessions */
function projectOrder(entries) {
  let order = [];
  try { order = JSON.parse(localStorage.getItem("ordre-projets") || "[]"); } catch (e) { order = []; }
  if (!Array.isArray(order)) order = [];
  const keys = entries.map((x) => x.cle);
  if (!order.length) order = [...entries].sort((a, b) => (a.kind === b.kind ? 0 : a.kind === "project" ? -1 : 1)).map((x) => x.cle);
  order = order.filter((c) => keys.includes(c));
  keys.forEach((c) => { if (!order.includes(c)) order.push(c); });
  try { localStorage.setItem("ordre-projets", JSON.stringify(order)); } catch (e) { /* optional */ }
  return order.map((c) => entries.find((x) => x.cle === c));
}
function renderTabs() {
  $$("nav button[data-vue]").forEach((b) => b.classList.toggle("actif", b.dataset.vue === view));
  const el = $("#onglets-p");
  if (!el) return;
  $("#btn-sup").classList.toggle("actif", view === "projets" && !currentProject);
  const entries = projectList.length ? projectList : targets.map((c) => ({ cle: `${c.kind}:${c.id}`, nom: c.nom, kind: c.kind, compteurs: {} }));
  const order = projectOrder(entries.filter((x) => !x.interne));             // the studio itself (audits): no tab
  const badge = (n) => n ? `<span class="badge-onglet" title="${n} à valider">${n}</span>` : "";
  el.innerHTML = order.map((x) => `<button role="tab" data-p="${esc(x.cle)}" aria-selected="${currentProject === x.cle}" title="${esc(x.nom)}${x.kind === "topic" ? " (sujet)" : ""}">${esc(x.nom)}${badge((x.compteurs || {}).a_valider)}</button>`).join("")
;
  // selected tab made visible by scrolling ONLY the tab row (never the page: on phones,
  // scrollIntoView jumped the page to the top on every refresh), and only when the selection changes
  const a = el.querySelector('[aria-selected="true"]');
  if (a && el.dataset.vu !== currentProject) {
    el.dataset.vu = currentProject || "";
    const ra = a.getBoundingClientRect(), re = el.getBoundingClientRect();
    if (ra.left < re.left || ra.right > re.right) el.scrollLeft += ra.left - re.left - (re.width - ra.width) / 2;
  }
  tabEdges();
}
function tabEdges() {                                     // left / right fade when tabs are hidden
  const el = $("#onglets-p");
  if (!el) return;
  el.classList.toggle("cache-g", el.scrollLeft > 2);
  el.classList.toggle("cache-d", el.scrollLeft + el.clientWidth < el.scrollWidth - 2);
}
$("#onglets-p").addEventListener("scroll", tabEdges);
window.addEventListener("resize", tabEdges);
$("#onglets-p").addEventListener("wheel", (e) => {                // many projects: the mouse wheel scrolls the tabs
  const el = e.currentTarget; if (el.scrollWidth <= el.clientWidth) return;
  e.preventDefault(); el.scrollLeft += e.deltaY || e.deltaX;
}, { passive: false });
$("#onglets-p").onclick = (e) => {
  const b = e.target.closest("button");
  if (!b) return;
  const key = b.dataset.p || null;
  if (key !== currentProject) selection = null;
  if (key) openProject(key);
};
$("#plus-p").onclick = () => newProject();
$("#btn-sup").onclick = () => { selection = null; openSupervisor(); };
/* Home button: general conversation on the right, ongoing work of all projects on the left */
async function openSupervisor() {
  currentProject = null; currentBlock = "ensemble";
  try { localStorage.setItem("projet-courant", ""); } catch (e) { /* optional */ }
  renderTabs(); renderTabsBlock();
  placeSupervisor(null);
  const ps = await api("/api/projets");
  projectList = ps; renderTabs(); renderTabsBlock();
  workSummary(ps);
}
/* Large screens: tasks | task detail | Supervisor. The detail block moves into its own column, and back. */
const wideScreen = matchMedia("(min-width:2560px)");
const threeColumns = () => wideScreen.matches && !!currentProject;
function placeDetail() {
  const d = $("#detail"), col = $("#colonne-detail"), three = threeColumns();
  if (!d || !col) return;
  if (three && d.parentElement !== col) col.appendChild(d);
  if (!three && d.parentElement === col) $("#bloc-travail").insertBefore(d, $("#bloc-travail .volet[data-b='equipe']"));
  col.hidden = !three;
  document.querySelector(".p-projets").classList.toggle("trois", three);
  if (three) {
    d.hidden = false; d.classList.remove("volet");
    $("#fermer-colonne").hidden = !selection;
    if (!selection) { d.dataset.tid = ""; d.innerHTML = '<div class="accueil"><p class="vide">Choisis une tâche à gauche : son avancement et sa validation s\'affichent ici.</p></div>'; }
  } else d.classList.add("volet");
}
wideScreen.addEventListener("change", () => { placeDetail(); renderTabsBlock(); if (selection) { lastView = ""; show(); } });
$("#fermer-colonne").onclick = () => { selection = null; lastView = ""; renderTabsBlock(); taskLists(projectTasks); };
/* Work block: its tabs change depending on « Tous » or a single project */
function renderTabsBlock() {
  const el = $("#onglets-bloc");
  const p = projectList.find((x) => x.cle === currentProject) || {};
  const c = p.compteurs || {};
  const toApproveTotal = projectList.reduce((n, x) => n + ((x.compteurs || {}).a_valider || 0), 0);
  const items = !currentProject
    ? [["ensemble", `Tâches${toApproveTotal ? `<span class="badge-onglet">${toApproveTotal}</span>` : ""}`], ["sup-reglages", "Réglages"]]
    : [["taches", `Tâches${c.a_valider ? `<span class="badge-onglet">${c.a_valider}</span>` : ""}`],
       ...(selection && !threeColumns() ? [["detail", `Détail<span class="fermer-b" data-fermer-detail="1" role="button" title="Fermer la tâche" aria-label="Fermer la tâche">×</span>`]] : []),
       ["equipe", "Équipe"], ["fichiers", "Résultats"], ...(projectGit[currentProject] ? [["branches", "Branches"]] : []), ["projet", "Réglages"]];
  if (!items.some(([k]) => k === currentBlock)) currentBlock = items[0][0];
  el.innerHTML = items.map(([k, t]) => `<button role="tab" data-b="${k}" aria-selected="${k === currentBlock}">${t}</button>`).join("");
  placeDetail();
  if (!currentProject) $("#p-entete").hidden = true;
  $$("#bloc-travail .volet").forEach((v) => (v.hidden = v.dataset.b !== currentBlock));
}
function chooseBlock(b) {
  currentBlock = b; renderTabsBlock();
  if (b === "branches" && currentProject) { gitRepository = currentProject; gitDetail(); }
  if (b === "fichiers" && currentProject) projectFiles();
  if (b === "equipe" && currentProject) teamSettings();
  if (b === "sup-reglages") gSettings().catch((e) => GB("reglages", `<div class="alerte">${esc(e.message)}</div>`));
  if (b === "sup-reglages") gPhone().catch((e) => GB("telephone", `<div class="alerte">${esc(e.message)}</div>`));
  if (b === "sup-reglages") gAI().catch((e) => GB("ia", `<div class="alerte">${esc(e.message)}</div>`));
}
$("#onglets-bloc").onclick = (e) => {
  if (e.target.closest("[data-fermer-detail]")) { selection = null; lastView = ""; currentBlock = "taches"; renderTabsBlock(); taskLists(projectTasks); return; }
  const b = e.target.closest("button[data-b]");
  if (b) chooseBlock(b.dataset.b);
};
$("nav").onclick = (e) => {
  const b = e.target.closest("button[data-vue]");
  if (!b) return;
  showView(b.dataset.vue);
};
async function openPath(path) { if (sessionInfo.distant) { alert("Ça s'ouvre sur le PC : fais-le depuis le PC."); return; } try { await api("/api/ouvrir", { chemin: path }); } catch (e) { alert(e.message); } }

/* ================================================================ REQUEST */
let threadSignature = "";
async function loadConversation(scroll) {
  const scope = projectChat;
  const msgs = await api("/api/conversation" + (scope ? `?projet=${encodeURIComponent(scope)}` : ""));
  if (scope !== projectChat) return;                      // the page changed during the request
  const sig = (scope || "") + "#" + userName + "#" + (aiState ? (aiState.actif || "aucune") : "") + "#" + msgs.map((m) => `${m.id}:${m.etat}:${m.proposition.etat || ""}:${m.proposition.suivi ? m.proposition.suivi.status + m.proposition.suivi.etape_nom + m.proposition.suivi.cout_usd : ""}`).join("|");
  if (sig === threadSignature && !scroll) return;
  const thread = $("#fil");
  const atBottom = thread.scrollHeight - thread.scrollTop - thread.clientHeight < 40;
  threadSignature = sig;
  lastUser = (msgs.filter((m) => m.auteur === "mel").pop() || {}).id;
  const finish = msgs[msgs.length - 1];
  lastSupervisorId = finish && finish.auteur !== "mel" ? finish.id : 0;   // the user already answered: no more buttons
  const noAi = aiState && !aiState.actif;
  thread.innerHTML = msgs.length ? msgs.map(bubble).join("") : (scope
    ? `<div class="vide-chat"><p class="vide">Pose une question sur ce projet ou décris un travail :<br>le Superviseur répond ou propose une tâche ici.</p>${noAi ? "" : startingPoints(scope)}</div>`
    : `<div class="vide-chat"><div class="accueil"><div class="grand">Salut${userName ? " " + esc(userName) : ""}.</div>
      <p class="vide">Demande-moi où en est un projet, pose une question, ou décris un travail :<br>je réponds ou je le confie à la bonne équipe.</p>${noAi ? `<div class="cta-ia"><p class="warn">Aucune IA connectée pour l'instant.</p><button class="btn principal" data-connecter-ia>Connecter une IA</button></div>` : startingPoints("")}</div></div>`);
  $$("[data-connecter-ia]").forEach((b) => (b.onclick = openAiSettings));
  $$("#fil [data-suggestion]").forEach((b) => (b.onclick = () => {
    $("#message").value = b.dataset.suggestion; adjustInputField();
    if (b.dataset.envoyer) $("#envoyer").click(); else { const m = $("#message"); m.focus(); m.setSelectionRange(m.value.length, m.value.length); }
  }));
  msgs.filter((m) => m.proposition.etat === "proposee").forEach(bindProposal);
  $$("#fil [data-modifier]").forEach((b) => (b.onclick = async () => {
    try {
      const r = await api(`/api/conversation/${b.dataset.modifier}/modifier`, {});
      if (r.lance) infoBubble("La tâche déjà lancée continue");
      $("#message").value = r.texte; adjustInputField(); $("#message").focus(); threadSignature = ""; loadConversation(true);
    } catch (e) { alert(e.message); }
  }));
  $$("#fil [data-arreter]").forEach((b) => (b.onclick = async () => {
    b.disabled = true;
    try { await api(`/api/conversation/${b.dataset.arreter}/arreter`, {}); threadSignature = ""; loadConversation(); } catch (e) { alert(e.message); }
  }));
  if (scroll || atBottom) thread.scrollTop = thread.scrollHeight;  // scrolls INSIDE the block, never the page
}
/* Starting points of an empty conversation, by kind of project. « … » = to complete before sending. */
const SUGGESTIONS = {
  home: ["Où en sont mes projets ?", "Qu'est-ce qui attend ma validation ?", "Que peux-tu faire pour moi ?", "Crée un nouveau sujet sur …"],
  code: ["Où en est ce projet ?", "Relis le code et liste les bugs probables", "Propose les 3 prochaines étapes", "Ajoute la fonctionnalité suivante : …"],
  web: ["Où en est ce site ?", "Vérifie l'accessibilité et le référencement", "Améliore la page d'accueil", "Ajoute une page : …"],
  doc: ["Résume ce qui existe déjà", "Fais un plan détaillé", "Relis et corrige le style", "Rédige la partie : …"],
  art: ["Propose 3 directions visuelles", "Fais une planche de références", "Crée une image de …", "Range et renomme les images"],
  topic: ["Résume ce qu'on sait sur ce sujet", "Cherche des références et des sources", "Propose les prochaines étapes", "Fais une recherche sur …"],
};
function startingPoints(scope) {
  const p = scope ? projectList.find((x) => x.cle === scope) || {} : null;
  const kind = !p ? "home" : p.kind === "topic" ? (p.type === "art" ? "art" : "topic") : SUGGESTIONS[p.type] ? p.type : "code";
  const list = SUGGESTIONS[kind];
  return `<div class="suggestions" aria-label="Suggestions">${list.map((s) => {
    const open = s.endsWith("…");
    return `<button class="suggestion" data-suggestion="${esc(open ? s.slice(0, -1) : s)}"${open ? "" : ' data-envoyer="1"'}>${esc(s)}</button>`;
  }).join("")}</div>`;
}
function placeSupervisor(key) {
  projectChat = key || null;
  $("#sup-portee").textContent = key ? "conversation de ce projet" : "conversation générale";
  $("#message").placeholder = key ? "Question ou travail pour ce projet · @ fichier · / raccourci" : "Pose une question ou décris un travail · @ fichier · / raccourci";
  threadSignature = "";
  loadConversation(true);
}

let lastUser = null, userName = "";
function bubble(m) {
  if (m.auteur === "mel") {
    const atts = (m.proposition && m.proposition.pieces) || [];
    const views = atts.map((c) => /\.(png|jpe?g|gif|webp)$/i.test(c) ? `<img src="/api/piece?chemin=${encodeURIComponent(c)}" alt="">` : `<span>${esc(c.split("/").slice(3).join("/"))}</span>`).join("");
    return `<div class="bulle mel"><span class="heure-msg">${msgTime(m.at)}</span>${esc(m.texte)}${atts.length ? `<div class="pj">${views}</div>` : ""}${m.id === lastUser ? `<button class="lien modifier-msg" data-modifier="${m.id}" title="Arrête la réponse si elle est en cours et remet ton texte dans la zone de saisie">Modifier</button>` : ""}</div>`;
  }
  if (m.etat === "en_cours") return `<div class="bulle sup attente"><div class="qui">Superviseur</div>réfléchit… <span class="chrono" data-depuis="${esc(m.at)}"></span> <button class="lien arreter-msg" data-arreter="${m.id}">Arrêter</button></div>`;
  if (m.etat === "annule") return `<div class="bulle sup attente"><div class="qui">Superviseur</div>${esc(m.texte)}</div>`;
  const p = m.proposition || {};
  let prop = "";
  if (p.etat === "proposee") {
    prop = `<div class="proposition" data-id="${m.id}">
      ${p.titre ? `<div class="titre-prop"><b>${esc(p.titre)}</b></div>` : ""}<small>Je propose de confier à</small> <b>${esc(p.nom_cible || p.cible)}</b>${p.nouvelle_cible ? ' <span class="etat warn">nouveau sujet, créé au lancement</span>' : ""}${p.role ? ` <small>· rôle ${esc(p.role)}</small>` : ""}
      ${p.erreur ? `<div class="alerte">${esc(p.erreur)}</div>` : ""}${p.conseil ? `<div class="discret conseil-prop">${esc(p.conseil)}</div>` : ""}
      <div class="demande-prop">${md(p.demande)}</div>
      <textarea class="demande-edit" hidden>${esc(p.demande)}</textarea>
      ${p.etapes ? `<div class="chaine-bloc"><b>Chaîne de ${p.etapes.length} étapes</b> <small class="discret">— chacune attend ta validation avant la suivante</small><ol>${p.etapes.map((e) => `<li><b>${esc(e.role || "rôle choisi par le studio")}</b> — ${esc(e.demande)}</li>`).join("")}</ol></div>` : ""}
      <div class="bas-prop"><label>Modèle <select class="p-mod"></select></label><label>Effort <select class="p-eff"></select></label><label>Mode <select class="p-mode"></select></label>
        <span class="boutons-prop"><button class="lien modifier-dem">Modifier la demande</button><button class="btn discret ignorer">Ignorer</button><button class="btn discret nuit-b" title="En file : part pendant la nuit, rapport le matin">Cette nuit</button><button class="btn principal lancer">Lancer</button></span></div>
      <span class="warn msg"></span></div>`;
  } else if (p.etat === "lancee") {
    prop = `<div class="proposition suivi-prop"><span class="ok">Lancé</span> dans <b>${esc(p.nom_cible || p.cible)}</b> — <button class="lien" data-voir="${esc(p.tache)}" data-cible="${esc(p.cible)}">voir la tâche</button>${liveTracking(p.suivi)}</div>`;
  } else if (p.etat === "nuit") {
    prop = `<div class="proposition"><span class="info">Prévue cette nuit</span> dans <b>${esc(p.nom_cible || p.cible)}</b> — part à ${esc(nightWindow[0])}, rapport le matin. Laisse le PC allumé. <button class="lien" data-nuit-retirer="${esc(p.nuit)}">Ne pas la faire</button></div>`;
  } else if (p.etat === "equipe_proposee") {                // team composed by the Supervisor: one click applies it
    const e = p.equipe || {};
    prop = `<div class="proposition proposition-equipe" data-equipe="${m.id}"><div class="titre-prop"><b>Équipe proposée pour ${esc(p.nom_cible || p.cible || "")}</b></div>
      ${p.erreur ? `<div class="alerte">${esc(p.erreur)}</div>` : ""}
      ${(e.activer || []).length ? `<p class="sous-titre-g">Au travail</p><ul class="liste-equipe">${e.activer.map((x) => `<li><b>${esc(x.nom)}</b>${x.effort ? ` <small class="discret">effort ${esc(x.effort)}</small>` : ""}${x.consignes ? `<br><small>${esc(x.consignes)}</small>` : ""}</li>`).join("")}</ul>` : ""}
      ${(e.desactiver || []).length ? `<p class="sous-titre-g">Mis de côté</p><p class="discret">${e.desactiver.map((x) => esc(x.nom)).join(" · ")}</p>` : ""}
      ${Array.isArray(e.mcp) ? `<p class="sous-titre-g">Serveurs MCP</p><p class="discret">${e.mcp.length ? e.mcp.map(esc).join(" · ") : "aucun"}</p>` : ""}
      <div class="bas-prop"><span class="boutons-prop"><button class="btn discret" data-equipe-ignorer="${m.id}">Ignorer</button><button class="btn principal" data-equipe-appliquer="${m.id}"${p.erreur ? " disabled" : ""}>Appliquer</button></span></div>
      <span class="warn msg"></span></div>`;
  } else if (p.etat === "equipe_appliquee") {
    prop = `<div class="proposition"><span class="ok">Équipe appliquée</span> à <b>${esc(p.nom_cible || p.cible)}</b> — <button class="lien" data-ouvrir-equipe="${esc(p.cible)}">voir l'équipe</button></div>`;
  } else if (p.etat === "chaine_fusion") {               // chain step validated: one click merges, the next step starts
    prop = `<div class="proposition"><span class="boutons-prop"><button class="btn principal" data-chaine-fusion="${esc(p.tache)}" data-rid="${m.id}">${p.suivante ? `Fusionner et lancer l'étape ${p.suivante}` : "Fusionner"}</button>
      <button class="lien" data-voir="${esc(p.tache)}" data-cible="${esc(p.projet || "")}">voir la tâche</button></span><span class="warn msg"></span></div>`;
  } else if (p.etat === "chaine_application") {
    prop = `<div class="proposition"><span class="boutons-prop"><button class="btn principal" data-chaine-continuer="${esc(p.chaine)}" data-rid="${m.id}">Continuer</button>
      <button class="lien" data-voir="${esc(p.tache)}" data-cible="${esc(p.projet || "")}">voir la tâche</button></span><span class="warn msg"></span></div>`;
  } else if (p.etat === "chaine_fait") {
    prop = `<div class="discret" style="margin-top:8px">✔ Fait.</div>`;
  } else if (p.etat === "ignoree") {
    prop = `<div class="discret" style="margin-top:8px">Proposition ignorée.</div>`;
  }
  if ((p.installer || []).length) {                        // extensions suggested by the Supervisor: one click each
    const TYPE_NAMES = { skill: "skill", mcp: "connecteur", logiciel: "logiciel", pack: "pack" };
    prop += `<div class="proposition installer-prop"><div class="titre-prop"><b>À installer</b> <small class="discret">vérifié avant installation, rien ne part sans ton clic</small></div>
      <ul class="liste-equipe">${p.installer.map((x) => `<li><b>${esc(x.nom)}</b> <small class="discret">${TYPE_NAMES[x.type] || esc(x.type)}</small>${x.pourquoi ? `<br><small>${esc(x.pourquoi)}</small>` : ""}
        <span class="boutons-prop">${x.installe ? '<span class="ok">installé</span>'
          : x.url ? `<button class="btn petit" data-installer-url="${esc(x.url)}">Voir et ajouter</button>`
          : x.cle ? `<button class="btn petit" data-installer-fiche="${esc(x.id)}" title="Une clé ou un prérequis est nécessaire">Configurer</button>`
          : `<button class="btn principal petit" data-installer-sup="${esc(x.id)}" data-rid="${m.id}">Installer</button>`}</span></li>`).join("")}</ul>
      <span class="warn msg"></span></div>`;
  }
  if (p.question && m.id === lastSupervisorId && !p.repondu) {         // Supervisor question: one-click answer
    const q = p.question;
    const fileName = (o) => o.split(/[\\/]/).pop();
    prop += `<div class="reponses-rapides" data-q="${m.id}">${q.type === "texte"
      ? `<input class="champ" placeholder="Ta réponse…" maxlength="500"><button class="btn principal petit" data-rep-texte="1">Répondre</button>`
      : q.options.map((o) => `<button class="btn${/^oui$/i.test(o) ? " principal" : ""} petit" data-rep="${esc(o)}" title="${esc(o)}">${esc(q.type === "fichier" ? "📄 " + fileName(o) : o)}</button>`).join("")
        + (q.type === "fichier" ? `<button class="btn discret petit" data-rep-joindre="1">Autre fichier…</button>` : "")}</div>`;
  }
  return `<div class="bulle sup ${m.etat === "erreur" ? "erreur" : ""}"><div class="qui">Superviseur<span class="heure-msg">${msgTime(m.at, p.duree_s)}</span>${p.bilan ? ` · <button class="lien" data-voir="${esc(p.bilan)}" data-cible="${esc(p.projet || "")}">bilan de « ${esc(p.bilan_titre || "la tâche")} »</button>` : ""}${p.duree_s != null ? `<span class="temps">répondu en ${formatDuration(p.duree_s)}${p.modele_sup ? " · " + esc(p.modele_sup) : ""}</span>` : ""}</div>${m.etat === "erreur" ? esc(m.texte) : md(m.texte)}${prop}${p.rapport_nuit && p.rapport_nuit.length ? `<div class="rapport-nuit">${p.rapport_nuit.map((x) => `<button class="btn discret petit" data-voir="${esc(x.tid)}" data-cible="${esc(x.cible)}">${esc(x.titre.slice(0, 40))} · ${esc(x.etat)}</button>`).join("")}</div>` : ""}</div>`;
}

/* Time of a message in the conversation (« 02:14 »; with the date when it is not today); a reply: asked + answer time */
function msgTime(iso, plusS) {
  try {
    const d = new Date(new Date(iso).getTime() + (+plusS || 0) * 1000);
    if (isNaN(d)) return "";
    const today = d.toDateString() === new Date().toDateString();
    return (today ? "" : d.toLocaleDateString("fr-FR", { day: "2-digit", month: "2-digit" }) + " ") + d.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" });
  } catch { return ""; }
}
/* Launched task, followed from the conversation: stage, working time, cost (when known) */
const TRACK_STAGES = ["Plan", "Agent", "Vérif", "Relecture", "Fin"];            // same five names everywhere: Plan · Agent · Vérif · Relecture · Fin
function liveTracking(s) {
  if (!s) return "";
  const active = ACTIVE_STATUSES.includes(s.status), waiting = TO_APPROVE.includes(s.status);
  const i = waiting ? 4 : Math.max(0, PHASES.findIndex(([, names]) => names.includes(s.etape_nom)));
  const done = !active && !waiting;
  const time = active ? timer(s.etape_depuis || s.updated_at, s.duree_s) : s.duree_s ? formatDuration(s.duree_s) : "";
  const cost = s.cout_usd ? `${(+s.cout_usd).toFixed(2)} $` : "";
  const stages = done ? `<span class="etat ${couleur(s.status)}">${esc(LABELS[s.status] || s.status)}</span>`
    : `<div class="phases phases-suivi" role="img" aria-label="Étape : ${TRACK_STAGES[i]}">${TRACK_STAGES.map((n, k) => `<span class="${k < i ? "faite" : k === i ? "active" : ""}">${n}</span>`).join("")}</div>`;
  return `<div class="suivi">${stages}<small class="discret">${[time && `⏱ ${time}`, cost].filter(Boolean).join(" · ")}</small></div>`;
}
function bindProposal(m) {
  const el = document.querySelector(`.proposition[data-id="${m.id}"]`);
  if (!el) return;
  const proposedAi = AI_ROLES[m.proposition.role] || defaultAi();   // the proposed agent's AI: its models and effort levels
  const modsP = modelsFor(proposedAi), proposedEfforts = effortsFor(proposedAi.famille);
  let model = modsP.some(([v]) => v === m.proposition.modele) ? m.proposition.modele : "";   // Supervisor's choices, editable
  listChoice(el.querySelector(".p-mod"), modsP, model, (v) => (model = v));
  el.querySelector(".p-mod").disabled = modsP.length < 2;
  let mode = m.proposition.mode || "";
  listChoice(el.querySelector(".p-mode"), MODES, mode, (v) => (mode = v));
  let effort = proposedEfforts.some(([v]) => v === m.proposition.effort) ? m.proposition.effort : "";
  listChoice(el.querySelector(".p-eff"), proposedEfforts, effort, (v) => (effort = v));
  el.querySelector(".p-eff").disabled = proposedEfforts.length < 2;
  const zone = el.querySelector(".demande-edit");
  const adjust = () => { zone.style.height = "auto"; zone.style.height = zone.scrollHeight + 4 + "px"; };
  el.querySelector(".modifier-dem").onclick = (ev) => {
    zone.hidden = !zone.hidden; el.querySelector(".demande-prop").hidden = !zone.hidden;
    ev.currentTarget.textContent = zone.hidden ? "Modifier la demande" : "Voir la demande";
    if (!zone.hidden) { adjust(); zone.focus(); }
  };
  zone.oninput = adjust;
  el.querySelector(".lancer").onclick = async (ev) => {
    if (ev.currentTarget.disabled) return;
    const b = ev.currentTarget; b.disabled = true;
    try {
      const r = await api(`/api/conversation/${m.id}/lancer`, { demande: zone.value, modele: model, mode, effort });
      threadSignature = ""; loadConversation(); updateBadge(); targets = await api("/api/cibles");
      el.querySelector(".msg").textContent = `Lancé : ${r.tid}`;
    } catch (e) { el.querySelector(".msg").textContent = e.message; b.disabled = false; }
  };
  el.querySelector(".nuit-b").onclick = async (ev) => {
    const b = ev.currentTarget; b.disabled = true;
    try {
      await api(`/api/conversation/${m.id}/nuit`, { demande: zone.value, modele: model, mode, effort });
      threadSignature = ""; loadConversation();
    } catch (e) { el.querySelector(".msg").textContent = e.message; b.disabled = false; }
  };
  el.querySelector(".ignorer").onclick = async () => { await api(`/api/conversation/${m.id}/ignorer`, {}); threadSignature = ""; loadConversation(); };
}

document.addEventListener("click", async (ev) => {          // team proposals: apply / ignore / open the Équipe tab
  const a = ev.target.closest("[data-equipe-appliquer]"), i = ev.target.closest("[data-equipe-ignorer]"), o = ev.target.closest("[data-ouvrir-equipe]");
  if (!a && !i && !o) return;
  ev.preventDefault();
  if (o) { currentProject = o.dataset.ouvrirEquipe; currentBlock = "equipe"; showView("projets"); setTimeout(() => chooseBlock("equipe"), 300); return; }
  const b = a || i; b.disabled = true;
  try {
    if (a) {
      const r = await api(`/api/conversation/${a.dataset.equipeAppliquer}/equipe`, {}); infoBubble(r.message); if (currentBlock === "equipe") teamSettings();
      if (r.suite) await api("/api/conversation", { texte: "Équipe appliquée. Propose maintenant le travail prévu (tâche ou chaîne).",   // work was asked too: go on
        projet: projectChat || "", modele: supModel(), effort: supervisorEffort });
    }
    else await api(`/api/conversation/${i.dataset.equipeIgnorer}/ignorer`, {});
    threadSignature = ""; loadConversation();
  } catch (e) { const msg = b.closest(".proposition")?.querySelector(".msg"); if (msg) msg.textContent = e.message; b.disabled = false; }
});
document.addEventListener("click", async (ev) => {          // chain announcements: merge / continue in one click
  const f = ev.target.closest("[data-chaine-fusion]"), c = ev.target.closest("[data-chaine-continuer]");
  if (!f && !c) return;
  ev.preventDefault();
  const b = f || c; b.disabled = true;
  try {
    if (f) await api(`/api/taches/${f.dataset.chaineFusion}/fusionner`, {});
    else await api(`/api/chaines/${c.dataset.chaineContinuer}/continuer`, {});
    await api(`/api/conversation/${b.dataset.rid}/fait`, {});
    threadSignature = ""; loadConversation(); updateJobs();
  } catch (e) { const msg = b.closest(".proposition")?.querySelector(".msg"); if (msg) msg.textContent = e.message; b.disabled = false; }
});
document.addEventListener("click", async (ev) => {          // extensions suggested in the conversation
  const s = ev.target.closest("[data-installer-sup]"), u = ev.target.closest("[data-installer-url]"), f = ev.target.closest("[data-installer-fiche]");
  if (!s && !u && !f) return;
  ev.preventDefault();
  if (u) { showView("perso"); setTimeout(() => { skillFromUrl(); $("#su-url").value = u.dataset.installerUrl; $("#su-voir").click(); }, 600); return; }
  if (f) { showView("perso"); await showCustom(true).catch(() => {}); elementSheet(f.dataset.installerFiche); return; }
  s.disabled = true; s.textContent = "Installation…";
  try { const r = await api(`/api/conversation/${s.dataset.rid}/installer`, { id: s.dataset.installerSup }); infoBubble(r.message); }
  catch (e) { const msg = s.closest(".proposition")?.querySelector(".msg"); if (msg) msg.textContent = e.message; s.disabled = false; s.textContent = "Installer"; }
  threadSignature = ""; loadConversation();
});
let nightWindow = ["01:00", "07:00"];
api("/api/nuit").then((n) => (nightWindow = n.plage)).catch(() => {});
document.addEventListener("click", async (ev) => {
  const n = ev.target.closest("[data-nuit-retirer]");
  if (!n) return;
  try { await api("/api/nuit/retirer", { id: n.dataset.nuitRetirer }); threadSignature = ""; loadConversation(); } catch (e) { alert(e.message); }
});
document.addEventListener("click", async (ev) => {
  const b = ev.target.closest("[data-voir]");
  if (!b) return;
  ev.preventDefault();
  let target = b.dataset.cible;
  if (!target || !target.includes(":")) {                    // link without a project (old message): use the task's
    try {
      const t = (await api(`/api/taches/${b.dataset.voir}`)).tache.target;
      const c = (targets || []).find((k) => k.id === String(t).split(":").pop() && (!String(t).includes(":") || `${k.kind}:${k.id}` === t));
      target = c ? `${c.kind}:${c.id}` : target;
    } catch { /* the task will still open if the project is known */ }
  }
  selection = b.dataset.voir; lastView = ""; currentBlock = "detail"; currentProject = target || currentProject; showView("projets");
  if (document.body.dataset.mob === "sup") mobileView("travail");   // phone: leave the Supervisor for the task
  if (window.innerWidth <= 900) window.scrollTo({ top: 0 });
});

/* Attachments: drag and drop (files and folders), paste an image, ＋ button. Sent on « Envoyer ». */
let attached = [];                       // { fichier, rel, apercu }
const MAX_FILES = 200, MAX_TOTAL = 300 * 1024 * 1024;
function addAttachment(file, rel) {
  if (attached.length >= MAX_FILES) return;
  if (attached.reduce((s, j) => s + j.fichier.size, 0) + file.size > MAX_TOTAL) { alert("Trop lourd : 300 Mo au total par message."); return; }
  const preview = /^image\//.test(file.type) ? URL.createObjectURL(file) : "";
  attached.push({ fichier: file, rel: rel || file.name, apercu: preview });
  renderAttachments();
}
function renderAttachments() {
  $("#jointes").innerHTML = attached.map((j, i) => `<div class="jointe">${j.apercu ? `<img src="${j.apercu}" alt="">` : "📄"}<span>${esc(j.rel)}</span><button class="x" data-i="${i}">✕</button></div>`).join("");
  $$("#jointes .x").forEach((b) => (b.onclick = () => { attached.splice(+b.dataset.i, 1); renderAttachments(); }));
}
async function readEntry(entry, path) {
  if (entry.isFile) return new Promise((ok) => entry.file((f) => { addAttachment(f, path + f.name); ok(); }, ok));
  if (!entry.isDirectory) return;
  const reader = entry.createReader();
  let batch;
  do {
    batch = await new Promise((ok) => reader.readEntries(ok, () => ok([])));
    for (const e of batch) await readEntry(e, path + entry.name + "/");
  } while (batch.length);
}
let repoCounter = 0;
document.addEventListener("dragenter", (e) => { if (view !== "projets") return; e.preventDefault(); if (repoCounter++ === 0) { const d = document.createElement("div"); d.className = "depot"; d.id = "depot"; d.textContent = "Dépose tes fichiers ici"; document.body.appendChild(d); } });
document.addEventListener("dragleave", () => { if (--repoCounter <= 0) { repoCounter = 0; $("#depot")?.remove(); } });
document.addEventListener("dragover", (e) => { if (view === "projets") e.preventDefault(); });
document.addEventListener("drop", async (e) => {
  if (view !== "projets") return;
  e.preventDefault(); repoCounter = 0; $("#depot")?.remove();
  const items = [...(e.dataTransfer.items || [])];
  if (items.length && items[0].webkitGetAsEntry) { for (const it of items) { const en = it.webkitGetAsEntry(); if (en) await readEntry(en, ""); } }
  else [...e.dataTransfer.files].forEach((f) => addAttachment(f));
});
$("#message").addEventListener("paste", (e) => {
  let n = 0;
  for (const it of e.clipboardData.items) {
    if (it.kind === "file") { const f = it.getAsFile(); if (f) { n++; addAttachment(f, f.name && f.name !== "image.png" ? f.name : `image-collee-${Date.now()}-${n}.png`); } }
  }
  if (n) e.preventDefault();
});
/* Like a terminal: selecting with the mouse copies; right-click pastes (or copies if there is a selection).
   Shift + right-click keeps the usual menu. Pasting text asks the browser for permission once. */
function infoBubble(text) {
  let b = $("#bulle-info");
  if (!b) { b = document.createElement("div"); b.id = "bulle-info"; b.setAttribute("role", "status"); document.body.appendChild(b); }
  b.textContent = text; b.classList.add("visible");
  clearTimeout(infoBubble.t); infoBubble.t = setTimeout(() => b.classList.remove("visible"), 1200);
}
const textField = (el) => el && ((el.tagName === "TEXTAREA") || (el.tagName === "INPUT" && /^(text|search|url|email|)$/i.test(el.type || ""))) && !el.readOnly && !el.disabled;
function currentSelection() {
  const a = document.activeElement;
  if (textField(a) && a.selectionStart !== a.selectionEnd) return a.value.slice(a.selectionStart, a.selectionEnd);
  return String(window.getSelection() || "");
}
async function copyText(text) {
  try { await navigator.clipboard.writeText(text); return true; }
  catch { try { return document.execCommand("copy"); } catch { return false; } }
}
document.addEventListener("mouseup", async (e) => {
  if (e.button !== 0) return;
  const t = currentSelection();
  if (t.trim() && await copyText(t)) infoBubble("Copié");
});
function insertText(field, text) {
  field.focus();
  if (!document.execCommand("insertText", false, text)) field.setRangeText(text, field.selectionStart, field.selectionEnd, "end");
  field.dispatchEvent(new Event("input", { bubbles: true }));
}
document.addEventListener("contextmenu", async (e) => {
  if (e.shiftKey) return;                                       // Shift + right-click: usual menu
  e.preventDefault();
  const t = currentSelection();
  if (t.trim()) {                                               // a selection: right-click copies it
    if (await copyText(t)) infoBubble("Copié");
    const a = document.activeElement; if (textField(a)) a.setSelectionRange(a.selectionEnd, a.selectionEnd); else window.getSelection().removeAllRanges();
    return;
  }
  const field = textField(e.target) ? e.target : (view === "projets" && $("#message") && $("#message").offsetParent ? $("#message") : null);
  if (!field) { infoBubble("Rien où coller ici"); return; }
  try {                                                         // copied images → Supervisor attachments
    if (field.id === "message" && navigator.clipboard.read) {
      let n = 0;
      for (const it of await navigator.clipboard.read()) {
        const type = it.types.find((x) => x.startsWith("image/"));
        if (type) { const blob = await it.getType(type); n++; addAttachment(new File([blob], `image-collee-${Date.now()}-${n}.png`, { type }), `image-collee-${Date.now()}-${n}.png`); }
      }
      if (n) { infoBubble(n > 1 ? `${n} images jointes` : "Image jointe"); return; }
    }
  } catch { /* no image or read refused: try text instead */ }
  try {
    const text = await navigator.clipboard.readText();
    if (text) { insertText(field, text); infoBubble("Collé"); } else infoBubble("Presse-papiers vide");
  } catch { infoBubble("Autorise le presse-papiers (ou Ctrl+V)"); field.focus(); }
});
$("#joindre").onclick = () => ($("#menu-joindre").hidden = !$("#menu-joindre").hidden);
$("#j-fichiers").onclick = () => $("#fichiers").click();
$("#j-dossier").onclick = () => $("#dossier").click();
$("#fichiers").onchange = (e) => { [...e.target.files].forEach((f) => addAttachment(f)); e.target.value = ""; $("#menu-joindre").hidden = true; };
$("#dossier").onchange = (e) => { [...e.target.files].forEach((f) => addAttachment(f, f.webkitRelativePath || f.name)); e.target.value = ""; $("#menu-joindre").hidden = true; };

let lastSupervisorId = 0;                                 // only the Supervisor's last question keeps its buttons
document.addEventListener("click", (e) => {
  const zone = e.target.closest(".reponses-rapides"); if (!zone) return;
  const b = e.target.closest("button"); if (!b) return;
  if (b.dataset.repJoindre) { $("#joindre").click(); return; }
  const text = b.dataset.repTexte ? zone.querySelector("input").value.trim() : b.dataset.rep;
  if (!text) return;
  zone.querySelectorAll("button").forEach((x) => (x.disabled = true));
  $("#message").value = text; send();
});
document.addEventListener("keydown", (e) => {
  if (e.key === "Enter" && e.target.closest(".reponses-rapides input")) { e.preventDefault(); e.target.parentElement.querySelector("[data-rep-texte]").click(); }
});
async function send() {
  const t = $("#message").value.trim();
  if (!t && !attached.length) return;
  let batch = "";
  try {
    if (attached.length) {
      batch = "L" + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
      $("#envoyer").textContent = "Envoi…";
      for (const j of attached) {
        const r = await fetch(`/api/pieces?lot=${batch}&rel=${encodeURIComponent(j.rel)}`, { method: "POST", headers: { "X-Studio": "1", "Content-Type": "application/octet-stream" }, body: j.fichier });
        if (!r.ok) throw new Error((await r.json().catch(() => ({}))).erreur || `envoi de ${j.rel} refusé`);
      }
    }
    await api("/api/conversation", { texte: t, lot: batch, projet: projectChat || "", modele: supModel(), effort: supervisorEffort });
    $("#message").value = ""; adjustInputField(); attached = []; renderAttachments();
    threadSignature = ""; await loadConversation(true);
  } catch (e) { alert(e.message); }
  finally { $("#envoyer").textContent = "Envoyer"; }
}
$("#envoyer").onclick = send;
/* Dictation (mic left of Envoyer): browser speech recognition, text typed live into the input;
   otherwise a recording transcribed on the PC (faster-whisper). Nothing is sent before « Envoyer ». */
const Reco = window.SpeechRecognition || window.webkitSpeechRecognition;
let dictation = null, recorder = null;
function micState(state) {                                  // "" | "ecoute" | "attente"
  const b = $("#micro");
  b.classList.toggle("actif", state === "ecoute"); b.classList.toggle("attente", state === "attente");
  b.setAttribute("aria-pressed", String(state === "ecoute"));
  b.title = state === "ecoute" ? "J'écoute… clique pour arrêter" : state === "attente" ? "Transcription…" : "Dicter à la voix";
}
function writeDictation(base, text) { const t = $("#message"); t.value = base + text; adjustInputField(); t.scrollTop = t.scrollHeight; }
async function saveForPC(base) {
  if (!navigator.mediaDevices || !window.MediaRecorder) { infoBubble("Dictée indisponible sur cet appareil."); return; }
  let flux;
  try { flux = await navigator.mediaDevices.getUserMedia({ audio: true }); }
  catch { infoBubble("Autorise le micro pour dicter."); return; }
  const chunks = [], rec = new MediaRecorder(flux);
  rec.ondataavailable = (e) => e.data.size && chunks.push(e.data);
  rec.onstop = async () => {
    flux.getTracks().forEach((x) => x.stop()); recorder = null; micState("attente");
    try {
      const blob = new Blob(chunks, { type: rec.mimeType || "audio/webm" });
      const r = await fetch("/api/dicter", { method: "POST", headers: { "X-Studio": "1", "Content-Type": blob.type }, body: blob });
      const j = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(j.erreur || "dictée impossible");
      if (j.texte) writeDictation(base, j.texte); else infoBubble("Rien entendu.");
    } catch (e) { infoBubble(e.message); }
    micState(""); $("#message").focus();
  };
  recorder = rec; rec.start(); micState("ecoute");
}
$("#micro").onclick = () => {
  if (dictation) { dictation.stop(); return; }
  if (recorder) { recorder.stop(); return; }
  if ($("#micro").classList.contains("attente")) return;
  const v = $("#message").value, base = v && !/\s$/.test(v) ? v + " " : v;
  if (!Reco) return saveForPC(base);
  const r = new Reco(), android = /Android/i.test(navigator.userAgent);
  r.lang = navigator.language || "fr-FR"; r.interimResults = true; r.continuous = !android;   // Android: one sentence at a time (otherwise duplicates)
  let final = "", fallbackValue = false;
  r.onresult = (e) => {
    let temporary = "";
    for (let i = e.resultIndex; i < e.results.length; i++) { const x = e.results[i]; if (x.isFinal) final += x[0].transcript; else temporary += x[0].transcript; }
    writeDictation(base, (final + temporary).replace(/^\s+/, ""));
  };
  r.onerror = (e) => {
    if (e.error === "not-allowed" || e.error === "service-not-allowed") infoBubble("Autorise le micro pour dicter.");
    else if (e.error === "network" || e.error === "language-not-supported") fallbackValue = true;   // browser service unreachable: the PC transcribes
    else if (e.error !== "no-speech" && e.error !== "aborted") infoBubble("Dictée interrompue.");
  };
  r.onend = () => { dictation = null; micState(""); if (fallbackValue) saveForPC(base); else $("#message").focus(); };
  dictation = r;
  try { r.start(); micState("ecoute"); } catch { dictation = null; saveForPC(base); }
};

/* « @ »: mention a project file or function; its content is sent with the message */
let mentionEntries = [], mentionsIndex = 0, mentionsTimer = null, mentionsRequest = 0;
function mentionsBox() {
  let b = $("#mentions");
  if (!b) { b = document.createElement("ul"); b.id = "mentions"; b.className = "mentions"; b.hidden = true; b.setAttribute("role", "listbox"); $(".saisie").appendChild(b); }
  return b;
}
function closeMentions() { mentionEntries = []; mentionsBox().hidden = true; }
function currentToken() {
  const t = $("#message"), before = t.value.slice(0, t.selectionStart);
  const r = before.match(/^\/([a-z0-9-]*)$/i);                // « / » at the very start of a message: shortcuts
  if (r) return { q: r[1], debut: 0, raccourci: true };
  const m = before.match(/(?:^|\s)@("?)([^\s"@]*)$/);
  return m ? { q: m[2], debut: before.length - m[2].length - 1 - m[1].length } : null;
}
let shortcutsCache = null;
async function searchShortcuts(q) {
  if (!shortcutsCache) shortcutsCache = await api("/api/raccourcis");
  q = q.toLowerCase();
  return shortcutsCache.filter((r) => !q || r.nom.includes(q) || r.titre.toLowerCase().includes(q))
    .map((r) => ({ type: "raccourci", jeton: r.texte, libelle: "/" + r.nom, detail: r.titre }));
}
function renderMentions() {
  const b = mentionsBox();
  if (!mentionEntries.length) { b.hidden = true; return; }
  b.innerHTML = mentionEntries.map((m, i) => `<li role="option" data-mention="${i}" class="${i === mentionsIndex ? "actif" : ""}"><span class="type-m">${m.type === "fonction" ? "ƒ" : m.type === "raccourci" ? "⚡" : "📄"}</span><b>${esc(m.libelle)}</b><small>${esc(m.detail)}</small></li>`).join("")
    + (mentionEntries[0].type === "raccourci" ? '<li class="aide-m discret">↑ ↓ pour choisir · Entrée : la demande s\'écrit, tu peux la modifier avant d\'envoyer</li>'
      : '<li class="aide-m discret">↑ ↓ pour choisir · Entrée pour ajouter · le contenu part avec ton message</li>');
  b.hidden = false;
}
function chooseMention(i) {
  const m = mentionEntries[i], j = currentToken();
  if (!m || !j) return closeMentions();
  const t = $("#message"), finish = t.selectionStart;
  const addition = m.type === "raccourci" ? m.jeton : m.jeton + " ";
  t.value = t.value.slice(0, j.debut) + addition + t.value.slice(finish);
  const bracket = m.type === "raccourci" ? addition.indexOf("[") : -1;      // « [décris…] »: selected, ready to be replaced
  const pos = j.debut + addition.length;
  if (bracket >= 0) { t.setSelectionRange(j.debut + bracket, j.debut + addition.indexOf("]", bracket) + 1); t.focus(); closeMentions(); adjustInputField(); return; }
  t.setSelectionRange(pos, pos); t.focus(); closeMentions(); adjustInputField();
}
$("#message").addEventListener("input", () => {
  clearTimeout(mentionsTimer);
  const j = currentToken();
  if (!j) return closeMentions();
  mentionsTimer = setTimeout(async () => {
    const n = ++mentionsRequest;
    let l = [];
    try { l = j.raccourci ? await searchShortcuts(j.q) : await api(`/api/mentions?projet=${encodeURIComponent(projectChat || "")}&q=${encodeURIComponent(j.q)}`); } catch { return; }
    if (n !== mentionsRequest || !currentToken()) return;
    mentionEntries = l; mentionsIndex = 0; renderMentions();
  }, 150);
});
document.addEventListener("mousedown", (e) => {
  const li = e.target.closest("[data-mention]");
  if (li) { e.preventDefault(); chooseMention(+li.dataset.mention); }
  else if (!e.target.closest("#mentions, #message")) closeMentions();
});
$("#message").addEventListener("keydown", (e) => {
  if (mentionEntries.length && !mentionsBox().hidden) {
    if (e.key === "ArrowDown" || e.key === "ArrowUp") { e.preventDefault(); mentionsIndex = (mentionsIndex + (e.key === "ArrowDown" ? 1 : -1) + mentionEntries.length) % mentionEntries.length; renderMentions(); return; }
    if (e.key === "Enter" || e.key === "Tab") { e.preventDefault(); chooseMention(mentionsIndex); return; }
    if (e.key === "Escape") { e.preventDefault(); closeMentions(); return; }
  }
  if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); }
});
function adjustInputField() { const t = $("#message"); t.style.height = "auto"; t.style.height = Math.min(t.scrollHeight, 200) + "px"; }
$("#message").addEventListener("input", adjustInputField);

/* ================================================================ PROJECTS */
async function loadProjects() {
  const ps = await api("/api/projets");
  projectList = ps;
  let key = null;
  try { key = localStorage.getItem("projet-courant"); } catch (e) { /* storage unavailable */ }
  if (key === "") return openSupervisor();                // last screen opened: the Supervisor
  const order = projectOrder(ps);
  if (!ps.some((x) => x.cle === key)) key = order.length ? order[0].cle : null;
  if (key) return openProject(key);
  currentProject = null; currentBlock = "ensemble";            // no project: prompt to add one
  renderTabs(); renderTabsBlock();
  placeSupervisor(null);
  allTasks = { t: [], ps: [] }; overviewLists();
}
/* Home, center: what is running or awaiting approval, project by project, then the latest finished tasks */
async function workSummary(ps) {
  let t = [];
  try { t = await api("/api/taches"); } catch { return; }
  if (currentProject) return;
  ps = ps || await api("/api/projets");
  allTasks = { t, ps };
  overviewLists();
}
let allTasks = { t: [], ps: [] }, overviewSearch = "", statusE = "";
function overviewLists() {
  const { t, ps } = allTasks;
  const keyOf = (x) => { const c = (targets || []).find((k) => k.id === String(x.target).split(":").pop() && (!String(x.target).includes(":") || `${k.kind}:${k.id}` === x.target)); return c ? `${c.kind}:${c.id}` : x.target; };
  const nameOf = (x) => (ps.find((p) => p.cle === keyOf(x)) || {}).nom || targetName(x.target);
  const item = (x) => `<li data-voir="${esc(x.id)}" data-cible="${esc(keyOf(x))}">
    <div class="ligne1"><span class="etat ${couleur(x.status)}">${esc(taskLabel(x))}</span><small class="temps">${taskTime(x)}</small></div>
    <small title="${esc(withoutChain(x.request || ""))}"><b>${esc(nameOf(x))}</b> · ${x.chaine ? "⛓ " : ""}${esc(taskName(x))}</small>${phaseBar(x)}${previews(x)}${quickActions(x)}</li>`;
  const validate = t.filter((x) => TO_APPROVE.includes(x.status)), cours = t.filter((x) => IN_PROGRESS.includes(x.status));
  const allEntries = t.filter((x) => !TO_APPROVE.includes(x.status) && !IN_PROGRESS.includes(x.status));
  const stripAccents = (x) => (x || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  const q = stripAccents(overviewSearch.trim());
  const filtered = allEntries.filter((x) => (!statusE || (statusE === "ok" ? ["approuvee", "appliquee"].includes(x.status) : x.status === statusE))
    && (!q || stripAccents(`${nameOf(x)} ${taskName(x)} ${x.request} ${x.summary}`).includes(q)));
  $("#e-valider").innerHTML = validate.map(item).join("") || '<li class="vide" style="cursor:default">Rien à valider.</li>';
  $("#e-cours").innerHTML = cours.map(item).join("") || `<li class="vide" style="cursor:default">${ps.length ? "Rien en cours." : "Aucun projet pour l'instant : ajoute-en un avec ＋."}</li>`;
  $("#e-finies").innerHTML = filtered.slice(0, 50).map(item).join("") || (allEntries.length ? '<li class="vide" style="cursor:default">Aucune tâche ne correspond.</li>' : "");
  $("#e-t-finies").textContent = `Terminées (${allEntries.length})`;
  $("#e-compte").textContent = (q || statusE) && allEntries.length ? `${filtered.length} sur ${allEntries.length}` : "";
  if (!$("#e-statut").childElementCount) chipList($("#e-statut"), FINISHED_STATUSES, statusE, (v) => { statusE = v; overviewLists(); });
}
$("#e-recherche").oninput = () => { overviewSearch = $("#e-recherche").value; overviewLists(); };

/* Home, left: agent presets, shortcuts to internal settings, studio status */
function readableReset(t) {
  if (!t) return "";
  const s = t - Date.now() / 1000;
  if (s <= 0) return "remis à zéro";
  if (s < 3600) return `remise à zéro dans ${Math.max(1, Math.round(s / 60))} min`;
  if (s < 86400) return `remise à zéro dans ${Math.floor(s / 3600)} h ${String(Math.round((s % 3600) / 60)).padStart(2, "0")}`;
  return "remise à zéro " + new Date(t * 1000).toLocaleString("fr-FR", { weekday: "short", hour: "2-digit", minute: "2-digit" });
}
async function homeLimits() {
  const el = $("#limites");
  if (!el) return;
  const l = await api("/api/limites").catch(() => null);
  if (!l) { el.innerHTML = '<p class="lim-info">Limites indisponibles.</p>'; return; }
  el.innerHTML = ["Claude", "Codex"].map((name) => {
    const x = l[name] || {};
    if (!x.ok && x.reconnexion === "en_cours") { setTimeout(homeLimits, 8000); return `<div class="lim-outil"><div class="lim-tete">${name}</div><p class="lim-info">Reconnexion de Claude Code…</p></div>`; }
    if (!x.ok && x.reconnexion === "bouton") return `<div class="lim-outil"><div class="lim-tete">${name}</div><p class="lim-info">${esc(x.info || "Connexion expirée.")} <button class="btn petit" data-reco-claude="1">Reconnecter</button></p></div>`;
    if (!x.ok) return `<div class="lim-outil"><div class="lim-tete">${name}</div><p class="lim-info">${esc(x.info || "Indisponible.")}</p></div>`;
    const seen = x.vu && Date.now() / 1000 - x.vu > 600 ? `relevé ${new Date(x.vu * 1000).toLocaleString("fr-FR", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" })}` : "à l'instant";
    return `<div class="lim-outil" title="${esc(x.info || "")}"><div class="lim-tete">${name}<small>${esc(seen)}</small></div>` + x.fenetres.map((f) => {
      const c = f.pct >= 85 ? "haut" : f.pct >= 60 ? "moyen" : "";
      return `<div class="lim-ligne"><span>${esc(f.nom)}</span><span class="lim-barre"><i class="${c}" style="width:${Math.max(f.pct, 1.5)}%"></i></span><b>${Math.round(f.pct)} %</b>`
        + (f.reinit ? `<span class="lim-reinit">${esc(readableReset(f.reinit))}</span>` : "") + "</div>";
    }).join("") + "</div>";
  }).join("");
}
document.addEventListener("click", async (ev) => {      // Usage: reconnect the subscription tool (only if it asks)
  const b = ev.target.closest("[data-reco-claude]");
  if (!b) return;
  b.disabled = true; b.textContent = "Reconnexion…";
  try {
    const r = await api(b.dataset.recoClaude === "login" ? "/api/claude/connexion" : "/api/claude/reconnecter", {});
    if (r.ok) { infoBubble(r.info); homeLimits(); updateAlerts && updateAlerts(); return; }
    b.closest(".lim-info").innerHTML = `${esc(r.info)} <button class="btn petit" data-reco-claude="login">Se connecter</button>`;
  } catch (e) { b.closest(".lim-info").textContent = e.message; }
});
async function removeProject(key, name) {
  if (!confirm(`Retirer « ${name} » du studio ?\n\nRien n'est supprimé : sa fiche est rangée dans Archives\\${key.startsWith("project:") ? "projets" : "sujets"}-retires, ses fichiers, ses tâches passées et sa mémoire restent intacts.`)) return;
  try { const r = await api(`/api/cibles/${encodeURIComponent(key)}/retirer`, {}); targets = await api("/api/cibles"); selection = null; loadProjects(); alert(r.message); }
  catch (e) { alert(e.message); }
}
function newProject() {
  const d = $("#dlg-nouveau");
  newForm($("#dlg-corps"));
  if (!d.open) d.showModal();
  $("#nv-nom").focus();
}
$("#dlg-nouveau").addEventListener("click", (e) => { if (e.target === e.currentTarget) e.currentTarget.close(); });   // click outside the window
function newForm(nv) {
  nv.innerHTML = `<p class="titre" style="margin:0 0 10px">Ajouter un projet ou un sujet</p><div class="puces" id="nv-kind"></div>
    <p class="sous-titre-g" style="margin:10px 0 6px">Partir de</p><div class="puces petites" id="nv-modele"></div><small class="discret" id="nv-modele-aide"></small>
    <input class="champ" id="nv-nom" placeholder="Nom (ex. Mon site web)"><input class="champ" id="nv-chemin" placeholder="Dossier du projet (C:\\…)" hidden>
    <div class="actions" style="margin:0"><button class="btn principal" id="nv-ok">Ajouter</button><button class="btn discret" id="nv-annuler">Annuler</button></div><small id="nv-msg" class="warn"></small>`;
  let kind = "project";
  chipList($("#nv-kind"), [["project", "Projet (avec dossier)"], ["topic", "Sujet (sans dossier)"]], kind, (v) => { kind = v; $("#nv-chemin").hidden = v !== "project"; });
  $("#nv-chemin").hidden = false;
  let model = "";
  const helpTexts = { "": "Aucune équipe imposée : tous les agents restent disponibles.", site: "Développeur web, designer, SEO, accessibilité, tests…",
    jeu: "Game designer, programmeur, level designer, direction artistique, son, scénario, tests… (mode Performance)",
    appli: "Programmeur, interface, tests, sécurité, documentation…", document: "Recherche, rédaction, traduction…",
    visuels: "Direction artistique, illustration, art technique…" };
  chipList($("#nv-modele"), [["", "Vide"], ["site", "Site web"], ["jeu", "Jeu vidéo"], ["appli", "Application"], ["document", "Document"], ["visuels", "Images"]], model,
    (v) => { model = v; $("#nv-modele-aide").textContent = helpTexts[v]; });
  $("#nv-modele-aide").textContent = helpTexts[""];
  $("#nv-nom").focus();
  $("#nv-annuler").onclick = (ev) => { ev.stopPropagation(); $("#dlg-nouveau").close(); };
  $("#nv-ok").onclick = async (ev) => {
    ev.stopPropagation();
    const name = $("#nv-nom").value.trim();
    const id = name.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
    if (!id) { $("#nv-msg").textContent = "Donne un nom."; return; }
    if (kind === "project" && !$("#nv-chemin").value.trim()) { $("#nv-msg").textContent = "Indique le dossier du projet."; return; }
    try { await api("/api/cibles", { kind, id, nom: name, chemin: kind === "project" ? $("#nv-chemin").value.trim() : "", modele: model }); targets = await api("/api/cibles"); projectList = await api("/api/projets"); $("#dlg-nouveau").close(); selection = null; openProject(`${kind}:${id}`); }
    catch (e) { $("#nv-msg").textContent = e.message; }
  };
}

let projectTasks = [];
async function openProject(key) {
  const change = currentProject !== key;
  currentProject = key;
  try { localStorage.setItem("projet-courant", key); } catch (e) { /* optional */ }
  if (selection && (change || !PROJECT_BLOCKS.includes(currentBlock))) currentBlock = "detail";
  else if (change || !PROJECT_BLOCKS.includes(currentBlock)) currentBlock = "taches";
  renderTabs(); renderTabsBlock();
  if (projectChat !== key) placeSupervisor(key);
  const p = await api(`/api/projets/${encodeURIComponent(key)}`);
  if (currentProject !== key) return;
  $("#p-retirer").onclick = () => removeProject(key, p.nom);
  $("#p-nom").textContent = p.nom;
  $("#p-info").textContent = `${p.kind === "project" ? "projet" : "sujet"}${p.dossier ? " · " + p.dossier : " · sans dossier"} · mémoire ${p.memoire.replace(/^studio:/, "")}`;
  $("#p-contexte").innerHTML = p.contexte ? md(p.contexte) : '<p class="vide">Pas encore de contexte.</p>';
  renderProjectProfile(key, p.profil || "", p.profil_accueil || "normal");
  $("#p-modifier-ctx").hidden = !p.contexte_chemin;
  $("#p-modifier-ctx").onclick = () => openPath(p.contexte_chemin);
  buildInfo(p);
  taskLists(p.taches);
  projectTeam(p.equipe);
  projectHeader(p);
  renderTabsBlock();
  if (selection) show();
}
/* Project header: the name and the agents' mode, switchable right here (applies to the next tasks) */
function projectHeader(p) {
  const el = $("#p-entete");
  if (!el) return;
  const current = p.profil || p.profil_accueil || "normal";
  el.innerHTML = `<b class="nom-entete">${esc(p.nom)}</b><label class="mode-entete" title="Mode des agents pour ce projet : pris en compte dès la prochaine tâche">Mode
    <select id="p-entete-mode">${PROFILES.map(([v, t]) => `<option value="${v}"${v === current ? " selected" : ""}>${t}</option>`).join("")}</select></label>`;
  el.hidden = false;
  $("#p-entete-mode").onchange = async (e) => {
    try {
      const r = await api("/api/profil", { cible: p.cle, profil: e.target.value });
      p.profil = r.profil; renderProjectProfile(p.cle, r.profil, p.profil_accueil || "normal"); infoBubble(`Mode ${e.target.selectedOptions[0].textContent}`);
    } catch (er) { infoBubble(er.message); e.target.value = current; }
  };
}

const CHAIN_STATE = { en_cours: "en cours", attente_fusion: "attend ta fusion", attente_application: "attend que tu appliques le résultat", en_pause: "en pause", terminee: "terminée", arretee: "arrêtée" };
function chainBlock(c) {
  if (!c) return "";
  return `<div class="chaine-bloc"><b>⛓ Chaîne « ${esc(c.titre)} »</b> · <span class="${c.statut === "en_pause" ? "warn" : c.statut === "terminee" ? "ok" : ""}">${CHAIN_STATE[c.statut] || esc(c.statut)}</span>
    ${c.note ? `<div class="discret">${esc(c.note)}</div>` : ""}
    <ol>${c.etapes.map((e, i) => `<li class="${i === c.courant ? "courante" : ""}">${esc(e.nom_role)} — ${esc(e.demande.slice(0, 120))}${e.etat ? ` <span class="etat ${couleur(e.etat)}">${LABELS[e.etat] || esc(e.etat)}</span>` : ""}${e.tache && e.tache !== selection ? ` <button class="lien" data-voir="${esc(e.tache)}" data-cible="${esc(currentProject || "")}">voir</button>` : ""}</li>`).join("")}</ol>
    ${["en_cours", "attente_fusion", "attente_application", "en_pause"].includes(c.statut) ? `<div class="actions">${c.statut === "en_pause" ? `<button class="btn" data-chaine-reprendre="${esc(c.id)}">Relancer l'étape ${c.courant + 1}</button>` : ""}${c.peut_continuer ? `<button class="btn principal" data-chaine-continuer="${esc(c.id)}">Continuer : lancer l'étape ${c.courant + 2 > c.etapes.length ? "finale" : c.courant + 2}</button>` : ""}<button class="btn discret danger" data-chaine-arreter="${esc(c.id)}">Arrêter la chaîne</button></div>` : ""}</div>`;
}
document.addEventListener("click", async (ev) => {
  const r = ev.target.closest("[data-chaine-reprendre]"), a = ev.target.closest("[data-chaine-arreter]"), c = ev.target.closest("[data-chaine-continuer]");
  if (!r && !a && !c) return;
  const button = r || a || c;
  if (button.disabled) return;
  button.disabled = true;
  try {
    if (c) { if (!confirm("Le travail de cette étape est-il en place (fusionné, appliqué, ou rien à reporter) ? L'étape suivante va partir.")) { button.disabled = false; return; } const x = await api(`/api/chaines/${c.dataset.chaineContinuer}/continuer`, {}); if (x.tid) selection = x.tid; }
    else if (a) { if (!confirm("Arrêter cette chaîne ? Les étapes déjà faites restent ; les suivantes ne partiront pas.")) return; await api(`/api/chaines/${a.dataset.chaineArreter}/arreter`, {}); }
    else { const x = await api(`/api/chaines/${r.dataset.chaineReprendre}/reprendre`, {}); selection = x.tid; }
    lastView = ""; setTimeout(() => openProject(currentProject), 300);
  } catch (e) { alert(e.message); button.disabled = false; }
});

/* « Retirer » a file from the changes before approving: it goes back to its original state */
document.addEventListener("click", async (ev) => {
  const b = ev.target.closest("[data-retirer]");
  if (!b) return;
  ev.preventDefault(); ev.stopPropagation();
  const name = b.dataset.retirer;
  if (!confirm(`Retirer « ${name.split("/").pop()} » ?\nCe changement ne sera pas appliqué. La version de l'agent reste gardée dans le dossier de la tâche.`)) return;
  b.disabled = true; b.textContent = "Retrait…";
  try {
    await api(`/api/taches/${selection}/decision`, { decision: "retirer", fichiers: [name] });
    setTimeout(() => { lastView = ""; openProject(currentProject); }, 700);
  } catch (e) { alert(e.message); b.disabled = false; b.textContent = "Retirer"; }
}, true);

/* Readable diff: file by file, additions in green, deletions in red, line numbers */
function renderDiff(text, removable = false) {
  if (!text || !text.trim()) return "";
  const rows = text.split("\n"), taskFiles = [];
  let f = null, a = 0, b = 0;
  for (let i = 0; i < rows.length; i++) {
    const l = rows[i];
    if (l.startsWith("--- ") && (rows[i + 1] || "").startsWith("+++ ")) {
      const plus = rows[i + 1].slice(4).trim(), minus = l.slice(4).trim();
      const name = (plus === "/dev/null" ? minus.replace(/^a\//, "") : plus.replace(/^b\//, "")).replace(/\t.*$/, "");
      f = { nom: name, plus: 0, moins: 0, rangs: [], nouveau: false, supprime: false, fonctions: [] }; taskFiles.push(f); i++; continue;
    }
    if (!f || l.startsWith("diff --git") || l.startsWith("index ")) continue;
    const h = l.match(/^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@/);
    if (h) {
      a = +h[1]; b = +h[3]; if (h[1] === "0" && h[2] === "0") f.nouveau = true; if (h[3] === "0" && h[4] === "0") f.supprime = true;
      const ctx = l.replace(/^@@[^@]*@@\s*/, "").trim();          // function or class containing the change
      const fn = (ctx.match(/([A-Za-z_][\w:~]*)\s*\(/) || ctx.match(/(?:class|struct|def|function)\s+([\w:]+)/) || [])[1];
      if (fn && !f.fonctions.includes(fn)) f.fonctions.push(fn);
      f.rangs.push(["hunk", "", "", l]); continue;
    }
    if (l.startsWith("+")) { f.plus++; f.rangs.push(["add", "", b++, l.slice(1)]); }
    else if (l.startsWith("-")) { f.moins++; f.rangs.push(["del", a++, "", l.slice(1)]); }
    else if (l.startsWith(" ")) { f.rangs.push(["ctx", a++, b++, l.slice(1)]); }
  }
  if (!taskFiles.length) return "";
  let budget = 4000;
  const tp = taskFiles.reduce((n, x) => n + x.plus, 0), tm = taskFiles.reduce((n, x) => n + x.moins, 0);
  const fnCount = new Set(taskFiles.flatMap((x) => x.fonctions.map((fn) => x.nom + fn))).size;
  return `<section class="compte-rendu changements"><p class="titre">Changements · ${taskFiles.length} fichier${taskFiles.length > 1 ? "s" : ""}${fnCount ? ` · ${fnCount} fonction${fnCount > 1 ? "s" : ""}` : ""} · <span class="ok">+${tp}</span> <span class="bad">−${tm}</span></p>
    <p class="discret aide-diff">Clique sur un fichier pour voir ce qui a changé.${removable ? " « Retirer » : le fichier n'est pas gardé (la version de l'agent reste dans le dossier de la tâche)." : ""}</p>
    ${taskFiles.map((x) => {
      const ranks = x.rangs.slice(0, Math.max(0, budget)); budget -= ranks.length;
      return `<details class="fichier-diff"><summary><span class="nom-f">${esc(x.nom)}</span>${x.nouveau ? '<span class="type">nouveau</span>' : x.supprime ? '<span class="type">supprimé</span>' : ""}<span class="plus">+${x.plus}</span><span class="moins">−${x.moins}</span>${x.fonctions.length ? `<small class="fonctions">${x.fonctions.slice(0, 6).map(esc).join(" · ")}${x.fonctions.length > 6 ? ` · +${x.fonctions.length - 6}` : ""}</small>` : ""}${removable ? `<button type="button" class="retirer-f" data-retirer="${esc(x.nom)}" title="Ne pas garder ce changement">Retirer</button>` : ""}</summary>
        <div class="diff-lignes"><table>${ranks.map(([k, n1, n2, t]) => `<tr class="${k}"><td class="n">${n1}</td><td class="n">${n2}</td><td class="t">${esc(t) || " "}</td></tr>`).join("")}</table>
        ${ranks.length < x.rangs.length ? `<p class="discret" style="padding:4px 8px">… ${x.rangs.length - ranks.length} lignes de plus : « Ouvrir le dossier » pour le diff complet.</p>` : ""}</div></details>`;
    }).join("")}</section>`;
}

const ROLE_STATES = { travaille: "travaille", attend_mel: "attend ton accord", en_pause: "en pause", ailleurs: "occupé ailleurs", libre: "libre" };
function showDetail() {
  const d = $("#detail");
  if (!d) return;
  if (currentProject && !threeColumns()) chooseBlock("detail");
  else if (threeColumns()) renderTabsBlock();
  d.scrollTop = 0;                                          // the selected task is shown from its start, inside its block
  if (window.innerWidth <= 900) d.scrollIntoView({ behavior: matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth", block: "start" });
}
function projectTeam(eq) {
  if (!eq) return;
  const targetName = (c) => c.replace(/^(project|topic):/, "");
  const card = (r) => {
    const here = r.ici[0], elsewhere = r.ailleurs[0];
    const what = here ? `<a href="#" data-tache="${esc(here.tache)}" title="${esc(withoutChain(here.demande))}">${esc(here.titre || short(here.demande))}</a>${here.etape ? `<small>étape : ${esc(here.etape)}</small>` : ""}`
      : elsewhere ? `<small>sur ${esc(targetName(elsewhere.cible))}</small>` : "";
    return `<div class="agent ${r.etat}${r.adapte ? "" : " sur-demande"}" title="${esc(r.nom)}${r.adapte ? "" : " — sur demande pour ce projet"}">
      <div class="tete"><span class="point ${r.etat}"></span><b>${esc(r.nom)}</b></div>
      <small>${esc(TOOL_LABELS[r.outil] || r.outil)}${r.modele ? " · " + esc(r.modele) : ""}${r.adapte ? "" : " · sur demande"}</small>
      ${what}
      <span class="etat-a ${r.etat === "libre" ? "ok" : r.etat === "en_pause" ? "bad" : "warn"}">${ROLE_STATES[r.etat]}</span></div>`;
  };
  const n = eq.filter((r) => r.etat === "travaille").length;
  const rank = { travaille: 0, attend_mel: 1, en_pause: 2, ailleurs: 3, libre: 4 };
  const order = [...eq].sort((x, y) => (rank[x.etat] - rank[y.etat]) || (y.adapte - x.adapte));   // who works first
  const row = $("#p-equipe");
  row.innerHTML = order.map(card).join("");
  $$("#p-equipe a[data-tache]").forEach((a) => (a.onclick = (ev) => { ev.preventDefault(); selection = a.dataset.tache; lastView = ""; show(); showDetail(); }));
}

/* Project team: the shared roles, tuned for this project (active, model, effort, instructions) + its MCP servers */
async function teamSettings() {
  const el = $("#p-equipe-reglages"), key = currentProject;
  if (!el || !key) return;
  let v;
  try { v = await api(`/api/equipes/projet?cible=${encodeURIComponent(key)}`); } catch (e) { el.innerHTML = `<p class="warn">${esc(e.message)}</p>`; return; }
  if (currentProject !== key) return;
  const opt = (items, sel) => items.map(([k, t]) => `<option value="${esc(k)}"${k === sel ? " selected" : ""}>${esc(t)}</option>`).join("");
  const modelLabel = (m) => (SUPERVISOR_MODELS.find(([k]) => k === m) || [m, m || "auto"])[1];
  const effortLabel = (e) => (EFFORTS.find(([k]) => k === e) || [e, e || "auto"])[1];
  const rows = v.roles.map((r) => `<tr class="${r.actif ? "" : "inactif"}" data-role="${esc(r.id)}">
      <td><label style="display:flex;gap:8px;align-items:center"><input type="checkbox" data-eq="actif" ${r.actif ? "checked" : ""}><span><b>${esc(r.nom)}</b>${r.propre ? '<span class="pastille">propre au projet</span>' : ""}${r.personnalise ? '<span class="pastille perso">réglé ici</span>' : ""}<br><small class="discret">${esc(TOOL_LABELS[r.outil] || r.outil)}</small></span></label></td>
      <td>${r.outil === "claude-code" ? `<select data-eq="modele">${opt([["", `Commun (${modelLabel(r.modele_commun)})`], ...SUPERVISOR_MODELS.filter(([k]) => k)], r.modele)}</select>`
        : r.outil === "codex" && CODEX_MODELS.length > 1 ? `<select data-eq="modele">${opt([["", "Commun (celui de Codex)"], ...CODEX_MODELS.filter(([k]) => k)], r.modele)}</select>`
        : '<small class="discret">celui de l\'outil</small>'}</td>
      <td class="col-effort"><select data-eq="effort">${opt([["", `Commun (${effortLabel(r.effort_commun)})`], ...EFFORTS.filter(([k]) => k)], r.effort)}</select></td>
      <td><button class="btn discret petit" data-eq-consignes="1" title="${esc(r.consignes || "Consignes propres à ce projet")}">${r.consignes ? "Consignes ●" : "Consignes"}</button></td></tr>`).join("");
  const mcp = v.mcp.length ? `<p class="sous-titre-g" style="margin-top:14px">Serveurs MCP de ce projet</p><div class="puces petites">${v.mcp.map((m) => `<label class="puce${m.actif ? " sel" : ""}" style="cursor:pointer"><input type="checkbox" data-mcp-p="${esc(m.nom)}" ${m.actif ? "checked" : ""} hidden>${esc(m.nom)}</label>`).join("")}</div>
      <small class="discret">${v.mcp_regle ? "Choix propre à ce projet." : "Tous actifs (aucun choix propre)."} Ajoute des serveurs dans Extensions › Connecteurs.</small>` : "";
  el.innerHTML = `<p class="sous-titre-g" style="margin-top:16px">Réglages de l'équipe pour ce projet</p>
    <p class="aide-g discret">Les métiers sont communs à tous les projets. Ici, tu choisis ceux qui servent à ce projet, leur modèle, leur effort et des consignes propres. Une demande précise passe toujours avant.</p>
    <div class="matrice-defile"><table class="equipe-reglages"><thead><tr><th>Métier</th><th>Modèle</th><th class="col-effort">Effort</th><th></th></tr></thead><tbody>${rows}</tbody></table></div>
    <div class="actions" style="margin:10px 0 0"><button class="btn principal" id="eq-optimiser" title="Remet chaque métier de ce projet sur Auto : meilleur modèle selon les classements, effort selon le mode">Optimiser selon les classements</button><button class="btn" id="eq-creer">Créer un agent pour ce projet</button></div>${mcp}`;
  const configure = async (role, fieldValues) => { try { await api("/api/equipes/role", { cible: key, role, ...fieldValues }); teamSettings(); } catch (e) { alert(e.message); } };
  $$("#p-equipe-reglages tr[data-role]").forEach((tr) => {
    const role = tr.dataset.role;
    tr.querySelector('[data-eq="actif"]').onchange = (ev) => configure(role, { actif: ev.target.checked });
    const m = tr.querySelector('[data-eq="modele"]'); if (m) m.onchange = (ev) => configure(role, { modele: ev.target.value });
    tr.querySelector('[data-eq="effort"]').onchange = (ev) => configure(role, { effort: ev.target.value });
    tr.querySelector("[data-eq-consignes]").onclick = () => {
      const r = v.roles.find((x) => x.id === role);
      $("#perso-fiche-corps").innerHTML = `<h2>${esc(r.nom)}</h2><div class="meta">Consignes propres à ce projet (ajoutées à chaque mission de ce métier ici)</div>
        <div class="consignes-p"><textarea id="eq-consignes" placeholder="Ex. : Unreal 5.6, C++ seulement, suis les conventions du CLAUDE.md, teste en PIE.">${esc(r.consignes)}</textarea></div>
        <p class="warn" id="fiche-msg"></p><div class="bas"><button class="btn discret" data-fermer-fiche="1">Annuler</button><button class="btn principal" id="eq-consignes-ok">Enregistrer</button></div>`;
      $("#perso-fiche").hidden = false;
      $("#eq-consignes-ok").onclick = async () => { try { await api("/api/equipes/role", { cible: key, role, consignes: $("#eq-consignes").value }); $("#perso-fiche").hidden = true; teamSettings(); } catch (e) { $("#fiche-msg").textContent = e.message; } };
    };
  });
  $$("#p-equipe-reglages [data-mcp-p]").forEach((c) => (c.onchange = async () => {
    const names = [...$$("#p-equipe-reglages [data-mcp-p]")].filter((x) => x.checked).map((x) => x.dataset.mcpP);
    try { await api("/api/equipes/mcp", { cible: key, noms: names }); teamSettings(); } catch (e) { alert(e.message); }
  }));
  $("#eq-creer").onclick = () => { projectAgent = key; $("#creer-agent").onclick(); };
  $("#eq-optimiser").onclick = () => optimizeAgents(key);
}
/* « Optimiser selon les classements »: everything back to Auto (best AI and model per trade in the rankings) */
async function optimizeAgents(key) {
  const where = key ? "de ce projet" : "de tous les projets";
  if (!confirm(`Optimiser les agents ${where} ?\n\nChaque métier repasse sur Auto : la meilleure IA et le meilleur modèle pour ce métier selon les classements, parmi tes IA connectées ; l'effort suit le mode du projet.\nTes réglages actuels sont gardés dans une copie.`)) return;
  try {
    const r = await api("/api/agents/optimiser", key ? { cible: key } : {});
    const lines = r.plan.slice(0, 8).map((x) => `${x.role} : ${x.ia} · ${x.modele}`).join(" ; ");
    infoBubble(`${r.modifies ? r.modifies + " réglage(s) remis sur Auto" : "Déjà optimisé"}. ${lines}${r.plan.length > 8 ? " …" : ""}`);
    if (key) teamSettings(); else gTeam();
    shortcutsCache = null;
  } catch (e) { alert(e.message); }
}
let projectAgent = "";
document.addEventListener("click", (ev) => { if (ev.target.closest("[data-fermer-fiche]") && view !== "perso") $("#perso-fiche").hidden = true; });

const ACTIVE_STATUSES = ["creee", "en_cours", "en_attente_creneau"];
function taskTime(x) {
  if (ACTIVE_STATUSES.includes(x.status) && x.etape_depuis) return `⏱ ${timer(x.etape_depuis, x.duree_s)}`;
  return x.duree_s ? `⏱ ${formatDuration(x.duree_s)}` : "";
}
const withoutChain = (t) => String(t || "").split("\n\n---\nÉtape ")[0];
/* Short task name (same rule as studio/titles.py): the given title, else the first sentence of the request, 60 chars. */
function short(request, maxLength = 60) {
  let t = withoutChain(request).replace(/[`*#>]+/g, "").replace(/(?<!\w)_+|_+(?!\w)/g, "");   // keeps L_Exploration
  const a = /[$[]audit-(skills|memories)\s+(audit|fix|clean)\b/.exec(t);
  if (a) return (a[2] === "audit" ? "Audit des " : "Appliquer l'audit des ") + (a[1] === "skills" ? "skills" : "mémoires");
  t = t.split(/\s+/).join(" ").replace(/^(objectif|but|tâche|tache|demande|mission|contexte|résumé|resume|titre|todo|à faire|a faire)\s*[:：\-–—]\s*/i, "");
  t = t.split(/(?<=[.!?])\s|\s(?:où|ou|contexte|lis|lire|cible|livrable|critères?|périmètre)\s*:\s/i)[0].replace(/^[\s.;:\-–—]+|[\s.;:\-–—]+$/g, "");
  if (t.length > maxLength) { const v = t.lastIndexOf(", ", maxLength); if (v >= 25) t = t.slice(0, v); }
  if (t.length > maxLength) t = (t.slice(0, maxLength).replace(/\s+\S*$/, "").replace(/[\s,;:\-–—(]+$/, "") || t.slice(0, maxLength)) + "…";
  return t ? t[0].toUpperCase() + t.slice(1) : "Tâche";
}
/* The project name is useless in the title: the tab already shows it (« … sur RPG3D » → « … ») */
function withoutProject(t, names) {
  for (const n of [...new Set(names.filter((x) => x && x.length >= 2))].sort((a, b) => b.length - a.length)) {
    const e = n.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    t = t.replace(new RegExp(`\\s*\\b(sur|dans|de|du|pour|à|au)\\s+(le\\s+projet\\s+|le\\s+)?${e}(?![\\w-])`, "gi"), "")
      .replace(new RegExp(`^\\s*${e}\\s*[:：\\-–—]\\s*`, "i"), "").replace(new RegExp(`\\s*\\(\\s*${e}\\s*\\)`, "gi"), "");
  }
  return t.split(/\s+/).join(" ").replace(/^[\s,;:\-–—]+|[\s,;:\-–—]+$/g, "");
}
const taskName = (x) => {
  const target = String(x.target || ""), id = target.split(":").pop();
  const t = x.titre || (x.options && x.options.titre) || short(x.request || x.summary || "", 400);
  return short(withoutProject(t, [targetName(target), id]) || t, 50);
};   // the chaining reminder stays for the agent, not for the list
/* Task card: progress bar (Plan → Agent → Check → Review → Done) and latest action while running,
   direct buttons when it waits for the user (Valider, Corriger, Reprendre): a one-click decision, without opening the details. */
const PHASES = [["Plan", ["demande", "choix_cible", "contexte", "plan", "unreal"]], ["Agent", ["execution"]], ["Vérif", ["verification"]],
  ["Relecture", ["audit"]], ["Fin", ["presentation", "approbation", "application", "fusion", "finalisation", "memoire"]]];
/* Same bar at the top of the task: where it is now (Plan · Agent · Vérif · Relecture · Fin) */
function taskStepper(t, s) {
  const waiting = TO_APPROVE.includes(t.status), active = ACTIVE_STATUSES.includes(t.status);
  const failed = ["bloquee", "interrompue", "echec", "annulee"].includes(t.status);
  const ordered = [...s.etapes].sort((a, b) => (a.started_at < b.started_at ? -1 : 1));
  const current = ordered.filter((e) => e.status === "en_cours" && !e.ended_at).pop() || ordered.filter((e) => e.ended_at).pop();   // same rule as the card
  const at = current ? Math.max(0, PHASES.findIndex(([, names]) => names.includes(current.name))) : 0;
  const i = waiting ? 4 : active || failed ? at : 5;                  // 5 = everything done
  const last = waiting ? "À valider" : failed ? (LABELS[t.status] || t.status) : "";
  return `<div class="phases phases-tache${failed ? " arretee" : ""}" role="img" aria-label="Étape : ${i < 5 ? PHASES[Math.min(i, 4)][0] : "Fin"}">${PHASES.map(([n], k) =>
    `<span class="${k < i ? "faite" : k === i ? (failed ? "arret" : "active") : ""}">${k === i && last ? esc(last) : n}</span>`).join("")}</div>`;
}
function phaseBar(x) {
  if (!["creee", "en_cours"].includes(x.status)) return "";
  if (x.id === selection && $("#detail") && $("#detail").dataset.tid === x.id && !$("#detail").closest("[hidden]")) return "";   // already at the top of the open task
  const i = Math.max(0, PHASES.findIndex(([, names]) => names.includes(x.etape_nom)));
  return `<div class="phases" role="img" aria-label="Étape : ${PHASES[i][0]}">${PHASES.map(([n], k) => `<span class="${k < i ? "faite" : k === i ? "active" : ""}">${n}</span>`).join("")}</div>
    ${x.derniere_action ? `<small class="action-en-cours">${esc(x.derniere_action)}${(+x.essai || 1) > 1 ? ` · essai ${x.essai}` : ""}</small>` : ""}`;
}
function quickActions(x) {
  if (TO_APPROVE.includes(x.status)) return `<div class="rapides"><button class="btn principal petit" data-rapide="valider" data-tid="${esc(x.id)}" title="Valider sans ouvrir la tâche">Valider</button><button class="btn petit" data-rapide="corriger" data-tid="${esc(x.id)}">Corriger</button></div>`;
  if (["bloquee", "interrompue", "echec"].includes(x.status)) return `<div class="rapides">${x.summary ? `<small class="raison-blocage">${esc(String(x.summary).split("\n")[0].slice(0, 120))}</small>` : ""}<button class="btn principal petit" data-rapide="reprendre" data-tid="${esc(x.id)}">Reprendre</button></div>`;
  return "";
}
/* What a task awaiting approval produced, right on its card: first images (click = full size) and file count */
function previews(x) {
  if (!TO_APPROVE.includes(x.status)) return "";
  const imgs = x.apercus || [], more = (+x.nb_fichiers || 0) - imgs.length;
  if (!imgs.length && more <= 0) return "";
  return `<div class="apercus">${imgs.map((p) => `<button class="apercu" data-apercu="${esc(p)}" data-tid="${esc(x.id)}" title="${esc(p.split("/").pop())}"><img src="${fileUrl({ tid: x.id, chemin: p })}" alt="" loading="lazy"></button>`).join("")}${more > 0 ? `<span class="plus-f">${imgs.length ? "+ " : ""}${more} fichier${more > 1 ? "s" : ""}</span>` : ""}</div>`;
}
document.addEventListener("click", (e) => {               // thumbnail: opens the image, without opening the task
  const b = e.target.closest("[data-apercu]");
  if (!b) return;
  e.stopPropagation(); e.preventDefault();
  const chemin = b.dataset.apercu;
  showFile({ tid: b.dataset.tid, chemin, nom: chemin.split("/").pop(), genre: "image", tache: "" });
}, true);
function taskItem(x) {
  return `<li data-id="${x.id}" class="${x.id === selection ? "sel" : ""}">
    <div class="ligne1"><span class="etat ${couleur(x.status)}">${esc(taskLabel(x))}${x.chaine ? `</span><span class="badge-chaine" title="Étape d'une chaîne">⛓ ${(+x.etape || 0) + 1}` : ""}</span><small class="temps">${taskTime(x)}</small></div>
    <small title="${esc(withoutChain(x.request || ""))}">${esc(taskName(x))}</small>${phaseBar(x)}${previews(x)}${quickActions(x)}</li>`;
}
document.addEventListener("click", async (e) => {         // cards' direct buttons: before the click that opens the task
  const b = e.target.closest("[data-rapide]");
  if (!b) return;
  e.stopPropagation(); e.preventDefault();
  const tid = b.dataset.tid, a = b.dataset.rapide;
  try {
    if (a === "valider") {
      const s = await api(`/api/taches/${tid}`);
      await api(`/api/taches/${tid}/decision`, { decision: "approuver", empreinte: s.empreinte });
      infoBubble("Validée");
    } else if (a === "corriger") {
      const c = prompt("Que faut-il corriger ?"); if (!c) return;
      await api(`/api/taches/${tid}/decision`, { decision: "corriger", commentaire: c }); infoBubble("Correction demandée");
    } else if (a === "annuler") {
      if (!confirm("Annuler cette tâche ?")) return;
      await api(`/api/taches/${tid}/annuler`, {}); infoBubble("Tâche annulée");
    } else if (a === "stop") {
      b.disabled = true; b.textContent = "Arrêt…";
      await api(`/api/taches/${tid}/arreter`, {}); infoBubble("Arrêtée : « Reprendre » la relance là où elle en était");
    } else if (a === "reprendre") {
      b.disabled = true; b.textContent = "Reprise…";
      await api(`/api/taches/${tid}/reprendre`, {});
      setTimeout(async () => { const x = await api(`/api/taches/${tid}`).catch(() => null); if (x && x.tache.status === "bloquee") infoBubble("Toujours bloquée : " + (x.tache.summary || "").split("\n")[0].slice(0, 120)); }, 1500);
    }
  } catch (er) { infoBubble(er.message); }
  setTimeout(() => { lastView = ""; if (currentProject) openProject(currentProject); else workSummary(); updateBadge(); if (currentBlock === "branches") gitDetail(); }, 600);
}, true);
let finishedSearch = "", finishedStatus = "";
const FINISHED_STATUSES = [["", "Toutes"], ["ok", "Validées"], ["annulee", "Annulées"]];
function taskLists(t) {
  projectTasks = t;
  const validate = t.filter((x) => TO_APPROVE.includes(x.status)), cours = t.filter((x) => IN_PROGRESS.includes(x.status));
  const allEntries = t.filter((x) => !TO_APPROVE.includes(x.status) && !IN_PROGRESS.includes(x.status));
  const q = finishedSearch.trim().toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  const stripAccents = (x) => (x || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  const filtered = allEntries.filter((x) => (!finishedStatus || (finishedStatus === "ok" ? ["approuvee", "appliquee"].includes(x.status) : x.status === finishedStatus))
    && (!q || stripAccents(`${x.request} ${x.summary} ${x.id}`).includes(q)));
  const finishedItems = filtered.slice(0, 50);
  $("#l-valider").innerHTML = validate.map(taskItem).join("") || '<li class="vide" style="cursor:default">Rien à valider.</li>';
  $("#l-cours").innerHTML = cours.map(taskItem).join("") || '<li class="vide" style="cursor:default">Rien en cours.</li>';
  $("#l-finies").innerHTML = finishedItems.map(taskItem).join("") || (allEntries.length ? '<li class="vide" style="cursor:default">Aucune tâche ne correspond.</li>' : "");
  $("#t-finies").textContent = `Terminées (${allEntries.length})`;
  $("#f-compte").textContent = filtered.length > finishedItems.length ? `${finishedItems.length} affichées sur ${filtered.length} : précise la recherche.` : (q || finishedStatus) && allEntries.length ? `${filtered.length} sur ${allEntries.length}` : "";
  if (!$("#f-statut").childElementCount) chipList($("#f-statut"), FINISHED_STATUSES, finishedStatus, (v) => { finishedStatus = v; taskLists(projectTasks); });
  $$("#volet-taches li[data-id]").forEach((li) => (li.onclick = () => { selection = li.dataset.id; lastView = ""; show(); taskLists(t); showDetail(); }));
  renderTabsBlock();
}
$("#f-recherche").oninput = () => { finishedSearch = $("#f-recherche").value; taskLists(projectTasks); };

$(".logo").onclick = (e) => { e.preventDefault(); showView("projets"); };

async function show() {
  if (!selection) return;
  const s = await api(`/api/taches/${selection}`);
  const t = s.tache;
  const key = `${t.id}|${t.status}|${t.updated_at}|${s.etapes.length}|${s.attend_decision}|${s.chaine ? s.chaine.statut + s.chaine.courant + s.chaine.note : ""}`;
  if (key === lastView) return;
  lastView = key;
  const [res, dif] = await Promise.all([api(`/api/taches/${selection}/resultat`),
    ACTIVE_STATUSES.includes(t.status) ? Promise.resolve({ texte: "" }) : api(`/api/taches/${selection}/diff`).catch(() => ({ texte: "" }))]);
  const eq = s.equipe || {};
  // who works, with the exact model really used (read in the AI's own output; live while it works)
  const actor = eq.producteur ? `${esc(eq.producteur.role)} via ${esc(TOOL_LABELS[eq.producteur.outil] || eq.producteur.outil)}<span id="modele-direct">${eq.producteur.modele ? " · " + esc(eq.producteur.modele) : ""}</span>`
    + ` · relu par ${esc(TOOL_LABELS[eq.auditeur.outil] || eq.auditeur.outil)}${eq.auditeur.modele ? " · " + esc(eq.auditeur.modele) : ""}` : "";
  const inProgress = IN_PROGRESS.includes(t.status);
  // The result (RESULTAT.md) is split: report up front, the rest collapsed
  const SECTIONS = ["Résumé de l'exécutant", "Fichiers", "Vérifications", "Audit", "Actions dans l'éditeur Unreal", "Commandes lancées", "Tentatives précédentes"];
  const sec = { _tete: "" };
  let selected = "_tete";
  (res.texte || "").replace(/\r\n/g, "\n").split("\n").forEach((l) => {
    const m = /^## (.+)$/.exec(l);
    if (m && SECTIONS.some((k) => m[1].trim() === k || m[1].startsWith(k + " ") || m[1].startsWith(k + " —"))) { selected = m[1].trim(); sec[selected] = ""; }
    else sec[selected] += l + "\n";
  });
  Object.keys(sec).forEach((k) => (sec[k] = sec[k].trim()));
  const lowerTitles = (txt) => txt.replace(/^#{1,3}(?=[ \t])/gm, "####");   // agent headings: never at studio heading level
  const reportKey = Object.keys(sec).find((k) => k.startsWith("Résumé de l'exécutant"));
  const report = reportKey ? lowerTitles(sec[reportKey]) : "";
  const taskFiles = (sec["Fichiers"] || "").split("\n").filter((l) => l.startsWith("- ")).map((l) => l.slice(2).split(" : ")).filter(([, v]) => v && v !== "—");
  const fileCount = taskFiles.reduce((n, [, v]) => n + v.split(", ").length, 0);
  const checks = (sec["Vérifications"] || "").split("\n").filter((l) => l.startsWith("- "));
  const defects = (sec["Audit"] || "").split("\n").filter((l) => l.startsWith("- ") && !l.includes("Aucun défaut"));
  const checkOk = checks.length && checks.every((l) => l.includes("✔"));
  const ueActions = (sec["Actions dans l'éditeur Unreal"] || "").split("\n").filter((l) => l.startsWith("- ")).map((l) => l.slice(2));
  const ueWrites = ueActions.filter((l) => l.startsWith("écriture")).length;
  const nothingToApply = !fileCount;
  const chip = (ok, text) => `<span class="puce-etat ${ok ? "ok" : "bad"}">${ok ? "✔" : "✘"} ${esc(text)}</span>`;
  const verdict = res.texte ? `<div class="verdict-tache"><span class="puce-etat">${nothingToApply ? "aucun fichier modifié" : `${fileCount} fichier${fileCount > 1 ? "s" : ""} modifié${fileCount > 1 ? "s" : ""}`}</span>
      ${ueActions.length ? `<span class="puce-etat${ueWrites ? " ue" : ""}">Unreal : ${ueActions.length} action${ueActions.length > 1 ? "s" : ""}${ueWrites ? ` dont ${ueWrites} modification${ueWrites > 1 ? "s" : ""}` : ", lecture"}</span>` : ""}
      ${checks.length ? chip(checkOk, checkOk ? "vérifications OK" : "vérifications en échec") : ""}${chip(!defects.length, defects.length ? `${defects.length} défaut${defects.length > 1 ? "s" : ""} à la relecture` : "relecture OK")}</div>` : "";
  const faulty = t.status === "a_approuver_avec_defauts";
  const BTN_FOLDER = `<button class="btn discret dossier-bas" id="dossier" title="Ouvre le dossier de la tâche dans l'Explorateur">Ouvrir le dossier</button>`;
  const decision = s.attend_decision
    ? `<div class="decision-bas"><p class="aide-decision">${nothingToApply
        ? (ueWrites ? `Aucun fichier du dépôt modifié, mais ${ueWrites} modification${ueWrites > 1 ? "s" : ""} faite${ueWrites > 1 ? "s" : ""} directement dans l'éditeur Unreal (voir Détails). Classe la tâche, ou demande une correction.`
          : "Rien à appliquer : ce compte rendu ne modifie aucun fichier. Classe-le, ou demande une correction.")
        : fileCount > 1 ? `Valider applique exactement ces ${fileCount} fichiers au projet.` : "Valider applique exactement ce fichier au projet."}${faulty ? " <b class=\"warn\">La relecture a relevé des défauts.</b>" : ""}</p>
       <div class="decision"><button class="btn principal" id="ok">${nothingToApply ? "Classer" : "Valider"}</button><button class="btn" id="corr">Demander une correction</button><button class="btn discret danger" id="ann">Annuler</button></div></div>`
    : ACTIVE_STATUSES.includes(t.status) ? `<div class="decision-bas"><div class="decision"><button class="btn" id="stop" title="Arrête l'agent ; « Reprendre » le relance là où il en était (même conversation, rien n'est refait)">Stop</button><button class="btn discret danger" id="ann">Annuler</button></div></div>`
    : inProgress ? `<div class="decision-bas">${["bloquee", "interrompue", "echec"].includes(t.status) && t.summary ? `<p class="raison-blocage">${esc(t.status === "bloquee" ? "Bloquée : " : "")}${esc(t.summary.split("\n")[0].slice(0, 220))}</p>` : ""}<div class="decision"><button class="btn principal" id="rep">Reprendre</button><button class="btn discret danger" id="ann">Annuler</button></div></div>`
    : "";
  const request = withoutChain(t.request || "");
  const shortTitle = taskName(t);
  const active = ACTIVE_STATUSES.includes(t.status);
  const stepDuration = (e) => e.ended_at ? formatDuration(seconds(e.started_at, e.ended_at)) : (active && e.status === "en_cours" ? timer(e.started_at) : "—");
  const work = s.etapes.filter((e) => e.ended_at).reduce((n, e) => n + seconds(e.started_at, e.ended_at), 0);
  const activeStep = s.etapes.find((e) => !e.ended_at && e.status === "en_cours");
  const byType = {};
  s.etapes.filter((e) => e.ended_at).forEach((e) => (byType[e.name] = (byType[e.name] || 0) + seconds(e.started_at, e.ended_at)));
  const timeDetail = ["execution", "audit", "verification"].filter((k) => byType[k] >= 1).map((k) => `${k} ${formatDuration(byType[k])}`).join(" · ");
  const elapsed = `<small class="temps-tache">⏱ Temps de travail : <b>${active && activeStep ? timer(activeStep.started_at, work) : formatDuration(work)}</b>${timeDetail ? ` (${timeDetail})` : ""}</small>`;
  // Steps and log in plain French: what happened, in order, without jargon
  const STEP_NAME = { demande: "Demande reçue", choix_cible: "Projet choisi", contexte: "Contexte et mémoire lus", plan: "Plan préparé",
    unreal: "Unreal ouvert", execution: "L'agent travaille", verification: "Vérifications", audit: "Relecture par un 2e agent",
    approbation: "En attente de ta décision", application: "Résultat appliqué", fusion: "Fusion", graphe: "Studio" };
  const STEP_STATE = { termine: "✔ fini", en_cours: "en cours…", echec: "✘ échec", erreur: "✘ erreur", annule: "annulé" };
  const plaintext = (t) => String(t || "").replace("serveur unreal-mcp déjà en ligne", "déjà connecté").replace("unreal-mcp prêt", "connexion prête")
    .replace("unreal-mcp injoignable", "connexion impossible").replace(/serveur unreal-mcp|unreal-mcp/g, "connexion à Unreal").replace(/\bMCP\b/g, "connexion")
    .replace(/worktree/gi, "copie de travail").replace(/\bcommit\b/g, "commit");
  const STEP_DETAIL = (e) => plaintext( e.name === "choix_cible" ? targetName(e.detail) : e.name === "plan" ? "" : e.name === "contexte" ? (e.detail.includes("OK") ? "OK" : e.detail) : e.detail);
  const stepOrder = [...s.etapes].sort((a, b) => (a.started_at < b.started_at ? -1 : 1));
  const stages = stepOrder.map((e) => `<tr><td>${esc(STEP_NAME[e.name] || e.name)}${e.attempt > 1 ? ` <small class="discret">(essai ${e.attempt})</small>` : ""}</td>
    <td class="nowrap ${e.status === "termine" ? "ok" : e.status === "en_cours" ? "info" : "bad"}">${esc(STEP_STATE[e.status] || e.status)}</td>
    <td class="nowrap">${stepDuration(e)}</td><td>${esc(STEP_DETAIL(e)).slice(0, 140)}</td></tr>`).join("");
  const hour = (iso) => { try { return new Date(iso).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit", second: "2-digit" }); } catch { return iso; } };
  const log = s.evenements.map((e) => `<li><span class="heure">${esc(hour(e.at))}</span>${esc(plaintext(e.message.replace(/^Statut : (\w+)/, (m, x) => "Statut : " + (LABELS[x] || x))))}</li>`).join("");
  // Refreshing the same task: the page keeps its height and its separately loaded parts (live view, screenshots,
  // expanded files) while they reload, otherwise the phone scrolls back up on its own.
  const dEl = $("#detail"), sameTask = dEl.dataset.tid === t.id;
  const oldDirect = sameTask && $("#direct-tache") ? $("#direct-tache").innerHTML : "";
  const oldCaptures = sameTask && $("#captures-tache") ? $("#captures-tache").innerHTML : "";
  const openItems = sameTask ? [...$$("#detail details[open]")].map((x) => x.querySelector("summary") && x.querySelector("summary").textContent) : [];
  if (sameTask) { dEl.style.minHeight = dEl.offsetHeight + "px"; clearTimeout(dEl._libre); dEl._libre = setTimeout(() => (dEl.style.minHeight = ""), 3000); }
  else dEl.style.minHeight = "";
  dEl.dataset.tid = t.id;
  $("#detail").innerHTML = `<div class="entete-tache"><span class="etat ${couleur(t.status)}">${taskLabel(t)}</span>
      <div class="titre-tache"><h2 title="${esc(request)}">${esc(shortTitle)}</h2>${BTN_FOLDER}</div>${request.trim() !== shortTitle ? `<details class="pli demande-complete"><summary>Demande complète</summary><p>${esc(request)}</p></details>` : ""}
      ${actor ? `<small>${actor}${t.options && t.options.modele && !eq.producteur.modele ? " · modèle demandé " + esc(t.options.modele) : ""}${t.options && t.options.effort ? " · effort " + esc(EFFORT_LABELS[t.options.effort] || t.options.effort) : ""}</small>` : ""}${elapsed}</div>
    ${taskStepper(t, s)}
    ${s.simulation ? '<div class="alerte">Simulation : aucun modèle n\'a été appelé. Ce résultat montre le parcours, pas une capacité réelle.</div>' : ""}
    ${s.memoire && s.memoire !== "OK" ? `<div class="alerte">Mémoire partagée : ${esc(s.memoire)}</div>` : ""}
    ${branchActions(s, t)}
    ${["bloquee", "interrompue", "echec"].includes(t.status) && t.summary ? `<div class="alerte">${esc(t.summary)}</div>` : ""}
    ${verdict}
    ${report ? `<section class="compte-rendu"><p class="titre">Résumé</p>${md(report.replace(/^\s*[*_]*En bref[*_]*\s*:?[*_]*\s*/i, ""))}</section>`
      : res.texte ? md(res.texte) : activeStep && active ? `<p class="etape-en-cours"><span class="point travaille"></span><span id="etape-texte">${esc(STEP_NAME[activeStep.name] || activeStep.name)}${activeStep.attempt > 1 ? ` (essai ${activeStep.attempt})` : ""}</span> — ${timer(activeStep.started_at)}<span class="boutons-etape"><button class="btn petit" id="stop" title="Arrête l'agent ; « Reprendre » le relance là où il en était">Stop</button><button class="btn discret danger petit" id="ann">Annuler</button></span></p>`
      : `<p class="vide">${t.status === "bloquee" ? "Bloquée : rien n'a été produit." : inProgress ? "En attente de reprise." : "Pas de résultat."}</p>`}
    ${auditButton(t)}
    <section class="direct-tache" id="direct-tache"${oldDirect ? "" : " hidden"}>${oldDirect}</section>
    ${active && !activeStep ? decision : ""}
    ${chainBlock(s.chaine)}
    <div id="captures-tache">${oldCaptures}</div>
    ${defects.length ? `<details class="pli defauts-pli"><summary>Défauts relevés à la relecture (${defects.length})</summary><ul>${defects.map((l) => `<li>${esc(l.slice(2)).slice(0, 400)}</li>`).join("")}</ul></details>` : ""}
    ${renderDiff(dif.texte, ["a_approuver", "a_approuver_avec_defauts"].includes(t.status))}
    <div id="annuler-app"></div>
    ${active ? "" : decision}`;
  if (openItems.length) $$("#detail details").forEach((x) => { const su = x.querySelector("summary"); if (su && openItems.includes(su.textContent)) x.open = true; });
  taskActivity(t.id, ACTIVE_STATUSES.includes(t.status));
  if (["appliquee", "approuvee"].includes(t.status)) api(`/api/taches/${t.id}/annulable`).then((a) => {
    const el = $("#annuler-app");
    if (!el || !a.possible || selection !== t.id) return;
    el.innerHTML = `<div class="annuler-app"><button class="btn discret danger" id="defaire">Annuler ce qui a été appliqué</button><small class="discret">${esc(a.texte)}</small></div>`;
    $("#defaire").onclick = async (ev) => {
      if (!confirm(`Annuler ce que cette tâche a appliqué à ton projet ?\n\n${a.texte}`)) return;
      ev.currentTarget.disabled = true;
      try { const r = await api(`/api/taches/${t.id}/defaire`, {}); infoBubble(r.message); lastView = ""; show(); }
      catch (e) { alert(e.message); ev.currentTarget.disabled = false; }
    };
  }).catch(() => {});
  api(`/api/taches/${t.id}/captures`).then((l) => {
    const el = $("#captures-tache");
    if (!el || !l.length) return;
    el.innerHTML = `<details class="pli captures"${l.length <= 6 ? " open" : ""}><summary>Captures (${l.length})</summary><div class="grille-captures">${l.map((n) => `<a href="/api/taches/${esc(t.id)}/captures/${encodeURIComponent(n)}" target="_blank" rel="noopener" title="${esc(n)} — ouvrir en grand"><img src="/api/taches/${esc(t.id)}/captures/${encodeURIComponent(n)}" alt="${esc(n)}" loading="lazy"><small>${esc(n)}</small></a>`).join("")}</div></details>`;
  }).catch(() => {});
  const act = (sel, fn) => { const b = $(sel); if (b) b.onclick = fn; };
  const after = () => setTimeout(() => { lastView = ""; openProject(currentProject); updateBadge(); }, 400);
  act("#ok", () => api(`/api/taches/${selection}/decision`, { decision: "approuver", empreinte: s.empreinte }).then(after));
  act("#corr", () => { const c = prompt("Que faut-il corriger ?"); if (c) api(`/api/taches/${selection}/decision`, { decision: "corriger", commentaire: c }).then(after); });
  act("#ann", () => confirm("Annuler cette tâche ?") && api(`/api/taches/${selection}/annuler`, {}).then(after));
  act("#rep", () => { $("#rep").disabled = true; $("#rep").textContent = "Reprise…";
    api(`/api/taches/${selection}/reprendre`, {}).then(() => setTimeout(async () => {
      const x = await api(`/api/taches/${selection}`).catch(() => null);
      if (x && x.tache.status === "bloquee") infoBubble("Toujours bloquée : " + (x.tache.summary || "").split("\n")[0].slice(0, 120));
      after();
    }, 1500)).catch((e) => { infoBubble(e.message); after(); }); });
  act("#stop", () => { $("#stop").disabled = true; $("#stop").textContent = "Arrêt…"; api(`/api/taches/${selection}/arreter`, {}).then(after).catch((e) => alert(e.message)); });
  act("#dossier", () => openPath(t.id));
  act("#fusionner", async () => {
    $("#f-msg").textContent = "Fusion…";
    try { const r = await api(`/api/taches/${selection}/fusionner`, {}); $("#f-msg").textContent = r.message; lastView = ""; setTimeout(show, 600); }
    catch (e) { $("#f-msg").textContent = e.message; }
  });
  act("#compiler-t", () => compileProject(t.target, "#f-msg"));
  act("#commit-d", () => chooseBlock("branches"));
  act("#appliquer-audit", () => confirm("Appliquer les corrections de cet audit ? Rien n'est supprimé : ce qui part va en archive, dans la copie du projet.")
    && launchAudit({ cible: t.target, quoi: $("#appliquer-audit").dataset.quoi, mode: "appliquer", depuis: t.id }));

}

/* Finished audit (report): button to apply its fixes in a new task */
function auditButton(t) {
  const m = /^(?:\$|\[)audit-(skills|memories) audit/.exec(t.request || "");     // « [audit-skills audit] » (older: « $audit-skills audit »)
  if (!m || !["approuvee", "appliquee"].includes(t.status)) return "";
  const what = m[1] === "skills" ? "skills" : "memoires";
  return `<div class="actions-branche"><button class="btn principal" id="appliquer-audit" data-quoi="${what}">Appliquer les corrections</button>
    <span class="discret">${what === "skills" ? "Corrections sûres dans le projet ; les skills globaux restent listés pour toi." : "Dans la copie du projet ; rien n'est supprimé (archives)."}</span></div>`;
}

/* Merge and build (tasks done in a branch, projects with a « build » command) */
function branchActions(s, t) {
  if (!s.worktree || s.rien_a_appliquer || !["approuvee", "appliquee"].includes(t.status)) return "";
  const f = s.fusion;
  const dirty = !f && s.depot_modifie;                // merge impossible while tracked files are modified
  const merge = f ? `<span class="ok">✔ Fusionnée dans ${esc(f.branche)} (${esc(f.commit)})</span>`
    : dirty ? `<button class="btn principal" id="commit-d" title="Ouvre l'onglet Branches : coche les fichiers, clique Commit, puis reviens fusionner">Commit d'abord (${s.depot_modifie} fichier${s.depot_modifie > 1 ? "s" : ""})</button><button class="btn" id="fusionner" disabled title="Possible après le commit">Fusionner dans ${esc(s.branche_depart || "la branche de départ")}</button>`
    : `<button class="btn principal" id="fusionner">Fusionner dans ${esc(s.branche_depart || "la branche de départ")}</button>`;
  const comp = s.compilable ? `<button class="btn" id="compiler-t">Compiler</button>` : "";
  return `<div class="actions-branche">${merge}${comp}<span id="f-msg" class="discret">${f ? "Rien n'est poussé vers GitHub." : "Fusion locale, rien n'est poussé vers GitHub."}</span></div>`;
}
async function gitLine(key) {
  const el = $("#p-git");
  if (!el) return;
  el.innerHTML = "";
  if (!key.startsWith("project:")) return;
  try {
    const d = await api(`/api/git/${encodeURIComponent(key)}`);
    if (currentProject !== key) return;
    el.innerHTML = `${gitSummary(d)} · <button class="lien" id="p-branches">${d.branches.length} branche${d.branches.length > 1 ? "s" : ""} →</button>`;
    $("#p-branches").onclick = () => chooseBlock("branches");
    if (!projectGit[key]) { projectGit[key] = true; renderTabsBlock(); }
  } catch { projectGit[key] = false; if (currentBlock === "branches") chooseBlock("taches"); else renderTabsBlock(); }
}
function buildInfo(p) {
  $("#p-build").innerHTML = p.compilable ? `<div class="actions-branche" style="margin:10px 0 0"><button class="btn" id="compiler-p">Compiler</button><span id="p-build-msg" class="discret"></span></div>` : "";
  if (p.compilable) { $("#compiler-p").onclick = () => compileProject(p.cle, "#p-build-msg"); updateJobs(); }
  gitLine(p.cle);
}
async function compileProject(target, sel) {
  try { await api("/api/compiler", { cible: target }); $(sel).textContent = "Compilation lancée…"; $(sel).dataset.compile = "1"; updateJobs(); }
  catch (e) { $(sel).textContent = e.message; }
}

/* Background jobs (build, tests, install): indicator in the header */
let jobsState = {}, seenJobs = {};
const activeJobs = () => Object.values(jobsState || {}).some((j) => j.etat === "en_cours");
async function updateJobs() {
  try { jobsState = await api("/api/travaux"); } catch { return; }
  const entries = Object.entries(jobsState);
  const inProgress = entries.filter(([, j]) => j.etat === "en_cours");
  const b = $("#travaux");
  if (inProgress.length) {
    const [, j] = inProgress[0];
    b.hidden = false; b.className = "lien";
    b.innerHTML = `⚙ ${esc(j.titre)} ${timer(j.debut)}${inProgress.length > 1 ? ` (+${inProgress.length - 1})` : ""}`;
  } else {
    const finished = entries.filter(([k, j]) => j.fin && seenJobs[k] !== j.fin).sort((a, c) => (a[1].fin < c[1].fin ? 1 : -1))[0];
    if (finished) {
      const [k, j] = finished; seenJobs[k] = j.fin;
      b.hidden = false; b.className = "lien " + (j.etat === "ok" ? "ok" : "echec");
      b.textContent = `${j.etat === "ok" ? "✔" : "✖"} ${j.titre} : ${j.etat === "ok" ? "réussi" : "échec"} (voir)`;
    }
  }
  const jp = currentProject && jobsState[`compiler:${currentProject}`];
  const text = jp && (jp.etat === "en_cours" ? `compilation en cours… ${timer(jp.debut)}` : `<span class="${jp.etat === "ok" ? "ok" : "bad"}">${jp.etat === "ok" ? "✔ compilé" : "✖ échec de compilation (Gestion › Outils)"}</span> · ${formatDuration(seconds(jp.debut, jp.fin))}`);
  if (text) ["#p-build-msg", "#f-msg"].forEach((sel) => { const el = $(sel); if (el && (sel === "#p-build-msg" || el.dataset.compile)) el.innerHTML = text; });
}
$("#travaux").onclick = () => openManagement("outils");
$("#etat-memoire").onclick = () => openManagement("outils");

/* Limit gauges (header): one ring per tool, % of the 5 h window (same numbers as /usage). Blue, yellow, red;
   it pulses when the limit will be hit before the reset at the current pace. A click opens Gestion › Usage. */
async function updateAlerts() {
  let l, a = [];
  try { [l, a] = await Promise.all([api("/api/limites"), api("/api/alertes").catch(() => [])]); } catch { return; }
  const h = (t) => new Date(t * 1000).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" });
  const when = (t) => (t - Date.now() / 1000 > 86400 ? new Date(t * 1000).toLocaleDateString("fr-FR", { weekday: "long" }) + " " : "") + h(t);
  const gauges = ["Claude", "Codex"].filter((o) => l[o] && l[o].ok && (l[o].fenetres || []).length).map((o) => {
    const fs = l[o].fenetres, f = fs.find((x) => x.nom === "5 h") || fs[0], pct = Math.round(f.pct || 0);
    const al = a.find((x) => x.outil === o);
    const hue = al || pct >= 85 ? "rouge" : pct >= 60 ? "jaune" : "bleu";
    const R = 9, C = 2 * Math.PI * R;
    const title = fs.map((x) => `${x.nom} : ${Math.round(x.pct)} %${x.reinit ? " · remise à zéro " + when(x.reinit) : ""}`).join("\n")
      + (al ? `\n${al.minutes === 0 ? "Limite atteinte" : `Au rythme actuel : limite dans ~${minutes(al.minutes * 60)}`}` : "");
    return `<button class="jauge ${hue}${al ? " en-alerte" : ""}" data-jauge="1" title="${esc(o)}\n${esc(title)}" aria-label="${esc(o)} : ${pct} % de la limite de 5 h">
      <svg width="22" height="22" viewBox="0 0 22 22" aria-hidden="true"><circle cx="11" cy="11" r="${R}" class="fond"/><circle cx="11" cy="11" r="${R}" class="plein" stroke-dasharray="${(C * Math.min(pct, 100) / 100).toFixed(1)} ${C.toFixed(1)}" transform="rotate(-90 11 11)"/></svg>
      <span>${esc(o)} ${pct} %${al ? ` · ${al.minutes === 0 ? "atteinte" : "~" + minutes(al.minutes * 60)}` : ""}</span></button>`;
  });
  $("#alertes").hidden = !gauges.length;
  $("#alertes").innerHTML = gauges.join("");
}
$("#alertes").onclick = (e) => { if (e.target.closest("[data-jauge]")) openManagement("usage"); };

/* ================================================================ MANAGEMENT */
/* Gestion: a dashboard. Each internal setting has its block, everything is visible and editable in place. */
const BLOCKS_G = { equipe: "agents", outils: "outils", usage: "usage", memoire: "memoire", entretien: "entretien", skills: "docs", documents: "docs", audits: "audits", };
let managementTab = "equipe";
try { managementTab = localStorage.getItem("onglet-gestion") || "equipe"; } catch (e) { /* storage unavailable */ }
function chooseManagementTab(og) {
  if (!$(`#vue-gestion .panneau-g[data-og="${og}"]`)) og = "equipe";      // tab gone (e.g. « Modèles et benchmarks »): the first one
  managementTab = og;
  if (view === "gestion") loadManagementTab(og);
  try { localStorage.setItem("onglet-gestion", og); } catch (e) { /* same */ }
  $$("#vue-gestion .onglets-g [data-og]").forEach((b) => b.setAttribute("aria-selected", String(b.dataset.og === og)));
  $$("#vue-gestion .panneau-g").forEach((x) => (x.hidden = x.dataset.og !== og));
}
$$("#vue-gestion .onglets-g [data-og]").forEach((b) => (b.onclick = () => chooseManagementTab(b.dataset.og)));
chooseManagementTab(managementTab);
const GB = (id, html) => { const el = $(`#g-${id}`); if (el) el.innerHTML = html; };
/* Gestion: only the displayed tab loads (the other on first click), then on every return to the page. */
const TAB_BLOCKS_G = { equipe: { equipe: gTeam, bench: gBench, usage: gUsage, reglages: gSettings, outils: gTools, entretien: gMaintenance },
  savoir: { memoire: gMemory, docs: gDocs, audits: gAudits } };
let loadedTabs = new Set();
async function loadManagementTab(og) {
  if (loadedTabs.has(og)) return;
  loadedTabs.add(og);
  if (og === "equipe") homeLimits();
  await Promise.all(Object.entries(TAB_BLOCKS_G[og] || {}).map(([k, f]) => f().catch((e) => GB(k, `<div class="alerte">${esc(e.message)}</div>`))));
  if (og === "equipe") setTimeout(adjustUsage, 300);
}
async function showManagement() {
  loadedTabs = new Set();
  await loadManagementTab(managementTab);
}
function openManagement(section) {
  showView("gestion");
  const z = $(`#zone-${BLOCKS_G[section] || section}`);
  if (z && z.closest(".panneau-g")) chooseManagementTab(z.closest(".panneau-g").dataset.og);
  if (z) { z.scrollIntoView({ behavior: matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth", block: "start" }); z.classList.add("repere"); setTimeout(() => z.classList.remove("repere"), 1600); }
}

/* --- Agents: model and effort of each role, at a glance */
/* Each agent's AI: any connected AI; models and efforts offered according to THAT AI (its own names). */
let AI_EFFORTS = {}, AI_ROLES = {}, AI_INFO = { connexions: [] };
const shortAiName = (n) => String(n || "").split(" (")[0];
const effortsFor = (family, fallback) => { const l = AI_EFFORTS[family] || [];
  const lib = (l.find(([v]) => v === fallback) || [])[1];
  return l.length ? [["", `Auto${lib ? " · " + lib : ""}`], ...l] : [["", "Non réglable"]]; };
const modelsFor = (eff) => eff && eff.outil === "claude-code" ? MODELS
  : [["", `Auto${eff && eff.outil === "api" && eff.nom.includes(" · ") ? " · " + eff.nom.split(" · ").slice(1).join(" · ") : ""}`]];
const defaultAi = () => AI_ROLES.producteur || Object.values(AI_ROLES)[0] || { outil: "claude-code", famille: "claude-code", nom: "" };
async function loadAiRoles(o) {
  try { o = o || await api("/api/organisation"); AI_ROLES = Object.fromEntries(o.equipe.map((r) => [r.id, r.ia_effective])); } catch { /* later */ }
}
async function gTeam() {
  const [o, info] = await Promise.all([api("/api/organisation"), api("/api/ia").catch(() => ({ connexions: [] }))]);
  AI_INFO = info; loadAiRoles(o);
  const ACTIVE = ["creee", "en_cours", "en_attente_creneau"];
  const opt = (items, sel) => items.map(([v, t]) => `<option value="${esc(v)}"${v === sel ? " selected" : ""}>${esc(t)}</option>`).join("");
  const rank = { travaille: 0, attend_mel: 1, libre: 2 };
  const tiles = o.equipe.map((r) => {
    const work = r.taches.some((x) => ACTIVE.includes(x.status)), waiting = r.taches.length && !work;
    return { r, etat: work ? "travaille" : waiting ? "attend_mel" : "libre" };
  }).sort((a, b) => rank[a.etat] - rank[b.etat] || a.r.nom.localeCompare(b.r.nom)).map(({ r, etat: state }) => {   // working ones first
    const eff = r.ia_effective || { outil: r.outil, famille: r.outil, nom: TOOL_LABELS[r.outil] || r.outil };
    const fallback = r.modele_preset || r.modele_defaut || "";
    const ais = [["", r.id === "auditeur" ? "Auto · une autre IA que celle qui a travaillé" : `Auto · ${eff.nom || "meilleure IA disponible"}`], ...(info.claude ? [["claude-code", "Claude Code"]] : []), ...(info.codex ? [["codex", "Codex"]] : []),
      ...info.connexions.filter((c) => c.fournisseur !== "elevenlabs").map((c) => [c.id, `${shortAiName(c.nom)}${c.modele ? " · " + c.modele : ""}`])];
    const autoName = r.modele_exact || (fallback ? modelName(fallback) : "outil");      // the exact model when it is known
    const mods = eff.outil === "claude-code" ? [["", `Auto · ${autoName}`], ...MODELS.slice(1)]
      : eff.outil === "codex" ? [["", `Auto · ${r.modele_exact || fallback || "modèle de Codex"}`], ...CODEX_MODELS.slice(1)] : modelsFor(eff);
    if (r.modele && !mods.some(([v]) => v === r.modele)) mods.push([r.modele, r.modele]);
    const effs = effortsFor(eff.famille, r.effort_defaut);
    if (r.effort && !effs.some(([v]) => v === r.effort)) effs.push([r.effort, r.effort]);
    return `<div class="agent-g${r.ia || r.modele || r.effort ? " regle" : ""}"><div class="tete-g"><span class="point ${state}" title="${ROLE_STATES[state]}"></span>
      <span class="nom"><b title="${esc(r.nom)}">${esc(r.nom)}</b><small>${esc(eff.nom || r.outil)}${r.lecture_seule ? " · lecture seule" : ""}</small></span></div>
      <div class="reglages-g"><select data-ia-role="${esc(r.id)}" title="IA de cet agent : n'importe quelle IA connectée" aria-label="IA de ${esc(r.nom)}">${opt(ais, r.ia || "")}</select>
      <select data-modele="${esc(r.id)}" data-cx="${esc(eff.outil === "api" ? eff.connexion : "")}" title="Modèle" aria-label="Modèle de ${esc(r.nom)}" ${eff.outil === "codex" && CODEX_MODELS.length < 2 ? "disabled" : ""}>${opt(mods, r.modele || "")}</select>
      <select data-effort="${esc(r.id)}" title="Effort (les niveaux de cette IA)" aria-label="Effort de ${esc(r.nom)}" ${effs.length > 1 ? "" : "disabled"}>${opt(effs, r.effort || "")}</select></div></div>`;
  }).join("");
  GB("equipe", `<div class="agents-g">${tiles}</div><details class="pli" id="pli-matrice"><summary>Agents par projet</summary><div id="g-matrice"><p class="vide">…</p></div></details>`);
  $("#pli-matrice").addEventListener("toggle", () => { if ($("#pli-matrice").open) teamMatrix(); });
  $("#aide-equipe").innerHTML = "IA « Auto » : la mieux classée aux benchmarks pour ce métier parmi celles que tu as connectées, quelle qu'elle soit. Modèle et effort « Auto » suivent le mode de chaque projet (Rapide, Normal, Performance : sur la page du projet ou dans « Agents par projet ») ; un choix ici passe avant, une demande passe avant tout.";
  $$("#g-equipe [data-ia-role]").forEach((x) => (x.onchange = () => api("/api/ia-role", { role: x.dataset.iaRole, ia: x.value }).then(gTeam).catch((e) => alert(e.message))));
  $$("#g-equipe [data-modele][data-cx]").forEach((x) => { if (!x.dataset.cx) return;      // connected AI: its models, loaded on first click
    x.addEventListener("focus", async () => { if (x.dataset.charge) return; x.dataset.charge = "1";
      try { const r = await api("/api/ia/modeles", { id: x.dataset.cx }); const v = x.value;
        x.innerHTML = opt([[x.options[0].value, x.options[0].text], ...r.modeles.map((m) => [m, m])], v); } catch { /* list unavailable */ } }, { once: true }); });
  $$("#g-equipe [data-modele]").forEach((x) => (x.onchange = () => api("/api/modeles", { role: x.dataset.modele, modele: x.value }).then(gTeam).catch((e) => alert(e.message))));
  $$("#g-equipe [data-effort]").forEach((x) => (x.onchange = () => api("/api/efforts", { role: x.dataset.effort, effort: x.value }).then(gTeam).catch((e) => alert(e.message))));
}

/* --- Tools and updates */
const INSTALLATIONS = {
  lecture: { libelle: "Lecture des PDF et images (~140 Mo)", question: "Installer PyMuPDF et Pillow (~140 Mo) dans l'environnement du studio ?" },
  parole: { libelle: "Lecture des sons et vidéos (~550 Mo + modèle ~480 Mo)", question: "Installer faster-whisper et PyAV (~550 Mo) ? Le modèle de parole (~480 Mo) se téléchargera à la première pièce sonore." },
  retro: { libelle: "Outils de rétro-ingénierie (~25 Mo)", question: "Installer pefile, capstone, lief et kaitaistruct (~25 Mo) dans l'environnement du studio ? Ils servent au Rétro-ingénieur (lecture de binaires et de formats)." },
};
async function gTools() {
  const e = await api("/api/etat");
  const pt = (v) => v.etat === "OK" ? "libre" : v.etat === "MANUEL" || v.etat === "PARTIEL" ? "attend_mel" : "en_pause";
  GB("outils", `<p class="sous-titre-g">Studio</p><div class="reglage"><span id="o-studio">Version…</span><button class="btn discret" id="o-maj">Rechercher une mise à jour</button></div>
    <p class="sous-titre-g">Versions</p><div id="o-versions"><p class="vide">Vérification des versions…</p></div>
    <p class="sous-titre-g">Connexions</p>
    <div class="etats-g">${Object.entries(e).map(([k, v]) => `<span class="etat-g" title="${esc(v.etat)} — ${esc(v.detail)}"><span class="point ${pt(v)}"></span>${esc(k)}</span>`).join("")}</div>
    <p class="discret aide-g" style="margin-top:8px">Survole une pastille pour le détail.</p>`);
  toolVersions();
  const studioVersion = (m) => { const x = $("#o-studio"); if (x && m) x.textContent = `Version ${m.actuelle}` + (m.disponible ? ` · ${m.disponible.version} disponible` : m.installee ? ` · ${m.installee} installée (redémarrer)` : m.depot ? " · à jour" : "") + (m.erreur ? ` · ${m.erreur}` : ""); };
  updateVersion().then(studioVersion);
  $("#o-maj").onclick = async () => { $("#o-maj").disabled = true; try { await api("/api/mise-a-jour/verifier", {}); hiddenUpdate = ""; studioVersion(await updateVersion()); } catch (x) { alert(x.message); } $("#o-maj").disabled = false; };
}

async function teamMatrix() {
  const el = $("#g-matrice");
  if (!el) return;
  const m = await api("/api/equipes").catch(() => null);
  if (!m) { el.innerHTML = '<p class="warn">Indisponible.</p>'; return; }
  const cell = (p, r) => { const x = p.roles[r.id];
    if (!x) return '<td class="discret">·</td>';
    const k = x.etat === "travaille" ? "travaille" : !x.actif ? "off" : x.personnalise ? "perso" : "on";
    const t = { travaille: "▶", off: "—", perso: "◆", on: "●" }[k];
    return `<td class="c ${k}" data-mat-p="${esc(p.cle)}" title="${esc(p.nom)} · ${esc(r.nom)}${x.etat ? " · " + (ROLE_STATES[x.etat] || x.etat) : ""}${x.personnalise ? " · réglé pour ce projet" : ""}${x.propre ? " · propre au projet" : ""}">${t}</td>`; };
  el.innerHTML = `<p class="aide-g discret">● actif · ◆ réglé pour ce projet · ▶ au travail · — pas utilisé. Clique une case pour régler l'équipe du projet, ou un mode pour le changer.</p>
    <div class="matrice-defile"><table class="matrice"><thead><tr><th>Métier</th>${m.projets.map((p) => `<th>${esc(p.nom.slice(0, 18))}</th>`).join("")}</tr></thead>
    <tbody><tr class="ligne-mode"><td>Mode</td>${m.projets.map((p) => `<td class="c" data-mode-p="${esc(p.cle)}" title="Se règle dans Projets › ${esc(p.nom)} › Réglages"><span class="mode-p ${esc(p.profil)}">${esc((PROFILES.find(([v]) => v === p.profil) || ["", "Normal"])[1])}</span></td>`).join("")}</tr>
    ${m.roles.map((r) => `<tr><td>${esc(r.nom)}</td>${m.projets.map((p) => cell(p, r)).join("")}</tr>`).join("")}</tbody></table></div>`;
  $$("#g-matrice [data-mode-p]").forEach((c) => (c.onclick = () => { currentProject = c.dataset.modeP; currentBlock = "projet"; showView("projets"); setTimeout(() => chooseBlock("projet"), 500); }));
  $$("#g-matrice [data-mat-p]").forEach((c) => (c.onclick = () => { currentProject = c.dataset.matP; currentBlock = "equipe"; showView("projets"); setTimeout(() => chooseBlock("equipe"), 500); }));
}

/* --- Maintenance (Réglages column): studio tests, optional features, background jobs */
async function gMaintenance() {
  const [inst, tr] = await Promise.all([api("/api/outils/installes"), api("/api/travaux")]);
  const leftover = Object.keys(INSTALLATIONS).filter((q) => !inst[q]);       // a completed install is no longer offered
  const inProgress = (q) => (tr[`installer:${q}`] || {}).etat === "en_cours";
  const jobs = Object.values(tr).sort((a, b) => (a.debut < b.debut ? 1 : -1));
  const cleanup = await api("/api/menage").catch(() => ({}));
  const mo = (o) => `${Math.round((o || 0) / 2 ** 20)} Mo`;
  GB("entretien", `<div class="menage-g"><b>Ménage automatique</b> <span class="${cleanup.actif ? "ok" : "warn"}">${cleanup.actif ? "activé" : "coupé"}</span>
      <p class="discret aide-g">Au fil de l'eau : à la fin de chaque tâche, sa copie de travail part ; après la sauvegarde du jour, les anciennes (7 jours + 4 semaines gardés) ; après une mise à jour, les vieilles versions (3 gardées). Jamais tes projets, sujets, résultats, skills ni mémoire.${cleanup.jour ? ` Dernier rattrapage : ${esc(cleanup.jour)} — ${esc(cleanup.texte)}` : ""}${cleanup.total && cleanup.total.octets ? ` Depuis le début : ${mo(cleanup.total.octets)} libérés.` : ""}</p>
      <button class="btn" id="o-menage">Faire le ménage maintenant</button></div>
    <div class="actions colonne" style="margin:10px 0 0"><button class="btn" id="o-tests">Lancer les tests du studio</button></div>
    ${leftover.length ? `<p class="sous-titre-g">Fonctions en option</p><div class="actions colonne" style="margin:0">${leftover.map((q) => inProgress(q) ? `<button class="btn" disabled>Installation en cours…</button>` : `<button class="btn" data-installer="${q}">Installer : ${INSTALLATIONS[q].libelle}</button>`).join("")}</div>` : ""}
    ${jobs.length ? `<details class="pli" style="margin-top:10px"${jobs.some((j) => j.etat === "en_cours") ? " open" : ""}><summary>Travaux depuis l'ouverture (${jobs.length})</summary>${jobs.map((j) => `<details class="pli"><summary>${j.etat === "en_cours" ? "⚙" : j.etat === "ok" ? "✔" : "✖"} ${esc(j.titre)} · ${j.fin ? formatDuration(seconds(j.debut, j.fin)) : timer(j.debut)}</summary><pre class="sortie">${esc(j.sortie || "…")}</pre></details>`).join("")}</details>` : ""}`);
  const launch = async (url, requestBody) => { try { await api(url, requestBody); updateJobs(); setTimeout(gMaintenance, 800); } catch (x) { alert(x.message); } };
  $("#o-tests").onclick = () => launch("/api/outils/tests", {});
  $("#o-menage").onclick = async (ev) => { ev.currentTarget.disabled = true; try { const r = await api("/api/menage", {}); infoBubble(r.texte); } catch (x) { infoBubble(x.message); } gMaintenance(); };
  $$("#g-entretien [data-installer]").forEach((b) => (b.onclick = () => confirm(INSTALLATIONS[b.dataset.installer].question) && launch("/api/outils/installer", { quoi: b.dataset.installer })));
  if (jobs.some((j) => j.etat === "en_cours")) setTimeout(() => { if (view === "gestion") gMaintenance(); }, 4000);
}

/* --- Audits of agent skills and memories (global skills audit-skills / audit-memories, run by a connected AI) */
async function gAudits() {
  const aud = await api("/api/audits").catch(() => []);
  GB("audits", auditsBlock(aud));
  const selA = $("#a-cible");
  if (selA) {
    try { const m = localStorage.getItem("audit-cible"); if (m && aud.some((p) => p.cible === m)) selA.value = m; } catch (e) { /* storage unavailable */ }
    const updateAudit = () => { const p = aud.find((x) => x.cible === selA.value) || {}; $$("#g-audits [data-audit]").forEach((b) => { const d = p[`${b.dataset.audit}_audit`]; b.nextElementSibling.textContent = d ? `dernier : ${timeAgo(d.date)}${ACTIVE_STATUSES.includes(d.statut) ? " (en cours)" : ""}` : "jamais lancé"; }); };
    selA.onchange = () => { try { localStorage.setItem("audit-cible", selA.value); } catch (e) { /* same */ } updateAudit(); };
    updateAudit();
    $$("#g-audits [data-audit]").forEach((b) => (b.onclick = () => launchAudit({ cible: selA.value, quoi: b.dataset.audit, mode: "audit" })));
  }
}

function auditsBlock(aud) {
  if (!aud.length) return '<p class="vide">Aucun projet avec un dossier.</p>';
  return `<p class="explique-g">Relit les skills ou les fichiers d'instructions des agents (règles, instructions, plans) et dit ce qui est faux, en double ou chargé pour rien. Choisis un projet ou le studio lui-même (ses skills et ses règles communes). Rapport d'abord ; « Appliquer » ensuite, depuis le rapport.</p>
    <select id="a-cible" class="champ" style="width:100%;margin-bottom:6px">${aud.map((p) => `<option value="${esc(p.cible)}">${esc(p.nom)}</option>`).join("")}</select>
    <div class="audits-g">
      <button class="btn" data-audit="skills" title="Quels skills servent, lesquels se chevauchent ou chargent du texte pour rien">Auditer les skills</button><small class="discret"></small>
      <button class="btn" data-audit="memoires" title="CLAUDE.md, règles, plans : ce qui est faux, en double ou périmé">Auditer les mémoires</button><small class="discret"></small>
    </div>`;
}
function timeAgo(d) {
  const j = Math.floor((Date.now() - new Date(d.replace(" ", "T") + (/[zZ+]/.test(d.slice(10)) ? "" : "Z")).getTime()) / 864e5);
  return j <= 0 ? "aujourd'hui" : j === 1 ? "hier" : `il y a ${j} jours`;
}
async function launchAudit(requestBody) {
  try { const r = await api("/api/audits", requestBody); selection = r.tid; lastView = ""; currentProject = requestBody.cible; showView("projets"); }
  catch (e) { alert(e.message); }
}

/* --- Studio settings: closed list, saved in studio.config.toml (a copy of the previous one is kept) */
let settingMsg = { t: "↻ = pris en compte au prochain démarrage du studio.", c: "discret" };
/* --- Updates: banner when a version is installed (restart) or available (install) */
let hiddenUpdate = "";
async function updateVersion() {
  let e;
  try { e = await api("/api/mise-a-jour"); } catch { return; }
  const b = $("#bandeau-maj");
  const key = e.installee || (e.disponible && e.disponible.version) || "";
  if (!key || key === hiddenUpdate || sessionInfo.distant) { b.hidden = true; return e; }
  if (e.installee) {
    $("#maj-texte").textContent = `Mise à jour ${e.installee} installée.`;
    $("#maj-action").textContent = "Redémarrer le studio";
    $("#maj-action").onclick = async () => {
      try { await api("/api/mise-a-jour/redemarrer", {}); document.body.innerHTML = '<div class="ferme"><h1>Mise à jour</h1><p class="vide">Le studio redémarre…</p></div>'; }
      catch (x) { alert(x.message); }
    };
  } else {
    $("#maj-texte").textContent = `Nouvelle version ${e.disponible.version} disponible${e.disponible.notes ? " : " + e.disponible.notes.split("\n")[0].slice(0, 120) : ""}`;
    $("#maj-action").textContent = "Installer";
    $("#maj-action").onclick = async () => {
      $("#maj-action").disabled = true; $("#maj-action").textContent = "Installation…";
      try { await api("/api/mise-a-jour/installer", {}); } catch (x) { alert(x.message); }
      $("#maj-action").disabled = false; updateVersion();
    };
  }
  $("#maj-fermer").onclick = () => { hiddenUpdate = key; b.hidden = true; };
  b.hidden = false;
  return e;
}
setTimeout(updateVersion, 4000);
setInterval(updateVersion, 30 * 60 * 1000);

/* --- Connectors: PC software added by the user (empty by default) */
/* --- Create an agent: domain → suggested role → settings and recommended model → creation */
let agentCatalog = null;
const CATEGORY_NAMES = { texte: "texte", code: "code", image: "images", video: "vidéo", voix: "voix" };
function closeAgentAssistant() { $("#assistant-agent").hidden = true; }
$("#aa-fermer").onclick = () => { projectAgent = ""; closeAgentAssistant(); };
$("#assistant-agent").onclick = (e) => { if (e.target.id === "assistant-agent") closeAgentAssistant(); };
document.addEventListener("keydown", (e) => { if (e.key === "Escape" && !$("#assistant-agent").hidden) closeAgentAssistant(); });
$("#optimiser-agents").onclick = () => optimizeAgents("");
$("#creer-agent").onclick = async () => {
  $("#assistant-agent").hidden = false;
  $("#aa-corps").innerHTML = '<p class="vide">…</p>';
  try { agentCatalog = await api("/api/agents/catalogue"); domainStep(); }
  catch (e) { $("#aa-corps").innerHTML = `<p class="warn">${esc(e.message)}</p>`; }
};
function domainStep() {
  $("#aa-titre").textContent = "Créer un agent · 1/3 · ton domaine";
  $("#aa-corps").innerHTML = `<div class="grille-domaines">${agentCatalog.domaines.map((d) => `<button data-dom="${esc(d.id)}"><b>${esc(d.nom)}</b><br><small class="discret">${d.roles.length} rôles proposés</small></button>`).join("")}<button data-dom=""><b>Autre</b><br><small class="discret">partir de zéro</small></button></div>`;
  $$("[data-dom]").forEach((b) => (b.onclick = () => (b.dataset.dom ? roleStep(b.dataset.dom) : settingsStep(null, ""))));
}
function roleStep(dom) {
  const d = agentCatalog.domaines.find((x) => x.id === dom);
  $("#aa-titre").textContent = `Créer un agent · 2/3 · ${d.nom}`;
  $("#aa-corps").innerHTML = `<div class="grille-domaines">${d.roles.map((r, i) => `<div class="carte-role" role="button" tabindex="0" data-role="${i}"><b>${esc(r.nom)}</b><small>${esc(r.mission)}</small><br><small class="discret">type : ${CATEGORY_NAMES[r.categorie] || r.categorie}</small></div>`).join("")}
    <div class="carte-role" role="button" tabindex="0" data-role="-1"><b>Partir de zéro</b><small>Un rôle à toi, dans ce domaine.</small></div></div>
    <div class="actions" style="margin-top:12px"><button class="btn discret" id="aa-retour">Retour</button></div>`;
  $("#aa-retour").onclick = domainStep;
  $$("[data-role]").forEach((c) => (c.onclick = c.onkeydown = (e) => { if (e.type === "keydown" && e.key !== "Enter") return; settingsStep(+c.dataset.role >= 0 ? d.roles[+c.dataset.role] : null, dom); }));
}
function settingsStep(r, dom) {
  const cat = (r && r.categorie) || "texte";
  $("#aa-titre").textContent = "Créer un agent · 3/3 · réglages";
  const rows = (l) => esc((l || []).join("\n"));
  const sources = agentCatalog.sources;
  const reco = () => agentCatalog.recommandations[$("#aa-cat").value] || {};
  $("#aa-corps").innerHTML = `<div class="form-agent">
    <label for="aa-nom">Nom</label><input class="champ" id="aa-nom" maxlength="60" value="${esc(r ? r.nom : "")}">
    <label for="aa-mission">Mission (ce qu'il fait)</label><textarea id="aa-mission">${esc(r ? r.mission : "")}</textarea>
    <label for="aa-livrables">Ce qu'il livre (une ligne par livrable)</label><textarea id="aa-livrables">${rows(r && r.livrables)}</textarea>
    <label for="aa-limites">Ce qu'il ne doit jamais faire (une ligne par règle)</label><textarea id="aa-limites">${rows(r && r.limites)}</textarea>
    <label for="aa-cat">Type de travail</label><select id="aa-cat">${Object.entries(CATEGORY_NAMES).map(([k, t]) => `<option value="${k}"${k === cat ? " selected" : ""}>${t}</option>`).join("")}</select>
    <div class="reco" id="aa-reco"></div>
    <label for="aa-source">IA de cet agent</label><select id="aa-source">${sources.length ? sources.map((x) => `<option value="${esc(x.id)}">${esc(x.nom)}${x.modele ? " · " + esc(x.modele) : ""}</option>`).join("") : '<option value="">Aucune IA connectée</option>'}</select>
    <p class="warn aide-g" id="aa-msg"></p>
    <div class="actions" style="margin-top:12px;justify-content:space-between"><button class="btn discret" id="aa-retour">Retour</button><button class="btn principal" id="aa-creer">Créer l'agent</button></div></div>`;
  const updateReco = () => {
    const x = reco();
    const m = (o) => o ? `${esc(o.nom)} (${esc(o.fournisseur)}${o.score ? ", " + o.score + " " + esc(o.unite) : ""}${o.prix ? ", " + o.prix + " $" : ""})` : "—";
    $("#aa-reco").innerHTML = `${x.connecte ? `<div><b>Recommandé avec tes IA :</b> ${esc(x.connecte.nom)}${x.connecte.modele_conseille ? " → " + m(x.connecte.modele_conseille) : ""}</div>` : "<div><b>Aucune de tes IA ne convient encore.</b></div>"}
      <div><b>Meilleur du marché :</b> ${m(x.marche)}</div>${x.remarque ? `<div class="discret" style="margin-top:4px">${esc(x.remarque)}</div>` : ""}`;
    if (x.connecte && $("#aa-source").querySelector(`option[value="${x.connecte.id}"]`)) $("#aa-source").value = x.connecte.id;
  };
  $("#aa-cat").onchange = updateReco; updateReco();
  $("#aa-retour").onclick = () => (dom ? roleStep(dom) : domainStep());
  $("#aa-creer").onclick = async () => {
    const entries = (id) => $(id).value.split("\n").map((x) => x.trim()).filter(Boolean);
    try {
      const res = await api("/api/agents/creer", { nom: $("#aa-nom").value, mission: $("#aa-mission").value, livrables: entries("#aa-livrables"),
        limites: entries("#aa-limites"), categorie: $("#aa-cat").value, source: $("#aa-source").value, domaine: dom,
        mots_cles: r ? r.mots_cles : [], outils: r ? r.outils : undefined, criteres: r ? r.criteres : [], id: r ? r.id : "", projet: projectAgent });
      if (projectAgent) { projectAgent = ""; setTimeout(teamSettings, 300); }
      $("#aa-titre").textContent = "Agent créé";
      $("#aa-corps").innerHTML = `<p class="ok">« ${esc($("#aa-nom") ? $("#aa-nom").value : "")} » rejoint l'équipe. Le Superviseur peut maintenant lui confier des tâches.</p><div class="actions"><button class="btn principal" id="aa-ok">OK</button></div>`;
      $("#aa-ok").onclick = closeAgentAssistant;
      gTeam();
    } catch (e) { $("#aa-msg").textContent = e.message; }
  };
}

/* --- Benchmarks: global ranking then rankings by use (cloud and local mixed), updated daily */
let benchSort = { cat: "global", col: "score", lieu: "tous" };
let benchTimer = null, benchCache = null;
/* Models and benchmarks: cloud and local in the same table, plus « Installés ». Data loaded once, the
   tabs show immediately (reload only during a download or after an action). */
async function gBench(reload = true) {
  clearTimeout(benchTimer);
  if (reload || !benchCache) {
    const [b, loc, inst, ai] = await Promise.all([api("/api/benchmarks"), api("/api/modeles-locaux").catch(() => null), api("/api/modeles-locaux/details").catch(() => []),
      api("/api/ia").catch(() => ({ connexions: [] }))]);
    benchCache = { b, loc, inst, ia: ai };
  }
  renderBench();
}
function renderBench() {
  const { b, loc, inst, ia: ai } = benchCache;
  const cats = Object.entries(b.categories).filter(([k]) => k !== "local");
  const co = new Set(b.connectes);
  const isConnected = (m) => m.local ? co.has("local") : co.has(m.fournisseur) || (m.fournisseur === "openai" && co.has("codex"))
    || (co.has("openrouter") && !DIRECT_CLOUD.includes(m.fournisseur) && CLOUD_TEXT.includes(m.categorie));
  const installed = benchSort.cat === "installes";
  if (!installed && !cats.some(([k]) => k === benchSort.cat)) benchSort.cat = cats[0][0];
  const inverse = (b.inverses || []).includes(benchSort.cat);              // transcription: error rate, lower = better
  const byScore = (x, y) => x.score == null ? 1 : y.score == null ? -1 : inverse ? x.score - y.score : y.score - x.score;
  const sorter = (l) => [...l].sort((x, y) => benchSort.col === "prix" ? (x.local ? 0 : x.prix ?? 1e9) - (y.local ? 0 : y.prix ?? 1e9) || byScore(x, y)
    : benchSort.col === "vitesse" ? (y.vitesse || 0) - (x.vitesse || 0) || byScore(x, y) : byScore(x, y));
  const allItems = b.modeles.filter((m) => m.categorie === benchSort.cat);
  const rows = sorter(allItems.filter((m) => benchSort.lieu === "tous" || (benchSort.lieu === "local") === !!m.local));
  const rank = new Map([...allItems].sort(byScore).map((m, i) => [m, m.score == null ? "" : i + 1]));   // ranking position, cloud and local together
  const hasLocal = allItems.some((m) => m.local);
  let hidden = ""; try { hidden = localStorage.getItem("ollama-plus-tard") || ""; } catch {}
  let note = "";
  if (loc && (hasLocal || installed)) {
    if (!loc.installe) note = `<div class="note-ollama">Modèles locaux : installe <a href="${esc(loc.telecharger)}" target="_blank" rel="noopener">Ollama</a> (gratuit) pour les installer en un clic ici.</div>`;
    else if (!co.has("local") && !hidden) note = `<div class="note-ollama">Connecter Ollama pour que le Superviseur ou les agents utilisent tes modèles locaux ? <button class="btn petit principal" id="ollama-connecter">Connecter</button><button class="lien" id="ollama-plus-tard">Plus tard</button></div>`;
  }
  const access = (m) => m.local ? (loc ? localCell(m, loc) : "—") : isConnected(m) ? `<span class="ok">● connecté${co.has(m.fournisseur) || m.fournisseur === "openai" ? "" : " (OpenRouter)"}</span>`
    : connectable(m) ? `<button class="btn petit" data-connecter-cloud="${esc(m.fournisseur)}" data-nom-modele="${esc(m.nom)}">Connecter</button>` : '<small class="discret">sur son site</small>';
  const line = (m) => `<tr class="${isConnected(m) ? "connecte" : ""}"><td class="rang">${rank.get(m) || "—"}</td><td>${esc(m.nom)}<span class="badge-lc ${m.local ? "local" : "cloud"}">${m.local ? "LOCAL" : "CLOUD"}</span></td>
    <td><b>${m.score ?? "—"}</b></td><td class="nowrap">${access(m)}</td><td>${m.local ? '<span class="ok">Gratuit</span>' : m.prix != null ? m.prix + " $" : "—"}</td>
    <td>${m.vitesse ? m.vitesse + " t/s" : m.local ? '<small class="discret">selon le PC</small>' : "—"}</td><td>${esc(m.fournisseur)}</td><td><small class="discret">${esc(m.note || "")}</small></td></tr>`;
  const unit = ((allItems[0] || {}).unite || "score").replace(/^./, (c) => c.toUpperCase());
  let requestBody;
  if (installed) {
    // Connected and installed: the real usable models, cloud (subscription or key) and local (Ollama)
    const PROVIDER_NAMES = { anthropic: "Anthropic", openai: "OpenAI", gemini: "Google Gemini", mistral: "Mistral", deepseek: "DeepSeek", openrouter: "OpenRouter", groq: "Groq" };
    const viaKey = (f) => (ai.connexions || []).find((c) => c.fournisseur === f);
    const cloudAccess = (m) => m.fournisseur === "anthropic" && co.has("anthropic") && !viaKey("anthropic") ? "Abonnement Claude (Claude Code)"
      : m.fournisseur === "openai" && co.has("codex") && !viaKey("openai") ? "Abonnement ChatGPT (Codex)"
      : viaKey(m.fournisseur) ? `Clé API ${PROVIDER_NAMES[m.fournisseur] || m.fournisseur}` : viaKey("openrouter") ? "Clé API OpenRouter" : "Abonnement";
    const seenItems = new Set();
    const cloud = b.modeles.filter((m) => m.categorie === "global" && !m.local && isConnected(m) && !seenItems.has(m.nom) && seenItems.add(m.nom)).sort(byScore);
    const keys = (ai.connexions || []).filter((c) => !["ollama", "lmstudio"].includes(c.fournisseur));
    const scoreLocal = (name) => (b.modeles.find((m) => m.local && m.categorie === "global" && (name === (m.ollama || m.cle) || name.startsWith((m.ollama || m.cle) + ":"))) || {}).score;
    requestBody = `${note}<p class="sous-titre-g">Modèles cloud connectés (${cloud.length})</p>${cloud.length ? `<div class="bench-defile"><table class="table-bench"><thead><tr><th>Modèle</th><th>Indice global</th><th>Accès</th><th>Vitesse</th><th>Prix</th></tr></thead><tbody>${cloud.map((m) =>
        `<tr><td>${esc(m.nom)}<span class="badge-lc cloud">CLOUD</span></td><td><b>${m.score ?? "—"}</b></td><td>${esc(cloudAccess(m))}</td><td>${m.vitesse ? m.vitesse + " t/s" : "—"}</td><td>${m.prix != null ? m.prix + " $" : "—"}</td></tr>`).join("")}</tbody></table></div>`
        : '<p class="discret">Aucun : clique « Connecter » sur un modèle du classement.</p>'}
      ${keys.length ? `<p class="aide-g discret">Clés API enregistrées : ${keys.map((c) => `${esc(PROVIDER_NAMES[c.fournisseur] || c.fournisseur)}${c.modele ? ` (${esc(c.modele)})` : ""} <button class="lien" data-deco-ia="${esc(c.id)}">déconnecter</button>`).join(" · ")}. Abonnements : ils se gèrent dans Claude Code ou Codex.</p>` : ""}
      <p class="sous-titre-g" style="margin-top:14px">Modèles locaux installés (${inst.length})</p>${inst.length ? `<div class="bench-defile"><table class="table-bench"><thead><tr><th>Modèle</th><th>Indice global</th><th>Taille</th><th>Installé le</th><th></th></tr></thead><tbody>${inst.map((m) =>
        `<tr><td>${esc(m.nom)}<span class="badge-lc local">LOCAL</span></td><td><b>${scoreLocal(m.nom) ?? "—"}</b></td><td>${m.taille_go} Go</td><td>${esc(m.modifie)}</td><td class="nowrap"><button class="btn discret petit" data-maj-local="${esc(m.nom)}">Mettre à jour</button><button class="btn discret petit danger" data-desinstaller-local="${esc(m.nom)}">Désinstaller</button></td></tr>`).join("")}</tbody></table></div>
      <div class="reglage"><small class="discret">Ollama ne télécharge que ce qui a changé. « — » : modèle absent des classements publics.</small><button class="btn discret" id="maj-locaux">Tout mettre à jour</button></div>` : '<p class="discret">Aucun pour l\'instant : choisis-en un dans le classement (lignes LOCAL, bouton Installer).</p>'}`;
  } else {
    const helpText = (b.aides || {})[benchSort.cat] || "";
    requestBody = `${helpText ? `<p class="aide-bench discret">${esc(helpText)}${hasLocal ? "" : " Aucun modèle local mesuré par cette source."}</p>` : ""}${note}<div class="bench-defile"><table class="table-bench"><thead><tr><th>#</th><th>Modèle</th><th data-bcol="score" title="${esc((allItems[0] || {}).unite || "")}">${esc(unit)} ${inverse ? "▴" : "▾"}</th><th>Accès</th><th data-bcol="prix">Prix</th><th data-bcol="vitesse">Vitesse</th><th>Fournisseur</th><th>Remarque</th></tr></thead><tbody>
      ${rows.length ? rows.map(line).join("") : '<tr><td colspan="8" class="discret">Aucun modèle ici.</td></tr>'}</tbody></table></div>`;
  }
  GB("bench", `<div class="bench-modes"><div class="puces petites" id="bench-cats">${cats.map(([k, t]) => `<button class="puce${k === benchSort.cat ? " sel" : ""}" data-bcat="${k}">${esc(t)}</button>`).join("")}<button class="puce${installed ? " sel" : ""}" data-bcat="installes">Connectés et installés</button></div>
      ${installed ? "" : `<div class="seg" id="bench-lieu">${[["tous", "Tous"], ["cloud", "Cloud"], ["local", "Local"]].map(([k, t]) => `<button data-blieu="${k}" class="${benchSort.lieu === k ? "sel" : ""}">${t}</button>`).join("")}</div>`}</div>
    ${requestBody}
    <p class="aide-g discret" style="margin-top:6px">● = utilisable avec tes IA. Prix cloud : $ par million de jetons d'entrée (images : par image). ${esc(b.note)}<br>Classements du ${esc(b.date)}${b.actualise ? ` · vérifiés le ${esc(b.actualise.slice(0, 10))}` : ""} (mise à jour automatique une fois par jour) · ${b.sources.map((x) => `<a href="${esc(x.url)}" target="_blank" rel="noopener">${esc(x.nom)}</a>`).join(" · ")}</p>`);
  $$("[data-blieu]").forEach((x) => (x.onclick = () => { benchSort.lieu = x.dataset.blieu; renderBench(); }));
  $$("[data-bcat]").forEach((x) => (x.onclick = async () => {
    benchSort.cat = x.dataset.bcat; renderBench();
    if (x.dataset.bcat === "installes" && loc && loc.installe && !loc.ollama && !sessionInfo.distant) {   // the list comes from Ollama: it starts to provide it
      try { await api("/api/modeles-locaux/demarrer", {}); } catch (e) { /* empty list, nothing serious */ }
      gBench();
    }
  }));
  $$("[data-bcol]").forEach((x) => (x.onclick = () => { benchSort.col = x.dataset.bcol; renderBench(); }));
  $$("[data-connecter-cloud]").forEach((x) => (x.onclick = () => connectCloud(x.dataset.connecterCloud, x.dataset.nomModele)));
  $$("[data-installer-modele]").forEach((x) => (x.onclick = async () => {
    const name = x.dataset.installerModele, m = b.modeles.find((y) => (y.ollama || y.cle) === name);
    if (!confirm(`Installer ${m ? m.nom : name} sur ce PC avec Ollama ?\n${m && m.note ? m.note + "\n" : ""}Le téléchargement peut prendre du temps (plusieurs Go).`)) return;
    x.disabled = true;
    try { await api("/api/modeles-locaux/installer", { nom: name }); } catch (e) { alert(e.message); }
    gBench();
  }));
  $$("#g-bench [data-maj-local]").forEach((x) => (x.onclick = async () => { x.disabled = true; try { await api("/api/modeles-locaux/installer", { nom: x.dataset.majLocal }); infoBubble("Mise à jour lancée."); } catch (e) { alert(e.message); } }));
  $$("#g-bench [data-desinstaller-local]").forEach((x) => (x.onclick = async () => {
    const name = x.dataset.desinstallerLocal;
    if (!confirm(`Désinstaller ${name} ? Le modèle est retiré d'Ollama et libère sa place sur le disque (il se réinstalle en un clic).`)) return;
    x.disabled = true;
    try { infoBubble((await api("/api/modeles-locaux/desinstaller", { nom: name })).message); } catch (e) { alert(e.message); }
    gBench();
  }));
  $$("#g-bench [data-deco-ia]").forEach((x) => (x.onclick = async () => {
    if (!confirm("Déconnecter cette clé API ? Elle est effacée de ce PC (tu pourras la recoller).")) return;
    try { await api("/api/ia/retirer", { id: x.dataset.decoIa }); } catch (e) { alert(e.message); }
    gBench();
  }));
  if ($("#maj-locaux")) $("#maj-locaux").onclick = async (ev) => { ev.currentTarget.disabled = true;
    for (const m of inst) { try { await api("/api/modeles-locaux/installer", { nom: m.nom }); } catch (e) { alert(`${m.nom} : ${e.message}`); } }
    infoBubble("Mise à jour lancée."); };
  if ($("#ollama-connecter")) $("#ollama-connecter").onclick = async (ev) => { ev.currentTarget.disabled = true; try { await api("/api/ia/ajouter", { fournisseur: "ollama" }); infoBubble("Ollama connecté."); } catch (e) { alert(e.message); } gBench(); };
  if ($("#ollama-plus-tard")) $("#ollama-plus-tard").onclick = () => { try { localStorage.setItem("ollama-plus-tard", "1"); } catch {} renderBench(); };
  if (loc && Object.values(loc.modeles).some((x) => x.progression && x.progression.etat === "telechargement"))
    benchTimer = setTimeout(() => { if (view === "gestion") gBench().catch(() => {}); }, 2000);
}
/* Connecting a cloud model from the benchmarks: as simple as installing a local model. Subscription (the subscription
   tools) when available, else the provider's API key; other models go through OpenRouter (one key, all models). */
const DIRECT_CLOUD = ["anthropic", "openai", "gemini", "mistral", "deepseek", "xai", "moonshot"];
const CLOUD_TEXT = ["global", "agents", "code", "web", "raisonnement", "connaissances", "conversation", "vision"];
const CLOUD_KEYS = {
  anthropic: ["Anthropic (Claude)", "https://console.anthropic.com/settings/keys"], openai: ["OpenAI", "https://platform.openai.com/api-keys"],
  gemini: ["Google Gemini", "https://aistudio.google.com/apikey"], mistral: ["Mistral", "https://console.mistral.ai/api-keys"],
  deepseek: ["DeepSeek", "https://platform.deepseek.com/api_keys"], openrouter: ["OpenRouter", "https://openrouter.ai/keys"],
  xai: ["xAI (Grok)", "https://console.x.ai"], moonshot: ["Moonshot (Kimi)", "https://platform.moonshot.ai/console/api-keys"],
  groq: ["Groq", "https://console.groq.com/keys"], elevenlabs: ["ElevenLabs (voix)", "https://elevenlabs.io/app/settings/api-keys"],
};
const connectable = (m) => CLOUD_TEXT.includes(m.categorie) || (m.categorie === "image" && ["openai", "gemini"].includes(m.fournisseur));
async function connectCloud(provider, modelName, after) {
  const f = CLOUD_KEYS[provider] ? provider : "openrouter";
  const [name, keyLink] = CLOUD_KEYS[f];
  const el = $("#perso-fiche-corps");
  el.innerHTML = '<p class="vide">…</p>'; $("#perso-fiche").hidden = false;
  let d = {};
  try { d = await api("/api/ia"); } catch (e) { /* no details: key only */ }
  if (d.distant) { el.innerHTML = `<h2>Connecter ${esc(name)}</h2><p class="aide-g">La connexion se fait sur le PC (la clé ne passe jamais par le téléphone).</p><div class="bas"><button class="btn discret" data-fermer-fiche="1">Fermer</button></div>`; return; }
  const subscription = f === "anthropic" ? (d.claude ? `<button class="btn principal" id="cc-abo">Se connecter avec mon abonnement Claude</button>`
      : `<p class="aide-g">Abonnement Claude (Pro ou Max) : il faut d'abord Claude Code.</p><button class="btn" data-installer-outil="claude">Installer Claude Code</button>`)
    : f === "openai" ? (d.codex ? `<button class="btn principal" id="cc-abo">Se connecter avec mon abonnement ChatGPT</button>`
      : `<p class="aide-g">Abonnement ChatGPT : il faut d'abord Codex.</p><button class="btn" data-installer-outil="codex">Installer Codex</button>`) : "";
  el.innerHTML = `<h2>Connecter ${esc(name)}</h2><div class="meta">${modelName ? `pour utiliser ${esc(modelName)}${f === "openrouter" ? " et des centaines d'autres modèles avec une seule clé" : ""}` : f === "openrouter" ? "des centaines de modèles (dont des gratuits) avec une seule clé" : ""}</div>
    ${subscription ? `<p class="sous-titre-g">Avec ton abonnement</p>${subscription}<p class="sous-titre-g" style="margin-top:16px">Ou avec une clé API (paiement à l'usage)</p>` : `<p class="sous-titre-g">Clé API</p>`}
    <p class="aide-g">1. <a href="${esc(keyLink)}" target="_blank" rel="noopener">Crée une clé sur le site de ${esc(name)}</a> · 2. colle-la ici. Elle est vérifiée puis chiffrée sur ce PC, jamais affichée.</p>
    <label for="cc-cle">Clé API</label><input id="cc-cle" type="password" autocomplete="off" spellcheck="false">
    <p class="warn" id="fiche-msg"></p><div class="bas"><button class="btn discret" data-fermer-fiche="1">Annuler</button><button class="btn" id="cc-ok">Connecter avec la clé</button></div>`;
  if ($("#cc-abo")) $("#cc-abo").onclick = async (ev) => {
    ev.currentTarget.disabled = true;
    try { const r = await api(f === "anthropic" ? "/api/claude/connexion" : "/api/codex/connexion", {}); infoBubble(r.info); $("#perso-fiche").hidden = true; if (after) after(); }
    catch (e) { $("#fiche-msg").textContent = e.message; ev.currentTarget.disabled = false; }
  };
  $("#cc-ok").onclick = async (ev) => {
    const b = ev.currentTarget; b.disabled = true; b.textContent = "Vérification…";
    try { await api("/api/ia/ajouter", { fournisseur: f, cle: $("#cc-cle").value }); infoBubble(`${name} connecté.`); $("#perso-fiche").hidden = true; (after || gBench)(); }
    catch (e) { $("#fiche-msg").textContent = e.message; b.disabled = false; b.textContent = "Connecter avec la clé"; }
  };
  $("#cc-cle").onkeydown = (e) => { if (e.key === "Enter") $("#cc-ok").click(); };
}
function localCell(m, loc) {
  const name = m.ollama || m.cle, e = loc.modeles[name];
  if (!e) return "—";
  const p = e.progression;
  if (p && p.etat === "telechargement") return `<span class="info" title="${esc(p.message)}">${p.pct} %</span>`;
  if (e.installe) return '<span class="ok">Installé</span>';
  if (p && p.etat === "erreur") return `<span class="bad">Échec</span> <button class="btn discret petit" data-installer-modele="${esc(name)}">Réessayer</button><small class="erreur-local">${esc(p.message)}</small>`;
  return loc.installe ? `<button class="btn petit" data-installer-modele="${esc(name)}">Installer</button>` : '<small class="discret">Ollama requis</small>';
}

/* --- AI: subscription tool, API key or local AI; one for the Supervisor, one for the agents */
let aiState = null, aiMsg = "";
function openAiSettings() {
  if (currentProject) openSupervisor();
  if (document.body.dataset.mob) mobileView("travail");
  chooseBlock("sup-reglages");
  setTimeout(() => $("#g-ia") && $("#g-ia").scrollIntoView({ block: "start" }), 300);
}
async function gAI() {
  const d = (aiState = await api("/api/ia"));
  if (d.distant) { GB("ia", `<p class="aide-g discret">Les IA se connectent depuis le PC.</p>`); return; }
  const options = (audience) => {
    const items = audience === "superviseur" ? [] : [["", "Auto : la meilleure IA disponible pour chaque rôle (benchmarks)"]];
    if (d.claude) items.push(["claude-code", "Claude Code (abonnement)"]);
    if (d.codex) items.push(["codex", "Codex (abonnement ChatGPT)"]);
    d.connexions.filter((c) => c.fournisseur !== "elevenlabs").forEach((c) => items.push([c.id, `${c.nom} · ${c.modele || "?"}`]));   // voice only: never Supervisor or agent
    const current = d[audience] || (audience === "superviseur" ? (d.actif === "claude-code" ? "claude-code" : (d.connexions[0] || {}).id || "") : "");
    return items.length ? items.map(([v, t]) => `<option value="${esc(v)}"${v === current ? " selected" : ""}>${esc(t)}</option>`).join("") : '<option value="">Aucune IA</option>';
  };
  const locales = d.locales.filter((l) => !d.connexions.some((c) => c.fournisseur === l));
  const state = d.actif ? `<p class="ok aide-g">Prêt : le Superviseur répond avec ${d.actif === "claude-code" ? "Claude Code" : d.actif === "codex" ? "Codex" : "l'IA connectée"}.</p>`
    : `<p class="warn aide-g">Aucune IA : connecte-en une ci-dessous (clé API, ou IA locale comme Ollama).</p>`;
  GB("ia", `${state}${aiMsg ? `<p class="warn aide-g">${esc(aiMsg)}</p>` : ""}
    <div class="reglage"><span>Superviseur</span><select data-ia-pour="superviseur">${options("superviseur")}</select></div>
    <div class="reglage"><span>Agents</span><select data-ia-pour="agents">${options("agents")}</select></div>
    ${d.connexions.map((c) => { const local = ["ollama", "lmstudio"].includes(c.fournisseur), off = local && !d.locales.includes(c.fournisseur);
      const fix = !off ? "" : c.fournisseur === "ollama" ? (d.ollama_installe ? `<button class="btn principal petit" data-ia-lancer="ollama">Lancer</button>` : `<button class="btn principal petit" data-installer-outil="ollama">Installer</button>`)
        : `<small class="discret">ouvre LM Studio et démarre son serveur</small>`;
      return `<div class="ia-ligne"><b>${esc(c.nom)}${off ? ' <span class="warn">· ne répond pas</span>' : ""}</b>${fix}<select data-ia-modele="${esc(c.id)}"><option>${esc(c.modele || "?")}</option></select><button class="btn discret" data-ia-retirer="${esc(c.id)}">Retirer</button></div>`; }).join("")}
    <div class="ia-ligne"><b class="discret">${d.claude || d.codex || d.connexions.length ? "Autre IA : abonnement, IA locale ou clé" : "Aucune IA connectée"}</b><button class="btn${d.claude || d.codex || d.connexions.length ? "" : " principal"}" data-ia-assistant="1">Connecter une IA</button></div>
    ${locales.map((l) => `<div class="ia-ligne"><b>${esc((d.fournisseurs.find((f) => f.id === l) || {}).nom || l)} — détectée sur ce PC</b><button class="btn" data-ia-locale="${esc(l)}">Connecter</button></div>`).join("")}
    <div class="ia-ajout"><select id="ia-fournisseur">${d.fournisseurs.map((f) => `<option value="${esc(f.id)}" data-cle="${f.cle}">${esc(f.nom)}</option>`).join("")}</select>
      <input class="champ" id="ia-cle" type="password" autocomplete="off" placeholder="Clé API (gardée chiffrée sur ce PC)" spellcheck="false">
      <button class="btn principal" id="ia-ajouter">Connecter</button></div>
    <p class="aide-g discret" style="margin-top:8px">La clé est vérifiée puis chiffrée sur ce PC ; elle n'est jamais affichée ni envoyée ailleurs qu'au fournisseur choisi. IA locale : lance Ollama ou LM Studio, elle apparaît ici. Un abonnement (ChatGPT, Claude…) passe par son outil en ligne de commande : une fois installé et connecté, il apparaît dans les listes Superviseur et Agents, sans clé.</p>`);
  const provider = $("#ia-fournisseur");
  if (!$("#ia-url")) $("#ia-cle").insertAdjacentHTML("beforebegin", '<input class="champ" id="ia-url" placeholder="Adresse de l\'IA (https://…/v1)" spellcheck="false" hidden>');
  const updateKey = () => { const o = provider.selectedOptions[0], other = o && o.value === "autre";
    $("#ia-cle").hidden = o && o.dataset.cle === "false" && !other; $("#ia-url").hidden = !other;
    $("#ia-cle").placeholder = other ? "Clé API (si l'IA en demande une)" : "Clé API (gardée chiffrée sur ce PC)"; };
  provider.onchange = updateKey; updateKey();
  const addItem = async (f, key, url = "") => {
    aiMsg = "";
    try { await api("/api/ia/ajouter", { fournisseur: f, cle: key, url }); } catch (e) { aiMsg = e.message; }
    gAI(); loadConversation(false);
  };
  $("#ia-ajouter").onclick = (e) => { e.target.disabled = true; e.target.textContent = "Vérification…"; addItem(provider.value, $("#ia-cle").value, provider.value === "autre" ? $("#ia-url").value : ""); };
  $$("[data-ia-locale]").forEach((b) => (b.onclick = () => { b.disabled = true; addItem(b.dataset.iaLocale, ""); }));
  $$("[data-ia-pour]").forEach((s) => (s.onchange = async () => { try { await api("/api/ia/choisir", { [s.dataset.iaPour]: s.value }); } catch (e) { aiMsg = e.message; } gAI(); supervisorChoices(); }));
  $$("[data-ia-retirer]").forEach((b) => (b.onclick = async () => { await api("/api/ia/retirer", { id: b.dataset.iaRetirer }); gAI(); }));
  $$("[data-ia-lancer]").forEach((b) => (b.onclick = async () => {        // local AI installed but closed: open it on click
    b.disabled = true; b.textContent = "Lancement…";
    try { const r = await api("/api/modeles-locaux/demarrer", {}); infoBubble(r.message); } catch (e) { aiMsg = e.message; }
    setTimeout(() => { gAI(); supervisorChoices(); }, 1500);
  }));
  $$("[data-ia-assistant]").forEach((b) => (b.onclick = () => openWelcome("ia")));      // subscriptions, local AIs, keys: one screen
  $$("[data-ia-modele]").forEach((s) => (s.onfocus = async () => {         // model list loaded on open
    if (s.dataset.charge) return; s.dataset.charge = "1";
    try {
      const r = await api("/api/ia/modeles", { id: s.dataset.iaModele });
      const current = s.value;
      s.innerHTML = r.modeles.map((m) => `<option${m === current ? " selected" : ""}>${esc(m)}</option>`).join("");
    } catch (e) { aiMsg = e.message; }
  }));
  $$("[data-ia-modele]").forEach((s) => (s.onchange = () => api("/api/ia/choisir", { id: s.dataset.iaModele, modele: s.value }).then(gAI)));
}

/* --- Phone: Tailscale relay (stops with the studio) and devices paired with a 6-digit code */
let phoneCode = null, phoneMsg = "";
/* Notifications on this phone: task awaiting approval or blocked → notification, « Valider » inside if the review is OK */
async function notifsBlock(msg = "") {
  const el = $("#notifs-tel");
  if (!el) return;
  if (location.protocol !== "https:" || !("serviceWorker" in navigator) || !("PushManager" in window)) {
    el.innerHTML = '<p class="aide-g discret">Notifications : ouvre le studio dans Chrome, à l\'adresse https du PC, puis « Ajouter à l\'écran d\'accueil ».</p>'; return;
  }
  const reg = await navigator.serviceWorker.ready;
  const subscription = await reg.pushManager.getSubscription();
  const denied = Notification.permission === "denied";
  el.innerHTML = `<div class="reglage"><span>Notifications sur ce téléphone<br><small class="discret">Tâche à valider ou bloquée. « Valider » directement depuis la notification quand la relecture est OK.</small></span>
    <div class="puces petites" id="notif-choix">${[[true, "Activées"], [false, "Coupées"]].map(([v, t]) => `<button class="puce${!!subscription === v ? " sel" : ""}" data-v="${v}">${t}</button>`).join("")}</div></div>
    ${subscription ? '<div class="reglage"><span></span><button class="btn discret" id="notif-test">Envoyer une notification de test</button></div>' : ""}
    ${denied ? '<p class="warn aide-g">Notifications bloquées pour ce site : autorise-les dans les réglages de Chrome (cadenas à gauche de l\'adresse).</p>' : ""}
    ${msg ? `<p class="aide-g">${esc(msg)}</p>` : ""}`;
  $$("#notif-choix .puce").forEach((b) => (b.onclick = async () => {
    b.disabled = true;
    try {
      if (b.dataset.v === "true") {
        if ((await Notification.requestPermission()) !== "granted") return notifsBlock("Autorise les notifications pour les recevoir.");
        const { cle: key } = await api("/api/push");
        const rawText = atob(key.replace(/-/g, "+").replace(/_/g, "/") + "===".slice((key.length + 3) % 4));
        const s = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: Uint8Array.from(rawText, (c) => c.charCodeAt(0)) });
        await api("/api/push/abonner", { abonnement: s.toJSON(), appareil: /Android/i.test(navigator.userAgent) ? "Android" : "Téléphone" });
        notifsBlock("Activées : tu seras prévenu dès qu'une tâche t'attend.");
      } else {
        const s = await reg.pushManager.getSubscription();
        if (s) { await api("/api/push/desabonner", { endpoint: s.endpoint }).catch(() => {}); await s.unsubscribe(); }
        notifsBlock("Coupées.");
      }
    } catch (e) { notifsBlock(e.message); }
  }));
  if ($("#notif-test")) $("#notif-test").onclick = async () => {
    try { const r = await api("/api/push/test", {}); notifsBlock(r.envoyes ? "Envoyée : elle arrive dans quelques secondes." : "Pas envoyée : le PC n'a pas pu joindre le service de notification."); }
    catch (e) { notifsBlock(e.message); }
  };
}
async function gPhone() {
  const m = await api("/api/mobile");
  const ts = m.tailscale || {};
  const date = (d) => (d ? new Date(d).toLocaleString("fr-FR", { dateStyle: "short", timeStyle: "short" }) : "jamais");
  if (m.distant) { GB("telephone", `<p class="aide-g discret">Ce téléphone est associé. Les réglages d'accès se font depuis le PC.</p><div id="notifs-tel"></div>`); notifsBlock(); return; }
  let state;
  if (!ts.ok) state = `<p class="warn aide-g">${esc(ts.info || "Tailscale indisponible.")}</p>`;
  else if (m.actif) state = `<p class="ok aide-g">Accessible sur le téléphone : <b>https://${esc(m.adresse || ts.dns)}</b></p>`;
  else state = `<p class="aide-g discret">Tailscale est prêt (${esc(ts.dns)}). Accès coupé.</p>`;
  if (m.autoriser) state += `<p class="warn aide-g">Tailscale demande d'autoriser « Serve » une fois : <a href="${esc(m.autoriser)}" target="_blank" rel="noopener">ouvrir le lien</a>, puis Couper / Activer.</p>`;
  else if (m.reglage && !m.actif && m.erreur) state += `<p class="warn aide-g">${esc(m.erreur)}</p>`;
  const code = phoneCode && phoneCode.fin > Date.now()
    ? `<p class="aide-g">Sur le téléphone, ouvre <b>https://${esc(m.adresse || ts.dns)}</b> et tape :</p><div class="code-tel">${phoneCode.code.replace(/(\d{3})(\d{3})/, "$1 $2")}</div><p class="aide-g discret">Valable 10 minutes, une seule fois.</p>` : "";
  const apps = (m.appareils || []).map((a) => `<div class="tel-app"><span><b>${esc(a.nom)}</b><br><small class="discret">associé le ${date(a.cree)} · vu ${date(a.vu)}</small></span><button class="btn discret" data-revoquer="${esc(a.id)}">Révoquer</button></div>`).join("");
  if (phoneMsg && phoneMsg !== ts.info) state += `<p class="warn aide-g">${esc(phoneMsg)}</p>`;
  GB("telephone", `${state}
    <div class="reglage"><span>Accès depuis le téléphone</span><div class="puces petites" id="tel-acces">${[[true, "Activé"], [false, "Coupé"]].map(([v, t]) => `<button class="puce${!!m.reglage === v ? " sel" : ""}" data-v="${v}">${t}</button>`).join("")}</div></div>
    ${m.actif ? `<div class="reglage"><span>Nouveau téléphone</span><button class="btn" id="tel-code">Associer un téléphone</button></div>` : ""}
    ${code}${apps ? `<p class="sous-titre-g" style="margin-top:12px">Appareils associés</p>${apps}` : ""}
    <p class="aide-g discret" style="margin-top:10px">Seuls tes appareils connectés à ton compte Tailscale voient cette adresse, et chacun doit être associé ici.${m.actif ? " Tant que l'accès est activé, fermer la fenêtre ne ferme plus le studio (le téléphone reste connecté) : pour l'arrêter, bouton « Fermer le studio »." : ""}</p>`);
  $$("#tel-acces .puce").forEach((b) => (b.onclick = async () => {
    b.disabled = true;
    if (b.dataset.v === "true") b.textContent = "Connexion…";
    try { const r = await api("/api/mobile/acces", { oui: b.dataset.v === "true" }); phoneMsg = !r.ok && r.info ? r.info : ""; }
    catch (e) { phoneMsg = e.message; }
    gPhone();
  }));
  const bc = $("#tel-code");
  if (bc) bc.onclick = async () => { const r = await api("/api/mobile/code", { nom: "Téléphone" }); phoneCode = { code: r.code, fin: Date.now() + r.minutes * 60000 }; gPhone(); };
  $$("[data-revoquer]").forEach((b) => (b.onclick = async () => { await api("/api/mobile/revoquer", { id: b.dataset.revoquer }); gPhone(); }));
}
async function gSettings() {
  const l = await api("/api/reglages");
  const groups = [...new Set(l.map((r) => r.groupe))];
  const field = (r) => {
    const id = `${r.section}.${r.cle}`;
    if (r.type === "bool") return `<div class="puces petites" data-r="${id}">${[[true, "Oui"], [false, "Non"]].map(([v, t]) => `<button class="puce${r.valeur === v ? " sel" : ""}" data-v="${v}">${t}</button>`).join("")}</div>`;
    if (r.choix) return `<select data-r="${id}">${r.choix.map((v) => `<option value="${esc(v)}"${String(v) === String(r.valeur) ? " selected" : ""}>${r.unite && v === 0 ? "Aucune" : esc(v)}${r.unite && v ? " " + r.unite : ""}</option>`).join("")}</select>`;
    return `<div class="ligne-chemin"><input class="champ" data-r="${id}" value="${esc(r.valeur || "")}" placeholder="${r.type === "texte" ? "Ton prénom" : "C:\\…"}" spellcheck="false"><button class="btn discret" data-enr="${id}" title="Enregistrer">OK</button></div>`;
  };
  const group = (g) => `<div class="groupe-r"><p class="sous-titre-g">${esc(g)}</p>` + l.filter((r) => r.groupe === g).map((r) =>
    `<div class="reglage${r.type === "chemin" ? " large" : ""}"><span>${esc(r.libelle)}${r.redemarrage ? ' <small class="discret" title="Pris en compte au prochain démarrage du studio">↻</small>' : ""}</span>${field(r)}</div>`).join("") + "</div>";
  const place = (g) => /chemin/i.test(g) ? 4 : /limite|alerte/i.test(g) ? 2 : /entretien|technique/i.test(g) ? 3 : 1;   // Home: workflow only; Gestion: limits, upkeep, technical
  const without = (h) => h.replace(/<p class="sous-titre-g">[^<]*<\/p>/, "");          // the block title is enough
  GB("reglages", groups.filter((g) => place(g) === 1).map(group).join("") + `<p class="${settingMsg.c} aide-g" id="r-msg" style="margin-top:10px">${esc(settingMsg.t)}</p>`);
  GB("reglages2", groups.filter((g) => place(g) === 2).map((g) => without(group(g))).join("") || '<p class="vide">Rien ici.</p>');
  if ($("#g-reglages3")) $("#g-reglages3").innerHTML = groups.filter((g) => place(g) === 3).map(group).join("");
  const save = async (id, value) => {
    const [section, key] = id.split(".");
    try { const r = await api("/api/reglages", { section, cle: key, valeur: value }); settingMsg = { t: r.message, c: "ok" }; if (key === "langue") return location.reload(); gSettings(); if (section === "usage") homeLimits(); }
    catch (e) { settingMsg = { t: e.message, c: "warn" }; gSettings(); }
  };
  const Z = (q) => $$(`#g-reglages ${q}, #g-reglages2 ${q}, #g-reglages3 ${q}`);   // Settings (Home), Limits (Usage), Upkeep and technical (Outils)
  Z(".puces[data-r] .puce").forEach((b) => (b.onclick = () => save(b.parentElement.dataset.r, b.dataset.v === "true")));
  Z("select[data-r]").forEach((x) => (x.onchange = () => save(x.dataset.r, /^\d+$/.test(x.value) ? +x.value : x.value)));
  Z("[data-enr]").forEach((b) => (b.onclick = () => save(b.dataset.enr, Z(`input[data-r="${b.dataset.enr}"]`)[0].value)));
  Z("input[data-r]").forEach((x) => (x.onkeydown = (e) => { if (e.key === "Enter") save(x.dataset.r, x.value); }));
}
async function toolVersions() {
  let v;
  try { v = await api("/api/outils/versions"); } catch (e) { if ($("#o-versions")) $("#o-versions").innerHTML = `<p class="warn">${esc(e.message)}</p>`; return; }
  if (!$("#o-versions")) return;
  const tr = await api("/api/travaux").catch(() => ({}));
  $("#o-versions").innerHTML = `<table class="versions">${Object.entries(v).map(([k, x]) => {
    const inProgress = (tr[`maj:${k}`] || {}).etat === "en_cours";
    const state = !x.installee ? '<span class="bad">introuvable</span>' : x.a_jour === true ? '<span class="ok">à jour</span>'
      : x.a_jour === false ? `<span class="warn">${esc(x.derniere)} disponible</span>` : '<span class="discret">dernière version inconnue</span>';
    const button = inProgress ? '<button class="btn" disabled>Mise à jour…</button>'
      : x.a_jour === false && x.possible ? `<button class="btn principal" data-maj="${k}">Mettre à jour</button>`
      : x.a_jour === false ? `<small class="discret">${esc(x.methode)}</small>` : "";
    return `<tr><td><b>${esc(x.nom)}</b></td><td class="nowrap">${esc(x.installee || "—")}</td><td>${state}</td><td>${button}</td></tr>`;
  }).join("")}</table><p class="discret aide-g">Opus, Sonnet et Haiku suivent seuls les nouveaux modèles : mettre l'outil à jour suffit.</p>`;
  $$("#o-versions [data-maj]").forEach((b) => (b.onclick = async () => {
    const x = v[b.dataset.maj];
    if (!confirm(`Mettre à jour ${x.nom} (${x.installee} → ${x.derniere}) ?\n\nCommande : ${x.methode}. Les tâches doivent être terminées.`)) return;
    try { await api("/api/outils/mettre-a-jour", { outil: b.dataset.maj }); updateJobs(); setTimeout(gTools, 800); setTimeout(gMaintenance, 800); } catch (e) { alert(e.message); }
  }));
}

/* --- Usage */
const USAGES = { "tâche": "Tâches", relecture: "Relectures (auditeur)", superviseur: "Superviseur" };
const nb = (n) => n >= 1e6 ? `${(n / 1e6).toFixed(1).replace(".", ",")} M` : n >= 1e3 ? `${Math.round(n / 1e3)} k` : String(n || 0);
const minutes = (s) => !s ? "0 min" : s < 60 ? `${s} s` : s < 3600 ? `${Math.round(s / 60)} min` : `${Math.floor(s / 3600)} h ${String(Math.round((s % 3600) / 60)).padStart(2, "0")}`;
function adjustUsage() {                                       // « Détails du jour » expanded only if they fit without scrolling
  const c = $("#g-usage") && $("#g-usage").closest(".corps-g"), d = $("#u-details");
  if (!c || !d || !c.clientHeight) return;
  d.open = true;
  if (c.scrollHeight > c.clientHeight + 1) d.open = false;
}
/* Usage of all AIs: subscriptions (included), API keys (pay per use), local AIs (free) */
const AI_COLORS = ["var(--cyan)", "var(--magenta)", "#ffc35c", "#5ee6a0", "#9b8cff", "#ff8a3d", "#4aa8ff", "#e6fbff"];
const dollars = (v) => v == null ? "—" : v < 0.01 && v > 0 ? "< 0,01 $" : `${v.toFixed(2).replace(".", ",")} $`;
async function gUsage() {
  const u = await api("/api/usage");
  const order = u.ordre || Object.keys(u.familles);
  const couleur = (fam) => AI_COLORS[order.indexOf(fam) % AI_COLORS.length];
  const max = Math.max(60, ...u.jours.map((d) => Object.values(d.familles).reduce((a, b) => a + b, 0)));
  const shortDay = (d) => new Date(d + "T12:00:00").toLocaleDateString("fr-FR", { weekday: "short" });
  const ACCESS = { abonnement: "abonnement", cle: "clé API", local: "local" };
  const cell = (t) => t.appels ? `${minutes(t.duree_s)}<small class="discret"> · ${t.appels}</small>` : '<span class="discret">—</span>';
  const cost = (f) => f.acces === "abonnement" ? `<span class="discret" title="${f.semaine.cout_usd ? `≈ ${dollars(f.semaine.cout_usd)} si c'était facturé à l'API` : ""}">inclus</span>`
    : f.acces === "local" ? '<span class="ok">gratuit</span>' : `<b>${dollars(f.semaine.cout_usd)}</b>`;
  const rows = order.map((fam) => { const f = u.familles[fam];
    return `<tr><td><span class="carre" style="background:${couleur(fam)}"></span> <b>${esc(fam)}</b></td><td class="discret">${ACCESS[f.acces]}</td><td>${cell(f.fenetre)}</td><td>${cell(f.jour)}</td><td>${cell(f.semaine)}</td><td class="nowrap">${cost(f)}</td></tr>`; }).join("");
  const board = (l, name) => l.length ? `<table>${l.map((x) => `<tr><td>${esc(name(x))}</td><td class="nowrap">${minutes(x.duree_s)}</td><td class="nowrap">${x.appels} appel${x.appels > 1 ? "s" : ""}</td></tr>`).join("")}</table>` : '<p class="vide">Rien aujourd\'hui.</p>';
  const cp = u.cout_paye || {};
  const paid = order.some((f) => u.familles[f].acces === "cle");
  GB("usage", `${paid ? `<div class="cout-usage"><span>Payé à l'usage (clés API)</span><b>${dollars(cp.jour)}</b><small>aujourd'hui</small><b>${dollars(cp.semaine)}</b><small>7 jours</small><b>${dollars(cp.mois)}</b><small>30 jours</small></div>
      <p class="discret aide-g">Coût réel donné par OpenRouter, sinon estimé au prix du jour${cp.sans_prix ? ` (${cp.sans_prix} appel(s) sans prix connu)` : ""}. Les abonnements sont inclus, les IA locales gratuites.</p>` : ""}
    <table class="usage-resume"><thead><tr><th>IA</th><th>Accès</th><th>5 h</th><th>Aujourd'hui</th><th>7 jours</th><th>Coût 7 j</th></tr></thead><tbody>${rows}</tbody></table>
    <div class="usage-jours petit">${u.jours.map((d) => `<div class="usage-jour" title="${esc(d.jour)} · ${order.filter((f) => d.familles[f]).map((f) => `${f} ${minutes(d.familles[f])}`).join(" · ") || "rien"}">
      <div class="pile">${order.map((f) => d.familles[f] ? `<span style="height:${Math.round(d.familles[f] / max * 100)}%;background:${couleur(f)}"></span>` : "").join("")}</div><small class="discret">${shortDay(d.jour)}</small></div>`).join("")}</div>
    <details class="pli" id="u-details" style="margin-top:10px"><summary>Détails du jour</summary>
      <div class="usage-duo">${board(u.par_usage, (x) => USAGES[x.nom] || x.nom)}${board(u.par_projet, (x) => x.nom)}</div>
      ${u.derniers.length ? `<p class="sous-titre-g">Derniers appels</p><table>${u.derniers.slice(0, 8).map((x) => `<tr><td class="nowrap">${esc(x.heure)}</td><td>${esc(x.famille)}${x.modele ? " · " + esc(x.modele) : ""}</td><td>${esc(USAGES[x.usage] || x.usage)}</td><td>${esc(x.projet)}</td><td class="nowrap">${minutes(x.duree_s)}</td><td class="nowrap">${nb((x.entree || 0) + (x.cache || 0) + (x.sortie || 0))} jetons${x.cout_usd != null && !["Claude", "Codex"].includes(x.famille) ? " · " + dollars(x.cout_usd) : ""}</td><td>${x.ok ? "" : '<span class="bad">échec</span>'}</td></tr>`).join("")}</table>` : ""}
      <p class="discret aide-g">Seul l'usage lancé par le studio est compté.</p></details>
    <details class="pli" id="u-resultats"><summary>Tes résultats</summary><div id="u-res"><p class="vide">…</p></div></details>`);
  $("#u-resultats").ontoggle = (e) => { if (e.currentTarget.open) gResults(); };
  adjustUsage();
}

/* What your own tasks say about each model: first-try success, time, cost, by type of work. */
async function gResults() {
  let r;
  try { r = await api("/api/resultats"); } catch (e) { $("#u-res").innerHTML = `<p class="bad">${esc(e.message)}</p>`; return; }
  const pct = (a, b) => `${Math.round(100 * a / b)} %`;
  $("#u-res").innerHTML = r.lignes.length ? `<table class="table-resultats"><thead><tr><th>Travail</th><th>IA · modèle</th><th>Tâches</th><th title="Validée sans « corriger » ni reprise">Du 1er coup</th><th>Validées</th><th>Temps moy.</th><th>Coût moy.</th></tr></thead><tbody>
    ${r.lignes.map((x) => `<tr><td>${esc(x.travail)}</td><td>${esc(x.ia)}</td><td>${x.taches}</td><td class="${x.premier_coup / x.taches >= 0.7 ? "ok" : x.premier_coup / x.taches < 0.4 ? "warn" : ""}">${pct(x.premier_coup, x.taches)}</td><td>${pct(x.reussies, x.taches)}</td><td class="nowrap">${minutes(x.duree_moy_s)}</td><td class="nowrap">${x.cout_moy_usd == null ? "—" : dollars(x.cout_moy_usd)}</td></tr>`).join("")}</tbody></table>
    <p class="discret aide-g">Calculé sur tes ${r.total} tâche(s) terminée(s), sur ce PC. Dès ${r.min} tâches d'un même travail, le Superviseur te dit quel modèle le réussit le mieux.</p>`
    : `<p class="vide">Pas encore de tâche terminée. Le studio apprend de chaque tâche que tu valides (ou corriges) quel modèle réussit le mieux chaque travail.</p>`;
}

/* --- Data: memory, backups, cleanup */
let memoryScope = "general";
async function gMemory() {
  if (!targets.length) targets = await api("/api/cibles");
  GB("memoire", `<div class="ligne-g"><select id="m-portee" aria-label="Portée de la mémoire">${[["general", "Général"], ...targets.map((c) => [c.memoire.replace(/^studio:/, ""), c.nom])].map(([v, t]) => `<option value="${esc(v)}"${v === memoryScope ? " selected" : ""}>${esc(t)}</option>`).join("")}</select>
      <input class="recherche" id="m-q" placeholder="Chercher (Entrée)"></div><div id="m-res" class="defile-g court">…</div>
    <details class="pli"><summary>Ajouter un souvenir</summary>
      <textarea id="m-texte" class="zone-texte" placeholder="Un fait ou une décision à retenir — jamais de secret"></textarea>
      <div class="actions"><button class="btn" id="m-ajouter">Ajouter</button><span id="m-msg" class="discret"></span></div></details>`);
  $("#m-portee").onchange = () => { memoryScope = $("#m-portee").value; lookup(); };
  $("#m-q").onkeydown = (e) => { if (e.key === "Enter") lookup(); };
  $("#m-ajouter").onclick = async () => {
    try { const r = await api("/api/memoire", { portee: memoryScope, texte: $("#m-texte").value }); $("#m-msg").textContent = r.partage ? "Enregistré." : `Non partagé : ${r.statut}`; $("#m-texte").value = ""; lookup(); }
    catch (e) { $("#m-msg").textContent = e.message; }
  };
  lookup();
}
async function lookup() {
  try {
    const r = await api(`/api/memoire?${new URLSearchParams({ q: $("#m-q").value, portee: memoryScope })}`);
    $("#m-res").innerHTML = (r.en_attente ? `<div class="alerte">${r.en_attente} écriture(s) pas encore partagée(s).</div>` : "")
      + (r.souvenirs.map((x) => `<div class="souvenir">${esc(x.content)}<br><small>${esc(x.scope.replace(/^studio:/, ""))} · ${esc(x.provenance?.outil || "?")} · ${esc((x.created_at || "").slice(0, 10))}</small></div>`).join("") || '<p class="vide">Rien pour cette recherche.</p>');
  } catch (e) { $("#m-res").innerHTML = `<div class="alerte">${esc(e.message)}</div>`; }
}
/* --- Git and GitHub: repo status, branches, working copies, one-click actions */
let gitRepository = "";                                            // repo shown in the project's Branches tab
const gitSummary = (e) => e.erreur ? `<span class="bad">${esc(e.erreur)}</span>` : [
  e.detache ? '<span class="warn">HEAD détaché</span>' : `⎇ ${esc(e.branche)}`,
  e.modifies.length ? `<span class="warn">${e.modifies.length} fichier${e.modifies.length > 1 ? "s" : ""} modifié${e.modifies.length > 1 ? "s" : ""}</span>` : '<span class="ok">propre</span>',
  e.en_avance ? `<span class="warn">↑ ${e.en_avance} à pousser</span>` : "", e.en_retard ? `<span class="warn">↓ ${e.en_retard} à récupérer</span>` : "",
  !e.distant ? '<span class="discret">pas de GitHub</span>' : !e.amont && !e.detache ? '<span class="discret">branche pas sur GitHub</span>' : ""].filter(Boolean).join(" · ");
async function gitDetail() {
  let d;
  try { d = await api(`/api/git/${encodeURIComponent(gitRepository)}`); } catch (e) { GB("git", `<div class="alerte">${esc(e.message)}</div>`); return; }
  const tr = await api("/api/travaux").catch(() => ({}));
  const inProgress = (a) => (tr[`git:${gitRepository.split(":")[1]}:${a}`] || {}).etat === "en_cours";
  const button = (a, label, ok, helpText) => `<button class="btn${a === "pousser" && d.en_avance ? " principal" : ""}" data-git="${a}" ${ok && !inProgress(a) ? "" : "disabled"} title="${esc(helpText)}">${inProgress(a) ? "En cours…" : label}</button>`;
  const latest = Object.entries(tr).filter(([k]) => k.startsWith(`git:${gitRepository.split(":")[1]}:`)).map(([, j]) => j).sort((a, b) => (a.debut < b.debut ? 1 : -1));
  GB("git-etat", `${d.detache ? '<div class="alerte">HEAD détaché : aucune branche courante.</div>' : ""}
    <div class="actions-git">${button("actualiser", "Fetch", !!d.distant, "Actualiser : git fetch --prune, regarde ce qu'il y a de neuf sur GitHub, ne change aucun fichier")}
      ${button("recuperer", d.en_retard ? `Pull ↓${d.en_retard}` : "Pull", !!d.amont && !d.detache, "Récupérer : git pull --ff-only, seulement si rien ne se mélange")}
      ${d.gh ? button("pr", "Pull request", !!d.amont && !d.en_avance && !d.detache, "Créer une pull request sur GitHub (gh pr create --fill)") : ""}
      ${d.distant ? (d.distant.startsWith("https://github.com/") ? `<a class="lien lien-depot" href="${esc(d.distant)}" target="_blank" rel="noopener">${esc(d.distant.replace("https://", ""))}</a>` : `<small class="discret">${esc(d.distant)}</small>`) : ""}
      <span id="git-msg" class="discret"></span></div>
    ${latest.length ? `<p class="discret" style="margin:-6px 0 12px">Dernière action : ${latest[0].etat === "en_cours" ? "⚙" : latest[0].etat === "ok" ? "✔" : "✖"} ${esc(latest[0].titre)}${latest[0].etat === "echec" && latest[0].sortie ? ` — <span class="bad">${esc(latest[0].sortie.slice(-200))}</span>` : ""}</p>` : ""}
    `);
  commitBlock(d);
  treeArgs = [d, button]; branchGraph(d, button);
  const msg = (t) => { const m = $("#git-msg"); if (m) m.textContent = t; };
  const mergedCount = d.branches.filter((b) => b.fusionnee && !b.courante).length;
  $("#g-git").onclick = async (e) => {
    const x = (sel) => e.target.closest(sel);
    let b;
    if ((b = x("[data-git]"))) {
      const a = b.dataset.git;
      if ((a === "pousser" || a === "pr") && !confirm(a === "pousser" ? `Pousser ${d.branche} vers GitHub ?` : `Créer une pull request pour ${d.branche} sur GitHub ?`)) return;
      try { const r = await api("/api/git/action", { cible: gitRepository, action: a }); msg(r.message); updateJobs(); trackGit(); } catch (er) { msg(er.message); }
    } else if ((b = x("#git-nettoyer"))) {
      if (!confirm(`Supprimer les ${mergedCount} branches déjà fusionnées ? Leurs commits sont dans ${d.branche} : rien n'est perdu.`)) return;
      try { const r = await api("/api/git/nettoyer", { cible: gitRepository }); msg(r.message); gitDetail(); gitLine(gitRepository); } catch (er) { msg(er.message); }
    } else if ((b = x("[data-fusion]"))) {
      b.disabled = true; b.textContent = "Merge…";
      try {
        const r = await api("/api/git/fusionner", { cible: gitRepository, branche: b.dataset.fusion }); msg(r.message);
        const line = b.closest(".act-b");
        if (line) line.classList.add("fusion");           // the button disappears, then the tree redraws
        setTimeout(() => { gitDetail(); gitLine(gitRepository); }, line && !reducedMotion() ? 650 : 0); lastView = "";
      } catch (er) { msg(er.message); b.disabled = false; b.textContent = "Merge"; }
    } else if ((b = x("[data-effacer]"))) {
      if (!confirm(`Effacer la branche ${b.dataset.effacer} ?\n\nSon travail non fusionné sera perdu. La tâche reste dans l'historique (annulée), avec son compte rendu.`)) return;
      try { const r = await api("/api/git/effacer-branche", { cible: gitRepository, branche: b.dataset.effacer }); msg(r.message); gitDetail(); gitLine(gitRepository); lastView = ""; } catch (er) { msg(er.message); }
    } else if ((b = x("[data-suppr]"))) {
      if (!confirm(`Supprimer la branche ${b.dataset.suppr} ? Elle est déjà fusionnée : aucun commit n'est perdu.`)) return;
      try { const r = await api("/api/git/supprimer-branche", { cible: gitRepository, branche: b.dataset.suppr }); msg(r.message); gitDetail(); gitLine(gitRepository); } catch (er) { msg(er.message); }
    } else if ((b = x("[data-retirer]"))) {
      if (!confirm("Retirer cette copie de travail ? Le résultat, le diff et le journal de la tâche restent.")) return;
      try { const r = await api(`/api/espaces/${b.dataset.retirer}/retirer`, {}); msg(r.message); gitDetail(); } catch (er) { msg(er.message); }
    } else if ((b = x("[data-voir-tache]"))) {
      selection = b.dataset.voirTache; lastView = ""; currentBlock = "detail"; show(); renderTabsBlock();
    }
  };
  $$("#g-git-etat [data-git]").forEach((b) => (b.onclick = async () => {
    const a = b.dataset.git;
    if (a === "pr" && !confirm(`Créer une pull request pour ${d.branche} sur GitHub ?`)) return;
    try { const r = await api("/api/git/action", { cible: gitRepository, action: a }); msg(r.message); updateJobs(); trackGit(); } catch (er) { msg(er.message); }
  }));
  if (Object.keys(tr).some((k) => k.startsWith("git:") && tr[k].etat === "en_cours")) trackGit();
}
/* Branches as a « subway line »: main as a vertical neon line; each task branches off in a curve toward its card,
   color = status. The useful action is on the card (Fusionner, Valider, Reprendre): one click. Click on the card = the task. */
const reducedMotion = () => matchMedia("(prefers-reduced-motion: reduce)").matches;
function branchHue(b) {
  const st = b.tache ? b.tache.statut : "";
  if (["creee", "en_cours", "en_attente_creneau"].includes(st)) return ["bleu", "en cours"];
  if (TO_APPROVE.includes(st)) return ["jaune", "à valider"];
  if (["approuvee", "appliquee"].includes(st)) return ["vert", "prête à fusionner"];
  if (["bloquee", "echec", "interrompue"].includes(st)) return ["rouge", LABELS[st]];
  if (st === "annulee") return ["rouge", "annulée"];
  return ["gris", "branche"];
}
function sinceWhen(date) {
  const t = Date.parse(String(date).replace(" ", "T")); if (!t) return "";
  const m = Math.round((Date.now() - t) / 60000);
  return m < 1 ? "à l'instant" : m < 60 ? `il y a ${m} min` : m < 1440 ? `il y a ${Math.round(m / 60)} h` : `il y a ${Math.round(m / 1440)} j`;
}
function branchGraph(d, button) {
  /* Tree styled like a USB symbol / circuit board, main horizontal toward its arrow. A single step E all along main:
     arrow → merge squares → branch starts (oldest near the merges, newer ones toward the left).
     Each branch splits off at 45° then runs parallel to main up to its symbol (same size for all).
     Above: blocked and cancelled. Below: running, awaiting approval, ready. Text appears on hover;
     the action button always stays visible at the end of the branch. */
  const el = $("#g-git"); if (!el) return;
  const alive = d.branches.filter((b) => !b.courante && !b.fusionnee).sort((a, b) => (a.date < b.date ? -1 : 1));
  // squares: merges not yet pushed to GitHub (after Push, none remain); without GitHub, the last 12
  const merges = (d.a_pousser || d.historique || []).filter((c) => /^(Fusion studio|Merge branch)/.test(c.sujet)).slice(-12);
  const mergedCount = d.branches.filter((b) => b.fusionnee && !b.courante).length;
  // E: spacing of merge squares; EB: spacing of branches, the same for all, just large enough that a branch and
  // its buttons never touch the next one on the same side (the two sides alternate freely)
  // A branch = 45° (D) + parallel line (HZ) up to its symbol, its buttons centered below. E: spacing of merge
  // squares. EB: spacing of branches, the same for all; each symbol sits midway between its start and
  // the next start (or the last merge). Too long for the frame: the tree scrolls horizontally.
  const T = 12, C = 10, D = 22, HZ = 62, E = 56, GAP = 5, BTN = 21;   // buttons centered under the symbol
  const EB = 2 * (D + HZ);                                   // the symbol sits exactly midway between two starts
  const cy = D + T / 2 + 7 + BTN + 10, H = cy * 2;
  const W = Math.max(el.clientWidth || 700, 60 + (merges.length + 1) * E + alive.length * EB);
  const xA = W - 16;                                         // arrow tip; one E step between the arrow and each merge
  const pos = (k) => xA - T / 2 - (k + 1) * E;               // k-th merge from the arrow
  const origin = (i) => pos(merges.length - 1) - (i + 1) * EB;   // the oldest: symbol midway between its start and the last merge
  const shape = (cl, x, y, direction) => direction === "carre" ? `<rect class="${cl}" x="${x - C / 2}" y="${y - C / 2}" width="${C}" height="${C}"/>`
    : direction === "rond" ? `<circle class="${cl}" cx="${x}" cy="${y}" r="${T / 2}"/>`
    : `<path class="${cl}" d="M${x - T / 2} ${y - T / 2} L${x + T / 2} ${y} L${x - T / 2} ${y + T / 2} Z"/>`;   // right-pointing arrow
  const rel = alive.slice().reverse().map((b, i) => {      // the oldest right after the last merge
    const [hue, lib] = branchHue(b);
    const side = ["rouge", "gris"].includes(hue) ? -1 : 1, s0 = origin(i);
    return { b, teinte: hue, lib, cote: side, s0, y: cy + side * D, xp: s0 + D + HZ };
  });
  const x0 = Math.min(rel.length ? rel[rel.length - 1].s0 - 24 : pos(merges.length), 20);
  let xs = x0, trunks = "", defs = "";
  for (const r of rel.slice().sort((a, b) => a.s0 - b.s0)) { trunks += `<line class="tronc" x1="${xs}" y1="${cy}" x2="${r.s0}" y2="${cy}"/>`; xs = r.s0 + GAP; }
  trunks += `<line class="tronc" x1="${xs}" y1="${cy}" x2="${xA - T}" y2="${cy}"/>`;
  let svg = `${trunks}${shape("fleche", xA - T / 2, cy, "droite")}${shape("pied", x0 - T / 2, cy, "rond")}`;
  svg += merges.slice().reverse().map((c, i) => `<g><title>${esc(c.date)} · ${esc(c.sujet)}</title>${shape("carre-f", pos(i), cy, "carre")}</g>`).join("");
  const zones = rel.map((r, k) => {
    const { b, teinte: hue, cote: side, s0, y, xp } = r, t = b.tache;
    const gid = `deg-${k}`;                                   // the diagonal fades from main's cyan to the branch color
    defs += `<linearGradient id="${gid}" gradientUnits="userSpaceOnUse" x1="${s0}" y1="${cy}" x2="${s0 + D}" y2="${y}"><stop offset="0" class="arret-main"/><stop offset="1" class="arret-${hue}"/></linearGradient>`;
    svg += `<g class="branche-svg" data-i="${k}"><line class="trace-d" stroke="url(#${gid})" x1="${s0}" y1="${cy}" x2="${s0 + D}" y2="${y}"/><line class="trace ${hue}" x1="${s0 + D}" y1="${y}" x2="${xp - T / 2 - 1}" y2="${y}"/>`
      + shape(`pad ${hue}${hue === "bleu" ? " pulse" : ""}`, xp, y, hue === "bleu" ? "rond" : hue === "jaune" ? "droite" : "carre") + "</g>";
    // under the symbol: only git actions — Commit (greyed out if there is nothing to commit), Merge, or Delete for a
    // red branch; Stop, Reprendre and Annuler are in the card that opens when hovering the symbol
    let act = "";
    if (hue === "rouge" && t) act = `<button class="btn petit danger" data-effacer="${esc(b.nom)}" title="Supprimer : annule la tâche si besoin, retire sa copie et efface la branche (git branch -D)">Delete</button>`;
    else if (hue === "vert") act = `<button class="btn principal petit" data-fusion="${esc(b.nom)}" title="Fusionner : git merge dans ${esc(d.branche)}, en local ; rien n'est poussé vers GitHub">Merge</button>`;
    else if (t) {
      const toApprove = TO_APPROVE.includes(t.statut);
      act = `<button class="btn${toApprove ? " principal" : ""} petit" data-rapide="valider" data-tid="${esc(t.id)}" ${toApprove ? "" : "disabled"} title="${toApprove ? "Valider : le travail est enregistré (git commit) sur la branche de la tâche" : "Rien à valider pour l'instant"}">Commit</button>`;
    }
    const zone = `left:${xp - 15}px;top:${y - 15}px;width:30px;height:30px`;     // symbol hover
    return `<div class="zone-b" data-i="${k}" ${t ? `data-voir-tache="${esc(t.id)}"` : ""} tabindex="0" role="button" aria-label="${esc(t ? t.titre : b.nom)}" style="${zone}"></div>
      ${act ? `<div class="act-b" style="left:${xp}px;top:${side > 0 ? y + T / 2 + 8 : y - T / 2 - 8 - BTN}px">${act}</div>` : ""}`;
  });
  const canPush = !!d.distant && !d.detache && !d.en_retard && (d.en_avance || !d.amont);
  el.innerHTML = `<div class="arbre-tete"><span class="branche-c">⎇ ${esc(d.branche)}</span>
      <span class="meta-main">${d.en_avance ? `<b>${d.en_avance}</b> commit${d.en_avance > 1 ? "s" : ""} à pousser` : d.amont ? "à jour avec GitHub" : "pas encore sur GitHub"}${merges.length ? ` · ${merges.length} fusion${merges.length > 1 ? "s" : ""} ${d.a_pousser ? "à pousser" : "récente" + (merges.length > 1 ? "s" : "")}` : ""}</span>
      ${button("pousser", d.en_avance ? `Push ↑${d.en_avance}` : "Push", canPush, "Pousser : git push de la branche courante vers GitHub (jamais forcé)")}</div>
    <div class="arbre-cadre"><div class="arbre-defile"><div class="arbre" style="width:${W}px;height:${H}px"><svg width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" aria-hidden="true"><defs>${defs}</defs>${svg}</svg>${zones.join("")}
      ${!alive.length ? `<p class="arbre-vide" style="top:${cy + 14}px;right:${W - pos(merges.length) + 10}px">Aucune branche ouverte : tout est dans main.</p>` : ""}</div></div>
      <div class="info-b" hidden></div></div>
    ${mergedCount ? `<div class="metro-pied"><span>✓ ${mergedCount} branche${mergedCount > 1 ? "s" : ""} fusionnée${mergedCount > 1 ? "s" : ""} encore présente${mergedCount > 1 ? "s" : ""}</span><button class="lien" id="git-nettoyer" title="Supprimer : git branch -d sur chaque branche déjà fusionnée (copies de travail retirées avec) ; aucun commit perdu">Delete</button></div>` : ""}`;
  // hovering (or keyboard focus on) a branch: its card appears above or below
  const info = el.querySelector(".info-b"), frame = el.querySelector(".arbre-cadre");
  let infoTimer = 0, hovered = null;
  const hide = () => { info.hidden = true; if (hovered) hovered.classList.remove("survol"); hovered = null; };
  const later = () => { clearTimeout(infoTimer); infoTimer = setTimeout(hide, 280); };
  const showView = (z) => {
    clearTimeout(infoTimer);
    const r = rel[+z.dataset.i], t = r.b.tache, st = t ? t.statut : "";
    const meta = [r.b.devant != null ? `${r.b.devant} commit${r.b.devant > 1 ? "s" : ""}` : "", r.b.derriere ? `main a avancé de ${r.b.derriere}` : "", sinceWhen(r.b.date)].filter(Boolean).join(" · ");
    const running = ["creee", "en_cours", "en_attente_creneau"].includes(st), stopped = ["bloquee", "interrompue"].includes(st);
    const buttons = t ? [`<button class="btn principal petit" data-voir-tache="${esc(t.id)}">Voir la tâche</button>`,
      running ? `<button class="btn petit" data-rapide="stop" data-tid="${esc(t.id)}" title="Arrête l'agent ; Reprendre le relance là où il en était">Stop</button>` : "",
      stopped ? `<button class="btn petit" data-rapide="reprendre" data-tid="${esc(t.id)}">Reprendre</button>` : "",
      running || TO_APPROVE.includes(st) ? `<button class="btn discret petit danger" data-rapide="annuler" data-tid="${esc(t.id)}">Annuler</button>` : ""].join("") : "";
    info.className = `info-b ${r.teinte}`;
    info.innerHTML = `<b>${esc(t ? (withoutProject(short(t.titre, 90), []) || "Tâche") : r.b.nom)}</b><span class="etat-b">${esc(r.lib)}</span><small>${esc(meta)}</small>${buttons ? `<div class="boutons-info">${buttons}</div>` : ""}`;
    info.hidden = false;
    const zc = z.getBoundingClientRect(), cc = frame.getBoundingClientRect();
    info.style.left = Math.min(Math.max(0, zc.left - cc.left + zc.width / 2 - info.offsetWidth / 2), cc.width - info.offsetWidth) + "px";
    info.style.top = (r.cote > 0 ? zc.top - cc.top - info.offsetHeight - 6 : zc.bottom - cc.top + 6) + "px";   // main side: do not hide the buttons
    if (hovered) hovered.classList.remove("survol");
    hovered = el.querySelector(`.branche-svg[data-i="${z.dataset.i}"]`); if (hovered) hovered.classList.add("survol");
  };
  info.onmouseenter = () => clearTimeout(infoTimer);
  info.onmouseleave = later;
  info.onclick = (e) => { if (e.target.closest("button")) setTimeout(hide, 50); };
  const tactile = matchMedia("(hover: none)").matches;      // phone: a tap opens the card (no hover)
  el.querySelectorAll(".zone-b").forEach((z) => {
    z.onmouseenter = z.onfocus = () => { if (!tactile) showView(z); };
    z.onmouseleave = z.onblur = () => { if (!tactile) later(); };
    z.onkeydown = (e) => { if (e.key === "Enter") z.click(); };
    if (tactile) z.onclick = (e) => { e.stopPropagation(); showView(z); };
  });
  if (tactile) frame.onclick = (e) => { if (!e.target.closest(".info-b,.zone-b")) hide(); };
  const scroller = el.querySelector(".arbre-defile");
  if (scroller) {
    scroller.scrollLeft = scroller.scrollWidth;                 // the arrow (latest in main) visible
    let drag = null;                                         // drag with the mouse to scroll the tree
    scroller.onpointerdown = (e) => { if (e.button || e.target.closest("button,.zone-b")) return; drag = { x: e.clientX, g: scroller.scrollLeft }; scroller.classList.add("tire"); };
    scroller.onpointermove = (e) => { if (drag) scroller.scrollLeft = drag.g - (e.clientX - drag.x); };
    scroller.onpointerup = scroller.onpointerleave = () => { drag = null; scroller.classList.remove("tire"); };
    scroller.onscroll = hide;
  }
}
let treeTimer = 0, treeArgs = null;
addEventListener("resize", () => { clearTimeout(treeTimer); treeTimer = setTimeout(() => { if (treeArgs && currentBlock === "branches") branchGraph(...treeArgs); }, 200); });
/* One-click commit: files checked (very large ones unchecked by default), message auto-filled if empty */
async function commitBlock(d) {
  if (!d.modifies.length) { GB("git-fichiers", '<p class="vide">Rien à commiter : ton dossier est propre.</p>'); return; }
  let info;
  try { info = await api(`/api/git/${encodeURIComponent(gitRepository)}/a-commiter`); } catch (e) { GB("git-fichiers", `<div class="alerte">${esc(e.message)}</div>`); return; }
  const f = info.fichiers;
  const line = (x, i) => `<label class="ligne-commit${x.raison ? " exclu" : ""}"><input type="checkbox" data-i="${i}" ${x.coche ? "checked" : ""}>
      <span class="etat-f">${esc(x.etat)}</span><span class="chemin-f">${esc(x.chemin)}</span>${x.raison ? `<small class="warn">${esc(x.raison)}</small>` : ""}</label>`;
  GB("git-fichiers", `<div class="commit-bloc"><p class="aide-commit">${f.length} fichier${f.length > 1 ? "s" : ""} pas encore enregistré${f.length > 1 ? "s" : ""} dans <b>${esc(info.branche)}</b>. Tant qu'ils ne sont pas commités, aucune tâche ne peut être fusionnée.</p>
      <div class="liste-commit">${f.map(line).join("")}</div>
      <div class="actions-git"><input id="commit-msg" class="champ" placeholder="Message (facultatif : rempli tout seul)" maxlength="200">
        <button class="btn principal" id="commit-ok">Commit</button><span id="commit-info" class="discret"></span></div>
      <small class="discret">Commit local seulement : rien n'est envoyé sur GitHub (bouton « Pousser » pour ça).</small></div>`);
  const account = () => { const n = $$("#g-git-fichiers input[data-i]:checked").length; $("#commit-ok").textContent = n ? `Commit (${n})` : "Commit"; $("#commit-ok").disabled = !n; };
  $$("#g-git-fichiers input[data-i]").forEach((c) => (c.onchange = account)); account();
  $("#commit-ok").onclick = async () => {
    const chosen = [...$$("#g-git-fichiers input[data-i]:checked")].map((c) => f[+c.dataset.i].chemin);
    $("#commit-ok").disabled = true; $("#commit-info").textContent = "Commit…";
    try { const r = await api("/api/git/commit", { cible: gitRepository, fichiers: chosen, message: $("#commit-msg").value }); $("#commit-info").textContent = r.message; lastView = ""; gitDetail(); gitLine(gitRepository); }
    catch (e) { $("#commit-info").textContent = e.message; $("#commit-ok").disabled = false; }
  };
}
/* Live: what the agent is doing, files touched, open applications — refreshed every 4 s during the task */
let liveTimer = null, liveActive = false;
async function taskActivity(tid, active) {
  clearTimeout(liveTimer);
  const el = $("#direct-tache");
  if (!el || selection !== tid) return;
  let a;
  try { a = await api(`/api/taches/${tid}/activite`); } catch { return; }
  if (selection !== tid || !$("#direct-tache")) return;
  const hour = (iso) => { try { return new Date(iso).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" }); } catch { return ""; } };
  const actions = a.actions.length ? `<ul class="direct-liste">${a.actions.map((x, i) => `<li class="${i === 0 && active ? "maintenant" : ""}${x.genre === "refus" ? " bad" : ""}"><span class="heure">${esc(hour(x.heure))}</span>${esc(x.texte)}${x.fois > 1 ? ` <small class="discret">×${x.fois}</small>` : ""}</li>`).join("")}</ul>`
    : `<p class="discret">${active ? "Il lit le projet et prépare son travail…" : "Aucune action notée."}</p>`;
  const fileName = (c) => c.split("/").pop();
  const taskFiles = a.fichiers.length ? `<ul class="direct-liste">${a.fichiers.slice(0, 12).map((f) => `<li title="${esc(f.chemin)}"><span class="etat-f ${f.etat === "nouveau" ? "ok" : f.etat === "supprimé" ? "bad" : "warn"}">${esc(f.etat)}</span>${esc(fileName(f.chemin))}</li>`).join("")}${a.fichiers.length > 12 ? `<li class="discret">… et ${a.fichiers.length - 12} autres</li>` : ""}</ul>`
    : '<p class="discret">Aucun fichier modifié pour l\'instant.</p>';
  const COLORS = { "ouvert": "ok", "en cours": "info", "en arrière-plan": "info", "fermé": "bad" };
  const appList = a.applications.length ? `<ul class="direct-liste">${a.applications.map((x) => `<li><b>${esc(x.nom)}</b> — <span class="${COLORS[x.statut] || ""}">${esc(x.statut)}</span></li>`).join("")}</ul>`
    : '<p class="discret">Aucune application ouverte par l\'agent.</p>';
  if (a.modele && $("#modele-direct") && !$("#modele-direct").textContent) $("#modele-direct").textContent = " · " + a.modele;
  const said = active && [...(a.journal || [])].reverse().find((x) => x.genre === "message");   // what it says it is doing now
  if (said && $("#etape-texte")) $("#etape-texte").textContent = said.texte;
  const journal = journalView(a.journal || [], active, a.utilises);
  // while it works: the journal, with the files touched and the open applications beside it; afterwards, the journal only
  const oldList = el.querySelector(".journal-direct");          // keeps the reading position (top = follows the news)
  const atTop = !oldList || oldList.scrollTop < 30, oldTop = oldList ? oldList.scrollTop : 0, oldHeight = oldList ? oldList.scrollHeight : 0;
  liveActive = active;
  const opened = new Set([...el.querySelectorAll(".journal-direct li[data-k] details[open]")].map((d) => d.closest("li").dataset.k));
  el.innerHTML = active ? `<div class="direct-grille direct-journal">
      <div><p class="sous-titre-g">Journal</p>${journal}</div>
      <div><p class="sous-titre-g">Fichiers touchés${a.fichiers.length ? ` (${a.fichiers.length})` : ""}</p>${taskFiles}
        <p class="sous-titre-g">Applications</p>${appList}</div></div>`
    : (a.journal || []).length ? `<div class="journal-fini"><p class="sous-titre-g">Journal <span class="n">${a.journal.length}</span></p>${journal}</div>` : "";
  el.hidden = !el.innerHTML;
  el.querySelectorAll(".journal-direct li[data-k]").forEach((li) => { if (opened.has(li.dataset.k)) { const d = li.querySelector("details"); if (d) d.open = true; } });
  wireJournal(el);
  const list = el.querySelector(".journal-direct");
  if (list) list.scrollTop = atTop ? 0 : oldTop + (list.scrollHeight - oldHeight);   // reading older lines: they stay in place
  if (active) liveTimer = setTimeout(() => taskActivity(tid, true), 2500);
}
/* Journal: every step of the agent and of the studio, newest at the top, filter by kind, detail on click */
const JOURNAL_KINDS = [["", "Tout"], ["message", "Messages"], ["fichier", "Fichiers"], ["commande", "Commandes"], ["outil", "Skills et outils"], ["studio", "Studio"]];
let journalFilter = "";
function journalView(rows, active, used) {
  const kept = rows.filter((r) => !journalFilter || r.genre === journalFilter);
  const hour = (t) => { try { return new Date(t * 1000).toLocaleTimeString("fr-FR"); } catch { return ""; } };
  const ICONS = { message: "💬", fichier: "📄", commande: "›_", outil: "⚙", studio: "◆" };
  const say = (r) => r.genre === "studio" ? r.texte.replace(/^Statut : (\w+)/, (m, x) => "Statut : " + (LABELS[x] || x)).replace(/unreal-mcp/g, "connexion à Unreal") : r.texte;
  kept.forEach((r) => (r.texte = say(r)));
  const items = kept.slice(-250).reverse().map((r, i) => `<li data-k="${esc(String(r.t) + r.texte.slice(0, 40))}" class="j-${esc(r.genre)}${r.echec ? " bad" : ""}${active && i === 0 ? " maintenant" : ""}">
      <span class="heure">${esc(hour(r.t))}</span><span class="j-ico" aria-hidden="true">${ICONS[r.genre] || "·"}</span>
      ${r.detail ? `<details><summary>${esc(r.texte)}${r.echec ? " — échec" : r.code_sortie ? " — code 1, normal (rien trouvé)" : ""}</summary><code>${esc(r.detail)}</code></details>` : `<span>${esc(r.texte)}${r.echec ? " — échec" : r.code_sortie ? " — code 1, normal (rien trouvé)" : ""}</span>`}</li>`).join("");
  const u = used || {};
  const usedLine = [u.skills && u.skills.length ? `<b>Skills</b> ${u.skills.map(esc).join(", ")}` : "",
    u.mcp && u.mcp.length ? `<b>Connecteurs</b> ${u.mcp.map(esc).join(", ")}` : "",
    u.outils && Object.keys(u.outils).length ? `<b>Outils</b> ${Object.entries(u.outils).sort((a, b) => b[1] - a[1]).map(([k, n]) => `${esc(k)} ×${n}`).join(", ")}` : ""].filter(Boolean).join(" · ");
  return `${usedLine ? `<p class="j-utilises">${usedLine}</p>` : ""}<div class="j-filtres" role="tablist">${JOURNAL_KINDS.map(([k, n]) => `<button class="puce${k === journalFilter ? " sel" : ""}" data-jf="${k}">${n}</button>`).join("")}</div>
    <ol class="journal-direct">${items || `<li class="discret">${active ? "Il lit le projet et prépare son travail…" : "Rien de noté."}</li>`}</ol>`;
}
function wireJournal(el) {
  el.querySelectorAll("[data-jf]").forEach((b) => (b.onclick = (ev) => { ev.preventDefault(); journalFilter = b.dataset.jf; taskActivity(selection, liveActive); }));
}
let gitTimer = null;
function trackGit() { clearTimeout(gitTimer); gitTimer = setTimeout(() => { if (view === "projets" && currentBlock === "branches") { gitDetail(); gitLine(currentProject); } }, 2500); }

/* --- Skills and documents: a single search, a single viewer */
let docs = [];
const isSkill = (g) => /skill/i.test(g);
function docEntries(groups, activeFilter) {
  const f = (activeFilter || "").toLowerCase();
  return groups.map((g) => {
    const taskFiles = g.fichiers.filter((x) => !f || (x.titre + " " + x.chemin).toLowerCase().includes(f));
    if (!taskFiles.length) return "";
    let subdir = null;
    const items = taskFiles.map((x) => (x.sous_groupe && x.sous_groupe !== subdir ? `<div class="sous">${esc((subdir = x.sous_groupe))}</div>` : "")
      + `<div class="doc" data-c="${esc(x.chemin)}" tabindex="0">${esc(x.titre)}<small>${esc(x.chemin)}</small></div>`).join("");
    return `<details class="pli" ${f ? "open" : ""}><summary>${esc(g.groupe)} · ${taskFiles.length}</summary>${items}</details>`;
  }).join("") || '<p class="vide">Rien ne correspond.</p>';
}
async function gDocs() {
  docs = await api("/api/documents");
  const groups = [...docs.filter((g) => isSkill(g.groupe)), ...docs.filter((g) => !isSkill(g.groupe))];
  GB("docs", `<p class="discret aide-g">Toutes les IA reçoivent les mêmes skills, quelle que soit l'IA de l'agent (tenues à jour seules, au lancement et avant chaque tâche si une skill a changé). <button class="lien" id="g-sync">Vérifier maintenant</button> · <button class="lien" id="g-importer" title="Copie dans le studio les skills et instructions déjà présents sur ton PC (dossiers de tes outils d'IA) ; rien n'est écrasé, tes originaux ne sont pas touchés">Reprendre mes skills du PC</button> <span id="g-sync-msg" class="discret"></span></p>
    <p class="discret aide-g">Une seule liste : les skills du studio. Les outils d'IA qui ont leur propre dossier de skills en reçoivent une copie à jour, nommée <code>studio-nom</code> ; les autres IA les reçoivent avec chaque tâche.</p>
    <div class="actions dossiers-g">${[["projects", "Projets"], ["topics", "Sujets"], ["tasks", "Tâches"], ["Skills", "Skills"], ["rules", "Règles"], ["backups", "Sauvegardes"]].map(([c, t]) => `<button class="btn discret" data-ouvrir-dossier="${c}" title="Ouvrir le dossier ${t} dans l'Explorateur">${t}</button>`).join("")}</div>
    <p class="discret aide-g">Ici : lire et modifier les fichiers. Ajouter ou retirer des skills : <button class="lien" id="g-vers-ext">Extensions</button>.</p>
    <input class="recherche" id="g-filtre" placeholder="Chercher un skill ou un document…"><div id="g-liste" class="defile-g court">${docEntries(groups, "")}</div>`);
  $("#g-vers-ext").onclick = () => { customTab = "skill"; showView("perso"); };
  $$("[data-ouvrir-dossier]").forEach((b) => (b.onclick = () => openPath(b.dataset.ouvrirDossier)));
  const bindHandlers = () => $$("#g-liste .doc").forEach((d) => (d.onclick = d.onkeydown = async (ev) => {
    if (ev.type === "keydown" && ev.key !== "Enter") return;
    const r = await api(`/api/document?chemin=${encodeURIComponent(d.dataset.c)}`);
    $$("#g-liste .doc.sel").forEach((x) => x.classList.remove("sel")); d.classList.add("sel");
    $("#g-lecteur").innerHTML = `<div class="actions" style="margin:0 0 6px;justify-content:space-between"><small>${esc(d.dataset.c)}</small><span><button class="btn" id="g-mod">Modifier</button> <button class="btn discret" id="g-fermer">Fermer</button></span></div>
      ${/\.md$/.test(d.dataset.c) ? md(r.texte) : `<pre>${esc(r.texte)}</pre>`}`;
    $("#g-mod").onclick = () => openPath(d.dataset.c);
    $("#g-fermer").onclick = () => { d.classList.remove("sel"); $("#g-lecteur").innerHTML = '<p class="vide">Clique un skill ou un document pour le lire ici.</p>'; };
  }));
  $("#g-filtre").oninput = () => { $("#g-liste").innerHTML = docEntries(groups, $("#g-filtre").value); bindHandlers(); };
  bindHandlers();
  api("/api/skills/conflits").then((l) => {
    if (!l.length || !$("#g-docs")) return;
    $("#g-docs").insertAdjacentHTML("afterbegin", `<div class="alerte" id="g-conflits"><b>Modifiés dans tes dossiers, hors du studio</b>${l.map((x) =>
      `<div class="reglage"><span>${x.genre === "skill" ? "Skill" : "Instructions"} <b>${esc(x.nom)}</b>${x.deux_cotes ? " · modifiée aussi dans le studio" : ""}<br><small class="discret">${esc(x.origine)}</small></span><span><button class="btn discret petit" data-conflit="${esc(x.id)}" data-choix="original">Mettre à jour dans le studio</button><button class="btn discret petit" data-conflit="${esc(x.id)}" data-choix="studio">Garder la version du studio</button></span></div>`).join("")}</div>`);
    $$("#g-conflits [data-conflit]").forEach((b) => (b.onclick = async () => {
      try { infoBubble((await api("/api/skills/conflit", { nom: b.dataset.conflit, choix: b.dataset.choix })).message); gDocs(); } catch (e) { alert(e.message); }
    }));
  }).catch(() => {});
  $("#g-importer").onclick = async () => {
    $("#g-sync-msg").textContent = "Copie…";
    try { const r = await api("/api/skills/importer", {});
      $("#g-sync-msg").textContent = r.skills.length || r.instructions.length ? `Copié : ${[...r.skills, ...r.instructions].join(", ")}.` : "Rien de nouveau à reprendre.";
      if (r.skills.length) gDocs(); }
    catch (e) { $("#g-sync-msg").textContent = e.message; }
  };
  $("#g-sync").onclick = async () => {
    $("#g-sync-msg").textContent = "Synchronisation…";
    try { const r = await api("/api/skills/synchroniser", {}); $("#g-sync-msg").textContent = r.rapport.join(" · ") === "Déjà à jour." ? "Tout est à jour." : r.rapport.join(" · "); }
    catch (e) { $("#g-sync-msg").textContent = e.message; }
  };
}

/* ================================================================ status, badge, notifications, closing */
let knownStatuses = null;
async function updateBadge() {
  try {
    const t = await api("/api/taches");
    const av = t.filter((x) => TO_APPROVE.includes(x.status));
    $("#nb-valider").hidden = !av.length; $("#nb-valider").textContent = av.length;
    $("#mob-badge").hidden = !av.length; $("#mob-badge").textContent = av.length;             // phone: Work tab
    if (knownStatuses) t.filter((x) => ACTIVE_STATUSES.includes(knownStatuses[x.id]) && !ACTIVE_STATUSES.includes(x.status)).forEach(taskFinished);
    knownStatuses = Object.fromEntries(t.map((x) => [x.id, x.status]));
  } catch (e) { /* optional */ }
}
/* End of a task: a small notification with a single « Voir » button (system notification if the window is hidden) */
function taskFinished(x) {
  const state = TO_APPROVE.includes(x.status) ? "à valider" : ["approuvee", "appliquee"].includes(x.status) ? "terminée" : (LABELS[x.status] || x.status);
  const text = `${targetName(x.target)} · « ${taskName(x)} » ${state}`;
  if (document.hidden && "Notification" in window && Notification.permission === "granted") {
    const n = new Notification("Tâche " + state, { body: text, icon: "/icon-192.png", tag: x.id });
    n.onclick = () => { window.focus(); openTaskNotification(x); n.close(); };
    return;
  }
  let box = $("#notifs-fin");
  if (!box) { box = document.createElement("div"); box.id = "notifs-fin"; box.setAttribute("role", "status"); box.setAttribute("aria-live", "polite"); document.body.appendChild(box); }
  const el = document.createElement("div");
  el.className = `notif-fin ${couleur(x.status)}`;
  el.innerHTML = `<span>${esc(text)}</span><button class="btn principal petit">Voir</button>`;
  el.querySelector("button").onclick = () => { el.remove(); openTaskNotification(x); };
  box.appendChild(el);
  setTimeout(() => el.classList.add("sortie"), 20000);
  setTimeout(() => el.remove(), 20600);
}
function openTaskNotification(x) {
  const c = (targets || []).find((k) => k.id === String(x.target).split(":").pop() && (!String(x.target).includes(":") || `${k.kind}:${k.id}` === x.target));
  selection = x.id; lastView = ""; currentBlock = "detail"; currentProject = c ? `${c.kind}:${c.id}` : currentProject; showView("projets");
  if (document.body.dataset.mob === "sup") mobileView("travail");
}
async function loadState() {
  try {
    const e = await api("/api/etat?leger=1");
    const ok = e.memoire.etat === "OK";
    $("#etat-memoire").hidden = ok;                    // nothing at the top when all is well; a warning otherwise
    if (!ok) $("#etat-memoire").textContent = `⚠ Mémoire : ${e.memoire.etat}`;
  } catch (err) { /* the studio is not responding: the presence check handles it */ }
}
/* Files tab: images, sheets, texts and other files created by the agents for this project */
let fileEntries = [], fileFilter = "", fileSearch = "", compareMode = false, compareChoice = [];
const FILE_LOCATIONS = { copie: ["en attente de fusion", "attente"], projet: ["dans le projet", ""], sujet: ["dans le sujet", ""], capture: ["capture", ""], "": ["introuvable", "attente"] };
const fileUrl = (f) => `/api/fichiers/voir?tid=${encodeURIComponent(f.tid)}&chemin=${encodeURIComponent(f.chemin)}`;
async function projectFiles() {
  const key = currentProject;
  try { fileEntries = await api(`/api/fichiers?cible=${encodeURIComponent(key)}`); } catch (e) { $("#p-fichiers").innerHTML = `<div class="alerte">${esc(e.message)}</div>`; return; }
  if (currentProject === key) renderFiles();
}
/* Results gallery: everything the agents produced for this project or topic, sorted like the topics' folders */
const RESULT_KINDS = [["images", "Images"], ["documents", "Documents"], ["3d", "3D"], ["sounds", "Sons"], ["videos", "Vidéos"], ["code", "Code"], ["other", "Autres"]];
const kindOf = (f) => f.type || (f.genre === "image" ? "images" : "other");
function renderFiles() {
  const q = fileSearch.toLowerCase();
  const l = fileEntries.filter((f) => (!fileFilter || (fileFilter === "ref" ? f.reference : kindOf(f) === fileFilter)) && (!q || `${f.nom} ${f.chemin} ${f.tache}`.toLowerCase().includes(q)));
  const n = (k) => fileEntries.filter((f) => kindOf(f) === k).length;
  const nRef = fileEntries.filter((f) => f.reference).length;
  const chips = [["", `Tout (${fileEntries.length})`], ...(nRef ? [["ref", `★ Références (${nRef})`]] : []),
    ...RESULT_KINDS.filter(([k]) => n(k) || k === fileFilter).map(([k, t]) => [k, `${t} (${n(k)})`])];
  const where = (f) => `<span class="ou-f ${FILE_LOCATIONS[f.ou][1]}">${FILE_LOCATIONS[f.ou][0]}</span>`;
  const imgs = l.filter((f) => kindOf(f) === "images");
  const media = (f) => kindOf(f) === "sounds" && f.ou ? `<audio controls preload="none" src="${fileUrl(f)}"></audio>`
    : kindOf(f) === "videos" && f.ou ? `<video controls preload="metadata" src="${fileUrl(f)}"></video>` : "";
  const section = ([k, t]) => {
    const items = l.filter((f) => kindOf(f) === k);
    return items.length ? `<p class="sous-titre-g sous-titre-f">${t} <small class="discret">${items.length}</small></p><ul class="liste-f${k === "videos" ? " videos-f" : ""}">${items.map((f) => `<li data-f="${fileEntries.indexOf(f)}" title="${esc(f.chemin)}"><b>${esc(f.nom)}</b><span class="discret">${esc(f.tache)}</span>${where(f)}${media(f)}</li>`).join("")}</ul>` : "";
  };
  const others = RESULT_KINDS.slice(1).map(section).join("");
  $("#p-fichiers").innerHTML = `<div class="filtres-f"><div class="puces" id="f-genre"></div>
      <input class="champ" id="f-cherche" placeholder="Chercher (nom, tâche…)" value="${esc(fileSearch)}">
      <button class="btn discret" id="f-ranger" title="Lance l'archiviste : il déplace et renomme les fichiers des agents dans les bons dossiers, sans rien supprimer ; tu valides">Ranger le projet</button>
      ${imgsTotal() >= 2 ? `<button class="btn${compareMode ? " principal" : " discret"}" id="f-comparer" title="Choisis deux images pour les comparer avec un curseur avant / après">${compareMode ? `Comparer : choisis ${2 - compareChoice.length} image${compareChoice.length ? "" : "s"}` : "Comparer"}</button>` : ""}</div>
    ${!l.length ? `<p class="vide">${fileEntries.length ? "Rien ne correspond." : "Aucun résultat pour l'instant : les images, documents, sons et autres fichiers créés par les agents s'afficheront ici."}</p>` : ""}
    ${imgs.length ? `<div class="grille-f">${imgs.map((f) => { const i = fileEntries.indexOf(f); return `<div class="carte-f${compareChoice.includes(i) ? " choisie" : ""}" data-f="${i}" role="button" tabindex="0" title="${esc(f.chemin)}">${f.ou && f.genre === "image" ? `<img src="${fileUrl(f)}" alt="${esc(f.nom)}" loading="lazy">` : `<span class="sans-apercu">${esc((f.nom.split(".").pop() || "").toUpperCase())}</span>`}<button class="etoile${f.reference ? " oui" : ""}" data-etoile="${i}" title="${f.reference ? "Retirer des références" : "Marquer comme référence : le Superviseur la donnera aux agents"}" aria-label="Référence">${f.reference ? "★" : "☆"}</button><span class="infos"><b>${esc(f.nom)}</b>${esc(f.tache)}<br>${where(f)}</span></div>`; }).join("")}</div>` : ""}
    ${others}`;
  chipList($("#f-genre"), chips, fileFilter, (v) => { fileFilter = v; renderFiles(); });
  $("#f-cherche").oninput = (e) => { fileSearch = e.target.value; const pos = e.target.selectionStart; renderFiles(); const c = $("#f-cherche"); c.focus(); c.setSelectionRange(pos, pos); };
  $$("#p-fichiers [data-f]").forEach((el) => {
    const openCard = () => {
      const i = +el.dataset.f;
      if (!compareMode) return showFile(fileEntries[i]);
      compareChoice = compareChoice.includes(i) ? compareChoice.filter((x) => x !== i) : [...compareChoice, i].slice(-2);
      if (compareChoice.length === 2) { compareImages(fileEntries[compareChoice[0]], fileEntries[compareChoice[1]]); compareMode = false; compareChoice = []; }
      renderFiles();
    };
    el.onclick = (e) => { if (!e.target.closest("[data-etoile], audio, video")) openCard(); };
    el.onkeydown = (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); openCard(); } };
  });
  $$("#p-fichiers [data-etoile]").forEach((b) => (b.onclick = async (e) => {
    e.stopPropagation();
    const f = fileEntries[+b.dataset.etoile];
    try { await api("/api/fichiers/reference", { cible: currentProject, tid: f.tid, chemin: f.chemin, oui: !f.reference }); f.reference = !f.reference; renderFiles(); infoBubble(f.reference ? "Référence : le Superviseur la donnera aux agents" : "Retirée des références"); }
    catch (er) { infoBubble(er.message); }
  }));
  $("#f-ranger").onclick = async () => {
    if (!confirm("Lancer le rangement du projet ? L'archiviste déplace et renomme les fichiers produits par les agents (rien n'est supprimé), puis tu valides.")) return;
    try {
      const r = await api("/api/taches", { cible: currentProject, role: "archiviste", titre: "Ranger les fichiers du projet", demande: TIDY_REQUEST });
      selection = r.tid; lastView = ""; infoBubble("Rangement lancé"); setTimeout(() => openProject(currentProject), 400);
    } catch (e) { infoBubble(e.message); }
  };
  if ($("#f-comparer")) $("#f-comparer").onclick = () => { compareMode = !compareMode; compareChoice = []; renderFiles(); };
}
const TIDY_REQUEST = `Objectif : ranger les fichiers produits par les agents dans ce projet, pour que l'utilisateur retrouve tout facilement.
Où : tout le projet, en priorité les fichiers à la racine et dans les dossiers fourre-tout (captures/, references/, sources/, outputs/…).
Faire : déplacer chaque livrable dans le dossier prévu par le projet (voir CLAUDE.md / AGENTS.md ; images et planches dans Docs/art/<sujet>/, documents dans Docs/<sujet>/), renommer les noms illisibles (identifiant de tâche, longue suite de chiffres) en noms clairs, mettre à jour les liens Markdown.
Ne pas faire : ne rien supprimer (liste les copies inutiles dans ton compte rendu), ne pas toucher au code ni aux assets du moteur.
Compte rendu : un tableau avant → après, puis la liste des copies que l'utilisateur peut retirer.`;
const imgsTotal = () => fileEntries.filter((f) => f.genre === "image" && f.ou).length;
function compareImages(a, b) {                            // before / after slider: drag to reveal the second image
  const v = $("#visionneuse"), c = $("#v-contenu");
  $("#v-titre").textContent = `${a.nom}  ⟷  ${b.nom}`;
  c.innerHTML = `<div class="comparer"><img src="${fileUrl(a)}" alt="${esc(a.nom)}"><div class="haut" style="clip-path:inset(0 0 0 50%)"><img src="${fileUrl(b)}" alt="${esc(b.nom)}"></div>
    <div class="trait" style="left:50%"></div><span class="nom-g">${esc(a.nom)}</span><span class="nom-d">${esc(b.nom)}</span>
    <input type="range" min="0" max="100" value="50" aria-label="Position du curseur de comparaison"></div>`;
  const r = c.querySelector("input"), top = c.querySelector(".haut"), stroke = c.querySelector(".trait");
  r.oninput = () => { top.style.clipPath = `inset(0 0 0 ${r.value}%)`; stroke.style.left = r.value + "%"; };
  ["v-ouvrir", "v-dossier", "v-tache"].forEach((id) => ($("#" + id).hidden = true));
  v.hidden = false; r.focus();
}
async function showFile(f) {
  ["v-ouvrir", "v-dossier", "v-tache"].forEach((id) => ($("#" + id).hidden = false));
  const v = $("#visionneuse"), c = $("#v-contenu");
  $("#v-titre").textContent = `${f.nom} · ${f.tache}`;
  c.innerHTML = '<p class="vide">…</p>'; v.hidden = false; $("#v-fermer").focus();
  if (f.genre === "image") c.innerHTML = `<img src="${fileUrl(f)}" alt="${esc(f.nom)}">`;
  else if (["sounds", "videos"].includes(kindOf(f))) c.innerHTML = kindOf(f) === "sounds" ? `<audio controls autoplay src="${fileUrl(f)}"></audio>` : `<video controls autoplay src="${fileUrl(f)}"></video>`;
  else {
    try {
      const r = await fetch(fileUrl(f));
      if (!r.ok) throw new Error((await r.json().catch(() => ({}))).erreur || r.status);
      const t = await r.text();
      c.innerHTML = `<div class="texte-v">${/\.md$/i.test(f.nom) ? md(t) : `<pre>${esc(t)}</pre>`}</div>`;
    } catch (e) { c.innerHTML = `<p class="vide">${esc(e.message)}</p>`; }
  }
  const openFile = (folder) => api("/api/fichiers/ouvrir", { tid: f.tid, chemin: f.chemin, dossier: folder }).catch((e) => infoBubble(e.message));
  $("#v-ouvrir").onclick = () => openFile(false);
  $("#v-dossier").onclick = () => openFile(true);
  $("#v-tache").onclick = () => { v.hidden = true; selection = f.tid; lastView = ""; show(); showDetail(); };
}
$("#v-fermer").onclick = () => ($("#visionneuse").hidden = true);
document.addEventListener("keydown", (e) => { if (e.key === "Escape" && !$("#visionneuse").hidden) $("#visionneuse").hidden = true; });

/* Phone: bottom bar to switch from the work block to the Supervisor (the choice is kept) */
function mobileView(v) {
  document.body.dataset.mob = v;
  $$("#barre-mobile button").forEach((b) => b.classList.toggle("actif", b.dataset.mob === v));
  try { localStorage.setItem("vue-mobile", v); } catch {}
  if (v === "sup") { const f = $("#fil"); if (f) f.scrollTop = f.scrollHeight; }
}
$("#barre-mobile").onclick = (e) => { const b = e.target.closest("button[data-mob]"); if (b) mobileView(b.dataset.mob); };
mobileView((() => { try { return localStorage.getItem("vue-mobile") || "travail"; } catch { return "travail"; } })());
function openTaskNotif(tid) {
  if (!tid) return;
  const link = document.createElement("button"); link.dataset.voir = tid; link.hidden = true;
  document.body.appendChild(link); link.click(); link.remove();
}
if ("serviceWorker" in navigator) navigator.serviceWorker.addEventListener("message", (e) => e.data && openTaskNotif(e.data.ouvrirTache));
{ const t = new URLSearchParams(location.search).get("tache"); if (t) { history.replaceState(null, "", "/"); setTimeout(() => openTaskNotif(t), 1200); } }
if ("serviceWorker" in navigator && location.protocol === "https:") navigator.serviceWorker.register("/sw.js").catch(() => {});

/* Window size: recorded on every change, restored at next launch (full screen, maximized or exact size) */
let windowTimer = 0;
function recordWindow() {
  clearTimeout(windowTimer);
  windowTimer = setTimeout(() => {
    const full = !!document.fullscreenElement || (outerWidth >= screen.width && outerHeight >= screen.height);
    const maximized = !full && outerWidth >= screen.availWidth - 2 && outerHeight >= screen.availHeight - 2;
    fetch("/api/fenetre", { method: "POST", keepalive: true, headers: { "Content-Type": "application/json", "X-Studio": "1" },
      body: JSON.stringify({ plein_ecran: full, agrandie: maximized, x: screenX, y: screenY, l: outerWidth, h: outerHeight }) }).catch(() => {});
  }, 700);
}
addEventListener("resize", recordWindow);          // maximize, full screen, resize: a single request per change

/* Presence and reconnection: if the PC stops responding (studio closed, network down), a banner says so and the page
   reloads itself as soon as it is back. On returning to the app (phone, tab), everything refreshes immediately. */
let offline = false, sessionInfo = {};
async function presence() {
  try {
    await api("/api/presence", {});
    if (offline) location.reload();
  } catch (e) {
    if (e.code === 403) {
      if (sessionInfo.distant) { location.reload(); return; }       // phone revoked: code page
      document.body.innerHTML = '<div class="ferme"><h1>Game over</h1><p class="vide">Session terminée. Relance le raccourci du bureau.</p></div>';
      return;
    }
    if (!offline && (e instanceof TypeError || e.code >= 502)) {
      offline = true;
      const b = document.createElement("div");
      b.id = "hors-ligne"; b.setAttribute("role", "status");
      b.textContent = sessionInfo.distant ? "Studio fermé sur le PC ? Reconnexion…" : "Le studio ne répond pas. Reconnexion…";
      document.body.appendChild(b);
    }
  }
}
document.addEventListener("visibilitychange", () => {
  if (document.visibilityState !== "visible") return;
  presence(); loadState(); updateJobs();
  if (view === "projets") { loadConversation(false); if (!currentProject) workSummary(); }
});
api("/api/session").then((s) => {
  sessionInfo = s || {};
  if (sessionInfo.nom && sessionInfo.nom !== userName) { userName = sessionInfo.nom; loadConversation(false); }
  api("/api/ia").then((d) => { const before = aiState; aiState = d; if (!before || !!before.actif !== !!d.actif) loadConversation(false); }).catch(() => {});
  if (sessionInfo.distant) { $("#fermer-studio").style.display = "none"; document.body.classList.add("distant"); }   // from the phone, it could not be reopened
}).catch(() => {});
$("#fermer-studio").onclick = async () => {
  try { await api("/api/arreter", {}); }
  catch (e) {
    if (e.code !== 409 || !confirm("Un travail tourne encore. Fermer dès qu'il sera terminé ?")) return;
    await api("/api/arreter", { apres_travaux: true });
  }
  document.body.innerHTML = '<div class="ferme"><h1>See you next mission</h1><p class="vide">Tu peux fermer cette fenêtre.</p></div>';
  setTimeout(() => window.close(), 800);
};
document.addEventListener("click", () => { if ("Notification" in window && Notification.permission === "default") Notification.requestPermission(); }, { once: true });

api("/api/cibles").then((c) => { targets = c; updateBadge(); });
document.body.classList.add("fixe");
function listChoice(el, items, active, cb) {
  el.innerHTML = items.map(([v, t]) => `<option value="${esc(v)}"${v === active ? " selected" : ""}>${esc(t)}</option>`).join("");
  el.onchange = () => cb(el.value);
}
listChoice($("#sup-modele"), SUPERVISOR_MODELS, supervisorModel, (v) => keepSup("sup-modele", (supervisorModel = v)));
listChoice($("#sup-effort"), EFFORTS, supervisorEffort, (v) => keepSup("sup-effort", (supervisorEffort = v)));
const PROFILES = [["rapide", "Rapide"], ["normal", "Normal"], ["performance", "Performance"]];
const PROFILE_HELP = {
  rapide: "Plus vite et moins cher : modèle plus léger quand l'IA en propose, effort un cran plus bas, pas de relecture par une 2e IA.",
  normal: "Le réglage optimisé de chaque agent (recommandé).",
  performance: "Plus de raisonnement : le modèle le plus puissant de chaque IA (hors rédaction), effort un cran plus haut. Plus lent, consomme plus.",
};
function renderProjectProfile(key, clean, fallback) {          // per-project mode (Rapide / Normal / Performance)
  const current = clean || fallback || "normal";
  $("#p-profil").innerHTML = PROFILES.map(([v, t]) => `<button data-p="${v}" class="${v === current ? "sel" : ""}" aria-pressed="${v === current}">${t}</button>`).join("");
  $("#p-profil-aide").textContent = PROFILE_HELP[current] || "";
  if ($("#p-entete-mode")) $("#p-entete-mode").value = current;               // header selector kept in sync
  $$("#p-profil button").forEach((b) => (b.onclick = async () => {
    try { const r = await api("/api/profil", { cible: key, profil: b.dataset.p }); renderProjectProfile(key, r.profil, fallback); } catch (e) { alert(e.message); }
  }));
}
api("/api/choix").then((c) => {                          // offered models: [choix] modeles_claude (studio.config.toml)
  AI_EFFORTS = c.efforts_ia || {};
  loadAiRoles();
  MODELS = [["", "Auto"], ...c.modeles.map((m) => [m, modelName(m)])];
  SUPERVISOR_MODELS = [["", "Auto"], ...[...c.modeles].reverse().map((m) => [m, modelName(m)])];
  CODEX_MODELS = [["", "Auto"], ...(c.modeles_codex || []).map((m) => [m, m])];
  supervisorChoices();
}).catch(() => {});
/* Supervisor header: its AI, then the models and effort levels of THAT AI. Refreshed whenever the AI changes. */
async function supervisorChoices(d) {
  try { d = d || await api("/api/ia"); } catch { return; }
  if (d.distant) { $("#sup-ia").closest("label").hidden = true; }
  const items = [];
  if (d.claude) items.push(["claude-code", "Claude Code (abonnement)"]);
  if (d.codex) items.push(["codex", "Codex (abonnement ChatGPT)"]);
  d.connexions.filter((c) => c.fournisseur !== "elevenlabs").forEach((c) => items.push([c.id, shortAiName(c.nom)]));
  const current = d.actif === "api" ? d.superviseur || (d.connexions[0] || {}).id || "" : d.actif || "";
  listChoice($("#sup-ia"), items.length ? items : [["", "Aucune IA"]], current, async (v) => {
    try { await api("/api/ia/choisir", { superviseur: v }); } catch (e) { infoBubble(e.message); }
    supervisorChoices(); if (currentBlock === "sup-reglages") gAI().catch(() => {});
  });
  $("#sup-ia").closest("label").hidden = items.length < 2 && !!items.length;
  const cx = d.connexions.find((x) => x.id === current);
  const fam = current === "codex" ? "codex" : current === "claude-code" || !cx ? "claude-code" : cx.fournisseur;
  supFamily = fam;
  const model = $("#sup-modele");
  model.onfocus = null;
  if (fam === "claude-code") {
    listChoice(model, SUPERVISOR_MODELS, supervisorModel, (v) => keepSup("sup-modele", (supervisorModel = v)));
    model.closest("label").hidden = false;
  } else if (fam === "codex") {                          // Codex: « Auto » = its default model, or one of its own list
    if (!CODEX_MODELS.some(([v]) => v === codexModel)) codexModel = "";
    listChoice(model, CODEX_MODELS, codexModel, (v) => keepSup("sup-modele-codex", (codexModel = v)));
    model.closest("label").hidden = false;
  } else if (cx) {                                       // connected AI: its models, loaded on open
    model.innerHTML = `<option>${esc(cx.modele || "?")}</option>`; model.dataset.charge = "";
    model.onfocus = async () => {
      if (model.dataset.charge) return; model.dataset.charge = "1";
      try { const r = await api("/api/ia/modeles", { id: cx.id }); model.innerHTML = r.modeles.map((m) => `<option${m === cx.modele ? " selected" : ""}>${esc(m)}</option>`).join(""); } catch { /* list unavailable */ }
    };
    model.onchange = async () => { try { await api("/api/ia/choisir", { id: cx.id, modele: model.value }); infoBubble(`Modèle : ${model.value}`); } catch (e) { infoBubble(e.message); } };
    model.closest("label").hidden = false;
  } else model.closest("label").hidden = true;          // the CLI picks its own model
  const effs = effortsFor(fam);
  if (!effs.some(([v]) => v === supervisorEffort)) supervisorEffort = "";
  listChoice($("#sup-effort"), effs, supervisorEffort, (v) => keepSup("sup-effort", (supervisorEffort = v)));
  $("#sup-effort").closest("label").hidden = effs.length < 2;
}
/* Refreshes: nothing heavy while the window is hidden (minimized, other tab); everything updates as soon as
   it comes back. Only the badge and « à valider » notifications continue, more slowly. */
const each = (ms, f) => setInterval(() => { if (!document.hidden) f(); }, ms);
let tick = 0;
updateJobs(); updateAlerts();
setInterval(() => { if (!document.hidden && (activeJobs() || ++tick % 3 === 0)) updateJobs(); }, 4000);   // 4 s during work, otherwise 12 s
each(60000, updateAlerts);
each(60000, () => { if (view === "gestion") homeLimits(); });
each(8000, () => { if (view === "projets") api("/api/projets").then((ps) => { projectList = ps; renderTabs(); renderTabsBlock(); }).catch(() => {}); });
openSupervisor();                                      // on open: always the Supervisor (afterwards, each page returns where you left it)
loadState(); presence();
function refresh() {
  if (view === "projets") loadConversation(false);
  if (view === "projets" && !currentProject) workSummary();
  if (view === "projets" && currentProject) { api(`/api/projets/${encodeURIComponent(currentProject)}`).then((p) => { taskLists(p.taches); projectTeam(p.equipe); }).catch(() => {}); if (selection) show(); }
  updateBadge();
}
let hiddenTicks = 0;
setInterval(() => { if (!document.hidden) refresh(); else if (++hiddenTicks % 4 === 0) updateBadge(); }, 4000);
document.addEventListener("visibilitychange", () => { if (!document.hidden) { refresh(); updateJobs(); } });

/* PC resources in the header: mostly useful with local models (video memory used by Ollama). */
async function updateSystem() {
  if (sessionInfo.distant) return;                         // phone: the PC is what matters, not shown here
  let s;
  try { s = await api("/api/systeme"); } catch { return; }
  const el = $("#systeme");
  const gauge = (name, pct, text, title) => text == null ? "" : `<span class="m${pct >= 90 ? " max" : pct >= 75 ? " haut" : ""}" title="${esc(title)}"><b>${name}</b>${pct == null ? "" : `<span class="barre"><i style="width:${Math.min(100, pct)}%"></i></span>`}<span class="v">${text}</span></span>`;
  const r = s.ram || {}, g = s.gpu || {};
  const vramPct = g.vram_total_go ? 100 * g.vram_go / g.vram_total_go : null;
  const ai = (s.ollama || []).map((m) => `${m.nom} (${m.vram_go} Go)`).join(", ");
  el.innerHTML = gauge("CPU", s.cpu ?? 0, s.cpu == null ? "…" : `${Math.round(s.cpu)} %`, `Processeur : ${s.coeurs || "?"} cœurs`)
    + gauge("RAM", r.total_go ? 100 * r.utilise_go / r.total_go : null, r.total_go ? `${r.utilise_go}/${Math.round(r.total_go)} Go` : null, "Mémoire vive utilisée")
    + gauge("GPU", g.util ?? null, g.util == null ? null : `${Math.round(g.util)} %`, `${g.nom || "Carte graphique"}${ai ? " · IA locale chargée : " + ai : ""}`)
    + gauge("VRAM", vramPct, g.vram_go == null ? null : g.vram_total_go ? `${g.vram_go}/${Math.round(g.vram_total_go)} Go` : `${g.vram_go} Go`,
      `Mémoire de la carte graphique${ai ? " · IA locale : " + ai : ""}`);
  el.hidden = !el.innerHTML;
}
updateSystem();
each(3000, updateSystem);
setInterval(presence, 15000);
document.addEventListener("visibilitychange", () => { if (!document.hidden) presence(); });     // back to the window: at once
addEventListener("pagehide", () => {                       // window closed: the studio stops soon instead of after 10 min
  try { fetch("/api/presence", { method: "POST", keepalive: true, headers: { "Content-Type": "application/json", "X-Studio": "1" }, body: JSON.stringify({ fin: true }) }); } catch { /* best effort */ }
});
setInterval(() => $$(".chrono").forEach((el) => { el.textContent = formatDuration((+el.dataset.base || 0) + seconds(el.dataset.depuis)); }), 1000);

/* Window size: no zoom; only the blocks adapt (header height to fill the window). */
function adjustScale() {
  const h = document.querySelector("header");
  if (h) document.documentElement.style.setProperty("--entete", h.offsetHeight + "px");
}
window.addEventListener("resize", adjustScale);
adjustScale();
each(30000, loadState);

/* Light ripple on click on everything clickable (disabled if animations are reduced in Windows) */
const CLICKABLE = ".btn,.puce,.projet,.liste li,.doc,.agent-g,.lien-g";
document.addEventListener("pointerdown", (e) => {
  if (matchMedia("(prefers-reduced-motion: reduce)").matches) return;
  const el = e.target.closest(CLICKABLE);
  if (!el || el.disabled) return;
  const r = el.getBoundingClientRect(), o = document.createElement("span");
  o.className = "onde"; o.style.left = `${e.clientX - r.left}px`; o.style.top = `${e.clientY - r.top}px`;
  if (getComputedStyle(el).position === "static") el.style.position = "relative";
  if (getComputedStyle(el).overflow === "visible") el.style.overflow = "hidden";        // the ripple never overflows
  el.appendChild(o); o.addEventListener("animationend", () => o.remove());
  el.classList.remove("flash"); void el.offsetWidth; el.classList.add("flash");
  setTimeout(() => el.classList.remove("flash"), 500);
}, { passive: true });

/* ================================================================ EXTENSIONS
   Skills and connectors (MCP servers and PC software): Découvrir, Connecteurs, Skills, Installé. The domains
   (video games, 3D…) are the categories: no item appears twice on the same page. */
const ICONS = {
  jeu: '<path d="M6 11h4M8 9v4M15 12h.01M18 10h.01"/><rect x="2" y="6" width="20" height="12" rx="6"/>',
  "3d": '<path d="M12 2 3 7v10l9 5 9-5V7z"/><path d="m3 7 9 5 9-5M12 12v10"/>',
  design: '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-5-5L5 21"/>',
  code: '<path d="m16 18 6-6-6-6M8 6l-6 6 6 6"/>',
  web: '<circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a15 15 0 0 1 0 20M12 2a15 15 0 0 0 0 20"/>',
  documents: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M8 13h8M8 17h5"/>',
  audio: '<path d="M2 12h2M6 8v8M10 4v16M14 7v10M18 10v4M22 12h0"/>',
  "outils-ia": '<path d="M12 3v3M12 18v3M3 12h3M18 12h3M5.6 5.6l2.1 2.1M16.3 16.3l2.1 2.1M5.6 18.4l2.1-2.1M16.3 7.7l2.1-2.1"/><circle cx="12" cy="12" r="3"/>',
  donnees: '<path d="M3 3v18h18"/><path d="M7 15l4-4 3 3 5-6"/>',
  son: '<path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/>',
  video: '<rect x="2" y="5" width="15" height="14" rx="2"/><path d="m17 10 5-3v10l-5-3z"/>',
  ecriture: '<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/>',
  marketing: '<path d="m3 11 18-8v18L3 13z"/><path d="M11.6 16.8a3 3 0 1 1-5.8-1.6"/>',
  recherche: '<circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/>',
  perso: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
  pack: '<path d="m12 2 10 5-10 5L2 7z"/><path d="m2 12 10 5 10-5M2 17l10 5 10-5"/>',
};
const icon = (k) => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[k] || ICONS.code}</svg>`;
const TYPES_P = { skill: "Skill", mcp: "Serveur MCP", logiciel: "Logiciel" };
const TAG_P = { skill: "SKILL", mcp: "MCP", logiciel: "LOGICIEL" };
let library = null, libraryLoadedAt = 0, customTab = "decouvrir", customSearch = "", customCategory = "", customSort = "pertinence";
try { customTab = localStorage.getItem("onglet-extensions") || "decouvrir"; } catch (e) { /* storage unavailable */ }
async function showCustom(reload = true) {
  if (reload || !library) {
    try { library = await api("/api/bibliotheque"); libraryLoadedAt = Date.now();
      if (library.elements.some((e) => e.categorie === "perso")) library.categories = { ...library.categories, perso: "Déjà dans ton studio" }; } catch (e) { $("#perso-corps").innerHTML = `<div class="alerte">${esc(e.message)}</div>`; return; }
  }
  const sel = $("#perso-cat");
  if (!sel.dataset.rempli) { sel.innerHTML = `<option value="">Toutes les catégories</option>` + Object.entries(library.categories || {}).map(([k, v]) => `<option value="${esc(k)}">${esc(v)}</option>`).join(""); sel.dataset.rempli = "1"; }
  sel.value = customCategory;
  if (!["decouvrir", "connecteur", "skill", "installe"].includes(customTab)) customTab = "decouvrir";
  $$("#perso-onglets [data-o]").forEach((b) => b.setAttribute("aria-selected", String(b.dataset.o === customTab)));
  renderCustom();
}
const stripAccents = (t) => t.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
function customFilter() {
  const q = stripAccents(customSearch.trim());
  const tabOk = (e) => customTab === "connecteur" ? ["mcp", "logiciel"].includes(e.type) : customTab === "skill" ? e.type === "skill" : customTab === "installe" ? e.installe : true;
  let l = library.elements.filter((e) => e.type !== "pack" && tabOk(e) && (!customCategory || e.categorie === customCategory)        // domains: shown through the categories
    && (!q || stripAccents(`${e.nom} ${e.description} ${e.auteur}`).includes(q)));
  if (customSort === "nom") l = [...l].sort((a, b) => a.nom.localeCompare(b.nom, "fr"));
  if (customSort === "nouveau") l = [...l].sort((a, b) => (b.nouveau ? 1 : 0) - (a.nouveau ? 1 : 0));
  return l;
}
// The software's own logo when there is one (logos/<name>.svg, CC0), otherwise the category icon.
const extIcon = (e, cls) => `<span class="${cls}"${e.logo ? ` data-logo="${esc(e.logo)}"` : ""}>${icon(e.categorie)}</span>`;
function customCard(e, withCategory) {
  const attempt = e.installe && e.essai ? `<button data-essayer="${esc(e.id)}">Essayer</button>` : "";
  const action = e.auto ? `<button class="plus ok" data-fiche="${esc(e.id)}" title="Trouvé sur le PC : les agents le connaissent déjà" aria-label="Trouvé sur le PC">✓</button>`
    : e.installe ? `<button class="plus ok" data-fiche="${esc(e.id)}" title="Installé" aria-label="Installé">✓</button>` : `<button class="plus" data-installer-p="${esc(e.id)}" title="Ajouter" aria-label="Ajouter ${esc(e.nom)}">＋</button>`;
  const note = e.type === "mcp" && !e.installe && (e.manque || []).length ? ` · il faut ${esc(e.manque.join(", "))}`
    : e.type === "logiciel" ? (e.auto ? " · trouvé sur le PC" : e.installe ? "" : " · pas sur le PC") : "";
  const cat = withCategory && library.categories[e.categorie] ? ` · ${esc(library.categories[e.categorie])}` : "";
  return `<div class="carte-p${e.installe ? " installe" : ""}" data-fiche="${esc(e.id)}">${extIcon(e, "ico")}
    <span class="txt"><b>${esc(e.nom)}${e.verifie ? '<span class="verif" title="Source vérifiée">✔</span>' : ""}</b><span class="desc">${esc(e.description || "")}</span>
    <span class="meta"><span class="tag-p ${e.type}">${TAG_P[e.type] || ""}</span>par ${esc(e.auteur || "?")}${cat}${e.nouveau ? " · nouveau" : ""}${note}</span></span>
    <span class="acts">${attempt}${action}</span></div>`;
}
function renderCustom() {
  const l = customFilter(), requestBody = $("#perso-corps");
  const grid = (items, withCategory) => `<div class="perso-grille">${items.map((e) => customCard(e, withCategory)).join("")}</div>`;
  const section = (title, items, withCategory) => items.length ? `<div class="perso-section"><p class="titre">${esc(title)} <span class="n">${items.length}</span></p></div>${grid(items, withCategory)}` : "";
  if (!l.length) {
    requestBody.innerHTML = `<p class="vide">${customTab === "installe" && !customSearch && !customCategory ? "Rien d'installé pour l'instant : va dans « Découvrir »." : "Rien ne correspond."}</p>`;
    return;
  }
  if (customSearch || customCategory || customSort !== "pertinence") { requestBody.innerHTML = section(`${l.length > 1 ? "Résultats" : "Résultat"}`, l, true); placeLogos(requestBody); return; }
  if (customTab === "installe") {
    requestBody.innerHTML = section("Skills", l.filter((e) => e.type === "skill"), true) + section("Connecteurs", l.filter((e) => e.type !== "skill"), true);
    placeLogos(requestBody);
    return;
  }
  // Découvrir: first what serves your projects, then each category only once (no duplicate items)
  const pv = [];
  if (customTab === "decouvrir") {
    for (const id of library.pour_vous || []) { const e = l.find((x) => x.id === id); if (e && !e.installe && pv.length < 6) pv.push(e); }
  }
  const leftover = l.filter((e) => !pv.includes(e));
  const order = [...new Set([...pv.map((e) => e.categorie), ...Object.keys(library.categories)])];
  requestBody.innerHTML = section("Pour tes projets", pv, true)
    + order.map((k) => section(library.categories[k] || k, leftover.filter((e) => e.categorie === k))).join("")
    + section("Autres", leftover.filter((e) => !library.categories[e.categorie]));       // « Déjà dans ton studio » (core skills, your additions) last
  placeLogos(requestBody);
}
function elementSheet(id) {
  const e = library.elements.find((x) => x.id === id);
  if (!e || e.type === "pack") return;
  const el = $("#perso-fiche-corps");
  const vars = e.type === "mcp" && !e.installe ? (e.variables || []).map((v) => `<label>${esc(v.libelle)}${v.aide ? ` <small>(${esc(v.aide)})</small>` : ""}</label><input data-var="${esc(v.nom)}" type="${v.secret ? "password" : "text"}" autocomplete="off">`).join("") : "";
  const warn = e.type === "mcp" && (e.manque || []).length ? `<p class="warn">Il faut d'abord ${esc(e.manque.join(" et "))} sur le PC.</p>` : "";
  const mcpInfo = e.type === "mcp" ? `<p class="aide-g">Utilisé par tous les agents de tes tâches, quelle que soit leur IA (réglable par projet dans l'onglet Équipe). ${e.verifie ? "" : "Serveur de la communauté : vérifie qu'il te convient."} Le serveur se télécharge à sa première utilisation.</p>` : "";
  const logInfo = e.type === "logiciel" ? `<p class="aide-g">${e.auto ? "Trouvé sur ce PC : les agents le connaissent déjà, rien à faire." : e.installe ? "Déclaré aux agents." : e.trouve ? "Trouvé sur ce PC : un clic pour le déclarer aux agents." : `Pas trouvé sur ce PC. Le studio n'installe pas de logiciel : <a href="${esc(e.site)}" target="_blank" rel="noopener">site officiel</a>${e.winget ? ` ou dans PowerShell : <code>winget install --id ${esc(e.winget)} -e</code>` : ""}.`}</p>` : "";
  const path = e.type === "logiciel" && !e.installe && !e.trouve ? `<label>Chemin complet du programme, une fois installé</label><input data-var="chemin" placeholder="C:\\…\\programme.exe">` : "";
  const buttons = [`<button class="btn discret" data-fermer-fiche="1">Fermer</button>`];
  if (e.installe && e.type === "skill") buttons.unshift(`<a class="btn discret" href="/api/bibliotheque/exporter?id=${encodeURIComponent(e.id)}" download>Exporter (.zip)</a>`);
  if (e.installe && !e.socle && !e.auto) buttons.unshift(`<button class="btn discret danger" data-retirer-p="${esc(e.id)}" data-type="${esc(e.type)}">Retirer</button>`);
  if (e.installe && e.essai) buttons.push(`<button class="btn" data-essayer="${esc(e.id)}">Essayer</button>`);
  if (!e.installe) buttons.push(`<button class="btn principal" data-installer-p="${esc(e.id)}" data-depuis-fiche="1">Ajouter</button>`);
  el.innerHTML = `<div style="display:flex;gap:14px;align-items:center">${extIcon(e, "ico-f")}
      <div><h2>${esc(e.nom)}</h2><div class="meta"><span class="tag-p ${e.type}">${TAG_P[e.type]}</span>${esc(library.categories[e.categorie] || "")} · par ${esc(e.auteur || "?")}${e.verifie ? " · source vérifiée" : ""}${e.licence ? " · " + esc(e.licence) : ""}${e.taille ? ` · ${Math.max(1, Math.round(e.taille / 1024))} Ko` : ""}</div></div></div>
    <p>${esc(e.description || "")}</p>${e.essai ? `<p class="aide-g">Exemple : « ${esc(e.essai)} »</p>` : ""}${mcpInfo}${logInfo}${warn}${vars}${path}
    <p class="warn" id="fiche-msg"></p><div class="bas">${buttons.join("")}</div>`;
  placeLogos(el);
  $("#perso-fiche").hidden = false;
}
async function installCustom(id, fromSheet) {
  const e = library.elements.find((x) => x.id === id);
  if (!e) return;
  if (!fromSheet && ((e.type === "mcp" && (e.variables || []).length) || e.type === "logiciel" && !e.trouve)) return elementSheet(id);
  const valueMap = {};
  $$("#perso-fiche-corps [data-var]").forEach((i) => (valueMap[i.dataset.var] = i.value));
  if (e.type === "mcp" && !confirm(`Ajouter « ${e.nom} » pour tes agents ?\n${e.verifie ? "" : "Serveur de la communauté (non officiel).\n"}Son paquet se téléchargera à la première utilisation.`)) return;
  try {
    const r = await api("/api/bibliotheque/installer", { id, valeurs: valueMap });
    infoBubble(r.message || "Ajouté.");
    $("#perso-fiche").hidden = true;
    shortcutsCache = null;
    showCustom();
  } catch (err) { if (!$("#perso-fiche").hidden && $("#fiche-msg")) $("#fiche-msg").textContent = err.message; else { elementSheet(id); setTimeout(() => $("#fiche-msg") && ($("#fiche-msg").textContent = err.message), 50); } }
}
function tryCustom(id) {
  const e = library.elements.find((x) => x.id === id);
  if (!e) return;
  $("#perso-fiche").hidden = true;
  showView("projets");
  openSupervisor();
  if (document.body.dataset.mob) mobileView("sup");
  setTimeout(() => { const t = $("#message"); t.value = `${e.type === "skill" ? `Avec la skill « ${e.nom} » : ` : e.type === "mcp" ? `Avec ${e.nom} : ` : ""}${e.essai || ""}`; adjustInputField(); t.focus(); }, 400);
}
$("#perso-onglets").onclick = (ev) => { const b = ev.target.closest("[data-o]"); if (!b) return;
  customTab = b.dataset.o; try { localStorage.setItem("onglet-extensions", customTab); } catch (e) { /* same */ } showCustom(false); };
$("#perso-cherche").oninput = (ev) => { customSearch = ev.target.value; renderCustom(); };
$("#perso-cat").onchange = (ev) => { customCategory = ev.target.value; renderCustom(); };
$("#perso-tri").onchange = (ev) => { customSort = ev.target.value; renderCustom(); };
$("#perso-ajouter").onclick = (ev) => { ev.stopPropagation(); $("#menu-perso").hidden = !$("#menu-perso").hidden; };
document.addEventListener("click", (ev) => { if (!ev.target.closest(".perso-ajouter")) $("#menu-perso").hidden = true; });
$("#menu-perso").onclick = (ev) => {
  const a = (ev.target.closest("[data-a]") || {}).dataset; if (!a || !a.a) return;
  $("#menu-perso").hidden = true;
  if (a.a === "importer") $("#perso-zip").click();
  if (a.a === "url") skillFromUrl();
  if (a.a === "creer") { showView("projets"); openSupervisor(); if (document.body.dataset.mob) mobileView("sup");
    setTimeout(() => { const t = $("#message"); t.value = "Crée une skill pour [décris ce que la skill doit faire et quand l'utiliser]. Utilise la skill « Créer une skill » si elle est installée, et range-la dans Skills."; adjustInputField(); t.focus(); t.setSelectionRange(t.value.indexOf("["), t.value.indexOf("]") + 1); }, 400); }
  if (a.a === "mcp") mcpForm();
  if (a.a === "logiciel") {
    $("#perso-fiche-corps").innerHTML = `<h2>Ajouter un logiciel du PC</h2><div class="meta">Les agents sauront qu'il existe et où il est (Godot, Krita, ffmpeg…).</div>
      <label>Nom</label><input id="lg-nom" placeholder="Krita"><label>Chemin complet du programme</label><input id="lg-chemin" placeholder="C:\\Program Files\\Krita (x64)\\bin\\krita.exe">
      <p class="warn" id="fiche-msg"></p><div class="bas"><button class="btn discret" data-fermer-fiche="1">Annuler</button><button class="btn principal" id="lg-ok">Ajouter</button></div>`;
    $("#perso-fiche").hidden = false;
    $("#lg-ok").onclick = async () => {
      try { await api("/api/connecteurs/ajouter", { nom: $("#lg-nom").value, chemin: $("#lg-chemin").value }); infoBubble("Logiciel déclaré aux agents.");
        $("#perso-fiche").hidden = true; customTab = "installe"; showCustom(); }
      catch (e) { $("#fiche-msg").textContent = e.message; }
    };
  }
};
$("#perso-zip").onchange = async (ev) => {
  const f = ev.target.files[0]; ev.target.value = "";
  if (!f) return;
  const sendZip = async (ok) => { const r = await fetch(`/api/bibliotheque/importer?confirmer=${ok ? 1 : 0}`, { method: "POST", headers: { "X-Studio": "1", "Content-Type": "application/zip" }, body: f });
    const j = await r.json().catch(() => ({})); if (!r.ok) throw new Error(j.erreur || "import refusé"); return j; };
  try {
    const a = await sendZip(false);
    $("#perso-fiche-corps").innerHTML = `<h2>Importer « ${esc(a.id)} »</h2><div class="meta">${a.fichiers} fichier(s) · skill venue d'ailleurs : relis-la avant de l'ajouter</div>
      ${a.notes.length ? `<p class="sous-titre-g">À vérifier</p><ul>${a.notes.map((n) => `<li class="warn">${esc(n)}</li>`).join("")}</ul>` : '<p class="ok">Rien de suspect relevé.</p>'}
      <p class="sous-titre-g">Début du SKILL.md</p><pre>${esc(a.extrait)}</pre><p class="warn" id="fiche-msg"></p>
      <div class="bas"><button class="btn discret" data-fermer-fiche="1">Annuler</button><button class="btn principal" id="zip-ok">Ajouter cette skill</button></div>`;
    $("#perso-fiche").hidden = false;
    $("#zip-ok").onclick = async () => { try { const r = await sendZip(true); infoBubble(r.message); $("#perso-fiche").hidden = true; customTab = "installe"; showCustom(); } catch (e) { $("#fiche-msg").textContent = e.message; } };
  } catch (e) { alert(e.message); }
};
/* A skill from anywhere: GitHub folder or repository, SKILL.md page, raw file or .zip. Origin, licence, popularity and
   points to check are shown before anything is installed; GitHub content is pinned to the commit that was read. */
function skillFromUrl() {
  $("#perso-fiche-corps").innerHTML = `<h2>Ajouter une skill depuis une adresse</h2>
    <div class="meta">Dossier ou dépôt GitHub, page d'un SKILL.md, fichier brut ou archive .zip. Tu vois son origine et sa licence avant de l'ajouter.</div>
    <label>Adresse</label><input id="su-url" placeholder="https://github.com/editeur/depot/tree/main/skills/nom-de-la-skill" spellcheck="false">
    <p class="warn" id="fiche-msg"></p><div class="bas"><button class="btn discret" data-fermer-fiche="1">Annuler</button><button class="btn principal" id="su-voir">Voir la skill</button></div>`;
  $("#perso-fiche").hidden = false; $("#su-url").focus();
  const send = (ok) => api("/api/bibliotheque/importer-url", { url: $("#su-url") ? $("#su-url").value : skillFromUrl.url, confirmer: ok });
  const preview = async () => {
    skillFromUrl.url = $("#su-url").value; $("#su-voir").disabled = true; $("#fiche-msg").textContent = "Lecture…";
    try {
      const a = await send(false), o = a.origine || {};
      const facts = [o.editeur && `éditeur : ${esc(o.editeur)}`, o.licence ? `licence : ${esc(o.licence)}` : '<span class="warn">licence non indiquée</span>',
        o.etoiles != null && `${o.etoiles} étoiles`, o.maj && `mis à jour le ${esc(o.maj)}`, o.commit && `version figée ${esc(o.commit)}`,
        o.archive && '<span class="warn">dépôt archivé (plus maintenu)</span>'].filter(Boolean).join(" · ");
      $("#perso-fiche-corps").innerHTML = `<h2>Ajouter « ${esc(a.id)} »</h2><div class="meta">${esc(o.origine || "")} · ${a.fichiers} fichier(s)</div>
        <p>${facts}</p>
        ${a.notes.length ? `<p class="sous-titre-g">À vérifier</p><ul>${a.notes.map((n) => `<li class="warn">${esc(n)}</li>`).join("")}</ul>` : '<p class="ok">Rien de suspect relevé.</p>'}
        <p class="sous-titre-g">Début du SKILL.md</p><pre>${esc(a.extrait)}</pre><p class="warn" id="fiche-msg"></p>
        <div class="bas"><button class="btn discret" data-fermer-fiche="1">Annuler</button><button class="btn principal" id="su-ok">Ajouter cette skill</button></div>`;
      $("#su-ok").onclick = async () => { try { const r = await send(true); infoBubble(r.message); $("#perso-fiche").hidden = true; customTab = "installe"; showCustom(); } catch (e) { $("#fiche-msg").textContent = e.message; } };
    } catch (e) { $("#fiche-msg").textContent = e.message; $("#su-voir").disabled = false; }
  };
  $("#su-voir").onclick = preview;
  $("#su-url").onkeydown = (e) => { if (e.key === "Enter") preview(); };
}
function mcpForm() {
  $("#perso-fiche-corps").innerHTML = `<h2>Ajouter un serveur MCP</h2><div class="meta">Serveur pas relu par le studio : ajoute seulement ce que tu connais.</div>
    <label>Nom</label><input id="mp-nom" placeholder="mon-serveur">
    <label>Commande (serveur local)</label><input id="mp-cmd" placeholder="npx">
    <label>Arguments</label><input id="mp-args" placeholder="-y paquet-du-serveur@1.2.3">
    <label>…ou adresse (serveur distant)</label><input id="mp-url" placeholder="https://exemple.com/mcp">
    <p class="warn" id="fiche-msg"></p><div class="bas"><button class="btn discret" data-fermer-fiche="1">Annuler</button><button class="btn principal" id="mp-ok">Ajouter</button></div>`;
  $("#perso-fiche").hidden = false;
  $("#mp-ok").onclick = async () => {
    try { const r = await api("/api/bibliotheque/mcp-perso", { nom: $("#mp-nom").value, commande: $("#mp-cmd").value, arguments: $("#mp-args").value, url: $("#mp-url").value });
      infoBubble(r.message); $("#perso-fiche").hidden = true; customTab = "installe"; showCustom(); }
    catch (e) { $("#fiche-msg").textContent = e.message; }
  };
}
document.addEventListener("click", async (ev) => {
  if (view !== "perso" && $("#perso-fiche").hidden) return;
  const t = ev.target;
  const ess = t.closest("[data-essayer]"); if (ess) { ev.stopPropagation(); return tryCustom(ess.dataset.essayer); }
  const ins = t.closest("[data-installer-p]"); if (ins) { ev.stopPropagation(); ins.disabled = true; await installCustom(ins.dataset.installerP, !!ins.dataset.depuisFiche); ins.disabled = false; return; }
  const ret = t.closest("[data-retirer-p]");
  if (ret) { if (!confirm("Retirer ? Rien n'est effacé : une skill est rangée dans Archives.")) return;
    try { const r = await api("/api/bibliotheque/retirer", { id: ret.dataset.retirerP, type: ret.dataset.type }); infoBubble(r.message); $("#perso-fiche").hidden = true; showCustom(); } catch (e) { $("#fiche-msg").textContent = e.message; } return; }
  if (t.closest("[data-fermer-fiche]") || t.id === "perso-fiche") { $("#perso-fiche").hidden = true; return; }
  const f = t.closest("[data-fiche]"); if (f && !t.closest("#perso-fiche-corps")) return elementSheet(f.dataset.fiche);
});
document.addEventListener("keydown", (e) => { if (e.key === "Escape" && !$("#perso-fiche").hidden) $("#perso-fiche").hidden = true; });

/* --- First launch: connect an AI (cloud or on the PC), then GitHub; then a short guided tour.
   Nothing installs without a click: each install opens a visible window on the PC. */
const LOGOS = {};
async function logo(name) {
  if (!(name in LOGOS)) LOGOS[name] = fetch(`/logos/${name}.svg`).then((r) => (r.ok ? r.text() : "")).catch(() => "");
  return LOGOS[name];
}
async function placeLogos(rootDir) {
  for (const el of rootDir.querySelectorAll("[data-logo]")) {
    const svg = await logo(el.dataset.logo);
    if (svg) el.innerHTML = svg.replace(/<title>.*?<\/title>/, "");
  }
}
const CLOUD_WELCOME = [
  ["openrouter", "openrouter", "OpenRouter", "Tous les modèles, dont des gratuits"], ["openai", "openai", "OpenAI", "GPT"],
  ["anthropic", "anthropic", "Anthropic", "Claude par clé"], ["gemini", "gemini", "Google Gemini", "Gemini"],
  ["mistral", "mistral", "Mistral", "Européen"], ["deepseek", "deepseek", "DeepSeek", "Peu cher"],
  ["xai", "xai", "xAI", "Grok"], ["moonshot", "kimi", "Moonshot", "Kimi"], ["groq", "groq", "Groq", "Très rapide"],
];
let welcome = null, welcomeStep = "ia", welcomeTimer = null;
const checked = (ok) => (ok ? '<span class="ok coche-a">✓</span>' : "");
async function openWelcome(stage) {
  if (stage) welcomeStep = stage;
  let el = $("#bienvenue");
  if (!el) {
    el = document.createElement("div");
    el.id = "bienvenue"; el.setAttribute("role", "dialog"); el.setAttribute("aria-modal", "true"); el.setAttribute("aria-label", "Bienvenue");
    document.body.appendChild(el);
    el.addEventListener("click", welcomeClick);
  }
  el.hidden = false;
  if (!el.innerHTML) el.innerHTML = '<div class="boite-bienvenue carte"><p class="vide">…</p></div>';
  try { welcome = await api("/api/accueil"); } catch (e) { el.firstChild.innerHTML = `<p class="bad">${esc(e.message)}</p>`; return; }
  renderWelcome();
}
function renderWelcome() {
  const d = welcome, el = $("#bienvenue");
  if (!d || !el || el.hidden) return;
  const step = [["ia", "1. Une IA"], ["github", "2. GitHub"], ["fin", "3. C'est parti"]];
  const stages = `<div class="etapes-a">${step.map(([k, t]) => `<span class="${k === welcomeStep ? "actif" : ""}">${t}</span>`).join("")}</div>`;
  let requestBody = "";
  if (welcomeStep === "ia") {
    const subscription = (key, logoName, title, subdir, e) => `<div class="tuile-a${e.connecte ? " faite" : ""}"><span class="logo-a" data-logo="${logoName}"></span>
      <span class="txt-a"><b>${title}</b><small>${subdir}</small></span>${checked(e.connecte)}
      ${e.connecte ? "" : e.installe ? `<button class="btn principal petit" data-connexion-abo="${key}">Se connecter</button>`
        : `<button class="btn petit" data-installer-outil="${key}">Installer</button>`}</div>`;
    const already = new Set(d.connexions.map((c) => c.fournisseur));
    const o = d.ollama, advice = d.conseilles.filter((m) => m.tient !== "trop_gros");
    const ollamaConnected = already.has("ollama");
    let local;
    if (!o.installe) local = `<button class="btn" data-installer-outil="ollama">Installer Ollama</button> <a class="lien" href="${esc(o.lien)}" target="_blank" rel="noopener">ou depuis son site</a>`;
    else if (!o.ouvert) local = `<button class="btn" id="a-ollama-ouvrir">Ouvrir Ollama</button>`;
    else if (!advice.length) local = `<p class="aide-g">Ton PC est un peu juste pour une IA locale (${d.pc.ram_go || "?"} Go de mémoire). Prends plutôt une IA cloud : OpenRouter propose des modèles gratuits.</p>`;
    else local = `<p class="aide-g">Choisis un modèle${d.pc.vram_go ? ` (carte graphique : ${d.pc.vram_go} Go` : ` (mémoire : ${d.pc.ram_go || "?"} Go`}${d.pc.vram_go && d.pc.ram_go ? `, mémoire : ${d.pc.ram_go} Go)` : ")"} :</p>
      <div class="modeles-a">${advice.map((m) => { const inst = o.modeles.some((n) => n === m.nom || n.startsWith(m.nom + ":") || m.nom.startsWith(n));
        return `<div class="modele-a${m.conseille ? " conseille" : ""}"><span><b>${esc(m.titre)}</b>${m.conseille ? ' <span class="tag-a">conseillé</span>' : ""}<small>≈ ${m.memoire_go ?? "?"} Go · ${m.tient === "rapide" ? "rapide sur ta carte graphique" : m.tient === "possible" ? "possible, plus lent" : "à essayer"}${m.note ? " · " + esc(m.note) : ""}</small></span>
        <span class="act-a" data-progression="${esc(m.nom)}">${inst ? (ollamaConnected ? '<span class="ok">Prêt</span>' : `<button class="btn principal petit" data-utiliser-local="${esc(m.nom)}">Utiliser</button>`) : `<button class="btn petit" data-installer-local="${esc(m.nom)}">Installer</button>`}</span></div>`; }).join("")}</div>`;
    requestBody = `<h1>Bienvenue dans ton studio</h1><p class="sous-a">Connecte au moins une IA. Tu pourras en ajouter d'autres plus tard (Réglages ou Gestion › Modèles).</p>
      <p class="titre-a">Avec un abonnement</p><div class="grille-a">
        ${subscription("claude", "claude", "Claude", "Abonnement Pro ou Max", d.claude)}${subscription("codex", "openai", "ChatGPT", "Abonnement Plus ou Pro (Codex)", d.codex)}</div>
      <p class="titre-a">Avec une clé API (paiement à l'usage)</p><div class="grille-a">
        ${CLOUD_WELCOME.map(([f, l, t, s]) => `<button class="tuile-a bouton-a${already.has(f) ? " faite" : ""}" data-cle-cloud="${f}"><span class="logo-a" data-logo="${l}"></span><span class="txt-a"><b>${t}</b><small>${s}</small></span>${checked(already.has(f))}</button>`).join("")}
        <button class="tuile-a bouton-a" data-autre-ia="1"><span class="logo-a">＋</span><span class="txt-a"><b>Autre IA</b><small>Compatible OpenAI (adresse)</small></span></button></div>
      <p class="titre-a">Ou sur ton PC (gratuit, privé)</p><div class="tuile-a large${ollamaConnected ? " faite" : ""}"><span class="logo-a" data-logo="ollama"></span><span class="txt-a"><b>Ollama</b><small>${o.installe ? (o.ouvert ? "ouvert" : "installé, fermé") : "pas encore installé"}</small></span>${checked(ollamaConnected)}</div>
      <div class="local-a">${local}</div>
      <p class="warn" id="msg-accueil"></p>
      <div class="bas-a"><button class="btn discret" data-fermer-accueil="1">Plus tard</button><button class="btn discret" id="a-verifier">Vérifier</button>
        <button class="btn principal" data-etape-a="github"${d.pret ? "" : ' disabled title="Connecte d\'abord une IA"'}>Continuer</button></div>`;
  } else if (welcomeStep === "github") {
    const g = d.git;
    requestBody = `<h1>GitHub <small class="discret">(facultatif)</small></h1><p class="sous-a">Pour sauvegarder et partager tes projets en ligne. Tu peux passer cette étape.</p>
      <div class="grille-a">
        <div class="tuile-a${g.installe ? " faite" : ""}"><span class="logo-a" data-logo="git"></span><span class="txt-a"><b>Git</b><small>${g.installe ? "installé" : "suivi des versions de tes projets"}</small></span>${checked(g.installe)}
          ${g.installe ? "" : `<button class="btn petit" data-installer-outil="git">Installer</button>`}</div>
        <div class="tuile-a${g.github ? " faite" : ""}"><span class="logo-a" data-logo="github"></span><span class="txt-a"><b>GitHub</b><small>${g.github ? "connecté" : "ton compte (gratuit)"}</small></span>${checked(g.github)}
          ${g.github || !g.installe ? "" : `<button class="btn principal petit" id="a-github">Se connecter</button>`}</div></div>
      <p class="aide-g">Pas de compte ? <a href="https://github.com/signup" target="_blank" rel="noopener">Crée-le ici</a>, puis « Se connecter ».</p>
      <p class="warn" id="msg-accueil"></p>
      <div class="bas-a"><button class="btn discret" data-etape-a="ia">Retour</button><button class="btn discret" id="a-verifier">Vérifier</button><button class="btn principal" data-etape-a="fin">${g.github ? "Continuer" : "Passer"}</button></div>`;
  } else {
    requestBody = `<h1>C'est prêt</h1><p class="sous-a">Décris ce que tu veux au Superviseur, en une phrase : il propose une tâche, tu cliques « Lancer », ses agents travaillent, tu valides le résultat.</p>
      <div class="bas-a"><button class="btn discret" data-etape-a="github">Retour</button><button class="btn" data-finir-accueil="sans">Commencer</button><button class="btn principal" data-finir-accueil="visite">Visite guidée (1 min)</button></div>`;
  }
  el.innerHTML = `<div class="boite-bienvenue carte">${stages}${requestBody}</div>`;
  placeLogos(el);
  trackInstalls();
}
async function trackInstalls() {
  clearTimeout(welcomeTimer);
  if (welcomeStep !== "ia" || !welcome || !welcome.ollama.ouvert || $("#bienvenue")?.hidden) return;
  let loc;
  try { loc = await api("/api/modeles-locaux"); } catch { return; }
  let busy = false;
  for (const [name, e] of Object.entries(loc.modeles || {})) {
    const p = e.progression, place = $(`#bienvenue [data-progression="${CSS.escape(name)}"]`);
    if (!place || !p) continue;
    if (p.etat === "telechargement") { busy = true; place.innerHTML = `<span class="info">${p.pct} %</span>`; }
    else if (p.etat === "erreur") place.innerHTML = `<span class="bad" title="${esc(p.message)}">Échec</span> <button class="btn discret petit" data-installer-local="${esc(name)}">Réessayer</button>`;
    else if (p.etat === "fini") place.innerHTML = `<button class="btn principal petit" data-utiliser-local="${esc(name)}">Utiliser</button>`;
  }
  if (busy) welcomeTimer = setTimeout(trackInstalls, 2000);
}
async function welcomeClick(ev) {
  const t = ev.target, msg = (m, ok) => { const el = $("#msg-accueil"); if (el) { el.textContent = m || ""; el.className = ok ? "ok" : "warn"; } };
  const b = t.closest("button,[data-etape-a]");
  if (!b) return;
  try {
    if (b.dataset.etapeA) { welcomeStep = b.dataset.etapeA; return openWelcome(); }
    if (b.dataset.fermerAccueil) { $("#bienvenue").hidden = true; return; }
    if (b.id === "a-verifier") { b.disabled = true; msg("Vérification…", true); await openWelcome(); return; }
    if (b.dataset.cleCloud) return connectCloud(b.dataset.cleCloud, "", () => openWelcome());
    if (b.dataset.autreIa) { $("#bienvenue").hidden = true; return openAiSettings(); }
    if (b.dataset.connexionAbo) { b.disabled = true; const r = await api(b.dataset.connexionAbo === "claude" ? "/api/claude/connexion" : "/api/codex/connexion", {}); msg(r.info, true); return; }
    if (b.id === "a-ollama-ouvrir") { b.disabled = true; b.textContent = "Ouverture…"; await api("/api/modeles-locaux/demarrer", {}); return openWelcome(); }
    if (b.dataset.installerLocal) { b.disabled = true; await api("/api/modeles-locaux/installer", { nom: b.dataset.installerLocal }); return trackInstalls(); }
    if (b.dataset.utiliserLocal) { b.disabled = true; await api("/api/ia/ajouter", { fournisseur: "ollama", modele: b.dataset.utiliserLocal }); infoBubble("IA locale connectée."); return openWelcome(); }
    if (b.id === "a-github") { b.disabled = true; const r = await api("/api/accueil/github", {}); msg(r.info, true); return; }
    if (b.dataset.finirAccueil) {
      await api("/api/accueil/noter", { fini: true });
      $("#bienvenue").hidden = true; aiState = null; loadConversation(false);
      if (b.dataset.finirAccueil === "visite") launchTour();
      return;
    }
  } catch (e) { msg(e.message); b.disabled = false; }
}
/* Install a tool (coding agents, Ollama, Git): button usable everywhere (home, cloud connection). */
document.addEventListener("click", async (ev) => {
  const b = ev.target.closest("[data-installer-outil]");
  if (!b) return;
  ev.stopPropagation();
  const names = { claude: "Claude Code", codex: "Codex", ollama: "Ollama", git: "Git" }, name = names[b.dataset.installerOutil];
  if (!confirm(`Installer ${name} ? Une fenêtre s'ouvre sur le PC avec l'installation officielle ; tu peux la fermer à tout moment.`)) return;
  b.disabled = true;
  try {
    const r = await api("/api/accueil/installer", { outil: b.dataset.installerOutil });
    const place = $("#msg-accueil") || $("#fiche-msg");
    const text = r.info + (r.commande ? ` Commande : ${r.commande}` : "");
    if (place) { place.textContent = text; place.className = r.ok ? "ok" : "warn"; } else infoBubble(text);
    if (r.lien) window.open(r.lien, "_blank", "noopener");
    b.textContent = "Vérifier après l'installation"; b.disabled = false; b.removeAttribute("data-installer-outil"); b.id = "a-verifier";
  } catch (e) { infoBubble(e.message); b.disabled = false; }
}, true);

/* Guided tour: a few bubbles placed on the real areas of the studio. Replayable with the « Guide » button. */
const TOUR = [
  ["#superviseur", "Le Superviseur", "Ton point d'entrée : décris ce que tu veux, en une phrase. Il répond, ou propose une tâche avec un bouton « Lancer ». Rien ne part sans ton clic."],
  ["#bloc-travail", "Le travail", "Les tâches lancées apparaissent ici. Quand une tâche est finie, tu la relis puis tu cliques « Valider » (ou tu demandes une correction)."],
  ["#plus-p", "Tes projets", "Ajoute un projet (un dossier de ton PC) : chaque projet a son onglet, son équipe d'agents et son mode Rapide, Normal ou Performance."],
  ['nav [data-vue="perso"]', "Extensions", "Des skills (savoir-faire) et des connecteurs (outils, logiciels) en un clic, pour toutes tes IA."],
  ['nav [data-vue="gestion"]', "Gestion", "Les agents, les modèles et leurs classements, ce que consomme chaque IA, la mémoire partagée et les skills."],
  ["#systeme", "Ton PC", "Processeur, mémoire et carte graphique en direct : utile quand une IA tourne sur ton PC."],
  ["#guide", "Revoir ce guide", "Ce bouton relance la visite quand tu veux. Bonne mission !"],
];
let tourStep = 0;
function launchTour() {
  if (view !== "projets") document.querySelector('nav [data-vue="projets"]')?.click();
  tourStep = 0; showStep();
}
function finishTour() {
  $("#visite")?.remove(); $$(".cible-visite").forEach((x) => x.classList.remove("cible-visite"));
  api("/api/accueil/noter", { visite: true }).catch(() => {});
}
function showStep() {
  $$(".cible-visite").forEach((x) => x.classList.remove("cible-visite"));
  let step = TOUR[tourStep];
  while (step && !(document.querySelector(step[0])?.offsetParent)) step = TOUR[++tourStep];   // hidden area (small screen): skipped
  if (!step) return finishTour();
  const target = document.querySelector(step[0]);
  target.classList.add("cible-visite");
  target.scrollIntoView({ block: "nearest" });
  let bubble = $("#visite");
  if (!bubble) { bubble = document.createElement("div"); bubble.id = "visite"; bubble.setAttribute("role", "dialog"); document.body.appendChild(bubble); }
  const last = TOUR.slice(tourStep + 1).every((p) => !document.querySelector(p[0])?.offsetParent);
  bubble.innerHTML = `<b>${esc(step[1])}</b><p>${esc(step[2])}</p><div class="bas-a"><small class="discret">${tourStep + 1}/${TOUR.length}</small>
    <button class="btn discret petit" id="v-passer">Passer</button><button class="btn principal petit" id="v-suivant">${last ? "Terminer" : "Suivant"}</button></div>`;
  const r = target.getBoundingClientRect(), l = Math.min(340, innerWidth - 32);
  bubble.style.width = l + "px";
  bubble.style.left = Math.max(16, Math.min(innerWidth - l - 16, r.left + r.width / 2 - l / 2)) + "px";
  const h = bubble.offsetHeight;
  bubble.style.top = (r.bottom + h + 16 < innerHeight ? r.bottom + 12 : Math.max(16, r.top - h - 12)) + "px";
  $("#v-passer").onclick = finishTour;
  $("#v-suivant").onclick = () => { tourStep++; showStep(); };
  $("#v-suivant").focus();
}
document.addEventListener("keydown", (e) => { if (e.key === "Escape" && $("#visite")) finishTour(); });
if ($("#guide")) $("#guide").onclick = launchTour;
api("/api/accueil").then((d) => {
  welcome = d;
  if (d.distant) return;
  if (!d.fini && !d.pret) openWelcome("ia");
  else if (!d.visite && !d.fini) setTimeout(launchTour, 1200);   // an AI is already ready: only the tour, once
}).catch(() => {});

/* --- Language (Réglages › Langue): in English, the main interface labels are translated at display time
   (exact match of short texts: never the content of tasks, files or messages). */
const EN = {
  "Projets": "Projects", "Extensions": "Extensions", "Gestion": "Manage", "Fermer": "Close", "Guide": "Guide", "◆ Accueil": "◆ Home",
  "Salut.": "Hi.", "Tâches": "Tasks", "Réglages": "Settings", "À valider": "To review", "En cours": "In progress", "Terminées": "Done",
  "Rien à valider.": "Nothing to review.", "Rien en cours.": "Nothing in progress.", "Superviseur": "Supervisor", "Envoyer": "Send",
  "Modèle": "Model", "Effort": "Effort", "Mode": "Mode", "Auto": "Auto", "Bas": "Low", "Moyen": "Medium", "Élevé": "High", "Très élevé": "Very high",
  "Rapide": "Fast", "Normal": "Normal", "Performance": "Performance", "Lancer": "Launch", "Ignorer": "Ignore", "Cette nuit": "Tonight",
  "Modifier la demande": "Edit request", "Valider": "Approve", "Corriger": "Request changes", "Annuler": "Cancel", "Ajouter": "Add",
  "Détail": "Details", "Équipe": "Team", "Fichiers": "Files", "Branches": "Branches", "Projet": "Project", "Ouvrir": "Open", "Dossier": "Folder",
  "Voir la tâche": "View task", "Agents et outils": "Agents & tools", "Mémoire et skills": "Memory & skills", "Agents": "Agents",
  "Créer un agent": "Create an agent", "Modèles et benchmarks": "Models & benchmarks", "Usage": "Usage", "Limites et alertes": "Limits & alerts",
  "Outils et entretien": "Tools & maintenance", "Entretien": "Maintenance", "Skills et documents": "Skills & documents",
  "Audits des agents": "Agent audits", "Mémoire partagée": "Shared memory", "Lecture": "Reader", "IA": "AI", "Réglages du studio": "Studio settings",
  "Téléphone": "Phone", "Découvrir": "Discover", "Connecteurs": "Connectors", "Skills": "Skills", "Installé": "Installed", "＋ Ajouter": "＋ Add",
  "Par catégorie": "By category", "Par nom": "By name", "Nouveautés d'abord": "Newest first", "Importer une skill (.zip)": "Import a skill (.zip)",
  "Créer une skill avec le Superviseur": "Create a skill with the Supervisor", "Ajouter un serveur MCP": "Add an MCP server",
  "Ajouter un logiciel du PC": "Add a PC app", "Fichiers ou images": "Files or images", "Un dossier": "A folder",
  "Mode des agents pour ce projet": "Agent mode for this project", "Modifier le contexte": "Edit context", "Contexte du projet": "Project context",
  "Retirer ce projet du studio": "Remove this project from the studio", "À enregistrer (commit)": "To save (commit)",
  "Choisis une tâche pour voir son avancement et la valider.": "Pick a task to see its progress and approve it.",
  "Clique un skill ou un document pour le lire ici.": "Click a skill or document to read it here.", "Travail": "Work",
  "Tes résultats": "Your results", "Détails du jour": "Today's details", "Classement global": "Overall ranking",
  "Connecter": "Connect", "Installer": "Install", "Désinstaller": "Uninstall", "Se connecter": "Sign in", "Vérifier": "Check",
  "Continuer": "Continue", "Plus tard": "Later", "Retour": "Back", "Passer": "Skip", "Commencer": "Start", "Suivant": "Next", "Terminer": "Finish",
  "Bienvenue dans ton studio": "Welcome to your studio", "Avec un abonnement": "With a subscription",
  "Avec une clé API (paiement à l'usage)": "With an API key (pay as you go)", "Ou sur ton PC (gratuit, privé)": "Or on your PC (free, private)",
  "1. Une IA": "1. An AI", "2. GitHub": "2. GitHub", "3. C'est parti": "3. Let's go", "C'est prêt": "You're all set",
  "Visite guidée (1 min)": "Guided tour (1 min)", "Autre IA": "Other AI", "Utiliser": "Use", "Prêt": "Ready", "conseillé": "recommended",
  "Partir de": "Start from", "Vide": "Empty", "Site web": "Website", "Jeu vidéo": "Video game", "Application": "App", "Document": "Document", "Images": "Images",
  "Ajouter un projet ou un sujet": "Add a project or topic", "Projet (avec dossier)": "Project (with folder)", "Sujet (sans dossier)": "Topic (no folder)",
  "Aucune IA connectée pour l'instant.": "No AI connected yet.", "Connecter une IA": "Connect an AI", "en cours": "in progress", "à valider": "to review",
  "validée": "approved", "annulée": "cancelled", "terminée": "done", "échec": "failed", "bloquée": "blocked", "interrompue": "interrupted",
};
const EN_PH = { "Pose une question ou décris un travail · @ fichier · / raccourci": "Ask a question or describe a job · @ file · / shortcut",
  "Rechercher…": "Search…", "Chercher (texte, projet…)": "Search (text, project…)", "Chercher (texte, résumé…)": "Search (text, summary…)",
  "Nom (ex. Mon site web)": "Name (e.g. My website)", "Dossier du projet (C:\\…)": "Project folder" };
const TOUR_EN = [
  ["The Supervisor", "Your starting point: describe what you want in one sentence. It answers, or proposes a task with a “Launch” button. Nothing starts without your click."],
  ["The work", "Launched tasks show up here. When a task is done, review it and click “Approve” (or ask for changes)."],
  ["Your projects", "Add a project (a folder on your PC): each project gets its tab, its agent team and its Fast, Normal or Performance mode."],
  ["Extensions", "Skills (know-how) and connectors (tools, apps) in one click, for all your AIs."],
  ["Manage", "Agents, models and their rankings, what each AI costs, shared memory and skills."],
  ["Your PC", "Live CPU, memory and graphics card: handy when an AI runs on your PC."],
  ["Replay this guide", "This button replays the tour whenever you want. Good luck on your mission!"],
];
function translateNode(rootDir) {
  const walker = document.createTreeWalker(rootDir, NodeFilter.SHOW_TEXT);
  for (let n = rootDir.nodeType === 3 ? rootDir : walker.nextNode(); n; n = walker.nextNode()) {
    const t = n.nodeValue.trim();
    if (t && t.length < 90 && EN[t]) n.nodeValue = n.nodeValue.replace(t, EN[t]);
  }
  if (rootDir.querySelectorAll) [rootDir, ...rootDir.querySelectorAll("[placeholder]")].forEach((x) => { if (x.placeholder && EN_PH[x.placeholder]) x.placeholder = EN_PH[x.placeholder]; });
}
function enableEnglish() {
  document.documentElement.lang = "en";
  TOUR.forEach((p, i) => { if (TOUR_EN[i]) [p[1], p[2]] = TOUR_EN[i]; });
  translateNode(document.body);
  new MutationObserver((ms) => { for (const m of ms) for (const n of m.addedNodes) if (n.nodeType === 1 || n.nodeType === 3) translateNode(n); })
    .observe(document.body, { childList: true, subtree: true });
}
api("/api/session").then((s) => { if (s && s.langue === "en") enableEnglish(); }).catch(() => {});
