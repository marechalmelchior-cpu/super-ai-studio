"""A project's « Fichiers » tab: everything the agents created (images, sheets, texts, others), wherever it is.

Source: the files recorded by the studio at the end of each task (``artifacts`` table) and the images in
``Taches/<tâche>/captures``. Each file is looked up in its task's working copy (not merged yet),
otherwise in the project folder (merged). Read-only: nothing is moved or deleted.
"""
from __future__ import annotations

from pathlib import Path, PurePosixPath

IMAGES = {".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".webp": "image/webp", ".gif": "image/gif"}
TEXTS = {".md", ".txt", ".csv", ".html", ".pdf", ".docx", ".json"}
NOISE = (".patch", ".log", ".pyc", ".tmp")
MAX_IMAGE, MAX_TEXT = 40_000_000, 2_000_000
MEDIA = {".mp3": "audio/mpeg", ".wav": "audio/wav", ".ogg": "audio/ogg", ".flac": "audio/flac",
         ".mp4": "video/mp4", ".webm": "video/webm", ".mov": "video/quicktime"}
MAX_MEDIA = 150_000_000


def genre(chemin: str) -> str:
    s = PurePosixPath(chemin).suffix.lower()
    if s in IMAGES:
        return "image"
    if s in TEXTS and not (s == ".json" and "/" in chemin):     # agents' JSON records (captures/…): « autre »
        return "texte"
    return "autre"


def kind(chemin: str) -> str:
    """Kind of result, as sorted in the topics' folders: images, documents, 3d, sounds, videos, code, other."""
    from .orchestrator.runner import DELIVERABLE_TYPES
    s = PurePosixPath(chemin).suffix.lower()
    if s in IMAGES:
        return "images"
    return next((k for k, exts in DELIVERABLE_TYPES.items() if s in exts), "other")


def _under(base: Path, rel: str) -> Path | None:
    """base/rel only if it stays inside base (no ../, no absolute path)."""
    if not rel or rel.startswith(("/", "\\")) or ":" in rel or ".." in PurePosixPath(rel.replace("\\", "/")).parts:
        return None
    p = (base / rel).resolve()
    try:
        p.relative_to(base.resolve())
    except ValueError:
        return None
    return p


def place(studio, tid: str, rel: str) -> tuple[Path | None, str]:
    """(file, « copie » | « projet » | « capture ») — None if not found or not allowed."""
    from .orchestrator.runner import WORKSPACE
    run = studio.run_dir(tid, create_new=False)
    if rel.startswith("captures/") and rel.count("/") == 1:
        f = _under(run, rel)
        if f and f.is_file():
            return f, "capture"
    f = _under(run / WORKSPACE, rel)
    if f and f.is_file():
        return f, "copie"
    try:
        t = studio.store.get(tid)
        c = studio.registry.get(t["target"])
    except KeyError:
        return None, ""
    if c.has_path:
        f = _under(c.path(), rel)
        if f and f.is_file():
            return f, "projet"
    else:                                               # topic: working copy removed, the result is stored in Sujets/
        from .orchestrator.runner import deliverable_type
        nom = Path(rel).name
        f = _under(studio.paths.topics / c.id, f"{deliverable_type(nom, studio.paths.result_folders)}/{nom}")
        if f and f.is_file():
            return f, "sujet"
        try:                                            # stored under another name (« nom v2 »): list written in RESULTAT.md
            for l in (run / "RESULTAT.md").read_text(encoding="utf-8").splitlines():
                chemin = l[2:].strip() if l.startswith("- ") else ""
                if chemin.startswith((studio.paths.names["topics"] + "/", studio.paths.names["deliverables"] + "/")) and Path(chemin).stem.startswith(Path(nom).stem) \
                        and Path(chemin).suffix == Path(nom).suffix:
                    f = _under(studio.paths.root, chemin)
                    if f and f.is_file():
                        return f, "sujet"
        except OSError:
            pass
    return None, ""


def _file_refs(studio) -> Path:
    return studio.paths.data / "references.json"


def references(studio, cible: str = "") -> list[dict]:
    """Files marked « référence » by the user (star): [{cible, tid, chemin}], kept in data/references.json."""
    import json
    try:
        refs = json.loads(_file_refs(studio).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        refs = []
    return [r for r in refs if isinstance(r, dict) and (not cible or r.get("cible") == cible)]


def mark_reference(studio, cible: str, tid: str, rel: str, yes: bool) -> list[dict]:
    import json
    refs = [r for r in references(studio) if not (r.get("tid") == tid and r.get("chemin") == rel)]
    if yes:
        refs.append({"cible": cible, "tid": tid, "chemin": rel})
    _file_refs(studio).write_text(json.dumps(refs, ensure_ascii=False, indent=1), encoding="utf-8")
    return references(studio, cible)


def permitted(studio, tid: str, rel: str) -> bool:
    """Only files recorded for this task (or its captures) can be displayed."""
    if rel.startswith("captures/") and rel.count("/") == 1:
        return True
    return any(a["path"] == rel for a in studio.store.artifacts(tid))


def entries(studio, cible: str, limite: int = 400) -> list[dict]:
    out, seen_items = [], set()
    def same_target(x: str) -> bool:
        if x == cible:
            return True
        try:
            c = studio.registry.get(x)
            return f"{c.kind}:{c.id}" == cible
        except KeyError:
            return False
    tasks = [t for t in studio.store.list(100000) if t["status"] != "annulee" and same_target(t["target"])]
    for t in tasks:
        title = (t.get("options") or {}).get("titre") or (t.get("request") or "")[:60]
        latest: dict[str, dict] = {}
        for a in studio.store.artifacts(t["id"]):
            latest[a["path"]] = a
        captures = studio.run_dir(t["id"], create_new=False) / "captures"
        if captures.is_dir():
            for f in captures.iterdir():
                if f.is_file() and f.suffix.lower() in IMAGES:
                    latest.setdefault(f"captures/{f.name}", {"path": f"captures/{f.name}", "created_at": t["updated_at"]})
        for rel, a in latest.items():
            if rel.lower().endswith(NOISE) or PurePosixPath(rel).name.startswith("."):
                continue
            f, where = place(studio, t["id"], rel)
            cle = str(f) if f else f"{t['id']}:{rel}"
            if cle in seen_items:
                continue
            seen_items.add(cle)
            out.append({"tid": t["id"], "chemin": rel, "nom": PurePosixPath(rel).name, "genre": genre(rel), "type": kind(rel),
                        "tache": title, "statut": t["status"], "date": a.get("created_at") or t["updated_at"],
                        "ou": where, "taille": f.stat().st_size if f else 0})
    refs = {(r["tid"], r["chemin"]) for r in references(studio, cible)}
    for x in out:
        x["reference"] = (x["tid"], x["chemin"]) in refs
    out.sort(key=lambda x: (not x["reference"], -(_timestamp(x["date"]))))
    return out[:limite]


def _timestamp(d: str) -> float:
    from datetime import datetime
    try:
        return datetime.fromisoformat(str(d).replace("Z", "+00:00")).timestamp()
    except ValueError:
        return 0.0


def for_supervisor(studio, cible: str) -> str:
    """References chosen by the user, for the Supervisor's context: path in the project and current location."""
    rows = []
    for r in references(studio, cible):
        f, where = place(studio, r["tid"], r["chemin"])
        if f is None:
            continue
        rows.append(f"- {r['chemin']} ({'dans le projet' if where == 'projet' else 'pas encore fusionné : ' + str(f)})")
    return "\n".join(rows)
