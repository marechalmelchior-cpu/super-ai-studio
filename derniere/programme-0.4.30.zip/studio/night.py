"""Night tasks: « Cette nuit » on a Supervisor proposal queues it; it starts on its own during the night
window (setting, 01:00 → 07:00 by default), then a report waits in the general conversation in the morning.

- Nothing starts outside the window; the PC must stay on and the studio open (otherwise the queue waits for the next
  night, nothing is lost).
- Launched tasks follow the normal path (review, validation): the night never validates anything for you.
- Queue: data/nuit.json (atomic write).
"""
from __future__ import annotations

import json
import os
import threading
import uuid
from datetime import datetime, timedelta
from pathlib import Path

_lock = threading.Lock()
FINISHED_STATES = {"approuvee": "faite", "appliquee": "appliquée", "a_approuver": "à valider", "a_approuver_avec_defauts": "à valider (défauts)",
               "bloquee": "bloquée", "echec": "en échec", "annulee": "annulée", "interrompue": "interrompue"}


def _file(data: Path) -> Path:
    return Path(data) / "nuit.json"


def read_file(data: Path) -> dict:
    try:
        d = json.loads(_file(data).read_text(encoding="utf-8"))
        if isinstance(d, dict):
            return {"file": list(d.get("file", [])), "lancees": list(d.get("lancees", [])), "rapports": list(d.get("rapports", []))}
    except (OSError, ValueError):
        pass
    return {"file": [], "lancees": [], "rapports": []}


def _write(data: Path, d: dict) -> None:
    f = _file(data)
    f.parent.mkdir(parents=True, exist_ok=True)
    t = f.with_suffix(".tmp")
    t.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
    os.replace(t, f)


def time_window(cfg: dict) -> tuple[str, str]:
    n = cfg.get("nuit") or {}
    return str(n.get("debut") or "01:00"), str(n.get("fin") or "07:00")


def _minutes(h: str) -> int:
    hh, _, mm = h.partition(":")
    return int(hh) * 60 + int(mm or 0)


def during_night(cfg: dict, current_time: datetime) -> bool:
    d, f = (_minutes(x) for x in time_window(cfg))
    m = current_time.hour * 60 + current_time.minute
    return d <= m < f if d < f else (m >= d or m < f)


def night_of(cfg: dict, current_time: datetime) -> str:
    """Date of the current or last night: the day of the evening it starts."""
    d = _minutes(time_window(cfg)[0])
    m = current_time.hour * 60 + current_time.minute
    if d >= 12 * 60 and m >= d:                       # window started this evening (e.g. 23:00)
        return current_time.date().isoformat()
    return (current_time.date() - timedelta(days=1)).isoformat()


def schedule(studio, rid: int, cible: str = "", demande: str = "", modele: str = "", mode: str = "", effort: str = "") -> dict:
    msg = next((m for m in studio.store.messages(500) if m["id"] == rid), None)
    if msg is None or not msg["proposition"] or msg["proposition"].get("etat") != "proposee":
        raise ValueError("Aucune proposition à mettre en file pour ce message.")
    p = dict(msg["proposition"])
    demande = (demande or p.get("demande", "")).strip()
    if not demande:
        raise ValueError("Demande vide.")
    e = {"id": uuid.uuid4().hex[:12], "rid": rid, "cible": cible or p.get("cible", ""), "demande": demande,
         "titre": p.get("titre", ""), "modele": modele, "mode": mode, "effort": effort,
         "ajoute": datetime.now().isoformat(timespec="seconds")}
    with _lock:
        d = read_file(studio.paths.data)
        d["file"].append(e)
        _write(studio.paths.data, d)
    p.update(etat="nuit", nuit=e["id"], demande=demande, cible=e["cible"], modele_nuit=modele, mode_nuit=mode, effort_nuit=effort)
    studio.store.update_message(rid, proposition=p)
    return {"ok": True, "id": e["id"], "debut": time_window(studio.cfg)[0]}


def retire(studio, ident: str) -> dict:
    with _lock:
        d = read_file(studio.paths.data)
        e = next((x for x in d["file"] if x["id"] == ident), None)
        if not e:
            raise ValueError("Cette tâche n'est plus en file (déjà lancée ou retirée).")
        d["file"] = [x for x in d["file"] if x["id"] != ident]
        _write(studio.paths.data, d)
    msg = next((m for m in studio.store.messages(500) if m["id"] == e["rid"]), None)
    if msg and msg["proposition"].get("etat") == "nuit":
        studio.store.update_message(e["rid"], proposition={**msg["proposition"], "etat": "proposee"})
    return {"ok": True}


def tick(studio, sup, lancer, current_time: datetime | None = None) -> dict:
    """Called every minute: launches the queue during the night; after the night, writes the report only once."""
    current_time = current_time or datetime.now()
    done = {"lancees": [], "rapport": False}
    night = during_night(studio.cfg, current_time)
    with _lock:
        d = read_file(studio.paths.data)
        to_launch = d["file"] if night else []
        d["file"] = [] if night else d["file"]
        if to_launch:
            _write(studio.paths.data, d)
    for e in to_launch:
        try:
            tid = sup.lancer(e["rid"], e["cible"], e["demande"], e.get("modele", ""), e.get("mode", ""), e.get("effort", ""),
                             since_night=True)
            lancer(tid)
            e.update(tid=tid, lancee=current_time.isoformat(timespec="seconds"), nuit=night_of(studio.cfg, current_time))
        except Exception as ex:                          # noqa: BLE001 — noted in the morning report
            e.update(erreur=str(ex)[:300], lancee=current_time.isoformat(timespec="seconds"), nuit=night_of(studio.cfg, current_time))
        done["lancees"].append(e)
    with _lock:
        d = read_file(studio.paths.data)
        if done["lancees"]:
            d["lancees"] = (d["lancees"] + done["lancees"])[-200:]
        to_report = sorted({x.get("nuit") for x in d["lancees"] if x.get("nuit")} - set(d["rapports"]))
        to_report = [n for n in to_report if not (night and n == night_of(studio.cfg, current_time))]
        for n in to_report:
            _night_report(studio, [x for x in d["lancees"] if x.get("nuit") == n])
            d["rapports"] = (d["rapports"] + [n])[-60:]
            done["rapport"] = True
        if done["lancees"] or to_report:
            _write(studio.paths.data, d)
    return done


def _night_report(studio, launched: list[dict]) -> None:
    rows, links = [], []
    for e in launched:
        title = e.get("titre") or e["demande"][:70]
        if e.get("erreur"):
            rows.append(f"- **{title}** : pas lancée ({e['erreur']})")
            continue
        try:
            t = studio.store.get(e["tid"])
            etat = FINISHED_STATES.get(t["status"], "encore en cours")
        except KeyError:
            etat = "introuvable"
        rows.append(f"- **{title}** : {etat}")
        links.append({"tid": e["tid"], "titre": title, "cible": e.get("cible", ""), "etat": etat})
    to_approve = sum(1 for x in links if x["etat"].startswith("à valider"))
    texte = (f"### Rapport de la nuit\n{len(launched)} tâche(s) lancée(s) pendant la nuit"
             + (f", **{to_approve} à valider**" if to_approve else "") + ".\n\n" + "\n".join(rows))
    studio.store.message("superviseur", texte, proposal={"rapport_nuit": links})
