"""Attachments readable by agents (Request window, tasks).

Each attached file gets a ``<nom>.lisible/`` folder next to it:
- PDF: ``texte.md`` (text page by page) + ``pages/page-001.png``… (page renders, to see diagrams and images);
- images in an uncommon format (BMP, TIFF, TGA, DDS, PSD…) or very large: a readable ``image.png``;
- audio and video: ``transcription.md`` (timestamped speech), ``spectrogramme.png`` (to "see" the sound), ``infos``
  (duration, volume), and for a video ``images/vue-01.png``… (key frames);
- Word, Excel, PowerPoint: ``texte.md`` (standard library);
- ZIP archives: ``contenu.md`` (listing, nothing is extracted).
A ``LISIBLE.md`` summarises what was produced and what is missing (with the install command): the agent is never
silently blocked. Optional modules (PyMuPDF, Pillow, faster-whisper) are installed only with the user's consent
(``scripts\\Install-Attachment-Readers.ps1``).
"""
from __future__ import annotations

import json
import re
import zipfile
from pathlib import Path
from xml.etree import ElementTree

SUFFIX = ".lisible"
NATIVE_IMAGES = {".png", ".jpg", ".jpeg", ".gif", ".webp"}
IMAGES_TO_CONVERT = {".bmp", ".tif", ".tiff", ".tga", ".dds", ".psd", ".ico", ".jfif", ".avif", ".heic"}
AUDIO = {".wav", ".mp3", ".ogg", ".flac", ".m4a", ".aac", ".opus", ".wma"}
VIDEO = {".mp4", ".mov", ".mkv", ".webm", ".avi", ".m4v"}
OFFICE = {".docx", ".xlsx", ".pptx"}
INSTALLER = str(Path(__file__).resolve().parents[1] / "scripts" / "Install-Attachment-Readers.ps1") + " -Confirmer"
MAX_PAGES = 80


def capabilities() -> dict:
    """What the studio can read on this PC (shown in Gestion › Outils)."""
    def usable(mod):
        try:
            __import__(mod)
            return True
        except Exception:                        # noqa: BLE001 — a missing or broken module = unavailable
            return False
    return {"pdf": usable("pymupdf") or usable("fitz"), "images": usable("PIL"), "audio_video": usable("faster_whisper") and usable("av"),
            "office": True, "zip": True}


def _missing(module: str) -> str:
    return f"{module} n'est pas installé : lancer `{INSTALLER}` (accord de l'utilisateur requis)."


# ------------------------------------------------------------------ PDF
def _pdf(f: Path, out: Path, notes: list[str], products: list[Path]):
    try:
        import pymupdf as fitz                   # PyMuPDF (former name: fitz)
    except ImportError:
        try:
            import fitz
        except ImportError:
            notes.append("PDF non lu : " + _missing("PyMuPDF"))
            return
    doc = fitz.open(f)
    rows = [f"# {f.name} — texte extrait ({doc.page_count} pages)\n"]
    (out / "pages").mkdir(exist_ok=True)
    for i, page in enumerate(doc):
        rows.append(f"\n## Page {i + 1}\n\n{page.get_text().strip()}\n")
        if i < MAX_PAGES:
            png = out / "pages" / f"page-{i + 1:03d}.png"
            page.get_pixmap(dpi=110).save(png)
            products.append(png)
    if doc.page_count > MAX_PAGES:
        notes.append(f"Rendu limité aux {MAX_PAGES} premières pages (le texte couvre tout le document).")
    t = out / "texte.md"
    t.write_text("".join(rows), encoding="utf-8")
    products.insert(0, t)
    if sum(len(p.get_text().strip()) for p in doc) < 50:
        notes.append("Peu ou pas de texte dans ce PDF (document scanné ?) : lire les images des pages.")


# ------------------------------------------------------------------ images
def _image(f: Path, out: Path, notes: list[str], products: list[Path]):
    try:
        from PIL import Image
    except ImportError:
        if f.suffix.lower() not in NATIVE_IMAGES:
            notes.append("Image non convertie : " + _missing("Pillow"))
        return
    try:
        with Image.open(f) as im:
            notes.append(f"Image {im.width}×{im.height}, mode {im.mode}.")
            if f.suffix.lower() in NATIVE_IMAGES and max(im.size) <= 4000 and f.stat().st_size < 4_500_000:
                return                           # already readable as is
            im = im.convert("RGBA" if im.mode in ("RGBA", "LA", "P") else "RGB")
            im.thumbnail((2400, 2400))
            png = out / "image.png"
            im.save(png)
            products.append(png)
    except Exception as e:                       # noqa: BLE001
        notes.append(f"Image illisible par Pillow ({type(e).__name__}).")


# ------------------------------------------------------------------ audio and video
def _audio_video(f: Path, out: Path, notes: list[str], products: list[Path], cfg: dict):
    try:
        import av
        import numpy as np
    except ImportError:
        notes.append("Son/vidéo non lu : " + _missing("faster-whisper (avec PyAV)"))
        return
    video = f.suffix.lower() in VIDEO
    try:
        with av.open(str(f)) as c:
            length_s = float(c.duration / 1_000_000) if c.duration else 0.0
            notes.append(f"Durée : {length_s:.1f} s.")
            if video and c.streams.video:
                (out / "images").mkdir(exist_ok=True)
                st = c.streams.video[0]
                n = 6
                for k in range(n):
                    t = length_s * (k + 0.5) / n if length_s else 0
                    c.seek(int(t / st.time_base) if st.time_base else 0, stream=st)
                    for fr in c.decode(st):
                        png = out / "images" / f"vue-{k + 1:02d}.png"
                        fr.to_image().save(png)
                        products.append(png)
                        break
        # mono 16 kHz audio signal for the spectrogram and measurements
        with av.open(str(f)) as c:
            if not c.streams.audio:
                notes.append("Pas de piste son.")
                return
            res = av.AudioResampler(format="flt", layout="mono", rate=16000)
            chunks = []
            for fr in c.decode(c.streams.audio[0]):
                for r in res.resample(fr):
                    chunks.append(r.to_ndarray().reshape(-1))
            x = np.concatenate(chunks) if chunks else np.zeros(1, dtype=np.float32)
        peak, rms = float(np.max(np.abs(x)) or 0), float(np.sqrt(np.mean(x ** 2)) or 0)
        db = lambda v: 20 * np.log10(max(v, 1e-9))
        notes.append(f"Niveau : crête {db(peak):.1f} dBFS, moyenne {db(rms):.1f} dBFS.")
        _spectrogram(x, out / "spectrogramme.png", notes, products)
    except Exception as e:                       # noqa: BLE001
        notes.append(f"Décodage impossible ({type(e).__name__}).")
        return
    try:
        from faster_whisper import WhisperModel
    except ImportError:
        notes.append("Parole non transcrite : " + _missing("faster-whisper"))
        return
    modele = cfg.get("modele_parole", "small")
    root_dir = Path(cfg.get("dossier_modeles", "")) if cfg.get("dossier_modeles") else None
    try:
        m = WhisperModel(modele, device="cpu", compute_type="int8", download_root=str(root_dir) if root_dir else None)
        segs, info = m.transcribe(str(f), vad_filter=True)
        rows = [f"# {f.name} — transcription (langue détectée : {info.language}, modèle {modele})\n\n"]
        for s in segs:
            rows.append(f"[{s.start:6.1f} → {s.end:6.1f}] {s.text.strip()}\n")
        t = out / "transcription.md"
        t.write_text("".join(rows) if len(rows) > 1 else rows[0] + "(aucune parole détectée)\n", encoding="utf-8")
        products.insert(0, t)
    except Exception as e:                       # noqa: BLE001
        notes.append(f"Transcription impossible ({type(e).__name__}) : le modèle de parole se télécharge à la première utilisation.")


def _spectrogram(x, png: Path, notes: list[str], products: list[Path]):
    try:
        import numpy as np
        from PIL import Image
    except ImportError:
        return
    n, step = 512, 256
    if len(x) < n:
        return
    frames = np.lib.stride_tricks.sliding_window_view(x, n)[::step] * np.hanning(n)
    s = np.abs(np.fft.rfft(frames, axis=1)).T
    s = 20 * np.log10(s + 1e-6)
    s = np.clip((s - (s.max() - 80)) / 80, 0, 1)[::-1]
    img = Image.fromarray((s * 255).astype("uint8")).resize((min(1600, max(400, s.shape[1])), 400))
    img.save(png)
    products.append(png)
    notes.append("Spectrogramme : temps en horizontal, fréquences de 0 (bas) à 8 kHz (haut), clair = fort.")


# ------------------------------------------------------------------ office documents and archives
def _office(f: Path, out: Path, notes: list[str], products: list[Path]):
    try:
        with zipfile.ZipFile(f) as z:
            names = z.namelist()
            if f.suffix.lower() == ".docx":
                components = ["word/document.xml"]
            elif f.suffix.lower() == ".pptx":
                components = sorted((n for n in names if re.fullmatch(r"ppt/slides/slide\d+\.xml", n)),
                                 key=lambda n: int(re.search(r"(\d+)", n.split("/")[-1]).group(1)))
            else:
                components = ["xl/sharedStrings.xml"] + sorted(n for n in names if re.fullmatch(r"xl/worksheets/sheet\d+\.xml", n))
            rows = [f"# {f.name} — texte extrait\n"]
            for p in components:
                if p not in names:
                    continue
                root_dir = ElementTree.fromstring(z.read(p))
                block, current = [], []
                for el in root_dir.iter():
                    tag = el.tag
                    if tag.endswith("}t") and el.text:
                        current.append(el.text)
                    elif tag.endswith("}p") or tag.endswith("}si") or tag.endswith("}row"):
                        if current:
                            block.append("".join(current))
                            current = []
                    elif tag.endswith("}v") and el.text:
                        current.append(el.text + " ")
                if current:
                    block.append("".join(current))
                rows.append(f"\n## {p}\n\n" + "\n".join(b for b in block if b.strip()) + "\n")
        t = out / "texte.md"
        t.write_text("".join(rows), encoding="utf-8")
        products.append(t)
        if f.suffix.lower() == ".xlsx":
            notes.append("Excel : chaînes partagées puis valeurs des feuilles (sans mise en forme ni formules).")
    except (zipfile.BadZipFile, ElementTree.ParseError, KeyError) as e:
        notes.append(f"Document illisible ({type(e).__name__}).")


def _zip(f: Path, out: Path, notes: list[str], products: list[Path]):
    try:
        with zipfile.ZipFile(f) as z:
            infos = z.infolist()
        t = out / "contenu.md"
        t.write_text(f"# {f.name} — contenu ({len(infos)} éléments, rien n'est extrait)\n\n"
                     + "\n".join(f"- {i.filename} ({i.file_size} octets)" for i in infos[:2000]), encoding="utf-8")
        products.append(t)
    except zipfile.BadZipFile:
        notes.append("Archive ZIP illisible.")


# ------------------------------------------------------------------ entry point
def prepare(f: Path, cfg: dict | None = None) -> dict:
    """Prepares an attachment (idempotent: does nothing if LISIBLE.md exists). Never raises."""
    f = Path(f)
    out = f.with_name(f.name + SUFFIX)
    resume = out / "LISIBLE.md"
    if resume.exists():
        return json.loads((out / "lisible.json").read_text(encoding="utf-8"))
    notes: list[str] = []
    products: list[Path] = []
    ext = f.suffix.lower()
    out.mkdir(exist_ok=True)
    try:
        if ext == ".pdf":
            _pdf(f, out, notes, products)
        elif ext in NATIVE_IMAGES or ext in IMAGES_TO_CONVERT:
            _image(f, out, notes, products)
        elif ext in AUDIO or ext in VIDEO:
            _audio_video(f, out, notes, products, cfg or {})
        elif ext in OFFICE:
            _office(f, out, notes, products)
        elif ext == ".zip":
            _zip(f, out, notes, products)
        else:
            notes.append("Format lisible directement (texte, code) ou non pris en charge : ouvrir le fichier d'origine.")
    except Exception as e:                       # noqa: BLE001 — an attachment must never block the conversation
        notes.append(f"Préparation interrompue ({type(e).__name__}).")
    rel = [p.relative_to(f.parent).as_posix() for p in products]
    data = {"fichier": f.name, "lisible": rel, "notes": notes}
    (out / "lisible.json").write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")
    resume.write_text(f"# Version lisible de {f.name}\n\n" + "".join(f"- {r}\n" for r in rel)
                      + ("\n" + "".join(f"> {n}\n" for n in notes) if notes else ""), encoding="utf-8")
    return data


def prepare_batch(dossier: Path, cfg: dict | None = None) -> list[tuple[Path, dict]]:
    """All attachments of a message (excluding .lisible folders already produced)."""
    res = []
    for f in sorted(p for p in Path(dossier).rglob("*") if p.is_file() and not any(x.endswith(SUFFIX) for x in p.parts)):
        res.append((f, prepare(f, cfg)))
    return res


_dictation_model: dict = {}


def dictate(audio: bytes, cfg: dict | None = None, suffix_text: str = ".webm") -> str:
    """Dictating the message to the Supervisor (microphone): local transcription by faster-whisper, nothing is sent elsewhere.
    The audio file is temporary and deleted right away. ValueError with the reason if dictation is not possible."""
    import os
    import tempfile
    cfg = cfg or {}
    try:
        from faster_whisper import WhisperModel
    except ImportError:
        raise ValueError("Dictée sur le PC indisponible : " + _missing("faster-whisper")) from None
    modele = cfg.get("modele_parole", "small")
    root_dir = cfg.get("dossier_modeles") or None
    cle = (modele, root_dir)
    if cle not in _dictation_model:
        _dictation_model.clear()
        _dictation_model[cle] = WhisperModel(modele, device="cpu", compute_type="int8", download_root=root_dir)
    fd, chemin = tempfile.mkstemp(suffix=suffix_text if re.fullmatch(r"\.[a-z0-9]{2,5}", suffix_text) else ".webm")
    try:
        with os.fdopen(fd, "wb") as h:
            h.write(audio)
        segs, _ = _dictation_model[cle].transcribe(chemin, vad_filter=True)
        return " ".join(x.text.strip() for x in segs).strip()
    finally:
        try:
            os.remove(chemin)
        except OSError:
            pass
