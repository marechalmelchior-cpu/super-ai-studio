"""Studio language (Réglages › Langue): the Supervisor and the agents reply in the chosen language."""
from __future__ import annotations

INSTRUCTIONS = {
    "en": ("\n\n# Language\nThe user chose ENGLISH. Always write to the user in English (answers, proposals, reports, summaries), "
           "even though these instructions are in French. File names and code stay as they are."),
}


def ui_language(cfg: dict) -> str:
    v = str((cfg.get("utilisateur") or {}).get("langue") or "fr")
    return v if v in ("fr", "en") else "fr"


def instruction(cfg: dict) -> str:
    return INSTRUCTIONS.get(ui_language(cfg), "")


LANGUAGE_NAMES = {"fr": "français", "en": "English"}


def code_rule(cfg: dict) -> str:
    """Given to every agent: names stay English everywhere, words meant for people follow the studio's language."""
    lang = LANGUAGE_NAMES[ui_language(cfg)]
    return ("\n\n# Langue du code\nStrictement en anglais : le code (variables, fonctions, classes, noms des fichiers de code et "
            f"des tests), les noms des skills et les noms des fichiers .md. En {lang} : commentaires dans le code, documentation, "
            "contenu des fichiers .md et des skills, textes pour l'utilisateur — y compris la courte description de chaque "
            f"commande que tu lances (elle s'affiche dans le journal de la tâche, en {lang}). Les textes affichés à l'utilisateur final d'un "
            "projet gardent la langue du projet.")
