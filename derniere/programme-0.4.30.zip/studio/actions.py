"""Actions launched with one click from the interface: merge, build, tests, installing reader modules,
cleaning up workspaces. Nothing runs without the user's click; each action checks its conditions before
writing and stops cleanly otherwise. Long jobs run in the background (only one of each kind at a time).
"""
from __future__ import annotations

import json
import re
import os
import subprocess
import sys
import threading
import time
from datetime import datetime, timezone
from pathlib import Path

from .connectors import workspace as ws
from .connectors.base import NO_WINDOW, sha256_file
from .orchestrator.store import TERMINAL
from .security import redact


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


class Jobs:
    """Background jobs shown in the interface (state, duration, tail of the output)."""

    def __init__(self, controller=None):
        self._t: dict[str, dict] = {}
        self._guard_lock = threading.Lock()
        self.controller = controller

    def etat(self) -> dict:
        with self._guard_lock:
            return {k: dict(v) for k, v in self._t.items()}

    def lancer(self, nom: str, title: str, cmd: list[str], cwd: Path, timeout_s: float = 3600,
               after=None) -> dict:
        with self._guard_lock:
            if self._t.get(nom, {}).get("etat") == "en_cours":
                raise RuntimeError(f"« {title} » tourne déjà.")
            self._t[nom] = {"titre": title, "etat": "en_cours", "debut": _now(), "fin": "", "code": None,
                            "sortie": "", "commande": redact(" ".join(str(c) for c in cmd))[:300]}
        if self.controller:
            self.controller.begin()

        def run():
            output, code = "", None
            try:
                r = subprocess.run([str(c) for c in cmd], cwd=str(cwd), capture_output=True, text=True, encoding="utf-8",
                                   errors="replace", stdin=subprocess.DEVNULL, timeout=timeout_s, **NO_WINDOW)
                output, code = (r.stdout or "") + (r.stderr or ""), r.returncode
            except subprocess.TimeoutExpired:
                output, code = "Délai dépassé : arrêté.", -1
            except OSError as e:
                output, code = f"Impossible de lancer : {e}", -1
            finally:
                with self._guard_lock:
                    self._t[nom].update(etat="ok" if code == 0 else "echec", fin=_now(), code=code,
                                        sortie=redact(output)[-20000:])
                if after:
                    try:
                        after(code, output)
                    except Exception:            # noqa: BLE001 — a callback never breaks the job
                        pass
                if self.controller:
                    self.controller.finish()
        threading.Thread(target=run, daemon=True).start()
        return self.etat()[nom]


# ------------------------------------------------------------------ merge
def _task_worktree(studio, tid: str):
    t = studio.store.get(tid)
    cible = studio.registry.get(t["target"])
    base = studio.details_dir(tid) / "base.json"
    info = json.loads(base.read_text(encoding="utf-8")) if base.exists() else {}
    if "_worktree" not in info:
        raise ValueError("Cette tâche n'a pas été faite dans un worktree : rien à fusionner.")
    return t, cible, info


OPERATIONS = ("MERGE_HEAD", "CHERRY_PICK_HEAD", "REVERT_HEAD", "rebase-merge", "rebase-apply", "sequencer", "BISECT_LOG")


def _operation_in_progress(git: str, depot: Path) -> str:
    """Merge, rebase, cherry-pick… already started by the user in the repository (never touched by the studio)."""
    for nom in OPERATIONS:
        p = Path(ws._git(git, depot, "rev-parse", "--path-format=absolute", "--git-path", nom).strip())
        if p.exists():
            return nom
    return ""


REPORTS = re.compile(r"(^|/)RESULTAT[^/]*\.md$", re.I)


def _configure_reports(git: str, depot: Path) -> bool:
    """Merge with conflicts: if ALL conflicted files are agent reports (RESULTAT*.md), they are
    removed (git rm) and the merge can go on; otherwise nothing is touched (the merge will be aborted)."""
    conflicts = [l for l in ws._git(git, depot, "diff", "--name-only", "--diff-filter=U").splitlines() if l.strip()]
    if not conflicts or not all(REPORTS.search(c) for c in conflicts):
        return False
    ws._git(git, depot, "rm", "-q", "--", *conflicts)
    return not ws._git(git, depot, "diff", "--name-only", "--diff-filter=U").strip()


def merge(studio, tid: str) -> dict:
    """Merges the studio/<task> branch into the starting branch, with --no-ff and a prefilled message.
    Refuses if: the task is not approved; the branch no longer matches the approved commit; the repository is not on
    the starting branch (detached HEAD included); a merge, rebase… is already in progress; tracked files are
    modified (your work in progress is never mixed in). On conflict, only OUR merge is aborted."""
    from .orchestrator.runner import commit_title
    git = studio.cfg["outils"].get("git", "git")
    t, cible, info = _task_worktree(studio, tid)
    if t["status"] not in ("approuvee", "appliquee"):
        raise ValueError("Valide d'abord la tâche : seule une tâche validée peut être fusionnée.")
    depot, branch = cible.path(), f"studio/{tid}"
    bj = studio.details_dir(tid) / "branche.json"
    valid = json.loads(bj.read_text(encoding="utf-8")) if bj.exists() else {}
    if not ws._git(git, depot, "branch", "--list", branch).strip():
        raise ValueError(f"Branche {branch} introuvable.")
    tip = ws._git(git, depot, "rev-parse", branch).strip()
    if not valid.get("commit") or tip != valid["commit"]:
        raise ValueError(f"La branche {branch} ne correspond pas au commit validé : rien n'est fusionné.")
    base = valid.get("base") or info.get("_worktree", "")
    if base and ws._git(git, depot, "rev-list", "--count", f"{base}..{branch}").strip() == "0":
        return {"etat": "vide", "message": "Aucun changement validé sur cette branche : rien à fusionner."}
    expected = info.get("branche", "")
    if not expected or expected == "HEAD":
        raise ValueError("La tâche est partie d'un HEAD détaché : fusionne-la toi-même (voir BRANCHE.md).")
    if not ws._succeeds(git, depot, "symbolic-ref", "-q", "HEAD"):
        raise ValueError("Le dépôt est en HEAD détaché : repasse sur ta branche puis réessaie.")
    selected = ws._git(git, depot, "rev-parse", "--abbrev-ref", "HEAD").strip()
    if selected != expected:
        raise ValueError(f"Le dépôt est sur « {selected} », la tâche est partie de « {expected} » : rien n'est fait.")
    op = _operation_in_progress(git, depot)
    if op:
        raise ValueError(f"Une opération git est déjà en cours dans le dépôt ({op}) : termine-la, puis réessaie.")
    if ws._succeeds(git, depot, "merge-base", "--is-ancestor", branch, "HEAD"):
        return {"etat": "deja", "message": f"{branch} est déjà fusionnée dans {selected}."}
    dirty = ws._git(git, depot, "status", "--porcelain", "--untracked-files=no").strip()
    if dirty:
        raise ValueError("Le dépôt a des modifications non commitées ; commite-les ou mets-les de côté, puis réessaie : "
                         + ", ".join(l[3:] for l in dirty.splitlines()[:5]))
    message = f"Fusion studio {tid} : {commit_title(t.get('request') or '', 60)}"
    try:
        ws._git(git, depot, "merge", "--no-ff", "--no-verify", branch, "-m", message, timeout=900)
    except ws.WorktreeError as e:
        mh = Path(ws._git(git, depot, "rev-parse", "--path-format=absolute", "--git-path", "MERGE_HEAD").strip())
        our = mh.exists() and mh.read_text(encoding="utf-8").split()[:1] == [tip]
        rule = False
        if our and _configure_reports(git, depot):     # only an agent report (RESULTAT.md) was blocking
            try:
                ws._git(git, depot, "commit", "--no-verify", "--no-edit", timeout=300)
                rule = not mh.exists()
            except ws.WorktreeError:
                rule = False
        if not rule:
            if our:
                try:
                    ws._git(git, depot, "merge", "--abort")      # our merge only
                except ws.WorktreeError:
                    pass
                raise ValueError(f"Fusion impossible (conflit) : annulée, ton dépôt est comme avant. {e}") from None
            raise ValueError(f"Fusion refusée par git, rien n'a été fusionné : {e}") from None
        studio.store.event(tid, "Conflit sur un RESULTAT.md d'agent : laissé retiré du dépôt, fusion terminée")
    sha = ws._git(git, depot, "rev-parse", "--short", "HEAD").strip()
    studio.store.event(tid, f"Fusionnée dans {selected} ({sha})")
    (studio.details_dir(tid) / "fusion.json").write_text(json.dumps({"branche": selected, "commit": sha, "at": _now()}),
                                                      encoding="utf-8")
    return {"etat": "ok", "message": f"Fusionnée dans {selected} : commit {sha}. Rien n'est poussé vers GitHub.", "commit": sha}


# ------------------------------------------------------------------ undo a task already applied or merged
def cancellable(studio, tid: str) -> dict:
    """What « Annuler ce qui a été appliqué » would do for this task (nothing is done here)."""
    t = studio.store.get(tid)
    d = studio.details_dir(tid, create_new=False)
    if (d / "annulation.json").exists():
        return {"possible": False, "mode": "", "texte": "Déjà annulée."}
    if (d / "fusion.json").exists():
        return {"possible": True, "mode": "fusion",
                "texte": "Un commit inverse (git revert) annule la fusion. L'historique est gardé, rien n'est poussé vers GitHub."}
    if t["status"] == "appliquee" and (d / "application.json").exists():
        return {"possible": True, "mode": "application",
                "texte": "Les fichiers du projet reviennent comme avant la tâche. Ce que la tâche avait ajouté ou changé est "
                         "mis de côté dans le dossier de la tâche (rien n'est effacé)."}
    return {"possible": False, "mode": "", "texte": ""}


def cancel_apply(studio, tid: str) -> dict:
    """Undoes an applied (copy) or merged (worktree) task. Checks everything before writing; refuses if the project
    has changed since on those files (your work is never overwritten)."""
    import shutil
    a = cancellable(studio, tid)
    if not a["possible"]:
        raise ValueError(a["texte"] or "Rien à annuler pour cette tâche : elle n'a rien appliqué à ton projet.")
    d = studio.details_dir(tid)
    t = studio.store.get(tid)
    if a["mode"] == "fusion":
        git = studio.cfg["outils"].get("git", "git")
        cible = studio.registry.get(t["target"])
        depot = cible.path()
        fj = json.loads((d / "fusion.json").read_text(encoding="utf-8"))
        op = _operation_in_progress(git, depot)
        if op:
            raise ValueError(f"Une opération git est déjà en cours dans le dépôt ({op}) : termine-la, puis réessaie.")
        selected = ws._git(git, depot, "rev-parse", "--abbrev-ref", "HEAD").strip()
        if fj.get("branche") and selected != fj["branche"]:
            raise ValueError(f"Le dépôt est sur « {selected} », la fusion a été faite sur « {fj['branche']} » : rien n'est fait.")
        if ws._git(git, depot, "status", "--porcelain", "--untracked-files=no").strip():
            raise ValueError("Le dépôt a des modifications non commitées : commite-les ou mets-les de côté, puis réessaie.")
        sha = ws._git(git, depot, "rev-parse", fj["commit"]).strip()
        parents = ws._git(git, depot, "rev-list", "--parents", "-n", "1", sha).split()
        try:
            if len(parents) > 2:
                ws._git(git, depot, "revert", "--no-edit", "-m", "1", sha, timeout=600)
            else:
                ws._git(git, depot, "revert", "--no-edit", sha, timeout=600)
        except ws.WorktreeError as e:
            try:
                ws._git(git, depot, "revert", "--abort")
            except ws.WorktreeError:
                pass
            raise ValueError(f"Annulation impossible (conflit avec des changements faits depuis) : rien n'est modifié. {e}") from None
        new_name = ws._git(git, depot, "rev-parse", "--short", "HEAD").strip()
        info = {"mode": "fusion", "commit_inverse": new_name, "fusion": fj["commit"], "at": _now()}
        message = f"Fusion annulée par un commit inverse ({new_name}) sur {selected}. Rien n'est poussé vers GitHub."
    else:
        m = json.loads((d / "application.json").read_text(encoding="utf-8"))
        root_dir, before = Path(m["cible"]), Path(m.get("sauvegarde") or d / "avant-application")
        change = [rel for rel, h in m["fichiers"].items()
                  if not (root_dir / rel).is_file() or sha256_file(root_dir / rel) != h]
        if change:
            raise ValueError("Ces fichiers ont changé dans ton projet depuis la tâche : rien n'est modifié. "
                             + ", ".join(change[:8]) + (f" (+{len(change) - 8})" if len(change) > 8 else ""))
        guard = d / "annulation"
        for rel in m["fichiers"]:                        # the task's version is kept, never deleted
            (guard / rel).parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(root_dir / rel, guard / rel)
        restored, removed = [], []
        for rel in m["fichiers"]:
            target_f = root_dir / rel
            if (before / rel).is_file():
                tmp = target_f.with_name(f".studio-tmp-{target_f.name}")
                shutil.copy2(before / rel, tmp)
                os.replace(tmp, target_f)
                restored.append(rel)
            else:
                target_f.unlink()                             # its copy is already in annulation/
                removed.append(rel)
        info = {"mode": "application", "remis": restored, "retires": removed, "gardes": str(guard), "at": _now()}
        message = (f"{len(restored)} fichier(s) remis comme avant" + (f", {len(removed)} ajouté(s) par la tâche mis de côté" if removed else "")
                   + f". Version de la tâche gardée dans {guard}.")
    (d / "annulation.json").write_text(json.dumps(info, ensure_ascii=False, indent=1), encoding="utf-8")
    studio.store.event(tid, "Annulée après coup : " + message)
    studio.store.set_status(tid, "annulee", "Annulée après application — " + message)
    return {"ok": True, "message": message}


# ------------------------------------------------------------------ build
def editor_open() -> bool:
    if sys.platform != "win32":
        return False
    try:
        r = subprocess.run(["tasklist", "/FI", "IMAGENAME eq UnrealEditor.exe", "/NH"], capture_output=True, text=True,
                           timeout=15, **NO_WINDOW)
        return "UnrealEditor.exe" in (r.stdout or "")
    except (OSError, subprocess.TimeoutExpired):
        return False


def run_compile(studio, jobs: Jobs, cle: str) -> dict:
    from .orchestrator.runner import Studio
    cible = studio.registry.get(cle)
    cmd = Studio._build_command(cible, cible.path()) if cible.has_path else None
    if not cmd:
        raise ValueError("Pas de commande de compilation pour ce projet (« build » dans project.toml).")
    from . import unreal
    up = unreal.unreal_project(cible.path()) or next(iter(sorted(cible.path().glob("*.uproject"))), None)
    if up and cible.extra.get("type") == "unreal":
        # Unreal: the studio tool closes the editor cleanly (never forcibly), builds, then reopens it
        cmd = [python_console(), str(studio.paths.code / "scripts" / "tools" / "unreal_compiler.py"),
               "--uproject", str(up), "--rouvrir", str(up)]
    elif editor_open():
        raise ValueError("Unreal Editor est ouvert : ferme-le (en enregistrant) puis relance la compilation.")
    return jobs.lancer(f"compiler:{cible.kind}:{cible.id}", f"Compilation de {cible.nom}", cmd, cible.path(), 3600)


# ------------------------------------------------------------------ tests and installation
def python_console() -> str:
    """The studio runs under pythonw.exe (no console): pip and pytest go through the python.exe next to it."""
    exe = Path(sys.executable)
    if exe.name.lower() == "pythonw.exe" and (exe.parent / "python.exe").exists():
        return str(exe.parent / "python.exe")
    return sys.executable


def run_tests(studio, jobs: Jobs) -> dict:
    return jobs.lancer("tests", "Tests du studio", [python_console(), "-X", "utf8", "-m", "pytest", "-q", "tests"],
                          studio.paths.code, 1800)


PACKAGES = {"lecture": ("Lecture des PDF et des images (~140 Mo)", ("PyMuPDF", "pillow")),
           "parole": ("Lecture des sons et vidéos (~550 Mo, + modèle ~480 Mo à la 1re pièce sonore)", ("faster-whisper", "av")),
           "retro": ("Outils de rétro-ingénierie (~25 Mo)", ("pefile", "capstone", "lief", "kaitaistruct"))}
LOCKS = {"retro": "requirements-retro.lock.txt"}          # otherwise requirements-pieces.lock.txt
MODULES = {"lecture": (("pymupdf", "fitz"), ("PIL",)), "parole": (("faster_whisper",), ("av",)),
           "retro": (("pefile",), ("capstone",), ("lief",), ("kaitaistruct",))}      # each group: any one of the names is enough


def installed() -> dict:
    """Optional modules already present (without importing them): an install button already used disappears."""
    import importlib
    import importlib.util
    importlib.invalidate_caches()                        # also sees what was just installed, without restarting
    return {what: all(any(importlib.util.find_spec(n) for n in group) for group in groups)
            for what, groups in MODULES.items()}


def install(studio, jobs: Jobs, what: str) -> dict:
    if what not in PACKAGES:
        raise ValueError("Installation inconnue.")
    if installed().get(what):
        raise ValueError("Déjà installé : rien à faire.")
    title, names = PACKAGES[what]
    lock = studio.paths.code / LOCKS.get(what, "requirements-pieces.lock.txt")
    pinned = [l.strip() for l in lock.read_text(encoding="utf-8").splitlines() if l.strip() and not l.startswith("#")]
    packages = [l for l in pinned if l.split("==")[0].lower() in {n.lower() for n in names}]
    if what == "parole":
        packages = [l for l in pinned if l.split("==")[0].lower() in {"pymupdf", "pillow"}] + packages   # audio frames
    return jobs.lancer(f"installer:{what}", title, [python_console(), "-m", "pip", "install", "--disable-pip-version-check",
                                                        *packages], studio.paths.code, 1800)


# ------------------------------------------------------------------ workspace cleanup
def _size(d: Path) -> int:
    total = 0
    for root_dir, _, task_files in os.walk(d):
        for f in task_files:
            try:
                total += os.path.getsize(os.path.join(root_dir, f))
            except OSError:
                pass
    return total


def _base(studio, tid: str) -> str:
    try:
        return json.loads((studio.details_dir(tid) / "base.json").read_text(encoding="utf-8")).get("_worktree", "")
    except (OSError, ValueError):
        return ""


def workspaces(studio) -> list[dict]:
    """Task workspaces (worktrees), with size, task state and merge state."""
    git = studio.cfg["outils"].get("git", "git")
    runs = studio.paths.runs.resolve()
    out = []
    for cible in studio.registry.all():
        if cible.kind != "project" or cible.extra.get("isolation") != "worktree" or not cible.has_path or not cible.path().is_dir():
            continue
        try:
            entries = ws._git(git, cible.path(), "worktree", "list", "--porcelain")
        except ws.WorktreeError:
            continue
        for block in entries.strip().split("\n\n"):
            field_values = dict(l.split(" ", 1) for l in block.splitlines() if " " in l)
            chemin = Path(field_values.get("worktree", ""))
            try:
                rel = chemin.resolve().relative_to(runs)
            except (ValueError, OSError):
                continue                             # not a studio workspace (your folder, or another tool's)
            tid = studio.task_from_folder(rel.parts[0]) if rel.parts else ""
            try:
                task_status = studio.store.get(tid)["status"]
            except KeyError:
                task_status = "inconnue"
            if any(o["chemin"] == str(chemin) for o in out):
                continue                             # two targets on the same repository: a single row
            branch = f"studio/{tid}"
            base = _base(studio, tid)
            has_content = bool(base) and ws._succeeds(git, cible.path(), "rev-parse", "--verify", "-q", branch) and \
                ws._git(git, cible.path(), "rev-list", "--count", f"{base}..{branch}").strip() != "0"
            merged = has_content and ws._succeeds(git, cible.path(), "merge-base", "--is-ancestor", branch, "HEAD")
            copies = [p for p in studio.details_dir(tid, create_new=False).glob("relecture-*") if p.is_dir()] if tid else []
            out.append({"tache": tid, "projet": cible.nom, "chemin": str(chemin), "statut": task_status, "fusionnee": merged,
                        "vide": not has_content,
                        "octets": (_size(chemin) if chemin.is_dir() else 0) + sum(_size(p) for p in copies),
                        "retirable": task_status in TERMINAL})
    return out


def remove_workspace(studio, tid: str) -> dict:
    """Removes the workspace of a finished task (after the user's click). The approved work is already in its
    branch; the branch is deleted only if it is merged (git branch -d, never -D). The Taches\\<task> folder
    (result, diff, log) is kept."""
    git = studio.cfg["outils"].get("git", "git")
    t = studio.store.get(tid)
    if t["status"] not in TERMINAL:
        raise ValueError("La tâche n'est pas terminée : son espace reste.")
    cible = studio.registry.get(t["target"])
    user_workspace = studio.run_dir(tid) / ws.WORKSPACE
    if not (user_workspace / ".git").is_file():
        raise ValueError("Pas d'espace de travail git pour cette tâche.")
    if t["status"] in ("approuvee", "appliquee"):
        remaining_items = [l[3:] for l in ws._git(git, user_workspace, "status", "--porcelain", "--untracked-files=all").splitlines()
                  if l.strip() and not ws._skipped(l[3:].strip('"'), [])
                  and not l[3:].startswith(".agents/skills/")]
        if remaining_items:
            raise ValueError("L'espace contient des fichiers qui ne sont pas dans la branche validée : rien n'est retiré ("
                             + ", ".join(remaining_items[:5]) + ").")
        bj = studio.details_dir(tid) / "branche.json"
        valid = json.loads(bj.read_text(encoding="utf-8")).get("commit", "") if bj.exists() else ""
        if valid and not ws._succeeds(git, cible.path(), "merge-base", "--is-ancestor", valid, f"studio/{tid}"):
            raise ValueError("Le commit validé n'est plus sur la branche de la tâche : rien n'est retiré.")
    ws._git(git, cible.path(), "worktree", "remove", "--force", str(user_workspace), timeout=600)
    import shutil
    for copy_dir in studio.details_dir(tid).glob("relecture-*"):
        if copy_dir.is_dir():
            shutil.rmtree(copy_dir, ignore_errors=True)     # the auditor's disposable copies, can be recreated
    (studio.run_dir(tid) / ws.READY_MARKER).unlink(missing_ok=True)
    msg = "Espace retiré."
    base = _base(studio, tid)
    content = bool(base) and ws._git(git, cible.path(), "rev-list", "--count", f"{base}..studio/{tid}").strip() != "0"
    merged = content and ws._succeeds(git, cible.path(), "merge-base", "--is-ancestor", f"studio/{tid}", "HEAD")
    if merged or not content:
        try:
            ws._git(git, cible.path(), "branch", "-d", f"studio/{tid}")
            msg += f" Branche studio/{tid} supprimée ({'déjà fusionnée' if merged else 'vide'})."
        except ws.WorktreeError:
            msg += f" Branche studio/{tid} conservée."
    else:
        msg += f" Branche studio/{tid} conservée (pas fusionnée)."
    studio.store.event(tid, msg + " (par l'utilisateur depuis l'interface)")
    return {"etat": "ok", "message": msg}


# ------------------------------------------------------------------ versions of the subscription tools, update
NPM_PACKAGES = {"claude": "@anthropic-ai/claude-code", "codex": "@openai/codex"}
_latest: dict[str, tuple[float, str]] = {}


def latest_version(outil: str) -> str:
    """Latest published version (npm registry, public read, nothing is sent); cached for an hour; empty when offline."""
    import json as _json
    import urllib.request
    package = NPM_PACKAGES[outil]
    t, v = _latest.get(outil, (0.0, ""))
    if time.time() - t < 3600:
        return v
    v = ""
    for _ in range(2):                             # a transient failure does not leave « inconnue » for an hour
        try:
            req = urllib.request.Request(f"https://registry.npmjs.org/{package}/latest", headers={"User-Agent": "SuperAIStudio"})
            with urllib.request.urlopen(req, timeout=12) as r:
                v = str(_json.loads(r.read().decode("utf-8")).get("version", ""))
            break
        except Exception:                          # noqa: BLE001 — offline or registry unavailable: no info
            v = ""
    if v:
        _latest[outil] = (time.time(), v)
    return v


def ollama_version() -> dict:
    """Local model runner: installed version (local API, otherwise the command) and latest published (GitHub). Read-only."""
    import json as _json
    import shutil
    import urllib.request
    from .local_models import OLLAMA, ollama_executable
    inst = ""
    try:
        with urllib.request.urlopen(OLLAMA + "/api/version", timeout=2) as r:
            inst = str(_json.loads(r.read()).get("version", ""))
    except Exception:                              # noqa: BLE001 — not running: read the version from the command
        exe = ollama_executable()
        if exe:
            try:
                out = subprocess.run([exe, "--version"], capture_output=True, text=True, timeout=20, stdin=subprocess.DEVNULL, **NO_WINDOW)
                m = re.search(r"(\d+\.\d+\.\d+)", out.stdout + out.stderr)
                inst = m.group(1) if m else ""
            except (OSError, subprocess.TimeoutExpired):
                pass
    t, latest = _latest.get("ollama", (0.0, ""))
    if time.time() - t > 3600:
        try:
            req = urllib.request.Request("https://api.github.com/repos/ollama/ollama/releases/latest", headers={"User-Agent": "SuperAIStudio"})
            with urllib.request.urlopen(req, timeout=12) as r:
                latest = str(_json.loads(r.read()).get("tag_name", "")).lstrip("v")
            if latest:
                _latest["ollama"] = (time.time(), latest)
        except Exception:                          # noqa: BLE001
            latest = ""
    up_to_date = None
    if inst and latest:
        up_to_date = tuple(int(x) for x in re.findall(r"\d+", inst)[:3]) >= tuple(int(x) for x in re.findall(r"\d+", latest)[:3])
    winget = shutil.which("winget")
    return {"nom": "Ollama (modèles locaux)", "chemin": ollama_executable() or "", "installee": inst, "derniere": latest, "a_jour": up_to_date,
            "methode": "Ollama se met à jour seul (icône Ollama › Restart to update)" + (" ou : winget upgrade --id Ollama.Ollama -e" if winget else ""),
            "possible": False}


def _installed_version(exe: str | None) -> str:
    from .connectors.claude_code import parse_version
    if not exe:
        return ""
    try:
        out = subprocess.run([exe, "--version"], capture_output=True, text=True, timeout=30, encoding="utf-8",
                             errors="replace", stdin=subprocess.DEVNULL, **NO_WINDOW)
        return ".".join(map(str, parse_version(out.stdout or out.stderr)))
    except (OSError, subprocess.TimeoutExpired):
        return ""


def _update_command(outil: str, exe: str | None) -> tuple[list[str] | None, str]:
    """How to update the tool as it is installed on this PC (never guessing at random)."""
    import shutil
    if not exe:
        return None, "introuvable"
    bottom = exe.replace("\\", "/").lower()
    if outil == "claude":
        return [exe, "update"], "claude update"
    if "/openai/codex/bin/" in bottom:
        return None, "mis à jour par l'application Codex (ouvre-la : elle se met à jour seule)"
    npm = shutil.which("npm")
    if npm and ("/npm/" in bottom or bottom.endswith(".cmd")):
        return [npm, "install", "-g", f"{NPM_PACKAGES['codex']}@latest"], "npm install -g @openai/codex@latest"
    return None, "installation non reconnue : mets Codex à jour comme tu l'as installé"


def versions(studio) -> dict:
    from .connectors.base import find_exe
    from .connectors.claude_code import WIN_CANDIDATES as CC
    from .connectors.codex import WIN_CANDIDATES as CX
    out = {}
    for outil, cand, nom in (("claude", CC, "Claude Code"), ("codex", CX, "Codex")):
        exe = find_exe(studio.cfg["outils"].get(outil, outil), cand)
        inst, latest = _installed_version(exe), latest_version(outil)
        cmd, rpc_method = _update_command(outil, exe)
        up_to_date = None
        if inst and latest:
            up_to_date = tuple(int(x) for x in inst.split(".")) >= tuple(int(x) for x in re.findall(r"\d+", latest)[:3])
        out[outil] = {"nom": nom, "chemin": exe or "", "installee": inst, "derniere": latest, "a_jour": up_to_date,
                      "methode": rpc_method, "possible": bool(cmd)}
    o = ollama_version()
    if o["installee"] or o["chemin"]:                 # shown only if the local model runner is on the PC
        out["ollama"] = o
    return out


def apply_update(studio, jobs: Jobs, outil: str) -> dict:
    """Updates a subscription tool in the background. Refused while a task is running (the tool would be replaced
    mid-work). Model aliases (opus, sonnet, haiku) automatically follow new models."""
    from .connectors.base import find_exe
    from .connectors.claude_code import WIN_CANDIDATES as CC
    from .connectors.codex import WIN_CANDIDATES as CX
    if outil not in NPM_PACKAGES:
        raise ValueError("Outil inconnu.")
    with studio.store.db() as c:                  # busy slots = agents actually working (fixes included)
        from .orchestrator.store import pid_alive         # a slot left by a vanished process does not block
        busy_count = sum(1 for r in c.execute("SELECT pid FROM slots WHERE task_id IS NOT NULL") if pid_alive(r[0]))
    active_tasks = [t for t in studio.store.list(200) if t["status"] in ("creee", "en_cours", "en_attente_creneau")]
    if busy_count or active_tasks:
        raise RuntimeError(f"{max(busy_count, len(active_tasks))} tâche(s) en cours : attends qu'elles finissent avant de mettre à jour.")
    exe = find_exe(studio.cfg["outils"].get(outil, outil), CC if outil == "claude" else CX)
    cmd, rpc_method = _update_command(outil, exe)
    if not cmd:
        raise ValueError(f"Mise à jour automatique impossible : {rpc_method}.")

    def after(code, output):                       # the new version is read again on the next call
        for ex in list(getattr(studio, "executors", {}).values()) + list(getattr(studio, "auditors", {}).values()):
            for attr in ("_version", "_effort"):
                if hasattr(ex, attr):
                    setattr(ex, attr, None)
        _latest.pop(outil, None)
    nom = "Claude Code" if outil == "claude" else "Codex"
    return jobs.lancer(f"maj:{outil}", f"Mise à jour de {nom}", cmd, studio.paths.code, 900, after=after)
