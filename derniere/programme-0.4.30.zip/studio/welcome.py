"""First launch: connect an AI (cloud or local), then GitHub, in a few clicks; and the guided tour.

Nothing installs without a user click: each installation opens a visible window on the PC
(Windows: winget or the official installer; Mac and Linux: the official command in a terminal, or to copy).
"""
from __future__ import annotations

import json
import re
import shutil
import subprocess
import sys
from pathlib import Path

LINKS = {
    "ollama": "https://ollama.com/download",
    "git": "https://git-scm.com/downloads",
    "claude": "https://claude.com/product/claude-code",
    "codex": "https://developers.openai.com/codex/cli",
    "node": "https://nodejs.org",
}

# Official commands, per platform. Windows: winget (shipped with Windows 10/11) or official script.
_WIN = {
    "ollama": "winget install --id Ollama.Ollama -e",
    "git": "winget install --id Git.Git -e",
    "claude": "powershell -NoProfile -ExecutionPolicy Bypass -Command \"irm https://claude.ai/install.ps1 | iex\"",
    "codex": "winget install --id OpenJS.NodeJS.LTS -e",          # Node.js first; the CLI on the next click
}
_MAC = {
    "ollama": "brew install ollama",
    "git": "xcode-select --install",
    "claude": "curl -fsSL https://claude.ai/install.sh | bash",
    "codex": "brew install --cask codex",
}
_LINUX = {
    "ollama": "curl -fsSL https://ollama.com/install.sh | sh",
    "git": "sudo apt install -y git || sudo dnf install -y git",
    "claude": "curl -fsSL https://claude.ai/install.sh | bash",
    "codex": "npm install -g @openai/codex",
}


def os_support() -> str:
    return "windows" if sys.platform == "win32" else "mac" if sys.platform == "darwin" else "linux"


def command(outil: str) -> str:
    table = {"windows": _WIN, "mac": _MAC, "linux": _LINUX}[os_support()]
    if outil == "codex" and os_support() == "windows" and shutil.which("npm"):
        return "npm install -g @openai/codex"
    if outil == "claude" and os_support() == "windows" and not shutil.which("git"):
        return "winget install --id Git.Git -e && " + _WIN["claude"]       # the subscription tool on Windows needs Git
    if outil == "codex" and os_support() == "mac" and not shutil.which("brew") and shutil.which("npm"):
        return "npm install -g @openai/codex"
    return table.get(outil, "")


def _file(data: Path) -> Path:
    return Path(data) / "accueil.json"


def read_file(data: Path) -> dict:
    try:
        d = json.loads(_file(data).read_text(encoding="utf-8"))
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def jot(data: Path, **value_map) -> dict:
    d = {**read_file(data), **{k: bool(v) for k, v in value_map.items() if k in ("fini", "visite")}}
    _file(data).write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")
    return d


def _memory_go(note: str) -> float | None:
    m = re.search(r"≈\s*(\d+(?:[.,]\d+)?)\s*Go", note or "")
    return float(m.group(1).replace(",", ".")) if m else None


def recommended_models(catalog: list[dict], ram_gb: float | None, vram_gb: float | None) -> list[dict]:
    """Local models from the catalog with what they require and whether they fit on this PC.
    "rapide" = fits in the graphics card; "possible" = fits in memory (slower); otherwise too big."""
    seen_items, output = set(), []
    for m in sorted((m for m in catalog if m.get("local") and m.get("categorie") == "global"), key=lambda m: -(m.get("score") or 0)):
        nom = m.get("ollama") or m.get("cle")
        if not nom or nom in seen_items:
            continue
        seen_items.add(nom)
        go = _memory_go(m.get("note", ""))
        if go is None:
            fits = "inconnu"
        elif vram_gb and go <= vram_gb:
            fits = "rapide"
        elif ram_gb and go <= ram_gb * 0.75:
            fits = "possible"
        else:
            fits = "trop_gros"
        output.append({"nom": nom, "titre": m.get("nom", nom), "score": m.get("score"), "memoire_go": go, "tient": fits,
                       "note": (m.get("note", "").split("—", 1)[1].strip() if "—" in m.get("note", "") else "")})
    rank = {"rapide": 0, "possible": 1, "inconnu": 2, "trop_gros": 3}
    best = min(output, key=lambda x: (rank[x["tient"]], -(x["score"] or 0)), default=None)
    for x in output:
        x["conseille"] = x is best and x["tient"] in ("rapide", "possible")
    return output


def _vram_windows() -> float | None:
    """Graphics card memory (any brand) read from the Windows registry; None elsewhere or if missing."""
    if sys.platform != "win32":
        return None
    try:
        import winreg
        base = r"SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}"
        best = 0
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, base) as k:
            for i in range(32):
                try:
                    with winreg.OpenKey(k, f"{i:04d}") as s:
                        v, _ = winreg.QueryValueEx(s, "HardwareInformation.qwMemorySize")
                        best = max(best, int(v if isinstance(v, int) else int.from_bytes(v, "little")))
                except OSError:
                    continue
        return round(best / 2**30, 1) or None
    except (OSError, ImportError, ValueError):
        return None


def _execute(cmd: list[str], delay: float = 6) -> tuple[int, str]:
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=delay,
                           **({"creationflags": 0x08000000} if sys.platform == "win32" else {}))
        return r.returncode, (r.stdout or "") + (r.stderr or "")
    except (OSError, subprocess.SubprocessError):
        return -1, ""


def github_connected() -> bool | None:
    """True if a GitHub account is registered (gh or Git's credential manager). None: impossible to tell."""
    if shutil.which("gh"):
        return _execute(["gh", "auth", "status"])[0] == 0
    if shutil.which("git"):
        code, output = _execute(["git", "credential-manager", "github", "list"])
        if code == 0:
            return bool(output.strip())
    return None


def etat(studio, home: Path | None = None) -> dict:
    """What the welcome screen shows: AIs already ready, Ollama, Git/GitHub, models suited to the PC."""
    from . import agents, ai, local_models, system
    from .connectors.base import find_exe
    from .connectors.claude_code import WIN_CANDIDATES
    home = home or Path.home()
    data = studio.paths.data
    claude = bool(find_exe(studio.cfg["outils"].get("claude", "claude"), WIN_CANDIDATES))
    codex = bool(find_exe(studio.cfg["outils"].get("codex", "codex")))
    connections = [c for c in ai.public(data).get("connexions", [])]
    claude_ok = claude and ((home / ".claude" / ".credentials.json").is_file() or sys.platform == "darwin")
    codex_ok = codex and (home / ".codex" / "auth.json").is_file()
    installed = local_models.installed()
    r = system.survey()
    gpu = r.get("gpu") or {}
    ram_gb = (r.get("ram") or {}).get("total_go")
    vram = gpu.get("vram_total_go") or _vram_windows()
    if not vram and sys.platform == "darwin" and ram_gb:
        import platform
        if platform.machine() == "arm64":
            vram = round(ram_gb * 0.66, 1)            # Apple Silicon Mac: unified memory, two thirds for the AI
    git = bool(shutil.which("git"))
    ready = bool(connections) or claude_ok or codex_ok
    d = read_file(data)
    return {
        "fini": bool(d.get("fini")), "visite": bool(d.get("visite")), "pret": ready, "plateforme": os_support(),
        "winget": bool(shutil.which("winget")) if os_support() == "windows" else False,
        "claude": {"installe": claude, "connecte": claude_ok, "commande": command("claude")},
        "codex": {"installe": codex, "connecte": codex_ok, "commande": command("codex")},
        "connexions": [{"fournisseur": c.get("fournisseur"), "nom": c.get("nom"), "modele": c.get("modele")} for c in connections],
        "ollama": {"installe": bool(local_models.ollama_executable()), "ouvert": installed is not None,
                   "modeles": installed or [], "commande": command("ollama"), "lien": LINKS["ollama"]},
        "pc": {"ram_go": ram_gb, "vram_go": vram, "gpu": gpu.get("nom", "")},
        "conseilles": recommended_models(agents.benchmarks(data)["modeles"], ram_gb, vram),
        "git": {"installe": git, "github": github_connected() if git else False, "commande": command("git"), "lien": LINKS["git"]},
    }


def _console(title: str, cmd: str) -> None:
    """Opens a visible window that runs the command; the user sees everything and can close it."""
    if sys.platform == "win32":
        subprocess.Popen(["cmd", "/c", "start", title, "cmd", "/k", cmd], creationflags=0x00000010)
    elif sys.platform == "darwin":
        script = cmd.replace("\\", "\\\\").replace('"', '\\"')
        subprocess.Popen(["osascript", "-e", f'tell application "Terminal" to do script "{script}"'], start_new_session=True)
    else:
        for t in (["x-terminal-emulator", "-e"], ["gnome-terminal", "--"], ["konsole", "-e"], ["xfce4-terminal", "-x"], ["xterm", "-e"]):
            if shutil.which(t[0]):
                subprocess.Popen([*t, "bash", "-c", cmd + "; exec bash"], start_new_session=True)
                return
        raise ValueError("Aucun terminal trouvé : copie la commande dans un terminal.")


def install(outil: str) -> dict:
    """Installs a tool on click (visible window). Without winget or a terminal: returns the command and the link."""
    if outil not in ("ollama", "git", "claude", "codex"):
        raise ValueError("Outil inconnu.")
    cmd = command(outil)
    names = {"ollama": "Ollama", "git": "Git", "claude": "Claude Code", "codex": "Codex"}
    if os_support() == "windows" and cmd.startswith("winget") and not shutil.which("winget"):
        return {"ok": False, "lien": LINKS[outil], "info": f"Installe {names[outil]} depuis son site, puis reviens ici."}
    if os_support() == "mac" and cmd.startswith("brew") and not shutil.which("brew"):
        return {"ok": False, "lien": LINKS[outil], "commande": cmd, "info": f"Installe {names[outil]} depuis son site, puis reviens ici."}
    try:
        _console(f"Installation de {names[outil]}", cmd)
    except (OSError, ValueError) as e:
        return {"ok": False, "commande": cmd, "lien": LINKS[outil], "info": str(e)}
    if outil == "codex" and "NodeJS" in cmd:
        return {"ok": True, "info": "Codex a besoin de Node.js : une fenêtre l'installe. Ensuite, reclique « Installer » pour Codex."}
    return {"ok": True, "info": f"Une fenêtre d'installation de {names[outil]} s'est ouverte : suis-la, puis clique « Vérifier »."}


def connect_github() -> dict:
    """GitHub sign-in in the browser (gh or the credential manager shipped with Git)."""
    if shutil.which("gh"):
        cmd = "gh auth login --web --git-protocol https"
    elif shutil.which("git"):
        cmd = "git credential-manager github login"
    else:
        raise ValueError("Installe d'abord Git.")
    _console("Connexion GitHub", cmd)
    return {"ok": True, "info": "Une fenêtre de connexion GitHub s'est ouverte : suis-la (le navigateur s'ouvre), puis clique « Vérifier »."}
