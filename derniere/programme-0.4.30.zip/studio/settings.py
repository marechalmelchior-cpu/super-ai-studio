"""Studio settings editable from Gestion (« Réglages » column).

Closed list: only these keys can be written, with their type and allowed values. Each write:
1. first copies ``studio.config.toml`` into ``Studio/data/config-avant/`` (nothing is ever deleted);
2. replaces ONE ``cle = valeur`` line in the section (comments and rest of the file kept; key added if missing);
3. checks that the file is still valid TOML, then writes it atomically;
4. updates the in-memory configuration. Settings read only at startup say so (``redemarrage``).
"""
from __future__ import annotations

import re
import shutil
import tomllib
from datetime import datetime
from pathlib import Path

# (section, key) → description
SETTINGS: dict[tuple[str, str], dict] = {
    ("superviseur", "web"): {"type": "bool", "libelle": "Recherche sur le web", "groupe": "Superviseur"},
    ("utilisateur", "nom"): {"type": "texte", "libelle": "Ton prénom (agents et Superviseur)", "groupe": "Superviseur"},
    ("utilisateur", "langue"): {"type": "str", "choix": ["fr", "en"], "libelle": "Langue · Language (fr / en)", "groupe": "Superviseur"},
    ("superviseur", "bilan"): {"type": "bool", "libelle": "Bilan du Superviseur à la fin de chaque tâche", "groupe": "Superviseur"},
    ("usage", "limites_claude"): {"type": "bool", "libelle": "Limites Claude en % (Gestion › Usage)", "groupe": "Limites et alertes"},
    ("usage", "limites_codex"): {"type": "bool", "libelle": "Limites Codex en % (Gestion › Usage)", "groupe": "Limites et alertes"},
    ("usage", "alerte_claude_5h_min"): {"type": "int", "choix": [0, 15, 30, 60, 90, 120], "unite": "min",
                                        "libelle": "Alerte : limite Claude atteinte dans moins de", "groupe": "Limites et alertes"},
    ("usage", "alerte_codex_5h_min"): {"type": "int", "choix": [0, 15, 30, 60, 90, 120], "unite": "min",
                                       "libelle": "Alerte : limite Codex atteinte dans moins de", "groupe": "Limites et alertes"},
    ("limites", "autonomie"): {"type": "str", "choix": ["complete", "validation"],
                               "libelle": "Tâches : finir seules (complete) ou attendre ma validation", "groupe": "Exécution des tâches"},
    ("limites", "taches_simultanees"): {"type": "int", "choix": [1, 2, 3, 4], "redemarrage": True,
                                        "libelle": "Tâches en parallèle", "groupe": "Exécution des tâches"},
    ("limites", "corrections_max"): {"type": "int", "choix": [0, 1, 2, 3],
                                     "libelle": "Corrections auto après relecture", "groupe": "Exécution des tâches"},
    ("audit", "auditeur_modele"): {"type": "bool", "redemarrage": True,
                                   "libelle": "Relecture par un second modèle", "groupe": "Exécution des tâches"},
    # Effort levels follow each AI's own models (chosen per task, per agent or in the Supervisor's header);
    # MCP servers are chosen per project (project › Équipe), never here.
    ("agents_api", "commandes"): {"type": "str", "choix": ["sures", "toutes", "non"],
                                  "libelle": "Commandes des IA connectées par clé ou en local (sures = tests et compilation)", "groupe": "Technique"},
    ("agents_api", "contexte_local"): {"type": "int", "choix": [8192, 16384, 32768, 65536, 131072], "unite": "jetons",
                                       "libelle": "IA locales : mémoire de travail max (plus = plus de mémoire vidéo)",
                                       "groupe": "Technique"},
    ("nuit", "debut"): {"type": "str", "choix": ["22:00", "23:00", "00:00", "01:00", "02:00", "03:00"],
                        "libelle": "Tâches de nuit : début", "groupe": "Exécution des tâches"},
    ("nuit", "fin"): {"type": "str", "choix": ["05:00", "06:00", "07:00", "08:00", "09:00"],
                      "libelle": "Tâches de nuit : fin (rapport ensuite)", "groupe": "Exécution des tâches"},
    ("entretien", "menage_auto"): {"type": "bool", "libelle": "Ménage automatique (vieilles sauvegardes, copies et caches)", "groupe": "Entretien"},
    ("interface", "acces_mobile"): {"type": "bool", "cache": True,          # button on the « Téléphone » card
                                    "libelle": "Accès depuis le téléphone (Tailscale)", "groupe": "Téléphone"},
    ("outils", "blender"): {"type": "chemin", "cache": True, "libelle": "Blender (blender.exe)", "groupe": "Connecteurs"},
    ("outils", "unreal_editor_cmd"): {"type": "chemin", "cache": True, "libelle": "Unreal (UnrealEditor-Cmd.exe)", "groupe": "Connecteurs"},
}


def entries(cfg: dict) -> list[dict]:
    """Settings with their current value, in display order."""
    return [{"section": s, "cle": k, "valeur": cfg.get(s, {}).get(k), **d} for (s, k), d in SETTINGS.items() if not d.get("cache")]


def validate(section: str, cle: str, valeur):
    d = SETTINGS.get((section, cle))
    if not d:
        raise ValueError("Réglage inconnu.")
    t = d["type"]
    if t == "bool":
        if not isinstance(valeur, bool):
            raise ValueError("Oui ou non attendu.")
        return valeur
    if t == "int":
        try:
            v = int(valeur)
        except (TypeError, ValueError):
            raise ValueError("Nombre attendu.") from None
        if "choix" in d and v not in d["choix"]:
            raise ValueError("Valeur non proposée.")
        return v
    v = str(valeur or "").strip()
    if t == "texte" and not (0 < len(v) <= 40):
        raise ValueError("Entre 1 et 40 caractères.")
    if "'" in v or "\n" in v or "\r" in v or len(v) > 400:
        raise ValueError("Valeur invalide.")
    if "choix" in d and v not in d["choix"]:
        raise ValueError("Valeur non proposée.")
    return v


def _literal(v) -> str:
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, int):
        return str(v)
    return f"'{v}'"                       # TOML literal string: the \ in Windows paths stay as they are


def store_file(path: Path, section: str, cle: str, valeur) -> Path:
    """Writes a value to the file; returns the copy made before the change."""
    path = Path(path)
    texte = path.read_text(encoding="utf-8")
    line = f"{cle} = {_literal(valeur)}"
    begin = re.search(rf"(?m)^\[{re.escape(section)}\]\s*$", texte)
    if not begin:
        new_name = texte.rstrip("\n") + f"\n\n[{section}]\n{line}\n"
    else:
        finish = re.search(r"(?m)^\[", texte[begin.end():])
        zone = texte[begin.end(): begin.end() + finish.start()] if finish else texte[begin.end():]
        pattern = re.compile(rf"(?m)^({re.escape(cle)}\s*=\s*)(\"[^\"\n]*\"|'[^'\n]*'|true|false|-?\d+(?:\.\d+)?)([ \t]*#.*)?$")
        if pattern.search(zone):
            zone2 = pattern.sub(lambda m: f"{m.group(1)}{_literal(valeur)}{m.group(3) or ''}", zone, count=1)
        else:
            zone2 = zone.rstrip("\n") + f"\n{line}\n" + ("\n" if finish else "")
            if not zone.strip():
                zone2 = f"\n{line}\n" + ("\n" if finish else "")
        new_name = texte[: begin.end()] + zone2 + texte[begin.end() + len(zone):]
    parsed = tomllib.loads(new_name)                          # the file must stay valid…
    if parsed.get(section, {}).get(cle) != valeur:           # …and contain exactly the new value
        raise ValueError("Écriture non vérifiée : rien n'est modifié.")
    copies = path.parent / "data" / "config-avant"
    copies.mkdir(parents=True, exist_ok=True)
    copy_dir = copies / f"studio.config-{datetime.now().strftime('%Y%m%d-%H%M%S-%f')}.toml"
    shutil.copy2(path, copy_dir)
    try:
        from .cleanup import cap
        cap(copies, "studio.config-*.toml", 10)     # the last 10 copies kept
    except Exception:                                   # noqa: BLE001
        pass
    tmp = path.with_suffix(".tmp")
    tmp.write_text(new_name, encoding="utf-8", newline="")
    tmp.replace(path)
    return copy_dir


def modify(cfg: dict, path: Path, section: str, cle: str, valeur) -> dict:
    v = validate(section, cle, valeur)
    store_file(path, section, cle, v)
    cfg.setdefault(section, {})[cle] = v
    d = SETTINGS[(section, cle)]
    return {"ok": True, "valeur": v, "redemarrage": bool(d.get("redemarrage")),
            "message": "Enregistré : pris en compte au prochain démarrage du studio." if d.get("redemarrage") else "Enregistré."}
