"""Studio configuration (TOML, read-only via tomllib)."""
from __future__ import annotations

import copy
import tomllib
from pathlib import Path
from typing import Any

DEFAULTS: dict[str, Any] = {
    "limites": {
        "taches_simultanees": 1,        # low concurrency to start
        "duree_max_etape_s": 900,       # timeout for a tool call
        "duree_max_tache_s": 3600,      # per run (waiting for approval does not count)
        "corrections_max": 2,           # retries after audit
        "autonomie": "complete",        # « complete »: review OK → validated, applied, merged automatically; « validation »: the user validates
    },
    "memoire": {
        # "agentmemory" = chosen technology; "sqlite" = explicit local alternative.
        "backend": "agentmemory",
        "url": "http://127.0.0.1:3111",
        "delai_s": 5.0,
        "en_cas_de_panne": "continuer_signale",   # or "bloquer"
        "ttl_jours_tache": 14,
    },
    "outils": {
        "claude": "claude",
        "codex": "codex",
        "blender": "",
        "unreal_editor_cmd": "",
        "git": "git",
        "mcp_unreal": "tout",            # agents: full access to unreal-mcp; « lecture » = read actions only
    },
    "interface": {"hote": "127.0.0.1", "port": 8765, "acces_mobile": False},
    "utilisateur": {"nom": "", "langue": "fr"},
    "entretien": {"menage_auto": True},     # daily cleanup of technical files (studio/cleanup.py): never projects or results   # language: fr or en (Supervisor, agents, interface)         # first name (Réglages › « Ton prénom »); empty = neutral texts
    "benchmarks": {"url": ""},          # full up-to-date rankings (same format as modeles/benchmarks.json); empty = today's prices only
    "audit": {"auditeur_modele": True},
    "agents_api": {"commandes": "sures", "contexte_local": 32768},   # contexte_local: max working memory of local models (tokens)
    "nuit": {"debut": "01:00", "fin": "07:00"},   # « Cette nuit » tasks: start within this window (PC time)  # agent commands via API key / local AI: non | sures | toutes
    "superviseur": {"web": True, "bilan": True, "modele": "", "modele_rapide": "haiku", "delai_s": 300},   # Request window: CLI tool in read-only mode
    # Attachments made readable (studio/attachments.py); speech model stored in Studio/data/modeles-parole
    "pieces": {"modele_parole": "small", "dossier_modeles": ""},
    "usage": {"alerte_claude_5h_min": 60, "alerte_codex_5h_min": 60, "limites_claude": True, "limites_codex": True},   # alert: limit reached in less than N min at the current rate
    "choix": {"modeles_claude": ["opus", "sonnet", "haiku"], "codex_effort_max": "high"},
}


def _merge(base: dict, extra: dict) -> dict:
    out = copy.deepcopy(base)
    for k, v in extra.items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _merge(out[k], v)
        else:
            out[k] = v
    return out


def load_config(path: Path | None) -> dict[str, Any]:
    cfg = copy.deepcopy(DEFAULTS)
    if path and Path(path).exists():
        with open(path, "rb") as fh:
            cfg = _merge(cfg, tomllib.load(fh))
    host = cfg["interface"]["hote"]
    if host not in ("127.0.0.1", "localhost"):
        raise ValueError("L'interface du studio doit rester locale (127.0.0.1).")
    return cfg


def set_tool(path: Path, cle: str, valeur: str) -> None:
    """Change a single ``cle = …`` line in the [outils] section (comments and the rest of the file preserved)."""
    import re
    if "'" in valeur or "\n" in valeur:
        raise ValueError("Chemin invalide.")
    texte = Path(path).read_text(encoding="utf-8")
    begin = re.search(r"(?m)^\[outils\]\s*$", texte)
    if not begin:
        raise ValueError("Section [outils] absente.")
    finish = re.search(r"(?m)^\[", texte[begin.end():])
    zone = texte[begin.end(): begin.end() + finish.start()] if finish else texte[begin.end():]
    pattern = re.compile(rf"(?m)^({re.escape(cle)}\s*=\s*)(\"[^\"]*\"|'[^']*')([ \t]*#.*)?$")
    if not pattern.search(zone):
        raise ValueError(f"Clé « {cle} » absente de [outils].")
    zone2 = pattern.sub(lambda m: f"{m.group(1)}'{valeur}'{m.group(3) or ''}", zone, count=1)
    new_name = texte[: begin.end()] + zone2 + texte[begin.end() + len(zone):]
    tomllib.loads(new_name)
    tmp = Path(path).with_suffix(".tmp")
    tmp.write_text(new_name, encoding="utf-8", newline="")
    tmp.replace(path)


def find_blender() -> list[str]:
    """Look for blender.exe: Steam libraries (registry + libraryfolders.vdf), Program Files, PATH."""
    import os
    import re
    import shutil
    import sys
    seen_items: list[str] = []
    steam: list[Path] = []
    if sys.platform == "win32":
        try:
            import winreg
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Valve\Steam") as k:
                steam.append(Path(winreg.QueryValueEx(k, "SteamPath")[0]))
        except OSError:
            pass
    for base in (os.environ.get("ProgramFiles(x86)"), os.environ.get("ProgramFiles")):
        if base:
            steam.append(Path(base) / "Steam")
    libs: list[Path] = []
    for s in steam:
        libs.append(s)
        vdf = s / "steamapps" / "libraryfolders.vdf"
        if vdf.exists():
            libs += [Path(p.replace("\\\\", "\\")) for p in re.findall(r'"path"\s+"([^"]+)"', vdf.read_text(encoding="utf-8", errors="replace"))]
    candidates = [lib / "steamapps" / "common" / "Blender" / "blender.exe" for lib in libs]
    for base in (os.environ.get("ProgramFiles"),):
        if base:
            candidates += sorted((Path(base) / "Blender Foundation").glob("*/blender.exe"), reverse=True)
    w = shutil.which("blender")
    if w:
        candidates.append(Path(w))
    for c in candidates:
        if c.is_file() and str(c) not in seen_items:
            seen_items.append(str(c))
    return seen_items
