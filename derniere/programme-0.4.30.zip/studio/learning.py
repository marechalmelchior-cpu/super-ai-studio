"""« Tes résultats »: the studio learns from your own tasks which model does each type of work best.

For each finished task: the trade (type of work), the AI and model that did it, whether it was validated on the
first try (no « corriger » from you nor resume after audit), the time and the cost. Nothing leaves the PC.
"""
from __future__ import annotations

import json

FINISHED = ("approuvee", "appliquee", "annulee", "echec")
MIN_TASKS = 3                      # below this, not enough hindsight to advise


def _tasks(store) -> list[dict]:
    with store.db() as c:
        rows = c.execute("SELECT t.id, t.status, t.options, "
                           "(SELECT COUNT(*) FROM approvals a WHERE a.task_id=t.id AND a.decision='corriger') AS corrections, "
                           "(SELECT MAX(attempt) FROM steps s WHERE s.task_id=t.id) AS tentatives "
                           "FROM tasks t WHERE t.status IN (?,?,?,?) AND json_extract(t.options,'$.bilan') IS NOT NULL",
                           FINISHED).fetchall()
    out = []
    for r in rows:
        b = (json.loads(r["options"] or "{}").get("bilan") or {})
        if not b.get("famille"):
            continue
        succeeded = r["status"] in ("approuvee", "appliquee")
        out.append({"role": b.get("role", ""), "ia": b["famille"] + (f" · {b['modele']}" if b.get("modele") else ""),
                    "reussie": succeeded, "premier_coup": succeeded and not r["corrections"] and (r["tentatives"] or 1) <= 1,
                    "duree_s": float(b.get("duree_s") or 0), "cout_usd": b.get("cout_usd")})
    return out


def results(studio) -> dict:
    """Per type of work then per model: count, first-try success, final success, average time and cost."""
    groups: dict[tuple[str, str], list[dict]] = {}
    for t in _tasks(studio.store):
        groups.setdefault((t["role"], t["ia"]), []).append(t)
    names = {r.id: r.nom for r in studio.roles.values()}
    rows = []
    for (role, ai), ts in groups.items():
        costs = [t["cout_usd"] for t in ts if t["cout_usd"] is not None]
        rows.append({"role": role, "travail": names.get(role, role or "—"), "ia": ai, "taches": len(ts),
                       "premier_coup": sum(t["premier_coup"] for t in ts), "reussies": sum(t["reussie"] for t in ts),
                       "duree_moy_s": round(sum(t["duree_s"] for t in ts) / len(ts)),
                       "cout_moy_usd": round(sum(costs) / len(costs), 4) if costs else None})
    rows.sort(key=lambda x: (x["travail"].lower(), -x["premier_coup"] / x["taches"], -x["taches"]))
    return {"lignes": rows, "total": sum(x["taches"] for x in rows), "min": MIN_TASKS}


def advice(studio, role: str) -> dict | None:
    """Best model for this type of work based on your tasks (at least MIN_TACHES), otherwise None."""
    if not role:
        return None
    cands = [x for x in results(studio)["lignes"] if x["role"] == role and x["taches"] >= MIN_TASKS]
    if not cands:
        return None
    best = max(cands, key=lambda x: (x["premier_coup"] / x["taches"], x["reussies"] / x["taches"],
                                      -(x["cout_moy_usd"] or 0), -x["duree_moy_s"]))
    return {"ia": best["ia"], "premier_coup": best["premier_coup"], "taches": best["taches"],
            "texte": f"D'après tes tâches : {best['ia']} réussit ce travail du premier coup {best['premier_coup']} fois sur {best['taches']}."}
