"""Task chains: several steps (one role + one request each) on the same target, run one after another.

Each step is an ordinary task: it waits for the user's validation. If the project works on a branch (worktree),
the next step also waits for the merge; if the project is applied by hand, it waits for the user to confirm it was applied
(« Continuer ») — it always starts from validated work, with the previous step's report. A cancelled or failed step pauses
the chain: the user resumes it (the step is relaunched) or stops it. Nothing starts without a user click at the outset, and each step
stays subject to validation.
"""
from __future__ import annotations

import threading
import uuid
from datetime import datetime

_lock = threading.Lock()
MAX_STEPS = 8


def create_new(studio, cible: str, title: str, stages: list[dict], options: dict | None = None) -> tuple[str, str]:
    """Saves the chain and creates the task for step 1 (to be launched by the caller). Returns (chain, task)."""
    own = []
    for e in stages or []:
        demande = str((e or {}).get("demande", "")).strip()
        role = str((e or {}).get("role", "")).strip()
        if not demande:
            continue
        if role and (role not in studio.roles or role == "auditeur"):
            raise ValueError(f"Rôle inconnu pour une étape : {role}")
        own.append({"role": role, "demande": demande[:4000]})
    if len(own) < 2:
        raise ValueError("Une chaîne demande au moins deux étapes.")
    if len(own) > MAX_STEPS:
        raise ValueError(f"{MAX_STEPS} étapes au plus par chaîne.")
    t = studio.registry.get(cible)
    cible = f"{t.kind}:{t.id}"
    title = (str(title or "").strip() or own[0]["demande"].splitlines()[0])[:120]
    opts = {k: v for k, v in (options or {}).items() if k in ("modele", "mode", "effort", "pieces") and v}   # attachments: step 1
    cid = "C" + datetime.now().strftime("%Y%m%d-%H%M%S-") + uuid.uuid4().hex[:4]
    studio.store.create_chain(cid, cible, title, own, opts)
    return cid, _launch_step(studio, cid, 0, "")


def _launch_step(studio, cid: str, i: int, previous: str) -> str:
    ch = studio.store.chain(cid)
    e = ch["etapes"][i]
    texte = (e["demande"] + f"\n\n---\nÉtape {i + 1}/{len(ch['etapes'])} de la chaîne « {ch['titre']} »."
             + (f"\nÉtape précédente, validée par l'utilisateur :\n{previous}" if previous else ""))
    opts = {**{k: v for k, v in ch["options"].items() if k != "pieces" or i == 0}, "chaine": cid, "etape": i,
            **({"role": e["role"]} if e["role"] else {})}
    tid = studio.create(ch["cible"], texte, **opts)
    ch["etapes"][i]["tache"] = tid
    ch["etapes"][i]["contexte"] = previous              # kept: a resumed step restarts with the same context
    studio.store.update_chain(cid, etapes=ch["etapes"], courant=i, statut="en_cours", note="")
    studio.store.event(tid, f"Chaîne {cid} — étape {i + 1}/{len(ch['etapes'])}")
    return tid


def _report(studio, tid: str) -> str:
    """What the step really produced: the runner's summary (last attempt) and files touched."""
    import json
    import re
    t = studio.store.get(tid)
    rd = studio.details_dir(tid)
    resume = ""
    execs = sorted(rd.glob("execution-*.json"), key=lambda p: int(re.sub(r"\D", "", p.stem) or 0))
    if execs:
        try:
            resume = json.loads(execs[-1].read_text(encoding="utf-8")).get("summary", "")
        except (OSError, ValueError):
            resume = ""
    task_files = []
    try:
        task_files = [a.get("path") or a.get("chemin") or "" for a in studio.store.artifacts(tid)][:30]
    except Exception:                              # noqa: BLE001 — optional
        task_files = []
    role = studio.roles.get((t.get("options") or {}).get("role", ""))
    rows = [f"- Rôle : {role.nom if role else 'choisi par le studio'} ; tâche {tid} ; statut : {t['status']}"]
    if any(task_files):
        rows.append("- Fichiers produits ou modifiés : " + ", ".join(f for f in task_files if f))
    rows.append("- Compte rendu de l'exécutant :\n" + (" ".join(resume.split())[:2500] or "(vide)"))
    return "\n".join(rows)


def _next_step(studio, ch: dict, tid: str) -> str | None:
    """Current step validated and its work in place: launch the next one, or finish the chain."""
    next_item = ch["courant"] + 1
    if next_item >= len(ch["etapes"]):
        studio.store.update_chain(ch["id"], statut="terminee", note="")
        return None
    return _launch_step(studio, ch["id"], next_item, _report(studio, tid))


def advance(studio, tid: str) -> str | None:
    """After a decision, cancellation, resume or merge: creates the next step's task if everything is
    ready. Returns its id (to be launched by the caller), else None. No effect outside a chain or when called twice."""
    t = studio.store.get(tid)
    o = t.get("options") or {}
    cid = o.get("chaine")
    if not cid:
        return None
    with _lock:
        ch = studio.store.chain(cid)
        if not ch or ch["statut"] in ("terminee", "arretee") or ch["courant"] != o.get("etape"):
            return None
        task_status = t["status"]
        if task_status in ("annulee", "echec"):
            studio.store.update_chain(cid, statut="en_pause", note=f"Étape {ch['courant'] + 1} {'annulée' if task_status == 'annulee' else 'en échec'} : relance-la ou arrête la chaîne.")
            return None
        if task_status not in ("approuvee", "appliquee"):
            return None
        if (studio.details_dir(tid) / "rien-a-appliquer.json").exists():    # report with no files: nothing to merge
            return _next_step(studio, ch, tid)
        infos = studio._branch_info(tid, t)
        if infos.get("worktree") and not infos.get("fusion"):
            studio.store.update_chain(cid, statut="attente_fusion",
                                    note="Fusionne cette étape : la suivante partira de son travail. Rien à fusionner, ou fusionnée par toi-même ? Clique « Continuer ».")
            return None
        if not infos.get("worktree") and task_status == "approuvee" and studio.registry.get(ch["cible"]).has_path:
            studio.store.update_chain(cid, statut="attente_application",
                                    note="Ce projet s'applique à la main : applique le résultat de cette étape dans le projet, puis clique « Continuer ».")
            return None
        return _next_step(studio, ch, tid)


def proceed(studio, cid: str) -> str | None:
    """The user confirms the current step's work is in place (merged, applied, or nothing to carry over)."""
    with _lock:
        ch = studio.store.chain(cid)
        if not ch:
            raise KeyError(f"Chaîne inconnue : {cid}")
        if ch["statut"] not in ("en_cours", "attente_fusion", "attente_application"):
            raise RuntimeError("Cette chaîne ne peut pas continuer (en pause, terminée ou arrêtée).")
        tid = ch["etapes"][ch["courant"]].get("tache", "")
        if not tid or studio.store.get(tid)["status"] not in ("approuvee", "appliquee"):
            raise RuntimeError(f"Valide d'abord l'étape {ch['courant'] + 1}.")
        return _next_step(studio, ch, tid)


def resume_run(studio, cid: str) -> str:
    """Paused chain: relaunch the current step (new task, same request, same context)."""
    with _lock:
        ch = studio.store.chain(cid)
        if not ch:
            raise KeyError(f"Chaîne inconnue : {cid}")
        if ch["statut"] != "en_pause":
            raise RuntimeError("Cette chaîne n'est pas en pause.")
        return _launch_step(studio, cid, ch["courant"], ch["etapes"][ch["courant"]].get("contexte", ""))


def halt(studio, cid: str) -> None:
    with _lock:                                         # never overwritten by a next step that is starting
        if not studio.store.chain(cid):
            raise KeyError(f"Chaîne inconnue : {cid}")
        studio.store.update_chain(cid, statut="arretee", note="Arrêtée par l'utilisateur.")


def resume(studio, cid: str) -> dict | None:
    """For the interface: title, status, steps (readable role, request, task, state)."""
    ch = studio.store.chain(cid)
    if not ch:
        return None
    stages = []
    for e in ch["etapes"]:
        r = studio.roles.get(e["role"])
        etat = ""
        if e.get("tache"):
            try:
                etat = studio.store.get(e["tache"])["status"]
            except KeyError:
                etat = ""
        stages.append({"role": e["role"], "nom_role": r.nom if r else "choisi par le studio", "demande": e["demande"],
                       "tache": e.get("tache", ""), "etat": etat})
    selected = stages[ch["courant"]] if ch["courant"] < len(stages) else {}
    return {"id": ch["id"], "titre": ch["titre"], "statut": ch["statut"], "courant": ch["courant"], "note": ch["note"],
            "etapes": stages, "peut_continuer": ch["statut"] in ("en_cours", "attente_fusion", "attente_application")
            and selected.get("etat") in ("approuvee", "appliquee")}
