"""MCP server "studio-memoire" (stdio, standard library only).

Why: the official @agentmemory/mcp client silently falls back to a local memory
when a call to the server fails (even with AGENTMEMORY_FORCE_PROXY, checked in its code),
and its searches do not filter by project. This server exposes the shared memory through the
studio's connector: scope required for reading and writing, visible errors,
no local fallback presented as shared.

Launch (configured in both CLI tools):
  <Studio>\\.venv\\Scripts\\python.exe -m studio.mcp_server     (PYTHONPATH=<Studio>, STUDIO_MCP_CLIENT=claude-code|codex)
"""
from __future__ import annotations

import json
import os
import sys
import traceback

from . import __version__
from .config import load_config
from .memory import MemoryUnavailable, Provenance, Scope, build_connector
from .paths import default_paths
from .security import SensitiveContentError, redact

PROTOCOLS = ("2025-11-25", "2025-06-18", "2025-03-26", "2024-11-05")
CLIENT = os.environ.get("STUDIO_MCP_CLIENT", "mcp")
DOC_SCOPE = "Portée : 'general', 'project:<id>', 'topic:<id>' ou 'task:<id>' (ex. 'project:mon-jeu')."

TOOLS = [
    {"name": "memoire_chercher",
     "description": "Cherche dans la mémoire partagée du studio, limitée aux portées demandées (+ général par défaut). " + DOC_SCOPE,
     "inputSchema": {"type": "object", "properties": {
         "requete": {"type": "string", "description": "Mots-clés (vide = tout lister)"},
         "portees": {"type": "array", "items": {"type": "string"}, "description": "Portées à lire"},
         "inclure_general": {"type": "boolean", "default": True},
         "limite": {"type": "integer", "default": 10}}, "required": ["portees"]}},
    {"name": "memoire_ajouter",
     "description": "Enregistre un fait durable dans UNE portée. Refuse les secrets. Indique clairement si l'écriture n'est PAS partagée (serveur en panne). " + DOC_SCOPE,
     "inputSchema": {"type": "object", "properties": {
         "texte": {"type": "string"}, "portee": {"type": "string"},
         "sujet": {"type": "string", "description": "Clé stable du sujet (permet de détecter les contradictions)"},
         "cle": {"type": "string", "description": "Clé d'idempotence (facultative)"}}, "required": ["texte", "portee"]}},
    {"name": "memoire_corriger",
     "description": "Corrige un souvenir (nouvelle version ; l'historique est conservé). " + DOC_SCOPE,
     "inputSchema": {"type": "object", "properties": {
         "portee": {"type": "string"}, "cle": {"type": "string"}, "texte": {"type": "string"}},
         "required": ["portee", "cle", "texte"]}},
    {"name": "memoire_conflits",
     "description": "Liste les contradictions d'une portée (à signaler à l'utilisateur, ne pas trancher seul). " + DOC_SCOPE,
     "inputSchema": {"type": "object", "properties": {"portee": {"type": "string"}}, "required": ["portee"]}},
    {"name": "memoire_etat", "description": "État de la mémoire partagée (OK / EN_PANNE / DEGRADE).",
     "inputSchema": {"type": "object", "properties": {}}},
]


CREATION = [
    {"name": "image_creer", "description": "Crée une image PNG avec une IA connectée au studio (n'importe laquelle qui sait le faire) "
     "et l'enregistre dans le dossier de travail (chemin relatif).",
     "inputSchema": {"type": "object", "properties": {"description": {"type": "string", "description": "Description détaillée (anglais conseillé)"},
                                                      "chemin": {"type": "string", "description": "Ex. images/heros.png"}},
                     "required": ["description", "chemin"]}},
    {"name": "voix_creer", "description": "Synthétise un texte en voix (MP3) avec une IA connectée au studio et l'enregistre (chemin relatif).",
     "inputSchema": {"type": "object", "properties": {"texte": {"type": "string"}, "chemin": {"type": "string"},
                                                      "voix": {"type": "string", "description": "facultatif"}},
                     "required": ["texte", "chemin"]}},
]


def _generation_connection(genre: str):
    """Connected AI that can create this kind (read from the user's studio settings), otherwise None."""
    try:
        from . import ai
        return ai.connection_for(default_paths().data, genre)
    except Exception:                                    # noqa: BLE001
        return None


def _create(genre: str, a: dict) -> tuple[str, bool]:
    from pathlib import Path
    from . import ai
    ext = ".png" if genre == "image" else ".mp3"
    rel = str(a.get("chemin") or f"sortie{ext}").replace("\\", "/").lstrip("/")
    if ".." in Path(rel).parts or ":" in rel:
        return "Refusé : chemin hors du dossier de travail.", True
    if not rel.lower().endswith(ext):
        rel += ext
    c = _generation_connection(genre)
    if c is None:
        return f"Aucune IA connectée ne sait créer de {genre} (Accueil › Réglages › IA).", True
    data = ai.generate_image(c, str(a.get("description", ""))) if genre == "image" else ai.generate_voice(c, str(a.get("texte", "")), str(a.get("voix", "")))
    p = Path.cwd() / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(data)
    return f"Fichier créé : {rel} ({len(data) // 1024} Ko).", False


class Server:
    def __init__(self, memory=None):
        if memory is None:
            paths = default_paths().ensure()
            memory = build_connector(load_config(paths.config_file), paths.data)
        self.mem = memory

    # ---------------------------------------------------------------- tools
    def call(self, name: str, a: dict) -> tuple[str, bool]:
        prov = Provenance(outil=CLIENT, agent="mcp")
        if CLIENT == "agent" and name in ("memoire_ajouter", "memoire_corriger"):     # studio agents: read-only
            return "Refusé : les agents lisent la mémoire ; le studio y enregistre le résultat après validation.", True
        if name in ("image_creer", "voix_creer"):
            try:
                return _create("image" if name == "image_creer" else "voix", a)
            except Exception as e:                      # noqa: BLE001 — provider error: the agent sees it and adapts
                return f"Échec de la création : {str(e)[:300]}", True
        if name == "memoire_etat":
            h = self.mem.health()
            return json.dumps(h.to_dict(), ensure_ascii=False), h.etat == "EN_PANNE"
        if name == "memoire_chercher":
            scopes = [Scope.parse(x) for x in a.get("portees", [])]
            recs = self.mem.recall(a.get("requete", ""), scopes, bool(a.get("inclure_general", True)),
                                   int(a.get("limite", 10)))
            if not recs:
                return "Aucun souvenir dans ces portées.", False
            return "\n".join(f"- [{r.scope.label} | {r.status} | clé {r.key} | {r.provenance.outil} {r.created_at}] {r.content}"
                             for r in recs), False
        if name == "memoire_ajouter":
            r = self.mem.remember(Scope.parse(a["portee"]), a["texte"], prov, key=a.get("cle") or None,
                                  subject=a.get("sujet", ""))
            if not r.shared:
                return (f"NON PARTAGÉ : la mémoire centrale est en panne. Écriture conservée localement "
                        f"(clé {r.record.key}) et envoyée automatiquement au retour du serveur. "
                        "Ne pas considérer cette information comme connue de l'autre outil."), True
            extra = " ATTENTION : contradiction avec un souvenir existant du même sujet — à signaler à l'utilisateur." \
                if r.status == "conteste" else ""
            return f"{r.status} (portée {r.record.scope.label}, clé {r.record.key}).{extra}", False
        if name == "memoire_corriger":
            r = self.mem.correct(Scope.parse(a["portee"]), a["cle"], a["texte"], prov)
            return f"{r.status} : nouvelle version {r.record.key}", not r.shared
        if name == "memoire_conflits":
            c = self.mem.conflicts(Scope.parse(a["portee"]))
            if not c:
                return "Aucune contradiction.", False
            return "\n".join(f"Sujet {s} :\n" + "\n".join(f"  - clé {r.key} ({r.provenance.outil}) : {r.content}" for r in rs)
                             for s, rs in c.items()), False
        raise ValueError(f"Outil inconnu : {name}")

    # ------------------------------------------------------------- JSON-RPC
    def handle(self, msg: dict) -> dict | None:
        mid, method = msg.get("id"), msg.get("method")
        if method == "initialize":
            asked = (msg.get("params") or {}).get("protocolVersion")
            return {"jsonrpc": "2.0", "id": mid, "result": {
                "protocolVersion": asked if asked in PROTOCOLS else PROTOCOLS[-1],
                "capabilities": {"tools": {"listChanged": False}},
                "serverInfo": {"name": "studio-memoire", "version": __version__},
                "instructions": "Mémoire partagée du studio : toujours indiquer une portée. " + DOC_SCOPE}}
        if method == "ping":
            return {"jsonrpc": "2.0", "id": mid, "result": {}}
        if method == "tools/list":
            allowed_tools = [t for t in TOOLS if CLIENT != "agent" or t["name"] not in ("memoire_ajouter", "memoire_corriger")]
            allowed_tools += [t for t in CREATION if _generation_connection("image" if t["name"] == "image_creer" else "voix")]
            return {"jsonrpc": "2.0", "id": mid, "result": {"tools": allowed_tools}}
        if method == "tools/call":
            p = msg.get("params") or {}
            try:
                text, is_err = self.call(p.get("name", ""), p.get("arguments") or {})
            except MemoryUnavailable as e:
                text, is_err = f"MÉMOIRE EN PANNE : {e}", True
            except SensitiveContentError as e:
                text, is_err = f"Refusé : {e}", True
            except (ValueError, KeyError, TypeError) as e:
                text, is_err = f"Erreur : {e}", True
            return {"jsonrpc": "2.0", "id": mid, "result": {"content": [{"type": "text", "text": redact(text)}],
                                                             "isError": is_err}}
        if mid is None:                       # notification (e.g. notifications/initialized)
            return None
        return {"jsonrpc": "2.0", "id": mid, "error": {"code": -32601, "message": f"Méthode inconnue : {method}"}}


def main() -> int:
    for s in (sys.stdin, sys.stdout):
        try:
            s.reconfigure(encoding="utf-8")
        except (AttributeError, ValueError):
            pass
    try:
        server = Server()
    except Exception as e:                    # unreadable configuration: say so and stop
        print(f"[studio-memoire] démarrage impossible : {e}", file=sys.stderr)
        return 1
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            msg = json.loads(line)
        except ValueError:
            continue
        try:
            out = server.handle(msg)
        except Exception:
            print("[studio-memoire] " + redact(traceback.format_exc())[-800:], file=sys.stderr)
            out = {"jsonrpc": "2.0", "id": msg.get("id"), "error": {"code": -32603, "message": "Erreur interne"}}
        if out is not None:
            sys.stdout.write(json.dumps(out, ensure_ascii=False) + "\n")
            sys.stdout.flush()
    return 0


if __name__ == "__main__":
    sys.exit(main())
