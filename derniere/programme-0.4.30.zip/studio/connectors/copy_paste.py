"""Copy-paste: bring in any AI (a website, an app) without giving it access to the PC.

- copy: a Markdown context file to paste or attach in the AI of your choice;
- paste: its answer, read as UNTRUSTED DATA. It becomes a proposal (plan, decisions)
  that the user approves; it can neither grant permissions nor trigger actions.
"""
from __future__ import annotations

import json
import re
from pathlib import Path

from ..security import redact

TEMPLATE = """## Compte rendu de l'IA
Tâche : {task_id}

### Analyse
(texte libre)

### Plan proposé
1. …

### Décisions proposées
- …

### Points à vérifier
- …
"""


def export_context(dest_dir: Path, task: dict, target: dict, memories: list[str], rules: list[str],
                   plan: list[str] | None = None, result: str = "") -> Path:
    dest_dir.mkdir(parents=True, exist_ok=True)
    f = dest_dir / f"CONTEXTE-{task['id']}.md"
    lines = [f"# Contexte studio — {task['id']}", "",
             "Contexte à donner à une IA (n'importe laquelle) pour réflexion ou relecture. "
             "Répondre avec le modèle de compte rendu en fin de document.", "",
             "## Demande de l'utilisateur", task["request"], "",
             "## Projet ou sujet", f"- {target.get('nom')} ({target.get('kind')}:{target.get('id')}, type {target.get('type')})",
             f"- Dépôt : {target.get('depot') or 'aucun'}", "",
             "## Règles applicables (fichiers de référence)", *([f"- {r}" for r in rules] or ["- (aucune)"]), "",
             "## Mémoire utile (filtrée par portée)", *([f"- {m}" for m in memories] or ["- (aucune)"]), ""]
    if plan:
        lines += ["## Plan actuel", *[f"{i}. {s}" for i, s in enumerate(plan, 1)], ""]
    if result:
        lines += ["## Résultat présenté", result, ""]
    lines += ["---", "## Modèle de compte rendu à renvoyer", TEMPLATE.format(task_id=task["id"])]
    f.write_text(redact("\n".join(lines)), encoding="utf-8")
    return f


def _section(text: str, title: str) -> list[str]:
    m = re.search(rf"^###\s*{re.escape(title)}\s*$(.*?)(?=^###\s|\Z)", text, re.M | re.S | re.I)
    if not m:
        return []
    items = []
    for line in m.group(1).splitlines():
        line = re.sub(r"^\s*(?:[-*]|\d+[.)])\s*", "", line).strip()
        if line and line != "…":
            items.append(line)
    return items


def import_report(src: Path, dest_dir: Path, task_id: str) -> dict:
    raw = src.read_bytes()
    try:
        text = raw.decode("utf-8-sig")
    except UnicodeDecodeError:
        text = raw.decode("cp1252", errors="replace")         # file saved as ANSI on Windows
    if task_id not in text:
        raise ValueError("Le compte rendu ne mentionne pas cette tâche : import refusé.")
    data = {"source": "copier-coller", "statut": "proposition_non_validee", "fiable": False, "tache": task_id,
            "analyse": " ".join(_section(text, "Analyse"))[:4000],
            "plan": _section(text, "Plan proposé")[:30],
            "decisions": _section(text, "Décisions proposées")[:30],
            "verifications": _section(text, "Points à vérifier")[:30]}
    data = json.loads(redact(json.dumps(data, ensure_ascii=False)))
    dest_dir.mkdir(parents=True, exist_ok=True)
    out = dest_dir / f"reponse-{task_id}.json"
    out.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    return data
