"""PC resources for the header: processor, RAM, graphics card (usage and video memory).

- No dependency: Windows API (ctypes) or /proc on Linux; NVIDIA graphics card via nvidia-smi, otherwise Windows
  performance counters (any brand); models loaded by Ollama (video memory used by the local AI).
- Lightweight: one graphics card reading at most every 4 s (in a thread), only while the page asks for it;
  the rest is read in a few microseconds.
"""
from __future__ import annotations

import ctypes
import json
import os
import shutil
import subprocess
import sys
import threading
import time
import urllib.request

_state = {"cpu": None, "gpu": {}, "ollama": [], "demande": 0.0, "fil": False}
_lock = threading.Lock()
_NO_WINDOW = 0x08000000 if sys.platform == "win32" else 0


# ------------------------------------------------------------------ processor
def _cpu_time() -> tuple[int, int] | None:
    """Cumulative (idle, total)."""
    if sys.platform == "win32":
        class FT(ctypes.Structure):
            _fields_ = [("l", ctypes.c_uint32), ("h", ctypes.c_uint32)]
        i, k, u = FT(), FT(), FT()
        if not ctypes.windll.kernel32.GetSystemTimes(ctypes.byref(i), ctypes.byref(k), ctypes.byref(u)):
            return None
        v = lambda f: (f.h << 32) | f.l                                  # noqa: E731
        return v(i), v(k) + v(u)                                          # kernel time includes idle
    if sys.platform == "darwin":                                          # Mac: kernel counters (host_statistics)
        try:
            lib = ctypes.CDLL("/usr/lib/libSystem.dylib")
            t, n = (ctypes.c_uint32 * 4)(), ctypes.c_uint32(4)                # user, system, idle, nice
            if lib.host_statistics(lib.mach_host_self(), 3, ctypes.byref(t), ctypes.byref(n)) != 0:
                return None
            return t[2], sum(t)
        except (OSError, AttributeError):
            return None
    try:
        with open("/proc/stat", encoding="ascii") as f:
            n = [int(x) for x in f.readline().split()[1:]]
        return n[3] + (n[4] if len(n) > 4 else 0), sum(n)
    except (OSError, ValueError):
        return None


def cpu() -> float | None:
    t = _cpu_time()
    if t is None:
        return None
    with _lock:
        before, _state["cpu"] = _state["cpu"], t
    if not before or t[1] <= before[1]:
        return None
    return round(100 * (1 - (t[0] - before[0]) / (t[1] - before[1])), 1)


# ------------------------------------------------------------------ RAM
def ram() -> dict:
    if sys.platform == "win32":
        class MS(ctypes.Structure):
            _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong), ("total", ctypes.c_ulonglong),
                        ("free", ctypes.c_ulonglong), ("a", ctypes.c_ulonglong), ("b", ctypes.c_ulonglong),
                        ("c", ctypes.c_ulonglong), ("d", ctypes.c_ulonglong), ("e", ctypes.c_ulonglong)]
        m = MS()
        m.dwLength = ctypes.sizeof(MS)
        if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m)):
            return {"total_go": round(m.total / 2**30, 1), "utilise_go": round((m.total - m.free) / 2**30, 1)}
        return {}
    if sys.platform == "darwin":                                          # Mac: sysctl (total) and vm_stat (used pages)
        try:
            import re
            import subprocess
            total = int(subprocess.run(["sysctl", "-n", "hw.memsize"], capture_output=True, text=True, timeout=3).stdout.strip())
            vm = subprocess.run(["vm_stat"], capture_output=True, text=True, timeout=3).stdout
            page = int((re.search(r"page size of (\d+)", vm) or [0, 16384])[1])
            pages = lambda nom: int((re.search(rf"{nom}:\s+(\d+)", vm) or [0, 0])[1])   # noqa: E731
            uses = (pages("Pages active") + pages("Pages wired down") + pages("Pages occupied by compressor")) * page
            return {"total_go": round(total / 2**30, 1), "utilise_go": round(uses / 2**30, 1)}
        except (OSError, ValueError, subprocess.SubprocessError):
            return {}
    try:
        info = {}
        with open("/proc/meminfo", encoding="ascii") as f:
            for l in f:
                k, v = l.split(":", 1)
                info[k] = int(v.split()[0]) * 1024
        total, usable = info["MemTotal"], info.get("MemAvailable", info.get("MemFree", 0))
        return {"total_go": round(total / 2**30, 1), "utilise_go": round((total - usable) / 2**30, 1)}
    except (OSError, ValueError, KeyError):
        return {}


# ------------------------------------------------------------------ graphics card (thread, every 4 s)
def _nvidia() -> dict:
    exe = shutil.which("nvidia-smi")
    if not exe:
        return {}
    r = subprocess.run([exe, "--query-gpu=name,utilization.gpu,memory.used,memory.total", "--format=csv,noheader,nounits"],
                       capture_output=True, text=True, timeout=4, creationflags=_NO_WINDOW)
    l = (r.stdout or "").strip().splitlines()
    if r.returncode or not l:
        return {}
    nom, util, used, total = [x.strip() for x in l[0].split(",")][:4]
    return {"nom": nom, "util": float(util), "vram_go": round(float(used) / 1024, 1), "vram_total_go": round(float(total) / 1024, 1)}


class _WindowsCounters:
    """Any brand (AMD, Intel, NVIDIA): Windows performance counters read through the PDH API, with the English
    names (works on a French Windows), without launching a program. Query opened once, re-read on each round."""
    FMT_DOUBLE, PLUS = 0x200, 0x800007D2

    def __init__(self):
        self.pdh = ctypes.windll.pdh
        self.q = ctypes.c_void_p()
        if self.pdh.PdhOpenQueryW(None, 0, ctypes.byref(self.q)) != 0:
            raise OSError("PDH indisponible")
        self.util, self.mem = ctypes.c_void_p(), ctypes.c_void_p()
        self.pdh.PdhAddEnglishCounterW(self.q, "\\GPU Engine(*engtype_3D)\\Utilization Percentage", 0, ctypes.byref(self.util))
        self.pdh.PdhAddEnglishCounterW(self.q, "\\GPU Adapter Memory(*)\\Dedicated Usage", 0, ctypes.byref(self.mem))
        self.pdh.PdhCollectQueryData(self.q)                  # first reading: calculation baseline

    def _values(self, c) -> list[float]:
        class Value(ctypes.Structure):
            _fields_ = [("status", ctypes.c_ulong), ("double", ctypes.c_double)]

        class Element(ctypes.Structure):
            _fields_ = [("name", ctypes.c_wchar_p), ("value", Value)]
        size, n = ctypes.c_ulong(0), ctypes.c_ulong(0)
        r = self.pdh.PdhGetFormattedCounterArrayW(c, self.FMT_DOUBLE, ctypes.byref(size), ctypes.byref(n), None)
        if r not in (0, self.PLUS) or not size.value:
            return []
        buf = (ctypes.c_byte * size.value)()
        if self.pdh.PdhGetFormattedCounterArrayW(c, self.FMT_DOUBLE, ctypes.byref(size), ctypes.byref(n), buf) != 0:
            return []
        el = ctypes.cast(buf, ctypes.POINTER(Element))
        return [el[i].value.double for i in range(n.value) if el[i].value.status in (0, 1)]

    def read_file(self) -> dict:
        if self.pdh.PdhCollectQueryData(self.q) != 0:
            return {}
        util, mem = self._values(self.util), self._values(self.mem)
        if not util and not mem:
            return {}
        return {"util": round(min(sum(util), 100.0), 1), "vram_go": round(max(mem or [0]) / 2**30, 1)}


def _ollama() -> list[dict]:
    try:
        with urllib.request.urlopen("http://127.0.0.1:11434/api/ps", timeout=1) as r:
            d = json.loads(r.read() or b"{}")
        return [{"nom": m.get("name", ""), "vram_go": round((m.get("size_vram") or 0) / 2**30, 1)} for m in d.get("models", [])]
    except (OSError, ValueError):
        return []


def _thread() -> None:
    counters = None
    if sys.platform == "win32" and not shutil.which("nvidia-smi"):
        try:
            counters = _WindowsCounters()
        except Exception:                                # noqa: BLE001 — no counter: graphics card not shown
            counters = None
    while time.time() - _state["demande"] < 30:           # nobody has looked for 30 s: the thread stops
        try:
            g = _nvidia() or (counters.read_file() if counters else {})
        except Exception:                                # noqa: BLE001
            g = {}
        o = _ollama()
        with _lock:
            _state["gpu"], _state["ollama"] = g, o
        time.sleep(4)
    with _lock:
        _state["fil"] = False


def survey() -> dict:
    """What the header shows; starts the slow-readings thread if it is asleep."""
    with _lock:
        _state["demande"] = time.time()
        lancer = not _state["fil"]
        _state["fil"] = True
    if lancer:
        threading.Thread(target=_thread, daemon=True).start()
    with _lock:
        gpu, ollama = dict(_state["gpu"]), list(_state["ollama"])
    return {"cpu": cpu(), "coeurs": os.cpu_count(), "ram": ram(), "gpu": gpu, "ollama": ollama}
