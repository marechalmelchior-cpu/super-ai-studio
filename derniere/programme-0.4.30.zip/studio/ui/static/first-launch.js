/* First launch: one click (optional first name, suggested folder) → creation, then the studio opens, where the home page
   offers to connect an AI with one button. */
const $ = (s) => document.querySelector(s);
async function api(path, body) {
  const opt = body === undefined ? {} : { method: "POST", headers: { "Content-Type": "application/json", "X-Studio": "1" }, body: JSON.stringify(body) };
  const r = await fetch(path, opt);
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.erreur || r.status);
  return j;
}
// Language of the studio: interface texts AND folder names (Projets/Projects…), chosen once here.
const TEXTS = {
  en: { titre: "Welcome to your AI studio", sous: "One click to create your studio. Then connect your AI with one button.",
        prenom: "Your first name", facultatif: "(optional)", dossier: "Studio folder:", changer: "change",
        "aide-dossier": "Your rules, skills, tasks, memory and backups will live here. Your projects stay where they are. Already have a studio (other PC, backup)? Pick its folder: it will be reused as is.",
        parcourir: "Browse…", creer: "Create my studio", reprendre: "Reuse this studio", creation: "Creating…",
        pret: "Your studio is ready", repris: "Studio reused", ouverture: "Opening the studio…",
        lent: "The studio is slow to start: launch it again from its icon." },
};
const FR = {};
document.querySelectorAll("[data-t]").forEach((el) => (FR[el.dataset.t] = el.textContent));
Object.assign(FR, { creer: "Créer mon studio", reprendre: "Reprendre ce studio", creation: "Création…", pret: "Ton studio est prêt",
  repris: "Studio repris", ouverture: "Ouverture du studio…", lent: "Le studio tarde à démarrer : relance-le depuis son icône." });
let language = (navigator.language || "fr").toLowerCase().startsWith("fr") ? "fr" : "en";
const t = (k) => (language === "en" ? TEXTS.en[k] : FR[k]);
function applyLanguage(l) {
  language = l;
  document.documentElement.lang = l;
  document.querySelectorAll("[data-t]").forEach((el) => (el.textContent = t(el.dataset.t)));
  document.querySelectorAll("[data-langue]").forEach((b) => b.setAttribute("aria-pressed", String(b.dataset.langue === l)));
  $("#nom").placeholder = l === "en" ? "E.g. Alex" : "Ex. Alex";
  if (!$("#creer").disabled) $("#creer").textContent = t(lastCheck && lastCheck.rejoindre ? "reprendre" : "creer");
}
let lastCheck = null;
document.querySelectorAll("[data-langue]").forEach((b) => (b.onclick = () => applyLanguage(b.dataset.langue)));
function showView(n) { document.querySelectorAll("section[data-etape]").forEach((s) => (s.hidden = +s.dataset.etape !== n)); }
let countdown = 0, valid = true;
async function check() {
  const d = $("#dossier").value.trim();
  $("#dossier-court").textContent = d;
  try {
    const v = await api("/api/verifier", { dossier: d });
    valid = v.ok; lastCheck = v;
    $("#info-dossier").textContent = v.info || "";
    $("#info-dossier").className = "info " + (v.ok ? "ok" : "warn");
    $("#creer").textContent = t(v.rejoindre ? "reprendre" : "creer");
    if (!v.ok) $("#pli-dossier").open = true;
    return v;
  } catch (e) { valid = false; $("#info-dossier").textContent = e.message; $("#info-dossier").className = "info warn"; $("#pli-dossier").open = true; }
}
$("#dossier").addEventListener("input", () => { clearTimeout(countdown); countdown = setTimeout(check, 300); });
$("#parcourir").onclick = async () => {
  $("#parcourir").disabled = true;
  try { const r = await api("/api/parcourir", { dossier: $("#dossier").value }); if (r.dossier) { $("#dossier").value = r.dossier; check(); } }
  finally { $("#parcourir").disabled = false; }
};
$("#creer").onclick = async () => {
  const v = await check();
  if (!v || !v.ok) return;
  $("#creer").disabled = true; $("#info-creer").textContent = t("creation"); $("#info-creer").className = "info";
  try {
    const name = $("#nom").value.trim();
    const r = await api("/api/creer", { nom: name, dossier: $("#dossier").value.trim(), packs: [], langue: language });
    showView(2);
    $("#titre-fin").textContent = r.rejoint ? t("repris") : `${t("pret")}${name ? ", " + name : ""}`;
    $("#texte-fin").textContent = t("ouverture");
    openStudio(r.suite);
  } catch (e) { $("#info-creer").textContent = e.message; $("#info-creer").className = "info warn"; $("#creer").disabled = false; }
};
document.addEventListener("keydown", (e) => { if (e.key === "Enter" && e.target.id === "nom") $("#creer").click(); });
async function openStudio(nextUrl) {                  // the studio starts on the same port: wait until it responds
  for (let i = 0; i < 120; i++) {
    await new Promise((r) => setTimeout(r, 1000));
    try { const p = await (await fetch("/api/ping", { cache: "no-store" })).json(); if (p.studio) { location.href = nextUrl; return; } } catch { /* not yet */ }
  }
  $("#texte-fin").textContent = t("lent");
}
(async () => {
  try { const infos = await api("/api/infos"); $("#dossier").value = infos.dossier; check(); } catch (e) { $("#info-creer").textContent = e.message; }
  applyLanguage(language);
  showView(1);
  $("#nom").focus();
})();
setInterval(() => api("/api/presence", {}).catch(() => {}), 20000);
