"""Preparing configuration changes (reviewable copies, never applied here).

Proposed change for AgentMemory (ADR-0003):
- version pinned identical to the server: ``@agentmemory/mcp@<version>``;
- ``AGENTMEMORY_FORCE_PROXY=1``: the client no longer silently falls back to a
  local memory (``standalone.json``) when the server is missing; the absence
  becomes a visible error;
- explicit ``AGENTMEMORY_URL`` on local loopback.
The secret is still read by the official client from ``~/.agentmemory/.env``: it
is never copied into a configuration.
"""
from __future__ import annotations

import difflib
import hashlib
import json
import re
from pathlib import Path

AGENTMEMORY_VERSION = "0.9.22"      # version of the installed global server (log of 2026-05-26)


def mcp_entry(version: str = AGENTMEMORY_VERSION) -> dict:
    return {"command": "npx", "args": ["-y", f"@agentmemory/mcp@{version}"],
            "env": {"AGENTMEMORY_URL": "http://localhost:3111", "AGENTMEMORY_FORCE_PROXY": "1"}}


_HEADER = re.compile(r"^\s*\[")


def _table_bounds(lines: list[str], name: str) -> tuple[int, int] | None:
    """(start, end) of a TOML table; the end excludes the blank/comment lines
    preceding the next table (they belong to it)."""
    head = re.compile(rf"^\s*\[{re.escape(name)}\]\s*(#.*)?$")
    for i, l in enumerate(lines):
        if head.match(l.rstrip("\r\n")):
            j = i + 1
            while j < len(lines) and not _HEADER.match(lines[j]):
                j += 1
            while j > i + 1 and (not lines[j - 1].strip() or lines[j - 1].lstrip().startswith("#")):
                j -= 1
            return i, j
    return None


def _set_key(lines: list[str], bounds: tuple[int, int], key: str, value_line: str) -> list[str]:
    """Replaces ``key = …`` (even multi-line) in the table, otherwise appends it at the end of the table."""
    i, j = bounds
    k_re = re.compile(rf"^\s*{re.escape(key)}\s*=")
    for n in range(i + 1, j):
        if k_re.match(lines[n]):
            m = n
            depth = lines[n].count("[") - lines[n].count("]")
            while depth > 0 and m + 1 < j:
                m += 1
                depth += lines[m].count("[") - lines[m].count("]")
            return lines[:n] + [value_line] + lines[m + 1:]
    return lines[:j] + [value_line] + lines[j:]


def patch_codex_config(text: str, version: str = AGENTMEMORY_VERSION) -> str:
    """Changes only ``command``/``args`` of ``[mcp_servers.agentmemory]`` and the keys
    ``AGENTMEMORY_URL``/``AGENTMEMORY_FORCE_PROXY`` of ``[mcp_servers.agentmemory.env]``.
    All other lines (keys, comments, tables) are kept."""
    nl = "\r\n" if "\r\n" in text else "\n"
    lines = text.splitlines(keepends=True)
    if lines and not lines[-1].endswith(("\n", "\r")):
        lines[-1] += nl
    e = mcp_entry(version)
    b = _table_bounds(lines, "mcp_servers.agentmemory")
    if b is None:
        raise ValueError("Aucune section [mcp_servers.agentmemory] : rien à modifier (à examiner).")
    lines = _set_key(lines, b, "command", f'command = "npx"{nl}')
    lines = _set_key(lines, _table_bounds(lines, "mcp_servers.agentmemory"), "args",
                     f"args = [{', '.join(json.dumps(a) for a in e['args'])}]{nl}")
    eb = _table_bounds(lines, "mcp_servers.agentmemory.env")
    if eb is None:
        _, end = _table_bounds(lines, "mcp_servers.agentmemory")
        lines = lines[:end] + [nl, f"[mcp_servers.agentmemory.env]{nl}"] + lines[end:]
        eb = _table_bounds(lines, "mcp_servers.agentmemory.env")
    for k, v in e["env"].items():
        lines = _set_key(lines, eb, k, f'{k} = "{v}"{nl}')
        eb = _table_bounds(lines, "mcp_servers.agentmemory.env")
    return "".join(lines)


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def diff(old: str, new: str, name: str) -> str:
    return "".join(difflib.unified_diff(old.splitlines(keepends=True), new.splitlines(keepends=True),
                                        f"actuel/{name}", f"propose/{name}"))


# --------------------------------------------------------------- applying ---
# Run only by the user (Apply-Configs.ps1), never automatically.
def apply_codex(config: "Path", proposal_dir: "Path", backup_dir: "Path") -> dict:
    import tomllib
    from datetime import datetime, timezone
    from pathlib import Path
    config, proposal_dir, backup_dir = Path(config), Path(proposal_dir), Path(backup_dir)
    current = config.read_text(encoding="utf-8")
    base = (proposal_dir / "codex.config.toml.base.sha256").read_text(encoding="ascii").strip()
    if sha256_text(current) != base:
        raise RuntimeError("config.toml a changé depuis la préparation : relancer « config-preparer » puis relire le diff.")
    new = (proposal_dir / "codex.config.toml.propose").read_text(encoding="utf-8")
    tomllib.loads(new)                                    # the proposal must be valid TOML
    backup_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    saved = backup_dir / f"codex-config-{stamp}.toml"
    with open(saved, "xb") as fh:
        fh.write(config.read_bytes())
    config.write_text(new, encoding="utf-8", newline="")
    tomllib.loads(config.read_text(encoding="utf-8"))
    return {"applique": str(config), "sauvegarde": str(saved)}


def restore_codex(config: "Path", backup_dir: "Path", backup_file: "Path | None" = None) -> dict:
    from datetime import datetime, timezone
    from pathlib import Path
    config, backup_dir = Path(config), Path(backup_dir)
    candidates = sorted(backup_dir.glob("codex-config-*.toml"))
    src = Path(backup_file) if backup_file else (candidates[-1] if candidates else None)
    if src is None or not src.exists():
        raise FileNotFoundError("Aucune sauvegarde de config.toml trouvée.")
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    keep = backup_dir / f"avant-restauration-codex-config-{stamp}.toml"
    with open(keep, "xb") as fh:                         # the current state is kept too
        fh.write(config.read_bytes())
    config.write_bytes(src.read_bytes())
    return {"restaure_depuis": str(src), "etat_precedent_conserve": str(keep)}


# ------------------------------------------------- studio MCP server (scoped memory) ---
def studio_mcp_entry(studio_dir: str, client: str) -> dict:
    windows = "\\" in studio_dir or re.match(r"^[A-Za-z]:", studio_dir)          # Windows path, otherwise Mac / Linux
    py = studio_dir.rstrip("\\/") + ("\\.venv\\Scripts\\python.exe" if windows else "/.venv/bin/python")
    return {"command": py, "args": ["-m", "studio.mcp_server"],
            "env": {"PYTHONPATH": studio_dir, "STUDIO_MCP_CLIENT": client, "PYTHONUTF8": "1"}}


def add_studio_mcp_codex(text: str, studio_dir: str) -> str:
    """Adds [mcp_servers.studio-memoire] if missing and ensures its tools are pre-approved
    (otherwise ``codex exec`` rejects them: « requires approval, but approval policy is never »).
    These are the studio's tools: scope enforced, secrets refused."""
    nl = "\r\n" if "\r\n" in text else "\n"
    if re.search(r"^\s*\[mcp_servers\.studio-memoire\]", text, re.M):
        lines = text.splitlines(keepends=True)
        lines = _set_key(lines, _table_bounds(lines, "mcp_servers.studio-memoire"), "default_tools_approval_mode",
                         f'default_tools_approval_mode = "approve"{nl}')
        return "".join(lines)
    e = studio_mcp_entry(studio_dir, "codex")
    block = [f"{nl}[mcp_servers.studio-memoire]{nl}", f"command = '{e['command']}'{nl}",
             f"args = [{', '.join(json.dumps(a) for a in e['args'])}]{nl}", f"startup_timeout_sec = 30{nl}",
             f'default_tools_approval_mode = "approve"{nl}',
             f"{nl}[mcp_servers.studio-memoire.env]{nl}"]
    block += [f"{k} = '{v}'{nl}" for k, v in e["env"].items()]
    if not text.endswith(("\n", "\r")):
        text += nl
    return text + "".join(block)
