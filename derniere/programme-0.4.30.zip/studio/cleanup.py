"""Automatic cleanup: the studio does not grow forever and stays tidy as it goes.

When it runs (never the same cleanup twice):
- at the end of each task (validated, applied, cancelled): its working copy and its review copies;
- right after the daily backup: backup rotation; after an update: old versions;
  after a settings change: settings copies; before opening the window: browser cache;
- at most once a day (reopening the studio reruns nothing): catch-up on tasks finished in the last 7 days,
  checkpoints, logs;
- on demand: Gestion › Entretien › « Faire le ménage maintenant ».

Always kept: projects, topics and their results, skills, rules, memory, RESULTAT.md and details/ of each task.
Only recreatable or stale technical data is limited:
- full backups: the last 7 days + one per week over 4 weeks (never fewer than 3);
- old program versions (copy before each update): the last 3;
- settings copies: the last 10;
- project copy inside a task (copie-de-travail, review copies): removed 7 days after the task ends;
- checkpoints of tasks finished more than 30 days ago;
- logs: 30 days; UI log cut down to 1 MB once over 5 MB;
- studio window cache beyond 150 MB.
A running task or one awaiting validation is never touched. Setting: Réglages › « Ménage automatique ».
"""
from __future__ import annotations

import json
import shutil
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

BACKUP_DAYS, BACKUP_WEEKS, MIN_BACKUPS = 7, 4, 3
VERSIONS, SETTINGS_COPIES = 3, 10
TASK_DAYS, RESUME_DAYS, LOG_DAYS = 7, 30, 30
FINISHED = ("approuvee", "appliquee", "annulee", "echec")
WINDOW_CACHES = ("Cache", "Code Cache", "GPUCache", "DawnCache", "DawnGraphiteCache", "DawnWebGPUCache", "GrShaderCache",
                  "ShaderCache", "Service Worker/CacheStorage", "Service Worker/ScriptCache")


def _size(p: Path) -> int:
    """Size of a file or folder; an unreadable item counts as 0 (never an error)."""
    def une(f: Path) -> int:
        try:
            return f.stat().st_size if f.is_file() else 0
        except OSError:
            return 0
    try:
        return une(p) if p.is_file() else sum(une(f) for f in p.rglob("*")) if p.is_dir() else 0
    except OSError:
        return 0


def _remove(p: Path, debrief: dict, cle: str) -> None:
    try:
        n = _size(p)
        shutil.rmtree(p) if p.is_dir() else p.unlink()
        debrief[cle] = debrief.get(cle, 0) + 1
        debrief["octets"] += n
    except OSError:
        pass                                            # file open or locked: try again next time


def backups_to_remove(task_files: list[Path], current_time: datetime | None = None) -> list[Path]:
    """Keeps the most recent of each of the last 7 days, then the most recent of each of the following 4 weeks."""
    current_time = current_time or datetime.now(timezone.utc)
    dates = []
    for f in task_files:
        try:
            dates.append((datetime.strptime(f.name.split("-", 1)[1][:16], "%Y%m%dT%H%M%SZ").replace(tzinfo=timezone.utc), f))
        except (IndexError, ValueError):
            continue                                    # unknown name: never touched
    dates.sort(reverse=True)
    keep, kept_days, weeks = set(), set(), set()
    for d, f in dates:
        age = (current_time - d).days
        if age < BACKUP_DAYS and d.date() not in kept_days:
            kept_days.add(d.date())
            keep.add(f)
        elif BACKUP_DAYS <= age < BACKUP_DAYS + 7 * BACKUP_WEEKS \
                and (age - BACKUP_DAYS) // 7 not in weeks:          # one per 7-day slice
            weeks.add((age - BACKUP_DAYS) // 7)
            keep.add(f)
    for _, f in dates:                                  # never fewer than 3 backups, even old ones
        if len(keep) >= MIN_BACKUPS:
            break
        keep.add(f)
    return [f for _, f in dates if f not in keep]


def _most_recent(dossier: Path, pattern: str, keep: int) -> list[Path]:
    if not dossier.is_dir():
        return []
    task_files = sorted((f for f in dossier.glob(pattern) if f.is_file()), key=lambda f: f.stat().st_mtime, reverse=True)
    return task_files[keep:]


def cap(dossier: Path, pattern: str, keep: int) -> int:
    """Keeps the `garder` most recent (called right after creating a new copy). Returns the number removed."""
    debrief = {"octets": 0}
    for f in _most_recent(Path(dossier), pattern, keep):
        _remove(f, debrief, "n")
    return debrief.get("n", 0)


def rotate_backups(dossier: Path) -> int:
    """Right after the daily backup: 7 days + 4 weeks kept."""
    debrief = {"octets": 0}
    dossier = Path(dossier)
    if dossier.is_dir():
        for f in backups_to_remove([p for p in dossier.glob("studio-*") if p.suffix in (".dpapi", ".zip")]):
            _remove(f, debrief, "n")
    return debrief.get("n", 0)


def cleanup_enabled(config_file: Path) -> bool:
    try:
        from .config import load_config
        return (load_config(config_file).get("entretien") or {}).get("menage_auto") is not False
    except Exception:                                   # noqa: BLE001
        return True


def _old_versions(code: Path, data: Path) -> Path:
    return code.parent / "anciennes-versions" if code.name == "app" else data / "anciennes-versions"


def removable_copy(studio, row: dict) -> bool:
    """A finished task's working copy no longer holds anything useful:
    worktree (the work is on its branch: retirer_espace re-checks), topic (results already filed in Sujets/),
    project in an applied copy or with nothing to apply, cancelled task. Project in a validated but unapplied copy: kept."""
    if row["status"] not in FINISHED:
        return False
    if row["status"] in ("annulee", "echec"):
        return True
    try:
        t = studio.registry.get(row["target"])
    except (KeyError, ValueError):
        return False                                    # project removed from the studio: touch nothing
    if not t.has_path or row["status"] == "appliquee":
        return True
    d = studio.run_dir(row["id"], create_new=False)
    return (d / "copie-de-travail" / ".git").is_file() or (d / "details" / "rien-a-appliquer.json").exists()


def clean_task(studio, tid: str, debrief: dict | None = None) -> dict:
    """End of task (validated, applied, cancelled): removes its working copy and the review copies.
    RESULTAT.md, screenshots and details/ remain. A failed task keeps its copy 7 days (daily sweep)."""
    from . import actions
    from .connectors import workspace as ws
    debrief = debrief if debrief is not None else {"octets": 0}
    try:
        row = studio.store.get(tid)
    except KeyError:
        return debrief
    if not removable_copy(studio, row):
        return debrief
    dossier = studio.run_dir(tid, create_new=False)
    user_workspace = dossier / ws.WORKSPACE
    if user_workspace.exists():
        if (user_workspace / ".git").is_file():                 # git worktree: retirer_espace checks (validated branch intact)
            try:
                n = _size(user_workspace)
                actions.remove_workspace(studio, tid)
                debrief["copies_taches"] = debrief.get("copies_taches", 0) + 1
                debrief["octets"] += n
            except Exception:                           # noqa: BLE001 — files outside the branch, git missing…: keep
                pass
        else:
            _remove(user_workspace, debrief, "copies_taches")
    details = dossier / "details"
    if details.is_dir():
        for copy_dir in details.glob("relecture-*"):       # auditor's throwaway copies
            if copy_dir.is_dir():
                _remove(copy_dir, debrief, "copies_relecture")
    return debrief


def after_task(studio, tid: str) -> None:
    """Called when a task ends: the studio stays tidy as it goes. Never raises."""
    if (studio.cfg.get("entretien") or {}).get("menage_auto") is False:
        return
    try:
        if studio.store.get(tid)["status"] in ("approuvee", "appliquee", "annulee"):
            clean_task(studio, tid)
    except Exception:                                   # noqa: BLE001
        pass


def _tasks(studio, debrief: dict, current_time: float) -> None:
    """Catch-up: tasks finished more than 7 days ago (failures included, or cleanup interrupted at the time)."""
    with studio.store.db() as c:
        rows = c.execute("SELECT id, status, updated_at FROM tasks WHERE status IN (?,?,?,?)", FINISHED).fetchall()
    for r in rows:
        try:
            finish = datetime.fromisoformat(r["updated_at"]).timestamp()
        except (TypeError, ValueError):
            continue
        if current_time - finish >= TASK_DAYS * 86400:
            clean_task(studio, r["id"], debrief)


def _resume_files(studio, debrief: dict) -> None:
    """Checkpoints (LangGraph) of long-finished tasks: useless, a finished task does not resume."""
    import sqlite3
    f = studio.paths.checkpoints
    if not f.exists():
        return
    limite = (datetime.now(timezone.utc) - timedelta(days=RESUME_DAYS)).isoformat(timespec="seconds")
    with studio.store.db() as c:
        ids = [r["id"] for r in c.execute("SELECT id FROM tasks WHERE status IN (?,?,?,?) AND updated_at < ?", (*FINISHED, limite))]
    if not ids:
        return
    try:
        con = sqlite3.connect(f, timeout=5)
        try:
            tables = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            n = 0
            for t in ("checkpoints", "writes"):
                if t in tables:
                    for i in range(0, len(ids), 500):
                        batch = ids[i:i + 500]
                        n += con.execute(f"DELETE FROM {t} WHERE thread_id IN ({','.join('?' * len(batch))})", batch).rowcount
            con.commit()
            if n:
                debrief["reprises"] = debrief.get("reprises", 0) + n   # space reused by SQLite: the file stops growing
        finally:
            con.close()
    except sqlite3.Error:
        pass


def _logs(studio, debrief: dict, current_time: float) -> None:
    d = studio.paths.logs
    if not d.is_dir():
        return
    for f in d.rglob("*"):
        if f.is_file() and current_time - f.stat().st_mtime > LOG_DAYS * 86400:
            _remove(f, debrief, "journaux")
        elif f.is_file() and f.suffix == ".log" and f.stat().st_size > 5 * 2**20:
            try:                                        # active log too large: keep the end (1 MB)
                with open(f, "rb") as h:
                    h.seek(-2**20, 2)
                    finish = h.read()
                before = f.stat().st_size
                f.write_bytes(finish[finish.find(b"\n") + 1:])
                debrief["octets"] += before - f.stat().st_size
                debrief["journaux"] = debrief.get("journaux", 0) + 1
            except OSError:
                pass


def window_cache(data: Path) -> int:
    """Before opening the window: the studio browser caches are emptied if over 150 MB. Returns the bytes freed."""
    debrief = {"octets": 0}
    profile = Path(data) / "edge-studio"
    if profile.is_dir() and _size(profile) >= 150 * 2**20:
        for base in [profile, *[p for p in profile.iterdir() if p.is_dir()]]:
            for nom in WINDOW_CACHES:
                if (base / nom).is_dir():
                    _remove(base / nom, debrief, "n")
    return debrief["octets"]


def _window_cache(studio, debrief: dict) -> None:
    profile = studio.paths.data / "edge-studio"
    if _size(profile) < 150 * 2**20:
        return
    for base in [profile, *[p for p in profile.iterdir() if p.is_dir()]] if profile.is_dir() else []:
        for nom in WINDOW_CACHES:
            if (base / nom).is_dir():
                _remove(base / nom, debrief, "cache_fenetre")


def lancer(studio, forced: bool = False) -> dict:
    """Once a day (or on demand); returns what was freed. Never raises."""
    f = studio.paths.data / "menage.json"
    try:
        last = json.loads(f.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        last = {}
    today = datetime.now().strftime("%Y-%m-%d")
    if not forced and last.get("jour") == today:
        return last
    if not forced and (studio.cfg.get("entretien") or {}).get("menage_auto") is False:
        return {**last, "coupe": True}
    debrief: dict = {"octets": 0}
    current_time = time.time()
    stages = (
        lambda: [_remove(x, debrief, "sauvegardes") for x in backups_to_remove(
            [p for p in studio.paths.backups.glob("studio-*") if p.suffix in (".dpapi", ".zip")])] if studio.paths.backups.is_dir() else None,
        lambda: [_remove(x, debrief, "anciennes_versions") for x in _most_recent(_old_versions(studio.paths.code, studio.paths.data), "*.zip", VERSIONS)],
        lambda: [_remove(x, debrief, "copies_reglages") for x in _most_recent(studio.paths.data / "config-avant", "*.toml", SETTINGS_COPIES)],
        lambda: _tasks(studio, debrief, current_time),
        lambda: _resume_files(studio, debrief),
        lambda: _logs(studio, debrief, current_time),
        lambda: _window_cache(studio, debrief),
    )
    for e in stages:
        try:
            e()
        except Exception:                               # noqa: BLE001 — a failed step does not block the others
            pass
    total = dict(last.get("total") or {})
    for k, v in debrief.items():
        total[k] = total.get(k, 0) + v
    r = {"jour": today, "dernier": debrief, "total": total}
    try:
        f.write_text(json.dumps(r, ensure_ascii=False, indent=1), encoding="utf-8")
    except OSError:
        pass
    return r


def resume(r: dict) -> str:
    b = r.get("dernier") or {}
    if not b.get("octets") and len(b) <= 1:
        return "Rien à libérer."
    mo = b.get("octets", 0) / 2**20
    names = {"sauvegardes": "sauvegarde(s)", "anciennes_versions": "ancienne(s) version(s)", "copies_reglages": "copie(s) de réglages",
            "copies_taches": "copie(s) de projet dans des tâches finies", "copies_relecture": "copie(s) de relecture",
            "reprises": "point(s) de reprise", "journaux": "journal(aux)", "cache_fenetre": "dossier(s) de cache"}
    parts = [f"{v} {names[k]}" for k, v in b.items() if k in names and v]
    return f"{mo:.0f} Mo libérés : " + ", ".join(parts) + "."


def migrate_deliverables(studio) -> int:
    """One-time: results filed in Livrables/<Topic name>/ move to their topic (Sujets/<topic>/).
    Nothing is overwritten or lost: an identical file already there is not copied again, a different file becomes « nom v2 ».
    Livrables/ is removed only if it contains nothing but its LISEZ-MOI."""
    import hashlib
    from .folders import clean
    base = studio.paths.deliverables
    if not base.is_dir():
        return 0
    empreinte = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()    # noqa: E731
    n = 0
    for t in studio.registry.all():
        if t.kind != "topic":
            continue
        src = base / (clean(t.nom or t.id) or t.id)
        if not src.is_dir():
            continue
        for f in sorted(p for p in src.rglob("*") if p.is_file()):
            dest = studio.paths.topics / t.id / f.relative_to(src)
            dest.parent.mkdir(parents=True, exist_ok=True)
            k = 2
            while dest.exists() and empreinte(dest) != empreinte(f):
                dest = dest.with_name(f"{f.stem} v{k}{f.suffix}")
                k += 1
            if dest.exists():
                f.unlink()                              # identical copy already in the topic
            else:
                shutil.move(str(f), str(dest))
            n += 1
        for d in sorted((p for p in src.rglob("*") if p.is_dir()), key=lambda p: -len(p.parts)) + [src]:
            try:
                d.rmdir()                               # only folders that became empty
            except OSError:
                pass
    leftover = [p for p in base.rglob("*") if p.is_file() and p.name != "LISEZ-MOI.md"]
    if not leftover:
        (base / "LISEZ-MOI.md").unlink(missing_ok=True)
        try:
            base.rmdir()
        except OSError:
            pass
    return n


# Program files renamed when the code moved to English (0.4.20): an update only adds or replaces files, so the old
# copies are removed here once their replacement is present. Only inside the program folder, never user data.
RENAMED_FILES = {
    "studio/accueil.py": "studio/welcome.py",
    "studio/activite.py": "studio/activity.py",
    "studio/apprentissage.py": "studio/learning.py",
    "studio/bibliotheque.py": "studio/library.py",
    "studio/chaines.py": "studio/chains.py",
    "studio/coffre.py": "studio/vault.py",
    "studio/connecteurs.py": "studio/software_connectors.py",
    "studio/connectors/chatgpt.py": "studio/connectors/copy_paste.py",
    "studio/dossiers.py": "studio/folders.py",
    "studio/equipes.py": "studio/teams.py",
    "studio/espace.py": "studio/user_workspace.py",
    "studio/fichiers.py": "studio/task_files.py",
    "studio/garde_mcp.py": "studio/mcp_guard.py",
    "studio/git_projets.py": "studio/project_git.py",
    "studio/ia.py": "studio/ai.py",
    "studio/import_initial.py": "studio/initial_import.py",
    "studio/langue.py": "studio/ui_language.py",
    "studio/limites.py": "studio/limits.py",
    "studio/menage.py": "studio/cleanup.py",
    "studio/mise_a_jour.py": "studio/updates.py",
    "studio/modeles_locaux.py": "studio/local_models.py",
    "studio/modeles_projet.py": "studio/project_templates.py",
    "studio/nuit.py": "studio/night.py",
    "studio/outils_agents.py": "studio/agent_tools.py",
    "studio/pieces.py": "studio/attachments.py",
    "studio/plateforme.py": "studio/os_support.py",
    "studio/premier_lancement.py": "studio/first_launch.py",
    "studio/raccourcis.py": "studio/shortcuts.py",
    "studio/reglages.py": "studio/settings.py",
    "studio/superviseur.py": "studio/supervisor.py",
    "studio/systeme.py": "studio/system.py",
    "studio/titres.py": "studio/titles.py",
    "tests/test_accueil.py": "tests/test_welcome.py",
    "tests/test_activite.py": "tests/test_activity.py",
    "tests/test_bibliotheque.py": "tests/test_library.py",
    "tests/test_chaines_et_outils.py": "tests/test_chains_and_tools.py",
    "tests/test_compte_rendu.py": "tests/test_report.py",
    "tests/test_connecteurs.py": "tests/test_connectors.py",
    "tests/test_dictee.py": "tests/test_dictation.py",
    "tests/test_equipes.py": "tests/test_teams.py",
    "tests/test_espace.py": "tests/test_user_workspace.py",
    "tests/test_fichiers.py": "tests/test_task_files.py",
    "tests/test_garde_mcp.py": "tests/test_mcp_guard.py",
    "tests/test_git_projets.py": "tests/test_project_git.py",
    "tests/test_ia.py": "tests/test_ai.py",
    "tests/test_lanceur.py": "tests/test_launcher.py",
    "tests/test_limites.py": "tests/test_limits.py",
    "tests/test_memoire.py": "tests/test_memory.py",
    "tests/test_menage.py": "tests/test_cleanup.py",
    "tests/test_mise_a_jour.py": "tests/test_updates.py",
    "tests/test_modeles_locaux.py": "tests/test_local_models.py",
    "tests/test_nuit.py": "tests/test_night.py",
    "tests/test_outils_agents.py": "tests/test_agent_tools.py",
    "tests/test_parcours.py": "tests/test_workflow.py",
    "tests/test_pieces.py": "tests/test_attachments.py",
    "tests/test_raccourcis.py": "tests/test_shortcuts.py",
    "tests/test_rangement.py": "tests/test_tidying.py",
    "tests/test_reglages.py": "tests/test_settings.py",
    "tests/test_releve_outils.py": "tests/test_tools_snapshot.py",
    "tests/test_sauvegarde.py": "tests/test_backup.py",
    "tests/test_skill_superviseur.py": "tests/test_supervisor_skill.py",
    "tests/test_stop_et_bilan.py": "tests/test_stop_and_summary.py",
    "tests/test_superviseur.py": "tests/test_supervisor.py",
    "tests/test_titres.py": "tests/test_titles.py",
    "tests/test_usage_et_cibles.py": "tests/test_usage_and_targets.py",
    "scripts/Appliquer-Configs.ps1": "scripts/Apply-Configs.ps1",
    "scripts/Arreter-Memoire.ps1": "scripts/Stop-Memory.ps1",
    "scripts/Commun.ps1": "scripts/Common.ps1",
    "scripts/Creer-Raccourci.ps1": "scripts/Create-Shortcut.ps1",
    "scripts/Demarrer-Memoire.ps1": "scripts/Start-Memory.ps1",
    "scripts/Installer-Dependances.ps1": "scripts/Install-Dependencies.ps1",
    "scripts/Installer-Lecture-Pieces.ps1": "scripts/Install-Attachment-Readers.ps1",
    "scripts/Lancer-Interface.ps1": "scripts/Start-Interface.ps1",
    "scripts/Mise-En-Service.ps1": "scripts/Setup-Studio.ps1",
    "scripts/Reparer-Memoire.ps1": "scripts/Repair-Memory.ps1",
    "scripts/Restaurer-Configs.ps1": "scripts/Restore-Configs.ps1",
    "scripts/Sauvegarder-Standalone.ps1": "scripts/Backup-Standalone.ps1",
    "scripts/Securiser-Port-Moteur.ps1": "scripts/Secure-Engine-Port.ps1",
    "scripts/Synchroniser-Skills.ps1": "scripts/Sync-Skills.ps1",
    "scripts/Tests-Integration.ps1": "scripts/Run-Integration-Tests.ps1",
    "scripts/Verifier-Environnement.ps1": "scripts/Test-Environment.ps1",
    "scripts/Verifier-Sauvegardes-DPAPI.ps1": "scripts/Test-DPAPI-Backups.ps1",
    "scripts/outils/generer_fond_ondes.py": "scripts/tools/generate_wave_background.py",
    "scripts/outils/menage_claude_20261022.py": "scripts/tools/cleanup_20261022.py",
    "scripts/outils/ranger_maj75.py": "scripts/tools/tidy_update75.py",
    "scripts/outils/unreal_compiler.py": "scripts/tools/unreal_compiler.py",
    "installeur/construire.py": "installeur/build.py",
    "studio/ui/static/icone-192.png": "studio/ui/static/icon-192.png",
    "studio/ui/static/icone-512.png": "studio/ui/static/icon-512.png",
    "studio/ui/static/logo-entete.png": "studio/ui/static/header-logo.png",
    "studio/ui/static/premier.html": "studio/ui/static/first-launch.html",
    "studio/ui/static/premier.js": "studio/ui/static/first-launch.js",
}


def remove_obsolete_files(code: Path) -> int:
    """Delete old program files whose renamed replacement exists (and their compiled caches). Returns the count."""
    removed = 0
    for old, new in RENAMED_FILES.items():
        o, n = Path(code) / old, Path(code) / new
        if o.is_file() and n.is_file():
            try:
                o.unlink()
                removed += 1
            except OSError:
                continue
            for cache in (o.parent / "__pycache__").glob(o.stem + ".*.pyc"):
                try:
                    cache.unlink()
                except OSError:
                    pass
    return removed


def _renamed_dirs() -> dict[str, str]:
    """Program template folders renamed to English (skills of the templates, packs and library)."""
    from .renames import SKILL_RENAMES
    out = {"modeles/bibliotheque": "modeles/library"}
    for old, new in SKILL_RENAMES.items():
        out[f"modeles/espace/Skills/{old}"] = f"modeles/espace/Skills/{new}"
        out[f"modeles/library/Skills/{old}"] = f"modeles/library/Skills/{new}"
        out[f"modeles/bibliotheque/Skills/{old}"] = f"modeles/library/Skills/{new}"
        for pack in ("avance", "blender", "unreal", "concept-art"):
            out[f"modeles/packs/{pack}/Skills/{old}"] = f"modeles/packs/{pack}/Skills/{new}"
    out.update({f"modeles/espace/Regles/{o}": f"modeles/espace/Regles/{n}" for o, n in
                (("INSTRUCTIONS-COMMUNES.md", "COMMON-INSTRUCTIONS.md"), ("PRIORITES.md", "PRIORITIES.md"), ("SECURITE.md", "SECURITY.md"))})
    return out


def remove_obsolete_template_files(code: Path) -> int:
    """Old copies of renamed template files and folders: removed only where the renamed copy exists (program files,
    never user data), then empty folders are removed."""
    removed = 0
    code = Path(code)
    for old, new in _renamed_dirs().items():
        o, n = code / old, code / new
        if o.is_file() and n.is_file():
            pairs = [(o, n)]
        elif o.is_dir() and n.is_dir():
            pairs = [(f, n / f.relative_to(o)) for f in o.rglob("*") if f.is_file()]
        else:
            continue
        for f, g in pairs:
            if g.is_file():
                try:
                    f.unlink()
                    removed += 1
                except OSError:
                    pass
        if o.is_dir():
            for d in sorted((x for x in o.rglob("*") if x.is_dir()), key=lambda x: len(x.parts), reverse=True) + [o]:
                try:
                    d.rmdir()                                 # only if empty
                except OSError:
                    pass
    return removed
