"""Shared model for studio memories.

Each memory has: an identity (stable idempotency key), a scope,
a provenance, dates, an optional subject (to detect contradictions)
and possibly the key of the memory it corrects.
"""
from __future__ import annotations

import hashlib
import re
import unicodedata
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from typing import Literal

ScopeKind = Literal["general", "project", "topic", "task"]
_ID_RE = re.compile(r"^[a-z0-9][a-z0-9._-]{0,63}$")
LABEL_PREFIX = "studio:"


def utcnow() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


@dataclass(frozen=True)
class Scope:
    kind: ScopeKind
    id: str = ""

    def __post_init__(self):
        if self.kind not in ("general", "project", "topic", "task"):
            raise ValueError(f"Portée inconnue : {self.kind}")
        if self.kind == "general":
            if self.id:
                raise ValueError("La portée générale n'a pas d'identifiant.")
        elif not _ID_RE.match(self.id or ""):
            raise ValueError(f"Identifiant de portée invalide : {self.id!r}")

    @property
    def label(self) -> str:
        """Label stored on the engine side (AgentMemory ``project`` field)."""
        return LABEL_PREFIX + ("general" if self.kind == "general" else f"{self.kind}:{self.id}")

    @classmethod
    def parse(cls, text: str) -> "Scope":
        text = text.strip()
        if text.startswith(LABEL_PREFIX):
            text = text[len(LABEL_PREFIX):]
        if text in ("general", "général"):
            return cls("general")
        kind, _, ident = text.partition(":")
        aliases = {"projet": "project", "sujet": "topic", "tache": "task", "tâche": "task"}
        return cls(aliases.get(kind, kind), ident)  # type: ignore[arg-type]

    def __str__(self) -> str:
        return self.label


GENERAL = Scope("general")


def normalize(text: str) -> str:
    text = unicodedata.normalize("NFKC", text).strip().lower()
    return re.sub(r"\s+", " ", text)


def content_key(scope: Scope, content: str) -> str:
    return hashlib.sha256(f"{scope.label}\n{normalize(content)}".encode()).hexdigest()[:32]


@dataclass
class Provenance:
    outil: str                 # "claude-code", "codex", "studio", "chatgpt-import", "mel"
    agent: str = ""            # role or session identifier
    tache: str = ""            # studio task identifier
    source: str = ""           # file, URL, conversation…


@dataclass
class MemoryRecord:
    scope: Scope
    content: str
    key: str
    provenance: Provenance
    type: str = "fact"
    subject: str = ""          # e.g. "rpg3d.version-moteur"
    supersedes: str = ""       # key of the corrected memory
    created_at: str = field(default_factory=utcnow)
    backend_id: str = ""
    # Computed on read (never stored):
    status: str = "actif"      # actif | remplace | conteste

    def to_dict(self) -> dict:
        d = asdict(self)
        d["scope"] = self.scope.label
        return d


@dataclass
class WriteResult:
    status: str                # cree | deja_present | en_attente_non_partage | conteste
    record: MemoryRecord
    detail: str = ""

    @property
    def shared(self) -> bool:
        return self.status in ("cree", "deja_present", "conteste")


@dataclass
class Health:
    etat: str                  # OK | EN_PANNE | DEGRADE | NON_CONFIGURE
    backend: str
    detail: str = ""
    en_attente: int = 0        # local writes not shared

    def to_dict(self) -> dict:
        return asdict(self)


class MemoryUnavailable(RuntimeError):
    """The central storage is not responding. Never hide this error."""
