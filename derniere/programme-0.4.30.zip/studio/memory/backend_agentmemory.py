"""AgentMemory backend (local REST API, http://127.0.0.1:3111).

Findings verified in the AgentMemory code (see Decisions/ADR-0003):
- 0.9.22 (installed version): no ``project`` field; ``/memories`` does not filter
  by scope; automatic "supersession" (Jaccard similarity > 0.7)
  applies to all memories, across all scopes.
- 0.9.30: ``project`` stored and filtered by ``/memories``; ``smart-search``
  still ignores ``project`` for memories.

Consequently, this backend never uses ``smart-search`` and enforces scope
itself: each memory carries its scope in ``concepts`` and in a header
line; reading lists the memories then filters on the studio side. The
``project`` field is also sent (used by 0.9.30, ignored by 0.9.22).
The header holds the scope, the key and a scope-specific "salt" of tokens,
proportional to the text length: the similarity between a memory and an identical
text from another scope (or without scope) stays < 0.67, below the 0.7 threshold
of 0.9.22's automatic supersession. The salt is removed on read.
"""
from __future__ import annotations

import hashlib
import json
import os
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

from .models import MemoryRecord, MemoryUnavailable, Provenance, Scope

C_SCOPE, C_KEY, C_SUBJ, C_SUP, C_PROV, C_CREATED = (
    "studio-portee=", "studio-cle=", "studio-sujet=", "studio-corrige=", "studio-prov=", "studio-cree=")
HEADER_PREFIX = "[studio-portee="


def _is_loopback(url: str) -> bool:
    host = urllib.parse.urlparse(url).hostname or ""
    return host in ("127.0.0.1", "localhost", "::1")


def read_secret(url: str, env: dict | None = None, home: Path | None = None) -> str:
    """Same rule as the official client: environment variable, otherwise
    ``~/.agentmemory/.env`` then ``~/.agentmemory/secret``, loopback only.
    The value is never logged."""
    env = os.environ if env is None else env
    if env.get("AGENTMEMORY_SECRET"):
        return env["AGENTMEMORY_SECRET"]
    if not _is_loopback(url):
        return ""
    home = home or Path.home()
    envfile = home / ".agentmemory" / ".env"
    if envfile.exists():
        for line in envfile.read_text(encoding="utf-8", errors="ignore").splitlines():
            if line.startswith("AGENTMEMORY_SECRET="):
                return line.split("=", 1)[1].strip().strip('"').strip("'")
    sfile = home / ".agentmemory" / "secret"
    if sfile.exists():
        return sfile.read_text(encoding="utf-8").strip()
    return ""


class AgentMemoryBackend:
    name = "agentmemory"

    def __init__(self, url: str = "http://127.0.0.1:3111", timeout: float = 5.0, secret: str | None = None,
                 task_ttl_days: int = 14):
        if not _is_loopback(url):
            raise ValueError("Le studio n'utilise AgentMemory qu'en boucle locale.")
        self.url = url.rstrip("/")
        self.timeout = timeout
        self._secret = read_secret(self.url) if secret is None else secret
        self.version = ""
        self.task_ttl_days = task_ttl_days

    # -- HTTP ---------------------------------------------------------------
    def _req(self, method: str, path: str, body: dict | None = None, query: dict | None = None):
        url = f"{self.url}/agentmemory/{path}"
        if query:
            url += "?" + urllib.parse.urlencode(query)
        data = json.dumps(body).encode() if body is not None else None
        req = urllib.request.Request(url, data=data, method=method)
        req.add_header("Content-Type", "application/json")
        if self._secret:
            req.add_header("Authorization", f"Bearer {self._secret}")
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                raw = resp.read()
                return json.loads(raw) if raw else {}
        except urllib.error.HTTPError as e:
            if e.code == 401:
                raise MemoryUnavailable("AgentMemory refuse l'accès (secret absent ou différent).") from None
            raise MemoryUnavailable(f"AgentMemory a répondu HTTP {e.code} sur {path}.") from None
        except (urllib.error.URLError, TimeoutError, ConnectionError, OSError) as e:
            raise MemoryUnavailable(
                f"Serveur AgentMemory injoignable sur {self.url} ({type(e).__name__}). "
                "Aucun partage n'est possible tant qu'il n'est pas démarré.") from None

    # -- backend API --------------------------------------------------------
    def ping(self) -> dict:
        self._req("GET", "livez")
        h = self._req("GET", "health")
        self.version = str(h.get("version", ""))
        return {"ok": True, "detail": f"AgentMemory {self.version} ({h.get('status', '?')})", "version": self.version}

    @staticmethod
    def _salt(label: str, content: str) -> str:
        n = len([t for t in content.split() if len(t) > 2])
        k = min(n // 2 + 3, 600)
        return " ".join("s" + hashlib.sha256(f"{label}:{i}".encode()).hexdigest()[:8] for i in range(k))

    def _encode(self, rec: MemoryRecord) -> dict:
        prov = json.dumps(rec.provenance.__dict__, ensure_ascii=False, separators=(",", ":"))
        header = (f"{HEADER_PREFIX}{rec.scope.label}] [studio-cle={rec.key}] "
                  f"[studio-sel {self._salt(rec.scope.label, rec.content)}]")
        concepts = [C_SCOPE + rec.scope.label, C_KEY + rec.key, C_CREATED + rec.created_at, C_PROV + prov]
        if rec.subject:
            concepts.append(C_SUBJ + rec.subject)
        if rec.supersedes:
            concepts.append(C_SUP + rec.supersedes)
        extra = {"ttlDays": self.task_ttl_days} if rec.scope.kind == "task" else {}   # temporary task state
        return {
            **extra,
            "content": f"{header}\n{rec.content}",
            "type": rec.type if rec.type in ("pattern", "preference", "architecture", "bug", "workflow", "fact") else "fact",
            "concepts": concepts,
            "project": rec.scope.label,
            "agentId": rec.provenance.outil[:128] or "studio",
        }

    @staticmethod
    def _decode(m: dict, scope: Scope) -> MemoryRecord | None:
        concepts = [c for c in (m.get("concepts") or []) if isinstance(c, str)]
        meta = {}
        for c in concepts:
            for p in (C_SCOPE, C_KEY, C_SUBJ, C_SUP, C_PROV, C_CREATED):
                if c.startswith(p) and p not in meta:
                    meta[p] = c[len(p):]
        if meta.get(C_SCOPE) != scope.label:          # scope enforced on read
            return None
        project = m.get("project")
        if project is not None and project != scope.label:
            return None
        content = str(m.get("content", ""))
        if content.startswith(HEADER_PREFIX):
            content = content.split("\n", 1)[1] if "\n" in content else ""
        try:
            prov = Provenance(**json.loads(meta.get(C_PROV, "{}")))
        except (TypeError, ValueError):
            prov = Provenance(outil="inconnu")
        return MemoryRecord(scope=scope, content=content, key=meta.get(C_KEY, ""), provenance=prov,
                            type=str(m.get("type", "fact")), subject=meta.get(C_SUBJ, ""),
                            supersedes=meta.get(C_SUP, ""), created_at=meta.get(C_CREATED) or str(m.get("createdAt", "")),
                            backend_id=str(m.get("id", "")))

    def _all(self, scope: Scope) -> list[dict]:
        out, offset, page = [], 0, 1000
        while True:
            q = {"limit": page, "offset": offset, "agentId": "*", "includeOrphans": "true", "project": scope.label}
            body = self._req("GET", "memories", query=q)
            items = body.get("memories", []) if isinstance(body, dict) else []
            if not items:
                return out
            out.extend(items)
            offset += len(items)                  # the server may cap the page size
            if offset > 1_000_000:
                raise MemoryUnavailable("Pagination AgentMemory incohérente.")

    def list(self, scope: Scope) -> list[MemoryRecord]:
        recs = [r for r in (self._decode(m, scope) for m in self._all(scope)) if r and r.key]
        recs.sort(key=lambda r: r.created_at)
        return recs

    def put(self, rec: MemoryRecord) -> tuple[str, bool]:
        for existing in self.list(rec.scope):
            if existing.key == rec.key:
                return existing.backend_id, False
        body = self._req("POST", "remember", body=self._encode(rec))
        if isinstance(body, dict) and body.get("success") is False:
            raise MemoryUnavailable(f"AgentMemory a refusé l'écriture : {body.get('error', 'raison inconnue')}")
        mem = body.get("memory", {}) if isinstance(body, dict) else {}
        return str(mem.get("id", "")), True
