"""Readable folder names for tasks: « 2026-10-24 Brancher les animations ».

The technical ID (T20261024-…) stays in the database; only the visible folder has a clear name.
Windows-safe names: no < > : " / \\ | ? *, no trailing dot or space, bounded length.
"""
from __future__ import annotations

import re
from datetime import datetime
from pathlib import Path

_FORBIDDEN = re.compile(r'[<>:"/\\|?*\x00-\x1f]+')
_SMALL_WORDS = {"à", "a", "de", "du", "des", "d", "le", "la", "les", "l", "et", "ou", "avec", "ses", "son", "sa",
                "pour", "au", "aux", "en", "un", "une", "que", "qui", "dans", "sur", "par"}
_RESERVED = {"con", "prn", "aux", "nul", *(f"com{i}" for i in range(1, 10)), *(f"lpt{i}" for i in range(1, 10))}


def clean(texte: str, max_bytes: int = 60) -> str:
    t = _FORBIDDEN.sub(" ", texte or "")
    t = re.sub(r"\s+", " ", t).strip()
    if len(t) > max_bytes:
        t = t[:max_bytes].rsplit(" ", 1)[0] if " " in t[:max_bytes] else t[:max_bytes]
    cut = t.endswith("…")
    t = t.rstrip(" .…,;:-–—")
    if cut:                                       # truncated title: no small word dangling at the end
        words = t.split(" ")
        while len(words) > 2 and words[-1].lower() in _SMALL_WORDS:
            words.pop()
        t = " ".join(words).rstrip(" ,;:-–—")
    return "" if t.lower() in _RESERVED else t


def task_name(title: str, when: datetime | None = None, already_exists=lambda nom: False) -> str:
    """« YYYY-MM-DD Title »; « (2) », « (3) »… if the name is already taken."""
    day = (when or datetime.now()).strftime("%Y-%m-%d")
    base = f"{day} {clean(title) or 'Tâche'}"
    nom, n = base, 2
    while already_exists(nom):
        nom, n = f"{base} ({n})", n + 1
    return nom


def is_simple_name(nom: str) -> bool:
    return bool(nom) and nom == Path(nom).name and nom not in (".", "..") and not _FORBIDDEN.search(nom)
