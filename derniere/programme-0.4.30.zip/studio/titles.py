"""Short name of a task: a few clear words, the full request stays alongside.

The Supervisor proposes its own title ("titre" in its proposal). Otherwise — direct task, chain, old
task — the studio derives it from the request: first sentence, without « Objectif : », without Markdown, 60 characters max.
"""
from __future__ import annotations

import re

PREFIXES = r"(objectif|but|tâche|tache|demande|mission|contexte|résumé|resume|titre|todo|à faire|a faire)\s*[:：\-–—]\s*"


def without_project(t: str, names: tuple[str, ...] = ()) -> str:
    """Removes the project name (we already see which tab we are in): « … sur RPG3D », « RPG3D : … »."""
    for n in sorted({x for x in names if x and len(x) >= 2}, key=len, reverse=True):
        n = re.escape(n)
        t = re.sub(rf"\s*\b(sur|dans|de|du|pour|à|au)\s+(le\s+projet\s+|le\s+)?{n}\b", "", t, flags=re.I)
        t = re.sub(rf"^\s*{n}\s*[:：\-–—]\s*", "", t, flags=re.I)
        t = re.sub(rf"\s*\(\s*{n}\s*\)", "", t, flags=re.I)
    return " ".join(t.split()).strip(" ,;:-–—")


def short_title(demande: str, max_bytes: int = 50, names: tuple[str, ...] = ()) -> str:
    t = str(demande or "").split("\n\n---\n")[0]                       # chain reminder: for the agent, not for the name
    t = re.sub(r"[`*#>]+", "", t)
    t = re.sub(r"(?<!\w)_+|_+(?!\w)", "", t)  # keeps L_Exploration
    t = re.sub(r"[$\[]audit-(skills|memories)\s+audit\b.*", lambda m: "Audit des " + ("skills" if m.group(1) == "skills" else "mémoires"), t, flags=re.S)
    t = re.sub(r"[$\[]audit-(skills|memories)\s+(fix|clean)\b.*", lambda m: "Appliquer l'audit des " + ("skills" if m.group(1) == "skills" else "mémoires"), t, flags=re.S)
    t = " ".join(t.split())
    t = re.sub(r"^" + PREFIXES, "", t, flags=re.I)
    m = re.match(r"(?:exécute|execute|fais|réalise|traite)\s+(?:la\s+)?tâche\s+(?:\S*[/\\])?([\w.-]+?)\.md\b", t, re.I)
    if m:                                       # « Exécute la tâche Tasks/Corriger-X.md » → « Corriger X »
        t = m.group(1).replace("-", " ").replace("_", " ")
    # first sentence or first part before « Où : », « Contexte : »…
    t = re.split(r"(?<=[.!?])\s|\s(?:où|ou|contexte|lis|lire|cible|livrable|critères?|périmètre)\s*:\s", t, maxsplit=1, flags=re.I)[0]
    t = without_project(t.strip(" .;:-–—"), names)
    if len(t) > max_bytes and 20 <= t.rfind(", ", 0, max_bytes + 1):
        t = t[:t.rfind(", ", 0, max_bytes + 1)]                      # a comma before the limit: stop there
    if len(t) > max_bytes:
        cut = t[:max_bytes].rsplit(" ", 1)[0].rstrip(" ,;:-–—(")
        t = (cut or t[:max_bytes]) + "…"
    return (t[:1].upper() + t[1:]) if t else "Tâche"
