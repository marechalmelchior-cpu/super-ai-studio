"""Supervisor « / » shortcuts: ready-made requests (modeles/raccourcis.json), extended or replaced by
the user's own (data/raccourcis.json, same shape). Read-only; an unreadable file is ignored."""
from __future__ import annotations

import json
import re
from pathlib import Path


def _read(f: Path) -> list[dict]:
    try:
        d = json.loads(f.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return []
    out = []
    for r in (d.get("raccourcis") if isinstance(d, dict) else d) or []:
        if isinstance(r, dict) and re.fullmatch(r"[a-z0-9-]{1,30}", str(r.get("nom", ""))) and str(r.get("texte", "")).strip():
            out.append({"nom": r["nom"], "titre": str(r.get("titre") or r["nom"])[:60], "texte": str(r["texte"])[:4000]})
    return out


def entries(code: Path, data: Path) -> list[dict]:
    all_items = {r["nom"]: r for r in _read(Path(code) / "modeles" / "raccourcis.json")}
    for r in _read(Path(data) / "raccourcis.json"):
        all_items[r["nom"]] = {**r, "perso": True}
    return list(all_items.values())
