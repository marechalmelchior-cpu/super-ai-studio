"""First launch (studio installed without a workspace): wizard in the studio window.

1. First name. 2. Workspace folder (suggested: Documents\\Studio IA; an existing workspace is joined as is).
3. Optional packs. 4. Tools already on the PC (read-only). → « Créer mon studio ».
Same protections as the studio: 127.0.0.1 only, session key exchanged for a cookie, X-Studio header on
submissions. Nothing is installed; no existing file is overwritten. Connecting an AI happens afterwards, in the
studio (Supervisor).
"""
from __future__ import annotations

import hmac
import json
import secrets
import subprocess
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from . import user_workspace

STATIC = Path(__file__).resolve().parent / "ui" / "static"
COOKIE = "studio_premier"
ABSENCE_S = 180                     # window closed before finishing: the wizard stops (nothing was created)


def choose_folder(origin: str = "") -> str:
    """System « Choose a folder » dialog (Windows, Finder on Mac, zenity or kdialog on Linux). Empty if cancelled."""
    if sys.platform != "win32":
        import shutil
        if sys.platform == "darwin":
            cmd = ["osascript", "-e", 'POSIX path of (choose folder with prompt "Dossier de ton studio")']
        elif shutil.which("zenity"):
            cmd = ["zenity", "--file-selection", "--directory", "--title=Dossier de ton studio"] + ([f"--filename={origin}/"] if origin else [])
        elif shutil.which("kdialog"):
            cmd = ["kdialog", "--getexistingdirectory", origin or str(Path.home())]
        else:
            return ""
        try:
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=600, stdin=subprocess.DEVNULL)
            return r.stdout.strip().rstrip("/") if r.returncode == 0 else ""
        except (OSError, subprocess.TimeoutExpired):
            return ""
    from .connectors.base import NO_WINDOW
    script = ("Add-Type -AssemblyName System.Windows.Forms; $d = New-Object System.Windows.Forms.FolderBrowserDialog; "
              "$d.Description = 'Dossier de ton studio'; $d.ShowNewFolderButton = $true; "
              "$d.SelectedPath = $env:STUDIO_DEPART; "
              "if ($d.ShowDialog() -eq 'OK') { [Console]::OutputEncoding = [Text.Encoding]::UTF8; $d.SelectedPath }")
    try:
        import os
        r = subprocess.run(["powershell", "-NoProfile", "-STA", "-Command", script], capture_output=True, text=True,
                           env={**os.environ, "STUDIO_DEPART": origin[:400]},
                           encoding="utf-8", errors="replace", timeout=600, stdin=subprocess.DEVNULL, **NO_WINDOW)
        return r.stdout.strip().splitlines()[-1] if r.stdout.strip() else ""
    except (OSError, subprocess.TimeoutExpired):
        return ""


def folder_state(dossier: str) -> dict:
    d = Path(dossier).expanduser()
    if not dossier or not d.is_absolute():
        return {"ok": False, "info": "Indique un chemin complet."}
    if user_workspace.is_workspace(d):
        return {"ok": True, "rejoindre": True, "info": "Un studio existe déjà ici : il sera repris tel quel."}
    if d.exists() and not d.is_dir():
        return {"ok": False, "info": "Ce chemin est un fichier."}
    if d.exists() and any(d.iterdir()):
        subdir = d / "Studio IA"
        if user_workspace.is_workspace(subdir):
            return {"ok": True, "rejoindre": True, "cible": str(subdir), "info": "Un studio existe déjà dans « Studio IA » : il sera repris."}
        return {"ok": True, "cible": str(subdir), "info": f"Ce dossier contient déjà des fichiers : le studio sera créé dans {subdir} (rien n'est touché)."}
    return {"ok": True, "info": "Le dossier sera créé." if not d.exists() else "Dossier vide : parfait."}


def serve(port: int, open_, after_create, note=lambda m: None) -> dict | None:
    """Runs the wizard; returns the result of creer_espace, or None if the window was closed before the end.
    ``ouvrir(url)`` opens the window; ``apres_creation(racine) -> str`` returns the studio address (key included)."""
    cle = secrets.token_urlsafe(24)
    finish = threading.Event()
    result: dict = {}
    presence = {"t": time.monotonic()}
    hosts = {f"127.0.0.1:{port}", f"localhost:{port}"}

    class H(BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def _send(self, code: int, obj=None, ctype="application/json", raw: bytes | None = None, extra=()):
            data = raw if raw is not None else json.dumps(obj, ensure_ascii=False).encode()
            self.send_response(code)
            self.send_header("Content-Type", f"{ctype}; charset=utf-8" if ctype.startswith(("text", "application/json")) else ctype)
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Referrer-Policy", "no-referrer")
            self.send_header("Content-Security-Policy", "default-src 'self'; img-src 'self' data:; style-src 'self' "
                                                        "'unsafe-inline'; script-src 'self'; frame-ancestors 'none'")
            for k, v in extra:
                self.send_header(k, v)
            self.end_headers()
            self.wfile.write(data)

        def _cookie_ok(self) -> bool:
            for part in (self.headers.get("Cookie") or "").split(";"):
                k, _, v = part.strip().partition("=")
                if k == COOKIE and hmac.compare_digest(v, cle):
                    return True
            return False

        def do_GET(self):
            if self.headers.get("Host") not in hosts:
                return self._send(403, {"erreur": "hôte refusé"})
            u = urlparse(self.path)
            if u.path == "/api/ping":
                return self._send(200, {"premier": True})
            if u.path in ("/header-logo.png", "/icon-192.png"):
                return self._send(200, ctype="image/png", raw=(STATIC / u.path.lstrip("/")).read_bytes())
            if u.path.startswith("/fonts/") and (STATIC / u.path.lstrip("/")).is_file() and ".." not in u.path:
                return self._send(200, ctype="font/woff2", raw=(STATIC / u.path.lstrip("/")).read_bytes())
            t = (parse_qs(u.query).get("t") or [""])[0]
            if u.path == "/" and t and hmac.compare_digest(t, cle):
                return self._send(303, raw=b"", extra=(("Set-Cookie", f"{COOKIE}={cle}; HttpOnly; SameSite=Strict; Path=/"),
                                                         ("Location", "/")))
            if not self._cookie_ok():
                return self._send(403, ctype="text/html", raw="<p style='font:16px system-ui;padding:30px'>Relance le studio.</p>".encode())
            presence["t"] = time.monotonic()
            if u.path == "/":
                return self._send(200, ctype="text/html", raw=(STATIC / "first-launch.html").read_bytes())
            if u.path == "/first-launch.js":
                return self._send(200, ctype="text/javascript", raw=(STATIC / "first-launch.js").read_bytes())
            if u.path == "/api/infos":
                return self._send(200, {"dossier": str(user_workspace.proposed_folder()), "packs": user_workspace.packs(),
                                        "outils": user_workspace.detect_tools()})
            return self._send(404, {"erreur": "inconnu"})

        def do_POST(self):
            if self.headers.get("Host") not in hosts or self.headers.get("X-Studio") != "1" or not self._cookie_ok():
                return self._send(403, {"erreur": "refusé"})
            presence["t"] = time.monotonic()
            n = int(self.headers.get("Content-Length", 0) or 0)
            u = urlparse(self.path).path
            try:
                b = json.loads(self.rfile.read(min(n, 100_000)) or b"{}")
                if not isinstance(b, dict):
                    raise ValueError("Requête invalide.")
                if u == "/api/presence":
                    return self._send(200, {"ok": True})
                if u == "/api/verifier":
                    return self._send(200, folder_state(str(b.get("dossier", ""))))
                if u == "/api/parcourir":
                    return self._send(200, {"dossier": choose_folder(str(b.get("dossier", "")))})
                if u == "/api/creer":
                    if result:
                        return self._send(409, {"erreur": "déjà créé"})
                    known = {p["id"] for p in user_workspace.packs()}
                    choice = [p for p in b.get("packs", []) if p in known]
                    r = user_workspace.create_workspace(Path(str(b.get("dossier", ""))), str(b.get("nom", "")), choice,
                                                     language="en" if b.get("langue") == "en" else "fr")
                    result.update(r)
                    next_url = after_create(Path(r["racine"]))
                    note(f"premier lancement : espace {'rejoint' if r['rejoint'] else 'créé'}")
                    self._send(200, {"ok": True, **r, "crees": len(r["crees"]), "suite": next_url})
                    finish.set()
                    return
            except (ValueError, OSError) as e:
                return self._send(400, {"erreur": str(e)})
            return self._send(404, {"erreur": "inconnu"})

    httpd = ThreadingHTTPServer(("127.0.0.1", port), H)
    httpd.daemon_threads = True
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    open_(f"http://127.0.0.1:{port}/?t={cle}")
    while not finish.wait(2):
        if time.monotonic() - presence["t"] > ABSENCE_S:
            break
    time.sleep(0.3)                                         # the « créé » response goes out before shutdown
    httpd.shutdown()
    httpd.server_close()
    return dict(result) or None
