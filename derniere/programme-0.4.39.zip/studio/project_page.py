"""Lecture du savoir d'un projet et édition atomique de sa fiche."""
from __future__ import annotations

import hashlib
from .migrations import compatibility as json
import os
import re
import stat
import tempfile
import tomllib
from .migrations import compatibility as _compat
from datetime import datetime, timezone
from .migrations.compatibility import TechnicalPath as Path
from pathlib import PureWindowsPath

from .registry import APPLICATIONS, _toml_value
from .security import assert_no_secret, redact

MAX_TEXT = 256_000
MAX_ENTRIES = 2000
PATH_FIELDS = {"worktree_folders", "exclude", "rules", "documents"}
LIST_FIELDS = PATH_FIELDS | {"checks", "build"}
EDITABLE = LIST_FIELDS | {"name", "repository", "application", "isolation", "uproject", "agent_mode",
                          "default_effort", "task_timeout_seconds"}


def public(value):
    if isinstance(value, str):
        return redact(value)
    if isinstance(value, list):
        return [public(x) for x in value]
    if isinstance(value, dict):
        return {k: public(v) for k, v in value.items()}
    return value


def target(studio, project_id):
    t = studio.registry.get(f"project:{project_id}")
    if t.file is None or t.extra.get("internal"):
        raise ValueError("Ce projet n'a pas de fiche modifiable.")
    return t


def _linked(path):
    try:
        info = path.lstat()
    except FileNotFoundError:
        return False
    return stat.S_ISLNK(info.st_mode) or bool(getattr(info, "st_file_attributes", 0) & 0x400)


def safe_path(root, relative):
    """Refuse aussi les jonctions Windows, lecteurs relatifs et flux alternatifs."""
    if not isinstance(relative, str) or not relative or len(relative) > 1024:
        raise ValueError("Chemin relatif attendu.")
    value = relative.replace("\\", "/").rstrip("/")
    parts = value.split("/")
    if (PureWindowsPath(value).drive or value.startswith("/") or any(p in ("", ".", "..") for p in parts)
            or any(c in value for c in ':\x00\r\n') or any(p.endswith((" ", ".")) for p in parts)):
        raise ValueError("Chemin hors du projet ou invalide.")
    current = Path(root)
    if _linked(current):
        raise ValueError("Les liens et jonctions sont refusés.")
    for part in parts:
        current = current / part
        if _linked(current):
            raise ValueError("Les liens et jonctions sont refusés.")
    resolved = current.resolve()
    if Path(root).resolve() not in resolved.parents:
        raise ValueError("Chemin hors du projet.")
    return current


def _root(t):
    root = t.path()
    if root is None or not root.is_dir() or _linked(root):
        raise ValueError("Dossier du projet indisponible ou lié.")
    return root


def _walk(root, relative, budget):
    """Parcours borné sans suivre les liens ; jamais de lecture de leur cible."""
    try:
        start = safe_path(root, relative)
    except ValueError:
        return
    pending = [start]
    while pending and budget[0] > 0:
        p = pending.pop()
        budget[0] -= 1
        if _linked(p):
            continue
        if p.is_dir():
            with os.scandir(p) as entries:
                for entry in entries:
                    if len(pending) >= MAX_ENTRIES or budget[0] <= len(pending):
                        budget[1] = True
                        break
                    pending.append(Path(entry.path))
        elif p.is_file():
            yield p
    if pending:
        budget[1] = True


def _read(path):
    with path.open("rb") as stream:
        data = stream.read(MAX_TEXT + 1)
    if len(data) > MAX_TEXT:
        raise ValueError("Fichier trop gros pour l'aperçu (256 ko maximum). Ouvre son dossier.")
    return data.decode("utf-8-sig", errors="replace")


def _entry(root, path):
    info = path.stat()
    relative = path.relative_to(root).as_posix()
    return {"path": relative, "folder": path.parent.relative_to(root).as_posix(), "size": info.st_size,
            "modified_at": datetime.fromtimestamp(info.st_mtime, timezone.utc).isoformat()}


def documents(t):
    root = _root(t)
    files = {}
    budget = [MAX_ENTRIES, False]
    for relative in dict.fromkeys(["CLAUDE.md", "AGENTS.md", *t.rules, *t.documents]):
        for path in _walk(root, relative, budget):
            if path.suffix.lower() == ".md":
                files[path.relative_to(root).as_posix()] = _entry(root, path)
    return {"items": sorted(files.values(), key=lambda e: e["modified_at"], reverse=True),
            "limited": budget[1] or budget[0] <= 0}


def _metadata(text, fallback):
    head = re.match(r"\A---\r?\n(.*?)\r?\n---(?:\r?\n|$)", text, re.S)
    fields = {}
    if head:
        lines = head.group(1).splitlines()
        for index, line in enumerate(lines):
            m = re.match(r"^(name|description):\s*(.*)$", line)
            if m:
                value = m.group(2).strip()
                if value in (">", "|", ">-", "|-"):
                    following = []
                    for more in lines[index + 1:]:
                        if more and not more[0].isspace():
                            break
                        following.append(more.strip())
                    value = " ".join(following)
                fields[m.group(1)] = value.strip("\"'")
    return fields.get("name") or fallback, fields.get("description", "")


def skills(t):
    root = _root(t)
    roots = []
    for relative in t.rules:
        try:
            p = safe_path(root, relative)
        except ValueError:
            continue
        if p.name == "skills" or (p.is_dir() and (p / "SKILL.md").is_file()):
            roots.append(p.relative_to(root).as_posix())
    roots = list(dict.fromkeys(roots))
    grouped = {}
    budget = [MAX_ENTRIES, False]
    for relative in roots:
        for path in _walk(root, relative, budget):
            if path.name != "SKILL.md":
                continue
            key = path.parent.relative_to(root / relative).as_posix()
            item = grouped.setdefault(key, {"name": path.parent.name, "description": "", "copies": [], "missing": []})
            entry = _entry(root, path)
            try:
                text = _read(path)
                name, description = _metadata(text, path.parent.name)
                if not item["copies"]:
                    item.update(name=name, description=description)
                entry["digest"] = hashlib.sha256(text.encode()).hexdigest()
            except ValueError as error:
                entry.update(digest="", error=str(error))
            entry["root"] = relative
            item["copies"].append(entry)
    for key, item in grouped.items():
        present = {entry["root"] for entry in item["copies"]}
        item["missing"] = [r for r in roots if r not in present]
        item["different"] = len({e["digest"] for e in item["copies"]}) > 1
        item["unverified"] = any(not e["digest"] for e in item["copies"])
    return {"roots": roots, "items": sorted(grouped.values(), key=lambda e: e["name"].casefold()),
            "limited": budget[1] or budget[0] <= 0}


def resource(t, relative, kind="document"):
    root = _root(t)
    path = safe_path(root, relative)
    allowed = ({e["path"] for e in documents(t)["items"]} if kind == "document" else
               {e["path"] for s in skills(t)["items"] for e in s["copies"]})
    if path.relative_to(root).as_posix() not in allowed:
        raise ValueError("Document non déclaré ou introuvable.")
    return path


def read_resource(t, relative, kind):
    path = resource(t, relative, kind)
    return {"path": relative, "text": _read(path)}


def memory(studio, t, query):
    records = studio.memory.recall(query[:200], [t.scope], include_general=False, limit=500)
    return {"items": sorted([r.to_dict() for r in records if r.scope == t.scope],
                            key=lambda r: r["created_at"], reverse=True), "limit": 500,
            "pending": studio.memory.pending_count()}


def read_settings(studio, t):
    data = _compat.toml_loads(t.file.read_text(encoding="utf-8-sig"))
    defaults = {"name": t.name, "repository": "", "application": "manual", "isolation": "copy", "uproject": "",
                "agent_mode": studio.profile(f"project:{t.id}"), "default_effort": "",
                "task_timeout_seconds": studio.cfg["limits"]["task_timeout_s"]}
    values = {k: data.get(k, defaults.get(k, [])) for k in sorted(EDITABLE)}
    masked = [k for k, v in values.items() if public(v) != v]
    branch = ""
    if t.has_path and t.path().is_dir() and (t.path() / ".git").exists():
        from .connectors import workspace
        try:
            branch = workspace._git(studio.cfg["tools"].get("git", "git"), t.path(), "symbolic-ref", "--short", "HEAD", timeout=5).strip()
        except workspace.WorktreeError:
            branch = "HEAD détachée ou indisponible"
    return {"values": values, "id": t.id, "path": t.path_value, "base_branch": branch,
            "masked_fields": masked, "autonomous": studio.autonomous(),
            "mcp_access": studio.cfg["tools"].get("mcp_unreal", "all")}


def validate(t, values):
    from .connectors.base import LEVELS
    if not isinstance(values, dict) or not values or set(values) - EDITABLE:
        raise ValueError("Réglages inconnus ou demande vide.")
    assert_no_secret(json.dumps(values, ensure_ascii=False), "fiche projet")
    root = t.path()
    for key, value in values.items():
        if key in LIST_FIELDS:
            if (not isinstance(value, list) or len(value) > 200 or
                    any(not isinstance(v, str) or not v.strip() or len(v) > 4000 or any(c in v for c in '\x00\r\n') for v in value)):
                raise ValueError(f"{key} : liste de textes non vides attendue (200 maximum).")
            if key in PATH_FIELDS:
                if root is None:
                    raise ValueError("Le projet n'a pas de dossier.")
                for v in value:
                    safe_path(root, v)
        elif key == "task_timeout_seconds":
            if type(value) is not int or not 30 <= value <= 86400:
                raise ValueError("Durée attendue : de 30 à 86400 secondes.")
        else:
            if not isinstance(value, str) or len(value) > 4000 or any(c in value for c in '\x00\r\n'):
                raise ValueError(f"{key} : texte invalide.")
            options = {"application": APPLICATIONS, "isolation": ("copy", "worktree"),
                       "agent_mode": ("", "fast", "normal", "performance"), "default_effort": ("", *LEVELS)}
            if key in options and value not in options[key]:
                raise ValueError(f"{key} : valeur non autorisée.")
            if key == "name" and not 1 <= len(value.strip()) <= 120:
                raise ValueError("Le nom doit contenir de 1 à 120 caractères.")
            if key == "uproject" and value:
                if root is None or safe_path(root, value).suffix.lower() != ".uproject":
                    raise ValueError("Fichier .uproject relatif attendu.")
    return values


def _value_end(text, start):
    """Limite lexicale TOML : chaînes multilignes, tableaux et commentaires inclus."""
    index, depth, quote = start, 0, ""
    while index < len(text):
        if quote:
            if text.startswith(quote, index):
                index += len(quote)
                quote = ""
                continue
            if quote[0] == '"' and text[index] == "\\":
                index += 2
                continue
        elif text[index] in "\"'":
            quote = text[index] * (3 if text.startswith(text[index] * 3, index) else 1)
            index += len(quote)
            continue
        elif text[index] == "#":
            if depth == 0:
                return index
            end = text.find("\n", index)
            index = len(text) if end < 0 else end
            continue
        elif text[index] in "[{":
            depth += 1
        elif text[index] in "]}":
            depth -= 1
        elif text[index] in "\r\n" and depth == 0:
            return index
        index += 1
    return index


def _update_text(text, values):
    spans, offset, insertion = {}, 0, len(text)
    while offset < len(text):
        end = text.find("\n", offset)
        end = len(text) if end < 0 else end + 1
        line = text[offset:end]
        if re.match(r"\s*\[", line):
            insertion = offset
            break
        match = re.match(r'''[ \t]*(?:([A-Za-z0-9_-]+)|"([A-Za-z0-9_-]+)"|'([A-Za-z0-9_-]+)')[ \t]*=[ \t]*''', line)
        if match:
            start = offset + match.end()
            finish = _value_end(text, start)
            while finish > start and text[finish - 1] in " \t":
                finish -= 1
            spans[next(v for v in match.groups() if v is not None)] = (start, finish)
            next_line = text.find("\n", _value_end(text, start))
            offset = len(text) if next_line < 0 else next_line + 1
        else:
            offset = end
    edits = [(spans[k][0], spans[k][1], _toml_value(v)) for k, v in values.items() if k in spans]
    missing = "".join(f"{k} = {_toml_value(v)}\n" for k, v in values.items() if k not in spans)
    if missing:
        edits.append((insertion, insertion, ("\n" if insertion and text[insertion - 1] != "\n" else "") + missing + "\n"))
    for start, end, replacement in sorted(edits, reverse=True):
        text = text[:start] + replacement + text[end:]
    return text


def save_settings(studio, t, values):
    values = validate(t, values)
    path = t.file
    # Une fiche doit rester dans son registre, sans lien dans ses composants.
    expected = safe_path(studio.paths.projects, t.id + "/project.toml")
    if path is None or path.absolute() != expected.absolute():
        raise ValueError("Fiche hors du registre des projets.")
    original = path.read_bytes()
    text = original.decode("utf-8-sig")
    previous = _compat.toml_loads(text)
    values = {k: v for k, v in values.items() if k not in previous or previous[k] != v}
    if not values:
        return {"ok": True, "message": "Aucune modification à enregistrer."}
    changed = _update_text(text, values)
    expected = {**previous, **values}
    if _compat.toml_loads(changed) != expected:
        raise ValueError("Écriture non vérifiée : rien n'est modifié.")
    # La copie brute conserve aussi les clés inconnues et précède toute écriture de la fiche.
    backups = studio.paths.data / "previous-config"
    backups.mkdir(parents=True, exist_ok=True)
    backup = backups / f"project-{t.id}-{datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S-%f')}.toml"
    with backup.open("xb") as stream:
        stream.write(original)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(dir=path.parent, prefix=".project-", suffix=".tmp", delete=False) as stream:
            temporary = Path(stream.name)
            stream.write(changed.encode("utf-8"))
            stream.flush()
            os.fsync(stream.fileno())
        if path.read_bytes() != original:
            raise ValueError("La fiche a changé pendant l'enregistrement. Relis-la avant de réessayer.")
        os.replace(temporary, path)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)
    return {"ok": True, "message": "Réglages enregistrés pour les prochaines tâches."}
