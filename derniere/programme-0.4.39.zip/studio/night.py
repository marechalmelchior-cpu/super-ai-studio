"""Night tasks: « Cette nuit » on a Supervisor proposal queues it; it starts on its own during the night
window (setting, 01:00 → 07:00 by default), then a report waits in the general conversation in the morning.

- Nothing starts outside the window; the PC must stay on and the studio open (otherwise the queue waits for the next
  night, nothing is lost).
- Launched tasks follow the normal path (review, validation): the night never validates anything for you.
- Queue: data/nuit.json (atomic write).
"""
from __future__ import annotations

from .migrations import compatibility as json
import os
import threading
import uuid
from datetime import datetime, timedelta
from .migrations.compatibility import TechnicalPath as Path

_lock = threading.Lock()
FINISHED_STATES = {"approved": "faite", "applied": "appliquée", "awaiting_approval": "à valider", "awaiting_approval_with_defects": "à valider (défauts)",
               "blocked": "bloquée", "failed": "en échec", "cancelled": "annulée", "interrupted": "interrupted"}


def _file(data: Path) -> Path:
    return Path(data) / "night.json"


def read_file(data: Path) -> dict:
    try:
        d = json.loads(_file(data).read_text(encoding="utf-8"))
        if isinstance(d, dict):
            return {"file": list(d.get("file", [])), "launched": list(d.get("launched", [])), "reports": list(d.get("reports", []))}
    except (OSError, ValueError):
        pass
    return {"file": [], "launched": [], "reports": []}


def _write(data: Path, d: dict) -> None:
    f = _file(data)
    f.parent.mkdir(parents=True, exist_ok=True)
    t = f.with_suffix(".tmp")
    t.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
    os.replace(t, f)


def time_window(cfg: dict) -> tuple[str, str]:
    n = cfg.get("night") or {}
    return str(n.get("begin") or "01:00"), str(n.get("end") or "07:00")


def _minutes(h: str) -> int:
    hh, _, mm = h.partition(":")
    return int(hh) * 60 + int(mm or 0)


def during_night(cfg: dict, current_time: datetime) -> bool:
    d, f = (_minutes(x) for x in time_window(cfg))
    m = current_time.hour * 60 + current_time.minute
    return d <= m < f if d < f else (m >= d or m < f)


def night_of(cfg: dict, current_time: datetime) -> str:
    """Date of the current or last night: the day of the evening it starts."""
    d = _minutes(time_window(cfg)[0])
    m = current_time.hour * 60 + current_time.minute
    if d >= 12 * 60 and m >= d:                       # window started this evening (e.g. 23:00)
        return current_time.date().isoformat()
    return (current_time.date() - timedelta(days=1)).isoformat()


def schedule(studio, rid: int, target: str = "", request: str = "", model: str = "", mode: str = "", effort: str = "") -> dict:
    msg = next((m for m in studio.store.messages(500) if m["id"] == rid), None)
    if msg is None or not msg["proposal"] or msg["proposal"].get("state") != "proposed":
        raise ValueError("Aucune proposition à mettre en file pour ce message.")
    p = dict(msg["proposal"])
    request = (request or p.get("request", "")).strip()
    if not request:
        raise ValueError("Demande vide.")
    e = {"id": uuid.uuid4().hex[:12], "rid": rid, "target": target or p.get("target", ""), "request": request,
         "title": p.get("title", ""), "model": model, "mode": mode, "effort": effort,
         "added": datetime.now().isoformat(timespec="seconds")}
    with _lock:
        d = read_file(studio.paths.data)
        d["file"].append(e)
        _write(studio.paths.data, d)
    p.update(state="night", night=e["id"], request=request, target=e["target"], model_night=model, mode_night=mode, effort_night=effort)
    studio.store.update_message(rid, proposal=p)
    return {"ok": True, "id": e["id"], "begin": time_window(studio.cfg)[0]}


def removed(studio, ident: str) -> dict:
    with _lock:
        d = read_file(studio.paths.data)
        e = next((x for x in d["file"] if x["id"] == ident), None)
        if not e:
            raise ValueError("Cette tâche n'est plus en file (déjà lancée ou retirée).")
        d["file"] = [x for x in d["file"] if x["id"] != ident]
        _write(studio.paths.data, d)
    msg = next((m for m in studio.store.messages(500) if m["id"] == e["rid"]), None)
    if msg and msg["proposal"].get("state") == "night":
        studio.store.update_message(e["rid"], proposal={**msg["proposal"], "state": "proposed"})
    return {"ok": True}


def tick(studio, sup, launch, current_time: datetime | None = None) -> dict:
    """Called every minute: launches the queue during the night; after the night, writes the report only once."""
    current_time = current_time or datetime.now()
    done = {"launched": [], "report": False}
    night = during_night(studio.cfg, current_time)
    with _lock:
        d = read_file(studio.paths.data)
        to_launch = d["file"] if night else []
        d["file"] = [] if night else d["file"]
        if to_launch:
            _write(studio.paths.data, d)
    for e in to_launch:
        try:
            tid = sup.launch(e["rid"], e["target"], e["request"], e.get("model", ""), e.get("mode", ""), e.get("effort", ""),
                             since_night=True)
            launch(tid)
            e.update(tid=tid, launched=current_time.isoformat(timespec="seconds"), night=night_of(studio.cfg, current_time))
        except Exception as ex:                          # noqa: BLE001 — noted in the morning report
            e.update(error=str(ex)[:300], launched=current_time.isoformat(timespec="seconds"), night=night_of(studio.cfg, current_time))
        done["launched"].append(e)
    with _lock:
        d = read_file(studio.paths.data)
        if done["launched"]:
            d["launched"] = (d["launched"] + done["launched"])[-200:]
        to_report = sorted({x.get("night") for x in d["launched"] if x.get("night")} - set(d["reports"]))
        to_report = [n for n in to_report if not (night and n == night_of(studio.cfg, current_time))]
        for n in to_report:
            _night_report(studio, [x for x in d["launched"] if x.get("night") == n])
            d["reports"] = (d["reports"] + [n])[-60:]
            done["report"] = True
        if done["launched"] or to_report:
            _write(studio.paths.data, d)
    return done


def _night_report(studio, launched: list[dict]) -> None:
    rows, links = [], []
    for e in launched:
        title = e.get("title") or e["request"][:70]
        if e.get("error"):
            rows.append(f"- **{title}** : pas lancée ({e['error']})")
            continue
        try:
            t = studio.store.get(e["tid"])
            state = FINISHED_STATES.get(t["status"], "encore en cours")
        except KeyError:
            state = "missing"
        rows.append(f"- **{title}** : {state}")
        links.append({"tid": e["tid"], "title": title, "target": e.get("target", ""), "state": state})
    to_approve = sum(1 for x in links if x["state"].startswith("à valider"))
    text = (f"### Rapport de la nuit\n{len(launched)} tâche(s) lancée(s) pendant la nuit"
             + (f", **{to_approve} à valider**" if to_approve else "") + ".\n\n" + "\n".join(rows))
    studio.store.message("supervisor", text, proposal={"night_report": links})
