"""Entrée en ligne de commande ; textes et contenus en français.

Exemples :
  python -m studio state
  python -m studio task "Corriger average()" --target studio-demo --launch
  python -m studio track <TID>
  python -m studio approve <TID> --fingerprint <empreinte_affichée>
  python -m studio memory-search "combat" --scope project:rpg3d
"""
from __future__ import annotations

import argparse
from .migrations import compatibility as json
import sys
from .migrations.compatibility import TechnicalPath as Path


def _studio(args, executors=None):
    from .orchestrator.runner import Studio
    return Studio(executors=executors)


TOOL_LABELS = {"claude-code": "Claude Code", "codex": "Codex", "simulation": "SIMULATION"}


def _print_organization(o: dict):
    print("ÉQUIPE — à qui tu parles")
    for r in o["team"]:
        tool = TOOL_LABELS.get(r["tool"], r["tool"]) + (" (lecture seule)" if r["read_only"] else "")
        if not r["active"]:
            tool = "règles automatiques (auditeur modèle désactivé)"
        work = [x["id"] for x in r["tasks"] if x["status"] in ("created", "running", "awaiting_slot")]
        waiting = [x["id"] for x in r["tasks"] if x["id"] not in work]
        state = (f"au travail : {', '.join(work)}  " if work else "") + (f"attend ton accord : {', '.join(waiting)}" if waiting else "")
        state = state or "libre"
        print(f"  {r['name']:<26} {tool:<24} {state}")
    print("\nPROJETS ET SUJETS")
    for c in o["targets"]:
        print(f"  {c['name']:<34} {'project' if c['kind'] == 'project' else 'topic':<7} {c.get('folder') or '(sans dossier)'}")
    print("\nTÂCHES EN COURS")
    for x in o["tasks_active"] or []:
        print(f"  {x['id']}  {x['status']:<24} {x['target']:<14} {x['summary'][:60]}")
    if not o["tasks_active"]:
        print("  aucune")
    li = o["limits"]
    print(f"\nRÈGLES : {li['concurrent_tasks']} tâche à la fois · {li['max_corrections']} corrections auto max · "
          f"mémoire {o['memory']} · rien n'est appliqué sans ton approbation")


def _print(obj, as_json: bool):
    if as_json:
        print(json.dumps(obj, ensure_ascii=False, indent=2, default=str))
    elif isinstance(obj, dict) and "task" in obj:
        t = obj["task"]
        print(f"Tâche {t['id']} — {t['status']}  ({t['target']})")
        print(f"  {t['summary']}")
        if obj.get("simulation"):
            print("  ⚠ SIMULATION : aucun modèle appelé")
        if obj.get("memory"):
            print(f"  Mémoire : {obj['memory']}")
        eq = obj.get("team") or {}
        if eq.get("producer"):
            print(f"  Équipe : {eq['producer']['role']} via {TOOL_LABELS.get(eq['producer']['tool'], eq['producer']['tool'])}"
                  f" · auditeur : {TOOL_LABELS.get(eq['reviewer']['tool'], eq['reviewer']['tool'])} (lecture seule)")
        for e in obj["stages"]:
            print(f"  [{e['status']:>8}] {e['name']} (tentative {e['attempt']}) {e['detail'][:90]}")
        if obj.get("awaiting_decision"):
            print(f"\n  Résultat : {obj['folder']}/RESULTAT.md")
            print(f"  Empreinte à approuver : {obj['fingerprint']}")
    else:
        print(json.dumps(obj, ensure_ascii=False, indent=2, default=str))



def _next_chain(st, tid: str) -> None:
    """Like the interface: a chain step validated (or cancelled) from the command line advances its chain."""
    from .chains import advance
    new_name = advance(st, tid)
    if new_name:
        print(f"Chaîne : étape suivante lancée ({new_name}).")
        st.run(new_name)

def main(argv: list[str] | None = None) -> int:
    for stream in (sys.stdout, sys.stderr):           # Windows console in cp1252: no crash on « ⚠ », « é »…
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, ValueError):
            pass
    p = argparse.ArgumentParser(prog="studio", description="Studio IA de l'utilisateur")
    p.add_argument("--json", action="store_true", help="sortie JSON")
    sub = p.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("state"); s.add_argument("--fast", action="store_true")
    sub.add_parser("targets")
    s = sub.add_parser("project-add"); s.add_argument("id"); s.add_argument("name"); s.add_argument("--path_value", required=True)
    s.add_argument("--type", default="doc"); s.add_argument("--repository", default=""); s.add_argument("--isolation", default="copy")
    s = sub.add_parser("topic-add"); s.add_argument("id"); s.add_argument("name"); s.add_argument("--description", default="")
    s = sub.add_parser("task"); s.add_argument("request"); s.add_argument("--target", required=True)
    s.add_argument("--role", default=""); s.add_argument("--executor", default=""); s.add_argument("--launch", action="store_true")
    s.add_argument("--model", default="", help="opus | sonnet | haiku (Claude Code) ou nom de modèle Codex ; vide = réglage du rôle")
    s.add_argument("--mode", default="", choices=["", "fast", "max"], help="rapide (sans relecture par un 2e modèle) | max (raisonnement maximal + compilation)")
    for name in ("launch", "resume", "track", "cancel", "copy", "chatgpt-export"):   # copy = copy-paste to an AI
        sub.add_parser(name).add_argument("tid")
    s = sub.add_parser("approve"); s.add_argument("tid"); s.add_argument("--fingerprint", required=True)
    s.add_argument("--comment", default="")
    s = sub.add_parser("correct"); s.add_argument("tid"); s.add_argument("comment")
    for name in ("paste", "chatgpt-import"):          # paste = the AI's reply, saved as a proposal
        s = sub.add_parser(name); s.add_argument("tid"); s.add_argument("file")
    sub.add_parser("tasks")
    sub.add_parser("organization", help="équipe, projets et sujets, tâches en cours")
    sub.add_parser("skills-synchronize", help="skills du studio vers Claude et Codex, skills des projets vers .agents/skills (Codex)")
    s = sub.add_parser("set-blender", help="trouve blender.exe (Steam compris) et l'enregistre dans studio.config.toml")
    s.add_argument("path_value", nargs="?", default="")
    s = sub.add_parser('processes'); s.add_argument("tid", nargs="?")
    s = sub.add_parser("memory-search"); s.add_argument("query", nargs="?", default="")
    s.add_argument("--scope", action="append", default=[]); s.add_argument("--without-general", action="store_true")
    s.add_argument("--limit", type=int, default=20)
    s = sub.add_parser("memory-add"); s.add_argument("text"); s.add_argument("--scope", required=True)
    s.add_argument("--tool", required=True, help="claude-code | codex | api | mel | copier-coller")
    s.add_argument("--topic", default=""); s.add_argument("--key", default=""); s.add_argument("--task", default="")
    s = sub.add_parser("memory-correct"); s.add_argument("--scope", required=True); s.add_argument("--key", required=True)
    s.add_argument("text"); s.add_argument("--tool", default="mel")
    s = sub.add_parser("memory-conflicts"); s.add_argument("--scope", required=True)
    sub.add_parser("memory-flush-pending")
    s = sub.add_parser("backup"); s.add_argument("--with-runs", action="store_true")
    s = sub.add_parser("verify-backup"); s.add_argument("file")
    s = sub.add_parser("test-restore"); s.add_argument("file"); s.add_argument("folder")
    s = sub.add_parser("config-prepare", help="prépare la copie révisable de la config Codex")
    s.add_argument("--secondary-cli", "--codex", dest="secondary_cli", default=str(Path.home() / ".codex" / "config.toml"))
    s.add_argument("--studio-mcp", action="store_true", help="ajoute aussi le serveur MCP studio-memoire")
    s = sub.add_parser("config-apply"); s.add_argument("--secondary-cli", "--codex", dest="secondary_cli", default=str(Path.home() / ".codex" / "config.toml"))
    s = sub.add_parser("config-restore"); s.add_argument("--secondary-cli", "--codex", dest="secondary_cli", default=str(Path.home() / ".codex" / "config.toml"))
    s.add_argument("--since", default="")
    sub.add_parser("mcp-diagnostic", help="teste le client MCP AgentMemory des configurations")
    sub.add_parser("demo")
    sub.add_parser("interface")
    sub.add_parser("launcher", help="ouvre l'interface (raccourci du bureau) : session protégée, arrêt automatique")
    arguments = list(argv if argv is not None else sys.argv[1:])
    aliases = {"etat":"state", "cibles":"targets", "projet-ajouter":"project-add", "sujet-ajouter":"topic-add", "tache":"task", "taches":"tasks", "lancer":"launch", "reprendre":"resume", "summary":"resume", "suivre":"track", "annuler":"cancel", "approuver":"approve", "corriger":"correct", "copier":"copy", "coller":"paste", "regler-blender":"set-blender", "memory-send-attente":"memory-flush-pending", "memoire-envoyer-attente":"memory-flush-pending", "config-preparer":"config-prepare", "diagnostic-mcp":"mcp-diagnostic", "lanceur":"launcher"}
    def technical_name(value):
        if value in json.CANONICAL_KEYS:
            return value
        return json.KEYS.get(value, "-".join(json.KEYS.get(part, part) for part in value.split("-")))
    command_seen = False
    for index, argument in enumerate(arguments):
        if argument == "--":
            break
        if argument.startswith("--"):
            flag, separator, value = argument.partition("=")
            converted = {"--avec-runs": "--with-runs", "--with_value-runs": "--with-runs"}.get(flag, "--" + technical_name(flag[2:]))
            arguments[index] = converted + (separator + value if separator else "")
        elif not argument.startswith("-") and not command_seen:
            arguments[index] = aliases.get(argument, technical_name(argument))
            command_seen = True
    a = p.parse_args(arguments)

    from .memory import MemoryUnavailable, Provenance, Scope
    try:
        if a.cmd in ("memory-search", "memory-add", "memory-correct", "memory-conflicts", "memory-flush-pending"):
            from .config import load_config
            from .memory import build_connector
            from .paths import default_paths
            paths = default_paths().ensure()
            mem = build_connector(load_config(paths.config_file), paths.data)
            if a.cmd == "memory-search":
                if not a.scope and a.without_general:
                    raise SystemExit("Indiquer au moins une portée.")
                recs = mem.recall(a.query, [Scope.parse(x) for x in a.scope], not a.without_general, a.limit)
                _print([r.to_dict() for r in recs], True)
            elif a.cmd == "memory-add":
                r = mem.remember(Scope.parse(a.scope), a.text, Provenance(tool=a.tool, task=a.task),
                                 key=a.key or None, subject=a.topic)
                _print({"status": r.status, "shared": r.shared, "key": r.record.key, "detail": r.detail}, True)
                return 0 if r.shared else 3
            elif a.cmd == "memory-correct":
                r = mem.correct(Scope.parse(a.scope), a.key, a.text, Provenance(tool=a.tool))
                _print({"status": r.status, "key": r.record.key}, True)
            elif a.cmd == "memory-conflicts":
                _print({k: [x.to_dict() for x in v] for k, v in mem.conflicts(Scope.parse(a.scope)).items()}, True)
            else:
                _print(mem.flush_outbox(), True)
            return 0
        if a.cmd in ("backup", "verify-backup", "test-restore"):
            from .backup import create_backup, restore_to_test, verify_backup
            from .paths import default_paths
            if a.cmd == "backup":
                print(create_backup(default_paths().ensure(), with_runs=a.with_runs))
            elif a.cmd == "verify-backup":
                _print(verify_backup(Path(a.file)), True)
            else:
                _print(restore_to_test(Path(a.file), Path(a.folder)), True)
            return 0
        if a.cmd == "config-prepare":
            from .configs import diff, patch_secondary_cli_config, sha256_text
            from .paths import default_paths
            src = Path(a.secondary_cli)
            old = src.read_text(encoding="utf-8")
            new = patch_secondary_cli_config(old)
            if a.studio_mcp:
                from .configs import add_studio_mcp_secondary_cli
                new = add_studio_mcp_secondary_cli(new, str(default_paths().studio))
            out = default_paths().code / "configs-preparees"
            out.mkdir(parents=True, exist_ok=True)
            (out / "codex.config.toml.propose").write_text(new, encoding="utf-8", newline="")
            (out / "codex.config.toml.diff").write_text(diff(old, new, "config.toml"), encoding="utf-8")
            (out / "codex.config.toml.base.sha256").write_text(sha256_text(old), encoding="utf-8")
            print(out / "codex.config.toml.diff")
            return 0
        if a.cmd in ("config-apply", "config-restore"):
            from .configs import apply_secondary_cli, restore_secondary_cli
            from .paths import default_paths
            dp = default_paths()
            if a.cmd == "config-apply":
                _print(apply_secondary_cli(Path(a.secondary_cli), dp.code / "configs-preparees", dp.backups / "configs"), True)
            else:
                _print(restore_secondary_cli(Path(a.secondary_cli), dp.backups / "configs", Path(a.since) if a.since else None), True)
            return 0
        if a.cmd == "mcp-diagnostic":
            from .diag_mcp import diagnose
            r1 = diagnose()
            _print({"first_lancement": r1}, True)
            if r1.get("initialize_s", 0) > 20:
                _print({"second_launch_cache_chaud": diagnose()}, True)
            return 0 if r1.get("ok") else 4
        if a.cmd == "set-blender":
            from .config import set_tool, find_blender
            from .paths import default_paths
            candidates = [a.path_value] if a.path_value else find_blender()
            if not candidates or not Path(candidates[0]).is_file():
                print("Blender missing. Indique sound path_value : studio.cmd regler-blender \"C:\\…\\blender.exe\"")
                return 1
            set_tool(default_paths().config_file, "blender", candidates[0])
            print(f"Blender enregistré : {candidates[0]}" + (f"\nAutres trouvés : {', '.join(candidates[1:])}" if len(candidates) > 1 else ""))
            return 0
        if a.cmd == "launcher":
            from .launcher import main as launch_command
            return launch_command()
        if a.cmd == "interface":
            from .ui.server import serve
            serve()
            return 0
        if a.cmd == "demo":
            from .demo import demo_executors
            ex = demo_executors()
            st = _studio(a, executors={"simulation": ex["code"]})
            t1 = st.create("studio-demo", "Corriger average() pour une liste vide (démonstration)", executor="simulation")
            _print(st.run(t1), a.json)
            st.executors["simulation"] = ex["topic"]
            t2 = st.create("topic:veille-ia", "Rédiger une note de synthèse sur la persistance LangGraph (démonstration)",
                           executor="simulation")
            _print(st.run(t2), a.json)
            print("\nDÉMONSTRATION SIMULÉE : approuver ou annuler avec les commandes indiquées.")
            return 0

        st = _studio(a)
        if a.cmd == "skills-synchronize":
            from .supervisor import sync_all
            print("\n".join(sync_all(st)))
        elif a.cmd == "organization":
            o = st.organization()
            print(json.dumps(o, ensure_ascii=False, indent=2, default=str)) if a.json else _print_organization(o)
        elif a.cmd == "state":
            from .health import check_all
            _print(check_all(st, probe_tools=not a.fast), True)
        elif a.cmd == "targets":
            _print([t.to_public() for t in st.registry.all()], True)
        elif a.cmd == "project-add":
            t = st.registry.add("project", a.id, a.name, path_value=a.path_value, type=a.type, repository=a.repository, isolation=a.isolation)
            _print(t.to_public(), True)
        elif a.cmd == "topic-add":
            _print(st.registry.add("topic", a.id, a.name, description=a.description).to_public(), True)
        elif a.cmd == "task":
            opts = {k: v for k, v in (("role", a.role), ("executor", a.executor), ("model", a.model), ("mode", a.mode)) if v}
            tid = st.create(a.target, a.request, **opts)
            print(f"Tâche créée : {tid}")
            if a.launch:
                _print(st.run(tid), a.json)
        elif a.cmd == "launch":
            _print(st.run(a.tid), a.json)
        elif a.cmd == "resume":
            _print(st.resume(a.tid), a.json)
            _next_chain(st, a.tid)
        elif a.cmd == "track":
            _print(st.status(a.tid), a.json)
        elif a.cmd == "approve":
            _print(st.decide(a.tid, "approve", a.fingerprint, a.comment), a.json)
            _next_chain(st, a.tid)
        elif a.cmd == "correct":
            _print(st.decide(a.tid, "correct", "", a.comment), a.json)
        elif a.cmd == "cancel":
            _print(st.cancel(a.tid), a.json)
            _next_chain(st, a.tid)
        elif a.cmd == "tasks":
            for t in st.store.list():
                print(f"{t['id']}  {t['status']:<26} {t['target']:<20} {t['summary'][:60]}")
        elif a.cmd == 'processes':
            from .orchestrator.processes import processes
            _print(processes(st.store, a.tid), True)
        elif a.cmd in ("copy", "chatgpt-export"):
            print(st.export_copy_paste(a.tid))
        elif a.cmd in ("paste", "chatgpt-import"):
            from .connectors.copy_paste import import_report
            _print(import_report(Path(a.file), st.run_dir(a.tid) / "copy-paste", a.tid), True)
        return 0
    except MemoryUnavailable as e:
        print(f"MÉMOIRE EN PANNE : {e}", file=sys.stderr)
        return 2
    except (KeyError, ValueError, FileExistsError) as e:
        print(f"Erreur : {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
