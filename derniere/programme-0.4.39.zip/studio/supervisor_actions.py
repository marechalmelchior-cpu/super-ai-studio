"""Actions proposées : données validées, exécution uniquement après le clic de Mel."""
from __future__ import annotations

import copy
from .migrations import compatibility as json
import re
import threading

from . import chains, teams
from .security import assert_no_secret, redact

try:
    from . import project_page
except ImportError:
    project_page = None

PARAMETERS = {
    "approve_task": {"tid"}, "request_correction": {"tid", "comment"},
    'resume_task': {"tid"}, "stop_task": {"tid"}, "merge_task": {"tid"},
    "continue_chain": {"chain_id"}, 'resume_chain': {"chain_id"},
    "set_role_setting": {"project", "role", "field", "value"},
    "express_task": {"target", "request"},
}
if project_page is not None and callable(getattr(project_page, "save_settings", None)):
    PARAMETERS["set_project_setting"] = {"project", "key", "value"}

WAITING = ("awaiting_approval", "awaiting_approval_with_defects")


def validate_scope(studio, name, params, scope):
    """La conversation d'un projet ne peut proposer une action sur un autre."""
    if not scope:
        return
    expected = _target(studio, scope)
    if "tid" in params:
        actual = studio.store.get(params["tid"])["target"]
    elif "chain_id" in params:
        actual = studio.store.chain(params["chain_id"])["target"]
    else:
        actual = params.get("project") or params.get("target")
    if actual == "common":
        raise ValueError("Réglage commun interdit depuis la page d'un projet.")
    target = _target(studio, actual)
    if (target.kind, target.id) != (expected.kind, expected.id):
        raise ValueError("L'action vise un autre projet que la conversation.")


def _text(value, name, limit=4000, empty=False):
    if not isinstance(value, str) or len(value) > limit or "\x00" in value or (not empty and not value.strip()):
        raise ValueError(f"Paramètre {name} invalide.")
    return value


def _target(studio, value, project_only=False):
    _text(value, "project", 100)
    if not re.fullmatch(r"(?:(?:project|topic):)?[a-z0-9][a-z0-9._-]{0,63}", value):
        raise ValueError("Identifiant de cible invalide.")
    target = studio.registry.get(value)
    if project_only and target.kind != "project":
        raise ValueError("Un projet est requis.")
    return target


def validate(studio, name, params):
    """Validation sans écriture, refaite au clic et au début de l'exécution."""
    if not isinstance(name, str) or name not in PARAMETERS:
        raise ValueError(f"Action non autorisée : {name}")
    if not isinstance(params, dict) or set(params) != PARAMETERS[name]:
        raise ValueError(f"Paramètres attendus pour {name} : {', '.join(sorted(PARAMETERS[name]))}")
    assert_no_secret(json.dumps(params, ensure_ascii=False), "action du Superviseur")
    if "tid" in params:
        tid = _text(params["tid"], "tid", 40)
        if not re.fullmatch(r"T[0-9]{8}-[0-9]{6}-[0-9a-f]{6}", tid):
            raise ValueError("Identifiant de tâche invalide.")
        task = studio.store.get(tid)
        allowed = WAITING if name in ("approve_task", "request_correction") else {
            'resume_task': ("blocked", "interrupted", "failed"),
            "stop_task": ("created", "running", "awaiting_slot"),
            "merge_task": ("approved", "applied"),
        }[name]
        if task["status"] not in allowed:
            raise ValueError(f"Cette tâche ne permet pas cette action (état : {task['status']}).")
        if name in ("approve_task", "request_correction"):
            state = studio.status(tid)
            if not state["awaiting_decision"] or not state["fingerprint"]:
                raise ValueError("La tâche n'attend pas de décision sur un résultat.")
        if name == "request_correction":
            _text(params["comment"], "comment", 8000)
        if name == "merge_task":
            state = studio.status(tid)
            if not state.get("worktree") or state.get("merge"):
                raise ValueError("Aucune branche validée à fusionner pour cette tâche.")
    elif "chain_id" in params:
        cid = _text(params["chain_id"], "chain_id", 80)
        if not re.fullmatch(r"[A-Za-z0-9-]+", cid):
            raise ValueError("Identifiant de chaîne invalide.")
        chain = chains.summary(studio, cid)
        if not chain:
            raise ValueError(f"Chaîne inconnue : {cid}")
        if name == "continue_chain" and not chain["can_continue"]:
            raise ValueError("Cette chaîne ne peut pas continuer : valide d'abord son étape courante.")
        if name == 'resume_chain' and chain["status"] != "paused":
            raise ValueError("Cette chaîne n'est pas en pause.")
    elif name == "set_project_setting":
        target = _target(studio, params["project"], True)
        key = _text(params["key"], "key", 80)
        if key not in project_page.EDITABLE or key in {"build", "checks"}:
            raise ValueError("Réglage non autorisé pour une action du Superviseur.")
        project_page.validate(target, {key: params["value"]})
    elif name == "set_role_setting":
        project = params["project"]
        if project != "common":
            target = _target(studio, project)
        role_id = _text(params["role"], "role", 100)
        field = _text(params["field"], "field", 40)
        role = studio.roles.get(role_id)
        if role is None or field not in ("active", "model", "effort", "instructions"):
            raise ValueError("Métier ou champ inconnu.")
        if project != "common" and role.projects_list and f"{target.kind}:{target.id}" not in role.projects_list:
            raise ValueError("Ce métier n'est pas disponible pour ce projet.")
        value = params["value"]
        if field == "active":
            if type(value) is not bool or (role_id == "reviewer" and value is False):
                raise ValueError("Activation invalide : le relecteur reste actif.")
        else:
            _text(value, "value", 4000, empty=True)
            if field == "model" and not re.fullmatch(r"[A-Za-z0-9._:/@-]{0,100}", value):
                raise ValueError("Modèle invalide.")
            if field == "effort" and value not in teams.EFFORTS:
                raise ValueError("Effort invalide.")
    elif name == "express_task":
        _target(studio, params["target"])
        _text(params["request"], "request", 8000)
    return params


def approve_task(studio, params, context, item):
    tid = params["tid"]
    state = studio.graph.get_state(studio._cfg(tid)).values
    expected = item.get("result_hash")
    if not expected or state.get("result_hash") != expected or studio._current_hash(state) != expected:
        raise ValueError("Le résultat a changé depuis la proposition : demande une nouvelle proposition.")
    result = context["decide"](tid, "approve", expected, "Action du Superviseur validée par Mel")
    if studio.store.get(tid)["status"] not in ("approved", "applied"):
        raise RuntimeError("Approbation non terminée : consulte la tâche.")
    return result


def request_correction(studio, params, context, item):
    return context["decide"](params["tid"], "correct", "", params["comment"])


def resume_task(studio, params, context, item):
    return context["resume"](params["tid"])


def stop_task(studio, params, context, item):
    return studio.stop(params["tid"])


def merge_task(studio, params, context, item):
    return context["merge"](params["tid"])


def continue_chain(studio, params, context, item):
    tid = chains.proceed(studio, params["chain_id"])
    if tid:
        context["launch"](tid)
    return {"tid": tid or ""}


def resume_chain(studio, params, context, item):
    tid = chains.resume_run(studio, params["chain_id"])
    context["launch"](tid)
    return {"tid": tid}


def set_project_setting(studio, params, context, item):
    target = _target(studio, params["project"], True)
    return context["project_setting"](target, {params["key"]: params["value"]})


def set_role_setting(studio, params, context, item):
    field = {"active": "active", "model": "model", "effort": "effort", "instructions": "instructions"}[params["field"]]
    if params["project"] == "common":
        if field == "model":
            return studio.set_model(params["role"], params["value"])
        if field == "effort":
            return studio.set_effort(params["role"], params["value"])
        return teams.configure_common_role(studio, params["role"], {field: params["value"]})
    target = _target(studio, params["project"])
    return teams.configure_role(studio, f"{target.kind}:{target.id}", params["role"], {field: params["value"]})


def express_task(studio, params, context, item):
    tid = studio.create(params["target"], params["request"], mode="fast", effort="low", manual_approval=True)
    context["launch"](tid)
    return {"tid": tid}


HANDLERS = {name: globals()[name] for name in PARAMETERS}


class ActionProposals:
    def __init__(self, studio):
        self.studio = studio
        self.lock = threading.RLock()

    def propose(self, values, scope=""):
        if not isinstance(values, list) or not 1 <= len(values) <= 3:
            raise ValueError("Une proposition doit contenir de une à trois actions.")
        items = []
        for value in values:
            if not isinstance(value, dict) or set(value) != {"action", "params", "label", "why"}:
                raise ValueError("Chaque action requiert action, params, label et why.")
            item = copy.deepcopy(value)
            validate(self.studio, item["action"], item["params"])
            validate_scope(self.studio, item["action"], item["params"], scope)
            _text(item["label"], "label", 160)
            _text(item["why"], "why", 500)
            item["state"] = "pending"
            if item["action"] == "approve_task":
                item["result_hash"] = self.studio.status(item["params"]["tid"])["fingerprint"]
            items.append(item)
        return {"state": "actions", "actions": items, **({"project": scope} if scope else {})}

    def _read(self, rid):
        with self.studio.store.db() as db:
            row = db.execute("SELECT author, proposal FROM conversation WHERE id=?", (rid,)).fetchone()
        if not row or row["author"] != "supervisor":
            raise ValueError("Proposition introuvable.")
        prop = json.loads(row["proposal"] or "{}")
        if prop.get("state") != "actions" or prop.get("removed"):
            raise ValueError("Cette proposition n'est plus disponible.")
        return prop

    def claim(self, rid, index, comment=None, *, remote=False):
        with self.lock:
            prop = self._read(rid)
            if type(index) is not int or not 0 <= index < len(prop["actions"]):
                raise ValueError("Indice d'action invalide.")
            item = prop["actions"][index]
            if remote and item["action"] in {"set_project_setting", "set_role_setting"}:
                raise ValueError("À faire depuis le PC.")
            if item["state"] != "pending" or any(x["state"] in ("running", "executing") for x in prop["actions"]):
                raise ValueError("Action déjà traitée ou une action est en cours.")
            if comment is not None:
                if item["action"] != "request_correction":
                    raise ValueError("Seul le commentaire de correction est modifiable.")
                item["params"]["comment"] = comment
            try:
                validate(self.studio, item["action"], item["params"])
                validate_scope(self.studio, item["action"], item["params"], prop.get("project", ""))
                if item["action"] == "approve_task":
                    state = self.studio.graph.get_state(self.studio._cfg(item["params"]["tid"])).values
                    if state.get("result_hash") != item["result_hash"] or self.studio._current_hash(state) != item["result_hash"]:
                        raise ValueError("Le résultat a changé depuis la proposition : demande une nouvelle proposition.")
            except (KeyError, ValueError, RuntimeError) as error:
                item.update(state="error", error=redact(str(error)))
                self.studio.store.update_message(rid, proposal=prop)
                raise
            item["state"] = "running"
            self.studio.store.update_message(rid, proposal=prop)
            return copy.deepcopy(item)

    def finish(self, rid, index, context):
        with self.lock:
            prop = self._read(rid)
            item = copy.deepcopy(prop["actions"][index])
            if item["state"] != "running":
                raise ValueError("Cette action n'a pas été validée par Mel.")
            # La réservation est consommée avant l'appel : un second appel ne rejoue aucun effet.
            prop["actions"][index]["state"] = "executing"
            self.studio.store.update_message(rid, proposal=prop)
        try:
            validate(self.studio, item["action"], item["params"])
            validate_scope(self.studio, item["action"], item["params"], prop.get("project", ""))
            result = HANDLERS[item["action"]](self.studio, item["params"], context, item)
            tid = item["params"].get("tid") or (result.get("tid") if isinstance(result, dict) else "")
            if not tid and "chain_id" in item["params"]:
                chain = self.studio.store.chain(item["params"]["chain_id"])
                tid = chain["stages"][chain["current"]].get("task", "")
            message = "Action du Superviseur validée par Mel : " + item["action"] + " — " + item["label"]
            self.studio.store.event(tid or "studio", redact(message))
            item.update(state="done", result={"tid": tid or ""})
        except Exception as error:  # Une erreur reste visible dans la proposition, sans relance automatique.
            message = "Action du Superviseur validée par Mel : " + item["action"] + " — erreur : " + str(error)
            self.studio.store.event(item["params"].get("tid") or "studio", redact(message))
            item.update(state="error", error=redact(str(error)))
        with self.lock:
            prop = self._read(rid)
            prop["actions"][index] = item
            self.studio.store.update_message(rid, proposal=prop)
        return item

    def ignore(self, rid):
        with self.lock:
            prop = self._read(rid)
            if any(x["state"] in ("running", "executing") for x in prop["actions"]):
                raise ValueError("Attends la fin de l'action en cours.")
            for item in prop["actions"]:
                if item["state"] == "pending":
                    item["state"] = "ignored"
            self.studio.store.update_message(rid, proposal=prop)
