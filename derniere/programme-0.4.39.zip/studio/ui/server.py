"""Local studio interface (http://127.0.0.1:8765), standard library only.

Security:
- listens on 127.0.0.1 only (otherwise the configuration is rejected at load time);
- Host header checked (against DNS rebinding);
- POST requests require the ``X-Studio: 1`` header (a third-party site cannot add it);
- with the launcher (desktop shortcut): random single-use session key, exchanged for an
  HttpOnly/SameSite=Strict cookie; without that cookie nothing is served. The key changes at every start.
Starts only on explicit request (shortcut or ``python -m studio interface``); no permanent service:
with the launcher, the server stops by itself when no window is open and no task is running.
"""
from __future__ import annotations

import hmac
from ..migrations import compatibility as json
import re
import threading
import time
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from ..migrations.compatibility import TechnicalPath as Path
from urllib.parse import parse_qs, unquote, urlparse

from ..orchestrator.store import TERMINAL
from ..security import redact

STATIC = Path(__file__).parent / "static"
_TID = re.compile(r"^T\d{8}-\d{6}-[0-9a-f]{6}$")
_BACKUP = re.compile(r"^studio-\d{8}T\d{6}Z\.(dpapi|zip)$")
COOKIE = "studio_session"


class Control:
    """Window presence, tasks started from the interface, clean shutdown."""

    def __init__(self, absence_delay_s: float | None = None, grace_s: float = 120.0):
        self.absence_delay_s = absence_delay_s        # None = no automatic shutdown (manual « interface » mode)
        self.last_seen = time.monotonic() + grace_s
        self.jobs = 0
        self.stop_request = threading.Event()
        self._lock = threading.Lock()
        self.keep = lambda: False                   # true = stay open without a window (phone access active)

    def presence(self):
        self.last_seen = max(self.last_seen, time.monotonic())

    def leave(self):
        """The window says it is closing: stop soon (about 10 s, unless a window comes back), not after the full delay."""
        if self.absence_delay_s is not None:
            self.last_seen = min(self.last_seen, time.monotonic() - self.absence_delay_s + 10)

    def begin(self):
        with self._lock:
            self.jobs += 1

    def finish(self):
        with self._lock:
            self.jobs -= 1

    def should_stop(self) -> bool:
        if self.stop_request.is_set():
            return self.jobs == 0
        if self.absence_delay_s is None or self.keep():
            return False
        return self.jobs == 0 and time.monotonic() - self.last_seen > self.absence_delay_s


_FOLDER_KEYS = ("backups", "tasks", "archives", "deliverables", "rules", "projects", "topics")   # folders the UI may open
_GROUPS = [  # (group label shown in the UI, patterns relative to the root; {key} = localized folder name) — display order
    # One place per kind of file, nothing twice: the studio's skills are the single source (each AI gets them,
    # copied into the tools that have their own skills folder), the rules are shared by every AI.
    ("Skills", ["Skills/*/SKILL.md"]),
    ("Règles communes", ["{rules}/*.md", "{rules}/{imported}/*.md"]),
    ("Projets et sujets", ["{projects}/*/*.md", "{projects}/*/*.toml", "{topics}/*/*.md", "{topics}/*/*.toml"]),
    ("Rôles de l'équipe", ["Studio/roles/*.toml"]),
]
_SUBGROUP_FOLDERS = ("Projets et sujets",)          # sub-heading = the project or topic folder
_PROJECT_SKILL_DIRS = (".claude/skills", ".agents/skills")   # where agent tools look for a project's own skills


def _title(p: Path) -> str:
    """Readable title: « name: » of a SKILL.md, else first Markdown heading, else TOML « nom = », else the file name."""
    try:
        head = p.read_text(encoding="utf-8", errors="replace").splitlines()[:40]
    except OSError:
        return p.name
    for l in head:
        if p.name == "SKILL.md" and l.startswith("name:"):
            return l.split(":", 1)[1].strip()
        if l.startswith("# "):
            return l[2:].strip()
        if p.suffix == ".toml" and l.startswith('name ='):
            return l.split("=", 1)[1].strip().strip('"')
    return p.name


def _home() -> Path:
    return Path.home()


def _documents(root: Path, studio=None) -> list[dict]:
    """Documents grouped: the studio's own (Markdown and TOML settings, excluding templates and data), then installed
    skills (global ones of each subscription tool) and those of registered projects. Read-only; never any other file."""
    seen_items, out = set(), []

    def add_item(group: str, src_files: list[tuple[str, Path, str]]):
        task_files = []
        from ..agent_tools import is_rules_copy
        from ..project_page import safe_path
        for path_value, p, subdir in src_files:
            try:
                if path_value.startswith("project:"):
                    project_ref, relative = path_value.split("/", 1)
                    safe_path(studio.registry.get("project:" + project_ref.partition(":")[2]).path(), relative)
                else:
                    safe_path(root, path_value)
            except ValueError:
                continue
            if subdir == "Importées de ton PC" and is_rules_copy(p.read_text(encoding="utf-8", errors="replace")):
                continue                                   # a mere copy of the common rules: not listed twice
            if p.is_file() and p not in seen_items:
                seen_items.add(p)
                task_files.append({"path_value": path_value, "title": redact(_title(p)), "subgroup": subdir, "_p": p})
        if task_files:
            out.append({"group": group, "files": task_files})

    from ..paths import StudioPaths
    folder_names = StudioPaths(root).names
    for group, patterns in _GROUPS:
        src = []
        for m in (x.format(**folder_names) for x in patterns):
            for p in sorted(root.glob(m)):
                if "_model" in p.parts:
                    continue
                rel = p.relative_to(root).as_posix()
                parts = rel.split("/")
                sub = parts[1] if group in _SUBGROUP_FOLDERS and len(parts) > 2 else \
                    "Importées de ton PC" if group == "Règles communes" and len(parts) > 2 else ""
                src.append((rel, p, sub))
        add_item(group, src)
    if studio is not None:                  # a project's own skills, in its repository (one entry per skill name)
        for t in studio.registry.all():
            if t.kind == "project" and t.has_path and t.path().is_dir():
                names, entries = set(), []
                for d in _PROJECT_SKILL_DIRS:
                    for p in sorted((t.path() / d).glob("*/SKILL.md")):
                        if p.parent.name not in names:
                            names.add(p.parent.name)
                            entries.append((f"project:{t.id}/{d}/{p.parent.name}/SKILL.md", p, ""))
                add_item(f"Skills du projet {t.name}", entries)
    return out


def _public(groups: list[dict]) -> list[dict]:
    return [{"group": g["group"], "files": [{k: v for k, v in f.items() if k != "_p"} for f in g["files"]]} for g in groups]


def _doc_paths(root: Path, studio=None) -> dict[str, Path]:
    return {f["path_value"]: f["_p"] for g in _documents(root, studio) for f in g["files"]}


def _pairing_page(message: str = "") -> bytes:
    """Page shown to a phone not yet paired: it types the 6-digit code displayed on the PC."""
    import html
    m = f"<p style='color:#b42318'>{html.escape(message)}</p>" if message else ""
    return ("<!doctype html><html lang=fr><meta charset=utf-8><meta name=viewport content='width=device-width,initial-scale=1'>"
            "<meta name=theme-color content='#0f1115'><title>Super AI Agent Pro Station Max 2000</title>"
            "<body style='font:17px system-ui;margin:0;padding:32px 20px;background:#0f1115;color:#e8eaed'>"
            "<img src='/icon-192.png' alt='' width=64 height=64 style='border-radius:14px'>"
            "<h1 style='font-size:21px'>Associer ce téléphone</h1>"
            "<p style='color:#9aa0a6'>Sur le PC : Superviseur › Réglages › Téléphone › « Associer un téléphone ». "
            "Tape ici le code affiché.</p>" + m +
            "<form method=post action='/associer' style='display:flex;gap:10px;margin-top:18px'>"
            "<input name=code inputmode=numeric autocomplete=one-time-code pattern='[0-9 ]*' maxlength=7 required autofocus "
            "placeholder='123456' style='flex:1;min-width:0;width:100%;box-sizing:border-box;font:24px ui-monospace,monospace;letter-spacing:4px;padding:12px;"
            "border-radius:10px;border:1px solid #3c4043;background:#1b1e24;color:inherit'>"
            "<button style='font:600 17px system-ui;padding:0 20px;border:0;border-radius:10px;background:#8ab4f8;"
            "color:#0f1115'>OK</button></form></body></html>").encode()


def make_handler(studio, port: int, token: str | None = None, controller: Control | None = None):
    allowed_hosts = {f"127.0.0.1:{port}", f"localhost:{port}"}
    # Runs from the interface: up to N tasks in parallel (limites.taches_simultanees), one per project.
    parallel_slots = threading.BoundedSemaphore(max(1, int(studio.cfg["limits"].get("concurrent_tasks", 1))))
    locks: dict[str, threading.Lock] = {}
    locks_guard = threading.Lock()
    ctl = controller or Control()
    from .. import actions, chains
    jobs = actions.Jobs(ctl)
    root = studio.paths.root
    from ..supervisor import Supervisor
    sup = getattr(studio, "supervisor", None) or Supervisor(studio)
    studio.supervisor = sup

    def target_key(target: str) -> str:
        try:
            t = studio.registry.get(target)
            return f"{t.kind}:{t.id}"
        except (KeyError, ValueError):
            return target

    def team(t, key: str, act: list[dict]) -> list[dict]:
        """All roles for this target: suitable ones first; what each one does here or elsewhere."""
        types = {t.type, "topic"} if t.kind == "topic" else {t.type}
        from ..teams import editor_view
        out = []
        for r in studio.roles.values():
            here = [a for a in act if a["role"] == r.id and target_key(a["target"]) == key]
            elsewhere = [{**a, "target": target_key(a["target"])} for a in act
                        if a["role"] == r.id and a["state"] == 'working' and target_key(a["target"]) != key]
            state = ('working' if any(a["state"] == 'working' for a in here) else "awaiting_user" if any(a["state"] == "awaiting_user" for a in here)
                    else "paused" if here else "elsewhere" if elsewhere else "free")
            config = editor_view(studio, r, key)
            tool, model = config["effective_tool"], config["model_label"]
            out.append({"id": r.id, "name": r.name, "tool": tool, "model": model[:1].upper() + model[1:] if model.islower() else model,
                        "adapted": r.id == "reviewer" or bool(types & set(r.domains)), "state": state,
                        "here": here, "elsewhere": elsewhere, **config})
        order = {'working': 0, "awaiting_user": 1, "paused": 2, "elsewhere": 3, "free": 4}
        return sorted(out, key=lambda x: (order[x["state"]], not x["adapted"], x["id"] == "reviewer", x["name"]))   # who is working first

    def projects_list(act: list[dict] | None = None) -> list[dict]:
        tasks = studio.store.list(1000)
        act = studio.activity() if act is None else act
        out = []
        studio_t = studio.registry.studio_target()             # the studio itself: only once it has tasks (audits), never a tab
        extra = [studio_t] if any(x["target"] == f"project:{studio_t.id}" for x in tasks) else []
        for t in [*studio.registry.all(), *extra]:
            key = f"{t.kind}:{t.id}"
            mine = [x for x in tasks if target_key(x["target"]) == key]
            cpt = {"awaiting_validation": 0, "running": 0, "completed": 0}
            for x in mine:
                s = x["status"]
                cpt["awaiting_validation" if s.startswith("awaiting_approval") else "completed" if s in TERMINAL else "running"] += 1
            at_work = sorted({studio.roles[a["role"]].name for a in act if a["state"] == 'working'
                                 and target_key(a["target"]) == key and a["role"] in studio.roles})
            out.append({**t.to_public(), "key": key, "internal": bool(t.extra.get("internal")),
                        "folder": str(t.path()) if t.has_path else "", "counters": cpt,
                        "latest": mine[0] if mine else None, "au_work": at_work, "created": str(t.extra.get("created", ""))})
        return sorted(out, key=lambda p: p["created"], reverse=True)          # stable sort: undated items keep their original order

    def with_action(tasks: list[dict]) -> list[dict]:
        """Running tasks: the agent's last action in plain words (« Modifie EnemyBase.cpp »), for the list card.
        Tasks awaiting approval: a preview of what they produced (first images, file count), to approve without opening."""
        from .. import activity
        from ..task_files import IMAGES
        for x in tasks:
            if str(x["status"]).startswith("awaiting_approval"):
                try:
                    paths = sorted({a["path"] for a in studio.store.artifacts(x["id"])})
                    x["previews"] = [p for p in paths if p.lower().endswith(tuple(IMAGES))][:3]
                    x["count_files"] = len(paths)
                except Exception:                 # noqa: BLE001 — optional
                    pass
            if x["status"] in ("created", "running") and x.get("stage_name") in ("execution", "audit", "verification"):
                try:
                    a = activity.actions(studio.details_dir(x["id"], create_new=False), 1)
                    x["last_action"] = a[0]["text"] if a else ""
                except Exception:                 # noqa: BLE001 — optional
                    pass
        return tasks

    def usage_summary() -> dict:
        """Usage of ALL AIs (subscriptions, API keys, the API aggregator, local AIs): calls, working
        time and tokens over 5 h (subscription window), today, 7 days; pay-per-use cost (API keys:
        actual cost from the aggregator or estimate at today's price), « inclus » for a subscription, free when local.
        Only calls started by the studio are counted."""
        from datetime import timedelta
        from .. import ai
        current_time = datetime.now()
        day = current_time.strftime("%Y-%m-%d")
        five_hours_ago = (current_time - timedelta(hours=5)).isoformat(timespec="seconds")
        week = (current_time - timedelta(days=6)).strftime("%Y-%m-%d")
        month = (current_time - timedelta(days=29)).strftime("%Y-%m-%d")
        monthly_calls = studio.store.api_calls(month)
        api_calls = [x for x in monthly_calls if x["day"] >= week]
        names = {f"{t.kind}:{t.id}": t.name for t in studio.registry.all()}

        def total(batch):
            return {"calls": len(batch), "duration_s": round(sum(x["duration_s"] or 0 for x in batch)),
                    "input": sum(x["input_tokens"] or 0 for x in batch), "cache": sum(x["cache_tokens"] or 0 for x in batch),
                    "output": sum(x["output_tokens"] or 0 for x in batch),
                    "cost_usd": round(sum(x["cost_usd"] or 0 for x in batch), 4), "failures": sum(1 for x in batch if not x["ok"])}

        def access(fam: str) -> str:
            return "subscription" if fam in ("Claude", "Codex") else "local" if "(local)" in fam else "key"
        # every connected or installed AI, even with no usage yet
        known = ["Claude", "Codex"] + [ai.family(c) for c in ai.read_file(studio.paths.data)["connections"]]
        try:
            from .. import local_models
            if local_models.local_runner_executable() and "Ollama (local)" not in known:
                known.append("Ollama (local)")
        except Exception:                                # noqa: BLE001
            pass
        order = list(dict.fromkeys(known + sorted({x["family"] for x in monthly_calls})))
        families = {}
        for fam in order:
            a = [x for x in monthly_calls if x["family"] == fam]
            families[fam] = {"access": access(fam), "day": total([x for x in a if x["day"] == day]),
                             "window": total([x for x in a if x["at"] >= five_hours_ago]),
                             "week": total([x for x in a if x["day"] >= week]), "month": total(a)}
        paid_calls = [x for x in monthly_calls if access(x["family"]) == "key"]
        paid_cost = {"day": round(sum(x["cost_usd"] or 0 for x in paid_calls if x["day"] == day), 4),
                     "week": round(sum(x["cost_usd"] or 0 for x in paid_calls if x["day"] >= week), 4),
                     "month": round(sum(x["cost_usd"] or 0 for x in paid_calls), 4),
                     "without_price": sum(1 for x in paid_calls if x["cost_usd"] is None)}
        todays = [x for x in api_calls if x["day"] == day]
        by = lambda key: sorted(({"name": k, **total([x for x in todays if key(x) == k])}       # noqa: E731
                                  for k in {key(x) for x in todays}), key=lambda d: -d["duration_s"])
        kept_days = []
        for i in range(6, -1, -1):
            d = (current_time - timedelta(days=i)).strftime("%Y-%m-%d")
            kept_days.append({"day": d, "families": {fam: total([x for x in api_calls if x["day"] == d and x["family"] == fam])["duration_s"]
                                                  for fam in order}})
        old_items = [x for x in studio.store.usage(30) if x["day"] >= week]     # counters from before the detailed log
        return {"families": families, "order": order, "days": kept_days, "paid_cost": paid_cost,
                "by_usage": by(lambda x: x["usage"]),
                "by_project": by(lambda x: names.get(x["target"] or "", x["target"] or "toutes les conversations")),
                "latest": [{"hour": x["at"][11:16], "family": x["family"], "usage": x["usage"],
                              "project": names.get(x["target"] or "", x["target"] or ""), "role": x["role"], "model": x["model"],
                              "duration_s": round(x["duration_s"] or 0), "input": x["input_tokens"], "cache": x["cache_tokens"],
                              "output": x["output_tokens"], "cost_usd": x["cost_usd"], "ok": bool(x["ok"])} for x in api_calls[:15]],
                "begin_log": (api_calls[-1]["day"] if api_calls else day),
                "old_counters": [x for x in old_items if not any(a["day"] == x["day"] for a in api_calls)],
                "seuils": studio.cfg.get("usage", {})}

    def mutex(key: str) -> threading.Lock:
        with locks_guard:
            return locks.setdefault(key, threading.Lock())

    def git_single(key: str, fn, *args):
        """Commit or merge on the main folder: allowed even while a task works in ITS copy (git
        protects its own files); two git operations on the same project never overlap."""
        v = mutex("git:" + key)
        if not v.acquire(timeout=120):
            raise RuntimeError("Une autre opération git est en cours sur ce projet : réessaie dans un instant.")
        try:
            return fn(*args)
        finally:
            v.release()

    def exclusive(key: str, fn, *args):
        """Immediate action on a project (merge, removal, build): refused if the project is already busy."""
        v = mutex(key)
        if not v.acquire(blocking=False):
            raise RuntimeError("Ce projet est occupé (une tâche, une fusion ou un retrait est en cours) : réessaie dans un instant.")
        try:
            return fn(*args)
        finally:
            v.release()

    def update_in_progress() -> str:
        return next((j["title"] for k, j in jobs.state().items() if k.startswith("update:") and j.get("state") == "running"), "")

    def following(tid: str) -> None:
        """After a decision, cancellation, resume or merge: starts the next step of a chain if everything
        is ready. While a subscription tool is being updated nothing starts: « Continuer » afterwards."""
        if update_in_progress():
            cid = (studio.store.get(tid).get("options") or {}).get("chain")
            if cid:
                studio.store.update_chain(cid, note=f"{update_in_progress()} : clique « Continuer » une fois terminée.")
            return
        try:
            new_name = chains.advance(studio, tid)
        except Exception as e:                   # noqa: BLE001 — visible in the task log
            studio.store.event(tid, f"Chaîne : étape suivante non lancée ({type(e).__name__})")
            return
        if new_name:
            background(execute, new_name, tid=new_name)

    def execute(tid: str):
        """Runs a task; if it ends on its own (report with no files), the chain continues."""
        r = studio.run(tid)
        after_run(tid)
        return r

    def after_run(tid: str) -> None:
        """After a team pass: automatic merge (autonomous mode), next chain step, summary."""
        t = studio.store.get(tid)
        if t["status"] in ("approved", "applied"):
            if studio.autonomous() and studio._branch_info(tid, t).get("worktree") and not (studio.run_dir(tid) / "nothing-to-apply.json").exists():
                try:                                  # autonomous mode: local merge (never a push), cleanly refused otherwise
                    f = actions.merge(studio, tid)
                    studio.store.event(tid, f"Fusion automatique : {f['message']}")
                    compile_after_merge(tid, t)
                except Exception as e:                # noqa: BLE001 — modified repo, conflict…: the button stays
                    studio.store.event(tid, f"Fusion automatique non faite : {str(e)[:300]} — bouton « Fusionner » disponible")
            following(tid)
        debrief_after(tid)
        from .. import cleanup
        cleanup.after_task(studio, tid)                 # task finished: its working copy is removed right away
    def compile_after_merge(tid: str, t: dict) -> None:
        """A game-engine project's C++ was just merged: closes the editor cleanly, builds the real project, reopens it
        (before the next chain step, which can then use the new fields). Never a forced close."""
        from .. import unreal
        try:
            target = studio.registry.get(t["target"])
            up = unreal.unreal_project(target.path()) if target.has_path else None
            diffs = sorted(studio.details_dir(tid, create_new=False).glob("diff-*.patch"), key=lambda p: int(re.sub(r"\D", "", p.stem) or 0))
            cpp = bool(diffs) and re.search(r"^\+\+\+ b/Source/|^diff --git a/Source/", diffs[-1].read_text(encoding="utf-8", errors="replace"), re.M)
            if not up or not cpp:
                return
            r = unreal.run_compile(up, studio.cfg, lambda m: studio.store.event(tid, m), reopen=up,
                                log=studio.details_dir(tid) / "build-after-merge.log")
            studio.store.event(tid, f"Compilation après fusion : {r['message']}" + (" — " + " | ".join(r.get("errors", [])[:3]) if r["code"] == 2 else ""))
        except Exception as e:                        # noqa: BLE001 — never blocking: the « Compiler » button stays
            studio.store.event(tid, f"Compilation après fusion non faite : {str(e)[:300]}")

    def debrief_after(tid: str) -> None:
        """When the team is done (done, to validate, failed): the Supervisor posts a short summary in the conversation."""
        t = studio.store.get(tid)
        if t["status"] in ("created", "running", "awaiting_slot", "interrupted", "cancelled"):
            return
        if not bool(studio.cfg.get("supervisor", {}).get("outcome", True)):
            return
        threading.Thread(target=sup.debrief, args=(tid,), daemon=True).start()

    def decide_task(tid: str, decision: str, fingerprint: str, comment: str, task_files=None):
        r = studio.decide(tid, decision, fingerprint, comment, task_files)
        if decision == "correct":                    # the team redid the work: same follow-up as a run
            after_run(tid)
        else:
            following(tid)
            from .. import cleanup
            cleanup.after_task(studio, tid)             # validated or cancelled: the studio stays tidy as it goes
        return r

    def cancel_task(tid: str):
        r = studio.cancel(tid)
        following(tid)
        from .. import cleanup
        cleanup.after_task(studio, tid)
        return r

    def resume_task(tid: str):
        r = studio.resume(tid)
        after_run(tid)
        return r

    def background(fn, *args, tid: str = "", free: bool = False):
        'free=True: cancellation or validation (short), never queued behind another task of the project.'
        if not free and update_in_progress():          # the tool is being replaced: no work starts
            raise RuntimeError(f"{update_in_progress()} : attends la fin de la mise à jour, puis relance.")
        target = ""
        if tid:
            try:
                target = target_key(studio.store.get(tid)["target"])
            except KeyError:
                pass

        def run():
            try:
                if free:
                    fn(*args)
                else:
                    with mutex(target or "_"), parallel_slots:   # one task at a time per project, N in total
                        fn(*args)
            except Exception as e:                  # the state is already saved by the studio
                if tid:
                    studio.store.event(tid, f"Erreur interface : {type(e).__name__}")
            finally:
                ctl.finish()
        ctl.begin()
        threading.Thread(target=run, daemon=True).start()

    def merge_supervisor_task(tid):
        key = target_key(studio.store.get(tid)["target"])
        result = git_single(key, actions.merge, studio, tid)
        following(tid)
        return result

    def finish_supervisor_action(rid, index, item):
        from ..supervisor_actions import project_page
        context = {
            "decide": decide_task, "resume": resume_task,
            "launch": lambda tid: background(execute, tid, tid=tid),
            "merge": merge_supervisor_task,
            "project_setting": lambda target, values: project_page.save_settings(studio, target, values),
        }
        if item["action"] in ("set_project_setting", "set_role_setting"):
            key = item["params"]["project"]
            key = target_key(key) if key != "common" else "common"
            try:
                return exclusive(key, sup.actions.finish, rid, index, context)
            except RuntimeError as error:
                # Le refus du verrou doit aussi rester visible dans la proposition.
                with sup.actions.lock:
                    prop = sup.actions._read(rid)
                    prop["actions"][index].update(state="error", error=redact(str(error)))
                    studio.store.update_message(rid, proposal=prop)
                    studio.store.event("studio", "Action du Superviseur validée par Mel : " + item["action"]
                                       + " — erreur : " + redact(str(error)))
                return
        return sup.actions.finish(rid, index, context)

    class H(BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def _send(self, code: int, obj=None, ctype="application/json", raw: bytes | None = None, extra=()):
            data = raw if raw is not None else json.dumps(obj, ensure_ascii=False, default=str).encode()
            self.send_response(code)
            self.send_header("Content-Type", ctype if ctype.startswith(("font/", "image/", "audio/", "video/")) else f"{ctype}; charset=utf-8")   # no charset on binary content
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("X-Frame-Options", "DENY")
            self.send_header("Referrer-Policy", "no-referrer")
            self.send_header("Content-Security-Policy",
                             "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self'; frame-ancestors 'none'")
            for k, v in extra:
                self.send_header(k, v)
            self.end_headers()
            self.wfile.write(data)

        def _remote(self) -> bool:
            """Request that came through the VPN relay (phone) rather than from this PC."""
            from .. import mobile
            return mobile.host_allowed(self.headers.get("Host") or "")

        def _ok_host(self) -> bool:
            if self.headers.get("Host") not in allowed_hosts and not self._remote():
                self._send(403, {"error": "hôte refusé"})
                return False
            return True

        def _cookie(self, name: str = COOKIE) -> str:
            for part in (self.headers.get("Cookie") or "").split(";"):
                k, _, v = part.strip().partition("=")
                if k == name:
                    return v
            return ""

        def _ok_device(self, path: str) -> bool:
            """Phone: device key required (cookie), otherwise pairing page (6-digit code)."""
            from .. import mobile
            if mobile.check(studio.paths.data, self._cookie(mobile.DEVICE_COOKIE)):
                return True
            if path in ("/", "/index.html"):
                self._send(200, ctype="text/html", raw=_pairing_page())
            else:
                self._send(403, {"error": "Téléphone non associé."})
            return False

        def _pair_device(self):
            from .. import mobile
            n = int(self.headers.get("Content-Length", 0) or 0)
            field_values = parse_qs(self.rfile.read(min(n, 2000)).decode("utf-8", "replace"))
            key = mobile.use_code(studio.paths.data, (field_values.get("code") or [""])[0])
            if not key:
                return self._send(403, ctype="text/html", raw=_pairing_page("Code incorrect ou expiré. Demande un nouveau "
                                                                                 "code sur le PC."))
            self.send_response(303)
            self.send_header("Set-Cookie", f"{mobile.DEVICE_COOKIE}={key}; HttpOnly; Secure; SameSite=Lax; Path=/; "
                                           "Max-Age=31536000")
            self.send_header("Location", "/")
            self.send_header("Content-Length", "0")
            self.send_header("Cache-Control", "no-store")
            self.end_headers()

        def _ok_session(self, path: str, query: dict) -> bool:
            """Without launcher (token None): local protections only. With launcher: session cookie required.
            Through the VPN relay (phone): device key required in every case."""
            if self._remote():
                return self._ok_device(path)
            if token is None:
                return True
            if hmac.compare_digest(self._cookie(), token):
                return True
            given = (query.get("t") or [""])[0]
            if path == "/" and given and hmac.compare_digest(given, token):
                # Exchange the key for a cookie, then clean the address (the key does not stay in the address bar).
                self.send_response(303)
                self.send_header("Set-Cookie", f"{COOKIE}={token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=31536000")
                self.send_header("Location", "/")
                self.send_header("Content-Length", "0")
                self.send_header("Cache-Control", "no-store")
                self.send_header("Referrer-Policy", "no-referrer")
                self.end_headers()
                return False
            page = ("<!doctype html><meta charset=utf-8><title>Super AI Agent Pro Station Max 2000</title><body style='font:16px system-ui;"
                    "padding:40px'><h1>Super AI Agent Pro Station Max 2000</h1><p>Session non reconnue. Ouvre le studio avec le raccourci "
                    "« Super AI Agent Pro Station Max 2000 » du bureau.</p>").encode()
            self._send(403, ctype="text/html", raw=page)
            return False

        def _body(self) -> dict:
            n = int(self.headers.get("Content-Length", 0) or 0)
            return json.loads(self.rfile.read(n) or b"{}") if n < 1_000_000 else {}

        # ------------------------------------------------------------------ GET
        def do_GET(self):
            if not self._ok_host():
                return
            u = urlparse(self.path)
            path, query = json.api_path(u.path), json.normalize(parse_qs(u.query))
            if path == "/api/ping":                     # no data: lets the launcher detect an open instance
                return self._send(200, {"studio": True})
            m_font = re.fullmatch(r"/fonts/([a-z0-9-]+\.woff2)", path)
            if m_font and (STATIC / "fonts" / m_font.group(1)).is_file():     # local fonts (OFL), never a CDN
                return self._send(200, ctype="font/woff2", raw=(STATIC / "fonts" / m_font.group(1)).read_bytes())
            m_logo = re.fullmatch(r"/logos/([a-z0-9-]+\.svg)", path)
            if m_logo and (STATIC / "logos" / m_logo.group(1)).is_file():           # logos of AIs and tools (MIT/CC0 licences)
                return self._send(200, ctype="image/svg+xml", raw=(STATIC / "logos" / m_logo.group(1)).read_bytes())
            if path == "/favicon.ico":
                ico = STATIC / "logo-boom-2000.ico"
                return self._send(200, ctype="image/x-icon", raw=(ico if ico.is_file() else STATIC / "station-max-2000.ico").read_bytes())
            if path in ("/header-logo.png", "/logo-boom-2000.png"):          # studio logo (public, like the favicon)
                return self._send(200, ctype="image/png", raw=(STATIC / path.lstrip("/")).read_bytes())
            if path in ("/icon-192.png", "/icon-512.png"):                   # app icons (phone)
                return self._send(200, ctype="image/png", raw=(STATIC / path.lstrip("/")).read_bytes())
            if path in ("/icone-192.png", "/icone-512.png", "/logo-header.png"):  # older names, still asked by installed phone apps
                new = {"/icone-192.png": "icon-192.png", "/icone-512.png": "icon-512.png", "/logo-header.png": "header-logo.png"}[path]
                return self._send(200, ctype="image/png", raw=(STATIC / new).read_bytes())
            if path == "/manifest.webmanifest":                               # install the studio on the phone
                return self._send(200, ctype="application/manifest+json", raw=(STATIC / "manifest.webmanifest").read_bytes())
            if path == "/sw.js":
                return self._send(200, ctype="text/javascript", raw=(STATIC / "sw.js").read_bytes(), extra=(("Service-Worker-Allowed", "/"),))
            if not self._ok_session(path, query):
                return
            try:
                if path in ("/", "/index.html"):
                    return self._send(200, ctype="text/html", raw=(STATIC / "index.html").read_bytes())
                if path == "/app.js":
                    return self._send(200, ctype="text/javascript", raw=(STATIC / "app.js").read_bytes())
                if path == "/api/session":
                    from .. import mobile
                    from ..user_workspace import name as workspace_name
                    return self._send(200, {"launcher": token is not None, "automatic_stop": ctl.absence_delay_s is not None,
                                            "jobs": ctl.jobs, "distant": self._remote(), "name": workspace_name(),
                                            "reste_open": mobile.relay_active(),
                                            "language": str((studio.cfg.get("user") or {}).get("language") or "fr")})
                if path == "/api/welcome":               # first launch: AIs ready, local model runner, Git/GitHub, models suited to the PC
                    from .. import welcome
                    return self._send(200, {**welcome.state(studio), "distant": self._remote()})
                if path == "/api/system":               # header: processor, memory, graphics card, loaded local AI
                    from .. import system
                    return self._send(200, system.survey())
                if path == "/api/state":
                    from ..health import check_all
                    if query.get("leger"):                  # top banner every 30 s: memory only
                        h = studio.memory.health()
                        return self._send(200, {"memory": {"state": h.state, "backend": h.backend, "detail": h.detail, "pending": h.pending}})
                    return self._send(200, check_all(studio, probe_tools=True))
                m = re.fullmatch(r"/api/projects/([a-z0-9][a-z0-9._-]{0,63})/(skills|memory|documents|settings)", path)
                if m:
                    from .. import project_page
                    from ..memory import MemoryUnavailable
                    try:
                        t = project_page.target(studio, m.group(1))
                        action = m.group(2)
                        relative = (query.get("path") or [""])[0]
                        if action == "settings":
                            result = {**project_page.read_settings(studio, t), "read_only": self._remote()}
                        elif action == "memory":
                            result = project_page.memory(studio, t, (query.get("q") or [""])[0])
                        elif relative:
                            result = project_page.read_resource(t, relative, "skill" if action == "skills" else "document")
                        else:
                            result = project_page.skills(t) if action == "skills" else project_page.documents(t)
                        return self._send(200, project_page.public(result))
                    except MemoryUnavailable:
                        return self._send(503, {"error": "MÉMOIRE EN PANNE — lecture du projet indisponible."})
                    except (ValueError, OSError) as error:
                        return self._send(400, {"error": redact(str(error))[:600]})
                if path == "/api/targets":
                    return self._send(200, [t.to_public() for t in studio.registry.all()])
                if path == "/api/organization":
                    from ..teams import editor_view
                    organization = studio.organization()
                    for item in organization["team"]:
                        item.update(editor_view(studio, studio.roles[item["id"]]))
                    return self._send(200, organization)
                if path == "/api/conversation":
                    # each conversation is separate: home shows only its own, a project only its own
                    project = (query.get("project") or [""])[0]
                    msgs = [m for m in studio.store.messages(400) if (m["proposal"].get("project") or "") == project
                            and not m["proposal"].get("removed")][-80:]
                    from ..supervisor import readable_names
                    for m in msgs:                    # including old replies: never a task identifier on screen
                        if m["author"] != "mel":
                            m["text"] = readable_names(studio, m["text"])
                    launched = {m["proposal"].get("task") for m in msgs if m["proposal"].get("state") == "launched"} - {None, ""}
                    if launched:                      # live tracking in the bubble: stage, time, cost
                        rows = {x["id"]: x for x in studio.store.list(500) if x["id"] in launched}
                        for m in msgs:
                            x = rows.get(m["proposal"].get("task"))
                            if x:
                                m["proposal"]["tracking"] = {k: x.get(k) for k in (
                                    "status", "stage_name", "created_at", "updated_at", "duration_s", "stage_since", "cost_usd", "title")}
                    return self._send(200, msgs)
                if path == "/api/attachment":
                    rel = (query.get("path_value") or [""])[0]
                    base = studio.paths.attachments.resolve()
                    if rel.startswith("Runs/attachments/"):          # messages from before the cleanup (maj75)
                        rel = studio.paths.attachments.relative_to(studio.paths.root).as_posix() + "/" + rel[len("Runs/attachments/"):]
                    from ..migrations.compatibility import _renamed_path
                    f = _renamed_path(studio.paths.root / rel).resolve()
                    types = {".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".gif": "image/gif", ".webp": "image/webp"}
                    if base not in f.parents or not f.is_file() or f.suffix.lower() not in types:
                        return self._send(404, {"error": "missing"})
                    return self._send(200, ctype=types[f.suffix.lower()], raw=f.read_bytes())
                if path == "/api/skills/conflicts":       # proposed updates (skills and .md changed outside the studio)
                    from ..initial_import import proposals
                    return self._send(200, proposals(studio.paths.root, studio.paths.data))
                if path == "/api/usage":
                    return self._send(200, usage_summary())
                if path == "/api/cleanup":                 # Gestion › Entretien: last automatic cleanup
                    from .. import cleanup
                    try:
                        d = json.loads((studio.paths.data / "cleanup.json").read_text(encoding="utf-8"))
                    except (OSError, ValueError):
                        d = {}
                    return self._send(200, {**d, "text": cleanup.summary(d) if d else "", "active": (studio.cfg.get("maintenance") or {}).get("automatic_cleanup") is not False})
                if path == "/api/results":              # Usage › Tes résultats: what your tasks say about each model
                    from .. import learning
                    return self._send(200, learning.results(studio))
                if path == "/api/push":                 # phone notifications: VAPID public key, number of subscribers
                    from .. import push
                    return self._send(200, {"key": push.server_key(studio.paths.data), "subscribers": len(push.read_file(studio.paths.data)["subscriptions"])})
                if path == "/api/push/pending":      # read by the phone when it wakes up
                    from .. import push
                    return self._send(200, push.pending(studio))
                if path == "/api/night":                  # night queue and time window
                    from .. import night
                    d = night.read_file(studio.paths.data)
                    return self._send(200, {"file": d["file"], "range_value": night.time_window(studio.cfg)})
                if path == "/api/extensions/catalog":
                    from ..extensions import build_catalog
                    return self._send(200, build_catalog(studio))
                if path == "/api/library":         # Personnalisation: skills, connectors, packs
                    from .. import library
                    return self._send(200, library.state(studio))
                if path == "/api/library/export":
                    from .. import library
                    ident = (query.get("id") or [""])[0]
                    return self._send(200, raw=library.export_skill(studio, ident), ctype="application/zip",
                                      extra=(("Content-Disposition", f'attachment; filename="{ident}.zip"'),))
                if path == "/api/teams":              # Gestion: projects × roles
                    from .. import teams
                    return self._send(200, teams.board(studio))
                if path == "/api/teams/project":
                    from .. import teams
                    return self._send(200, teams.project_view(studio, target_key((query.get("target") or [""])[0])))
                if path == "/api/shortcuts":           # « / » in the message to the Supervisor
                    from .. import shortcuts
                    return self._send(200, shortcuts.entries(studio.paths.code, studio.paths.data))
                if path == "/api/mentions":             # « @ » in the message to the Supervisor: files and functions
                    from .. import mentions
                    project = sup.project((query.get("project") or [""])[0])
                    return self._send(200, mentions.lookup(studio, project, (query.get("q") or [""])[0][:100]))
                if path == "/api/audits":               # last skills / memories audit per project (Gestion)
                    from .. import audits
                    return self._send(200, audits.latest(studio))
                if path == "/api/mobile":               # « Téléphone » card: VPN, relay, paired devices
                    from .. import mobile
                    return self._send(200, {"setting": bool(studio.cfg["interface"].get("mobile_access")),
                                            "tailscale": mobile.tailscale_state(), **mobile.relay_state(),
                                            "address": mobile.remote_host(), "code": mobile.code_in_progress(),
                                            "devices": mobile.public(studio.paths.data), "distant": self._remote()})
                if path == "/api/ai":                   # connections to AIs (never the keys)
                    from .. import ai
                    from ..connectors.base import find_exe
                    from ..connectors.primary_cli import WIN_CANDIDATES
                    actor, c = ai.choice(studio, "supervisor")
                    from ..local_models import local_runner_executable
                    return self._send(200, {**ai.public(studio.paths.data), "local_items": ai.detect_local_models(),
                                            "ollama_installed": bool(local_runner_executable()),
                                            "claude": bool(find_exe(studio.cfg["tools"].get("primary_cli", "claude"), WIN_CANDIDATES)),
                                            "codex": bool(find_exe(studio.cfg["tools"].get("secondary_cli", "codex"))),
                                            "active": actor, "distant": self._remote()})
                if path == "/api/agents/catalog":     # create an agent: domains, roles, connected AIs, recommendations
                    from .. import agents
                    cat = agents.catalog()
                    return self._send(200, {**cat, "sources": agents.connected_sources(studio),
                                            "recommendations": {c: agents.recommend(studio, c)
                                                                for c in ("text", "code", "image", "video", "voice")}})
                if path == "/api/benchmarks":
                    from .. import agents
                    return self._send(200, {**agents.benchmarks(studio.paths.data),
                                            "connected": sorted({s["provider"] for s in agents.connected_sources(studio)})})
                if path == "/api/local-models/details":   # Outils: installed local models (size, date)
                    from .. import local_models
                    return self._send(200, local_models.details())
                if path == "/api/local-models":       # benchmarks: models installable on the PC (local runner)
                    from .. import agents, local_models
                    return self._send(200, local_models.state(agents.benchmarks(studio.paths.data)["models"]))
                if path == "/api/update":
                    from .. import updates
                    updates.check()
                    return self._send(200, updates.state())
                if path == "/api/connectors":
                    from .. import software_connectors
                    return self._send(200, {"connectors": software_connectors.list_all(studio), "suggestions": software_connectors.SUGGESTIONS})
                if path == "/api/packs":                # skill and role packs (base always present)
                    from ..user_workspace import packs_state
                    return self._send(200, packs_state(studio.paths.root))
                if path == "/api/settings":             # studio settings editable from Gestion (closed list)
                    from .. import settings
                    return self._send(200, settings.entries(studio.cfg))
                if path == "/api/limits":              # subscription limits in % (read-only, one tool's figures cached 60 s)
                    from .. import limits
                    return self._send(200, limits.limits(studio.cfg))
                if path == "/api/alerts":
                    # Alert when, at the current pace, the subscription limit (same % as /usage) will be reached
                    # within less than the configured threshold (default 1 h). No alert if limits are unavailable.
                    from .. import limits
                    u = studio.cfg.get("usage", {})
                    thresholds = {"Claude": u.get("primary_alert_5h_min", 60), "Codex": u.get("secondary_alert_5h_min", 60)}
                    return self._send(200, limits.alerts(limits.limits(studio.cfg), thresholds))
                if path == "/api/choices":
                    from .. import ai
                    return self._send(200, {**studio.choice(), "profile": studio.profile(),
                                            "ai_efforts": {k: [list(x) for x in v] for k, v in ai.AI_EFFORTS.items()}})
                if path == "/api/tools/versions":
                    return self._send(200, actions.versions(studio))
                if path == "/api/tools/installed":
                    return self._send(200, actions.installed())
                if path == "/api/jobs":
                    return self._send(200, jobs.state())
                if path == "/api/git":                  # git state of each project (« Git et GitHub » tab, project page)
                    from .. import project_git
                    return self._send(200, project_git.entries(studio))
                if path.startswith("/api/git/") and path.endswith("/a-commiter"):    # files to commit, checked boxes
                    from .. import project_git
                    try:
                        return self._send(200, project_git.to_commit(studio, unquote(path[len("/api/git/"):-len("/a-commiter")])))
                    except ValueError as e:
                        return self._send(404, {"error": str(e)})
                if path.startswith("/api/git/"):
                    from .. import project_git
                    try:
                        return self._send(200, project_git.detail(studio, unquote(path[len("/api/git/"):])))
                    except ValueError as e:
                        return self._send(404, {"error": str(e)})
                if path == "/api/workspaces":
                    return self._send(200, actions.workspaces(studio))
                if path == "/api/projects":
                    return self._send(200, projects_list())
                if path.startswith("/api/projects/"):
                    key = unquote(path[len("/api/projects/"):])
                    act = studio.activity()
                    p = next((x for x in projects_list(act) if x["key"] == key), None)
                    if p is None:
                        return self._send(404, {"error": "projet inconnu"})
                    p["team"] = team(studio.registry.get(key), key, act)
                    p["buildable"] = bool(studio.registry.get(key).extra.get("build"))
                    base = studio.paths.projects if p["kind"] == "project" else studio.paths.topics
                    ctx = base / p["id"] / "CONTEXTE.md"
                    from ..project_page import safe_path
                    try:
                        safe_path(base, p["id"] + "/CONTEXTE.md")
                    except ValueError:
                        ctx = None
                    tasks = with_action([x for x in studio.store.list(1000) if target_key(x["target"]) == key])
                    return self._send(200, {**p, "tasks": tasks, "profile": studio.project_profiles().get(key, ""),
                                            "welcome_profile": studio.profile(),
                                            "context": redact(ctx.read_text(encoding="utf-8", errors="replace")) if ctx and ctx.exists() else "",
                                            "context_path_value": ctx.relative_to(root).as_posix() if ctx and ctx.exists() else ""})
                if path == "/api/tasks":
                    return self._send(200, with_action(studio.store.list()))
                if path == "/api/memory":
                    return self._memory_get(query)
                if path == "/api/backups":
                    files = sorted((p for p in studio.paths.backups.glob("studio-*") if _BACKUP.match(p.name)), reverse=True)
                    return self._send(200, [{"name": p.name, "bytes": p.stat().st_size,
                                             "date": datetime.fromtimestamp(p.stat().st_mtime, timezone.utc).isoformat()}
                                            for p in files[:50]])
                if path == "/api/documents":
                    return self._send(200, _public(_documents(root, studio)))
                if path == "/api/document":
                    rel = (query.get("path_value") or [""])[0]
                    allowed = _doc_paths(root, studio)
                    if rel not in allowed:
                        return self._send(404, {"error": "document inconnu"})
                    return self._send(200, {"path_value": rel, "text": redact(allowed[rel].read_text(encoding="utf-8", errors="replace"))[:400_000]})
                m = re.match(r"^/api/tasks/([^/]+)/activity$", path)
                if m and _TID.match(m.group(1)):       # live: what the agent is doing, files touched, applications
                    from .. import activity, unreal
                    from ..orchestrator.processes import processes
                    tid = m.group(1)
                    t = studio.store.get(tid)
                    details = studio.details_dir(tid, create_new=False)
                    work = studio.run_dir(tid, create_new=False) / 'copie-de-travail'
                    active = t["status"] in ("created", "running", "awaiting_slot")
                    j = activity.log(details, studio.store.events(tid), steps=studio.store.steps(tid))
                    out = {"actions": activity.actions(details, 8), "files": activity.task_files(work, details, studio.cfg["tools"].get("git", "git")),
                           "applications": [], "log": j["inputs"], "model": j["model"], "used": j["used"]}
                    if active:
                        try:
                            c = studio.registry.get(t["target"])
                            ue = c.has_path and (c.extra.get("type") == "unreal" or bool(unreal.unreal_project(c.path())))
                        except KeyError:
                            ue = False
                        pids = [p["pid"] for p in processes(studio.store, tid) if p["status"] == "running" and p["pid"]]
                        out["applications"] = activity.applications(pids, ue)
                    return self._send(200, out)
                if path == "/api/files":            # Fichiers tab: what agents created for this project
                    from .. import task_files
                    return self._send(200, task_files.entries(studio, target_key((query.get("target") or [""])[0])))
                if path == "/api/files/view":
                    from .. import task_files
                    tid, rel = (query.get("tid") or [""])[0], (query.get("path_value") or [""])[0]
                    if not _TID.match(tid) or not task_files.permitted(studio, tid, rel):
                        return self._send(404, {"error": "fichier inconnu"})
                    f, _ = task_files.place(studio, tid, rel)
                    if f is None:
                        return self._send(404, {"error": "fichier introuvable (copie retirée ?)"})
                    ext = f.suffix.lower()
                    if ext in task_files.IMAGES and f.stat().st_size <= task_files.MAX_IMAGE:
                        return self._send(200, raw=f.read_bytes(), ctype=task_files.IMAGES[ext])
                    if ext in (".md", ".txt", ".csv", ".json") and f.stat().st_size <= task_files.MAX_TEXT:
                        return self._send(200, raw=redact(f.read_text(encoding="utf-8", errors="replace")).encode("utf-8"),
                                          ctype="text/plain")
                    if ext in task_files.MEDIA and f.stat().st_size <= task_files.MAX_MEDIA:     # sounds and videos: played in the gallery
                        return self._send(200, raw=f.read_bytes(), ctype=task_files.MEDIA[ext])
                    return self._send(415, {"error": "aperçu impossible : ouvre-le avec « Ouvrir »"})
                m = re.match(r"^/api/tasks/([^/]+)/captures(?:/([A-Za-z0-9._ -]{1,120}))?$", path)
                if m and _TID.match(m.group(1)):       # images saved by the agent in Taches/<tâche>/captures
                    folder = studio.run_dir(m.group(1), create_new=False) / "captures"
                    from ..project_page import safe_path
                    try:
                        safe_path(studio.run_dir(m.group(1), create_new=False), "captures")
                    except ValueError:
                        return self._send(404, {"error": "capture inconnue"})
                    types = {".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".webp": "image/webp", ".gif": "image/gif"}
                    if not m.group(2):
                        names = sorted(p.name for p in folder.glob("*") if p.is_file() and p.suffix.lower() in types) if folder.is_dir() else []
                        return self._send(200, names[:60])
                    from ..project_page import safe_path
                    try:
                        f = safe_path(studio.run_dir(m.group(1), create_new=False), "captures/" + unquote(m.group(2)))
                    except ValueError:
                        return self._send(404, {"error": "capture inconnue"})
                    if f.parent != folder or f.suffix.lower() not in types or not f.is_file() or f.stat().st_size > 40_000_000:
                        return self._send(404, {"error": "capture inconnue"})
                    return self._send(200, raw=f.read_bytes(), ctype=types[f.suffix.lower()])
                m = re.match(r"^/api/tasks/([^/]+)(?:/(result|diff|processes|cancellable))?$", path)
                if m and _TID.match(m.group(1)):
                    tid, what = m.group(1), m.group(2)
                    if what == "cancellable":
                        return self._send(200, actions.cancellable(studio, tid))
                    if what == "result":
                        f = studio.run_dir(tid, create_new=False) / "RESULTAT.md"
                        b = studio.run_dir(tid, create_new=False) / "BRANCHE.md"
                        text = (b.read_text(encoding="utf-8") + "\n\n---\n\n" if b.exists() else "") \
                            + (f.read_text(encoding="utf-8") if f.exists() else "")
                        return self._send(200, {"text": text})
                    if what == "diff":
                        diffs = sorted(studio.details_dir(tid, create_new=False).glob("diff-*.patch"),
                                       key=lambda p: int(re.sub(r"\D", "", p.stem) or 0))
                        return self._send(200, {"text": diffs[-1].read_text(encoding="utf-8")[:200_000] if diffs else ""})
                    if what == "processes":
                        from ..orchestrator.processes import processes
                        return self._send(200, processes(studio.store, tid))
                    st_ = studio.status(tid)
                    cid = (studio.store.get(tid).get("options") or {}).get("chain")
                    if cid:
                        st_["chain"] = chains.summary(studio, cid)
                    return self._send(200, st_)
                if path == "/api/chains":
                    target = (query.get("target") or [""])[0]
                    return self._send(200, [chains.summary(studio, c["id"]) for c in studio.store.chains(target_key(target) if target else "")])
                self._send(404, {"error": "missing"})
            except KeyError as e:
                self._send(404, {"error": str(e)})

        def _memory_get(self, query: dict):
            from ..memory import MemoryUnavailable, Scope
            scope_list = [Scope.parse(x) for x in query.get("scope", []) if x]
            q = (query.get("q") or [""])[0]
            try:
                recs = studio.memory.recall(q, scope_list, include_general=True, limit=100)
                return self._send(200, {"state": "OK", "memories": [r.to_dict() for r in recs],
                                        "pending": studio.memory.pending_count()})
            except MemoryUnavailable as e:
                return self._send(503, {"error": f"MÉMOIRE EN PANNE — {e}"})

        def _receive_attachment(self, q: dict):
            """File dropped or pasted into the Demande window → Studio/data/pieces-jointes/<lot>/<relative path>. 50 MB max per file."""
            batch = (q.get("lot") or [""])[0]
            rel = (q.get("rel") or q.get("name") or [""])[0].replace("\\", "/")
            n = int(self.headers.get("Content-Length", 0) or 0)
            if not re.fullmatch(r"[A-Za-z0-9_-]{6,64}", batch) or not rel or n <= 0:
                return self._send(400, {"error": "pièce invalide"})
            if n > 50 * 1024 * 1024:
                return self._send(413, {"error": "fichier trop gros (50 Mo maximum)"})
            parts = [re.sub(r'[<>:"|?*\x00-\x1f]', "_", p).strip(" .") for p in rel.split("/") if p not in ("", ".", "..")]
            if not parts or not all(parts):
                return self._send(400, {"error": "nom de fichier invalide"})
            from ..project_page import safe_path
            try:
                base = safe_path(studio.paths.data, "attachments/" + batch)
                dest = safe_path(base, "/".join(parts))
            except ValueError:
                return self._send(400, {"error": "chemin refusé"})
            if base not in dest.parents:
                return self._send(400, {"error": "chemin refusé"})
            if sum(1 for _ in base.rglob("*")) > 500 if base.exists() else False:
                return self._send(413, {"error": "trop de fichiers dans ce message"})
            data = self.rfile.read(n)
            dest.parent.mkdir(parents=True, exist_ok=True)
            if dest.exists():                           # never overwrite: add a suffix
                dest = dest.with_name(f"{dest.stem}-{int(time.time() * 1000) % 100000}{dest.suffix}")
            dest.write_bytes(data)
            return self._send(201, {"path_value": dest.relative_to(studio.paths.root).as_posix(), "bytes": len(data)})

        # ------------------------------------------------------------------ POST
        def do_POST(self):
            if not self._ok_host():
                return
            u = urlparse(self.path)
            path = json.api_path(u.path)
            if path == "/pair" and self._remote():   # pairing page form (phone)
                return self._pair_device()
            if self.headers.get("X-Studio") != "1":
                return self._send(403, {"error": "en-tête X-Studio manquant"})
            if not self._ok_session(path, {}):
                return
            # Le téléphone garde les tâches et validations ; configuration et installations exigent le PC.
            local_paths = {"/api/settings", "/api/tools/install", "/api/tools/update",
                           "/api/local-models/install", "/api/agents/create", "/api/skills/conflict",
                           "/api/packs/install"}
            if self._remote() and (path in local_paths or path.startswith("/api/library/")):
                return self._send(403, {"error": "À faire depuis le PC."})
            if path == "/api/attachments":
                return self._receive_attachment(parse_qs(u.query))
            if path == "/api/library/import":    # skill as .zip: preview and review, then install
                n = int(self.headers.get("Content-Length", 0) or 0)
                from .. import library
                try:
                    return self._send(200, library.import_skill(studio, self.rfile.read(min(n, library.MAX_IMPORT + 1)),
                                                                       (parse_qs(u.query).get("confirm") or ["0"])[0] == "1"))
                except ValueError as e:
                    return self._send(400, {"error": str(e)})
            if path == "/api/dictate":                   # microphone: speech → text, transcribed on the PC (local speech-to-text)
                n = int(self.headers.get("Content-Length", 0) or 0)
                if n <= 0 or n > 25 * 1024 * 1024:
                    return self._send(413, {"error": "enregistrement vide ou trop long"})
                data = self.rfile.read(n)
                from .. import attachments
                ext = {"audio/ogg": ".ogg", "audio/mp4": ".m4a", "audio/wav": ".wav"}.get((self.headers.get("Content-Type") or "").split(";")[0], ".webm")
                try:
                    return self._send(200, {"text": attachments.dictate(data, studio.cfg.get("attachments", {}), ext)})
                except ValueError as e:
                    return self._send(400, {"error": str(e)})
                except Exception as e:                  # noqa: BLE001 — model still downloading, unreadable audio…
                    return self._send(500, {"error": f"Dictée impossible ({type(e).__name__})."})
            b = self._body()
            try:
                m = re.fullmatch(r"/api/projects/([a-z0-9][a-z0-9._-]{0,63})/(settings|open-folder)", path)
                if m:
                    from .. import project_page
                    if self._remote():
                        return self._send(403, {"error": "À faire depuis le PC."})
                    t = project_page.target(studio, m.group(1))
                    if m.group(2) == "settings":
                        try:
                            result = exclusive(f"project:{t.id}", project_page.save_settings, studio, t, b.get("values"))
                        except OSError:
                            return self._send(500, {"error": "Enregistrement impossible : vérifie les droits et l’espace disque. "
                                                            "La fiche du projet reste intacte."})
                        return self._send(200, result)
                    kind = b.get("kind", "document")
                    if kind not in ("document", "skill"):
                        raise ValueError("Type de document inconnu.")
                    location = project_page.resource(t, b.get("path", ""), kind).parent
                    from ..os_support import open_
                    open_(location)
                    return self._send(200, {"ok": True})
                if path == "/api/conversation":
                    batch, project = str(b.get("lot", "")), str(b.get("project", ""))
                    choice = studio.choice()
                    supervisor_model = str(b.get("model", "")) if b.get("model") in choice["models"] else ""
                    supervisor_effort = str(b.get("effort", "")) if b.get("effort") in choice["efforts"] else ""
                    sup.remember_choice(supervisor_model, supervisor_effort)
                    mid, rid = sup.ask(b.get("text", ""), batch, project)
                    text = b.get("text", "")

                    def reply():
                        try:
                            sup.reply(text, rid, batch, project, supervisor_model, supervisor_effort)
                        finally:
                            ctl.finish()
                    ctl.begin()
                    threading.Thread(target=reply, daemon=True).start()
                    return self._send(202, {"id": mid, "response": rid})
                m = re.fullmatch(r"/api/conversation/(\d+)/action", path)
                if m:
                    if set(b) - {"index", "comment"} or "index" not in b:
                        raise ValueError("Le clic accepte seulement index et le commentaire de correction.")
                    if update_in_progress():
                        raise RuntimeError(f"{update_in_progress()} : attends la fin de la mise à jour.")
                    rid, index = int(m.group(1)), b["index"]
                    try:
                        item = sup.actions.claim(rid, index, b.get("comment"), remote=self._remote())
                    except ValueError as error:
                        if self._remote() and str(error) == "À faire depuis le PC.":
                            return self._send(403, {"error": str(error)})
                        raise
                    tid = item["params"].get("tid", "")
                    background(finish_supervisor_action, rid, index, item, tid=tid,
                               free=item["action"] not in ("request_correction", 'resume_task'))
                    return self._send(202, {"ok": True})
                m = re.match(r"^/api/conversation/(\d+)/(stop|edit)$", path)
                if m:                                   # the user stops a reply, or takes back their last message to fix it
                    return self._send(200, sup.halt(int(m.group(1))) if m.group(2) == "stop" else sup.modify(int(m.group(1))))
                m = re.match(r"^/api/conversation/(\d+)/(launch|ignore|night|team|install|done)$", path)
                if m:
                    rid = int(m.group(1))
                    if m.group(2) == "done":            # chain announcement acted upon (merge / continue)
                        msg = next((x for x in studio.store.messages(400) if x["id"] == rid), None)
                        if msg and str((msg["proposal"] or {}).get("state", "")).startswith("chain_"):
                            studio.store.update_message(rid, proposal={**msg["proposal"], "state": "chain_done"})
                        return self._send(200, {"ok": True})
                    if m.group(2) == "install":       # extension suggested by the Supervisor: installed on the user's click
                        if self._remote():
                            return self._send(403, {"error": "À faire depuis le PC."})
                        return self._send(200, sup.install_item(rid, str(b.get("id", ""))))
                    if m.group(2) == "team":          # team proposed by the Supervisor: applied on the user's click
                        return self._send(200, sup.apply_team(rid))
                    if m.group(2) == 'ignore':
                        sup.ignore(rid)
                        return self._send(200, {"ok": True})
                    if m.group(2) == "night":            # « Cette nuit »: queued, starts during the night window
                        from .. import night
                        return self._send(200, night.schedule(studio, rid, b.get("target", ""), b.get("request", ""), b.get("model", ""),
                                                              b.get("mode", "") if b.get("mode") in ("fast", "max") else "",
                                                              b.get("effort", "") if b.get("effort") in studio.choice()["efforts"] else ""))
                    tid = sup.launch(rid, b.get("target", ""), b.get("request", ""), b.get("model", ""),
                                     b.get("mode", "") if b.get("mode") in ("fast", "max") else "",
                                     b.get("effort", "") if b.get("effort") in studio.choice()["efforts"] else "")
                    background(execute, tid, tid=tid)
                    return self._send(201, {"tid": tid})
                if path == "/api/local-models/start":
                    from .. import local_models
                    if self._remote():
                        return self._send(403, {"error": "Ollama s'ouvre sur le PC."})
                    return self._send(200, local_models.startup())
                if path == "/api/local-models/uninstall":
                    from .. import local_models
                    if self._remote():
                        return self._send(403, {"error": "À faire depuis le PC."})
                    return self._send(200, local_models.uninstall(str(b.get("name", ""))))
                if path == "/api/local-models/install":
                    from .. import agents, local_models
                    return self._send(202, local_models.install(str(b.get("name", "")), agents.benchmarks(studio.paths.data)["models"],
                                                                    open_=False))
                if path in ("/api/push/subscribe", "/api/push/unsubscribe", "/api/push/test"):
                    from .. import push
                    if path.endswith("subscribe") and not path.endswith("unsubscribe"):
                        return self._send(200, push.subscribe(studio.paths.data, b.get("subscription") or {}, str(b.get("device", ""))))
                    if path.endswith("unsubscribe"):
                        return self._send(200, push.unsubscribe(studio.paths.data, str(b.get("endpoint", ""))))
                    return self._send(200, {"sent": push.send(studio.paths.data)})
                if path == "/api/cleanup":
                    from .. import cleanup
                    r = cleanup.launch(studio, forced=True)
                    return self._send(200, {**r, "text": cleanup.summary(r)})
                if path == "/api/welcome/record":
                    from .. import welcome
                    return self._send(200, welcome.jot(studio.paths.data, **{k: b[k] for k in ("finished", "visit") if k in b}))
                if path in ("/api/welcome/install", "/api/welcome/github"):
                    from .. import welcome
                    if self._remote():
                        return self._send(403, {"error": "À faire depuis le PC (une fenêtre s'y ouvre)."})
                    if path.endswith("github"):
                        return self._send(200, welcome.connect_github())
                    return self._send(200, welcome.install(str(b.get("tool", ""))))
                if path == "/api/codex/connection":       # Benchmarks: sign in with a chat subscription
                    from .. import limits
                    if self._remote():
                        return self._send(403, {"error": "La connexion se fait sur le PC (une fenêtre s'y ouvre)."})
                    return self._send(200, limits.secondary_cli_connection(studio.cfg))
                if path in ("/api/claude/reconnecter", "/api/claude/connection"):   # Usage: subscription tool login expired
                    from .. import limits
                    if path.endswith("reconnecter"):
                        return self._send(200, limits.reconnect_primary_cli(studio.cfg))
                    if self._remote():
                        return self._send(403, {"error": "La connexion se fait sur le PC (une fenêtre s'y ouvre)."})
                    return self._send(200, limits.primary_cli_connection(studio.cfg))
                if path == "/api/library/import-url":   # skill from any address: preview and review, then install
                    from .. import library
                    if self._remote():
                        return self._send(403, {"error": "À faire depuis le PC."})
                    return self._send(200, library.import_skill_url(studio, str(b.get("url", "")), bool(b.get("confirm"))))
                if path.startswith("/api/library/"):
                    from .. import library
                    if path.endswith("/install"):
                        value_map = b.get("values") if isinstance(b.get("values"), dict) else {}
                        if self._remote() and any(v for v in value_map.values() if isinstance(v, str)):
                            return self._send(403, {"error": "Une clé se saisit sur le PC."})
                        return self._send(200, library.install(studio, str(b.get("id", "")), value_map))
                    if path.endswith("/remove"):
                        return self._send(200, library.removed(studio, str(b.get("id", "")), str(b.get("type", ""))))
                    if path.endswith("/mcp-custom"):
                        if self._remote():
                            return self._send(403, {"error": "À faire depuis le PC."})
                        return self._send(200, library.add_custom_mcp(studio, str(b.get("name", "")), str(b.get("command", "")),
                                                                               str(b.get("arguments", "")), str(b.get("url", ""))))
                    return self._send(404, {"error": "unknown"})
                if path in ("/api/teams/role", "/api/teams/mcp"):   # project team: its own settings
                    from .. import teams
                    target = target_key(str(b.get("target", "")))
                    studio.registry.get(target)
                    if path.endswith("/role"):
                        return self._send(200, teams.configure_role(studio, target, str(b.get("role", "")),
                                                                   {k: b[k] for k in ("active", "model", "effort", "instructions", "ai") if k in b}))
                    return self._send(200, teams.configure_mcp(studio, target, b.get("names") if isinstance(b.get("names"), list) else None))
                if path == "/api/night/remove":
                    from .. import night
                    return self._send(200, night.removed(studio, str(b.get("id", ""))))
                if path == "/api/teams/common-role":
                    from ..teams import configure_common_role
                    return self._send(200, configure_common_role(studio, str(b.get("role", "")),
                                                               {k: b[k] for k in ("active", "instructions") if k in b}))
                if path == "/api/models":
                    return self._send(200, studio.set_model(b.get("role", ""), b.get("model", "")))
                if path == "/api/agents/optimize":        # one click: every trade back to Auto (rankings), global or one project
                    return self._send(200, studio.optimize(target_key(str(b["target"])) if b.get("target") else ""))
                if path == "/api/ai-role":                 # Gestion › Agents: any connected AI for this role
                    from .. import ai
                    out = studio.set_ai_role(str(b.get("role", "")), str(b.get("ai", "")))
                    return self._send(200, {**out, "warning": ai.local_warning(studio.paths.data, str(b.get("ai", "")))}
                                      if isinstance(out, dict) else out)
                if path == "/api/profile":
                    if self._remote() and b.get("target"):
                        return self._send(403, {"error": "À faire depuis le PC."})
                    if b.get("target"):                    # project-specific preset (empty = the home one)
                        return self._send(200, {"profile": studio.set_project_profile(target_key(str(b["target"])), str(b.get("profile", "")))})
                    return self._send(200, {"profile": studio.set_profile(str(b.get("profile", "")))})
                if path.startswith("/api/update/"):
                    from .. import updates
                    if self._remote():
                        return self._send(403, {"error": "À faire depuis le PC."})
                    if path.endswith("/verify"):
                        updates.check(force=True)
                        return self._send(200, updates.state())
                    if path.endswith("/install"):
                        return self._send(200, updates.install())
                    if path.endswith("/redemarrer"):
                        if ctl.jobs:
                            return self._send(409, {"error": "Un travail tourne encore : redémarre quand il est fini."})
                        updates.restart_later()
                        ctl.stop_request.set()
                        return self._send(202, {"ok": True})
                    return self._send(404, {"error": "unknown"})
                if path == "/api/agents/create":
                    from .. import agents
                    return self._send(200, agents.create_new(studio, b))
                if path in ("/api/connectors/add", "/api/connectors/remove"):
                    from .. import software_connectors
                    if self._remote():
                        return self._send(403, {"error": "À faire depuis le PC."})
                    l = (software_connectors.add_item(studio, str(b.get("name", "")), str(b.get("path_value", ""))) if path.endswith("add")
                         else software_connectors.removed(studio, str(b.get("id", ""))))
                    return self._send(200, {"connectors": l})
                if path == "/api/benchmarks/refresh":
                    from .. import agents
                    return self._send(200, agents.refresh(studio.paths.data, str(studio.cfg.get("benchmarks", {}).get("url", "")), force=True))
                if path.startswith("/api/ai/"):
                    from .. import ai
                    if self._remote():                 # a key can only be entered on the PC
                        return self._send(403, {"error": "À faire depuis le PC."})
                    try:
                        if path == "/api/ai/add":
                            return self._send(200, ai.add_item(studio.paths.data, str(b.get("provider", "")), str(b.get("key", "")),
                                                              str(b.get("model", "")), str(b.get("url", ""))))
                        if path == "/api/ai/models":
                            c = ai.connection(studio.paths.data, str(b.get("id", "")))
                            if not c:
                                return self._send(404, {"error": "Connexion inconnue."})
                            return self._send(200, {"models": ai.list_models(c)})
                        if path == "/api/ai/choose":
                            ai.modify(studio.paths.data, str(b.get("id", "")), **{k: b[k] for k in ("supervisor", "agents", "model") if k in b})
                            chosen = str(b.get("supervisor") or b.get("agents") or b.get("id") or "")
                            return self._send(200, {**ai.public(studio.paths.data), "warning": ai.local_warning(studio.paths.data, chosen)})
                        if path == "/api/ai/remove":
                            ai.removed(studio.paths.data, str(b.get("id", "")))
                            return self._send(200, ai.public(studio.paths.data))
                    except ai.AIError as e:
                        return self._send(400, {"error": str(e)})
                    return self._send(404, {"error": "unknown"})
                if path == "/api/packs/install":      # adds a pack (nothing existing is replaced)
                    from ..user_workspace import packs_state, install_pack, name
                    from ..orchestrator.roles import load_roles
                    created = install_pack(studio.paths.root, str(b.get("id", "")), name())
                    studio.roles = load_roles(studio.paths.roles)
                    return self._send(200, {"added": len(created), "packs": packs_state(studio.paths.root)})
                if path.startswith("/api/mobile/"):
                    from .. import mobile, settings
                    if self._remote():                 # pair, disconnect or revoke: only from the PC
                        return self._send(403, {"error": "À faire depuis le PC."})
                    if path == "/api/mobile/access":
                        yes = b.get("yes") is True
                        settings.modify(studio.cfg, studio.paths.config_file, "interface", "mobile_access", yes)
                        e = mobile.start_relay(port, studio.paths.logs) if yes else (mobile.stop_relay() or {"ok": True})
                        return self._send(200, {"ok": e["ok"], "info": e.get("info", "")})
                    if path == "/api/mobile/code":
                        return self._send(200, mobile.new_code(str(b.get("name", ""))))
                    if path == "/api/mobile/revoke":
                        mobile.revoke(studio.paths.data, str(b.get("id", "")))
                        return self._send(200, {"devices": mobile.public(studio.paths.data)})
                    return self._send(404, {"error": "unknown"})
                if path == "/api/settings":
                    from .. import settings
                    r = settings.modify(studio.cfg, studio.paths.config_file, str(b.get("section", "")),
                                          str(b.get("key", "")), b.get("value"))
                    if b.get("section") == "user":
                        from ..user_workspace import set_name
                        set_name(studio.cfg)
                    return self._send(200, r)
                if path == "/api/efforts":
                    return self._send(200, studio.set_effort(b.get("role", ""), b.get("effort", "")))
                if path == "/api/skills/conflict":         # proposed update: folder or studio version
                    from ..initial_import import settle
                    return self._send(200, settle(studio.paths.root, str(b.get("name", "")), str(b.get("choices", "")), studio.paths.data))
                if path == "/api/skills/import":       # « Reprendre mes skills »: copy what is missing, nothing overwritten
                    from ..initial_import import import_
                    if self._remote():
                        return self._send(403, {"error": "À faire depuis le PC."})
                    return self._send(200, import_(studio.paths.root, _home()))
                if path == "/api/skills/synchronize":
                    from ..agent_tools import signature_skills
                    from ..supervisor import sync_all
                    r = sync_all(studio, _home())
                    (studio.paths.data / "skills-signature.txt").write_text(signature_skills(studio.paths.root), encoding="utf-8")
                    return self._send(200, {"report": r})
                if path == "/api/window":            # window size, restored at next launch
                    e = {"fullscreen": bool(b.get("fullscreen")), "maximized": bool(b.get("maximized"))}
                    try:
                        prev = json.loads((studio.paths.data / "window.json").read_text(encoding="utf-8"))
                    except (OSError, ValueError):
                        prev = {}
                    for k in ("x", "y", "l", "h"):        # maximized or full screen: keep the last normal size
                        v = b.get(k) if not (e["fullscreen"] or e["maximized"]) else prev.get(k)
                        if isinstance(v, (int, float)) and -20000 < v < 20000:
                            e[k] = int(v)
                    (studio.paths.data / "window.json").write_text(json.dumps(e), encoding="utf-8")
                    return self._send(200, {"ok": True})
                if path == "/api/presence":
                    if b.get("end") is True and not self._remote():
                        ctl.leave()                     # window closed (a reload pings again right away)
                        return self._send(200, {"ok": True})
                    ctl.presence()
                    return self._send(200, {"ok": True, "jobs": ctl.jobs})
                if path == "/api/stop":
                    if self._remote():                 # from the phone it could not be reopened afterwards
                        return self._send(403, {"error": "Ferme le studio depuis le PC."})
                    if ctl.jobs and not b.get("after_jobs"):
                        return self._send(409, {"error": "une tâche tourne encore", "jobs": ctl.jobs})
                    ctl.stop_request.set()
                    return self._send(202, {"ok": True, "jobs": ctl.jobs})
                if path == "/api/git/action":           # fetch / pull --ff-only / push / PR: one user click = their consent
                    from .. import project_git
                    return self._send(202, project_git.launch(studio, jobs, b.get("target", ""), b.get("action", "")))
                if path == "/api/git/clean":         # all already-merged branches at once
                    from .. import project_git
                    return self._send(200, project_git.delete_merged(studio, b.get("target", "")))
                if path == "/api/git/commit":           # LOCAL commit of the files checked by the user (never a push)
                    from .. import project_git
                    c = b.get("target", "")
                    return self._send(200, git_single(c, project_git.do_commit, studio, c, list(b.get("files") or []), str(b.get("message", ""))))
                if path == "/api/git/merge":        # task branch → current branch, from the Branches tab
                    from .. import project_git
                    c, br = b.get("target", ""), str(b.get("branch", ""))
                    r = git_single(c, project_git.merge_branch, studio, c, br)
                    if br.startswith("studio/"):
                        following(br[len("studio/"):])
                    return self._send(200, r)
                if path == "/api/git/erase-branch":     # red branch (blocked, cancelled…): user's Delete click
                    from .. import project_git
                    return self._send(200, project_git.erase_branch(studio, b.get("target", ""), b.get("branch", "")))
                if path == "/api/git/delete-branch":   # only an already-merged branch (git branch -d)
                    from .. import project_git
                    return self._send(200, project_git.delete_branch(studio, b.get("target", ""), b.get("branch", "")))
                if path == "/api/audits":               # Gestion buttons: audit, then apply a finished audit
                    from .. import audits
                    tid = audits.launch(studio, b.get("target", ""), b.get("quoi", ""), b.get("mode", "audit"), b.get("since", ""))
                    background(execute, tid, tid=tid)
                    return self._send(201, {"tid": tid})
                if path == "/api/tasks":
                    opts = {k: b[k] for k in ("role", "executor", "model") if b.get(k)}
                    if b.get("title"):
                        opts["title"] = str(b["title"])[:70]
                    if b.get("mode") in ("fast", "max"):
                        opts["mode"] = b["mode"]
                    if b.get("effort") in studio.choice()["efforts"]:
                        opts["effort"] = b["effort"]
                    tid = studio.create(b["target"], b["request"], **opts)
                    background(execute, tid, tid=tid)
                    return self._send(201, {"tid": tid})
                if path == "/api/targets":
                    kind = "project" if b.get("kind") == "project" else "topic"
                    fields = {k: b[k] for k in ("path_value", "type", "description") if b.get(k)}
                    model = str(b.get("model", ""))
                    if model:
                        from .. import project_templates
                        if model not in project_templates.MODELS:
                            return self._send(400, {"error": "Modèle de projet inconnu."})
                        fields.setdefault("type", project_templates.MODELS[model]["type"])
                        if kind == "project" and fields.get("path_value") and not self._remote() and Path(fields["path_value"]).expanduser().is_absolute():
                            Path(fields["path_value"]).expanduser().mkdir(parents=True, exist_ok=True)   # new project: folder created if missing
                    t = studio.registry.add(kind, b["id"], b["name"], **fields)
                    if model:
                        project_templates.apply(studio, f"{t.kind}:{t.id}", model)
                    return self._send(201, t.to_public())
                if path == "/api/memory":
                    from ..memory import Provenance, Scope
                    text = (b.get("text") or "").strip()
                    if not text:
                        return self._send(400, {"error": "texte vide"})
                    r = studio.memory.remember(Scope.parse(b["scope"]), text, Provenance(tool="mel", agent="interface"))
                    return self._send(201, {"status": r.status, "shared": r.shared, "detail": r.detail})
                if path == "/api/files/reference":  # « référence » star set by the user on a file
                    from .. import task_files
                    tid, rel, target_r = str(b.get("tid", "")), str(b.get("path_value", "")), target_key(str(b.get("target", "")))
                    if not _TID.match(tid) or not task_files.permitted(studio, tid, rel):
                        return self._send(404, {"error": "fichier inconnu"})
                    return self._send(200, task_files.mark_reference(studio, target_r, tid, rel, bool(b.get("yes"))))
                if path == "/api/files/open":     # an agent-created file, or its folder, in the system file manager
                    import os
                    import sys
                    from .. import task_files
                    tid, rel = str(b.get("tid", "")), str(b.get("path_value", ""))
                    if not _TID.match(tid) or not task_files.permitted(studio, tid, rel):
                        return self._send(404, {"error": "fichier inconnu"})
                    f, _ = task_files.place(studio, tid, rel)
                    if f is None:
                        return self._send(404, {"error": "fichier introuvable"})
                    target_o = f.parent if b.get("folder") else f
                    from ..os_support import open_
                    open_(target_o)                  # system file manager: path checked
                    return self._send(200, {"ok": True})
                if path == "/api/open":
                    # Opens a studio document, a result folder or a backup in the associated system application
                    # (editor, file manager). Allowlist: nothing outside the studio.
                    import os
                    import sys
                    rel = b.get("path_value", "")
                    allowed = _doc_paths(root, studio)
                    if rel in allowed:
                        target = allowed[rel]
                    elif _TID.match(rel):
                        target = studio.run_dir(rel, create_new=False)
                    elif rel == "Skills" or rel in _FOLDER_KEYS or rel in {studio.paths.names[k] for k in _FOLDER_KEYS}:
                        target = root / (studio.paths.names[rel] if rel in _FOLDER_KEYS else rel)   # folder key or its localized name
                        target.mkdir(exist_ok=True)
                    elif re.fullmatch(r"test-restore-\d{8}T\d{6}Z", rel):
                        target = studio.paths.restores / rel
                    else:
                        return self._send(404, {"error": "emplacement non autorisé"})
                    if not target.exists():
                        return self._send(404, {"error": "missing"})
                    from ..os_support import open_
                    open_(target)                                  # allowlisted path
                    return self._send(200, {"open": str(target)})
                if path == "/api/backups":
                    from ..backup import create_backup
                    out = create_backup(studio.paths)
                    return self._send(201, {"name": out.name})
                m = re.match(r"^/api/backups/([^/]+)/(verify|test-restore)$", path)
                if m and _BACKUP.match(m.group(1)):
                    from ..backup import restore_to_test, verify_backup
                    f = studio.paths.backups / m.group(1)
                    if m.group(2) == "verify":
                        return self._send(200, verify_backup(f))
                    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
                    dest = studio.paths.restores / f"test-restore-{stamp}"
                    return self._send(200, {**restore_to_test(f, dest), "folder": str(dest)})
                if path == "/api/compile":
                    c = target_key(str(b.get("target", "")))
                    return self._send(202, exclusive(c, actions.run_compile, studio, jobs, c))
                if path == "/api/tools/tests":
                    return self._send(202, actions.run_tests(studio, jobs))
                if path == "/api/tools/update":
                    if ctl.jobs:                       # task, Supervisor reply, installation…: the tool is in use
                        raise RuntimeError("Un travail est en cours (tâche, réponse du Superviseur, installation) : "
                                           "attends qu'il finisse avant de mettre à jour.")
                    return self._send(202, actions.apply_update(studio, jobs, str(b.get("tool", ""))))
                if path == "/api/tools/install":
                    return self._send(202, actions.install(studio, jobs, str(b.get("quoi", ""))))
                if path == "/api/chains":
                    opts = {k: b.get(k) for k in ("model", "mode", "effort") if b.get(k)}
                    if opts.get("mode") not in (None, "fast", "max"):
                        opts.pop("mode")
                    if opts.get("effort") and opts["effort"] not in studio.choice()["efforts"]:
                        opts.pop("effort")
                    cid, tid = chains.create_new(studio, str(b.get("target", "")), str(b.get("title", "")), b.get("stages") or [], opts)
                    background(execute, tid, tid=tid)
                    return self._send(201, {"chain": cid, "tid": tid})
                m = re.match(r"^/api/chains/([A-Za-z0-9-]+)/(resume|stop|continue)$", path)
                if m:
                    if m.group(2) == "stop":
                        chains.halt(studio, m.group(1))
                        return self._send(200, {"ok": True})
                    if m.group(2) == "continue":
                        if update_in_progress():
                            raise RuntimeError(f"{update_in_progress()} : attends la fin de la mise à jour.")
                        tid = chains.proceed(studio, m.group(1))
                        if tid:
                            background(execute, tid, tid=tid)
                        return self._send(200, {"tid": tid or ""})
                    tid = chains.resume_run(studio, m.group(1))
                    background(execute, tid, tid=tid)
                    return self._send(201, {"tid": tid})
                m = re.match(r"^/api/targets/([^/]+)/remove$", path)
                if m:
                    c = target_key(unquote(m.group(1)))
                    t = studio.registry.get(c)
                    def remove_target():
                        open_tasks = [x for x in studio.store.list(1000) if target_key(x["target"]) == c and x["status"] not in TERMINAL]
                        if open_tasks:
                            raise RuntimeError(f"{len(open_tasks)} tâche(s) de « {t.name} » ne sont pas terminées : valide-les ou "
                                               "annule-les d'abord. Rien n'a été retiré.")
                        try:
                            dest = studio.registry.removed(c)
                        except PermissionError:
                            raise RuntimeError(f"Impossible de ranger la fiche de « {t.name} » : un de ses fichiers est sans doute "
                                               "ouvert (éditeur, Explorateur). Ferme-le et réessaie ; rien n'a été retiré.")
                        return {"ok": True, "message": f"« {t.name} » est retiré du studio. Sa fiche est rangée dans "
                                f"{dest.relative_to(studio.paths.root).as_posix()} ; rien n'a été supprimé."}
                    return self._send(200, exclusive(c, remove_target))
                m = re.match(r"^/api/workspaces/([^/]+)/remove$", path)
                if m and _TID.match(m.group(1)):
                    c = target_key(studio.store.get(m.group(1))["target"])
                    return self._send(200, exclusive(c, actions.remove_workspace, studio, m.group(1)))
                m = re.match(r"^/api/tasks/([^/]+)/undo$", path)
                if m and _TID.match(m.group(1)):       # « Annuler ce qui a été appliqué » (copy restored, or git revert)
                    c = target_key(studio.store.get(m.group(1))["target"])
                    return self._send(200, git_single(c, actions.cancel_apply, studio, m.group(1)))
                m = re.match(r"^/api/tasks/([^/]+)/merge$", path)
                if m and _TID.match(m.group(1)):
                    c = target_key(studio.store.get(m.group(1))["target"])
                    r = git_single(c, actions.merge, studio, m.group(1))
                    following(m.group(1))                 # chain: the next step starts from the merged work
                    return self._send(200, r)
                m = re.match(r"^/api/tasks/([^/]+)/(decision|cancel|resume|stop|copy|chatgpt)$", path)
                if m and _TID.match(m.group(1)):
                    tid, action = m.groups()
                    if action in ("copy", "chatgpt"):
                        return self._send(200, {"file": str(studio.export_copy_paste(tid))})
                    if action == "cancel":
                        studio.store.request_cancel(tid)
                        background(cancel_task, tid, tid=tid, free=True)
                    elif action == "stop":            # « Stop »: stops the agent, the task can be resumed
                        return self._send(200, studio.stop(tid))
                    elif action == "resume":
                        background(resume_task, tid, tid=tid)
                    else:
                        if b.get("decision") not in ("approve", "correct", "cancel", "remove"):
                            return self._send(400, {"error": "décision : approuver, corriger, annuler ou retirer"})
                        if b["decision"] == "approve" and not b.get("fingerprint"):
                            return self._send(400, {"error": "empreinte du résultat présenté requise"})
                        task_files = b.get("files") or []
                        if b["decision"] == "remove":
                            if not isinstance(task_files, list) or not task_files or not all(isinstance(f, str) for f in task_files):
                                return self._send(400, {"error": "fichiers à retirer : liste de chemins"})
                            if studio.store.get(tid)["status"] not in ("awaiting_approval", "awaiting_approval_with_defects"):
                                return self._send(409, {"error": "la tâche n'attend pas ta validation"})
                        background(decide_task, tid, b["decision"], b.get("fingerprint", ""), b.get("comment", ""), task_files,
                                   tid=tid, free=b["decision"] != "correct")   # fixing restarts work: it waits its turn
                    return self._send(202, {"ok": True})
                self._send(404, {"error": "missing"})
            except (KeyError, ValueError, FileExistsError, FileNotFoundError) as e:
                self._send(400, {"error": redact(str(e))[:800]})
            except RuntimeError as e:                # work already running, git refusal…: clear message, nothing done
                self._send(409, {"error": redact(str(e))[:600]})
            except Exception as e:                   # noqa: BLE001 — message without secrets, details in the studio state
                from ..memory import MemoryUnavailable
                if isinstance(e, MemoryUnavailable):
                    return self._send(503, {"error": f"MÉMOIRE EN PANNE — {e}"})
                self._send(500, {"error": type(e).__name__})

    if controller is not None:                             # studio launched for real (not a test): night queue
        from .. import night

        def skills_at_launch():                       # import the PC's skills (once), then copies for each subscription tool
            try:
                from ..initial_import import import_once
                r = import_once(studio.paths.root, studio.paths.data)
                if r and (r["skills"] or r["instructions"]):
                    studio.store.message("supervisor", "### Skills repris de ton PC\n" + (f"Skills copiés dans le studio : {', '.join(r['skills'])}.\n" if r["skills"] else "")
                                         + (f"Instructions générales copiées : {', '.join(r['instructions'])} ({studio.paths.imported_rules.relative_to(studio.paths.root).as_posix()}).\n" if r["instructions"] else "")
                                         + "\nTes dossiers d'origine ne sont pas modifiés : le studio gère maintenant ses copies. "
                                           "Tu peux supprimer les originaux toi-même si tu le souhaites.")
            except Exception as e:                       # noqa: BLE001
                print(f"[import] {type(e).__name__}: {redact(str(e))[:200]}", flush=True)
            try:
                from ..agent_tools import skills_up_to_date
                to_flag = [x for x in skills_up_to_date(studio.paths.root, studio.paths.data) if "ton dossier" in x]
                if to_flag:
                    studio.store.message("supervisor", "### Changements dans tes dossiers\n" + "\n".join(f"- {x}" for x in to_flag)
                                         + "\n\nRien n'est remplacé sans ton accord : choisis dans Gestion › Skills et documents.")
            except Exception as e:                       # noqa: BLE001
                print(f"[skills] {type(e).__name__}: {redact(str(e))[:200]}", flush=True)
        threading.Thread(target=skills_at_launch, daemon=True).start()

        def daily_cleanup():                            # catch-up at most once a day: reopening the studio restarts nothing
            from .. import cleanup
            try:
                cleanup.migrate_deliverables(studio)          # Livrables/ (before 0.4.18) moves into Sujets/
                cleanup.launch(studio)
            except Exception as e:                       # noqa: BLE001
                print(f"[menage] {type(e).__name__}", flush=True)
        threading.Thread(target=daily_cleanup, daemon=True).start()

        def watch_night():
            while not ctl.should_stop():
                try:
                    night.tick(studio, sup, lambda tid: background(execute, tid, tid=tid))
                except Exception as e:                   # noqa: BLE001 — retries the next minute
                    print(f"[nuit] {type(e).__name__}: {redact(str(e))[:200]}", flush=True)
                for _ in range(60):
                    if ctl.should_stop():
                        return
                    time.sleep(1)
        threading.Thread(target=watch_night, daemon=True).start()

        def watch_push():                               # task to validate or blocked → wake subscribed phones
            from .. import push
            while not ctl.should_stop():
                try:
                    push.tick(studio)
                except Exception as e:                   # noqa: BLE001
                    print(f"[push] {type(e).__name__}: {redact(str(e))[:200]}", flush=True)
                time.sleep(15)
        threading.Thread(target=watch_push, daemon=True).start()
    return H


class StudioServer(ThreadingHTTPServer):
    """A page closed mid-send (phone asleep, tab closed) is not an error: nothing in the log."""

    def handle_error(self, request, client_address):
        import sys
        if isinstance(sys.exc_info()[1], (ConnectionAbortedError, ConnectionResetError, BrokenPipeError, TimeoutError)):
            return
        super().handle_error(request, client_address)


def _reconcile_chain_messages(studio) -> None:
    """Rattrape les annonces restées actives avant un arrêt, sans créer de dossier de tâche."""
    from .. import actions
    pending_tasks = {message["proposal"].get("task") for message in studio.store.chain_merge_messages()}
    for tid in pending_tasks:
        if tid and (studio.details_dir(tid, create_new=False) / "merge.json").is_file():
            actions._complete_chain_messages(studio, tid)


def serve(studio=None, token: str | None = None, controller: Control | None = None, on_ready=None):
    from ..orchestrator.runner import Studio
    studio = studio or Studio()
    try:                                  # replies cut by the previous stop (« réfléchit… » forever): closed, said plainly
        for m in studio.store.messages(200):
            if m["author"] == "supervisor" and m["state"] == "running":
                studio.store.update_message(m["id"], state="cancelled", text="Réponse interrompue par l'arrêt du studio. "
                                            "Repose ta question si besoin.")
    except Exception:                     # noqa: BLE001 — never blocks the start
        pass
    try:
        _reconcile_chain_messages(studio)
    except Exception:                     # noqa: BLE001 — le rattrapage ne bloque jamais le démarrage
        pass
    host, port = studio.cfg["interface"]["host"], int(studio.cfg["interface"]["port"])
    ctl = controller or Control()
    httpd = StudioServer((host, port), make_handler(studio, port, token, ctl))
    httpd.daemon_threads = True

    def watcher():
        while not ctl.should_stop():
            time.sleep(2)
        httpd.shutdown()

    threading.Thread(target=watcher, daemon=True).start()
    print(f"Studio : http://{host}:{port}  (Ctrl+C pour arrêter)", flush=True)
    from .. import mobile

    def watch_benchmarks():                             # rankings: at most one update per day
        from .. import agents
        while not ctl.stop_request.is_set():
            agents.refresh(studio.paths.data, str(studio.cfg.get("benchmarks", {}).get("url", "")))
            try:                                         # Personnalisation page catalogue, published in the repo
                from .. import library, updates
                library.refresh_catalog(studio.paths.data, updates.repository())
            except Exception:                            # noqa: BLE001
                pass
            ctl.stop_request.wait(6 * 3600)
    threading.Thread(target=watch_benchmarks, daemon=True).start()

    def watch_updates():                           # at launch then daily; minor ones install themselves
        from .. import updates
        ctl.stop_request.wait(20)
        while not ctl.stop_request.is_set():
            updates.automatic()
            ctl.stop_request.wait(24 * 3600)
    if token is not None:
        threading.Thread(target=watch_updates, daemon=True).start()
    from .. import night as _night
    # phone access active, or tasks planned tonight: closing the window does not close the studio
    ctl.keep = lambda: mobile.relay_active() or bool(_night.read_file(studio.paths.data)["file"])
    if token is not None:                                # launcher: VPN relay if the user enabled it, monitored
        def watch_phone():                          # VPN down or relay dropped: reconnect (every 60 s)
            while not ctl.stop_request.is_set():
                if studio.cfg["interface"].get("mobile_access") and not mobile.relay_active():
                    mobile.start_relay(port, studio.paths.logs)
                ctl.stop_request.wait(60)
        threading.Thread(target=watch_phone, daemon=True).start()
    if on_ready:
        on_ready(host, port)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        ctl.stop_request.set()                                 # the phone watcher stops too
        mobile.stop_relay()                          # the relay stops with the studio
        httpd.server_close()
        studio.close()
