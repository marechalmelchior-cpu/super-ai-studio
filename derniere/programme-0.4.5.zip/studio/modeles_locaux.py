"""Modèles sur ton PC (Gestion › Benchmarks › « Installer ») : téléchargement par Ollama, avec progression.

- Seuls les modèles locaux du catalogue des benchmarks s'installent ici (nom vérifié), au clic de l'utilisateur.
- Ollama doit être installé et ouvert : le studio ne l'installe jamais lui-même (lien de téléchargement sinon).
- Le téléchargement passe par l'API locale d'Ollama (127.0.0.1:11434) ; rien d'autre n'est lancé.
"""
from __future__ import annotations

import json
import re
import threading
import urllib.request

OLLAMA = "http://127.0.0.1:11434"
TELECHARGER_OLLAMA = "https://ollama.com/download"
_NOM = re.compile(r"^[a-z0-9][a-z0-9._-]{0,80}(:[a-z0-9._-]{1,40})?$")
_en_cours: dict[str, dict] = {}
_verrou = threading.Lock()


def _get(chemin: str, delai: float = 2):
    with urllib.request.urlopen(OLLAMA + chemin, timeout=delai) as r:
        return json.loads(r.read() or b"{}")


def installes() -> list[str] | None:
    """Modèles déjà présents dans Ollama ; None si Ollama ne répond pas."""
    try:
        return sorted(m.get("name", "") for m in _get("/api/tags").get("models", []) if m.get("name"))
    except (OSError, ValueError):
        return None


def nom_ollama(m: dict) -> str:
    return str(m.get("ollama") or m.get("cle") or "")


def present(nom: str, liste: list[str]) -> bool:
    """« qwen3.6 » est présent si « qwen3.6:latest » ou « qwen3.6:27b » l'est."""
    base = nom if ":" in nom else nom + ":"
    return any(x == nom or x.startswith(base) for x in liste)


def etat(catalogue: list[dict]) -> dict:
    liste = installes()
    with _verrou:
        en_cours = {k: dict(v) for k, v in _en_cours.items()}
    modeles = {}
    for m in catalogue:
        n = nom_ollama(m)
        if m.get("local") and n:
            modeles[n] = {"installe": bool(liste) and present(n, liste), **({"progression": en_cours[n]} if n in en_cours else {})}
    return {"ollama": liste is not None, "telecharger": TELECHARGER_OLLAMA, "modeles": modeles}


def installer(nom: str, catalogue: list[dict], note=lambda m: None) -> dict:
    nom = (nom or "").strip().lower()
    if not _NOM.match(nom) or nom not in {nom_ollama(m) for m in catalogue if m.get("local")}:
        raise ValueError("Modèle inconnu du catalogue : rien n'est installé.")
    if installes() is None:
        raise ValueError(f"Ollama n'est pas ouvert sur le PC. Installe-le ({TELECHARGER_OLLAMA}), lance-le, puis réessaie.")
    with _verrou:
        if nom in _en_cours and _en_cours[nom].get("etat") == "telechargement":
            return {"ok": True, "deja": True}
        _en_cours[nom] = {"etat": "telechargement", "pct": 0, "message": "Démarrage…"}

    def tirer():
        try:
            req = urllib.request.Request(OLLAMA + "/api/pull", data=json.dumps({"model": nom, "stream": True}).encode(),
                                         headers={"Content-Type": "application/json"})
            with urllib.request.urlopen(req, timeout=300) as r:
                for ligne in r:
                    try:
                        d = json.loads(ligne)
                    except ValueError:
                        continue
                    if d.get("error"):
                        raise RuntimeError(str(d["error"])[:300])
                    with _verrou:
                        p = _en_cours[nom]
                        if d.get("total"):
                            p["pct"] = int(100 * (d.get("completed") or 0) / d["total"])
                        p["message"] = str(d.get("status", ""))[:80]
            with _verrou:
                _en_cours[nom] = {"etat": "fini", "pct": 100, "message": "Installé."}
            note(f"modèle local installé : {nom}")
        except Exception as e:                             # noqa: BLE001 — affiché à côté du modèle
            with _verrou:
                _en_cours[nom] = {"etat": "erreur", "pct": 0, "message": f"Échec : {str(e)[:200]}"}
    threading.Thread(target=tirer, daemon=True).start()
    return {"ok": True}
