"""Serveur MCP « studio-memoire » (stdio, bibliothèque standard uniquement).

Pourquoi : le client officiel @agentmemory/mcp retombe en silence sur une mémoire locale
quand un appel au serveur échoue (même avec AGENTMEMORY_FORCE_PROXY, vérifié dans son code),
et ses recherches ne filtrent pas par projet. Ce serveur expose la mémoire partagée via le
connecteur du studio : portée obligatoire en lecture et en écriture, erreurs visibles,
aucun repli local présenté comme partagé.

Lancement (configuré dans Claude Code et Codex) :
  <Studio>\\.venv\\Scripts\\python.exe -m studio.mcp_server     (PYTHONPATH=<Studio>, STUDIO_MCP_CLIENT=claude-code|codex)
"""
from __future__ import annotations

import json
import os
import sys
import traceback

from . import __version__
from .config import load_config
from .memory import MemoryUnavailable, Provenance, Scope, build_connector
from .paths import default_paths
from .security import SensitiveContentError, redact

PROTOCOLS = ("2025-11-25", "2025-06-18", "2025-03-26", "2024-11-05")
CLIENT = os.environ.get("STUDIO_MCP_CLIENT", "mcp")
PORTEE_DOC = "Portée : 'general', 'project:<id>', 'topic:<id>' ou 'task:<id>' (ex. 'project:mon-jeu')."

TOOLS = [
    {"name": "memoire_chercher",
     "description": "Cherche dans la mémoire partagée du studio, limitée aux portées demandées (+ général par défaut). " + PORTEE_DOC,
     "inputSchema": {"type": "object", "properties": {
         "requete": {"type": "string", "description": "Mots-clés (vide = tout lister)"},
         "portees": {"type": "array", "items": {"type": "string"}, "description": "Portées à lire"},
         "inclure_general": {"type": "boolean", "default": True},
         "limite": {"type": "integer", "default": 10}}, "required": ["portees"]}},
    {"name": "memoire_ajouter",
     "description": "Enregistre un fait durable dans UNE portée. Refuse les secrets. Indique clairement si l'écriture n'est PAS partagée (serveur en panne). " + PORTEE_DOC,
     "inputSchema": {"type": "object", "properties": {
         "texte": {"type": "string"}, "portee": {"type": "string"},
         "sujet": {"type": "string", "description": "Clé stable du sujet (permet de détecter les contradictions)"},
         "cle": {"type": "string", "description": "Clé d'idempotence (facultative)"}}, "required": ["texte", "portee"]}},
    {"name": "memoire_corriger",
     "description": "Corrige un souvenir (nouvelle version ; l'historique est conservé). " + PORTEE_DOC,
     "inputSchema": {"type": "object", "properties": {
         "portee": {"type": "string"}, "cle": {"type": "string"}, "texte": {"type": "string"}},
         "required": ["portee", "cle", "texte"]}},
    {"name": "memoire_conflits",
     "description": "Liste les contradictions d'une portée (à signaler à l'utilisateur, ne pas trancher seul). " + PORTEE_DOC,
     "inputSchema": {"type": "object", "properties": {"portee": {"type": "string"}}, "required": ["portee"]}},
    {"name": "memoire_etat", "description": "État de la mémoire partagée (OK / EN_PANNE / DEGRADE).",
     "inputSchema": {"type": "object", "properties": {}}},
]


class Server:
    def __init__(self, memory=None):
        if memory is None:
            paths = default_paths().ensure()
            memory = build_connector(load_config(paths.config_file), paths.data)
        self.mem = memory

    # ---------------------------------------------------------------- outils
    def call(self, name: str, a: dict) -> tuple[str, bool]:
        prov = Provenance(outil=CLIENT, agent="mcp")
        if name == "memoire_etat":
            h = self.mem.health()
            return json.dumps(h.to_dict(), ensure_ascii=False), h.etat == "EN_PANNE"
        if name == "memoire_chercher":
            scopes = [Scope.parse(x) for x in a.get("portees", [])]
            recs = self.mem.recall(a.get("requete", ""), scopes, bool(a.get("inclure_general", True)),
                                   int(a.get("limite", 10)))
            if not recs:
                return "Aucun souvenir dans ces portées.", False
            return "\n".join(f"- [{r.scope.label} | {r.status} | clé {r.key} | {r.provenance.outil} {r.created_at}] {r.content}"
                             for r in recs), False
        if name == "memoire_ajouter":
            r = self.mem.remember(Scope.parse(a["portee"]), a["texte"], prov, key=a.get("cle") or None,
                                  subject=a.get("sujet", ""))
            if not r.shared:
                return (f"NON PARTAGÉ : la mémoire centrale est en panne. Écriture conservée localement "
                        f"(clé {r.record.key}) et envoyée automatiquement au retour du serveur. "
                        "Ne pas considérer cette information comme connue de l'autre outil."), True
            extra = " ATTENTION : contradiction avec un souvenir existant du même sujet — à signaler à l'utilisateur." \
                if r.status == "conteste" else ""
            return f"{r.status} (portée {r.record.scope.label}, clé {r.record.key}).{extra}", False
        if name == "memoire_corriger":
            r = self.mem.correct(Scope.parse(a["portee"]), a["cle"], a["texte"], prov)
            return f"{r.status} : nouvelle version {r.record.key}", not r.shared
        if name == "memoire_conflits":
            c = self.mem.conflicts(Scope.parse(a["portee"]))
            if not c:
                return "Aucune contradiction.", False
            return "\n".join(f"Sujet {s} :\n" + "\n".join(f"  - clé {r.key} ({r.provenance.outil}) : {r.content}" for r in rs)
                             for s, rs in c.items()), False
        raise ValueError(f"Outil inconnu : {name}")

    # ------------------------------------------------------------- JSON-RPC
    def handle(self, msg: dict) -> dict | None:
        mid, method = msg.get("id"), msg.get("method")
        if method == "initialize":
            asked = (msg.get("params") or {}).get("protocolVersion")
            return {"jsonrpc": "2.0", "id": mid, "result": {
                "protocolVersion": asked if asked in PROTOCOLS else PROTOCOLS[-1],
                "capabilities": {"tools": {"listChanged": False}},
                "serverInfo": {"name": "studio-memoire", "version": __version__},
                "instructions": "Mémoire partagée du studio : toujours indiquer une portée. " + PORTEE_DOC}}
        if method == "ping":
            return {"jsonrpc": "2.0", "id": mid, "result": {}}
        if method == "tools/list":
            return {"jsonrpc": "2.0", "id": mid, "result": {"tools": TOOLS}}
        if method == "tools/call":
            p = msg.get("params") or {}
            try:
                text, is_err = self.call(p.get("name", ""), p.get("arguments") or {})
            except MemoryUnavailable as e:
                text, is_err = f"MÉMOIRE EN PANNE : {e}", True
            except SensitiveContentError as e:
                text, is_err = f"Refusé : {e}", True
            except (ValueError, KeyError, TypeError) as e:
                text, is_err = f"Erreur : {e}", True
            return {"jsonrpc": "2.0", "id": mid, "result": {"content": [{"type": "text", "text": redact(text)}],
                                                             "isError": is_err}}
        if mid is None:                       # notification (ex. notifications/initialized)
            return None
        return {"jsonrpc": "2.0", "id": mid, "error": {"code": -32601, "message": f"Méthode inconnue : {method}"}}


def main() -> int:
    for s in (sys.stdin, sys.stdout):
        try:
            s.reconfigure(encoding="utf-8")
        except (AttributeError, ValueError):
            pass
    try:
        server = Server()
    except Exception as e:                    # configuration illisible : on le dit et on s'arrête
        print(f"[studio-memoire] démarrage impossible : {e}", file=sys.stderr)
        return 1
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            msg = json.loads(line)
        except ValueError:
            continue
        try:
            out = server.handle(msg)
        except Exception:
            print("[studio-memoire] " + redact(traceback.format_exc())[-800:], file=sys.stderr)
            out = {"jsonrpc": "2.0", "id": msg.get("id"), "error": {"code": -32603, "message": "Erreur interne"}}
        if out is not None:
            sys.stdout.write(json.dumps(out, ensure_ascii=False) + "\n")
            sys.stdout.flush()
    return 0


if __name__ == "__main__":
    sys.exit(main())
