"""Interface locale du studio (http://127.0.0.1:8765), bibliothèque standard uniquement.

Sécurité :
- écoute 127.0.0.1 uniquement (refus au chargement de la configuration sinon) ;
- en-tête Host vérifié (anti « DNS rebinding ») ;
- les requêtes POST exigent l'en-tête ``X-Studio: 1`` (un site tiers ne peut pas l'ajouter) ;
- avec le lanceur (raccourci du bureau) : clé de session aléatoire à usage unique, échangée contre un
  cookie HttpOnly/SameSite=Strict ; sans ce cookie, rien n'est servi. La clé change à chaque démarrage.
Ne démarre que sur demande explicite (raccourci ou ``python -m studio interface``) ; aucun service permanent :
avec le lanceur, le serveur s'arrête seul quand plus aucune fenêtre n'est ouverte et qu'aucune tâche ne tourne.
"""
from __future__ import annotations

import hmac
import json
import re
import threading
import time
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

from ..orchestrator.store import TERMINAL
from ..security import redact

STATIC = Path(__file__).parent / "static"
_TID = re.compile(r"^T\d{8}-\d{6}-[0-9a-f]{6}$")
_BACKUP = re.compile(r"^studio-\d{8}T\d{6}Z\.(dpapi|zip)$")
COOKIE = "studio_session"


class Controle:
    """Présence des fenêtres, tâches lancées depuis l'interface, arrêt propre."""

    def __init__(self, delai_absence_s: float | None = None, grace_s: float = 120.0):
        self.delai_absence_s = delai_absence_s        # None = pas d'arrêt automatique (mode « interface » manuel)
        self.derniere_presence = time.monotonic() + grace_s
        self.travaux = 0
        self.arret = threading.Event()
        self._lock = threading.Lock()
        self.garder = lambda: False                   # vrai = rester ouvert sans fenêtre (accès téléphone actif)

    def presence(self):
        self.derniere_presence = max(self.derniere_presence, time.monotonic())

    def debut(self):
        with self._lock:
            self.travaux += 1

    def fin(self):
        with self._lock:
            self.travaux -= 1

    def doit_s_arreter(self) -> bool:
        if self.arret.is_set():
            return self.travaux == 0
        if self.delai_absence_s is None or self.garder():
            return False
        return self.travaux == 0 and time.monotonic() - self.derniere_presence > self.delai_absence_s


_GROUPES = [  # (groupe, motifs relatifs à la racine) — l'ordre est celui de l'affichage
    ("Suivi du studio", ["LISEZ-MOI.md", "JOURNAL.md", "Studio/docs/*.md", "Sauvegardes/RESTAURATION.md"]),
    ("Règles communes", ["Regles/*.md"]),
    ("Décisions validées", ["Studio/Decisions/*.md"]),
    ("Skills", ["Skills/README.md", "Skills/*/*.md"]),
    ("Projets", ["Projets/README.md", "Projets/*/*.md", "Projets/*/*.toml"]),
    ("Sujets", ["Sujets/README.md", "Sujets/*/*.md", "Sujets/*/*.toml"]),
    ("Rôles de l'équipe", ["Studio/roles/*.toml"]),
    ("Studio (technique)", ["Studio/README.md", "Studio/studio.config.toml", "Studio/adapters/*.md"]),
]


def _titre(p: Path) -> str:
    """Titre lisible : « name: » d'un SKILL.md, sinon premier titre Markdown, sinon « nom = » TOML, sinon le fichier."""
    try:
        head = p.read_text(encoding="utf-8", errors="replace").splitlines()[:40]
    except OSError:
        return p.name
    for l in head:
        if p.name == "SKILL.md" and l.startswith("name:"):
            return l.split(":", 1)[1].strip()
        if l.startswith("# "):
            return l[2:].strip()
        if p.suffix == ".toml" and l.startswith("nom ="):
            return l.split("=", 1)[1].strip().strip('"')
    return p.name


def _home() -> Path:
    return Path.home()


def _documents(root: Path, studio=None) -> list[dict]:
    """Documents rangés par groupe : ceux du studio (Markdown et réglages TOML, hors modèles et données), puis les skills
    installés (globaux Claude Code et Codex) et ceux des projets enregistrés. Lecture seule ; jamais d'autre fichier."""
    vus, out = set(), []

    def ajouter(groupe: str, fichiers_src: list[tuple[str, Path, str]]):
        fichiers = []
        for chemin, p, sous in fichiers_src:
            if p.is_file() and p not in vus:
                vus.add(p)
                fichiers.append({"chemin": chemin, "titre": _titre(p), "sous_groupe": sous, "_p": p})
        if fichiers:
            out.append({"groupe": groupe, "fichiers": fichiers})

    for groupe, motifs in _GROUPES:
        src = []
        for m in motifs:
            for p in sorted(root.glob(m)):
                if "_modele" in p.parts:
                    continue
                rel = p.relative_to(root).as_posix()
                parts = rel.split("/")
                src.append((rel, p, parts[1] if groupe in ("Projets", "Sujets") and len(parts) > 2 else ""))
        ajouter(groupe, src)
    home = _home()
    for groupe, base, cle in (("Skills installés — Claude Code (globaux)", home / ".claude" / "skills", "~claude"),
                              ("Skills installés — Codex (globaux)", home / ".codex" / "skills", "~codex")):
        if base.is_dir():
            ajouter(groupe, [(f"{cle}/{p.parent.name}/SKILL.md", p, "") for p in sorted(base.glob("*/SKILL.md"))])
    if studio is not None:
        for t in studio.registry.all():
            if t.kind == "project" and t.has_path and t.path().is_dir():
                base = t.path() / ".claude" / "skills"
                ajouter(f"Skills du projet {t.nom}",
                        [(f"projet:{t.id}/.claude/skills/{p.parent.name}/SKILL.md", p, "") for p in sorted(base.glob("*/SKILL.md"))]
                        + [(f"projet:{t.id}/.claude/agents/{p.name}", p, "agents") for p in sorted((t.path() / ".claude" / "agents").glob("*.md"))])
    return out


def _public(groupes: list[dict]) -> list[dict]:
    return [{"groupe": g["groupe"], "fichiers": [{k: v for k, v in f.items() if k != "_p"} for f in g["fichiers"]]} for g in groupes]


def _doc_paths(root: Path, studio=None) -> dict[str, Path]:
    return {f["chemin"]: f["_p"] for g in _documents(root, studio) for f in g["fichiers"]}


def _page_association(message: str = "") -> bytes:
    """Page montrée à un téléphone pas encore associé : il tape le code à 6 chiffres affiché sur le PC."""
    import html
    m = f"<p style='color:#b42318'>{html.escape(message)}</p>" if message else ""
    return ("<!doctype html><html lang=fr><meta charset=utf-8><meta name=viewport content='width=device-width,initial-scale=1'>"
            "<meta name=theme-color content='#0f1115'><title>Super AI Agent Pro Station Max 2000</title>"
            "<body style='font:17px system-ui;margin:0;padding:32px 20px;background:#0f1115;color:#e8eaed'>"
            "<img src='/icone-192.png' alt='' width=64 height=64 style='border-radius:14px'>"
            "<h1 style='font-size:21px'>Associer ce téléphone</h1>"
            "<p style='color:#9aa0a6'>Sur le PC : Superviseur › Réglages › Téléphone › « Associer un téléphone ». "
            "Tape ici le code affiché.</p>" + m +
            "<form method=post action='/associer' style='display:flex;gap:10px;margin-top:18px'>"
            "<input name=code inputmode=numeric autocomplete=one-time-code pattern='[0-9 ]*' maxlength=7 required autofocus "
            "placeholder='123456' style='flex:1;min-width:0;width:100%;box-sizing:border-box;font:24px ui-monospace,monospace;letter-spacing:4px;padding:12px;"
            "border-radius:10px;border:1px solid #3c4043;background:#1b1e24;color:inherit'>"
            "<button style='font:600 17px system-ui;padding:0 20px;border:0;border-radius:10px;background:#8ab4f8;"
            "color:#0f1115'>OK</button></form></body></html>").encode()


def make_handler(studio, port: int, token: str | None = None, controle: Controle | None = None):
    allowed_hosts = {f"127.0.0.1:{port}", f"localhost:{port}"}
    # Exécutions depuis l'interface : jusqu'à N tâches en parallèle (limites.taches_simultanees), une seule par projet.
    paralleles = threading.BoundedSemaphore(max(1, int(studio.cfg["limites"].get("taches_simultanees", 1))))
    verrous: dict[str, threading.Lock] = {}
    verrous_garde = threading.Lock()
    ctl = controle or Controle()
    from .. import actions, chaines
    travaux = actions.Travaux(ctl)
    root = studio.paths.root
    from ..superviseur import Superviseur
    sup = getattr(studio, "superviseur", None) or Superviseur(studio)
    studio.superviseur = sup

    def cle_cible(target: str) -> str:
        try:
            t = studio.registry.get(target)
            return f"{t.kind}:{t.id}"
        except (KeyError, ValueError):
            return target

    def equipe(t, cle: str, act: list[dict]) -> list[dict]:
        """Tous les rôles pour cette cible : adaptés d'abord ; ce que chacun fait ici ou ailleurs."""
        types = {t.type, "topic"} if t.kind == "topic" else {t.type}
        modeles = studio.modeles()
        out = []
        for r in studio.roles.values():
            ici = [a for a in act if a["role"] == r.id and cle_cible(a["target"]) == cle]
            ailleurs = [{**a, "cible": cle_cible(a["target"])} for a in act
                        if a["role"] == r.id and a["etat"] == "travaille" and cle_cible(a["target"]) != cle]
            etat = ("travaille" if any(a["etat"] == "travaille" for a in ici) else "attend_mel" if any(a["etat"] == "attend_mel" for a in ici)
                    else "en_pause" if ici else "ailleurs" if ailleurs else "libre")
            out.append({"id": r.id, "nom": r.nom, "outil": r.executeur, "modele": modeles.get(r.id, ""),
                        "adapte": r.id == "auditeur" or bool(types & set(r.domaines)), "etat": etat,
                        "ici": ici, "ailleurs": ailleurs})
        ordre = {"travaille": 0, "attend_mel": 1, "en_pause": 2, "ailleurs": 3, "libre": 4}
        return sorted(out, key=lambda x: (ordre[x["etat"]], not x["adapte"], x["id"] == "auditeur", x["nom"]))   # qui travaille d'abord

    def projets(act: list[dict] | None = None) -> list[dict]:
        taches = studio.store.list(1000)
        act = studio.activite() if act is None else act
        out = []
        for t in studio.registry.all():
            cle = f"{t.kind}:{t.id}"
            mes = [x for x in taches if cle_cible(x["target"]) == cle]
            cpt = {"a_valider": 0, "en_cours": 0, "terminees": 0}
            for x in mes:
                s = x["status"]
                cpt["a_valider" if s.startswith("a_approuver") else "terminees" if s in TERMINAL else "en_cours"] += 1
            au_travail = sorted({studio.roles[a["role"]].nom for a in act if a["etat"] == "travaille"
                                 and cle_cible(a["target"]) == cle and a["role"] in studio.roles})
            out.append({**t.to_public(), "cle": cle, "dossier": str(t.path()) if t.has_path else "", "compteurs": cpt,
                        "derniere": mes[0] if mes else None, "au_travail": au_travail, "cree": str(t.extra.get("cree", ""))})
        return sorted(out, key=lambda p: p["cree"], reverse=True)          # tri stable : sans date, ordre d'origine

    def avec_action(taches: list[dict]) -> list[dict]:
        """Tâches qui tournent : dernière action de l'agent, en clair (« Modifie EnemyBase.cpp »), pour la carte de la liste."""
        from .. import activite
        for x in taches:
            if x["status"] in ("creee", "en_cours") and x.get("etape_nom") in ("execution", "audit", "verification"):
                try:
                    a = activite.actions(studio.details_dir(x["id"], creer=False), 1)
                    x["derniere_action"] = a[0]["texte"] if a else ""
                except Exception:                 # noqa: BLE001 — facultatif
                    pass
        return taches

    def resume_usage() -> dict:
        """Usage lisible : par outil (Claude, Codex), aujourd'hui, sur les 5 dernières heures (fenêtre des abonnements)
        et sur 7 jours ; en appels, en temps de travail, en jetons et, pour Claude, en coût équivalent API (estimation
        de Claude Code : le travail est compris dans l'abonnement). Seuls les appels lancés par le studio sont comptés."""
        from datetime import timedelta
        maintenant = datetime.now()
        jour = maintenant.strftime("%Y-%m-%d")
        il_y_a_5h = (maintenant - timedelta(hours=5)).isoformat(timespec="seconds")
        semaine = (maintenant - timedelta(days=6)).strftime("%Y-%m-%d")
        appels = studio.store.appels(semaine)
        noms = {f"{t.kind}:{t.id}": t.nom for t in studio.registry.all()}

        def total(lot):
            return {"appels": len(lot), "duree_s": round(sum(x["duree_s"] or 0 for x in lot)),
                    "entree": sum(x["jetons_entree"] or 0 for x in lot), "cache": sum(x["jetons_cache"] or 0 for x in lot),
                    "sortie": sum(x["jetons_sortie"] or 0 for x in lot),
                    "cout_usd": round(sum(x["cout_usd"] or 0 for x in lot), 2), "echecs": sum(1 for x in lot if not x["ok"])}
        familles = {}
        for fam in ("Claude", "Codex"):
            a = [x for x in appels if x["famille"] == fam]
            familles[fam] = {"jour": total([x for x in a if x["day"] == jour]),
                             "fenetre": total([x for x in a if x["at"] >= il_y_a_5h]), "semaine": total(a)}
        du_jour = [x for x in appels if x["day"] == jour]
        par = lambda cle: sorted(({"nom": k, **total([x for x in du_jour if cle(x) == k])}       # noqa: E731
                                  for k in {cle(x) for x in du_jour}), key=lambda d: -d["duree_s"])
        jours = []
        for i in range(6, -1, -1):
            d = (maintenant - timedelta(days=i)).strftime("%Y-%m-%d")
            jours.append({"jour": d, **{fam: total([x for x in appels if x["day"] == d and x["famille"] == fam])
                                        for fam in ("Claude", "Codex")}})
        anciens = [x for x in studio.store.usage(30) if x["day"] >= semaine]     # compteurs d'avant le journal détaillé
        return {"familles": familles, "jours": jours,
                "par_usage": par(lambda x: x["usage"]),
                "par_projet": par(lambda x: noms.get(x["cible"] or "", x["cible"] or "toutes les conversations")),
                "derniers": [{"heure": x["at"][11:16], "famille": x["famille"], "usage": x["usage"],
                              "projet": noms.get(x["cible"] or "", x["cible"] or ""), "role": x["role"], "modele": x["modele"],
                              "duree_s": round(x["duree_s"] or 0), "entree": x["jetons_entree"], "cache": x["jetons_cache"],
                              "sortie": x["jetons_sortie"], "ok": bool(x["ok"])} for x in appels[:15]],
                "debut_journal": (appels[-1]["day"] if appels else jour),
                "anciens_compteurs": [x for x in anciens if not any(a["day"] == x["day"] for a in appels)],
                "seuils": studio.cfg.get("usage", {})}

    def verrou(cle: str) -> threading.Lock:
        with verrous_garde:
            return verrous.setdefault(cle, threading.Lock())

    def git_seul(cle: str, fn, *args):
        """Commit ou fusion sur le dossier principal : possible même pendant qu'une tâche travaille dans SA copie (git
        protège ses propres fichiers) ; deux opérations git du même projet ne se chevauchent jamais."""
        v = verrou("git:" + cle)
        if not v.acquire(timeout=120):
            raise RuntimeError("Une autre opération git est en cours sur ce projet : réessaie dans un instant.")
        try:
            return fn(*args)
        finally:
            v.release()

    def exclusif(cle: str, fn, *args):
        """Action immédiate sur un projet (fusion, retrait, compilation) : refusée si le projet est déjà occupé."""
        v = verrou(cle)
        if not v.acquire(blocking=False):
            raise RuntimeError("Ce projet est occupé (une tâche, une fusion ou un retrait est en cours) : réessaie dans un instant.")
        try:
            return fn(*args)
        finally:
            v.release()

    def maj_en_cours() -> str:
        return next((j["titre"] for k, j in travaux.etat().items() if k.startswith("maj:") and j.get("etat") == "en_cours"), "")

    def suivant(tid: str) -> None:
        """Après une décision, une annulation, une reprise ou une fusion : lance l'étape suivante d'une chaîne si tout
        est prêt. Pendant une mise à jour de Claude Code ou Codex, rien ne part : « Continuer » après."""
        if maj_en_cours():
            cid = (studio.store.get(tid).get("options") or {}).get("chaine")
            if cid:
                studio.store.maj_chaine(cid, note=f"{maj_en_cours()} : clique « Continuer » une fois terminée.")
            return
        try:
            nouveau = chaines.avancer(studio, tid)
        except Exception as e:                   # noqa: BLE001 — visible dans le journal de la tâche
            studio.store.event(tid, f"Chaîne : étape suivante non lancée ({type(e).__name__})")
            return
        if nouveau:
            background(executer, nouveau, tid=nouveau)

    def executer(tid: str):
        """Exécute une tâche ; si elle se termine seule (compte rendu sans fichier), la chaîne continue."""
        r = studio.run(tid)
        apres_execution(tid)
        return r

    def apres_execution(tid: str) -> None:
        """Après un passage de l'équipe : fusion automatique (mode autonome), étape suivante d'une chaîne, bilan."""
        t = studio.store.get(tid)
        if t["status"] in ("approuvee", "appliquee"):
            if studio.autonome() and studio._infos_branche(tid, t).get("worktree") and not (studio.run_dir(tid) / "rien-a-appliquer.json").exists():
                try:                                  # mode autonome : fusion locale (jamais de push), refusée proprement sinon
                    f = actions.fusionner(studio, tid)
                    studio.store.event(tid, f"Fusion automatique : {f['message']}")
                    compiler_apres_fusion(tid, t)
                except Exception as e:                # noqa: BLE001 — dépôt modifié, conflit… : le bouton reste
                    studio.store.event(tid, f"Fusion automatique non faite : {str(e)[:300]} — bouton « Fusionner » disponible")
            suivant(tid)
        bilan_apres(tid)

    def compiler_apres_fusion(tid: str, t: dict) -> None:
        """Le C++ d'un projet Unreal vient d'être fusionné : ferme l'éditeur proprement, compile le vrai projet, le rouvre
        (avant l'étape suivante d'une chaîne, qui peut alors utiliser les nouveaux champs). Jamais de fermeture forcée."""
        from .. import unreal
        try:
            cible = studio.registry.get(t["target"])
            up = unreal.projet_unreal(cible.path()) if cible.has_path else None
            diffs = sorted(studio.details_dir(tid, creer=False).glob("diff-*.patch"), key=lambda p: int(re.sub(r"\D", "", p.stem) or 0))
            cpp = bool(diffs) and re.search(r"^\+\+\+ b/Source/|^diff --git a/Source/", diffs[-1].read_text(encoding="utf-8", errors="replace"), re.M)
            if not up or not cpp:
                return
            r = unreal.compiler(up, studio.cfg, lambda m: studio.store.event(tid, m), rouvrir=up,
                                journal=studio.details_dir(tid) / "build-apres-fusion.log")
            studio.store.event(tid, f"Compilation après fusion : {r['message']}" + (" — " + " | ".join(r.get("erreurs", [])[:3]) if r["code"] == 2 else ""))
        except Exception as e:                        # noqa: BLE001 — jamais bloquant : le bouton « Compiler » reste
            studio.store.event(tid, f"Compilation après fusion non faite : {str(e)[:300]}")

    def bilan_apres(tid: str) -> None:
        """Quand l'équipe a fini (faite, à valider, en échec) : le Superviseur fait un court bilan dans la conversation."""
        t = studio.store.get(tid)
        if t["status"] in ("creee", "en_cours", "en_attente_creneau", "interrompue", "annulee"):
            return
        if not bool(studio.cfg.get("superviseur", {}).get("bilan", True)):
            return
        threading.Thread(target=sup.bilan, args=(tid,), daemon=True).start()

    def decider(tid: str, decision: str, empreinte: str, commentaire: str):
        r = studio.decide(tid, decision, empreinte, commentaire)
        if decision == "corriger":                    # l'équipe a refait le travail : même suite qu'une exécution
            apres_execution(tid)
        else:
            suivant(tid)
        return r

    def annuler(tid: str):
        r = studio.cancel(tid)
        suivant(tid)
        return r

    def reprendre_tache(tid: str):
        r = studio.resume(tid)
        apres_execution(tid)
        return r

    def background(fn, *args, tid: str = "", libre: bool = False):
        """libre=True : annulation ou validation (courtes), jamais en attente derrière une autre tâche du projet."""
        if not libre and maj_en_cours():          # l'outil est en train d'être remplacé : aucun travail ne part
            raise RuntimeError(f"{maj_en_cours()} : attends la fin de la mise à jour, puis relance.")
        cible = ""
        if tid:
            try:
                cible = cle_cible(studio.store.get(tid)["target"])
            except KeyError:
                pass

        def run():
            try:
                if libre:
                    fn(*args)
                else:
                    with verrou(cible or "_"), paralleles:   # une tâche à la fois par projet, N au total
                        fn(*args)
            except Exception as e:                  # l'état est déjà enregistré par le studio
                if tid:
                    studio.store.event(tid, f"Erreur interface : {type(e).__name__}")
            finally:
                ctl.fin()
        ctl.debut()
        threading.Thread(target=run, daemon=True).start()

    class H(BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def _send(self, code: int, obj=None, ctype="application/json", raw: bytes | None = None, extra=()):
            data = raw if raw is not None else json.dumps(obj, ensure_ascii=False, default=str).encode()
            self.send_response(code)
            self.send_header("Content-Type", ctype if ctype.startswith(("font/", "image/")) else f"{ctype}; charset=utf-8")   # pas de charset sur du binaire
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("X-Frame-Options", "DENY")
            self.send_header("Referrer-Policy", "no-referrer")
            self.send_header("Content-Security-Policy",
                             "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self'; frame-ancestors 'none'")
            for k, v in extra:
                self.send_header(k, v)
            self.end_headers()
            self.wfile.write(data)

        def _distant(self) -> bool:
            """Requête arrivée par le relais Tailscale (téléphone) plutôt que depuis ce PC."""
            from .. import mobile
            return mobile.hote_autorise(self.headers.get("Host") or "")

        def _ok_host(self) -> bool:
            if self.headers.get("Host") not in allowed_hosts and not self._distant():
                self._send(403, {"erreur": "hôte refusé"})
                return False
            return True

        def _cookie(self, nom: str = COOKIE) -> str:
            for part in (self.headers.get("Cookie") or "").split(";"):
                k, _, v = part.strip().partition("=")
                if k == nom:
                    return v
            return ""

        def _ok_appareil(self, path: str) -> bool:
            """Téléphone : clé d'appareil exigée (cookie), sinon page d'association (code à 6 chiffres)."""
            from .. import mobile
            if mobile.verifier(studio.paths.data, self._cookie(mobile.COOKIE_APPAREIL)):
                return True
            if path in ("/", "/index.html"):
                self._send(200, ctype="text/html", raw=_page_association())
            else:
                self._send(403, {"erreur": "Téléphone non associé."})
            return False

        def _associer_appareil(self):
            from .. import mobile
            n = int(self.headers.get("Content-Length", 0) or 0)
            champs = parse_qs(self.rfile.read(min(n, 2000)).decode("utf-8", "replace"))
            cle = mobile.utiliser_code(studio.paths.data, (champs.get("code") or [""])[0])
            if not cle:
                return self._send(403, ctype="text/html", raw=_page_association("Code incorrect ou expiré. Demande un nouveau "
                                                                                 "code sur le PC."))
            self.send_response(303)
            self.send_header("Set-Cookie", f"{mobile.COOKIE_APPAREIL}={cle}; HttpOnly; Secure; SameSite=Lax; Path=/; "
                                           "Max-Age=31536000")
            self.send_header("Location", "/")
            self.send_header("Content-Length", "0")
            self.send_header("Cache-Control", "no-store")
            self.end_headers()

        def _ok_session(self, path: str, query: dict) -> bool:
            """Sans lanceur (token None) : protections locales seules. Avec lanceur : cookie de session exigé.
            Par le relais Tailscale (téléphone) : clé d'appareil exigée dans tous les cas."""
            if self._distant():
                return self._ok_appareil(path)
            if token is None:
                return True
            if hmac.compare_digest(self._cookie(), token):
                return True
            given = (query.get("t") or [""])[0]
            if path == "/" and given and hmac.compare_digest(given, token):
                # Échange de la clé contre un cookie, puis adresse nettoyée (la clé ne reste pas dans la barre d'adresse).
                self.send_response(303)
                self.send_header("Set-Cookie", f"{COOKIE}={token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=31536000")
                self.send_header("Location", "/")
                self.send_header("Content-Length", "0")
                self.send_header("Cache-Control", "no-store")
                self.send_header("Referrer-Policy", "no-referrer")
                self.end_headers()
                return False
            page = ("<!doctype html><meta charset=utf-8><title>Super AI Agent Pro Station Max 2000</title><body style='font:16px system-ui;"
                    "padding:40px'><h1>Super AI Agent Pro Station Max 2000</h1><p>Session non reconnue. Ouvre le studio avec le raccourci "
                    "« Super AI Agent Pro Station Max 2000 » du bureau.</p>").encode()
            self._send(403, ctype="text/html", raw=page)
            return False

        def _body(self) -> dict:
            n = int(self.headers.get("Content-Length", 0) or 0)
            return json.loads(self.rfile.read(n) or b"{}") if n < 1_000_000 else {}

        # ------------------------------------------------------------------ GET
        def do_GET(self):
            if not self._ok_host():
                return
            u = urlparse(self.path)
            path, query = u.path, parse_qs(u.query)
            if path == "/api/ping":                     # sans donnée : permet au lanceur de détecter une instance ouverte
                return self._send(200, {"studio": True})
            m_police = re.fullmatch(r"/fonts/([a-z0-9-]+\.woff2)", path)
            if m_police and (STATIC / "fonts" / m_police.group(1)).is_file():     # polices locales (OFL), jamais de CDN
                return self._send(200, ctype="font/woff2", raw=(STATIC / "fonts" / m_police.group(1)).read_bytes())
            if path == "/favicon.ico":
                ico = STATIC / "logo-boom-2000.ico"
                return self._send(200, ctype="image/x-icon", raw=(ico if ico.is_file() else STATIC / "station-max-2000.ico").read_bytes())
            if path in ("/logo-entete.png", "/logo-boom-2000.png"):          # logo du studio (public, comme le favicon)
                return self._send(200, ctype="image/png", raw=(STATIC / path.lstrip("/")).read_bytes())
            if path in ("/icone-192.png", "/icone-512.png"):                   # icônes de l'application (téléphone)
                return self._send(200, ctype="image/png", raw=(STATIC / path.lstrip("/")).read_bytes())
            if path == "/manifest.webmanifest":                               # installer le studio sur le téléphone
                return self._send(200, ctype="application/manifest+json", raw=(STATIC / "manifest.webmanifest").read_bytes())
            if path == "/sw.js":
                return self._send(200, ctype="text/javascript", raw=(STATIC / "sw.js").read_bytes(), extra=(("Service-Worker-Allowed", "/"),))
            if not self._ok_session(path, query):
                return
            try:
                if path in ("/", "/index.html"):
                    return self._send(200, ctype="text/html", raw=(STATIC / "index.html").read_bytes())
                if path == "/app.js":
                    return self._send(200, ctype="text/javascript", raw=(STATIC / "app.js").read_bytes())
                if path == "/api/session":
                    from .. import mobile
                    from ..espace import nom as espace_nom
                    return self._send(200, {"lanceur": token is not None, "arret_auto": ctl.delai_absence_s is not None,
                                            "travaux": ctl.travaux, "distant": self._distant(), "nom": espace_nom(),
                                            "reste_ouvert": mobile.relais_actif()})
                if path == "/api/etat":
                    from ..health import check_all
                    return self._send(200, check_all(studio, probe_tools=True))
                if path == "/api/cibles":
                    return self._send(200, [t.to_public() for t in studio.registry.all()])
                if path == "/api/organisation":
                    return self._send(200, studio.organisation())
                if path == "/api/conversation":
                    # chaque conversation est séparée : l'accueil n'affiche que les siens, un projet que les siens
                    projet = (query.get("projet") or [""])[0]
                    msgs = [m for m in studio.store.messages(400) if (m["proposition"].get("projet") or "") == projet
                            and not m["proposition"].get("retire")][-80:]
                    from ..superviseur import noms_lisibles
                    for m in msgs:                    # anciennes réponses comprises : jamais d'identifiant de tâche à l'écran
                        if m["auteur"] != "mel":
                            m["texte"] = noms_lisibles(studio, m["texte"])
                    return self._send(200, msgs)
                if path == "/api/piece":
                    rel = (query.get("chemin") or [""])[0]
                    base = studio.paths.pieces.resolve()
                    if rel.startswith("Runs/pieces/"):          # messages d'avant le rangement (maj75)
                        rel = studio.paths.pieces.relative_to(studio.paths.root).as_posix() + "/" + rel[len("Runs/pieces/"):]
                    f = (studio.paths.root / rel).resolve()
                    types = {".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".gif": "image/gif", ".webp": "image/webp"}
                    if base not in f.parents or not f.is_file() or f.suffix.lower() not in types:
                        return self._send(404, {"erreur": "introuvable"})
                    return self._send(200, ctype=types[f.suffix.lower()], raw=f.read_bytes())
                if path == "/api/usage":
                    return self._send(200, resume_usage())
                if path == "/api/audits":               # dernier audit skills / mémoires par projet (Gestion)
                    from .. import audits
                    return self._send(200, audits.derniers(studio))
                if path == "/api/mobile":               # carte « Téléphone » : Tailscale, relais, appareils associés
                    from .. import mobile
                    return self._send(200, {"reglage": bool(studio.cfg["interface"].get("acces_mobile")),
                                            "tailscale": mobile.etat_tailscale(), **mobile.etat_relais(),
                                            "adresse": mobile.hote_distant(), "code": mobile.code_en_cours(),
                                            "appareils": mobile.public(studio.paths.data), "distant": self._distant()})
                if path == "/api/ia":                   # connexions aux IA (jamais les clés)
                    from .. import ia
                    from ..connectors.base import find_exe
                    from ..connectors.claude_code import WIN_CANDIDATES
                    qui, c = ia.choix(studio, "superviseur")
                    return self._send(200, {**ia.public(studio.paths.data), "locales": ia.detecter_locales(),
                                            "claude": bool(find_exe(studio.cfg["outils"].get("claude", "claude"), WIN_CANDIDATES)),
                                            "codex": bool(find_exe(studio.cfg["outils"].get("codex", "codex"))),
                                            "actif": qui, "distant": self._distant()})
                if path == "/api/agents/catalogue":     # créer un agent : domaines, rôles, IA connectées, recommandations
                    from .. import agents
                    cat = agents.catalogue()
                    return self._send(200, {**cat, "sources": agents.sources_connectees(studio),
                                            "recommandations": {c: agents.recommander(studio, c)
                                                                for c in ("texte", "code", "image", "video", "voix")}})
                if path == "/api/benchmarks":
                    from .. import agents
                    return self._send(200, {**agents.benchmarks(studio.paths.data),
                                            "connectes": sorted({s["fournisseur"] for s in agents.sources_connectees(studio)})})
                if path == "/api/mise-a-jour":
                    from .. import mise_a_jour
                    mise_a_jour.verifier()
                    return self._send(200, mise_a_jour.etat())
                if path == "/api/connecteurs":
                    from .. import connecteurs
                    return self._send(200, {"connecteurs": connecteurs.lister(studio), "suggestions": connecteurs.SUGGESTIONS})
                if path == "/api/packs":                # packs de skills et rôles (socle toujours là)
                    from ..espace import etat_packs
                    return self._send(200, etat_packs(studio.paths.root))
                if path == "/api/reglages":             # réglages du studio modifiables depuis Gestion (liste fermée)
                    from .. import reglages
                    return self._send(200, reglages.liste(studio.cfg))
                if path == "/api/limites":              # limites des abonnements en % (lecture seule, Claude en cache 60 s)
                    from .. import limites
                    return self._send(200, limites.limites(studio.cfg))
                if path == "/api/alertes":
                    # Alerte quand, au rythme actuel, la limite de l'abonnement (mêmes % que /usage) sera atteinte
                    # dans moins du seuil réglé (par défaut 1 h). Pas d'alerte si les limites sont indisponibles.
                    from .. import limites
                    u = studio.cfg.get("usage", {})
                    seuils = {"Claude": u.get("alerte_claude_5h_min", 60), "Codex": u.get("alerte_codex_5h_min", 60)}
                    return self._send(200, limites.alertes(limites.limites(studio.cfg), seuils))
                if path == "/api/choix":
                    return self._send(200, {**studio.choix(), "profil": studio.profil()})
                if path == "/api/outils/versions":
                    return self._send(200, actions.versions(studio))
                if path == "/api/outils/installes":
                    return self._send(200, actions.installes())
                if path == "/api/travaux":
                    return self._send(200, travaux.etat())
                if path == "/api/git":                  # état git de chaque projet (onglet Git et GitHub, page projet)
                    from .. import git_projets
                    return self._send(200, git_projets.liste(studio))
                if path.startswith("/api/git/") and path.endswith("/a-commiter"):    # fichiers à commiter, cases cochées
                    from .. import git_projets
                    try:
                        return self._send(200, git_projets.a_commiter(studio, unquote(path[len("/api/git/"):-len("/a-commiter")])))
                    except ValueError as e:
                        return self._send(404, {"erreur": str(e)})
                if path.startswith("/api/git/"):
                    from .. import git_projets
                    try:
                        return self._send(200, git_projets.detail(studio, unquote(path[len("/api/git/"):])))
                    except ValueError as e:
                        return self._send(404, {"erreur": str(e)})
                if path == "/api/espaces":
                    return self._send(200, actions.espaces(studio))
                if path == "/api/projets":
                    return self._send(200, projets())
                if path.startswith("/api/projets/"):
                    cle = unquote(path[len("/api/projets/"):])
                    act = studio.activite()
                    p = next((x for x in projets(act) if x["cle"] == cle), None)
                    if p is None:
                        return self._send(404, {"erreur": "projet inconnu"})
                    p["equipe"] = equipe(studio.registry.get(cle), cle, act)
                    p["compilable"] = bool(studio.registry.get(cle).extra.get("build"))
                    base = studio.paths.projects if p["kind"] == "project" else studio.paths.topics
                    ctx = base / p["id"] / "CONTEXTE.md"
                    taches = avec_action([x for x in studio.store.list(1000) if cle_cible(x["target"]) == cle])
                    return self._send(200, {**p, "taches": taches, "profil": studio.profils_projets().get(cle, ""),
                                            "profil_accueil": studio.profil(),
                                            "contexte": ctx.read_text(encoding="utf-8", errors="replace") if ctx.exists() else "",
                                            "contexte_chemin": ctx.relative_to(root).as_posix() if ctx.exists() else ""})
                if path == "/api/taches":
                    return self._send(200, avec_action(studio.store.list()))
                if path == "/api/memoire":
                    return self._memoire_get(query)
                if path == "/api/sauvegardes":
                    files = sorted((p for p in studio.paths.backups.glob("studio-*") if _BACKUP.match(p.name)), reverse=True)
                    return self._send(200, [{"nom": p.name, "octets": p.stat().st_size,
                                             "date": datetime.fromtimestamp(p.stat().st_mtime, timezone.utc).isoformat()}
                                            for p in files[:50]])
                if path == "/api/documents":
                    return self._send(200, _public(_documents(root, studio)))
                if path == "/api/document":
                    rel = (query.get("chemin") or [""])[0]
                    allowed = _doc_paths(root, studio)
                    if rel not in allowed:
                        return self._send(404, {"erreur": "document inconnu"})
                    return self._send(200, {"chemin": rel, "texte": allowed[rel].read_text(encoding="utf-8", errors="replace")[:400_000]})
                m = re.match(r"^/api/taches/([^/]+)/activite$", path)
                if m and _TID.match(m.group(1)):       # en direct : ce que fait l'agent, fichiers touchés, applications
                    from .. import activite, unreal
                    from ..orchestrator.processes import processes
                    tid = m.group(1)
                    t = studio.store.get(tid)
                    details = studio.details_dir(tid, creer=False)
                    travail = studio.run_dir(tid, creer=False) / "copie-de-travail"
                    actif = t["status"] in ("creee", "en_cours", "en_attente_creneau")
                    out = {"actions": activite.actions(details), "fichiers": activite.fichiers(travail, details, studio.cfg["outils"].get("git", "git")),
                           "applications": []}
                    if actif:
                        try:
                            c = studio.registry.get(t["target"])
                            ue = c.has_path and (c.extra.get("type") == "unreal" or bool(unreal.projet_unreal(c.path())))
                        except KeyError:
                            ue = False
                        pids = [p["pid"] for p in processes(studio.store, tid) if p["status"] == "en_cours" and p["pid"]]
                        out["applications"] = activite.applications(pids, ue)
                    return self._send(200, out)
                if path == "/api/fichiers":            # onglet Fichiers : ce que les agents ont créé pour ce projet
                    from .. import fichiers
                    return self._send(200, fichiers.liste(studio, cle_cible((query.get("cible") or [""])[0])))
                if path == "/api/fichiers/voir":
                    from .. import fichiers
                    tid, rel = (query.get("tid") or [""])[0], (query.get("chemin") or [""])[0]
                    if not _TID.match(tid) or not fichiers.autorise(studio, tid, rel):
                        return self._send(404, {"erreur": "fichier inconnu"})
                    f, _ = fichiers.emplacement(studio, tid, rel)
                    if f is None:
                        return self._send(404, {"erreur": "fichier introuvable (copie retirée ?)"})
                    ext = f.suffix.lower()
                    if ext in fichiers.IMAGES and f.stat().st_size <= fichiers.MAX_IMAGE:
                        return self._send(200, raw=f.read_bytes(), ctype=fichiers.IMAGES[ext])
                    if ext in (".md", ".txt", ".csv", ".json") and f.stat().st_size <= fichiers.MAX_TEXTE:
                        return self._send(200, raw=f.read_bytes(), ctype="text/plain")
                    return self._send(415, {"erreur": "aperçu impossible : ouvre-le avec « Ouvrir »"})
                m = re.match(r"^/api/taches/([^/]+)/captures(?:/([A-Za-z0-9._ -]{1,120}))?$", path)
                if m and _TID.match(m.group(1)):       # images enregistrées par l'agent dans Taches/<tâche>/captures
                    dossier = studio.run_dir(m.group(1), creer=False) / "captures"
                    types = {".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".webp": "image/webp", ".gif": "image/gif"}
                    if not m.group(2):
                        noms = sorted(p.name for p in dossier.glob("*") if p.is_file() and p.suffix.lower() in types) if dossier.is_dir() else []
                        return self._send(200, noms[:60])
                    f = dossier / unquote(m.group(2))
                    if f.parent != dossier or f.suffix.lower() not in types or not f.is_file() or f.stat().st_size > 40_000_000:
                        return self._send(404, {"erreur": "capture inconnue"})
                    return self._send(200, raw=f.read_bytes(), ctype=types[f.suffix.lower()])
                m = re.match(r"^/api/taches/([^/]+)(?:/(resultat|diff|processus))?$", path)
                if m and _TID.match(m.group(1)):
                    tid, what = m.group(1), m.group(2)
                    if what == "resultat":
                        f = studio.run_dir(tid, creer=False) / "RESULTAT.md"
                        b = studio.run_dir(tid, creer=False) / "BRANCHE.md"
                        texte = (b.read_text(encoding="utf-8") + "\n\n---\n\n" if b.exists() else "") \
                            + (f.read_text(encoding="utf-8") if f.exists() else "")
                        return self._send(200, {"texte": texte})
                    if what == "diff":
                        diffs = sorted(studio.details_dir(tid, creer=False).glob("diff-*.patch"),
                                       key=lambda p: int(re.sub(r"\D", "", p.stem) or 0))
                        return self._send(200, {"texte": diffs[-1].read_text(encoding="utf-8")[:200_000] if diffs else ""})
                    if what == "processus":
                        from ..orchestrator.processes import processes
                        return self._send(200, processes(studio.store, tid))
                    st_ = studio.status(tid)
                    cid = (studio.store.get(tid).get("options") or {}).get("chaine")
                    if cid:
                        st_["chaine"] = chaines.resume(studio, cid)
                    return self._send(200, st_)
                if path == "/api/chaines":
                    cible = (query.get("cible") or [""])[0]
                    return self._send(200, [chaines.resume(studio, c["id"]) for c in studio.store.chaines(cle_cible(cible) if cible else "")])
                self._send(404, {"erreur": "introuvable"})
            except KeyError as e:
                self._send(404, {"erreur": str(e)})

        def _memoire_get(self, query: dict):
            from ..memory import MemoryUnavailable, Scope
            portees = [Scope.parse(x) for x in query.get("portee", []) if x]
            q = (query.get("q") or [""])[0]
            try:
                recs = studio.memory.recall(q, portees, include_general=True, limit=100)
                return self._send(200, {"etat": "OK", "souvenirs": [r.to_dict() for r in recs],
                                        "en_attente": studio.memory.pending_count()})
            except MemoryUnavailable as e:
                return self._send(503, {"erreur": f"MÉMOIRE EN PANNE — {e}"})

        def _recevoir_piece(self, q: dict):
            """Fichier glissé ou collé dans la fenêtre Demande → Studio/data/pieces-jointes/<lot>/<chemin relatif>. 50 Mo max par fichier."""
            lot = (q.get("lot") or [""])[0]
            rel = (q.get("rel") or q.get("nom") or [""])[0].replace("\\", "/")
            n = int(self.headers.get("Content-Length", 0) or 0)
            if not re.fullmatch(r"[A-Za-z0-9_-]{6,64}", lot) or not rel or n <= 0:
                return self._send(400, {"erreur": "pièce invalide"})
            if n > 50 * 1024 * 1024:
                return self._send(413, {"erreur": "fichier trop gros (50 Mo maximum)"})
            parts = [re.sub(r'[<>:"|?*\x00-\x1f]', "_", p).strip(" .") for p in rel.split("/") if p not in ("", ".", "..")]
            if not parts or not all(parts):
                return self._send(400, {"erreur": "nom de fichier invalide"})
            base = (studio.paths.pieces / lot).resolve()
            dest = base.joinpath(*parts).resolve()
            if base not in dest.parents:
                return self._send(400, {"erreur": "chemin refusé"})
            if sum(1 for _ in base.rglob("*")) > 500 if base.exists() else False:
                return self._send(413, {"erreur": "trop de fichiers dans ce message"})
            data = self.rfile.read(n)
            dest.parent.mkdir(parents=True, exist_ok=True)
            if dest.exists():                           # jamais d'écrasement : suffixe
                dest = dest.with_name(f"{dest.stem}-{int(time.time() * 1000) % 100000}{dest.suffix}")
            dest.write_bytes(data)
            return self._send(201, {"chemin": dest.relative_to(studio.paths.root).as_posix(), "octets": len(data)})

        # ------------------------------------------------------------------ POST
        def do_POST(self):
            if not self._ok_host():
                return
            u = urlparse(self.path)
            path = u.path
            if path == "/associer" and self._distant():   # formulaire de la page d'association (téléphone)
                return self._associer_appareil()
            if self.headers.get("X-Studio") != "1":
                return self._send(403, {"erreur": "en-tête X-Studio manquant"})
            if not self._ok_session(path, {}):
                return
            if path == "/api/pieces":
                return self._recevoir_piece(parse_qs(u.query))
            b = self._body()
            try:
                if path == "/api/conversation":
                    lot, projet = str(b.get("lot", "")), str(b.get("projet", ""))
                    choix = studio.choix()
                    modele_sup = str(b.get("modele", "")) if b.get("modele") in choix["modeles"] else ""
                    effort_sup = str(b.get("effort", "")) if b.get("effort") in choix["efforts"] else ""
                    sup.retenir_choix(modele_sup, effort_sup)
                    mid, rid = sup.demander(b.get("texte", ""), lot, projet)
                    texte = b.get("texte", "")

                    def repondre():
                        try:
                            sup.repondre(texte, rid, lot, projet, modele_sup, effort_sup)
                        finally:
                            ctl.fin()
                    ctl.debut()
                    threading.Thread(target=repondre, daemon=True).start()
                    return self._send(202, {"id": mid, "reponse": rid})
                m = re.match(r"^/api/conversation/(\d+)/(arreter|modifier)$", path)
                if m:                                   # Mel arrête une réponse, ou reprend son dernier message pour le corriger
                    return self._send(200, sup.arreter(int(m.group(1))) if m.group(2) == "arreter" else sup.modifier(int(m.group(1))))
                m = re.match(r"^/api/conversation/(\d+)/(lancer|ignorer)$", path)
                if m:
                    rid = int(m.group(1))
                    if m.group(2) == "ignorer":
                        sup.ignorer(rid)
                        return self._send(200, {"ok": True})
                    tid = sup.lancer(rid, b.get("cible", ""), b.get("demande", ""), b.get("modele", ""),
                                     b.get("mode", "") if b.get("mode") in ("rapide", "max") else "",
                                     b.get("effort", "") if b.get("effort") in studio.choix()["efforts"] else "")
                    background(executer, tid, tid=tid)
                    return self._send(201, {"tid": tid})
                if path == "/api/modeles":
                    return self._send(200, studio.set_modele(b.get("role", ""), b.get("modele", "")))
                if path == "/api/profil":
                    if b.get("cible"):                    # préréglage propre à un projet (vide = celui de l'accueil)
                        return self._send(200, {"profil": studio.set_profil_projet(cle_cible(str(b["cible"])), str(b.get("profil", "")))})
                    return self._send(200, {"profil": studio.set_profil(str(b.get("profil", "")))})
                if path.startswith("/api/mise-a-jour/"):
                    from .. import mise_a_jour
                    if self._distant():
                        return self._send(403, {"erreur": "À faire depuis le PC."})
                    if path.endswith("/verifier"):
                        mise_a_jour.verifier(force=True)
                        return self._send(200, mise_a_jour.etat())
                    if path.endswith("/installer"):
                        return self._send(200, mise_a_jour.installer())
                    if path.endswith("/redemarrer"):
                        if ctl.travaux:
                            return self._send(409, {"erreur": "Un travail tourne encore : redémarre quand il est fini."})
                        mise_a_jour.redemarrer_plus_tard()
                        ctl.arret.set()
                        return self._send(202, {"ok": True})
                    return self._send(404, {"erreur": "inconnu"})
                if path == "/api/agents/creer":
                    from .. import agents
                    return self._send(200, agents.creer(studio, b))
                if path in ("/api/connecteurs/ajouter", "/api/connecteurs/retirer"):
                    from .. import connecteurs
                    if self._distant():
                        return self._send(403, {"erreur": "À faire depuis le PC."})
                    l = (connecteurs.ajouter(studio, str(b.get("nom", "")), str(b.get("chemin", ""))) if path.endswith("ajouter")
                         else connecteurs.retirer(studio, str(b.get("id", ""))))
                    return self._send(200, {"connecteurs": l})
                if path == "/api/benchmarks/actualiser":
                    from .. import agents
                    return self._send(200, agents.actualiser(studio.paths.data, str(studio.cfg.get("benchmarks", {}).get("url", "")), force=True))
                if path.startswith("/api/ia/"):
                    from .. import ia
                    if self._distant():                 # une clé ne se saisit que sur le PC
                        return self._send(403, {"erreur": "À faire depuis le PC."})
                    try:
                        if path == "/api/ia/ajouter":
                            return self._send(200, ia.ajouter(studio.paths.data, str(b.get("fournisseur", "")), str(b.get("cle", "")),
                                                              str(b.get("modele", "")), str(b.get("url", ""))))
                        if path == "/api/ia/modeles":
                            c = ia.connexion(studio.paths.data, str(b.get("id", "")))
                            if not c:
                                return self._send(404, {"erreur": "Connexion inconnue."})
                            return self._send(200, {"modeles": ia.lister_modeles(c)})
                        if path == "/api/ia/choisir":
                            ia.modifier(studio.paths.data, str(b.get("id", "")), **{k: b[k] for k in ("superviseur", "agents", "modele") if k in b})
                            return self._send(200, ia.public(studio.paths.data))
                        if path == "/api/ia/retirer":
                            ia.retirer(studio.paths.data, str(b.get("id", "")))
                            return self._send(200, ia.public(studio.paths.data))
                    except ia.ErreurIA as e:
                        return self._send(400, {"erreur": str(e)})
                    return self._send(404, {"erreur": "inconnu"})
                if path == "/api/packs/installer":      # ajoute un pack (rien d'existant n'est remplacé)
                    from ..espace import etat_packs, installer_pack, nom
                    from ..orchestrator.roles import load_roles
                    crees = installer_pack(studio.paths.root, str(b.get("id", "")), nom())
                    studio.roles = load_roles(studio.paths.roles)
                    return self._send(200, {"ajoutes": len(crees), "packs": etat_packs(studio.paths.root)})
                if path.startswith("/api/mobile/"):
                    from .. import mobile, reglages
                    if self._distant():                 # associer, couper ou révoquer : seulement depuis le PC
                        return self._send(403, {"erreur": "À faire depuis le PC."})
                    if path == "/api/mobile/acces":
                        oui = b.get("oui") is True
                        reglages.modifier(studio.cfg, studio.paths.config_file, "interface", "acces_mobile", oui)
                        e = mobile.demarrer_relais(port, studio.paths.journaux) if oui else (mobile.couper_relais() or {"ok": True})
                        return self._send(200, {"ok": e["ok"], "info": e.get("info", "")})
                    if path == "/api/mobile/code":
                        return self._send(200, mobile.nouveau_code(str(b.get("nom", ""))))
                    if path == "/api/mobile/revoquer":
                        mobile.revoquer(studio.paths.data, str(b.get("id", "")))
                        return self._send(200, {"appareils": mobile.public(studio.paths.data)})
                    return self._send(404, {"erreur": "inconnu"})
                if path == "/api/reglages":
                    from .. import reglages
                    r = reglages.modifier(studio.cfg, studio.paths.config_file, str(b.get("section", "")),
                                          str(b.get("cle", "")), b.get("valeur"))
                    if b.get("section") == "utilisateur":
                        from ..espace import definir_nom
                        definir_nom(studio.cfg)
                    return self._send(200, r)
                if path == "/api/efforts":
                    return self._send(200, studio.set_effort(b.get("role", ""), b.get("effort", "")))
                if path == "/api/skills/synchroniser":
                    from ..superviseur import synchroniser_tout
                    return self._send(200, {"rapport": synchroniser_tout(studio, _home())})
                if path == "/api/fenetre":            # taille de la fenêtre, reprise au prochain lancement
                    e = {"plein_ecran": bool(b.get("plein_ecran")), "agrandie": bool(b.get("agrandie"))}
                    try:
                        anc = json.loads((studio.paths.data / "fenetre.json").read_text(encoding="utf-8"))
                    except (OSError, ValueError):
                        anc = {}
                    for k in ("x", "y", "l", "h"):        # agrandie ou plein écran : on garde la dernière taille normale
                        v = b.get(k) if not (e["plein_ecran"] or e["agrandie"]) else anc.get(k)
                        if isinstance(v, (int, float)) and -20000 < v < 20000:
                            e[k] = int(v)
                    (studio.paths.data / "fenetre.json").write_text(json.dumps(e), encoding="utf-8")
                    return self._send(200, {"ok": True})
                if path == "/api/presence":
                    ctl.presence()
                    return self._send(200, {"ok": True, "travaux": ctl.travaux})
                if path == "/api/arreter":
                    if self._distant():                 # depuis le téléphone, impossible de le rouvrir ensuite
                        return self._send(403, {"erreur": "Ferme le studio depuis le PC."})
                    if ctl.travaux and not b.get("apres_travaux"):
                        return self._send(409, {"erreur": "une tâche tourne encore", "travaux": ctl.travaux})
                    ctl.arret.set()
                    return self._send(202, {"ok": True, "travaux": ctl.travaux})
                if path == "/api/git/action":           # fetch / pull --ff-only / push / PR : un clic de Mel = son accord
                    from .. import git_projets
                    return self._send(202, git_projets.lancer(studio, travaux, b.get("cible", ""), b.get("action", "")))
                if path == "/api/git/nettoyer":         # toutes les branches déjà fusionnées, d'un coup
                    from .. import git_projets
                    return self._send(200, git_projets.supprimer_fusionnees(studio, b.get("cible", "")))
                if path == "/api/git/commit":           # commit LOCAL des fichiers cochés par Mel (jamais de push)
                    from .. import git_projets
                    c = b.get("cible", "")
                    return self._send(200, git_seul(c, git_projets.commiter, studio, c, list(b.get("fichiers") or []), str(b.get("message", ""))))
                if path == "/api/git/fusionner":        # branche de tâche → branche courante, depuis l'onglet Branches
                    from .. import git_projets
                    c, br = b.get("cible", ""), str(b.get("branche", ""))
                    r = git_seul(c, git_projets.fusionner_branche, studio, c, br)
                    if br.startswith("studio/"):
                        suivant(br[len("studio/"):])
                    return self._send(200, r)
                if path == "/api/git/effacer-branche":     # branche rouge (bloquée, annulée…) : clic Delete de Mel
                    from .. import git_projets
                    return self._send(200, git_projets.effacer_branche(studio, b.get("cible", ""), b.get("branche", "")))
                if path == "/api/git/supprimer-branche":   # seulement une branche déjà fusionnée (git branch -d)
                    from .. import git_projets
                    return self._send(200, git_projets.supprimer_branche(studio, b.get("cible", ""), b.get("branche", "")))
                if path == "/api/audits":               # boutons de Gestion : auditer, puis appliquer un audit fini
                    from .. import audits
                    tid = audits.lancer(studio, b.get("cible", ""), b.get("quoi", ""), b.get("mode", "audit"), b.get("depuis", ""))
                    background(executer, tid, tid=tid)
                    return self._send(201, {"tid": tid})
                if path == "/api/taches":
                    opts = {k: b[k] for k in ("role", "executeur", "modele") if b.get(k)}
                    if b.get("titre"):
                        opts["titre"] = str(b["titre"])[:70]
                    if b.get("mode") in ("rapide", "max"):
                        opts["mode"] = b["mode"]
                    if b.get("effort") in studio.choix()["efforts"]:
                        opts["effort"] = b["effort"]
                    tid = studio.create(b["cible"], b["demande"], **opts)
                    background(executer, tid, tid=tid)
                    return self._send(201, {"tid": tid})
                if path == "/api/cibles":
                    kind = "project" if b.get("kind") == "project" else "topic"
                    fields = {k: b[k] for k in ("chemin", "type", "description") if b.get(k)}
                    return self._send(201, studio.registry.add(kind, b["id"], b["nom"], **fields).to_public())
                if path == "/api/memoire":
                    from ..memory import Provenance, Scope
                    texte = (b.get("texte") or "").strip()
                    if not texte:
                        return self._send(400, {"erreur": "texte vide"})
                    r = studio.memory.remember(Scope.parse(b["portee"]), texte, Provenance(outil="mel", agent="interface"))
                    return self._send(201, {"statut": r.status, "partage": r.shared, "detail": r.detail})
                if path == "/api/fichiers/reference":  # étoile « référence » posée par Mel sur un fichier
                    from .. import fichiers
                    tid, rel, cible_r = str(b.get("tid", "")), str(b.get("chemin", "")), cle_cible(str(b.get("cible", "")))
                    if not _TID.match(tid) or not fichiers.autorise(studio, tid, rel):
                        return self._send(404, {"erreur": "fichier inconnu"})
                    return self._send(200, fichiers.marquer_reference(studio, cible_r, tid, rel, bool(b.get("oui"))))
                if path == "/api/fichiers/ouvrir":     # un fichier créé par un agent, ou son dossier, dans Windows
                    import os
                    import sys
                    from .. import fichiers
                    tid, rel = str(b.get("tid", "")), str(b.get("chemin", ""))
                    if not _TID.match(tid) or not fichiers.autorise(studio, tid, rel):
                        return self._send(404, {"erreur": "fichier inconnu"})
                    f, _ = fichiers.emplacement(studio, tid, rel)
                    if f is None:
                        return self._send(404, {"erreur": "fichier introuvable"})
                    cible_o = f.parent if b.get("dossier") else f
                    if sys.platform == "win32":
                        os.startfile(str(cible_o))  # noqa: S606 — fichier relevé pour une tâche, chemin vérifié
                    return self._send(200, {"ok": True})
                if path == "/api/ouvrir":
                    # Ouvre un document du studio, un dossier de résultat ou une sauvegarde dans l'application Windows
                    # associée (éditeur, Explorateur). Liste blanche : rien en dehors du studio.
                    import os
                    import sys
                    rel = b.get("chemin", "")
                    allowed = _doc_paths(root, studio)
                    if rel in allowed:
                        target = allowed[rel]
                    elif _TID.match(rel):
                        target = studio.run_dir(rel, creer=False)
                    elif rel in ("Sauvegardes", "Taches", "Archives", "Livrables", "Skills", "Regles", "Projets", "Sujets"):
                        target = root / rel
                        target.mkdir(exist_ok=True)
                    elif re.fullmatch(r"restauration-test-\d{8}T\d{6}Z", rel):
                        target = studio.paths.restaurations / rel
                    else:
                        return self._send(404, {"erreur": "emplacement non autorisé"})
                    if not target.exists():
                        return self._send(404, {"erreur": "introuvable"})
                    if sys.platform != "win32":
                        return self._send(501, {"erreur": "ouverture disponible sous Windows uniquement"})
                    os.startfile(str(target))                       # noqa: S606 — chemin de la liste blanche
                    return self._send(200, {"ouvert": str(target)})
                if path == "/api/sauvegardes":
                    from ..backup import create_backup
                    out = create_backup(studio.paths)
                    return self._send(201, {"nom": out.name})
                m = re.match(r"^/api/sauvegardes/([^/]+)/(verifier|restaurer-test)$", path)
                if m and _BACKUP.match(m.group(1)):
                    from ..backup import restore_to_test, verify_backup
                    f = studio.paths.backups / m.group(1)
                    if m.group(2) == "verifier":
                        return self._send(200, verify_backup(f))
                    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
                    dest = studio.paths.restaurations / f"restauration-test-{stamp}"
                    return self._send(200, {**restore_to_test(f, dest), "dossier": str(dest)})
                if path == "/api/compiler":
                    c = cle_cible(str(b.get("cible", "")))
                    return self._send(202, exclusif(c, actions.compiler, studio, travaux, c))
                if path == "/api/outils/tests":
                    return self._send(202, actions.lancer_tests(studio, travaux))
                if path == "/api/outils/mettre-a-jour":
                    if ctl.travaux:                       # tâche, réponse du Superviseur, installation… : l'outil sert
                        raise RuntimeError("Un travail est en cours (tâche, réponse du Superviseur, installation) : "
                                           "attends qu'il finisse avant de mettre à jour.")
                    return self._send(202, actions.mettre_a_jour(studio, travaux, str(b.get("outil", ""))))
                if path == "/api/outils/installer":
                    return self._send(202, actions.installer(studio, travaux, str(b.get("quoi", ""))))
                if path == "/api/chaines":
                    opts = {k: b.get(k) for k in ("modele", "mode", "effort") if b.get(k)}
                    if opts.get("mode") not in (None, "rapide", "max"):
                        opts.pop("mode")
                    if opts.get("effort") and opts["effort"] not in studio.choix()["efforts"]:
                        opts.pop("effort")
                    cid, tid = chaines.creer(studio, str(b.get("cible", "")), str(b.get("titre", "")), b.get("etapes") or [], opts)
                    background(executer, tid, tid=tid)
                    return self._send(201, {"chaine": cid, "tid": tid})
                m = re.match(r"^/api/chaines/([A-Za-z0-9-]+)/(reprendre|arreter|continuer)$", path)
                if m:
                    if m.group(2) == "arreter":
                        chaines.arreter(studio, m.group(1))
                        return self._send(200, {"ok": True})
                    if m.group(2) == "continuer":
                        if maj_en_cours():
                            raise RuntimeError(f"{maj_en_cours()} : attends la fin de la mise à jour.")
                        tid = chaines.continuer(studio, m.group(1))
                        if tid:
                            background(executer, tid, tid=tid)
                        return self._send(200, {"tid": tid or ""})
                    tid = chaines.reprendre(studio, m.group(1))
                    background(executer, tid, tid=tid)
                    return self._send(201, {"tid": tid})
                m = re.match(r"^/api/cibles/([^/]+)/retirer$", path)
                if m:
                    c = cle_cible(unquote(m.group(1)))
                    t = studio.registry.get(c)
                    def retirer_cible():
                        ouvertes = [x for x in studio.store.list(1000) if cle_cible(x["target"]) == c and x["status"] not in TERMINAL]
                        if ouvertes:
                            raise RuntimeError(f"{len(ouvertes)} tâche(s) de « {t.nom} » ne sont pas terminées : valide-les ou "
                                               "annule-les d'abord. Rien n'a été retiré.")
                        try:
                            dest = studio.registry.retirer(c)
                        except PermissionError:
                            raise RuntimeError(f"Impossible de ranger la fiche de « {t.nom} » : un de ses fichiers est sans doute "
                                               "ouvert (éditeur, Explorateur). Ferme-le et réessaie ; rien n'a été retiré.")
                        return {"ok": True, "message": f"« {t.nom} » est retiré du studio. Sa fiche est rangée dans "
                                f"{dest.relative_to(studio.paths.root).as_posix()} ; rien n'a été supprimé."}
                    return self._send(200, exclusif(c, retirer_cible))
                m = re.match(r"^/api/espaces/([^/]+)/retirer$", path)
                if m and _TID.match(m.group(1)):
                    c = cle_cible(studio.store.get(m.group(1))["target"])
                    return self._send(200, exclusif(c, actions.retirer_espace, studio, m.group(1)))
                m = re.match(r"^/api/taches/([^/]+)/fusionner$", path)
                if m and _TID.match(m.group(1)):
                    c = cle_cible(studio.store.get(m.group(1))["target"])
                    r = git_seul(c, actions.fusionner, studio, m.group(1))
                    suivant(m.group(1))                 # chaîne : l'étape suivante part du travail fusionné
                    return self._send(200, r)
                m = re.match(r"^/api/taches/([^/]+)/(decision|annuler|reprendre|arreter|chatgpt)$", path)
                if m and _TID.match(m.group(1)):
                    tid, action = m.groups()
                    if action == "chatgpt":
                        return self._send(200, {"fichier": str(studio.export_chatgpt(tid))})
                    if action == "annuler":
                        studio.store.request_cancel(tid)
                        background(annuler, tid, tid=tid, libre=True)
                    elif action == "arreter":            # « Stop » : arrête l'agent, la tâche reste reprenable
                        return self._send(200, studio.stop(tid))
                    elif action == "reprendre":
                        background(reprendre_tache, tid, tid=tid)
                    else:
                        if b.get("decision") not in ("approuver", "corriger", "annuler"):
                            return self._send(400, {"erreur": "décision : approuver, corriger ou annuler"})
                        if b["decision"] == "approuver" and not b.get("empreinte"):
                            return self._send(400, {"erreur": "empreinte du résultat présenté requise"})
                        background(decider, tid, b["decision"], b.get("empreinte", ""), b.get("commentaire", ""), tid=tid,
                                   libre=b["decision"] != "corriger")   # corriger relance du travail : il attend son tour
                    return self._send(202, {"ok": True})
                self._send(404, {"erreur": "introuvable"})
            except (KeyError, ValueError, FileExistsError, FileNotFoundError) as e:
                self._send(400, {"erreur": redact(str(e))[:800]})
            except RuntimeError as e:                # travail déjà en cours, refus de git… : message clair, rien de fait
                self._send(409, {"erreur": redact(str(e))[:600]})
            except Exception as e:                   # noqa: BLE001 — message sans secret, détail dans l'état du studio
                from ..memory import MemoryUnavailable
                if isinstance(e, MemoryUnavailable):
                    return self._send(503, {"erreur": f"MÉMOIRE EN PANNE — {e}"})
                self._send(500, {"erreur": type(e).__name__})

    return H


def serve(studio=None, token: str | None = None, controle: Controle | None = None, on_ready=None):
    from ..orchestrator.runner import Studio
    studio = studio or Studio()
    host, port = studio.cfg["interface"]["hote"], int(studio.cfg["interface"]["port"])
    ctl = controle or Controle()
    httpd = ThreadingHTTPServer((host, port), make_handler(studio, port, token, ctl))
    httpd.daemon_threads = True

    def veille():
        while not ctl.doit_s_arreter():
            time.sleep(2)
        httpd.shutdown()

    threading.Thread(target=veille, daemon=True).start()
    print(f"Studio : http://{host}:{port}  (Ctrl+C pour arrêter)", flush=True)
    from .. import mobile

    def veille_benchmarks():                             # classements : une mise à jour par jour au plus
        from .. import agents
        while not ctl.arret.is_set():
            agents.actualiser(studio.paths.data, str(studio.cfg.get("benchmarks", {}).get("url", "")))
            ctl.arret.wait(6 * 3600)
    threading.Thread(target=veille_benchmarks, daemon=True).start()

    def veille_mises_a_jour():                           # au lancement puis chaque jour ; les mineures s'installent seules
        from .. import mise_a_jour
        ctl.arret.wait(20)
        while not ctl.arret.is_set():
            mise_a_jour.automatique()
            ctl.arret.wait(24 * 3600)
    if token is not None:
        threading.Thread(target=veille_mises_a_jour, daemon=True).start()
    ctl.garder = mobile.relais_actif                     # accès téléphone actif : fermer la fenêtre ne ferme pas le studio
    if token is not None:                                # lanceur : relais Tailscale si Mel l'a activé, surveillé
        def veille_telephone():                          # Tailscale coupé ou relais tombé : reconnexion (toutes les 60 s)
            while not ctl.arret.is_set():
                if studio.cfg["interface"].get("acces_mobile") and not mobile.relais_actif():
                    mobile.demarrer_relais(port, studio.paths.journaux)
                ctl.arret.wait(60)
        threading.Thread(target=veille_telephone, daemon=True).start()
    if on_ready:
        on_ready(host, port)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        ctl.arret.set()                                 # la veille du téléphone s'arrête aussi
        mobile.couper_relais()                          # le relais s'arrête avec le studio
        httpd.server_close()
        studio.close()
