"""Pièces jointes lisibles par les agents (fenêtre Demande, tâches).

Chaque fichier joint reçoit à côté de lui un dossier ``<nom>.lisible/`` :
- PDF : ``texte.md`` (texte page par page) + ``pages/page-001.png``… (rendu des pages, pour voir schémas et images) ;
- images dans un format peu courant (BMP, TIFF, TGA, DDS, PSD…) ou très grandes : ``image.png`` lisible ;
- sons et vidéos : ``transcription.md`` (parole, horodatée), ``spectrogramme.png`` (pour « voir » le son), ``infos``
  (durée, volume), et pour une vidéo ``images/vue-01.png``… (images clés) ;
- Word, Excel, PowerPoint : ``texte.md`` (bibliothèque standard) ;
- archives ZIP : ``contenu.md`` (liste, rien n'est extrait).
Un ``LISIBLE.md`` résume ce qui a été produit et ce qui manque (avec la commande d'installation) : l'agent n'est jamais
bloqué en silence. Les modules optionnels (PyMuPDF, Pillow, faster-whisper) ne sont installés qu'avec l'accord de Mel
(``scripts\\Installer-Lecture-Pieces.ps1``).
"""
from __future__ import annotations

import json
import re
import zipfile
from pathlib import Path
from xml.etree import ElementTree

SUFFIXE = ".lisible"
IMAGES_NATIVES = {".png", ".jpg", ".jpeg", ".gif", ".webp"}
IMAGES_A_CONVERTIR = {".bmp", ".tif", ".tiff", ".tga", ".dds", ".psd", ".ico", ".jfif", ".avif", ".heic"}
AUDIO = {".wav", ".mp3", ".ogg", ".flac", ".m4a", ".aac", ".opus", ".wma"}
VIDEO = {".mp4", ".mov", ".mkv", ".webm", ".avi", ".m4v"}
OFFICE = {".docx", ".xlsx", ".pptx"}
INSTALLER = str(Path(__file__).resolve().parents[1] / "scripts" / "Installer-Lecture-Pieces.ps1") + " -Confirmer"
MAX_PAGES = 80


def capacites() -> dict:
    """Ce que le studio sait lire sur ce PC (affiché dans Gestion › Outils)."""
    def dispo(mod):
        try:
            __import__(mod)
            return True
        except Exception:                        # noqa: BLE001 — un module absent ou cassé = non disponible
            return False
    return {"pdf": dispo("pymupdf") or dispo("fitz"), "images": dispo("PIL"), "audio_video": dispo("faster_whisper") and dispo("av"),
            "office": True, "zip": True}


def _manque(module: str) -> str:
    return f"{module} n'est pas installé : lancer `{INSTALLER}` (accord de Mel requis)."


# ------------------------------------------------------------------ PDF
def _pdf(f: Path, out: Path, notes: list[str], produits: list[Path]):
    try:
        import pymupdf as fitz                   # PyMuPDF (ancien nom : fitz)
    except ImportError:
        try:
            import fitz
        except ImportError:
            notes.append("PDF non lu : " + _manque("PyMuPDF"))
            return
    doc = fitz.open(f)
    lignes = [f"# {f.name} — texte extrait ({doc.page_count} pages)\n"]
    (out / "pages").mkdir(exist_ok=True)
    for i, page in enumerate(doc):
        lignes.append(f"\n## Page {i + 1}\n\n{page.get_text().strip()}\n")
        if i < MAX_PAGES:
            png = out / "pages" / f"page-{i + 1:03d}.png"
            page.get_pixmap(dpi=110).save(png)
            produits.append(png)
    if doc.page_count > MAX_PAGES:
        notes.append(f"Rendu limité aux {MAX_PAGES} premières pages (le texte couvre tout le document).")
    t = out / "texte.md"
    t.write_text("".join(lignes), encoding="utf-8")
    produits.insert(0, t)
    if sum(len(p.get_text().strip()) for p in doc) < 50:
        notes.append("Peu ou pas de texte dans ce PDF (document scanné ?) : lire les images des pages.")


# ------------------------------------------------------------------ images
def _image(f: Path, out: Path, notes: list[str], produits: list[Path]):
    try:
        from PIL import Image
    except ImportError:
        if f.suffix.lower() not in IMAGES_NATIVES:
            notes.append("Image non convertie : " + _manque("Pillow"))
        return
    try:
        with Image.open(f) as im:
            notes.append(f"Image {im.width}×{im.height}, mode {im.mode}.")
            if f.suffix.lower() in IMAGES_NATIVES and max(im.size) <= 4000 and f.stat().st_size < 4_500_000:
                return                           # déjà lisible telle quelle
            im = im.convert("RGBA" if im.mode in ("RGBA", "LA", "P") else "RGB")
            im.thumbnail((2400, 2400))
            png = out / "image.png"
            im.save(png)
            produits.append(png)
    except Exception as e:                       # noqa: BLE001
        notes.append(f"Image illisible par Pillow ({type(e).__name__}).")


# ------------------------------------------------------------------ sons et vidéos
def _audio_video(f: Path, out: Path, notes: list[str], produits: list[Path], cfg: dict):
    try:
        import av
        import numpy as np
    except ImportError:
        notes.append("Son/vidéo non lu : " + _manque("faster-whisper (avec PyAV)"))
        return
    video = f.suffix.lower() in VIDEO
    try:
        with av.open(str(f)) as c:
            duree = float(c.duration / 1_000_000) if c.duration else 0.0
            notes.append(f"Durée : {duree:.1f} s.")
            if video and c.streams.video:
                (out / "images").mkdir(exist_ok=True)
                st = c.streams.video[0]
                n = 6
                for k in range(n):
                    t = duree * (k + 0.5) / n if duree else 0
                    c.seek(int(t / st.time_base) if st.time_base else 0, stream=st)
                    for fr in c.decode(st):
                        png = out / "images" / f"vue-{k + 1:02d}.png"
                        fr.to_image().save(png)
                        produits.append(png)
                        break
        # signal audio mono 16 kHz pour le spectrogramme et les mesures
        with av.open(str(f)) as c:
            if not c.streams.audio:
                notes.append("Pas de piste son.")
                return
            res = av.AudioResampler(format="flt", layout="mono", rate=16000)
            morceaux = []
            for fr in c.decode(c.streams.audio[0]):
                for r in res.resample(fr):
                    morceaux.append(r.to_ndarray().reshape(-1))
            x = np.concatenate(morceaux) if morceaux else np.zeros(1, dtype=np.float32)
        crete, rms = float(np.max(np.abs(x)) or 0), float(np.sqrt(np.mean(x ** 2)) or 0)
        db = lambda v: 20 * np.log10(max(v, 1e-9))
        notes.append(f"Niveau : crête {db(crete):.1f} dBFS, moyenne {db(rms):.1f} dBFS.")
        _spectrogramme(x, out / "spectrogramme.png", notes, produits)
    except Exception as e:                       # noqa: BLE001
        notes.append(f"Décodage impossible ({type(e).__name__}).")
        return
    try:
        from faster_whisper import WhisperModel
    except ImportError:
        notes.append("Parole non transcrite : " + _manque("faster-whisper"))
        return
    modele = cfg.get("modele_parole", "small")
    racine = Path(cfg.get("dossier_modeles", "")) if cfg.get("dossier_modeles") else None
    try:
        m = WhisperModel(modele, device="cpu", compute_type="int8", download_root=str(racine) if racine else None)
        segs, info = m.transcribe(str(f), vad_filter=True)
        lignes = [f"# {f.name} — transcription (langue détectée : {info.language}, modèle {modele})\n\n"]
        for s in segs:
            lignes.append(f"[{s.start:6.1f} → {s.end:6.1f}] {s.text.strip()}\n")
        t = out / "transcription.md"
        t.write_text("".join(lignes) if len(lignes) > 1 else lignes[0] + "(aucune parole détectée)\n", encoding="utf-8")
        produits.insert(0, t)
    except Exception as e:                       # noqa: BLE001
        notes.append(f"Transcription impossible ({type(e).__name__}) : le modèle de parole se télécharge à la première utilisation.")


def _spectrogramme(x, png: Path, notes: list[str], produits: list[Path]):
    try:
        import numpy as np
        from PIL import Image
    except ImportError:
        return
    n, pas = 512, 256
    if len(x) < n:
        return
    trames = np.lib.stride_tricks.sliding_window_view(x, n)[::pas] * np.hanning(n)
    s = np.abs(np.fft.rfft(trames, axis=1)).T
    s = 20 * np.log10(s + 1e-6)
    s = np.clip((s - (s.max() - 80)) / 80, 0, 1)[::-1]
    img = Image.fromarray((s * 255).astype("uint8")).resize((min(1600, max(400, s.shape[1])), 400))
    img.save(png)
    produits.append(png)
    notes.append("Spectrogramme : temps en horizontal, fréquences de 0 (bas) à 8 kHz (haut), clair = fort.")


# ------------------------------------------------------------------ bureautique et archives
def _office(f: Path, out: Path, notes: list[str], produits: list[Path]):
    try:
        with zipfile.ZipFile(f) as z:
            noms = z.namelist()
            if f.suffix.lower() == ".docx":
                parties = ["word/document.xml"]
            elif f.suffix.lower() == ".pptx":
                parties = sorted((n for n in noms if re.fullmatch(r"ppt/slides/slide\d+\.xml", n)),
                                 key=lambda n: int(re.search(r"(\d+)", n.split("/")[-1]).group(1)))
            else:
                parties = ["xl/sharedStrings.xml"] + sorted(n for n in noms if re.fullmatch(r"xl/worksheets/sheet\d+\.xml", n))
            lignes = [f"# {f.name} — texte extrait\n"]
            for p in parties:
                if p not in noms:
                    continue
                racine = ElementTree.fromstring(z.read(p))
                bloc, courant = [], []
                for el in racine.iter():
                    tag = el.tag
                    if tag.endswith("}t") and el.text:
                        courant.append(el.text)
                    elif tag.endswith("}p") or tag.endswith("}si") or tag.endswith("}row"):
                        if courant:
                            bloc.append("".join(courant))
                            courant = []
                    elif tag.endswith("}v") and el.text:
                        courant.append(el.text + " ")
                if courant:
                    bloc.append("".join(courant))
                lignes.append(f"\n## {p}\n\n" + "\n".join(b for b in bloc if b.strip()) + "\n")
        t = out / "texte.md"
        t.write_text("".join(lignes), encoding="utf-8")
        produits.append(t)
        if f.suffix.lower() == ".xlsx":
            notes.append("Excel : chaînes partagées puis valeurs des feuilles (sans mise en forme ni formules).")
    except (zipfile.BadZipFile, ElementTree.ParseError, KeyError) as e:
        notes.append(f"Document illisible ({type(e).__name__}).")


def _zip(f: Path, out: Path, notes: list[str], produits: list[Path]):
    try:
        with zipfile.ZipFile(f) as z:
            infos = z.infolist()
        t = out / "contenu.md"
        t.write_text(f"# {f.name} — contenu ({len(infos)} éléments, rien n'est extrait)\n\n"
                     + "\n".join(f"- {i.filename} ({i.file_size} octets)" for i in infos[:2000]), encoding="utf-8")
        produits.append(t)
    except zipfile.BadZipFile:
        notes.append("Archive ZIP illisible.")


# ------------------------------------------------------------------ point d'entrée
def preparer(f: Path, cfg: dict | None = None) -> dict:
    """Prépare une pièce (idempotent : ne refait rien si LISIBLE.md existe). Ne lève jamais d'exception."""
    f = Path(f)
    out = f.with_name(f.name + SUFFIXE)
    resume = out / "LISIBLE.md"
    if resume.exists():
        return json.loads((out / "lisible.json").read_text(encoding="utf-8"))
    notes: list[str] = []
    produits: list[Path] = []
    ext = f.suffix.lower()
    out.mkdir(exist_ok=True)
    try:
        if ext == ".pdf":
            _pdf(f, out, notes, produits)
        elif ext in IMAGES_NATIVES or ext in IMAGES_A_CONVERTIR:
            _image(f, out, notes, produits)
        elif ext in AUDIO or ext in VIDEO:
            _audio_video(f, out, notes, produits, cfg or {})
        elif ext in OFFICE:
            _office(f, out, notes, produits)
        elif ext == ".zip":
            _zip(f, out, notes, produits)
        else:
            notes.append("Format lisible directement (texte, code) ou non pris en charge : ouvrir le fichier d'origine.")
    except Exception as e:                       # noqa: BLE001 — une pièce ne doit jamais bloquer la conversation
        notes.append(f"Préparation interrompue ({type(e).__name__}).")
    rel = [p.relative_to(f.parent).as_posix() for p in produits]
    data = {"fichier": f.name, "lisible": rel, "notes": notes}
    (out / "lisible.json").write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")
    resume.write_text(f"# Version lisible de {f.name}\n\n" + "".join(f"- {r}\n" for r in rel)
                      + ("\n" + "".join(f"> {n}\n" for n in notes) if notes else ""), encoding="utf-8")
    return data


def preparer_lot(dossier: Path, cfg: dict | None = None) -> list[tuple[Path, dict]]:
    """Toutes les pièces d'un message (hors dossiers .lisible déjà produits)."""
    res = []
    for f in sorted(p for p in Path(dossier).rglob("*") if p.is_file() and not any(x.endswith(SUFFIXE) for x in p.parts)):
        res.append((f, preparer(f, cfg)))
    return res
