"""Agent par IA connectée (clé API ou IA locale) : boucle d'outils limitée à la copie isolée de la tâche.

Outils : lister, lire, chercher, écrire (pas d'écriture pour un relecteur). Aucune commande système, aucun accès
hors du dossier de la tâche, aucun réseau autre que l'appel au fournisseur choisi. Les clés ne passent jamais dans
la mission ni dans le compte rendu.
"""
from __future__ import annotations

import json
import re
from pathlib import Path

from .base import ExecResult, Mission

MAX_TOURS = 40
MAX_LECTURE = 60_000
IGNORES = {".git", "node_modules", "Binaries", "Intermediate", "Saved", "DerivedDataCache", ".venv", "__pycache__"}


def _outils(lecture_seule: bool, capacites: list[str] | None = None) -> list[dict]:
    def f(nom, desc, props, req):
        return {"type": "function", "function": {"name": nom, "description": desc,
                                                 "parameters": {"type": "object", "properties": props, "required": req}}}
    out = [f("lister", "Liste les fichiers et dossiers d'un dossier de l'espace (chemin relatif, « . » = racine).",
             {"chemin": {"type": "string"}}, ["chemin"]),
           f("lire", "Lit un fichier texte de l'espace (chemin relatif).", {"chemin": {"type": "string"}}, ["chemin"]),
           f("chercher", "Cherche un texte dans les fichiers de l'espace ; renvoie fichier:ligne: extrait.",
             {"texte": {"type": "string"}}, ["texte"])]
    if not lecture_seule:
        out.append(f("ecrire", "Crée ou remplace un fichier texte de l'espace (chemin relatif, contenu complet).",
                     {"chemin": {"type": "string"}, "contenu": {"type": "string"}}, ["chemin", "contenu"]))
        if "image" in (capacites or []):
            out.append(f("generer_image", "Génère une image PNG à partir d'une description détaillée et l'enregistre (chemin relatif .png).",
                         {"prompt": {"type": "string"}, "chemin": {"type": "string"}}, ["prompt", "chemin"]))
        if "voix" in (capacites or []):
            out.append(f("generer_voix", "Synthétise un texte en voix (fichier .mp3, chemin relatif).",
                         {"texte": {"type": "string"}, "chemin": {"type": "string"}}, ["texte", "chemin"]))
    return out


class ApiExecutor:
    name = "api"

    def __init__(self, data: Path, pour: str = "agents", lecture_seule: bool = False, studio=None):
        self.data = Path(data)
        self.pour = pour
        self.lecture_seule = lecture_seule
        self.studio = studio
        self._c: dict | None = None

    def _connexion(self, propre: str = "") -> dict | None:
        from .. import ia
        d = ia.lire(self.data)
        ident = propre if any(x["id"] == propre for x in d["connexions"]) else (d.get(self.pour) or "")
        c = next((x for x in d["connexions"] if x["id"] == ident), None)
        return c or (d["connexions"][0] if d["connexions"] else None)

    def available(self) -> tuple[bool, str]:
        c = self._connexion()
        if not c:
            return False, "Aucune IA connectée (Accueil › Réglages › IA)."
        return True, f"{c['fournisseur']} · {c.get('modele') or '?'}"

    # -- outils, confinés à l'espace
    @staticmethod
    def _chemin(racine: Path, rel: str) -> Path:
        rel = (rel or ".").replace("\\", "/").strip()
        if rel.startswith("/") or re.match(r"^[A-Za-z]:", rel) or ".." in Path(rel).parts:
            raise ValueError("chemin hors de l'espace")
        p = (racine / rel).resolve()
        p.relative_to(racine.resolve())
        return p

    def _executer_outil(self, racine: Path, nom: str, args: dict, ecrits: list[str]) -> str:
        try:
            if nom == "lister":
                d = self._chemin(racine, args.get("chemin", "."))
                if not d.is_dir():
                    return "Dossier introuvable."
                noms = sorted((x.name + ("/" if x.is_dir() else "")) for x in d.iterdir() if x.name not in IGNORES)
                return "\n".join(noms[:500]) or "(vide)"
            if nom == "lire":
                p = self._chemin(racine, args.get("chemin", ""))
                if not p.is_file():
                    return "Fichier introuvable."
                t = p.read_text(encoding="utf-8", errors="replace")
                return t[:MAX_LECTURE] + ("\n… (tronqué)" if len(t) > MAX_LECTURE else "")
            if nom == "chercher":
                motif = str(args.get("texte", ""))[:200]
                if not motif:
                    return "Texte vide."
                import os
                out, base = [], racine.resolve()
                fichiers = []
                for dossier, sous, noms in os.walk(racine, followlinks=False):     # jonctions et liens jamais suivis
                    sous[:] = [d for d in sous if d not in IGNORES and not Path(dossier, d).is_symlink()
                               and not getattr(Path(dossier, d), "is_junction", lambda: False)()]
                    fichiers += [Path(dossier, n) for n in noms]
                for p in fichiers:
                    if len(out) >= 200:
                        break
                    try:
                        if not p.is_file() or p.is_symlink() or p.stat().st_size > 2_000_000:
                            continue
                        p.resolve().relative_to(base)
                    except (OSError, ValueError):
                        continue
                    try:
                        for i, ligne in enumerate(p.read_text(encoding="utf-8", errors="ignore").splitlines(), 1):
                            if motif.lower() in ligne.lower():
                                out.append(f"{p.relative_to(racine).as_posix()}:{i}: {ligne.strip()[:200]}")
                    except OSError:
                        continue
                return "\n".join(out) or "Aucun résultat."
            if nom in ("generer_image", "generer_voix") and not self.lecture_seule and self._c is not None:
                from .. import ia
                ext = ".png" if nom == "generer_image" else ".mp3"
                rel = str(args.get("chemin", "")) or f"sortie{ext}"
                p = self._chemin(racine, rel if rel.lower().endswith(ext) else rel + ext)
                data = (ia.generer_image(self._c, str(args.get("prompt", ""))) if nom == "generer_image"
                        else ia.generer_voix(self._c, str(args.get("texte", ""))))
                p.parent.mkdir(parents=True, exist_ok=True)
                p.write_bytes(data)
                ecrits.append(p.relative_to(racine.resolve()).as_posix())
                return f"Fichier créé : {ecrits[-1]} ({len(data) // 1024} Ko)"
            if nom == "ecrire" and not self.lecture_seule:
                p = self._chemin(racine, args.get("chemin", ""))
                p.parent.mkdir(parents=True, exist_ok=True)
                p.write_text(str(args.get("contenu", "")), encoding="utf-8")
                ecrits.append(p.relative_to(racine.resolve()).as_posix())
                return f"Écrit : {ecrits[-1]}"
            return "Outil inconnu."
        except (ValueError, OSError) as e:
            return f"Refusé : {e}"
        except Exception as e:                  # noqa: BLE001 — erreur du fournisseur : l'agent la voit et s'adapte
            return f"Échec : {e}"

    def execute(self, mission: Mission, workdir: Path, runner) -> ExecResult:
        from .. import ia
        from ..orchestrator.processes import Cancelled
        c = self._connexion(mission.connexion)
        if not c:
            return ExecResult(False, "Aucune IA connectée.", self.name, error="aucune connexion")
        if mission.modele_api:
            c = {**c, "modele": mission.modele_api}
        self._c = c
        consigne = (mission.prompt() + "\n\n## Outils\nTu travailles avec les outils lister, lire, chercher"
                    + ("" if self.lecture_seule else ", ecrire") + " dans le dossier courant de la tâche (chemins relatifs). "
                    "Pas de commande système. Quand tu as fini, réponds sans appeler d'outil : ta réponse est ton compte rendu."
                    + (" Pour produire une image, appelle generer_image (prompt détaillé, en anglais de préférence)."
                       if "image" in mission.capacites and not self.lecture_seule else "")
                    + (" Pour produire une voix, appelle generer_voix." if "voix" in mission.capacites and not self.lecture_seule else ""))
        messages = [{"role": "system", "content": consigne}, {"role": "user", "content": "Exécute la mission."}]
        outils, ecrits, usage = _outils(self.lecture_seule, mission.capacites), [], {}
        for _ in range(MAX_TOURS):
            if runner is not None and runner.store.cancel_requested(mission.task_id):
                raise Cancelled("Tâche annulée.")
            try:
                r = ia.discuter(c, messages, outils)
            except ia.ErreurIA as e:
                texte = str(e)
                if "tool" in texte.lower():
                    texte += " — ce modèle ne sait pas utiliser d'outils : choisis-en un autre pour les agents."
                return ExecResult(False, texte, self.name, error=texte)
            for k, v in (r.get("usage") or {}).items():
                if isinstance(v, int):
                    usage[k] = usage.get(k, 0) + v
            m = r["message"]
            appels = m.get("tool_calls") or []
            messages.append({"role": "assistant", "content": m.get("content") or "", **({"tool_calls": appels} if appels else {})})
            if not appels:
                texte = m.get("content") or ""
                if isinstance(texte, list):
                    texte = "".join(b.get("text", "") for b in texte if isinstance(b, dict))
                return ExecResult(bool(texte.strip()), texte[:8000] or "Réponse vide.", self.name,
                                  raw={"usage": usage, "fichiers": ecrits, "modele": c.get("modele")})
            for a in appels:
                fn = a.get("function") or {}
                brut = fn.get("arguments") or "{}"
                try:
                    args = brut if isinstance(brut, dict) else json.loads(brut)
                except (TypeError, ValueError):
                    args = {}
                resultat = self._executer_outil(workdir, fn.get("name", ""), args if isinstance(args, dict) else {}, ecrits)
                messages.append({"role": "tool", "tool_call_id": a.get("id", ""), "content": resultat})
        return ExecResult(False, f"Trop d'étapes ({MAX_TOURS}) sans conclusion.", self.name, error="trop d'étapes",
                          raw={"usage": usage, "fichiers": ecrits})
