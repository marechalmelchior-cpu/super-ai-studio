"""Connexions aux IA : abonnement (Claude Code, Codex), clé API (OpenAI, Anthropic, Gemini, Mistral, OpenRouter,
DeepSeek, Groq) ou IA locale (Ollama, LM Studio).

Toutes les IA par clé ou locales passent par la même interface « chat completions » (format OpenAI, que ces
fournisseurs acceptent tous). Les clés sont chiffrées par Windows (DPAPI, compte courant) dans data/connexions.json,
jamais affichées, jamais écrites dans un journal ni dans un prompt. Rien n'est envoyé ailleurs qu'au fournisseur choisi.
"""
from __future__ import annotations

import base64
import json
import secrets
import sys
import threading
import urllib.error
import urllib.request
from pathlib import Path

FOURNISSEURS: dict[str, dict] = {
    "openai": {"nom": "OpenAI (ChatGPT)", "url": "https://api.openai.com/v1", "cle": True, "conseil": "gpt-4.1"},
    "anthropic": {"nom": "Anthropic (Claude)", "url": "https://api.anthropic.com/v1", "cle": True, "conseil": "claude-sonnet"},
    "gemini": {"nom": "Google Gemini", "url": "https://generativelanguage.googleapis.com/v1beta/openai", "cle": True, "conseil": "gemini-2.5-flash"},
    "mistral": {"nom": "Mistral", "url": "https://api.mistral.ai/v1", "cle": True, "conseil": "mistral-large-latest"},
    "openrouter": {"nom": "OpenRouter (beaucoup de modèles, une clé)", "url": "https://openrouter.ai/api/v1", "cle": True, "conseil": ""},
    "deepseek": {"nom": "DeepSeek", "url": "https://api.deepseek.com/v1", "cle": True, "conseil": "deepseek-chat"},
    "groq": {"nom": "Groq", "url": "https://api.groq.com/openai/v1", "cle": True, "conseil": ""},
    "ollama": {"nom": "Ollama (IA locale)", "url": "http://127.0.0.1:11434/v1", "cle": False, "conseil": "qwen2.5-coder"},
    "lmstudio": {"nom": "LM Studio (IA locale)", "url": "http://127.0.0.1:1234/v1", "cle": False, "conseil": ""},
}
_verrou = threading.Lock()


class ErreurIA(RuntimeError):
    pass


# ------------------------------------------------------------------ stockage (clés chiffrées)
def _fichier(data: Path) -> Path:
    return Path(data) / "connexions.json"


def _chiffrer(cle: str) -> str:
    if sys.platform == "win32":
        from .backup import protect
        return "dpapi:" + base64.b64encode(protect(cle.encode())).decode()
    return "local:" + base64.b64encode(cle.encode()).decode()       # hors Windows (tests) : fichier local seulement


def _dechiffrer(v: str) -> str:
    if not v:
        return ""
    genre, _, b = v.partition(":")
    raw = base64.b64decode(b)
    if genre == "dpapi":
        from .backup import unprotect
        return unprotect(raw).decode()
    return raw.decode()


def lire(data: Path) -> dict:
    try:
        d = json.loads(_fichier(data).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        d = {}
    d.setdefault("connexions", [])
    d.setdefault("superviseur", "")
    d.setdefault("agents", "")
    return d


def _ecrire(data: Path, d: dict) -> None:
    f = _fichier(data)
    f.parent.mkdir(parents=True, exist_ok=True)
    t = f.with_suffix(".partiel")
    t.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
    t.replace(f)


def public(data: Path) -> dict:
    """Pour l'interface : jamais la clé, seulement « clé enregistrée »."""
    d = lire(data)
    return {"connexions": [{"id": c["id"], "fournisseur": c["fournisseur"], "nom": FOURNISSEURS.get(c["fournisseur"], {}).get("nom", c["fournisseur"]),
                            "modele": c.get("modele", ""), "url": c.get("url", ""), "cle": bool(c.get("cle"))} for c in d["connexions"]],
            "superviseur": d["superviseur"], "agents": d["agents"],
            "fournisseurs": [{"id": k, **{x: v[x] for x in ("nom", "cle", "conseil")}} for k, v in FOURNISSEURS.items()]}


def adresse_sure(url: str) -> bool:
    """https vers n'importe quel hôte, ou http seulement vers ce PC (127.0.0.1, localhost, ::1)."""
    from urllib.parse import urlparse
    try:
        u = urlparse(url)
    except ValueError:
        return False
    if u.scheme == "https" and u.hostname:
        return True
    return u.scheme == "http" and u.hostname in ("127.0.0.1", "localhost", "::1")


def ajouter(data: Path, fournisseur: str, cle: str = "", modele: str = "", url: str = "") -> dict:
    if fournisseur not in FOURNISSEURS:
        raise ValueError("Fournisseur inconnu.")
    f = FOURNISSEURS[fournisseur]
    cle = (cle or "").strip()
    if f["cle"] and not cle:
        raise ValueError("Colle ta clé API.")
    if url and not adresse_sure(url):
        raise ValueError("Adresse refusée : https, ou une IA locale sur 127.0.0.1.")
    c = {"id": f"{fournisseur}-{secrets.token_hex(3)}", "fournisseur": fournisseur, "modele": modele.strip(),
         "url": url.strip(), "cle": _chiffrer(cle) if cle else ""}
    modeles = lister_modeles(c)                         # vérifie la clé avant d'enregistrer (erreur claire sinon)
    if not c["modele"] and modeles:
        c["modele"] = choisir_conseil(fournisseur, modeles)
    with _verrou:
        d = lire(data)
        d["connexions"].append(c)
        d["superviseur"] = d["superviseur"] or c["id"]
        d["agents"] = d["agents"] or c["id"]
        _ecrire(data, d)
    return {"id": c["id"], "modeles": modeles, "modele": c["modele"]}


def modifier(data: Path, ident: str, **champs) -> None:
    with _verrou:
        d = lire(data)
        for k in ("superviseur", "agents"):
            if k in champs:
                v = str(champs[k] or "")
                if v and v not in ("claude-code", "codex") and v not in {c["id"] for c in d["connexions"]}:
                    raise ValueError("Connexion inconnue.")
                d[k] = v
        if ident and "modele" in champs:
            for c in d["connexions"]:
                if c["id"] == ident:
                    c["modele"] = str(champs["modele"] or "")
        _ecrire(data, d)


def retirer(data: Path, ident: str) -> None:
    with _verrou:
        d = lire(data)
        d["connexions"] = [c for c in d["connexions"] if c["id"] != ident]
        for k in ("superviseur", "agents"):
            if d[k] == ident:
                d[k] = d["connexions"][0]["id"] if d["connexions"] else ""
        _ecrire(data, d)


def connexion(data: Path, ident: str) -> dict | None:
    return next((c for c in lire(data)["connexions"] if c["id"] == ident), None)


# ------------------------------------------------------------------ appels HTTP (format chat completions)
def _base(c: dict) -> str:
    return (c.get("url") or FOURNISSEURS[c["fournisseur"]]["url"]).rstrip("/")


def _entetes(c: dict) -> dict:
    h = {"Content-Type": "application/json", "User-Agent": "SuperAIStudio"}
    cle = _dechiffrer(c.get("cle", ""))
    if cle:
        h["Authorization"] = f"Bearer {cle}"
        if c["fournisseur"] == "anthropic":
            h["x-api-key"] = cle
            h["anthropic-version"] = "2023-06-01"
    return h


def _ollama_ferme(c: dict, e: Exception) -> bool:
    """Connexion refusée par l'Ollama de ce PC (fermé) : la requête n'est jamais arrivée, on peut l'ouvrir et réessayer."""
    from urllib.parse import urlparse
    raison = getattr(e, "reason", e)
    return (c.get("fournisseur") == "ollama" and isinstance(raison, ConnectionRefusedError)
            and (urlparse(_base(c)).hostname or "") in ("127.0.0.1", "localhost", "::1"))


def _requete(c: dict, chemin: str, corps: dict | None = None, delai: float = 300, _reessai: bool = True) -> dict:
    req = urllib.request.Request(_base(c) + chemin, headers=_entetes(c), method="POST" if corps is not None else "GET",
                                 data=json.dumps(corps).encode() if corps is not None else None)
    try:
        with urllib.request.urlopen(req, timeout=delai) as r:
            brut = r.read() or b"{}"
        try:
            d = json.loads(brut)
        except ValueError:
            raise ErreurIA(f"{FOURNISSEURS[c['fournisseur']]['nom']} : réponse illisible") from None
        return d if isinstance(d, dict) else {"data": d}
    except urllib.error.HTTPError as e:
        try:
            detail = json.loads(e.read() or b"{}")
            if isinstance(detail, list):                     # Gemini : [{"error": {...}}]
                detail = detail[0] if detail and isinstance(detail[0], dict) else {}
            err = detail.get("error") if isinstance(detail, dict) else None
            msg = err.get("message") if isinstance(err, dict) else (err or "")
        except (ValueError, AttributeError):
            msg = ""
        from .security import redact
        texte = {401: "clé refusée", 403: "accès refusé", 404: "adresse ou modèle introuvable", 429: "limite atteinte (quota)"}.get(e.code, f"erreur {e.code}")
        raise ErreurIA(f"{FOURNISSEURS[c['fournisseur']]['nom']} : {texte}" + (f" — {redact(str(msg))[:200]}" if msg else "")) from None
    except (urllib.error.URLError, OSError, TimeoutError) as e:
        if _reessai and _ollama_ferme(c, e):
            from . import modeles_locaux
            if modeles_locaux.assurer():                       # Ollama s'ouvre au moment où il sert
                return _requete(c, chemin, corps, delai, _reessai=False)
        local = not FOURNISSEURS[c["fournisseur"]]["cle"]
        raise ErreurIA(f"{FOURNISSEURS[c['fournisseur']]['nom']} ne répond pas"
                       + (" : lance-le sur ce PC." if local else f" ({type(e).__name__}).")) from None


def lister_modeles(c: dict) -> list[str]:
    d = _requete(c, "/models", delai=20)
    ids = [str(m.get("id", "")) for m in (d.get("data") or d.get("models") or []) if isinstance(m, dict)]
    return sorted({i.removeprefix("models/") for i in ids if i})


def choisir_conseil(fournisseur: str, modeles: list[str]) -> str:
    conseil = FOURNISSEURS[fournisseur]["conseil"]
    return next((m for m in modeles if conseil and m.startswith(conseil)), modeles[0] if modeles else "")


FAMILLES = {"openai": "OpenAI (clé API)", "anthropic": "Anthropic (clé API)", "gemini": "Gemini", "mistral": "Mistral",
            "openrouter": "OpenRouter", "deepseek": "DeepSeek", "groq": "Groq", "ollama": "Ollama (local)", "lmstudio": "LM Studio (local)"}


def famille(c: dict) -> str:
    """Nom de l'IA dans Gestion › Usage (les abonnements Claude Code et Codex restent « Claude » et « Codex »)."""
    return FAMILLES.get(c.get("fournisseur", ""), c.get("fournisseur", "") or "IA connectée")


def discuter(c: dict, messages: list[dict], outils: list[dict] | None = None, delai: float = 300) -> dict:
    """Un tour de conversation ; renvoie le message de l'IA (content, tool_calls) et l'usage."""
    if not c.get("modele"):
        raise ErreurIA("Aucun modèle choisi pour cette connexion (Accueil › Réglages › IA).")
    corps: dict = {"model": c["modele"], "messages": messages}
    if outils:
        corps["tools"] = outils
    if c.get("fournisseur") == "openrouter":            # OpenRouter renvoie alors le coût réel de l'appel (usage.cost)
        corps["usage"] = {"include": True}
    d = _requete(c, "/chat/completions", corps, delai)
    choix = (d.get("choices") or [{}])[0]
    return {"message": choix.get("message") or {}, "usage": d.get("usage") or {}, "fin": choix.get("finish_reason", "")}


def _brut(c: dict, chemin: str, corps: dict, delai: float = 300) -> bytes:
    req = urllib.request.Request(_base(c) + chemin, headers=_entetes(c), method="POST", data=json.dumps(corps).encode())
    try:
        with urllib.request.urlopen(req, timeout=delai) as r:
            return r.read()
    except urllib.error.HTTPError as e:
        raise ErreurIA(f"{FOURNISSEURS[c['fournisseur']]['nom']} : erreur {e.code} ({chemin})") from None
    except (urllib.error.URLError, OSError, TimeoutError) as e:
        raise ErreurIA(f"{FOURNISSEURS[c['fournisseur']]['nom']} ne répond pas ({type(e).__name__}).") from None


def modele_image(c: dict) -> str:
    if c.get("modele_image"):
        return c["modele_image"]
    try:
        noms = lister_modeles(c)
    except ErreurIA:
        noms = []
    for motif in ("gpt-image", "imagen", "flash-image", "dall-e"):
        trouve = sorted((m for m in noms if motif in m), reverse=True)
        if trouve:
            return trouve[0]
    return {"openai": "gpt-image-1", "gemini": "imagen-4.0-generate-001"}.get(c["fournisseur"], "")


def generer_image(c: dict, prompt: str, taille: str = "1024x1024") -> bytes:
    """Image PNG générée par l'IA connectée (OpenAI ou Gemini) ; rien n'est publié."""
    corps = {"model": modele_image(c), "prompt": prompt[:4000], "n": 1, "size": taille}
    if not corps["model"].startswith("gpt-image"):
        corps["response_format"] = "b64_json"
    d = json.loads(_brut(c, "/images/generations", corps) or b"{}")
    item = (d.get("data") or [{}])[0]
    if item.get("b64_json"):
        return base64.b64decode(item["b64_json"])
    if str(item.get("url", "")).startswith("https://"):
        with urllib.request.urlopen(item["url"], timeout=120) as r:
            return r.read()
    raise ErreurIA("Aucune image renvoyée.")


def generer_voix(c: dict, texte: str, voix: str = "alloy") -> bytes:
    """Fichier MP3 de synthèse vocale (OpenAI)."""
    return _brut(c, "/audio/speech", {"model": c.get("modele_voix") or "gpt-4o-mini-tts", "voice": voix, "input": texte[:4000]})


def detecter_locales() -> list[str]:
    """IA locales qui répondent maintenant (rien n'est lancé ni installé)."""
    out = []
    for k in ("ollama", "lmstudio"):
        try:
            with urllib.request.urlopen(FOURNISSEURS[k]["url"] + "/models", timeout=1):
                out.append(k)
        except OSError:
            pass
    return out


# ------------------------------------------------------------------ qui répond : Superviseur et agents
def choix(studio, pour: str) -> tuple[str, dict | None]:
    """("claude-code" | "codex" | "api" | "", connexion) pour « superviseur » ou « agents ».
    Réglage explicite d'abord ; sinon Claude Code s'il est installé ; sinon la première connexion."""
    d = lire(studio.paths.data)
    v = d.get(pour, "")
    if v in ("claude-code", "codex"):
        return v, None
    if v:
        c = next((x for x in d["connexions"] if x["id"] == v), None)
        if c:
            return "api", c
    from .connectors.claude_code import WIN_CANDIDATES
    from .connectors.base import find_exe
    if find_exe(studio.cfg["outils"].get("claude", "claude"), WIN_CANDIDATES):
        return "claude-code", None
    if d["connexions"]:
        return "api", d["connexions"][0]
    return "", None


def appel_superviseur(studio, c: dict, consigne: str, message: str) -> tuple[bool, str, dict]:
    from .espace import perso
    try:
        r = discuter(c, [{"role": "system", "content": perso(consigne)}, {"role": "user", "content": perso(message)}],
                     delai=float(studio.cfg.get("superviseur", {}).get("delai_s", 300)))
    except ErreurIA as e:
        return False, str(e), {}
    texte = r["message"].get("content") or ""
    if isinstance(texte, list):                         # certains fournisseurs renvoient des blocs
        texte = "".join(b.get("text", "") for b in texte if isinstance(b, dict))
    return bool(texte.strip()), texte or "Réponse vide.", {"jetons": r["usage"], "appel": True, "modele": c["modele"],
                                                           "famille": famille(c), "cout_usd": (r["usage"] or {}).get("cost")}
