"""Boîte à outils commune des agents : skills, mémoire partagée et serveurs MCP pour TOUS les modèles.

- Claude Code et Codex lisent leurs skills dans leurs dossiers (copies « studio-* », tenues à jour seules : voir
  ``skills_a_jour``). Les autres modèles (clé API, OpenRouter, Ollama…) les reçoivent ici : la liste courte (nom et
  description) dans la mission, et l'outil ``lire_skill`` pour ouvrir celle qui sert (chargement à la demande, comme
  Claude Code : la mission reste légère, même pour un petit modèle local).
- Mémoire : chacun reçoit les souvenirs utiles dans sa mission et peut en chercher d'autres en cours de tâche
  (lecture seule ; les écritures restent faites par le studio après validation).
- Source unique : Studio/Skills (et .claude/skills du projet). Rien n'est jamais supprimé ni écrasé hors des copies
  « studio-* » marquées par le studio.
"""
from __future__ import annotations

import hashlib
import re
from pathlib import Path

RESERVEE = "superviseur"                     # méthode du Superviseur : jamais donnée aux agents
MAX_SKILL = 60_000
_cache: dict[str, tuple[float, dict]] = {}


def _entete(md: Path) -> dict:
    """name / description du SKILL.md (cache selon la date du fichier)."""
    try:
        mt = md.stat().st_mtime
    except OSError:
        return {}
    c = _cache.get(str(md))
    if c and c[0] == mt:
        return c[1]
    t = md.read_text(encoding="utf-8", errors="replace")[:4000]
    m = re.match(r"(?s)^---\s*\n(.*?)\n---", t)
    bloc = m.group(1) if m else ""
    lire = lambda k: (re.search(rf"(?m)^{k}:\s*(.+)$", bloc) or [None, ""])[1].strip().strip("\"'")   # noqa: E731
    d = {"nom": lire("name") or md.parent.name, "description": lire("description")}
    _cache[str(md)] = (mt, d)
    return d


def skills_disponibles(racine_studio: Path, dossier_projet: Path | None = None) -> list[dict]:
    """Skills du studio puis du projet (celles du projet passent devant à nom égal)."""
    vues: dict[str, dict] = {}
    sources = [(Path(racine_studio) / "Skills", "studio")]
    if dossier_projet:
        sources.append((Path(dossier_projet) / ".claude" / "skills", "projet"))
    for base, origine in sources:
        if not base.is_dir():
            continue
        for d in sorted(base.iterdir()):
            md = d / "SKILL.md"
            if d.name == RESERVEE or not md.is_file():
                continue
            e = _entete(md)
            vues[d.name] = {"id": d.name, "nom": e.get("nom") or d.name, "description": e.get("description", ""),
                            "dossier": d, "origine": origine}
    return list(vues.values())


def resume_skills(skills: list[dict], max_car: int = 3000) -> str:
    """Liste courte pour la mission : une ligne par skill, coupée pour rester légère."""
    lignes, total = [], 0
    for s in skills:
        l = f"- {s['id']} : {(s['description'] or s['nom'])[:170]}"
        if total + len(l) > max_car:
            lignes.append(f"- … et {len(skills) - len(lignes)} autre(s) : lire_skill avec le nom exact.")
            break
        lignes.append(l)
        total += len(l)
    return "\n".join(lignes)


def lire_skill(skills: list[dict], nom: str, fichier: str = "") -> str:
    """SKILL.md (ou un fichier de la skill : références, modèles) ; jamais hors du dossier de la skill."""
    s = next((x for x in skills if x["id"] == nom or x["nom"] == nom), None)
    if not s:
        return "Skill inconnue. Skills disponibles : " + ", ".join(x["id"] for x in skills[:60])
    rel = (fichier or "SKILL.md").replace("\\", "/").strip().lstrip("/")
    if ".." in Path(rel).parts or re.match(r"^[A-Za-z]:", rel):
        return "Refusé : chemin hors de la skill."
    p = (s["dossier"] / rel).resolve()
    try:
        p.relative_to(s["dossier"].resolve())
    except ValueError:
        return "Refusé : chemin hors de la skill."
    if p.is_dir():
        return "\n".join(sorted(x.relative_to(s["dossier"]).as_posix() + ("/" if x.is_dir() else "")
                                for x in p.rglob("*") if "__pycache__" not in x.parts)[:300]) or "(vide)"
    if not p.is_file():
        return "Fichier introuvable dans la skill. Fichiers : " + lire_skill(skills, nom, ".")[:1500]
    t = p.read_text(encoding="utf-8", errors="replace")
    return t[:MAX_SKILL] + ("\n… (tronqué)" if len(t) > MAX_SKILL else "")


def chercher_memoire(memory, requete: str, portees: list[str], limite: int = 10) -> str:
    """Souvenirs de la mémoire partagée (portées de la tâche + général), en lecture seule."""
    from .memory import Scope
    try:
        recs = memory.recall(str(requete or "")[:300], [Scope.parse(p) for p in portees if p], True, max(1, min(int(limite), 20)))
    except Exception as e:                               # noqa: BLE001 — mémoire en panne : l'agent le dit et continue
        return f"Mémoire indisponible : {str(e)[:200]}"
    if not recs:
        return "Aucun souvenir pour cette recherche."
    return "\n".join(f"- [{r.scope.label}] {r.content}" for r in recs)


# ------------------------------------------------------------------ copies pour Claude Code et Codex : automatiques
def signature_skills(racine_studio: Path) -> str:
    """Empreinte rapide du dossier Skills (noms, tailles, dates) : quelques millisecondes, sans lire les fichiers."""
    h = hashlib.sha256()
    base = Path(racine_studio) / "Skills"
    if base.is_dir():
        for p in sorted(base.rglob("*")):
            if p.is_file() and "__pycache__" not in p.parts:
                try:
                    st = p.stat()
                except OSError:
                    continue
                h.update(f"{p.relative_to(base).as_posix()}|{st.st_size}|{int(st.st_mtime)}\n".encode())
    return h.hexdigest()[:24]


def skills_a_jour(racine_studio: Path, data: Path, home: Path | None = None, force: bool = False) -> list[str]:
    """Recopie les skills du studio chez Claude Code et Codex SEULEMENT si le dossier Skills a changé depuis la
    dernière fois (empreinte gardée dans data/skills-signature.txt). Mêmes garanties que la copie manuelle : seuls les
    dossiers « studio-* » marqués par le studio sont écrits ; rien n'est supprimé ni écrasé ailleurs."""
    from .superviseur import synchroniser_skills
    sig = signature_skills(racine_studio)
    f = Path(data) / "skills-signature.txt"
    try:
        if not force and f.read_text(encoding="utf-8").strip() == sig:
            return []
    except OSError:
        pass
    rapport = synchroniser_skills(Path(racine_studio), home)
    try:
        f.parent.mkdir(parents=True, exist_ok=True)
        t = f.with_suffix(".tmp")
        t.write_text(sig, encoding="utf-8")
        t.replace(f)
    except OSError:
        pass
    return [x for x in rapport if x != "Déjà à jour."]


# ------------------------------------------------------------------ fichiers d'instructions (.md) : un seul par projet
NOMS_INSTRUCTIONS = ("CLAUDE.md", "AGENTS.md")
_IGNORES = {".git", "node_modules", ".venv", "venv", "__pycache__", "Library", "Intermediate", "Binaries", "DerivedDataCache",
            "Saved", "build", "dist", ".godot", ".import", ".claude", ".agents"}
MAX_INSTRUCTIONS = 12_000


def fichiers_instructions(dossier: Path, profondeur: int = 3, maximum: int = 40) -> list[Path]:
    """CLAUDE.md et AGENTS.md du projet (racine et sous-dossiers proches), sans parcourir les dossiers lourds."""
    out: list[Path] = []
    dossier = Path(dossier)

    def visiter(d: Path, n: int):
        if len(out) >= maximum:
            return
        for nom in NOMS_INSTRUCTIONS:
            if (d / nom).is_file():
                out.append(d / nom)
        if n >= profondeur:
            return
        try:
            sous = sorted(x for x in d.iterdir() if x.is_dir() and x.name not in _IGNORES and not x.name.startswith("."))
        except OSError:
            return
        for x in sous:
            visiter(x, n + 1)
    if dossier.is_dir():
        visiter(dossier, 0)
    return out


def instructions_pour(executant: str, dossier: Path | None) -> tuple[str, list[str]]:
    """Ce que l'exécutant ne lit pas tout seul. Claude Code lit CLAUDE.md, Codex AGENTS.md (et CLAUDE.md en secours,
    réglé à son lancement) : on ne leur donne que ce qui manque. Les autres modèles reçoivent le fichier de la racine.
    Renvoie (texte à joindre à la mission, sous-dossiers à lire quand l'agent y travaille). Aucun fichier n'est copié."""
    if not dossier:
        return "", []
    dossier = Path(dossier)
    fichiers = fichiers_instructions(dossier)
    racine = {f.name: f for f in fichiers if f.parent == dossier}
    natif = {"claude-code": "CLAUDE.md", "codex": "AGENTS.md"}.get(executant)
    a_joindre: list[Path] = []
    if natif == "CLAUDE.md":
        if "CLAUDE.md" not in racine and "AGENTS.md" in racine:
            a_joindre = [racine["AGENTS.md"]]
    elif natif == "AGENTS.md":
        a_joindre = []                                   # AGENTS.md lu ; sinon CLAUDE.md en secours (réglage du lancement)
    else:
        vus = set()
        for nom in NOMS_INSTRUCTIONS:
            if nom in racine:
                t = racine[nom].read_text(encoding="utf-8", errors="replace").strip()
                if t and t not in vus:
                    vus.add(t)
                    a_joindre.append(racine[nom])
    texte, reste = [], MAX_INSTRUCTIONS
    for f in a_joindre:
        t = f.read_text(encoding="utf-8", errors="replace").strip()
        if not t or reste <= 0:
            continue
        texte.append(f"### {f.name} (racine du projet)\n{t[:reste]}" + ("\n… (tronqué : lis la suite dans le fichier)" if len(t) > reste else ""))
        reste -= len(t)
    sous = []
    for f in fichiers:
        if f.parent == dossier:
            continue
        lu = (natif == "CLAUDE.md" and (f.parent / "CLAUDE.md").is_file()) or (natif == "AGENTS.md")
        if not lu and f.parent.relative_to(dossier).as_posix() not in sous:
            sous.append(f.parent.relative_to(dossier).as_posix())
    return "\n\n".join(texte), sous


def instructions_globales(dossier_regles: Path, executant: str, home: Path | None = None, max_car: int = 8000) -> str:
    """CLAUDE.md / AGENTS.md globaux repris dans Regles/importes : donnés à chaque modèle, sauf à l'outil qui lit déjà
    l'original (Claude Code lit ~/.claude/CLAUDE.md, Codex ~/.codex/AGENTS.md) tant qu'il existe."""
    home = Path(home or Path.home())
    natifs = {"CLAUDE (Claude Code).md": ("claude-code", home / ".claude" / "CLAUDE.md"),
              "AGENTS (Codex).md": ("codex", home / ".codex" / "AGENTS.md")}
    d = Path(dossier_regles) / "importes"
    if not d.is_dir():
        return ""
    parts, vus = [], set()
    for f in sorted(d.glob("*.md")):
        ex, original = natifs.get(f.name, ("", None))
        if ex == executant and original is not None and original.exists():
            continue
        t = f.read_text(encoding="utf-8", errors="replace").strip()
        if t and t not in vus:
            vus.add(t)
            parts.append(f"### {f.stem} (instructions générales de l'utilisateur)\n{t}")
    return "\n\n".join(parts)[:max_car]


def regles_studio(dossier_regles: Path, max_car: int = 6000) -> str:
    """Règles communes du studio (instructions, sécurité, conventions) : courtes, données à TOUS les agents."""
    parts = []
    for nom in ("INSTRUCTIONS-COMMUNES.md", "SECURITE.md", "CONVENTIONS.md"):
        f = Path(dossier_regles) / nom
        if f.is_file():
            parts.append(f.read_text(encoding="utf-8", errors="replace").strip())
    t = "\n\n".join(parts)
    return t[:max_car]
