"""Espace du studio : les données (règles, skills, projets, tâches, mémoire, réglages) séparées du programme.

- Le programme (dossier ``Studio`` qui contient ``studio/``) peut être installé n'importe où ; une mise à jour ne touche
  jamais l'espace.
- L'espace est trouvé dans cet ordre : variable ``STUDIO_HOME`` ; fichier pointeur de l'utilisateur
  (``%APPDATA%\\SuperAIStudio\\espace.json``) ; sinon l'ancienne disposition, où le programme est rangé DANS l'espace
  (``AI-Workspace\\Studio\\studio``) — c'est le cas du studio de Mel, qui continue de marcher sans rien changer.
- Premier lancement sans espace : l'assistant demande un dossier. Un dossier qui contient déjà un espace est
  simplement rejoint (rien n'est copié ni remplacé) ; sinon l'espace est créé avec le socle et les packs choisis.
  Aucun fichier existant n'est jamais écrasé.
"""
from __future__ import annotations

import json
import os
import re
import shutil
import sys
import tomllib
from pathlib import Path

CODE = Path(__file__).resolve().parents[1]               # dossier du programme (contient studio/, modeles/, scripts/)
MODELES = CODE / "modeles"


def fichier_pointeur() -> Path:
    if os.environ.get("STUDIO_POINTEUR"):
        return Path(os.environ["STUDIO_POINTEUR"])
    base = os.environ.get("APPDATA") if sys.platform == "win32" else None
    base = Path(base) if base else Path.home() / ".config"
    return base / "SuperAIStudio" / "espace.json"


def est_espace(d: Path) -> bool:
    return (Path(d) / "Studio" / "studio.config.toml").is_file()


def racine_configuree() -> Path | None:
    """Racine de l'espace, ou None si le studio n'a pas encore d'espace (premier lancement)."""
    if os.environ.get("STUDIO_HOME"):
        return Path(os.environ["STUDIO_HOME"]).resolve()
    try:
        r = Path(json.loads(fichier_pointeur().read_text(encoding="utf-8"))["racine"])
        if est_espace(r):
            return r.resolve()
    except (OSError, ValueError, KeyError, TypeError):
        pass
    ancien = CODE.parent                                   # disposition historique : AI-Workspace\Studio\studio
    if CODE.name == "Studio" and (est_espace(ancien) or (ancien / "Regles").is_dir() or (ancien / "Projets").is_dir()):
        return ancien.resolve()
    return None


def ecrire_pointeur(racine: Path) -> None:
    f = fichier_pointeur()
    f.parent.mkdir(parents=True, exist_ok=True)
    t = f.with_suffix(".partiel")
    t.write_text(json.dumps({"racine": str(Path(racine).resolve())}, ensure_ascii=False), encoding="utf-8")
    t.replace(f)


def dossier_propose() -> Path:
    docs = Path.home() / "Documents"
    return (docs if docs.is_dir() else Path.home()) / "Studio IA"


# ------------------------------------------------------------------ prénom de l'utilisateur
_VOYELLES = "AEIOUYÉÈÊÂÎÔaeiouyéèêâîô"


def remplacer_nom(texte: str, nom: str) -> str:
    """Les textes du studio parlent de « l'utilisateur » ; avec un prénom réglé ([utilisateur] nom), il le remplace
    (« de l'utilisateur » → « d'Alex » devant une voyelle). Les anciens textes écrits avec « Mel » suivent la même règle.
    Sans prénom : texte inchangé."""
    nom = (nom or "").strip()
    if not nom:
        return texte
    voy = nom[0] in _VOYELLES
    for sujet in ("l'utilisateur", "Mel"):
        if sujet == nom:
            continue
        texte = re.sub(rf"\b([dD])e {sujet}\b", lambda m: f"{m.group(1)}'{nom}" if voy else f"{m.group(1)}e {nom}", texte)
        texte = re.sub(rf"\b([qQ])ue {sujet}\b", lambda m: f"{m.group(1)}u'{nom}" if voy else f"{m.group(1)}ue {nom}", texte)
        texte = re.sub(rf"\b[lL]'utilisateur\b" if sujet != "Mel" else r"\bMel\b", nom, texte)
    return texte


_nom_actuel = {"nom": ""}


def definir_nom(cfg: dict) -> str:
    """Prénom de l'utilisateur ([utilisateur] nom, Réglages › « Ton prénom ») ; absent = textes neutres."""
    _nom_actuel["nom"] = str((cfg.get("utilisateur") or {}).get("nom") or "").strip()
    return _nom_actuel["nom"]


def nom() -> str:
    return _nom_actuel["nom"]


def perso(texte: str) -> str:
    """Textes envoyés aux agents ou montrés dans l'interface : « l'utilisateur » devient son prénom s'il l'a réglé."""
    return remplacer_nom(texte, _nom_actuel["nom"]) if isinstance(texte, str) else texte


# ------------------------------------------------------------------ packs
def packs() -> list[dict]:
    out = []
    for d in sorted((MODELES / "packs").glob("*/pack.toml")):
        p = tomllib.loads(d.read_text(encoding="utf-8"))
        out.append({"id": d.parent.name, "nom": p["nom"], "description": p["description"],
                    "skills": p.get("skills", []), "roles": p.get("roles", [])})
    return out


def _copier(src: Path, dest: Path, remplacements: dict[str, str], nom: str, crees: list[str]) -> None:
    """Copie un dossier modèle sans jamais écraser un fichier existant ; textes personnalisés (prénom, chemins)."""
    for f in sorted(src.rglob("*")):
        if f.is_dir():
            continue
        cible = dest / f.relative_to(src)
        if cible.exists():
            continue
        cible.parent.mkdir(parents=True, exist_ok=True)
        if f.suffix.lower() in (".md", ".toml", ".txt"):
            t = f.read_text(encoding="utf-8")
            for k, v in remplacements.items():
                t = t.replace(k, v)
            cible.write_text(remplacer_nom(t, nom), encoding="utf-8")
        else:
            shutil.copy2(f, cible)
        crees.append(str(cible))


def installer_pack(racine: Path, pack: str, nom: str) -> list[str]:
    """Ajoute les skills et rôles d'un pack à un espace (rien d'existant n'est remplacé)."""
    d = MODELES / "packs" / pack
    if not (d / "pack.toml").is_file():
        raise ValueError(f"Pack inconnu : {pack}")
    crees: list[str] = []
    rempl = {"{{STUDIO_CMD}}": f'"{CODE / "studio.cmd"}"', "{{NOM}}": nom}
    if (d / "Skills").is_dir():
        _copier(d / "Skills", Path(racine) / "Skills", rempl, nom, crees)
    if (d / "roles").is_dir():
        _copier(d / "roles", Path(racine) / "Studio" / "roles", rempl, nom, crees)
    return crees


def etat_packs(racine: Path) -> list[dict]:
    """Packs proposés, avec « installe » quand tous leurs skills et rôles sont déjà dans l'espace."""
    out = []
    for p in packs():
        present = all((Path(racine) / "Skills" / s / "SKILL.md").is_file() for s in p["skills"]) and \
            all((Path(racine) / "Studio" / "roles" / f"{r}.toml").is_file() for r in p["roles"])
        out.append({**p, "installe": present})
    return out


_MOTS_VIDES = {"pour", "avec", "dans", "les", "des", "une", "qui", "que", "sur", "par", "son", "ses", "est", "sont", "aux",
               "the", "and", "for", "with", "this", "that", "from", "faire", "fait", "tout", "tous", "plus"}


def creer_agent(racine: Path, nom: str, mission: str, livrable: str = "", outil: str = "auto") -> dict:
    """Nouvel agent spécialisé (Studio/roles/<id>.toml) à partir de trois phrases ; rien d'existant n'est remplacé.
    Le Superviseur le choisit quand une demande parle de son sujet ; il travaille avec l'IA connectée."""
    nom, mission, livrable = (nom or "").strip()[:60], (mission or "").strip()[:800], (livrable or "").strip()[:300]
    if not nom or len(mission) < 10:
        raise ValueError("Donne un nom et une phrase sur ce que fait l'agent.")
    if outil not in ("auto", "claude-code", "codex"):
        raise ValueError("Outil inconnu.")
    import unicodedata
    base = re.sub(r"[^a-z0-9]+", "-", unicodedata.normalize("NFKD", nom.lower()).encode("ascii", "ignore").decode()).strip("-")[:40] or "agent"
    dossier = Path(racine) / "Studio" / "roles"
    dossier.mkdir(parents=True, exist_ok=True)
    ident, n = base, 2
    while (dossier / f"{ident}.toml").exists() or ident == "auditeur":
        ident, n = f"{base}-{n}", n + 1
    mots = []
    for m in re.findall(r"[\wÀ-ÿ-]{4,}", f"{nom} {mission} {livrable}".lower()):
        if m not in _MOTS_VIDES and m not in mots:
            mots.append(m)
    q = lambda s: json.dumps(s, ensure_ascii=False)                 # chaîne TOML valide (échappements compris)
    texte = "\n".join([
        f"id = {q(ident)}", f"nom = {q(nom)}", 'domaines = ["code", "doc", "topic", "web", "unreal", "python", "outillage"]',
        f"executeur = {q('claude-code' if outil == 'auto' else outil)}",
        f"mots_cles = {q(mots[:14])}",
        'outils = ["Read", "Glob", "Grep", "Write", "Edit"]',
        f"livrables = {q([livrable or 'Le livrable demandé, dans le dossier de la tâche'])}",
        'criteres = ["Le livrable demandé est présent et complet", "Compte rendu clair : fait, vérifié, reste à faire"]',
        'limites = ["Ne supprime rien", "Reste dans le périmètre de la demande"]',
        f"consignes = {q(mission)}", "# agent créé depuis Gestion › Agents", ""])
    tomllib.loads(texte)
    (dossier / f"{ident}.toml").write_text(texte, encoding="utf-8")
    return {"id": ident, "nom": nom}


def creer_espace(racine: Path, nom: str, choix_packs: list[str]) -> dict:
    """Crée (ou rejoint) l'espace et l'enregistre comme espace de l'utilisateur. Rien n'est écrasé."""
    racine = Path(racine).expanduser()
    if not racine.is_absolute():
        raise ValueError("Indique un chemin complet (ex. C:\\Users\\toi\\Documents\\Studio IA).")
    nom = re.sub(r"[\r\n'\"\\]", "", (nom or "").strip())[:40]
    if est_espace(racine):
        ecrire_pointeur(racine)
        return {"rejoint": True, "racine": str(racine), "crees": []}
    if racine.exists() and any(racine.iterdir()):
        racine = racine / "Studio IA"                       # dossier déjà rempli : l'espace va dans un sous-dossier
        if est_espace(racine):
            ecrire_pointeur(racine)
            return {"rejoint": True, "racine": str(racine), "crees": []}
    racine.mkdir(parents=True, exist_ok=True)
    crees: list[str] = []
    rempl = {"{{STUDIO_CMD}}": f'"{CODE / "studio.cmd"}"', "{{NOM}}": nom}
    _copier(MODELES / "espace", racine, rempl, nom, crees)
    for p in choix_packs:
        crees += installer_pack(racine, p, nom)
    for d in ("Taches", "Sauvegardes", "Archives", "Studio/data"):
        (racine / d).mkdir(parents=True, exist_ok=True)
    ecrire_pointeur(racine)
    return {"rejoint": False, "racine": str(racine), "crees": crees}


# ------------------------------------------------------------------ outils déjà présents sur le PC (lecture seule)
def detecter_outils() -> list[dict]:
    """Ce que le studio trouve déjà : rien n'est installé ni modifié."""
    import urllib.request
    from .connectors.base import find_exe

    def connecte(fichiers: list[Path]) -> bool:
        return any(f.exists() for f in fichiers)

    h = Path.home()
    out = []
    from .connectors.claude_code import WIN_CANDIDATES
    claude = find_exe("claude", WIN_CANDIDATES)
    out.append({"id": "claude", "nom": "Claude Code", "present": bool(claude),
                "detail": ("connecté" if connecte([h / ".claude" / ".credentials.json", h / ".claude.json"]) else "installé")
                if claude else "pas installé (facultatif)"})
    codex = find_exe("codex", [str(h / "AppData/Roaming/npm/codex.cmd")])
    out.append({"id": "codex", "nom": "Codex (ChatGPT)", "present": bool(codex),
                "detail": ("connecté" if connecte([h / ".codex" / "auth.json"]) else "installé") if codex else "pas installé (facultatif)"})
    git = shutil.which("git")
    out.append({"id": "git", "nom": "Git", "present": bool(git), "detail": "installé" if git else "pas installé (conseillé)"})
    ollama = False
    for url in ("http://127.0.0.1:11434/api/tags", "http://127.0.0.1:1234/v1/models"):
        try:
            with urllib.request.urlopen(url, timeout=1):
                ollama = True
                break
        except OSError:
            pass
    out.append({"id": "local", "nom": "IA locale (Ollama, LM Studio)", "present": ollama,
                "detail": "en marche" if ollama else "non détectée (facultatif)"})
    return out
