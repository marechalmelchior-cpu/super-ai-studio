"""Lanceur du raccourci « Super AI Agent Pro Station Max 2000 » (bureau) : un clic ouvre l'interface dans sa propre fenêtre.

- Local uniquement (127.0.0.1), rien n'est exposé sur le réseau ni sur Internet.
- Clé de session aléatoire à chaque démarrage, échangée contre un cookie HttpOnly : une autre application ou un
  site web ouvert dans le navigateur ne peut pas piloter le studio.
- Pas de service permanent : le serveur s'arrête seul ~1 min après la fermeture de la dernière fenêtre, mais
  jamais pendant une tâche lancée depuis l'interface (il attend la fin). Bouton « Fermer le studio » aussi.
- Second clic pendant que le studio est ouvert : nouvelle fenêtre sur la même session.
Journal sans secret : Studio/data/journaux/interface.log.
"""
from __future__ import annotations

import json
import os
import secrets
import threading
import shutil
import subprocess
import sys
import urllib.error
import urllib.request
import webbrowser
from datetime import datetime
from pathlib import Path

from .config import load_config
from .paths import default_paths

ABSENCE_S = 60          # arrêt après 1 min sans fenêtre ouverte (et sans tâche en cours)


def _message(texte: str) -> None:
    if sys.platform == "win32":
        import ctypes
        ctypes.windll.user32.MessageBoxW(0, texte, "Super AI Agent Pro Station Max 2000", 0x40)
        return
    print(texte)
    try:                                               # Mac / Linux lancés sans terminal : boîte de message aussi
        if sys.platform == "darwin":
            subprocess.run(["osascript", "-e", "on run argv", "-e", 'display dialog (item 1 of argv) buttons {"OK"} with title "Super AI Studio"',
                            "-e", "end run", texte], timeout=300, capture_output=True)
        elif shutil.which("zenity"):
            subprocess.run(["zenity", "--info", "--title=Super AI Studio", f"--text={texte}"], timeout=300, capture_output=True)
    except (OSError, subprocess.SubprocessError):
        pass


def _ping(host: str, port: int) -> bool | None:
    """True = un studio répond ; False = port libre ; None = port occupé par autre chose."""
    try:
        with urllib.request.urlopen(f"http://{host}:{port}/api/ping", timeout=2) as r:
            return json.loads(r.read()).get("studio") is True
    except urllib.error.HTTPError:
        return None
    except (OSError, ValueError):
        return False


def _edge() -> str | None:
    """Edge sous Windows ; sinon Chrome, Chromium ou Brave (Mac, Linux) : fenêtre d'application sans barre d'adresse."""
    from .plateforme import navigateur_app
    return navigateur_app()


def options_fenetre(data: Path | None) -> list[str]:
    """Taille et position de la fenêtre à la dernière fermeture (data/fenetre.json, noté par la page) :
    plein écran, agrandie, ou position et taille exactes. Profil Edge propre au studio : les options sont toujours
    appliquées, même si Edge est déjà ouvert ailleurs."""
    if data is None:
        return []
    opts = [f"--user-data-dir={Path(data) / 'edge-studio'}", "--no-first-run", "--no-default-browser-check"]
    try:
        e = json.loads((Path(data) / "fenetre.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return opts
    if e.get("plein_ecran"):
        return opts + ["--start-fullscreen"]
    if e.get("agrandie"):
        return opts + ["--start-maximized"]
    try:
        x, y, w, h = (int(e[k]) for k in ("x", "y", "l", "h"))
    except (KeyError, TypeError, ValueError):
        return opts
    if 400 <= w <= 10000 and 300 <= h <= 10000 and -10000 < x < 20000 and -10000 < y < 20000:
        opts += [f"--window-position={x},{y}", f"--window-size={w},{h}"]
    return opts


def ouvrir_fenetre(url: str, data: Path | None = None) -> None:
    """Fenêtre d'application (Edge --app : sans onglets ni barre d'adresse), à la taille de la dernière fermeture ;
    sinon navigateur par défaut."""
    edge = _edge()
    if edge:
        try:
            subprocess.Popen([edge, f"--app={url}", *options_fenetre(data)], stdin=subprocess.DEVNULL,
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, close_fds=True)
            return
        except OSError:
            pass
    webbrowser.open(url)


def sauvegarde_du_jour(paths, note=lambda m: None):
    """Une sauvegarde du studio par jour, au premier lancement de la journée (rien n'est supprimé : les anciennes restent)."""
    from datetime import timezone
    jour = datetime.now(timezone.utc).strftime("%Y%m%d")
    if any(p for p in paths.backups.glob(f"studio-{jour}T*") if not p.name.endswith(".partiel")):
        return None
    try:
        from .backup import create_backup
        f = create_backup(paths)
        note(f"sauvegarde du jour : {f.name}")
        return f
    except Exception as e:                       # noqa: BLE001 — la sauvegarde ne bloque jamais l'ouverture
        note(f"sauvegarde du jour impossible : {type(e).__name__}")
        return None


def cle_session(data: Path) -> str:
    """Clé de session stable d'un lancement à l'autre : une fenêtre ou un onglet rouvert sur ce PC reste connecté
    (cookie gardé un an). Fichier local, jamais affiché ni journalisé."""
    f = Path(data) / "interface-cle.json"
    try:
        cle = json.loads(f.read_text(encoding="utf-8"))["cle"]
        if isinstance(cle, str) and len(cle) >= 32:
            return cle
    except (OSError, ValueError, KeyError, TypeError):
        pass
    cle = secrets.token_urlsafe(32)
    t = f.with_suffix(".partiel")
    t.write_text(json.dumps({"cle": cle}), encoding="utf-8")
    t.replace(f)
    return cle


PORT_ASSISTANT = 8765      # port de l'assistant de premier lancement (= port par défaut du studio)


def premier_lancement() -> bool | None:
    """Studio installé sans espace : assistant de premier lancement. True = espace prêt (fenêtre déjà ouverte),
    None = rien à faire (espace déjà configuré), False = assistant fermé avant la fin."""
    from .espace import racine_configuree
    if racine_configuree() is not None:
        return None
    from .paths import StudioPaths
    from .premier_lancement import servir
    port = PORT_ASSISTANT
    if _ping("127.0.0.1", port) is not False:
        _message(f"Le port {port} est déjà utilisé : ferme l'autre application (ou l'autre studio) puis relance.")
        return False

    def apres(racine: Path) -> str:
        return f"/?t={cle_session(StudioPaths(racine).ensure().data)}"
    return bool(servir(port, lambda url: ouvrir_fenetre(url, None), apres))


def main() -> int:
    from .plateforme import completer_path
    completer_path()                                   # Mac / Linux : outils installés hors du PATH du bureau
    deja = premier_lancement()
    if deja is False:
        return 0
    paths = default_paths().ensure()
    log = open(paths.journaux / "interface.log", "a", encoding="utf-8", buffering=1)
    if sys.stdout is None or sys.executable.lower().endswith("pythonw.exe"):
        sys.stdout = sys.stderr = log                  # pythonw : pas de console

    def note(msg: str):
        log.write(f"{datetime.now().isoformat(timespec='seconds')}  {msg}\n")

    cfg = load_config(paths.config_file)
    host, port = cfg["interface"]["hote"], int(cfg["interface"]["port"])
    session = paths.data / "interface-session.json"

    etat = _ping(host, port)
    if etat:
        try:
            token = json.loads(session.read_text(encoding="utf-8"))["token"]
        except (OSError, ValueError, KeyError):
            _message("Un studio est déjà ouvert mais sa session est introuvable. Ferme-le (bouton « Fermer le studio ») "
                     "puis relance le raccourci.")
            return 1
        note("instance déjà ouverte : nouvelle fenêtre")
        ouvrir_fenetre(f"http://{host}:{port}/?t={token}", paths.data)
        return 0
    if etat is None:
        _message(f"Le port {port} est utilisé par une autre application. Change « port » dans "
                 f"Studio\\studio.config.toml (section [interface]) puis relance.")
        return 1

    token = cle_session(paths.data)
    session.write_text(json.dumps({"token": token, "pid": os.getpid()}), encoding="utf-8")
    from .ui.server import Controle, serve
    ctl = Controle(delai_absence_s=ABSENCE_S)
    note(f"démarrage (pid {os.getpid()})")
    # n'empêche pas de fermer le studio : une sauvegarde coupée reste un fichier « .partiel », ignoré et refaite au lancement suivant
    threading.Thread(target=sauvegarde_du_jour, args=(paths, note), daemon=True).start()
    try:
        serve(token=token, controle=ctl,                 # premier lancement : la fenêtre de l'assistant devient le studio
              on_ready=None if deja and port == PORT_ASSISTANT else (lambda h, p: ouvrir_fenetre(f"http://{h}:{p}/?t={token}", paths.data)))
    except OSError as e:
        note(f"échec : {type(e).__name__}")
        _message(f"Impossible d'ouvrir le studio : {e}")
        return 1
    finally:
        try:
            if json.loads(session.read_text(encoding="utf-8")).get("token") == token:
                session.unlink()
        except (OSError, ValueError):
            pass
        note("arrêt")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
