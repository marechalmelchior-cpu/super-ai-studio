"""Réglages du studio modifiables depuis Gestion (colonne « Réglages »).

Liste fermée : seules ces clés peuvent être écrites, avec leur type et leurs valeurs permises. Chaque écriture :
1. copie d'abord ``studio.config.toml`` dans ``Studio/data/config-avant/`` (rien n'est jamais supprimé) ;
2. remplace UNE ligne ``cle = valeur`` de la section (commentaires et reste du fichier conservés ; clé ajoutée si absente) ;
3. vérifie que le fichier reste un TOML valide, puis l'écrit de façon atomique ;
4. met à jour la configuration en mémoire. Les réglages lus seulement au démarrage le disent (``redemarrage``).
"""
from __future__ import annotations

import re
import shutil
import tomllib
from datetime import datetime
from pathlib import Path

# (section, clé) → description
REGLAGES: dict[tuple[str, str], dict] = {
    ("superviseur", "web"): {"type": "bool", "libelle": "Recherche sur le web", "groupe": "Superviseur"},
    ("utilisateur", "nom"): {"type": "texte", "libelle": "Ton prénom (agents et Superviseur)", "groupe": "Superviseur"},
    ("utilisateur", "langue"): {"type": "str", "choix": ["fr", "en"], "libelle": "Langue · Language (fr / en)", "groupe": "Superviseur"},
    ("superviseur", "bilan"): {"type": "bool", "libelle": "Bilan du Superviseur à la fin de chaque tâche", "groupe": "Superviseur"},
    ("usage", "limites_claude"): {"type": "bool", "libelle": "Limites Claude en % (Gestion › Usage)", "groupe": "Limites et alertes"},
    ("usage", "limites_codex"): {"type": "bool", "libelle": "Limites Codex en % (Gestion › Usage)", "groupe": "Limites et alertes"},
    ("usage", "alerte_claude_5h_min"): {"type": "int", "choix": [0, 15, 30, 60, 90, 120], "unite": "min",
                                        "libelle": "Alerte : limite Claude atteinte dans moins de", "groupe": "Limites et alertes"},
    ("usage", "alerte_codex_5h_min"): {"type": "int", "choix": [0, 15, 30, 60, 90, 120], "unite": "min",
                                       "libelle": "Alerte : limite Codex atteinte dans moins de", "groupe": "Limites et alertes"},
    ("limites", "autonomie"): {"type": "str", "choix": ["complete", "validation"],
                               "libelle": "Tâches : finir seules (complete) ou attendre ma validation", "groupe": "Exécution des tâches"},
    ("limites", "taches_simultanees"): {"type": "int", "choix": [1, 2, 3, 4], "redemarrage": True,
                                        "libelle": "Tâches en parallèle", "groupe": "Exécution des tâches"},
    ("limites", "corrections_max"): {"type": "int", "choix": [0, 1, 2, 3],
                                     "libelle": "Corrections auto après relecture", "groupe": "Exécution des tâches"},
    ("audit", "auditeur_modele"): {"type": "bool", "redemarrage": True,
                                   "libelle": "Relecture par un second modèle", "groupe": "Exécution des tâches"},
    ("choix", "codex_effort_max"): {"type": "str", "choix": ["high", "xhigh"], "redemarrage": True,
                                    "libelle": "Effort « Max » de Codex", "groupe": "Exécution des tâches"},
    ("outils", "mcp_unreal"): {"type": "str", "choix": ["tout", "lecture"], "redemarrage": True,
                               "libelle": "unreal-mcp pour les agents", "groupe": "Exécution des tâches"},
    ("agents_api", "commandes"): {"type": "str", "choix": ["sures", "toutes", "non"],
                                  "libelle": "Commandes des agents API (sures = tests et compilation)", "groupe": "Exécution des tâches"},
    ("agents_api", "contexte_local"): {"type": "int", "choix": [8192, 16384, 32768, 65536, 131072], "unite": "jetons",
                                       "libelle": "Modèles locaux : mémoire de travail max (plus = plus de mémoire vidéo)",
                                       "groupe": "Exécution des tâches"},
    ("nuit", "debut"): {"type": "str", "choix": ["22:00", "23:00", "00:00", "01:00", "02:00", "03:00"],
                        "libelle": "Tâches de nuit : début", "groupe": "Exécution des tâches"},
    ("nuit", "fin"): {"type": "str", "choix": ["05:00", "06:00", "07:00", "08:00", "09:00"],
                      "libelle": "Tâches de nuit : fin (rapport ensuite)", "groupe": "Exécution des tâches"},
    ("interface", "acces_mobile"): {"type": "bool", "cache": True,          # bouton de la carte « Téléphone »
                                    "libelle": "Accès depuis le téléphone (Tailscale)", "groupe": "Téléphone"},
    ("outils", "blender"): {"type": "chemin", "cache": True, "libelle": "Blender (blender.exe)", "groupe": "Connecteurs"},
    ("outils", "unreal_editor_cmd"): {"type": "chemin", "cache": True, "libelle": "Unreal (UnrealEditor-Cmd.exe)", "groupe": "Connecteurs"},
}


def liste(cfg: dict) -> list[dict]:
    """Réglages avec leur valeur actuelle, dans l'ordre d'affichage."""
    return [{"section": s, "cle": k, "valeur": cfg.get(s, {}).get(k), **d} for (s, k), d in REGLAGES.items() if not d.get("cache")]


def valider(section: str, cle: str, valeur):
    d = REGLAGES.get((section, cle))
    if not d:
        raise ValueError("Réglage inconnu.")
    t = d["type"]
    if t == "bool":
        if not isinstance(valeur, bool):
            raise ValueError("Oui ou non attendu.")
        return valeur
    if t == "int":
        try:
            v = int(valeur)
        except (TypeError, ValueError):
            raise ValueError("Nombre attendu.") from None
        if "choix" in d and v not in d["choix"]:
            raise ValueError("Valeur non proposée.")
        return v
    v = str(valeur or "").strip()
    if t == "texte" and not (0 < len(v) <= 40):
        raise ValueError("Entre 1 et 40 caractères.")
    if "'" in v or "\n" in v or "\r" in v or len(v) > 400:
        raise ValueError("Valeur invalide.")
    if "choix" in d and v not in d["choix"]:
        raise ValueError("Valeur non proposée.")
    return v


def _litteral(v) -> str:
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, int):
        return str(v)
    return f"'{v}'"                       # chaîne littérale TOML : les \ des chemins Windows restent tels quels


def ecrire(path: Path, section: str, cle: str, valeur) -> Path:
    """Écrit une valeur dans le fichier ; renvoie la copie faite avant modification."""
    path = Path(path)
    texte = path.read_text(encoding="utf-8")
    ligne = f"{cle} = {_litteral(valeur)}"
    debut = re.search(rf"(?m)^\[{re.escape(section)}\]\s*$", texte)
    if not debut:
        nouveau = texte.rstrip("\n") + f"\n\n[{section}]\n{ligne}\n"
    else:
        fin = re.search(r"(?m)^\[", texte[debut.end():])
        zone = texte[debut.end(): debut.end() + fin.start()] if fin else texte[debut.end():]
        motif = re.compile(rf"(?m)^({re.escape(cle)}\s*=\s*)(\"[^\"\n]*\"|'[^'\n]*'|true|false|-?\d+(?:\.\d+)?)([ \t]*#.*)?$")
        if motif.search(zone):
            zone2 = motif.sub(lambda m: f"{m.group(1)}{_litteral(valeur)}{m.group(3) or ''}", zone, count=1)
        else:
            zone2 = zone.rstrip("\n") + f"\n{ligne}\n" + ("\n" if fin else "")
            if not zone.strip():
                zone2 = f"\n{ligne}\n" + ("\n" if fin else "")
        nouveau = texte[: debut.end()] + zone2 + texte[debut.end() + len(zone):]
    lu = tomllib.loads(nouveau)                          # le fichier doit rester valide…
    if lu.get(section, {}).get(cle) != valeur:           # …et contenir exactement la nouvelle valeur
        raise ValueError("Écriture non vérifiée : rien n'est modifié.")
    copies = path.parent / "data" / "config-avant"
    copies.mkdir(parents=True, exist_ok=True)
    copie = copies / f"studio.config-{datetime.now().strftime('%Y%m%d-%H%M%S-%f')}.toml"
    shutil.copy2(path, copie)
    tmp = path.with_suffix(".tmp")
    tmp.write_text(nouveau, encoding="utf-8", newline="")
    tmp.replace(path)
    return copie


def modifier(cfg: dict, path: Path, section: str, cle: str, valeur) -> dict:
    v = valider(section, cle, valeur)
    ecrire(path, section, cle, v)
    cfg.setdefault(section, {})[cle] = v
    d = REGLAGES[(section, cle)]
    return {"ok": True, "valeur": v, "redemarrage": bool(d.get("redemarrage")),
            "message": "Enregistré : pris en compte au prochain démarrage du studio." if d.get("redemarrage") else "Enregistré."}
