"""Connexions aux IA : abonnement (Claude Code, Codex), clé API (OpenAI, Anthropic, Gemini, Mistral, OpenRouter,
DeepSeek, Groq) ou IA locale (Ollama, LM Studio).

Toutes les IA par clé ou locales passent par la même interface « chat completions » (format OpenAI, que ces
fournisseurs acceptent tous). Les clés sont chiffrées par Windows (DPAPI, compte courant) dans data/connexions.json,
jamais affichées, jamais écrites dans un journal ni dans un prompt. Rien n'est envoyé ailleurs qu'au fournisseur choisi.
"""
from __future__ import annotations

import base64
import json
import re
import secrets
import sys
import threading
import urllib.error
import urllib.request
from pathlib import Path

FOURNISSEURS: dict[str, dict] = {
    "openai": {"nom": "OpenAI (ChatGPT)", "url": "https://api.openai.com/v1", "cle": True, "conseil": "gpt-4.1"},
    "anthropic": {"nom": "Anthropic (Claude)", "url": "https://api.anthropic.com/v1", "cle": True, "conseil": "claude-sonnet"},
    "gemini": {"nom": "Google Gemini", "url": "https://generativelanguage.googleapis.com/v1beta/openai", "cle": True, "conseil": "gemini-2.5-flash"},
    "mistral": {"nom": "Mistral", "url": "https://api.mistral.ai/v1", "cle": True, "conseil": "mistral-large-latest"},
    "openrouter": {"nom": "OpenRouter (beaucoup de modèles, une clé)", "url": "https://openrouter.ai/api/v1", "cle": True, "conseil": ""},
    "deepseek": {"nom": "DeepSeek", "url": "https://api.deepseek.com/v1", "cle": True, "conseil": "deepseek-chat"},
    "groq": {"nom": "Groq", "url": "https://api.groq.com/openai/v1", "cle": True, "conseil": ""},
    "xai": {"nom": "xAI (Grok)", "url": "https://api.x.ai/v1", "cle": True, "conseil": "grok"},
    "moonshot": {"nom": "Moonshot (Kimi)", "url": "https://api.moonshot.ai/v1", "cle": True, "conseil": "kimi"},
    "autre": {"nom": "Autre IA (compatible OpenAI : adresse + clé)", "url": "", "cle": False, "conseil": ""},
    "elevenlabs": {"nom": "ElevenLabs (voix)", "url": "https://api.elevenlabs.io/v1", "cle": True, "conseil": "", "seulement": "voix"},
    "ollama": {"nom": "Ollama (IA locale)", "url": "http://127.0.0.1:11434/v1", "cle": False, "conseil": "qwen2.5-coder"},
    "lmstudio": {"nom": "LM Studio (IA locale)", "url": "http://127.0.0.1:1234/v1", "cle": False, "conseil": ""},
}
_verrou = threading.Lock()


class ErreurIA(RuntimeError):
    pass


# ------------------------------------------------------------------ stockage (clés chiffrées)
def _fichier(data: Path) -> Path:
    return Path(data) / "connexions.json"


def _chiffrer(cle: str) -> str:
    from .coffre import chiffrer
    return chiffrer(cle)


def _dechiffrer(v: str) -> str:
    from .coffre import dechiffrer
    return dechiffrer(v)


def lire(data: Path) -> dict:
    try:
        d = json.loads(_fichier(data).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        d = {}
    d.setdefault("connexions", [])
    d.setdefault("superviseur", "")
    d.setdefault("agents", "")
    return d


def _ecrire(data: Path, d: dict) -> None:
    f = _fichier(data)
    f.parent.mkdir(parents=True, exist_ok=True)
    t = f.with_suffix(".partiel")
    t.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
    t.replace(f)


def public(data: Path) -> dict:
    """Pour l'interface : jamais la clé, seulement « clé enregistrée »."""
    d = lire(data)
    return {"connexions": [{"id": c["id"], "fournisseur": c["fournisseur"], "nom": FOURNISSEURS.get(c["fournisseur"], {}).get("nom", c["fournisseur"]),
                            "modele": c.get("modele", ""), "url": c.get("url", ""), "cle": bool(c.get("cle"))} for c in d["connexions"]],
            "superviseur": d["superviseur"], "agents": d["agents"],
            "fournisseurs": [{"id": k, **{x: v[x] for x in ("nom", "cle", "conseil")}} for k, v in FOURNISSEURS.items()]}


def adresse_sure(url: str) -> bool:
    """https vers n'importe quel hôte, ou http seulement vers ce PC (127.0.0.1, localhost, ::1)."""
    from urllib.parse import urlparse
    try:
        u = urlparse(url)
    except ValueError:
        return False
    if u.scheme == "https" and u.hostname:
        return True
    return u.scheme == "http" and u.hostname in ("127.0.0.1", "localhost", "::1")


def ajouter(data: Path, fournisseur: str, cle: str = "", modele: str = "", url: str = "") -> dict:
    if fournisseur not in FOURNISSEURS:
        raise ValueError("Fournisseur inconnu.")
    f = FOURNISSEURS[fournisseur]
    cle = (cle or "").strip()
    if f["cle"] and not cle:
        raise ValueError("Colle ta clé API.")
    if fournisseur == "autre" and not (url or "").strip():
        raise ValueError("Indique l'adresse de l'IA (ex. https://api.exemple.com/v1).")
    if url and not adresse_sure(url):
        raise ValueError("Adresse refusée : https, ou une IA locale sur 127.0.0.1.")
    c = {"id": f"{fournisseur}-{secrets.token_hex(3)}", "fournisseur": fournisseur, "modele": modele.strip(),
         "url": url.strip(), "cle": _chiffrer(cle) if cle else ""}
    modeles = lister_modeles(c)                         # vérifie la clé avant d'enregistrer (erreur claire sinon)
    if not c["modele"] and modeles:
        c["modele"] = choisir_conseil(fournisseur, modeles)
    with _verrou:
        d = lire(data)
        d["connexions"].append(c)
        if not f.get("seulement"):                          # une IA de voix seule ne devient jamais le Superviseur
            d["superviseur"] = d["superviseur"] or c["id"]
            d["agents"] = d["agents"] or c["id"]
        _ecrire(data, d)
    return {"id": c["id"], "modeles": modeles, "modele": c["modele"]}


def modifier(data: Path, ident: str, **champs) -> None:
    with _verrou:
        d = lire(data)
        for k in ("superviseur", "agents"):
            if k in champs:
                v = str(champs[k] or "")
                if v and v not in ("claude-code", "codex") and v not in {c["id"] for c in d["connexions"]}:
                    raise ValueError("Connexion inconnue.")
                d[k] = v
        if ident and "modele" in champs:
            for c in d["connexions"]:
                if c["id"] == ident:
                    c["modele"] = str(champs["modele"] or "")
        _ecrire(data, d)


def retirer(data: Path, ident: str) -> None:
    with _verrou:
        d = lire(data)
        d["connexions"] = [c for c in d["connexions"] if c["id"] != ident]
        for k in ("superviseur", "agents"):
            if d[k] == ident:
                d[k] = d["connexions"][0]["id"] if d["connexions"] else ""
        _ecrire(data, d)


def connexion(data: Path, ident: str) -> dict | None:
    return next((c for c in lire(data)["connexions"] if c["id"] == ident), None)


# ------------------------------------------------------------------ appels HTTP (format chat completions)
def _base(c: dict) -> str:
    return (c.get("url") or FOURNISSEURS[c["fournisseur"]]["url"]).rstrip("/")


def _entetes(c: dict) -> dict:
    h = {"Content-Type": "application/json", "User-Agent": "SuperAIStudio"}
    cle = _dechiffrer(c.get("cle", ""))
    if cle:
        h["Authorization"] = f"Bearer {cle}"
        if c["fournisseur"] == "anthropic":
            h["x-api-key"] = cle
            h["anthropic-version"] = "2023-06-01"
        elif c["fournisseur"] == "elevenlabs":
            h["xi-api-key"] = cle
    return h


def _ollama_ferme(c: dict, e: Exception) -> bool:
    """Connexion refusée par l'Ollama de ce PC (fermé) : la requête n'est jamais arrivée, on peut l'ouvrir et réessayer."""
    from urllib.parse import urlparse
    raison = getattr(e, "reason", e)
    return (c.get("fournisseur") == "ollama" and isinstance(raison, ConnectionRefusedError)
            and (urlparse(_base(c)).hostname or "") in ("127.0.0.1", "localhost", "::1"))


def _requete(c: dict, chemin: str, corps: dict | None = None, delai: float = 300, _reessai: bool = True) -> dict:
    req = urllib.request.Request(_base(c) + chemin, headers=_entetes(c), method="POST" if corps is not None else "GET",
                                 data=json.dumps(corps).encode() if corps is not None else None)
    try:
        with urllib.request.urlopen(req, timeout=delai) as r:
            brut = r.read() or b"{}"
        try:
            d = json.loads(brut)
        except ValueError:
            raise ErreurIA(f"{FOURNISSEURS[c['fournisseur']]['nom']} : réponse illisible") from None
        return d if isinstance(d, dict) else {"data": d}
    except urllib.error.HTTPError as e:
        try:
            detail = json.loads(e.read() or b"{}")
            if isinstance(detail, list):                     # Gemini : [{"error": {...}}]
                detail = detail[0] if detail and isinstance(detail[0], dict) else {}
            err = detail.get("error") if isinstance(detail, dict) else None
            msg = err.get("message") if isinstance(err, dict) else (err or "")
        except (ValueError, AttributeError):
            msg = ""
        from .security import redact
        texte = {401: "clé refusée", 403: "accès refusé", 404: "adresse ou modèle introuvable", 429: "limite atteinte (quota)"}.get(e.code, f"erreur {e.code}")
        raise ErreurIA(f"{FOURNISSEURS[c['fournisseur']]['nom']} : {texte}" + (f" — {redact(str(msg))[:200]}" if msg else "")) from None
    except (urllib.error.URLError, OSError, TimeoutError) as e:
        if _reessai and _ollama_ferme(c, e):
            from . import modeles_locaux
            if modeles_locaux.assurer():                       # Ollama s'ouvre au moment où il sert
                return _requete(c, chemin, corps, delai, _reessai=False)
        local = not FOURNISSEURS[c["fournisseur"]]["cle"]
        raise ErreurIA(f"{FOURNISSEURS[c['fournisseur']]['nom']} ne répond pas"
                       + (" : lance-le sur ce PC." if local else f" ({type(e).__name__}).")) from None


def lister_modeles(c: dict) -> list[str]:
    d = _requete(c, "/models", delai=20)
    ids = [str(m.get("id") or m.get("model_id") or "") for m in (d.get("data") or d.get("models") or []) if isinstance(m, dict)]
    return sorted({i.removeprefix("models/") for i in ids if i})


def choisir_conseil(fournisseur: str, modeles: list[str]) -> str:
    conseil = FOURNISSEURS[fournisseur]["conseil"]
    return next((m for m in modeles if conseil and m.startswith(conseil)), modeles[0] if modeles else "")


FAMILLES = {"openai": "OpenAI (clé API)", "anthropic": "Anthropic (clé API)", "gemini": "Gemini", "mistral": "Mistral",
            "openrouter": "OpenRouter", "deepseek": "DeepSeek", "groq": "Groq", "xai": "xAI (Grok)", "moonshot": "Moonshot (Kimi)",
            "ollama": "Ollama (local)", "lmstudio": "LM Studio (local)"}


def famille(c: dict) -> str:
    """Nom de l'IA dans Gestion › Usage (les abonnements Claude Code et Codex restent « Claude » et « Codex »)."""
    if c.get("fournisseur") == "autre":                 # IA personnalisée : son adresse la nomme ; locale = gratuite
        from urllib.parse import urlparse
        hote = urlparse(c.get("url", "")).hostname or "IA"
        return f"{hote} (local)" if hote in ("127.0.0.1", "localhost", "::1") else hote
    return FAMILLES.get(c.get("fournisseur", ""), c.get("fournisseur", "") or "IA connectée")


# ------------------------------------------------------------------ Ollama : API native (taille de contexte réglée)
_contextes: dict[str, int] = {}


def _hote_ollama(c: dict) -> str:
    b = _base(c)
    return b[:-3] if b.endswith("/v1") else b


def contexte_max(c: dict) -> int:
    """Contexte maximal du modèle local (lu une fois par modèle dans Ollama) ; 0 si inconnu."""
    m = c.get("modele", "")
    if m in _contextes:
        return _contextes[m]
    n = 0
    if c.get("fournisseur") == "ollama":
        try:
            req = urllib.request.Request(_hote_ollama(c) + "/api/show", data=json.dumps({"model": m}).encode(),
                                         headers={"Content-Type": "application/json"}, method="POST")
            with urllib.request.urlopen(req, timeout=10) as r:
                info = json.loads(r.read() or b"{}").get("model_info") or {}
            n = max((int(v) for k, v in info.items() if k.endswith(".context_length") and isinstance(v, (int, float))), default=0)
        except (OSError, ValueError):
            n = 0
    if n:                                               # Ollama fermé : on redemandera la prochaine fois
        _contextes[m] = n
    return n


def _discuter_ollama(c: dict, messages: list[dict], outils: list[dict] | None, delai: float, contexte: int, effort: str = "") -> dict:
    """API native d'Ollama (/api/chat) : seule façon de choisir la taille du contexte (num_ctx). Sans ce réglage,
    Ollama garde son petit contexte par défaut et coupe le début de la mission SANS PRÉVENIR. Même format de retour
    que « chat completions »."""
    noms = {}
    natifs = []
    for m in messages:
        m = dict(m)
        if m.get("role") == "assistant" and m.get("tool_calls"):
            appels = []
            for a in m["tool_calls"]:
                f = a.get("function") or {}
                args = f.get("arguments")
                if isinstance(args, str):
                    try:
                        args = json.loads(args or "{}")
                    except ValueError:
                        args = {}
                noms[a.get("id", "")] = f.get("name", "")
                appels.append({"function": {"name": f.get("name", ""), "arguments": args or {}}})
            m["tool_calls"] = appels
        elif m.get("role") == "tool":
            m = {"role": "tool", "content": m.get("content", ""), "tool_name": noms.get(m.get("tool_call_id", ""), "")}
        natifs.append(m)
    corps = {"model": c["modele"], "messages": natifs, "stream": False, "keep_alive": "10m"}
    if outils:
        corps["tools"] = outils
    if effort and (c.get("fournisseur"), c.get("modele")) not in _sans_effort:   # modèles qui réfléchissent (Qwen3, DeepSeek-R1…)
        corps["think"] = effort != "low"
    if contexte:
        corps["options"] = {"num_ctx": int(contexte)}
    hote = {**c, "url": _hote_ollama(c)}
    d = _requete(hote, "/api/chat", corps, delai)
    msg = d.get("message") or {}
    appels = [{"id": f"appel_{i}", "type": "function", "function": {"name": (a.get("function") or {}).get("name", ""),
                                                                   "arguments": json.dumps((a.get("function") or {}).get("arguments") or {}, ensure_ascii=False)}}
              for i, a in enumerate(msg.get("tool_calls") or [])]
    return {"message": {"role": "assistant", "content": msg.get("content") or "", **({"tool_calls": appels} if appels else {})},
            "usage": {"prompt_tokens": int(d.get("prompt_eval_count") or 0), "completion_tokens": int(d.get("eval_count") or 0)},
            "fin": d.get("done_reason", "")}


_sans_effort: set[tuple] = set()                       # modèles qui refusent le réglage d'effort : plus redemandé
_NIVEAU_API = {"low": "low", "medium": "medium", "high": "high", "xhigh": "high", "max": "high"}


def discuter(c: dict, messages: list[dict], outils: list[dict] | None = None, delai: float = 300, contexte: int = 0,
             effort: str = "") -> dict:
    """Un tour de conversation ; renvoie le message de l'IA (content, tool_calls) et l'usage.
    contexte : taille du contexte à réserver (modèles locaux Ollama ; ignoré ailleurs).
    effort : profondeur de raisonnement (low | medium | high…) traduite pour chaque fournisseur qui la connaît
    (OpenRouter pour tous ses modèles, OpenAI, Gemini, Ollama « think ») ; un modèle qui la refuse est relancé sans."""
    effort = _NIVEAU_API.get(effort, "")
    if effort and (c.get("fournisseur"), c.get("modele")) not in _sans_effort:
        try:
            return _discuter(c, messages, outils, delai, contexte, effort)
        except ErreurIA as e:
            if not re.search(r"reason|think|effort|unsupported|not support|unknown|invalid|400", str(e), re.I):
                raise
            _sans_effort.add((c.get("fournisseur"), c.get("modele")))
    return _discuter(c, messages, outils, delai, contexte, "")


def _discuter(c: dict, messages: list[dict], outils: list[dict] | None, delai: float, contexte: int, effort: str) -> dict:
    if not c.get("modele"):
        raise ErreurIA("Aucun modèle choisi pour cette connexion (Accueil › Réglages › IA).")
    if c.get("fournisseur") == "ollama":
        if not contexte:                                # Superviseur, appels ponctuels : juste ce qu'il faut, par paliers
            taille = sum(len(str(m.get("content") or "")) for m in messages) + len(json.dumps(outils or []))
            contexte = min(contexte_max(c) or 32768, 32768, max(8192, -(-(taille // 3 + 4096) // 4096) * 4096))
        return _discuter_ollama(c, messages, outils, delai, contexte, effort)
    corps: dict = {"model": c["modele"], "messages": messages}
    if outils:
        corps["tools"] = outils
    if effort:
        if c.get("fournisseur") == "openrouter":
            corps["reasoning"] = {"effort": effort}
        elif c.get("fournisseur") in ("openai", "gemini"):
            corps["reasoning_effort"] = effort
    if c.get("fournisseur") == "openrouter":            # OpenRouter renvoie alors le coût réel de l'appel (usage.cost)
        corps["usage"] = {"include": True}
    d = _requete(c, "/chat/completions", corps, delai)
    choix = (d.get("choices") or [{}])[0]
    return {"message": choix.get("message") or {}, "usage": d.get("usage") or {}, "fin": choix.get("finish_reason", "")}


def _brut(c: dict, chemin: str, corps: dict, delai: float = 300) -> bytes:
    req = urllib.request.Request(_base(c) + chemin, headers=_entetes(c), method="POST", data=json.dumps(corps).encode())
    try:
        with urllib.request.urlopen(req, timeout=delai) as r:
            return r.read()
    except urllib.error.HTTPError as e:
        raise ErreurIA(f"{FOURNISSEURS[c['fournisseur']]['nom']} : erreur {e.code} ({chemin})") from None
    except (urllib.error.URLError, OSError, TimeoutError) as e:
        raise ErreurIA(f"{FOURNISSEURS[c['fournisseur']]['nom']} ne répond pas ({type(e).__name__}).") from None


# ------------------------------------------------------------------ images et voix : n'importe quelle IA qui sait le faire
CAPABLES = {"image": ("openai", "gemini", "xai", "openrouter", "autre"),
            "voix": ("openai", "elevenlabs", "groq", "autre")}
_MOTIFS = {"image": ("gpt-image", "imagen", "flash-image", "image", "dall-e", "flux", "sdxl", "stable-diffusion"),
           "voix": ("tts", "speech", "eleven", "voice", "kokoro")}


def _modele_pour(c: dict, genre: str) -> str:
    if c.get(f"modele_{genre}"):
        return c[f"modele_{genre}"]
    try:
        noms = lister_modeles(c)
    except ErreurIA:
        noms = []
    for motif in _MOTIFS[genre]:
        trouve = sorted((m for m in noms if motif in m.lower()), reverse=True)
        if trouve:
            return trouve[0]
    return {("openai", "image"): "gpt-image-1", ("gemini", "image"): "imagen-4.0-generate-001", ("xai", "image"): "grok-2-image",
            ("openrouter", "image"): "google/gemini-2.5-flash-image", ("openai", "voix"): "gpt-4o-mini-tts",
            ("elevenlabs", "voix"): "eleven_multilingual_v2"}.get((c.get("fournisseur"), genre), "")


def modele_image(c: dict) -> str:
    return _modele_pour(c, "image")


def connexion_pour(data: Path, genre: str, prefere: dict | None = None) -> dict | None:
    """Connexion capable de produire ce genre (« image » ou « voix ») : celle de l'agent si elle sait, sinon la
    première connectée qui sait. Le moins restrictif possible : toute IA compatible OpenAI (cloud ou locale) est essayée."""
    if prefere and prefere.get("fournisseur") in CAPABLES[genre]:
        return prefere
    return next((c for c in lire(data)["connexions"] if c["fournisseur"] in CAPABLES[genre]), None)


def _octets_image(item: dict) -> bytes:
    if item.get("b64_json"):
        return base64.b64decode(item["b64_json"])
    url = str(item.get("url") or (item.get("image_url") or {}).get("url") or "")
    if url.startswith("data:image") and "," in url:
        return base64.b64decode(url.split(",", 1)[1])
    if url.startswith("https://"):
        with urllib.request.urlopen(url, timeout=120) as r:
            return r.read()
    raise ErreurIA("Aucune image renvoyée.")


def generer_image(c: dict, prompt: str, taille: str = "1024x1024") -> bytes:
    """Image PNG générée par l'IA connectée : OpenAI, Gemini, xAI, OpenRouter (modèles d'image en conversation), ou
    toute IA compatible OpenAI (/images/generations, ex. LocalAI sur le PC). Rien n'est publié."""
    modele = modele_image(c)
    if c.get("fournisseur") == "openrouter":            # OpenRouter : modèles d'image via la conversation
        d = _requete(c, "/chat/completions", {"model": modele, "messages": [{"role": "user", "content": prompt[:4000]}],
                                              "modalities": ["image", "text"]}, 300)
        images = ((d.get("choices") or [{}])[0].get("message") or {}).get("images") or []
        if not images:
            raise ErreurIA("Ce modèle n'a pas renvoyé d'image : choisis un modèle d'image (OpenRouter).")
        return _octets_image(images[0])
    corps = {"model": modele, "prompt": prompt[:4000], "n": 1}
    if c.get("fournisseur") != "xai":
        corps["size"] = taille
    if not str(modele).startswith("gpt-image"):
        corps["response_format"] = "b64_json"
    d = json.loads(_brut(c, "/images/generations", corps) or b"{}")
    return _octets_image((d.get("data") or [{}])[0])


def generer_voix(c: dict, texte: str, voix: str = "") -> bytes:
    """Fichier MP3 de synthèse vocale : OpenAI, Groq, ElevenLabs, ou toute IA compatible OpenAI (/audio/speech,
    ex. un serveur de voix local)."""
    if c.get("fournisseur") == "elevenlabs":
        if not voix:
            voix = (_requete(c, "/voices", delai=20).get("voices") or [{}])[0].get("voice_id", "")
        if not voix:
            raise ErreurIA("ElevenLabs : aucune voix disponible sur ce compte.")
        return _brut(c, f"/text-to-speech/{voix}", {"text": texte[:5000], "model_id": _modele_pour(c, "voix")})
    return _brut(c, "/audio/speech", {"model": _modele_pour(c, "voix"), "voice": voix or "alloy", "input": texte[:4000],
                                      "response_format": "mp3"})


def detecter_locales() -> list[str]:
    """IA locales qui répondent maintenant (rien n'est lancé ni installé)."""
    out = []
    for k in ("ollama", "lmstudio"):
        try:
            with urllib.request.urlopen(FOURNISSEURS[k]["url"] + "/models", timeout=1):
                out.append(k)
        except OSError:
            pass
    return out


# ------------------------------------------------------------------ qui répond : Superviseur et agents
def choix(studio, pour: str) -> tuple[str, dict | None]:
    """("claude-code" | "codex" | "api" | "", connexion) pour « superviseur » ou « agents ».
    Réglage explicite d'abord ; sinon Claude Code s'il est installé ; sinon la première connexion."""
    d = lire(studio.paths.data)
    v = d.get(pour, "")
    if v in ("claude-code", "codex"):
        return v, None
    if v:
        c = next((x for x in d["connexions"] if x["id"] == v), None)
        if c:
            return "api", c
    from .connectors.claude_code import WIN_CANDIDATES
    from .connectors.base import find_exe
    if find_exe(studio.cfg["outils"].get("claude", "claude"), WIN_CANDIDATES):
        return "claude-code", None
    if d["connexions"]:
        return "api", d["connexions"][0]
    return "", None


def appel_superviseur(studio, c: dict, consigne: str, message: str) -> tuple[bool, str, dict]:
    from .espace import perso
    try:
        r = discuter(c, [{"role": "system", "content": perso(consigne)}, {"role": "user", "content": perso(message)}],
                     delai=float(studio.cfg.get("superviseur", {}).get("delai_s", 300)))
    except ErreurIA as e:
        return False, str(e), {}
    texte = r["message"].get("content") or ""
    if isinstance(texte, list):                         # certains fournisseurs renvoient des blocs
        texte = "".join(b.get("text", "") for b in texte if isinstance(b, dict))
    return bool(texte.strip()), texte or "Réponse vide.", {"jetons": r["usage"], "appel": True, "modele": c["modele"],
                                                           "famille": famille(c), "cout_usd": (r["usage"] or {}).get("cost")}
