﻿# Étape finale de l'installation (lancée par Installer-Studio.exe) : Python 3.12 si absent, environnement du studio,
# Claude Code si la case est cochée. Rien n'est installé en administrateur ; rien n'est supprimé.
param([Parameter(Mandatory = $true)][string]$App, [switch]$ClaudeCode)
# 'Continue' : sous l'installateur, la sortie d'erreur des programmes (pip, python) devient des « erreurs » PowerShell ;
# chaque étape est donc vérifiée par son code de retour ($LASTEXITCODE), et les commandes PowerShell par -ErrorAction Stop.
$ErrorActionPreference = 'Continue'
$ProgressPreference = 'SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Set-Location -LiteralPath $App -ErrorAction Stop
trap { Write-Output "Erreur : $($_.Exception.Message)"; exit 1 }

function Trouver-Python {
    $py = Get-Command py -ErrorAction SilentlyContinue
    if ($py) {
        $exe = (& py -3.12-64 -c "import sys; print(sys.executable)" 2>$null | Select-Object -First 1)
        if ($LASTEXITCODE -eq 0 -and $exe) { return ([string]$exe).Trim() }
    }
    $pf = if ($env:ProgramW6432) { $env:ProgramW6432 } else { $env:ProgramFiles }
    foreach ($p in @("$env:LOCALAPPDATA\Programs\Python\Python312\python.exe", "$pf\Python312\python.exe")) {
        if (Test-Path $p) {
            $bits = (& $p -c "import struct; print(struct.calcsize('P') * 8)" 2>$null | Select-Object -First 1)
            if ($LASTEXITCODE -eq 0 -and "$bits".Trim() -eq '64') { return $p }      # composants fournis : Windows 64 bits
        }
    }
    return $null
}

$python = Trouver-Python
if (-not $python) {
    Write-Output 'Python 3.12 absent : téléchargement depuis python.org…'
    $setup = Join-Path $env:TEMP 'python-3.12.10-amd64.exe'
    Invoke-WebRequest -UseBasicParsing 'https://www.python.org/ftp/python/3.12.10/python-3.12.10-amd64.exe' -OutFile $setup -ErrorAction Stop
    $sig = Get-AuthenticodeSignature $setup
    if ($sig.Status -ne 'Valid' -or $sig.SignerCertificate.Subject -notmatch 'Python Software Foundation') {
        throw 'Le fichier téléchargé n''est pas signé par la Python Software Foundation : installation arrêtée.'
    }
    Write-Output 'Installation de Python 3.12 (pour toi seulement, sans droits administrateur)…'
    $p = Start-Process -Wait -PassThru $setup -ArgumentList '/quiet', 'InstallAllUsers=0', 'PrependPath=0', 'Include_launcher=0',
        'Include_test=0', 'Shortcuts=0', 'AssociateFiles=0'
    if ($p.ExitCode -ne 0) { throw "Installation de Python en échec (code $($p.ExitCode))." }
    $python = Trouver-Python
    if (-not $python) { throw 'Python 3.12 introuvable après installation.' }
}
Write-Output "Python : $python"

$venv = Join-Path $App '.venv'
if (-not (Test-Path (Join-Path $venv 'Scripts\python.exe'))) {
    Write-Output 'Préparation de l''environnement du studio…'
    & $python -m venv $venv
    if ($LASTEXITCODE) { throw 'Création de l''environnement Python impossible.' }
}
Write-Output 'Installation des composants du studio (hors ligne)…'
& (Join-Path $venv 'Scripts\python.exe') -m pip install --disable-pip-version-check --no-warn-script-location --no-index --find-links (Join-Path $App 'wheels') -r (Join-Path $App 'requirements.lock.txt')
if ($LASTEXITCODE) { throw 'Installation des composants en échec.' }
& (Join-Path $venv 'Scripts\python.exe') -c "import studio.launcher, langgraph; print('Studio prêt')"
if ($LASTEXITCODE) { throw 'Vérification du studio en échec.' }
# Les composants sont déjà installés depuis le verrou ; un moteur système manquant conserve le repli.
& (Join-Path $venv 'Scripts\python.exe') -c "import webview, clr; print('Fenêtre native préparée')"
if ($LASTEXITCODE) { Write-Output 'Fenêtre native indisponible sur ce PC : le studio utilisera son repli navigateur.' }

if ($ClaudeCode) {
    if ((Get-Command claude -ErrorAction SilentlyContinue) -or (Test-Path "$env:USERPROFILE\.local\bin\claude.exe")) {
        Write-Output 'Claude Code est déjà installé.'
    } else {
        Write-Output 'Installation de Claude Code (installateur officiel d''Anthropic)…'
        # processus séparé : son script ne peut ni arrêter cette installation ni changer ses réglages
        & powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "irm https://claude.ai/install.ps1 | iex"
        if ($LASTEXITCODE) { Write-Output "Claude Code n'a pas pu être installé (code $LASTEXITCODE). Tu pourras le faire plus tard." }
    }
}
Write-Output 'Installation terminée.'
exit 0
