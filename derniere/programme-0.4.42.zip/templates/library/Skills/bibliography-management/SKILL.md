---
name: bibliography-management
description: Constituer et tenir une bibliographie fiable — recherche dans des sources reconnues, vérification de chaque référence, fiches de lecture, citations dans le texte et bibliographie au style demandé (APA, ISO 690, Chicago…). À utiliser pour un mémoire, une thèse, un article, un rapport ou un dossier documentaire.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Gérer une bibliographie

## Méthode
1. **Question et mots-clés** : sujet en une phrase, mots-clés en français et en anglais, période et types de documents utiles.
2. **Sources** : catalogues et bases reconnus (bibliothèque universitaire, SUDOC, HAL, theses.fr, Persée, OpenEdition, arXiv, PubMed selon la discipline) ; noter la requête et la date de chaque recherche.
3. **Vérifier chaque référence** : auteur, titre, année, revue ou éditeur, pages, DOI ou adresse ; ouvrir la source avant de la citer. Une référence introuvable est marquée « non vérifiée » et n'est pas citée.
4. **Gestionnaire de références** : tout ranger dans un outil (Zotero par exemple), avec étiquettes par chapitre et le PDF quand il est librement accessible.
5. **Fiches de lecture** : question traitée, méthode, résultats, limites, citations exactes avec la page.
6. **Rédaction** : citation dans le texte au format demandé, bibliographie générée par l'outil, contrôle final (chaque citation a sa référence et inversement).

## Livrable
- Bibliographie au style demandé, tableau de suivi des références (vérifiée oui/non, lue, utilisée dans le chapitre…) et fiches de lecture.

## Règles
- Ne jamais inventer une référence, un DOI, une page ou une citation ; distinguer ce que dit la source et ce que l'utilisateur en déduit.
- Citer entre guillemets et avec la page tout passage repris mot pour mot ; signaler le risque de plagiat.
- Pour un travail noté, aider à chercher, organiser et vérifier, sans rédiger le travail à la place de l'étudiant.
