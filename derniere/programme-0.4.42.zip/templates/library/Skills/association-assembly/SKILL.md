---
name: association-assembly
description: Préparer l'assemblée générale ou le conseil d'administration d'une association — convocation, ordre du jour, rapports moral et financier, résolutions, feuille de présence, pouvoirs, procès-verbal. À utiliser pour une AG ordinaire ou extraordinaire, un CA, un bureau ou une réunion d'adhérents.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Assemblée générale d'association

## Méthode
1. **Statuts d'abord** : relire les règles de l'association (délai et forme de convocation, quorum, majorités, vote par procuration ou à distance) ; elles priment sur tout modèle.
2. **Convocation** : date, heure, lieu ou lien, ordre du jour, documents joints, modalités de pouvoir ; envoyée dans le délai prévu par les statuts.
3. **Documents** : rapport moral (activités de l'année), rapport financier (comptes, budget prévisionnel), propositions de résolutions numérotées, candidatures aux instances.
4. **Séance** : feuille d'émargement, pouvoirs, vérification du quorum, président et secrétaire de séance, vote de chaque résolution (pour, contre, abstention).
5. **Procès-verbal** : date, présents et représentés, quorum, résumé des débats, résultat de chaque vote, signatures prévues par les statuts.
6. **Après** : déclaration des changements de dirigeants ou de statuts en préfecture dans les délais (démarche en ligne décrite sur service-public.fr et associations.gouv.fr), mise à jour du registre spécial si l'association en tient un.

## Règles
- Ne jamais inventer une règle de quorum ou de majorité : la lire dans les statuts, sinon le signaler.
- Données des adhérents : seulement l'utile, pas de diffusion de la liste complète sans accord.
- Outil d'organisation, pas de conseil juridique.
