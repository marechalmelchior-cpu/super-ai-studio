---
name: easy-to-read
description: Réécrire un texte en langage clair ou en « Facile à lire et à comprendre » (FALC) — phrases courtes, mots simples, une idée par phrase, mise en page aérée, images d'appui — et préparer la relecture par des personnes concernées. À utiliser pour un courrier administratif, un règlement, une notice, une page web, un document d'association ou de santé publique.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Langage clair et FALC

## Méthode
1. **Public** : qui va lire (personnes avec un handicap intellectuel, personnes âgées, personnes qui apprennent le français, grand public pressé) ; le FALC vise surtout les premières.
2. **Essentiel** : ce que le lecteur doit savoir ou faire, dans l'ordre où il en a besoin ; retirer le reste.
3. **Écriture** : phrases courtes, une idée par phrase, mots courants (expliquer un mot difficile quand il est indispensable), voix active, chiffres en chiffres, pas d'abréviation ni de sigle sans explication.
4. **Mise en page** : police sans empattements assez grande, texte aligné à gauche, une phrase par ligne en FALC, titres clairs, listes, images ou pictogrammes qui illustrent chaque idée importante.
5. **Relecture** : en FALC, le texte est relu par des personnes concernées avant d'utiliser le logo officiel.

## Sources
- « L'information pour tous. Règles européennes pour une information facile à lire et à comprendre », Inclusion Europe et Unapei (2009), consultables sur unapei.org et inclusion-europe.eu (consultés le 2026-10-29).

## Règles
- Ne pas changer le sens : pour un texte juridique ou médical, garder le document d'origine en référence et le signaler.
- Ne pas apposer le logo FALC sans la relecture prévue par ses règles d'usage.
