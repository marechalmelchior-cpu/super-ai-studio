---
name: quiz-builder
description: Créer des quiz et des évaluations — QCM, vrai/faux, réponses courtes, appariements, questions ouvertes — avec corrigé, barème, explications et export pour une plateforme (Moodle au format GIFT, tableur, document imprimable). À utiliser pour vérifier des connaissances, préparer un contrôle, une révision ou un module de formation.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Créer un quiz

## Méthode
1. **Objectifs évalués** : une liste de compétences ou notions ; chaque question en vise une seule.
2. **Mélange de niveaux** : restituer, comprendre, appliquer, analyser ; indiquer le niveau de chaque question.
3. **Rédaction** :
   - consigne courte et sans double négation ;
   - QCM : une seule bonne réponse sauf mention contraire, distracteurs plausibles issus d'erreurs fréquentes, pas de « toutes les réponses » ;
   - réponses courtes : liste des réponses acceptées (orthographes, unités).
4. **Corrigé** : bonne réponse, explication en une ou deux phrases, renvoi au cours.
5. **Barème** et durée conseillée.
6. **Export** : document élève sans réponses, corrigé séparé, fichier GIFT pour Moodle ou tableur pour une autre plateforme.

## Exemple GIFT
```
::Q1 Capitale:: Quelle est la capitale de l'Italie ? { =Rome ~Milan ~Naples ~Turin }
```

## Règles
- Vérifier chaque réponse ; une question ambiguë est réécrite, pas gardée.
- Pas de données nominatives d'élèves dans les fichiers produits.
- Accessibilité : texte lisible, images décrites, pas de question qui dépend seulement de la couleur.
