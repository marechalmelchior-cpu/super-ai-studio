---
name: data-quality-check
description: Contrôler un fichier de données avant de l'analyser ou de le publier — structure, types, doublons, valeurs manquantes ou aberrantes, cohérence entre colonnes, totaux de contrôle — et documenter chaque correction. À utiliser à réception d'un export, avant un tableau de bord, un rapport chiffré ou un import dans un logiciel.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Contrôler la qualité des données

## Méthode
1. **Copie de travail** : ne jamais modifier le fichier reçu ; noter sa source, sa date et son nombre de lignes.
2. **Structure** : une ligne = un enregistrement, une colonne = une information ; en-têtes clairs, unités, séparateur et encodage, dates dans un seul format.
3. **Contrôles par colonne** : type attendu, valeurs vides, valeurs hors plage (âge négatif, date future), listes de valeurs (fautes de saisie, majuscules), identifiants uniques.
4. **Doublons** exacts et probables (même nom et même date, par exemple) : les signaler avant de les fusionner.
5. **Cohérence** entre colonnes (date de fin après date de début, total = somme des lignes) et avec une source de référence (total comptable, nombre d'adhérents connu).
6. **Journal** : chaque correction notée (règle appliquée, lignes touchées, avant/après) ; ce qui reste douteux est marqué, pas deviné.

## Livrable
- Fichier nettoyé (copie), rapport de contrôle d'une page (problèmes trouvés, corrections, points ouverts) et journal des corrections.

## Règles
- Aucune ligne supprimée ni valeur remplacée sans règle écrite et validée par l'utilisateur.
- Données personnelles : travailler sur le minimum de colonnes utiles ; pseudonymiser avant de partager.
- Indiquer clairement les limites (données manquantes, période couverte) dans tout résultat tiré du fichier.
