---
name: cash-flow-forecast
description: Construire un plan de trésorerie sur 3 à 12 mois — encaissements, décaissements, solde mois par mois, scénarios prudent et optimiste, alertes. À utiliser pour anticiper un creux, préparer un rendez-vous bancaire, décider d'un investissement ou d'une embauche.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Plan de trésorerie

## Méthode
1. **Point de départ** : solde bancaire réel à une date donnée.
2. **Encaissements** : ventes prévues (au moment du paiement, pas de la facture), acomptes, subventions, apports, remboursements de TVA.
3. **Décaissements** : charges fixes (loyer, abonnements, assurances, salaires et cotisations, remboursements d'emprunt), charges variables (achats liés aux ventes), impôts et TVA aux échéances connues, investissements.
4. **Tableau mensuel** : solde début + encaissements − décaissements = solde fin ; mise en évidence des mois sous un seuil choisi.
5. **Scénarios** : prudent (ventes −20 %, retards de paiement), central, optimiste ; hypothèses écrites en clair.
6. **Actions** : relances, échelonnement, report d'achat, découvert ou prêt à discuter avec la banque.

## Livrable
- Tableur avec onglet hypothèses, tableau mensuel, graphique du solde, note d'une page.

## Règles
- Toute prévision est une **déduction** à partir d'hypothèses : les afficher à côté des chiffres.
- Pas de conseil en investissement ni en financement : présenter les options, l'utilisateur décide avec sa banque ou son comptable.
- Ne pas mélanger HT et TTC : la trésorerie se calcule en TTC.
