---
name: bookkeeping-prep
description: Préparer la comptabilité pour l'expert-comptable ou le logiciel — rassembler et nommer les pièces, catégoriser les dépenses et recettes, rapprocher les relevés bancaires, lister les pièces manquantes. À utiliser chaque mois, avant une clôture ou avant un rendez-vous avec le comptable.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Préparer sa comptabilité

## Méthode
1. **Collecter** : relevés bancaires, factures de vente, factures d'achat, notes de frais, justificatifs de caisse, contrats récurrents.
2. **Nommer** les fichiers de façon constante : `AAAA-MM-JJ fournisseur montant.pdf`, un dossier par mois.
3. **Catégoriser** chaque opération (ventes, achats de marchandises, sous-traitance, loyers, énergie, télécom, déplacements, repas, matériel, honoraires, banque, taxes, salaires) selon le plan de catégories fourni par le comptable ou le logiciel.
4. **Rapprocher** banque et pièces : chaque ligne du relevé a son justificatif ; tableau des écarts (pièce manquante, montant différent, doublon).
5. **Signaler** les points à trancher par le comptable (achat mixte pro/perso, immobilisation possible, TVA incertaine).

## Livrable
- Classeur : opérations catégorisées, rapprochement, liste des pièces manquantes, questions pour le comptable.
- Dossier de pièces renommées, sans modifier les originaux.

## Règles
- Outil de préparation, **pas de conseil comptable ou fiscal** : les choix d'écriture et de TVA reviennent au comptable.
- Ne jamais modifier un justificatif ; travailler sur des copies.
- Les données bancaires restent sur le PC de l'utilisateur ; ne pas les envoyer à un service en ligne sans accord.
