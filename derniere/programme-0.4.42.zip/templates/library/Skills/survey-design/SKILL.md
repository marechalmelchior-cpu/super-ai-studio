---
name: survey-design
description: Concevoir un questionnaire ou une enquête et en analyser les réponses — objectifs, population, échantillon, questions neutres, échelles, test, diffusion, nettoyage des données, tris, croisements et limites. À utiliser pour une enquête de satisfaction, une étude de marché, une consultation d'adhérents, un mémoire ou une recherche.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Questionnaire et enquête

## Méthode
1. **Objectifs** : 3 à 5 questions de recherche ; chaque question du questionnaire sert l'une d'elles, sinon elle est retirée.
2. **Population et échantillon** : qui est visé, comment on l'atteint, taille visée ; biais prévisibles (seuls les plus motivés répondent).
3. **Questions** : une idée par question, vocabulaire simple, sans orientation (« Que pensez-vous de… » plutôt que « Êtes-vous satisfait de notre excellent… »), réponses exhaustives et exclusives, option « ne sait pas » si pertinent.
4. **Échelles** : 5 ou 7 points avec libellés à chaque niveau, ordre constant ; questions ouvertes en nombre limité.
5. **Ordre** : du général au particulier, questions sensibles à la fin, données socio-démographiques limitées au nécessaire.
6. **Test** auprès de 5 personnes, puis corrections.
7. **Analyse** : nettoyage (doublons, réponses incohérentes), tris à plat, croisements, marges d'erreur indicatives, verbatims ; limites écrites.

## Livrable
- Questionnaire prêt à importer (LimeSurvey, formulaires, tableur), plan d'analyse, rapport avec graphiques.

## Règles
- Information des répondants (finalité, anonymat ou non, durée de conservation) et consentement ; pas de question sur des données sensibles sans nécessité et base légale.
- Ne pas présenter un échantillon non représentatif comme représentatif.
