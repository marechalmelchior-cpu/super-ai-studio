---
name: invoice-preparation
description: Préparer et contrôler des factures — mentions obligatoires, numérotation continue, TVA, échéances, avoirs — et se préparer à la facturation électronique. À utiliser pour émettre une facture, vérifier un modèle de facture ou corriger une facture déjà envoyée (par avoir). Complète la skill « freelance-management ».
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Préparer une facture

## Méthode
1. **Reprendre la source** : devis signé, bon de commande ou relevé d'heures ; quantités et prix tels qu'acceptés.
2. **Mentions** (France, à vérifier pour le statut de l'utilisateur) : numéro unique dans une suite chronologique continue, date d'émission, identité et adresse du vendeur et du client, SIREN/SIRET, numéro de TVA intracommunautaire s'il existe, désignation précise, quantité, prix unitaire HT, taux et montant de TVA (ou mention d'exonération, par exemple « TVA non applicable, art. 293 B du CGI » en franchise), totaux HT et TTC, date de la prestation ou de la livraison, date d'échéance, conditions d'escompte, taux des pénalités de retard et, entre professionnels, l'indemnité forfaitaire pour frais de recouvrement.
3. **Contrôle** : calculs refaits, numéro jamais réutilisé, pas de facture modifiée après envoi (on émet un **avoir** puis une nouvelle facture).
4. **Suivi** : tableau facture / client / montant / échéance / payé le / relance.

## Facturation électronique (France)
Calendrier publié par l'administration (vérifié le 2026-10-29, à revérifier) : réception des factures électroniques obligatoire pour toutes les entreprises depuis le 1er septembre 2026 ; émission obligatoire depuis le 1er septembre 2026 pour les grandes entreprises et les ETI, à partir du 1er septembre 2027 pour les PME et micro-entreprises. Source : economie.gouv.fr (dossier « facturation électronique ») et impots.gouv.fr. Préparer les nouvelles mentions annoncées (SIREN du client, adresse de livraison si différente, nature biens ou services, option pour la TVA sur les débits) et le choix d'une plateforme agréée.

## Règles
- Ne jamais inventer un numéro légal, un taux ou une mention : laisser un champ à remplir et le signaler.
- Aucune facture envoyée, aucun paiement déclenché sans validation de l'utilisateur.
- Pour une question fiscale précise (TVA particulière, international) : le dire et renvoyer vers l'expert-comptable.
