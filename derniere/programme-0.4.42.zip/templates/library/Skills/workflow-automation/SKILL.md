---
name: workflow-automation
description: Concevoir une automatisation avant de la construire — décrire le déclencheur, les étapes, les données, les erreurs et les contrôles, puis choisir l'outil (script, tableur, n8n, Make, Zapier, Power Automate…). À utiliser pour supprimer une tâche répétitive, relier deux logiciels ou fiabiliser un traitement manuel.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Concevoir une automatisation

## Méthode
1. **Observer la tâche actuelle** : qui la fait, combien de fois, combien de temps, ce qui coince. Si elle prend moins de temps à faire qu'à automatiser sur un an, le dire.
2. **Décrire le flux** : déclencheur (heure, nouveau fichier, formulaire, mail reçu), étapes numérotées, données entrantes et sortantes, résultat attendu.
3. **Cas d'erreur** : donnée manquante, doublon, service indisponible, quota atteint ; pour chacun, que faire (réessayer, mettre de côté, prévenir quelqu'un).
4. **Points de contrôle humain** : toute étape qui envoie, publie, paie ou supprime passe par une validation, au moins au début.
5. **Choix de l'outil** : le plus simple qui suffit (formule de tableur, script local, outil d'automatisation déjà utilisé). Indiquer gratuit / payant / compte requis.
6. **Test** : jeu de données d'essai, exécution à blanc, journal des actions, puis mise en service progressive.

## Livrable
- Fiche du flux (schéma en étapes, tableau des données, cas d'erreur, contrôles).
- Si demandé : le script ou la configuration, avec un mode « essai » qui n'écrit rien.

## Règles
- Les clés et mots de passe restent dans le coffre de l'outil ou les variables chiffrées du studio, jamais dans le flux en clair.
- Pas de collecte de données personnelles sans base légale (voir le registre RGPD de l'utilisateur).
- Aucune automatisation mise en service sans accord explicite de l'utilisateur.
