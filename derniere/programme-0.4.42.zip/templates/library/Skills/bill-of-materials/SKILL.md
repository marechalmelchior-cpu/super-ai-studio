---
name: bill-of-materials
description: Établir et tenir une nomenclature (BOM) — repères, références fabricant, quantités, fournisseurs, prix, alternatives, disponibilité, versions — pour un montage électronique, une machine, un meuble ou un ouvrage. À utiliser pour chiffrer un prototype, préparer une commande, une petite série ou un dossier de fabrication.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Nomenclature (BOM)

## Méthode
1. **Structure** : nomenclature à plat pour un petit projet, par sous-ensembles pour un projet plus grand.
2. **Colonnes** : repère (R1, C3, vis-01), désignation, valeur ou dimension, boîtier ou norme, référence fabricant, fabricant, quantité par unité, unité, fournisseur et référence fournisseur, prix unitaire par palier de quantité, délai, alternative validée, remarque.
3. **Contrôle** : quantités recoupées avec le schéma ou le plan, pièces en fin de vie ou en rupture signalées, unités cohérentes.
4. **Chiffrage** : coût par unité pour 1, 10 et 100 exemplaires, avec frais de port et pertes.
5. **Versions** : numéro et date de révision, liste des changements.

## Livrable
- Tableur (CSV et XLSX) importable chez les fournisseurs et dans l'outil de conception (KiCad, FreeCAD), plus un résumé du coût.

## Règles
- Ne jamais inventer une référence ou une disponibilité : marquer « à vérifier » et citer la source et sa date.
- Aucune commande passée sans validation de l'utilisateur.
- Signaler les composants soumis à des règles particulières (batteries au lithium pour le transport, équipements radio, sécurité électrique).
