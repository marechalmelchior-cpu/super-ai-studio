---
name: meeting-minutes
description: Rédiger le compte rendu d'une réunion à partir de notes, d'une transcription ou d'un ordre du jour — décisions, actions avec responsable et échéance, points ouverts. À utiliser après une réunion, un conseil, un rendez-vous client ou pour préparer l'ordre du jour de la suivante.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Compte rendu de réunion

## Méthode
1. **Cadre** : titre, date, lieu ou visio, participants (présents, excusés), animateur, rédacteur.
2. **Ordre du jour** : reprendre les points prévus, dans l'ordre, et ajouter ceux traités en plus.
3. **Par point** : contexte en une ou deux phrases, ce qui a été dit (sans attribuer d'opinion à quelqu'un qui ne l'a pas exprimée), décision prise ou « pas de décision ».
4. **Actions** : tableau action / responsable / échéance / statut. Une action sans responsable ni date est signalée « à attribuer ».
5. **Points ouverts** : questions sans réponse, informations à obtenir, sujets reportés.
6. **Prochaine réunion** : date et ordre du jour proposé.

## Livrable
- Compte rendu d'une à deux pages (Word, PDF ou texte), le tableau des actions en tête si la réunion est opérationnelle.
- Version courte de 5 lignes prête à copier dans un message.

## Règles
- Distinguer ce qui a été **décidé**, **proposé** et **supposé** ; ne jamais inventer une décision.
- Ne pas recopier d'informations personnelles ou confidentielles inutiles (santé, salaire, conflit).
- Si la source est une transcription automatique, signaler les passages douteux au lieu de les deviner.
- Aucun envoi aux participants sans validation de l'utilisateur.
