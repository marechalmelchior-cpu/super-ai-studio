---
name: local-business-listing
description: Préparer et tenir à jour la présence en ligne d'un commerce de proximité, d'un artisan ou d'un restaurant — fiche d'établissement sur les cartes et annuaires, horaires (dont jours fériés et congés), photos, services, réponses aux questions et cohérence des informations partout. À utiliser à l'ouverture, à un changement d'horaires ou d'adresse, ou quand les clients trouvent de mauvaises informations.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Fiche d'établissement local

## Méthode
1. **Fiche de référence** (un seul document qui fait foi) : nom exact, adresse, téléphone, site, horaires habituels, horaires exceptionnels (jours fériés, congés), catégorie d'activité, zone desservie, services (livraison, retrait, accessibilité, paiements acceptés), description courte et longue.
2. **Inventaire** des endroits où l'établissement apparaît : services de cartes, annuaires, réseaux sociaux, plateformes de réservation ou de livraison, site de la commune ou de l'office de tourisme.
3. **Mise en cohérence** : tableau endroit / information affichée / écart / correction à faire / fait le ; l'utilisateur fait lui-même les modifications avec ses accès.
4. **Photos** : façade (pour être reconnu), intérieur, produits ou plats, équipe si elle est d'accord ; photos récentes, nommées clairement, avec texte alternatif (« alt-text »).
5. **Calendrier** : rappel avant chaque jour férié et période de congés pour mettre à jour les horaires partout ; revue complète chaque trimestre.
6. **Avis et questions** : réponses préparées pour les questions fréquentes ; avis traités avec la skill « customer-follow-up ».

## Livrable
- Fiche de référence, tableau de cohérence, textes de description et calendrier des mises à jour.

## Règles
- L'agent ne se connecte à aucun compte et ne publie rien : il prépare, l'utilisateur publie.
- Informations exactes uniquement : pas de fausse catégorie, de faux avis ni de mots-clés trompeurs dans le nom.
- Pas de photo de clients ou de salariés reconnaissables sans leur accord.
