---
name: 3d-print-prep
description: Préparer une pièce pour l'impression 3D — contraintes de conception, choix du procédé et de la matière, vérification du maillage, orientation, supports, réglages du trancheur, tolérances d'assemblage, fiche d'impression. À utiliser pour imprimer un prototype, une pièce de rechange, une figurine ou une petite série en FDM ou en résine.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Préparer une impression 3D

## Méthode
1. **Usage de la pièce** : efforts, chaleur, extérieur, contact alimentaire (dans ce cas, le dire : peu de filaments et de procédés conviennent, à vérifier auprès du fabricant).
2. **Matière** : PLA (facile, peu résistant à la chaleur), PETG (plus résistant), ABS/ASA (chaleur, extérieur, ventilation nécessaire), TPU (souple), résine (détails fins, manipulation avec gants et ventilation).
3. **Conception** : épaisseur de paroi au moins 2 fois la largeur de la buse, porte-à-faux sous 45° ou supports, jeux d'assemblage de 0,2 à 0,4 mm en FDM à valider par une éprouvette.
4. **Maillage** : fichier STL ou 3MF étanche, normales correctes, unités en millimètres, échelle vérifiée.
5. **Trancheur** : orientation (résistance dans le sens des couches), hauteur de couche, remplissage, nombre de parois, supports, bordure ; estimation du temps et de la matière.
6. **Fiche** : imprimante, matière, réglages, durée, résultat, défauts observés et corrections.

## Outils utiles
- FreeCAD, OpenSCAD, Blender (modélisation) ; PrusaSlicer, UltiMaker Cura, OrcaSlicer (trancheurs).

## Règles
- Ne pas imprimer d'objet interdit ou dangereux (armes, pièces de sécurité certifiées) ; signaler toute demande de ce type.
- Respecter la licence des modèles téléchargés (usage commercial ou non).
