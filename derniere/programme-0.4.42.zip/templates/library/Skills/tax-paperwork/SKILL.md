---
name: tax-paperwork
description: Organiser les démarches fiscales — calendrier des échéances, liste des pièces à réunir, tableau des montants à reporter, questions à poser — pour un particulier, un indépendant ou une petite structure. À utiliser avant une déclaration de revenus, de TVA ou de résultat. Outil d'organisation, pas de conseil fiscal.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Organiser ses démarches fiscales

## Méthode
1. **Situation** : particulier, micro-entrepreneur, société, association ; régime déclaré par l'utilisateur (ne pas le deviner).
2. **Calendrier** : échéances de l'année tirées des sources officielles (impots.gouv.fr, espace professionnel, URSSAF pour les micro-entrepreneurs), avec la date de consultation de la source.
3. **Pièces** : liste par rubrique (revenus, frais, dons, emploi à domicile, garde d'enfants, investissements, ventes, achats, TVA collectée et déductible) et statut reçu / manquant.
4. **Tableau de report** : montant, origine, case ou ligne indiquée par la notice officielle, justificatif associé.
5. **Questions** : points incertains à poser au service des impôts (messagerie sécurisée) ou à l'expert-comptable.

## Livrable
- Calendrier, check-list des pièces, tableau de report et liste de questions, en un classeur.

## Règles
- **Pas de conseil fiscal ni d'optimisation** : présenter ce que disent les notices officielles, citer la source et sa date.
- Les règles changent chaque année : revérifier sur impots.gouv.fr avant toute déclaration.
- Ne jamais se connecter à l'espace fiscal de l'utilisateur ni saisir ses identifiants : il déclare lui-même.
