---
name: accessible-event
description: Organiser une réunion, une formation, un spectacle ou une fête accessible au plus grand nombre — lieu, accès et circulation, information avant l'événement, supports, sous-titrage ou interprétation, accueil, version en ligne et retour des participants. À utiliser pour une association, une collectivité, une entreprise, une école ou un événement familial.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Événement accessible

## Méthode
1. **Besoins** : demander dans l'inscription, de façon facultative et ouverte, « avez-vous besoin d'un aménagement pour participer ? » ; prévoir aussi sans attendre les demandes (accès de plain-pied, places assises, pauses).
2. **Lieu** : accès en transports, places de stationnement adaptées, entrée sans marche ou rampe, ascenseur, toilettes accessibles, largeur des passages, éclairage, signalétique lisible, espace calme ; vérifier sur place, pas seulement sur la fiche du lieu.
3. **Information avant** : invitation en langage clair (« easy-to-read »), plan d'accès, horaires, déroulé, contact pour poser une question ; documents accessibles (« accessible-documents »).
4. **Pendant** : micro utilisé par tous les intervenants, boucle magnétique si disponible, supports projetés lisibles (taille, contraste), décrire oralement ce qui est montré, sous-titres en direct ou interprétation en langue des signes quand c'est demandé ou pour un public large.
5. **En ligne ou hybride** : outil avec sous-titres, documents envoyés avant, enregistrement sous-titré ensuite (« subtitles »).
6. **Après** : questionnaire de retour avec une question sur l'accessibilité ; noter ce qui a manqué pour la prochaine fois.

## Livrable
- Liste de contrôle par phase (avant, pendant, après), modèle d'invitation, fiche de repérage du lieu et budget des aménagements.

## Règles
- Ne jamais exiger de justificatif ni de précision médicale : on demande des besoins, pas des diagnostics ; ces informations restent confidentielles.
- Signaler honnêtement ce qui n'est pas accessible plutôt que de le taire.
- Les obligations propres aux établissements recevant du public relèvent du propriétaire ou de l'exploitant du lieu : les lister pour vérification, sans conseil juridique.
