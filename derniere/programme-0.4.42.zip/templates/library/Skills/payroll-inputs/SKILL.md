---
name: payroll-inputs
description: Préparer les éléments variables de paie à transmettre au gestionnaire de paie ou au logiciel — heures, absences, congés, primes, frais, entrées et sorties — et contrôler un bulletin reçu. À utiliser chaque fin de mois dans une petite structure ou une association employeuse.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Préparer les variables de paie

## Méthode
1. **Référentiel** : liste des salariés (identifiant interne, contrat, temps de travail, convention collective indiquée par l'employeur).
2. **Variables du mois** par salarié : heures normales et supplémentaires ou complémentaires, absences (type, dates, justificatif reçu oui/non), congés pris, primes prévues au contrat ou décidées, avantages, frais à rembourser, acomptes déjà versés.
3. **Mouvements** : entrées (date, contrat signé, déclaration préalable faite), sorties (date, motif, solde à prévoir).
4. **Contrôle** : cohérence avec le planning, totaux par service, écarts avec le mois précédent expliqués.
5. **Bulletin reçu** : comparer les variables transmises aux lignes du bulletin et lister les différences à poser au gestionnaire.

## Livrable
- Tableau mensuel des variables (un onglet par mois) et liste des questions pour le gestionnaire de paie.

## Règles
- **Aucun calcul légal de cotisations ni conseil en droit social** : c'est le rôle du gestionnaire de paie, du logiciel agréé ou de l'expert-comptable.
- Données personnelles et salariales : diffusion limitée aux personnes habilitées, pas de copie inutile, pas d'envoi à un service en ligne sans accord.
- Ne jamais deviner une convention collective, un taux ou un droit : poser la question.
