---
name: space-planning
description: Préparer un projet d'aménagement ou de construction — programme des besoins, relevé des surfaces, schéma de principe des pièces, circulations, accessibilité, budget indicatif, liste des démarches et des professionnels à consulter. À utiliser pour un réaménagement de logement, de bureau, de boutique ou de salle, ou pour préparer un rendez-vous avec un architecte.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Programme d'aménagement

## Méthode
1. **Besoins** : usages, nombre de personnes, horaires, contraintes (bruit, lumière, rangement, équipements), souhaits classés indispensable / souhaitable.
2. **Relevé** : plan coté existant (longueurs, hauteurs, ouvertures, réseaux), photos ; unité et échelle indiquées.
3. **Programme** : tableau des espaces (nom, surface souhaitée, relations avec les autres espaces, lumière, équipement).
4. **Schéma de principe** : 2 ou 3 variantes d'organisation (bulles, puis plan simple), circulations et passages libres.
5. **Accessibilité** : pour un établissement recevant du public, les règles d'accessibilité s'appliquent ; les citer depuis la source officielle (ecologie.gouv.fr, service-public.fr) avec la date.
6. **Budget** indicatif par poste, avec la mention « estimation à confirmer par devis ».
7. **Démarches** : déclaration préalable ou permis de construire selon les travaux (service-public.fr) ; recours à un architecte obligatoire pour une construction de plus de 150 m² de surface de plancher par un particulier (seuil en vigueur depuis le 1er mars 2017, à vérifier) ; copropriété, bailleur, assurance.

## Outils utiles
- Sweet Home 3D, LibreCAD, FreeCAD, QGIS (parcelles), Blender (visualisation).

## Règles
- Aucun calcul de structure, d'électricité ou de sécurité incendie : renvoyer vers les professionnels qualifiés.
- Distinguer relevé (fait), hypothèse et proposition.
