---
name: grading-rubric
description: Construire une grille d'évaluation critériée et rédiger des appréciations — critères, niveaux de maîtrise, descripteurs observables, barème, commentaires constructifs. À utiliser pour corriger des copies, des oraux, des projets, des stages, ou pour harmoniser la notation entre plusieurs correcteurs.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Grille d'évaluation

## Méthode
1. **Critères** : 3 à 6, issus des objectifs annoncés aux apprenants (fond, méthode, forme, communication…).
2. **Niveaux** : 4 niveaux (non atteint, partiellement, atteint, dépassé) ou l'échelle de l'établissement.
3. **Descripteurs** : pour chaque critère et niveau, ce qu'on observe concrètement dans le travail ; éviter « bien », « assez bien ».
4. **Barème** : poids de chaque critère, conversion en note si nécessaire.
5. **Appréciations** : une réussite précise, un point à améliorer, un conseil actionnable ; ton bienveillant et factuel.
6. **Harmonisation** : corriger à plusieurs deux ou trois copies témoins avant de corriger le reste.

## Livrable
- Grille imprimable et version tableur ; banque de commentaires réutilisables par critère.

## Règles
- L'évaluation reste la décision de l'enseignant ou du formateur : proposer, ne pas trancher.
- Aucune donnée nominative ni note réelle copiée dans un service en ligne sans accord.
- Commentaires sans jugement sur la personne.
