---
name: project-plan
description: Construire le plan d'un projet — objectifs, livrables, découpage en tâches, planning, responsabilités (RACI), budget, risques et suivi. À utiliser pour lancer un projet, cadrer une demande client, préparer un rétroplanning ou faire le point d'avancement.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Plan de projet

## Méthode
1. **Cadrage** : objectif en une phrase, pour qui, critères de réussite mesurables, ce qui est hors périmètre.
2. **Livrables** : liste des résultats concrets attendus, chacun avec son critère d'acceptation.
3. **Découpage** : tâches de 0,5 à 5 jours, regroupées par livrable ; dépendances notées (« B commence quand A est fini »).
4. **Planning** : dates de début et de fin, jalons, marge pour les imprévus (10 à 20 %) ; rétroplanning si la date de fin est imposée.
5. **Responsabilités** : tableau RACI (Réalise, Approuve, Consulté, Informé) pour chaque livrable.
6. **Budget et moyens** : temps, achats, prestataires ; écart prévu / réel au suivi.
7. **Risques** : probabilité, impact, parade, responsable.
8. **Suivi** : point hebdomadaire court (fait, à faire, bloqué), tableau de bord vert / orange / rouge.

## Livrable
- Tableur (onglets : tâches, planning type Gantt, RACI, risques, budget) et note de cadrage d'une page.
- Export possible vers l'outil de gestion de projet de l'utilisateur, après accord.

## Règles
- Une estimation est une **estimation** : l'indiquer comme telle, avec l'hypothèse qui la fonde.
- Ne pas créer ni modifier de tâches dans un outil en ligne sans validation.
- Signaler tout de suite une date impossible plutôt que comprimer les tâches en silence.
