---
name: product-listing
description: Rédiger des fiches produits pour une boutique en ligne ou une place de marché — titre, description, caractéristiques, photos à prévoir, prix, variantes, mots-clés, informations obligatoires — en lot, à partir d'un tableur. À utiliser pour mettre en ligne un catalogue, améliorer des fiches qui ne vendent pas ou préparer un import.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Fiches produits

## Méthode
1. **Données sources** : tableur ou fiches fournisseur (référence, dimensions, matières, poids, couleurs, prix, stock).
2. **Titre** : nature du produit + caractéristique principale + variante, lisible avant d'être « optimisé ».
3. **Description** : à qui il sert et pourquoi (2 à 3 phrases), puis liste des caractéristiques, entretien, contenu du colis.
4. **Photos à prévoir** : fond neutre, détail, échelle, en situation ; texte alternatif pour chaque image.
5. **Informations à vérifier** : prix TTC, frais et délais de livraison, garanties légales (conformité, vices cachés), droit de rétractation pour la vente à distance aux particuliers, mentions propres au produit (composition textile, étiquetage énergétique, âge minimum des jouets…).
6. **Référencement** : mots-clés que les clients tapent vraiment, sans bourrage ; catégorie et attributs du site.
7. **Import** : colonnes au format de la plateforme (Shopify, WooCommerce, PrestaShop, place de marché).

## Règles
- Ne jamais inventer une caractéristique, une certification ou un avis client : laisser « à confirmer ».
- Garder le ton et le vocabulaire de la marque ; pas de copie de texte concurrent.
- Aucune mise en ligne ni modification de prix sans validation de l'utilisateur.
