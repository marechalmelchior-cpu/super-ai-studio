---
name: video-script
description: Écrire le script et le découpage d'une vidéo — idée, accroche, structure, texte voix off ou face caméra, plan par plan (storyboard écrit), plans de coupe, sons, textes à l'écran, liste de tournage. À utiliser pour une vidéo YouTube, un format court vertical, un tutoriel, une vidéo d'entreprise, une publicité ou un clip.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Script et découpage vidéo

## Méthode
1. **Brief** : objectif, public, plateforme, durée cible, format (16:9, 9:16, 1:1), ton.
2. **Accroche** : les 3 premières secondes disent pourquoi rester ; 3 versions à tester.
3. **Structure** : promesse, développement en étapes, preuve ou démonstration, conclusion et appel à l'action.
4. **Texte** : phrases courtes à dire à voix haute, environ 150 mots par minute ; minutage par séquence.
5. **Découpage** : tableau plan / durée / image (cadre, mouvement, décor) / son (voix, musique, effet) / texte à l'écran.
6. **Tournage** : liste des plans par lieu, matériel, accessoires, autorisations ; plans de coupe à prévoir.
7. **Montage** : ordre, rythme, sous-titres incrustés pour les formats courts, miniature et titre.

## Livrable
- Script minuté, tableau de découpage, liste de tournage, propositions de titres et de miniatures.

## Règles
- Musiques, images et extraits avec licence ; autorisations de droit à l'image des personnes filmées.
- Aucune publication sans validation de l'utilisateur.
