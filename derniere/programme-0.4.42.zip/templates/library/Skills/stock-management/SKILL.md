---
name: stock-management
description: Gérer le stock d'un commerce, d'un atelier ou d'une petite boutique en ligne — fichier articles, entrées et sorties, inventaire, seuils de réapprovisionnement, rotation, invendus, commande fournisseur. À utiliser pour mettre en place un suivi de stock simple, préparer un inventaire annuel ou réduire les ruptures et les surstocks.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Gestion de stock

## Méthode
1. **Fichier articles** : référence, désignation, famille, fournisseur, prix d'achat, prix de vente, unité, emplacement, code-barres s'il existe.
2. **Mouvements** : entrées (réceptions), sorties (ventes, casse, pertes, usage interne), avec date et pièce justificative ; stock théorique calculé.
3. **Inventaire** : comptage physique par zone, écart avec le théorique, explication des écarts.
4. **Seuils** : stock de sécurité et point de commande à partir des ventes moyennes et du délai fournisseur ; alerte quand un article passe sous le seuil.
5. **Analyse** : classement ABC (les 20 % d'articles qui font 80 % du chiffre), rotation, articles dormants, invendus à écouler.
6. **Commande** : proposition de commande par fournisseur, à valider.

## Livrable
- Tableur (articles, mouvements, inventaire, alertes, proposition de commande) ou import pour le logiciel de caisse ou la boutique en ligne.

## Règles
- Ne jamais corriger un stock sans trace : chaque ajustement a un motif.
- Aucune commande fournisseur ni modification d'une boutique en ligne sans validation de l'utilisateur.
