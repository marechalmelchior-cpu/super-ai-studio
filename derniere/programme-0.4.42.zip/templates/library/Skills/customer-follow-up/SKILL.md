---
name: customer-follow-up
description: Suivre et fidéliser ses clients après la vente — fichier clients utile, relances au bon moment, demande d'avis, traitement des avis négatifs, enquête de satisfaction et offres aux clients consentants. À utiliser pour un commerce, un artisan, un indépendant ou une petite équipe commerciale qui veut garder ses clients.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Suivi et fidélisation des clients

## Méthode
1. **Fichier clients** : seulement les informations utiles (contact, achats, date du dernier échange, préférences exprimées, consentement aux messages et sa date) ; une ligne par client.
2. **Moments de contact** : après la livraison ou la prestation (tout s'est bien passé ?), à l'échéance naturelle (entretien, renouvellement, saison), à la date anniversaire d'un contrat ; pas plus souvent que le client ne l'accepte.
3. **Demande d'avis** : message court, lien direct, sans contrepartie ; jamais d'avis rédigé à la place du client.
4. **Avis négatif** : remercier, reconnaître le problème sans se justifier longuement, proposer une solution concrète et un contact direct ; répondre en public sobrement et régler le fond en privé.
5. **Satisfaction** : 3 à 5 questions (voir « survey-design »), dont une ouverte ; regrouper les remarques par thème et en tirer une ou deux actions.
6. **Fidélité** : offre ou avantage réservé aux clients qui ont accepté de recevoir des messages ; mesure du taux de clients revenus.

## Livrable
- Fichier clients (tableur) avec la colonne consentement, calendrier des relances, modèles de messages (remerciement, relance, demande d'avis, réponse à un avis négatif) et bilan trimestriel.

## Règles
- Messages commerciaux seulement avec le consentement requis (voir « prospecting-plan » et « newsletter-campaign ») ; désinscription simple dans chaque message.
- Ni faux avis, ni avis achetés, ni suppression sélective d'avis : pratiques commerciales trompeuses.
- Aucun envoi ni geste commercial sans validation de l'utilisateur ; données des clients conservées pour une durée définie (voir « gdpr-records »).
