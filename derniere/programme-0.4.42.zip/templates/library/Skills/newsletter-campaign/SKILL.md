---
name: newsletter-campaign
description: Préparer une campagne d'emailing ou une lettre d'information — objectif, segment, objet, contenu, appel à l'action, version texte, tests, calendrier et mesure des résultats — dans les règles du consentement. À utiliser pour une newsletter mensuelle, une annonce de lancement, une relance de panier ou une campagne d'association.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Campagne d'emailing

## Méthode
1. **Objectif** unique et mesurable (inscriptions, ventes, dons, participation).
2. **Destinataires** : segment précis parmi les contacts **qui ont consenti** ; exclure les désinscrits et les adresses en erreur.
3. **Objet et pré-en-tête** : 3 propositions d'objet (moins de 50 caractères), sans majuscules criardes ni fausse urgence.
4. **Contenu** : une idée principale, paragraphes courts, un seul appel à l'action visible, images avec texte alternatif, version texte brut.
5. **Pied de page** : identité de l'expéditeur, raison de la réception, lien de désinscription en un clic.
6. **Tests** : rendu mobile et sombre, liens, orthographe, envoi d'essai à l'utilisateur ; test A/B sur l'objet si la liste est assez grande.
7. **Mesure** : taux d'ouverture (indicatif), clics, conversions, désinscriptions ; retenir une leçon pour la prochaine fois.

## Règles
- Consentement : obligatoire pour écrire à des particuliers ; information et opposition possible pour des professionnels (CNIL, cnil.fr, consulté le 2026-10-29).
- **Aucun envoi sans validation explicite de l'utilisateur**, même en mode test vers une vraie liste.
- Pas de liste achetée ou aspirée, pas de promesse trompeuse.
