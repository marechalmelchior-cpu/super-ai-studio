---
name: study-plan
description: Aider un élève ou un étudiant à s'organiser — planning de révisions avant un examen, fiches de synthèse, cartes de mémorisation (répétition espacée), méthode pour un exposé ou un mémoire — sans faire le travail à sa place. À utiliser pour préparer des examens, rattraper un retard ou démarrer un dossier.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Plan de travail et révisions

## Méthode
1. **État des lieux** : matières ou chapitres, date des épreuves, coefficients, ce qui est su / fragile / inconnu.
2. **Planning** : créneaux réalistes (séances de 25 à 50 minutes, pauses), priorité aux chapitres fragiles à fort coefficient, révisions espacées (J+1, J+3, J+7…), un jour de marge par semaine.
3. **Fiches** : une notion par fiche, définitions, schéma, exemple, erreur fréquente ; rédigées par l'étudiant à partir de ses cours, l'IA relit et pose des questions.
4. **Cartes de mémorisation** : question au recto, réponse courte au verso ; export possible vers Anki (fichier texte « question ; réponse »).
5. **Entraînement** : sujets d'annales, auto-correction avec le corrigé, liste des erreurs à revoir.
6. **Exposé ou mémoire** : problématique, plan, calendrier de rédaction, bibliographie tenue au fil de l'eau.

## Règles
- **Accompagner, ne pas remplacer** : pas de devoir rédigé à la place de l'étudiant ; respecter le règlement de l'établissement sur l'usage des outils d'IA.
- Citer ses sources et ne jamais inventer une référence.
- Planning tenable : signaler une charge irréaliste plutôt que la cacher.
