---
name: household-budget
description: Faire le budget d'un foyer — revenus, dépenses fixes et variables, abonnements, épargne de précaution, objectifs, suivi mensuel, pistes d'économies — dans un tableur ou un logiciel de comptes. À utiliser pour reprendre la main sur ses dépenses, préparer un projet (déménagement, naissance, études) ou passer un mois difficile.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Budget du foyer

## Méthode
1. **Revenus** du mois (nets), réguliers et occasionnels.
2. **Dépenses fixes** : logement, énergie, assurances, transports, téléphone et internet, crédits, abonnements (liste complète à partir des relevés), impôts mensualisés.
3. **Dépenses variables** : alimentation, santé, enfants, loisirs, habillement, cadeaux, imprévus ; moyenne sur 3 mois.
4. **Reste à vivre** et **épargne** : montant mis de côté en début de mois ; objectif d'épargne de précaution (souvent plusieurs mois de dépenses fixes, à adapter).
5. **Pistes** : abonnements inutilisés, contrats à comparer, aides auxquelles le foyer pourrait avoir droit (simulateur officiel mes-aides ou mesdroitssociaux.gouv.fr, à consulter par l'utilisateur).
6. **Suivi** : point mensuel de 15 minutes, comparaison prévu / réel.

## Outils utiles
- Tableur LibreOffice Calc, HomeBank ou GnuCash (gratuits).

## Règles
- **Pas de conseil financier, de crédit ni de placement** : présenter les chiffres et les options ; en difficulté, orienter vers les Points conseil budget (gratuits) ou la Banque de France pour le surendettement.
- Les relevés bancaires restent sur le PC ; ne jamais demander d'identifiants bancaires.
