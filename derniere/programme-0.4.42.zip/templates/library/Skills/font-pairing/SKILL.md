---
name: font-pairing
description: Choisir et associer des polices de caractères — rôle (titres, texte, interface), lisibilité, langues et accents couverts, graisses disponibles, licence d'utilisation (impression, web, application, logo) — et définir une échelle typographique. À utiliser pour une charte graphique, un site, un livre, une affiche ou une interface.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Choisir ses polices

## Méthode
1. **Usage** : support (écran, papier, petit corps), public, ton recherché, langues à couvrir (français : accents, ligatures œ et æ, guillemets « »).
2. **Rôles** : une police de texte très lisible, éventuellement une police de titre contrastée ; deux familles suffisent dans la plupart des cas.
3. **Association** : contraste clair (empattements + sans empattements, ou deux graisses d'une même famille), hauteurs d'x proches, même époque ou esprit.
4. **Échelle** : tailles en progression régulière (par exemple rapport 1,25), interlignage 1,4 à 1,6 pour le texte courant, longueur de ligne de 50 à 75 caractères.
5. **Vérifications** : chiffres, ponctuation, gras et italique réels, rendu à petite taille, contraste suffisant avec le fond.
6. **Licence** : vérifier pour chaque usage (bureautique, web, intégration dans une application ou un PDF, logo) ; les polices sous licence SIL Open Font License (OFL) peuvent être utilisées, intégrées et redistribuées librement, sauf vente isolée de la police.

## Livrable
- Planche typographique (titres, texte, légendes, boutons), échelle des tailles, fichiers ou liens officiels des polices et leur licence.

## Règles
- Ne jamais fournir de police piratée ni de fichier récupéré sur un site non officiel.
- Pour le web, héberger les polices avec le site quand la licence le permet (pas de dépendance à un service tiers imposée).
