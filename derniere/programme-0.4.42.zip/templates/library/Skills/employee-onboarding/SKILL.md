---
name: employee-onboarding
description: Organiser l'arrivée d'un salarié, d'un stagiaire ou d'un bénévole — démarches avant l'arrivée, premier jour, équipements et accès, livret d'accueil, objectifs des premières semaines et points d'étape. À utiliser pour préparer une embauche, accueillir un saisonnier ou mettre au propre un processus d'accueil.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Accueillir un nouvel arrivant

## Méthode
1. **Avant l'arrivée** : liste des démarches à vérifier avec le gestionnaire de paie ou l'expert-comptable (déclaration préalable à l'embauche, contrat signé, visite d'information et de prévention selon le poste), poste de travail, matériel, comptes et accès, badge, tenue.
2. **Premier jour** : horaire d'arrivée, personne qui accueille, visite, présentation à l'équipe, consignes de sécurité, déjeuner, premières tâches simples.
3. **Livret d'accueil** : présentation de la structure, organigramme, horaires et congés, contacts utiles, règles de fonctionnement, outils, qui appeler en cas de problème.
4. **Premières semaines** : objectifs clairs par semaine, référent désigné, formations prévues.
5. **Points d'étape** : à la fin de la première semaine, du premier mois et avant la fin de la période d'essai ; questions à poser et ce qui doit être ajusté.
6. **Départ** (même méthode à l'envers) : restitution du matériel, fermeture des accès, documents de fin de contrat à demander au gestionnaire de paie.

## Livrable
- Liste de contrôle datée (avant, jour 1, semaine 1, mois 1), livret d'accueil modifiable et planning des points d'étape.

## Règles
- Les démarches légales sont listées pour vérification, pas exécutées : elles relèvent de l'employeur et de son gestionnaire de paie ; aucun conseil en droit du travail.
- Les accès donnés sont limités au besoin du poste ; aucun mot de passe écrit dans les documents.
- Données personnelles du nouvel arrivant : seulement le nécessaire, rangées au bon endroit.
