---
name: trip-planning
description: Préparer un voyage ou un déplacement — itinéraire jour par jour, transports, hébergements, budget, formalités (papiers, visas, santé), assurances, liste d'affaires, plan B — pour un séjour personnel, une sortie scolaire, un déplacement professionnel ou un voyage de groupe.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Préparer un voyage

## Méthode
1. **Cadre** : dates, voyageurs (âges, besoins particuliers, mobilité), budget, envies, rythme.
2. **Formalités** à vérifier sur les sources officielles, avec la date de consultation : validité des papiers d'identité, visa ou autorisation électronique, conseils aux voyageurs et sécurité (diplomatie.gouv.fr, inscription possible sur Ariane), santé et vaccins, permis de conduire, autorisation de sortie du territoire pour un mineur voyageant sans ses parents.
3. **Itinéraire** : jour par jour, temps de trajet réalistes, une demi-journée libre de temps en temps.
4. **Transports et hébergements** : options comparées (prix, durée, conditions d'annulation), sans réserver.
5. **Budget** : transports, hébergement, repas, visites, assurances, imprévus (10 à 15 %).
6. **Liste d'affaires** et documents (copies numériques des papiers, contacts d'urgence, numéro de l'ambassade).
7. **Plan B** : retard, grève, météo, perte de papiers.

## Règles
- **Aucune réservation, aucun paiement** : l'utilisateur réserve lui-même.
- Les règles d'entrée changent : toujours revérifier sur le site officiel du pays et de diplomatie.gouv.fr avant le départ.
