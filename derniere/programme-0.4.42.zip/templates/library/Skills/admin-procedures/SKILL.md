---
name: admin-procedures
description: Aider à réaliser une démarche administrative — trouver la démarche officielle, la liste des pièces, les délais et les coûts, préparer les documents et un récapitulatif étape par étape — pour une carte d'identité, une aide, une déclaration, une inscription, un changement de situation ou une création d'entreprise.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Démarches administratives

## Méthode
1. **Situation** : ce que la personne veut obtenir ou déclarer, sa situation (sans données inutiles).
2. **Démarche officielle** : la fiche correspondante sur service-public.fr (ou le site de l'organisme : CAF, France Travail, Assurance maladie, impots.gouv.fr, ANTS, URSSAF), lien et date de consultation.
3. **Récapitulatif** : conditions, pièces à fournir (case à cocher), coût éventuel, délai, où et comment déposer, ce qui se passe ensuite.
4. **Préparation** : liste des documents à scanner, nommage des fichiers, brouillon des champs à remplir, courrier d'accompagnement si besoin (voir la skill « formal-letter »).
5. **Suivi** : date de dépôt, numéro de dossier, relance prévue.

## Règles
- **Seuls les sites officiels** (adresses en .gouv.fr ou de l'organisme) : signaler les sites payants qui imitent les démarches gratuites.
- Ne jamais se connecter à la place de la personne (FranceConnect, espaces personnels), ni demander ses mots de passe ou codes reçus par SMS.
- Pas de conseil juridique ; pour un cas particulier, orienter vers France services (accompagnement gratuit) ou un point d'accès au droit.
