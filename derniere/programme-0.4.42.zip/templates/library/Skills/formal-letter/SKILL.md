---
name: formal-letter
description: Rédiger un courrier formel clair — réclamation, résiliation, demande, contestation, mise en demeure amiable, lettre de motivation, attestation — avec les références utiles, le ton juste et le mode d'envoi conseillé. À utiliser pour écrire à une administration, un fournisseur, un bailleur, un employeur, une banque ou une assurance.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Courrier formel

## Méthode
1. **But** : ce que l'on demande précisément et pour quand.
2. **Éléments** : coordonnées de l'expéditeur et du destinataire, lieu et date, références (numéro de client, de contrat, de dossier), objet en une ligne.
3. **Corps** : rappel des faits datés, demande claire, délai raisonnable de réponse, pièces jointes listées ; ton courtois et ferme.
4. **Formule** de politesse simple et signature.
5. **Envoi** : lettre recommandée avec accusé de réception quand une preuve est utile (résiliation, contestation, mise en demeure) ; garder une copie.
6. **Résiliation** : vérifier les conditions du contrat ; pour un contrat souscrit en ligne, la résiliation doit pouvoir se faire en ligne en quelques clics depuis le 1er juin 2023 (loi du 16 août 2022, service-public.fr, consulté le 2026-10-29).

## Règles
- Ne citer un article de loi que s'il a été vérifié sur legifrance.gouv.fr ou service-public.fr, avec la date ; sinon s'en passer.
- Pas de menace ni d'affirmation non prouvée ; pour un litige sérieux, orienter vers un conciliateur de justice, une association de consommateurs ou un avocat.
- La lettre est envoyée par l'utilisateur lui-même.
