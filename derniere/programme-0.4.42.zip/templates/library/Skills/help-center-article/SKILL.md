---
name: help-center-article
description: Rédiger ou mettre à jour un article de centre d'aide ou de FAQ — question du client en titre, réponse courte, étapes numérotées, captures à prévoir, cas particuliers. À utiliser quand une question revient souvent au support, à la sortie d'une nouvelle fonction ou pour nettoyer une FAQ datée.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Article de centre d'aide

## Méthode
1. **Partir des vraies questions** : formulations employées par les clients (tickets, mails, avis) ; le titre reprend leurs mots, pas ceux de l'équipe interne.
2. **Réponse d'abord** : une ou deux phrases qui répondent, avant tout détail.
3. **Étapes** numérotées, une action par étape, avec le nom exact des boutons et menus ; indiquer où placer une capture et ce qu'elle doit montrer.
4. **Variantes** : différences selon l'appareil, l'offre ou le type de compte ; erreurs fréquentes et leur solution.
5. **Suite** : « si cela ne marche pas », avec le moyen de contacter le support et les informations à fournir.
6. **Entretien** : date de mise à jour, version du produit concernée, liens vers les articles voisins ; repérer les articles en double ou contradictoires.

## Livrable
- Article prêt à relire (titre, réponse courte, étapes, variantes, contact), en langage clair (voir la skill « easy-to-read »).
- Liste des captures à faire et des articles existants à fusionner ou retirer.

## Règles
- Décrire uniquement ce qui a été vérifié dans le produit ; marquer « à vérifier » ce qui ne l'a pas été.
- Rien n'est publié sans validation de l'utilisateur.
- Pas de données de clients réels dans les exemples ni dans les captures.
