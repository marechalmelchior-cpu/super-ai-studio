---
name: subtitles
description: Créer, traduire ou corriger des sous-titres — transcription, découpage, synchronisation, longueur des lignes, vitesse de lecture, sous-titres pour personnes sourdes ou malentendantes — et livrer en SRT, VTT ou ASS. À utiliser pour une vidéo de réseau social, un film, un cours en ligne, une conférence ou un jeu.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Sous-titres

## Méthode
1. **Transcription** fidèle (automatique possible, puis relecture complète à l'écoute) ; repérer les noms propres et termes techniques.
2. **Découpage** : une idée par sous-titre, coupure aux pauses naturelles, jamais entre un article et son nom.
3. **Repères courants** (à adapter au cahier des charges du client) : 2 lignes au plus, environ 37 à 42 caractères par ligne, durée d'affichage entre 1 et 7 secondes, vitesse de lecture autour de 15 à 17 caractères par seconde pour un public adulte, moins pour un jeune public.
4. **Synchronisation** : entrée au début de la parole, sortie peu après la fin, respect des changements de plan quand c'est possible.
5. **Accessibilité (SME)** : indiquer les locuteurs hors champ, les bruits et la musique utiles à la compréhension ; en France, la « Charte relative à la qualité du sous-titrage à destination des personnes sourdes ou malentendantes » (CSA, décembre 2011, aujourd'hui Arcom) fixe des conventions, notamment de couleurs.
6. **Contrôle** : chevauchements, fautes, lignes trop longues, lecture complète en situation.

## Livrable
- Fichier SRT ou VTT (et ASS si un style est demandé), plus un rapport des passages incertains.

## Outils utiles
- Subtitle Edit, Aegisub, FFmpeg pour incruster ou convertir (déclarés dans le studio si présents).

## Règles
- Ne pas inventer de paroles inaudibles : noter « [inaudible] ».
- Respecter les droits de la vidéo ; pas de sous-titrage d'un contenu piraté.
