---
name: legal-templates
description: Préparer des documents juridiques courants à partir de modèles — conditions générales de vente, mentions légales d'un site, politique de confidentialité, contrat de prestation simple, attestation — avec les champs à compléter et les points à faire valider. À utiliser pour un premier jet à relire par un professionnel du droit. Aucun conseil juridique.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Documents juridiques courants

## Méthode
1. **Besoin** : quel document, pour quelle activité, quel pays, quels clients (particuliers ou professionnels).
2. **Plan type** du document choisi, par exemple :
   - **CGV** : identité du vendeur, prix, commande, paiement, livraison ou exécution, droit de rétractation (vente à distance aux particuliers), garanties légales, responsabilité, données personnelles, médiation de la consommation, droit applicable ;
   - **Mentions légales d'un site** : éditeur, directeur de la publication, hébergeur, contact ;
   - **Contrat de prestation** : parties, objet, livrables, délais, prix et paiement, propriété des créations, confidentialité, résiliation, litiges.
3. **Rédaction** en langage clair, avec des champs `[À COMPLÉTER]` pour toute donnée propre à l'utilisateur.
4. **Liste des points à faire valider** par un avocat, un notaire ou un juriste, et les textes officiels à consulter (service-public.fr, economie.gouv.fr, legifrance.gouv.fr, cnil.fr), avec la date de consultation.

## Règles
- **Pas de conseil juridique** : le document est un modèle de départ, à faire relire avant usage ; le dire en tête du document.
- Ne jamais inventer un article de loi, un numéro ou une jurisprudence ; citer seulement ce qui a été vérifié, avec le lien.
- Ne pas recopier le texte protégé d'un concurrent ; produire une rédaction originale.
- Aucune signature, envoi ou dépôt au nom de l'utilisateur.
