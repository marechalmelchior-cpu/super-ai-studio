---
name: database-design
description: Concevoir ou revoir une base de données — entités et relations, schéma normalisé, types, clés et contraintes, index, migrations réversibles, sauvegardes, données personnelles. À utiliser pour démarrer une application, passer d'un tableur à une vraie base (SQLite, PostgreSQL, MySQL) ou corriger des lenteurs et des incohérences.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Concevoir une base de données

## Méthode
1. **Domaine** : liste des objets (client, commande, produit…), de leurs informations et des règles métier (« une commande a au moins une ligne »).
2. **Modèle** : entités, relations (1-n, n-n avec table de liaison), schéma dessiné ; normaliser jusqu'à éviter les doublons, dénormaliser seulement pour une raison mesurée.
3. **Schéma** : types précis (dates, montants en décimal exact, jamais en flottant), clés primaires, clés étrangères, contraintes `NOT NULL`, `UNIQUE`, `CHECK`.
4. **Index** : sur les colonnes filtrées ou jointes souvent ; vérifier avec le plan d'exécution (`EXPLAIN`).
5. **Migrations** : versionnées, réversibles, testées sur une copie des données ; jamais de modification directe en production.
6. **Sauvegardes** : fréquence, emplacement séparé, test de restauration régulier.
7. **Données personnelles** : minimiser, chiffrer ce qui est sensible, durées de conservation (voir le registre RGPD).

## Livrable
- Schéma (diagramme et script SQL), jeu de données d'exemple, migrations, notes de conception.

## Règles
- Aucune commande destructive (`DROP`, `DELETE` sans condition, `TRUNCATE`) sur une base réelle sans sauvegarde vérifiée et accord explicite.
- Les identifiants de connexion restent dans des variables chiffrées, jamais dans le code.
