---
name: marketing-plan
description: Construire un plan marketing simple et chiffré pour une petite structure — objectif mesurable, public, message, canaux, calendrier, budget, indicateurs et bilan. À utiliser pour un lancement, une saison commerciale, une ouverture de boutique ou un événement.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Plan marketing

## Méthode
1. **Objectif** chiffré et daté (ex. 40 inscriptions avant le 15 mars), et point de départ connu.
2. **Public** : qui, où il s'informe, ce qui le décide ; un ou deux profils, pas plus.
3. **Message** : promesse en une phrase, preuves (avis, chiffres vérifiables, démonstration), appel à l'action unique.
4. **Canaux** choisis selon le public et les moyens : site, référencement, réseaux sociaux, e-mail aux contacts consentants, presse locale, partenaires, affichage, salons, publicité payante.
5. **Calendrier** semaine par semaine : préparation, lancement, relances, bilan ; qui fait quoi.
6. **Budget** par canal (temps et argent) et coût visé par résultat (par inscription, par vente).
7. **Mesure** : indicateurs suivis chaque semaine, outil de mesure, seuil qui déclenche un ajustement ; bilan final comparé à l'objectif.

## Livrable
- Plan d'une à deux pages, calendrier (tableur) et tableau de suivi des indicateurs.
- Renvoi vers les skills « social-media », « newsletter-campaign » et « ad-campaign-brief » pour produire les contenus.

## Règles
- Aucune publication, aucun envoi, aucune dépense publicitaire sans validation de l'utilisateur.
- Prospection et e-mails dans les règles du consentement (voir « prospecting-plan ») ; pas de faux avis ni de promesse invérifiable.
- Ne pas inventer de chiffres de marché : citer la source et sa date, ou écrire « estimation ».
