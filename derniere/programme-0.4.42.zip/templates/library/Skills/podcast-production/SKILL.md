---
name: podcast-production
description: Produire un podcast de bout en bout — concept, conducteur d'épisode, préparation des invités, enregistrement, montage, mixage, niveaux sonores, notes d'épisode, transcription, publication par flux RSS. À utiliser pour lancer une émission, préparer un épisode ou améliorer le son d'un podcast existant.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Produire un podcast

## Méthode
1. **Concept** : public, promesse, format (durée, rythme, solo, interview, table ronde), nom, visuel carré.
2. **Conducteur** : accroche, présentation, parties minutées, transitions, appel à l'action, générique ; questions préparées pour l'invité.
3. **Enregistrement** : pièce calme et amortie, micro proche et constant, enregistrement séparé de chaque voix si possible, test de 30 secondes avant de commencer, autorisation écrite de l'invité.
4. **Montage** : coupes des hésitations gênantes (pas toutes), silences raccourcis, cohérence des niveaux entre voix.
5. **Mixage** : réduction du bruit, égalisation légère, compression, musique sous la voix ; niveau final autour de −16 LUFS intégrés en stéréo et un pic réel sous −1 dBTP (repère courant de la diffusion en podcast, à confirmer selon la plateforme).
6. **Publication** : titre, description, chapitres, transcription (accessibilité), mots-clés ; fichier MP3 ou AAC ; flux RSS via l'hébergeur choisi.

## Outils utiles
- Audacity, REAPER, OBS Studio, FFmpeg (mesure de niveau avec le filtre `loudnorm`).

## Règles
- Musique et extraits : licence vérifiée (libre de droits ou autorisée).
- Aucune publication sans validation de l'utilisateur ; respect du droit à l'image et à la voix des invités.
