---
name: support-ticket-handling
description: Traiter les demandes du support client — tri par thème et par urgence, doublons, brouillons de réponse dans le ton de la maison, escalade documentée vers l'équipe concernée. À utiliser pour vider une file de tickets, répondre à un client mécontent ou préparer une escalade.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Traiter les demandes du support

## Méthode
1. **Lire et classer** chaque demande : thème (commande, facturation, panne, compte, question d'usage), produit concerné, client (nouveau, régulier, professionnel).
2. **Urgence** sur une échelle simple : bloquant (le client ne peut plus rien faire), gênant, question. Monter d'un cran si plusieurs clients signalent le même problème : c'est peut-être un incident.
3. **Doublons et regroupements** : rassembler les demandes qui décrivent le même problème et le signaler une seule fois à l'équipe.
4. **Brouillon de réponse** : reformuler la demande en une phrase, répondre ou donner la prochaine étape avec un délai réaliste, une seule question à la fois si une information manque, formule de fin. Ton poli, simple, sans jargon ni promesse impossible.
5. **Escalade** quand la réponse dépasse le support : résumé du problème, étapes pour le reproduire, ce qui a déjà été tenté, impact (nombre de clients, chiffre d'affaires), urgence, contact du client ; une seule personne responsable du suivi.
6. **Clôture** : vérifier que le client a sa réponse, noter la cause et, si la question revient souvent, proposer un article d'aide (skill « help-center-article »).

## Livrable
- Tableau des demandes : thème, urgence, statut, réponse proposée, escalade oui/non.
- Brouillons de réponse prêts à relire, et fiche d'escalade pour chaque cas qui sort du support.

## Règles
- Aucun envoi au client, aucun remboursement, aucun geste commercial sans validation de l'utilisateur.
- Ne jamais demander un mot de passe ni un numéro de carte complet ; ne recopier que les données personnelles utiles au traitement.
- Ne pas inventer de cause ni de date de correction : écrire « en cours d'analyse » tant que ce n'est pas confirmé.
