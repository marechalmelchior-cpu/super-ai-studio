---
name: membership-management
description: Gérer les adhérents et les dons d'une association — fichier des membres, cotisations, relances, reçus de dons, attestations, statistiques — dans un tableur ou un logiciel associatif. À utiliser pour la rentrée des adhésions, l'appel à cotisation, la préparation des reçus de dons ou le rapport annuel.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Adhérents, cotisations et dons

## Méthode
1. **Fichier des membres** : numéro, nom, contact, date d'adhésion, type de cotisation, montant, date et mode de paiement, consentement aux communications, date de fin. Une ligne par adhésion et par année.
2. **Appel à cotisation** : message clair (montant, échéance, moyens de paiement, ce que la cotisation finance), relances espacées et courtoises.
3. **Suivi** : tableau à jour / en retard / parti ; rapprochement avec les encaissements bancaires.
4. **Dons** : registre (donateur, date, montant, nature, mode de versement). Les reçus fiscaux ne peuvent être délivrés que par un organisme qui remplit les conditions légales (intérêt général notamment) : faire confirmer l'éligibilité par le bureau ; le modèle de reçu officiel est le formulaire Cerfa n° 11580 (vérifier la version en vigueur sur service-public.fr et impots.gouv.fr).
5. **Attestations** : adhésion, participation, bénévolat, sur modèle validé par le bureau.
6. **Statistiques** pour l'AG : nombre d'adhérents, évolution, répartition, montant des cotisations et des dons.

## Livrable
- Tableur des adhérents et des dons, modèles de messages et d'attestations, tableau de bord annuel.

## Règles
- RGPD : seulement les données utiles, informer les membres, ne jamais céder ni prêter le fichier ; durée de conservation prévue au registre (skill « gdpr-records »).
- Pas de conseil fiscal : l'éligibilité aux reçus de dons relève du bureau, au besoin après rescrit auprès de l'administration.
- Aucun envoi aux adhérents sans validation.
