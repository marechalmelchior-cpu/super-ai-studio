---
name: training-program
description: Concevoir un programme de formation pour adultes — public, prérequis, objectifs opérationnels, durée, modules, méthodes, évaluation des acquis, accessibilité, supports — et la fiche programme à remettre aux stagiaires. À utiliser pour un formateur indépendant, un organisme de formation, une formation interne ou un atelier.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Programme de formation

## Méthode
1. **Analyse du besoin** : situation de travail visée, écart à combler, public et nombre de stagiaires, contraintes (présentiel, distanciel, durée).
2. **Objectifs opérationnels** : « à l'issue de la formation, le stagiaire sera capable de… » avec un verbe d'action mesurable.
3. **Architecture** : modules et séquences, durée de chacune, alternance apports / pratique (au moins la moitié du temps en pratique quand c'est possible).
4. **Méthodes et moyens** : études de cas, mises en situation, ateliers ; matériel, salle, outils numériques.
5. **Évaluation** : positionnement à l'entrée, évaluation des acquis en fin de module, satisfaction à chaud, suivi à froid.
6. **Accessibilité** : contact du référent handicap, adaptations possibles.
7. **Fiche programme** : intitulé, public, prérequis, objectifs, durée, dates, lieu, tarif, modalités d'accès et d'évaluation, contact.

## Règles
- Si l'organisme est certifié Qualiopi, relier chaque élément aux indicateurs du référentiel national qualité (travail-emploi.gouv.fr, à consulter à la date du jour) sans promettre une conformité que seul l'auditeur établit.
- Supports : citer les sources et respecter les licences.
- Pas de données personnelles des stagiaires dans les documents types.
