---
name: lesson-plan
description: Préparer une séquence et des séances de cours — objectifs, prérequis, déroulé minuté, activités, différenciation, supports, évaluation — pour l'école, le collège, le lycée, le supérieur ou un atelier. À utiliser pour préparer un cours, une séquence de plusieurs séances ou adapter une séance à une classe hétérogène.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Préparer un cours

## Méthode
1. **Cadre** : niveau, discipline, durée, nombre d'élèves, place dans la progression ; extrait du programme officiel visé (eduscol.education.fr pour la France), cité avec sa date.
2. **Objectifs** : 2 à 4 objectifs formulés avec un verbe observable (« identifier », « résoudre », « argumenter »), et les prérequis.
3. **Déroulé minuté** : accroche (5 min), découverte ou situation-problème, apports, entraînement, synthèse écrite, vérification rapide de compréhension.
4. **Activités** : consignes exactes, modalités (individuel, binôme, groupe), matériel, rôle de l'enseignant.
5. **Différenciation** : aide pour les élèves en difficulté, prolongement pour ceux qui avancent vite, adaptations pour les élèves à besoins particuliers (PAP, PPS) quand l'enseignant les indique.
6. **Évaluation** : diagnostique, formative pendant la séance, sommative en fin de séquence ; critères de réussite.

## Livrable
- Fiche de séance (une page), supports élèves (fiche d'activité, trace écrite), corrigé.

## Règles
- Ne jamais demander ni stocker de données nominatives sur les élèves ; parler de profils.
- Vérifier chaque fait enseigné ; signaler les points à confirmer.
- Respecter le droit d'auteur des supports (citer, privilégier les ressources libres).
