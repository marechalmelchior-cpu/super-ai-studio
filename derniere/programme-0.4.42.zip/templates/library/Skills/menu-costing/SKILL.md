---
name: menu-costing
description: Construire les fiches techniques d'un restaurant ou d'un traiteur — ingrédients et grammages, coût matière par portion, prix de vente conseillé selon un taux de marge, allergènes, étapes de préparation — et la carte qui en découle. À utiliser pour créer ou revoir une carte, recalculer après une hausse de prix ou préparer l'affichage des allergènes.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Fiches techniques et coût matière

## Méthode
1. **Fiche technique** par plat : nombre de portions, ingrédients avec poids net utilisé, rendement (pertes d'épluchage, de cuisson), prix d'achat au kilo ou à l'unité, étapes, temps, matériel, dressage.
2. **Coût matière** par portion = somme des (quantité brute × prix unitaire) ÷ portions.
3. **Prix de vente** : à partir du ratio coût matière / prix de vente HT choisi par l'utilisateur, puis TVA applicable selon le produit et le mode de consommation (taux à vérifier sur impots.gouv.fr) ; arrondi lisible.
4. **Allergènes** : pour chaque plat, présence des 14 allergènes à déclarer (gluten, crustacés, œufs, poissons, arachides, soja, lait, fruits à coque, céleri, moutarde, sésame, sulfites, lupin, mollusques), selon le règlement (UE) n° 1169/2011 ; information obligatoire aussi pour les plats non préemballés.
5. **Carte** : équilibre des prix et des coûts, plats très rentables mis en valeur, mention « fait maison » seulement si les conditions officielles sont remplies (economie.gouv.fr).
6. **Mise à jour** : tableau des prix d'achat daté ; recalcul automatique des fiches.

## Livrable
- Classeur : base des ingrédients, fiches techniques, tableau de la carte avec coût et marge, tableau des allergènes imprimable.

## Règles
- Ne jamais deviner la composition d'un produit acheté : lire l'étiquette du fournisseur.
- Aucune allégation santé ou nutritionnelle non justifiée sur la carte.
