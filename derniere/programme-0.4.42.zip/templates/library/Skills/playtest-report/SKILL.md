---
name: playtest-report
description: Préparer et analyser des tests joueurs (playtests) — objectifs, protocole, questionnaire, observation, grille de notes, synthèse des problèmes classés par gravité et recommandations. À utiliser avant un salon, une démo, un accès anticipé ou à chaque jalon de développement d'un jeu.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Tests joueurs

## Méthode
1. **Questions à éclairer** : 3 au plus (« le tutoriel est-il compris ? », « le niveau 2 est-il trop dur ? »).
2. **Protocole** : profil des testeurs, durée, consignes neutres, ce que l'observateur ne doit pas dire, matériel d'enregistrement (avec accord écrit).
3. **Observation** : grille horodatée (moment, action, réaction, blocage), sans interrompre le joueur.
4. **Questionnaire** : avant (habitudes de jeu), après (compréhension, difficulté, plaisir, moments marquants), questions ouvertes et échelles de 1 à 5.
5. **Données de jeu** si disponibles : temps par niveau, morts, abandons, chemins.
6. **Synthèse** : problèmes classés par gravité (bloquant, gênant, mineur) et fréquence, citations courtes des joueurs, hypothèses de cause, recommandations et ce qu'il faut retester.

## Livrable
- Protocole et questionnaire prêts à imprimer, rapport de 2 à 4 pages, tableau des problèmes à verser dans le suivi du projet.

## Règles
- Distinguer ce qui a été **observé** de ce qui est **interprété**.
- Données des testeurs : anonymisées, consentement pour les enregistrements ; testeurs mineurs avec l'accord des parents.
