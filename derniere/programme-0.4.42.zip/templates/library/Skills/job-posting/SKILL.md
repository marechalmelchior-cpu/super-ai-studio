---
name: job-posting
description: Rédiger une offre d'emploi ou de stage claire et non discriminatoire, la fiche de poste associée et la grille de tri des candidatures. À utiliser pour recruter un salarié, un stagiaire, un alternant ou un bénévole, et pour répondre aux candidats.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Offre d'emploi et tri des candidatures

## Méthode
1. **Fiche de poste** : missions principales (5 à 8), résultats attendus, rattachement, lieu, conditions (contrat, durée, temps de travail, rémunération ou fourchette, télétravail, date de début).
2. **Compétences** : indispensables (3 à 5) et appréciées, séparées ; savoir-faire observables plutôt que traits de personnalité.
3. **Annonce** : accroche sur la structure, missions, profil, conditions, déroulé du recrutement (étapes, délais), contact. Langage simple, écriture inclusive si la structure l'utilise.
4. **Grille de tri** : critères liés au poste uniquement, notés de 0 à 3, identiques pour tous les candidats.
5. **Réponses** : modèles d'accusé de réception, de refus courtois et d'invitation à l'entretien.

## Règles
- Aucun critère discriminatoire (âge, sexe, origine, situation de famille, apparence, handicap, état de santé, opinions…) : voir le Code du travail, article L1132-1, et la partie sur les offres d'emploi (articles L5331-1 et suivants), sur legifrance.gouv.fr. En France, l'offre est rédigée en français.
- Données des candidats : collecter le strict nécessaire, informer de la durée de conservation (la CNIL recommande au plus 2 ans après le dernier contact, cnil.fr), ne pas rechercher d'informations privées en ligne.
- Aucune publication ni réponse envoyée sans validation de l'utilisateur.
