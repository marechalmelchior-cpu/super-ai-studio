---
name: volunteer-schedule
description: Organiser le planning d'une équipe de bénévoles ou de salariés à temps partiel — besoins par créneau, disponibilités, répartition équitable, remplacements, rappels, fiches de mission. À utiliser pour un événement, une permanence, une épicerie solidaire, un club, une maraude ou un accueil.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Planning d'équipe et de bénévoles

## Méthode
1. **Besoins** : créneaux (date, heure, lieu), nombre de personnes par créneau, compétences ou habilitations requises (secourisme, caisse, permis).
2. **Disponibilités** : formulaire simple ou tableau (nom ou prénom, créneaux possibles, préférences, limite de créneaux par mois).
3. **Répartition** : couvrir d'abord les créneaux critiques, équilibrer la charge, binômes débutant / expérimenté, pas plus de créneaux qu'accepté par la personne.
4. **Remplacements** : liste de réserve, règle d'échange entre bénévoles, contact du coordinateur.
5. **Fiches de mission** : rôle, horaires, lieu, consignes de sécurité, contact d'urgence.
6. **Rappels** : messages préparés (veille du créneau), à envoyer par l'utilisateur.

## Livrable
- Tableur du planning (vue par créneau et par personne), fiches de mission, messages de rappel.

## Règles
- Le bénévolat reste libre : pas de pression ni de sanction dans les messages.
- Données personnelles limitées à l'utile (prénom, contact), partagées seulement avec les coordinateurs.
- Aucun message envoyé sans validation de l'utilisateur.
