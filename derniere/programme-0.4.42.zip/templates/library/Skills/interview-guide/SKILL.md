---
name: interview-guide
description: Préparer un entretien de recrutement structuré et équitable — critères issus de la fiche de poste, questions identiques pour tous les candidats, mise en situation, grille de notation, compte rendu factuel. À utiliser avant une série d'entretiens, pour former un recruteur occasionnel ou pour comparer des candidats.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Guide d'entretien de recrutement

## Méthode
1. **Critères** : 4 à 6 compétences ou qualités tirées de la fiche de poste (skill « job-posting »), chacune décrite par ce qu'on doit pouvoir observer.
2. **Questions** : pour chaque critère, une question sur une situation vécue (« racontez une fois où… ») et une relance ; les mêmes pour tous les candidats.
3. **Mise en situation** courte et réaliste, proportionnée au poste, sans travail gratuit exploitable par l'entreprise.
4. **Déroulé** : accueil, présentation du poste et des conditions (horaires, salaire ou fourchette, lieu), questions, questions du candidat, suite du processus et délai de réponse.
5. **Grille** : note de 1 à 4 par critère, avec des exemples de réponse pour chaque niveau ; notes prises pendant l'entretien, faits plutôt qu'impressions.
6. **Décision** : comparer les grilles critère par critère, puis rédiger un retour poli et utile pour chaque candidat non retenu.

## Livrable
- Guide d'entretien d'une page, grille de notation (tableur ou document) et modèles de messages (convocation, refus, proposition).

## Règles
- Aucune question sur des critères interdits de discrimination (en France : Code du travail, article L1132-1 ; Défenseur des droits, defenseurdesdroits.fr, consulté le 2026-10-29) : âge, situation de famille, grossesse, origine, santé, handicap, religion, opinions, orientation sexuelle, lieu de résidence…
- Les notes d'entretien sont des données personnelles : seulement ce qui est utile, durée de conservation fixée, information du candidat (skill « gdpr-records »).
- La décision appartient à l'utilisateur ; aucun message envoyé sans sa validation.
