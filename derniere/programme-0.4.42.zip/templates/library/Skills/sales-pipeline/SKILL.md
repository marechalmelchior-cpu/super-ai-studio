---
name: sales-pipeline
description: Tenir et analyser un suivi commercial (pipeline) — étapes des affaires, montants, probabilités, prochaines actions, prévisions de chiffre d'affaires — dans un tableur ou un CRM. À utiliser pour préparer le point commercial de la semaine, relancer les affaires qui dorment ou prévoir le chiffre du trimestre.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Suivi commercial

## Méthode
1. **Étapes** définies une fois pour toutes, avec un critère de passage observable : contact, besoin qualifié, proposition envoyée, négociation, gagné, perdu.
2. **Fiche affaire** : client, interlocuteur, besoin, montant estimé, étape, date de dernière action, prochaine action et date, source.
3. **Revue hebdomadaire** : affaires sans action depuis 14 jours, propositions sans réponse, affaires à clôturer (gagnées ou perdues avec la raison).
4. **Prévision** : montant pondéré par étape (probabilités choisies par l'utilisateur), comparé à l'objectif ; distinguer engagé, probable, possible.
5. **Analyse** : taux de transformation par étape, durée moyenne d'une vente, raisons de perte les plus fréquentes.

## Livrable
- Tableur (ou export du CRM) avec vue par étape, liste des relances de la semaine, prévision et trois enseignements.

## Règles
- Les probabilités sont des **hypothèses** de l'utilisateur, pas des faits : les afficher.
- Ne modifier les fiches d'un CRM en ligne qu'après validation ; jamais de suppression.
- Données clients : seulement l'utile au suivi commercial.
