---
name: news-article
description: Écrire un article d'information ou de presse — angle, recherche et vérification des faits, citations sourcées, structure en pyramide inversée, titre et chapô, relecture — pour un média, un journal local, un bulletin d'association ou un blog. À utiliser pour un article, une brève, un portrait, un compte rendu d'événement ou un communiqué.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Article d'information

## Méthode
1. **Angle** : un seul, formulé en une phrase (« ce qui change pour les habitants du quartier »).
2. **Faits** : qui, quoi, où, quand, comment, pourquoi ; chaque fait relié à une source (document, interview, donnée publique) avec sa date.
3. **Vérification** : deux sources indépendantes pour un fait important, chiffres recalculés, citations relues avec la personne si possible ; distinguer fait, analyse et opinion.
4. **Structure** : titre informatif, chapô (l'essentiel en 2 ou 3 lignes), corps en pyramide inversée, intertitres, citations courtes et attribuées.
5. **Formats** : brève (500 à 800 signes), article (2 500 à 5 000), portrait, compte rendu ; adapter au support.
6. **Relecture** : noms propres, titres des personnes, dates, orthographe, équilibre des points de vue.

## Livrable
- Article prêt à relire, liste des sources avec liens et dates, points restant à vérifier.

## Règles
- Déontologie : ne pas inventer de citation, de témoin ni de chiffre ; corriger les erreurs ouvertement (Charte d'éthique professionnelle des journalistes, SNJ, et Déclaration de Munich de 1971).
- Respect de la vie privée, présomption d'innocence, droit à l'image ; protéger les sources.
- Aucune publication sans validation de l'utilisateur.
