---
name: game-audio
description: Organiser l'audio d'un jeu vidéo — document de conception sonore, liste des sons et musiques (asset list), conventions de nommage, variations, intégration dans le moteur ou un middleware, mixage par catégories, niveaux, accessibilité. À utiliser pour lancer la production sonore d'un jeu, préparer une commande à un sound designer ou un compositeur, ou corriger un mixage.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Audio de jeu

## Méthode
1. **Intention** : ambiance, références, ce que le son doit apprendre au joueur (danger, réussite, ressource).
2. **Liste des sons** (tableur) : identifiant, catégorie (interface, personnages, armes, environnement, musique, voix), déclencheur dans le jeu, nombre de variations, durée, boucle oui/non, priorité, statut.
3. **Nommage** : `cat_objet_action_variation` (ex. `sfx_porte_ouvrir_03`), sans espaces ni accents.
4. **Musique** : thèmes par lieu ou situation, transitions, boucles propres, couches qui s'ajoutent selon l'intensité.
5. **Intégration** : sources 3D et atténuation, variations de hauteur et de volume pour éviter la répétition, limites de voix simultanées ; moteur natif (Unreal, Unity, Godot) ou middleware (FMOD, Wwise : comptes et licences à vérifier).
6. **Mixage** : bus par catégorie, réduction de la musique sous les dialogues, réglages séparés dans les options du joueur ; repères de niveau publiés par l'Audio Standards Working Group (ASWG-R001 : environ −24 LUFS pour la console et −18 LUFS pour le portable, à confirmer pour la plateforme visée).
7. **Accessibilité** : sous-titres et indications visuelles des sons importants, réglage de volume par catégorie, option mono.

## Règles
- Licences vérifiées pour chaque son de banque ; voix d'acteurs avec contrat écrit, y compris pour tout clonage de voix.
- Garder les sources (sessions, stems) séparées des fichiers exportés.
