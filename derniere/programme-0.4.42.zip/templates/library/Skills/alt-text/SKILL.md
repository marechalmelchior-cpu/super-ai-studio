---
name: alt-text
description: Rédiger les textes alternatifs des images et décrire les contenus visuels — photos, illustrations, graphiques, schémas, captures, boutons-images, images décoratives — pour un site, un document, une présentation ou un réseau social. À utiliser pour rendre un contenu accessible aux personnes aveugles ou malvoyantes et pour répondre aux exigences WCAG et RGAA.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Textes alternatifs

## Méthode
1. **Rôle de l'image** dans son contexte :
   - **décorative** : alternative vide (`alt=""`) ;
   - **informative** : l'information qu'elle apporte, en une phrase courte ;
   - **fonctionnelle** (lien, bouton) : l'action ou la destination (« Rechercher », « Accueil ») ;
   - **complexe** (graphique, schéma, carte) : alternative courte + description détaillée à proximité ou tableau des données.
2. **Rédaction** : ne pas commencer par « image de » ; reprendre le texte présent dans l'image ; éviter de répéter la légende.
3. **Contexte** : la même photo n'a pas la même alternative sur une page produit et dans un article.
4. **Réseaux sociaux** : description dans le champ prévu, sous-titres pour les vidéos.
5. **Contrôle** : lecture de la page avec un lecteur d'écran (NVDA sous Windows) ou un outil d'audit.

## Références
- WCAG 2.2 (W3C, recommandation du 5 octobre 2023), critère 1.1.1 « Contenu non textuel » ; RGAA 4.1.2 (accessibilite.numerique.gouv.fr), thématique « Images » ; consultés le 2026-10-29.

## Règles
- Décrire ce qui est visible et utile, sans supposer l'identité, l'origine ou l'état de santé d'une personne photographiée.
