---
name: quote-builder
description: Construire un devis détaillé et chiffré pour un artisan, un prestataire ou un commerce — métrés, fournitures, main-d'œuvre, déplacements, options, acompte, validité — avec le calcul de marge. À utiliser pour répondre à une demande de travaux, d'intervention, de prestation ou de commande sur mesure.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Construire un devis

## Méthode
1. **Demande** : besoin du client, lieu, contraintes d'accès, délais, photos ou plans fournis ; questions à poser avant de chiffrer.
2. **Postes** : lots (préparation, fournitures, pose, finitions, évacuation) ; pour chaque ligne : désignation précise, unité (m², ml, h, forfait), quantité, prix unitaire HT, total.
3. **Coûts internes** (onglet non remis au client) : prix d'achat, temps passé, taux horaire, frais de déplacement, part des frais généraux ; marge calculée par lot.
4. **Options** chiffrées à part, pour laisser le choix au client.
5. **Conditions** : durée de validité, acompte, échéancier, délai d'exécution, conditions de paiement, ce qui n'est pas compris.
6. **Mentions** à vérifier selon l'activité : identité et SIRET, TVA ou mention d'exonération, assurance professionnelle (dont la garantie décennale pour les travaux concernés), signature « bon pour accord ».
7. **Dépannage, réparation et entretien chez un particulier** (bâtiment et équipement de la maison) : devis détaillé écrit remis **avant** l'intervention, **dès le premier euro et même en cas d'urgence** ; l'ancien seuil de 150 € TTC a été supprimé le 1er avril 2017 (arrêté du 24 janvier 2017, legifrance.gouv.fr ; fiche DGCCRF « Dépannage à domicile », economie.gouv.fr, mise à jour en juillet 2025 ; consultés le 2026-10-29). Vérifier si l'activité figure dans la liste de l'arrêté.

## Livrable
- Devis prêt à envoyer (PDF ou Word) et tableur de chiffrage avec la marge.

## Règles
- Ne jamais inventer un prix fournisseur : marquer « prix à confirmer » et le signaler.
- Un devis signé engage les deux parties : rien n'est envoyé sans validation de l'utilisateur.
- Pas de conseil juridique : pour un litige ou un marché public, renvoyer vers un professionnel.
