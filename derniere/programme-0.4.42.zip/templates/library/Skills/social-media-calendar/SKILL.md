---
name: social-media-calendar
description: Préparer un calendrier éditorial pour les réseaux sociaux sur un mois ou une saison — thèmes récurrents, temps forts, formats par réseau, textes et visuels à produire, validation et bilan. À utiliser pour un commerce, une association, un artiste ou un indépendant qui veut publier régulièrement sans y passer ses soirées.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Calendrier des réseaux sociaux

## Méthode
1. **Cadre** : réseaux réellement utilisés par le public, rythme tenable (ex. 2 publications par semaine), temps disponible.
2. **Piliers** : 3 ou 4 thèmes récurrents (coulisses, conseils, nouveautés, témoignages) pour ne pas partir de zéro chaque semaine.
3. **Temps forts** : dates de l'activité (ouverture, soldes, rentrée, événement), fêtes et journées utiles au public ; éviter les dates sensibles.
4. **Grille** : date, réseau, pilier, format (photo, carrousel, vidéo courte, story), texte, visuel à produire, lien, statut (idée, rédigé, validé, programmé, publié).
5. **Production par lots** : écrire et préparer les visuels de deux semaines en une séance ; textes alternatifs pour les images (skill « alt-text »).
6. **Bilan mensuel** : publications qui ont le mieux marché (portée, interactions, clics), ce qu'on garde et ce qu'on arrête.

## Livrable
- Calendrier dans un tableur (une ligne par publication), textes prêts à relire et liste des visuels à créer.

## Règles
- Rien n'est publié ni programmé sans validation de l'utilisateur.
- Droit à l'image : accord des personnes reconnaissables, et des parents pour les mineurs ; droits d'auteur des musiques et images respectés.
- Partenariat ou cadeau reçu : le signaler clairement dans la publication.
