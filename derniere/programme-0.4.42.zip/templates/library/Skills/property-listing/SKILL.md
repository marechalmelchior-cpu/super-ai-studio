---
name: property-listing
description: Rédiger une annonce immobilière de vente ou de location complète et loyale — description, points forts, surfaces, informations énergétiques obligatoires, prix et honoraires, photos à prévoir — et la fiche de visite. À utiliser pour un agent immobilier, un propriétaire bailleur, un gestionnaire ou un particulier qui vend.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Annonce immobilière

## Méthode
1. **Fiche du bien** (données fournies par l'utilisateur) : type, adresse ou secteur, surface (loi Carrez en copropriété pour la vente, surface habitable pour la location), pièces, étage, ascenseur, extérieurs, stationnement, chauffage, charges, taxe foncière, travaux récents, copropriété (nombre de lots, procédures).
2. **Informations énergétiques** : classes énergie et climat du DPE et, depuis le 1er janvier 2022, une estimation des dépenses annuelles d'énergie (source : ecologie.gouv.fr et service-public.fr, consultés le 2026-10-29) ; mentionner les règles propres aux logements les moins performants pour la location, à vérifier à la date de l'annonce.
3. **Prix** : prix de vente (en précisant qui paie les honoraires) ou loyer, charges, dépôt de garantie, honoraires de location ; zone d'encadrement des loyers si elle s'applique.
4. **Texte** : titre factuel, description en trois temps (le lieu, le bien, la vie au quotidien), points forts vérifiables, sans superlatifs creux.
5. **Photos à prévoir** : lumière naturelle, pièces rangées, une photo par pièce, extérieur, plan.
6. **Fiche de visite** : informations clés, questions fréquentes, documents disponibles.

## Règles
- Aucune information inventée ou embellie (surface, exposition, travaux) : l'annonce engage son auteur.
- Pas de critère discriminant envers les candidats locataires ou acquéreurs.
- Aucune publication sans validation ; ne pas diffuser l'adresse exacte sans accord du propriétaire.
