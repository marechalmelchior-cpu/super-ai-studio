---
name: music-release
description: Préparer la sortie d'un titre ou d'un album — fichiers maîtres, niveaux pour le streaming, métadonnées et crédits, codes ISRC et UPC/EAN, pochette, déclarations de droits, calendrier de promotion. À utiliser pour un artiste indépendant, un label, une musique de jeu ou de film.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Sortie musicale

## Méthode
1. **Fichiers maîtres** : WAV 24 bits (44,1 ou 48 kHz selon le distributeur), version instrumentale, extraits.
2. **Niveaux** : les plateformes normalisent le volume ; repère courant d'environ −14 LUFS intégrés et d'un pic réel sous −1 dBTP (valeur indiquée par plusieurs plateformes de streaming, à confirmer auprès du distributeur choisi).
3. **Métadonnées** : titre exact, artistes principaux et invités, compositeurs, auteurs, producteurs, genre, langue, mention explicite, année, label.
4. **Codes** : ISRC par enregistrement (souvent fourni par le distributeur), UPC/EAN pour la sortie.
5. **Pochette** : carré, au moins 3000 × 3000 px selon la plupart des distributeurs, sans texte promotionnel interdit par leurs règles.
6. **Droits** : déclaration des œuvres auprès de l'organisme de gestion collective de l'auteur s'il en est membre (en France, la Sacem), accords écrits entre coauteurs, licences des samples.
7. **Calendrier** : envoi au distributeur 3 à 4 semaines avant la date (souvent demandé pour la mise en avant), pré-sauvegarde, contenus réseaux, envoi aux médias et playlists.

## Livrable
- Fiche de sortie (tableau des métadonnées et crédits), liste de contrôle des fichiers, calendrier de promotion.

## Règles
- Ne jamais déclarer un crédit ou un partage de droits non confirmé par écrit par les intéressés.
- Aucun envoi au distributeur ni publication sans validation de l'utilisateur.
