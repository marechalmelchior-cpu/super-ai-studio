---
name: manuscript-editing
description: Accompagner l'édition d'un manuscrit — lecture éditoriale, préparation de copie, harmonisation typographique, feuille de style, épreuves, métadonnées et fichiers de sortie (PDF imprimeur, EPUB). À utiliser pour un roman, un essai, un livre pratique, une thèse à publier ou un livre autoédité.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Édition d'un manuscrit

## Méthode
1. **Lecture éditoriale** : structure, rythme, cohérence (noms, dates, chronologie), clarté ; rapport avec points forts et propositions, sans réécrire à la place de l'auteur.
2. **Feuille de style** : orthographe retenue des noms et termes, majuscules, nombres en lettres ou en chiffres, dialogues (tirets, guillemets), citations, notes.
3. **Préparation de copie** : corrections proposées en mode suivi des modifications, chaque intervention justifiable.
4. **Typographie française** : espaces insécables, guillemets « », capitales accentuées, coupures de mots, veuves et orphelines à la mise en page.
5. **Épreuves** : relecture sur la mise en page finale, liste des corrections par page.
6. **Métadonnées** : titre, auteur, résumé, mots-clés, ISBN (attribué par l'AFNIL en France), prix, dépôt légal (BnF).
7. **Sorties** : PDF pour l'imprimeur (fonds perdus, polices incorporées, profil demandé), EPUB vérifié (outil EPUBCheck), couverture aux dimensions de l'imprimeur.

## Outils utiles
- LibreOffice Writer, Scribus, Sigil, calibre, Pandoc.

## Règles
- L'auteur décide : chaque modification est une proposition visible.
- Ne pas diffuser le manuscrit hors du cadre convenu ; droits d'auteur respectés pour les citations et images.
