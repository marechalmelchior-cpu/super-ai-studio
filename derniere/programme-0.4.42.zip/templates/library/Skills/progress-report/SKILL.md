---
name: progress-report
description: Rédiger un point d'avancement de projet clair — état général, ce qui est fait, ce qui vient, risques et blocages, décisions attendues, indicateurs — pour une direction, un client, un financeur ou une équipe. À utiliser pour un point hebdomadaire, un comité de pilotage ou un rapport intermédiaire.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Point d'avancement

## Méthode
1. **Lecteur** : qui lit, ce qu'il doit décider, combien de temps il y consacre ; adapter la longueur (5 lignes, une page, un rapport).
2. **État général** en une ligne : dans les temps / à surveiller / en retard, avec la raison principale.
3. **Fait depuis le dernier point** : livrables terminés, comparés au plan (skill « project-plan »).
4. **À venir** : prochaines étapes avec dates et responsables.
5. **Risques et blocages** : description, effet sur le délai, le budget ou la qualité, action proposée, qui doit agir.
6. **Décisions attendues** : formulées comme des questions fermées, avec les options et leur conséquence.
7. **Indicateurs** : avancement, budget consommé, charge, qualité ; mêmes indicateurs d'un point à l'autre pour voir l'évolution.

## Livrable
- Point d'avancement (message, page ou diaporama court) et tableau de suivi mis à jour.

## Règles
- Dire les retards tôt et sans les minimiser ; ne jamais annoncer « terminé » ce qui n'est pas livré et vérifié.
- Distinguer faits, estimations et hypothèses.
- Aucun envoi sans validation de l'utilisateur.
