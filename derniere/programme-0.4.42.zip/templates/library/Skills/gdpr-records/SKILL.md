---
name: gdpr-records
description: Tenir le registre des traitements de données personnelles (RGPD) d'une petite structure — fiches par traitement, durées de conservation, mesures de sécurité, mentions d'information, demandes d'accès. À utiliser pour une entreprise, une association, un cabinet ou un indépendant qui gère des clients, adhérents, patients, salariés ou prospects.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Registre RGPD

## Méthode
1. **Inventaire** des traitements : clients et facturation, prospection, salariés et paie, recrutement, adhérents ou bénévoles, site web et cookies, vidéosurveillance, rendez-vous, newsletter.
2. **Fiche par traitement** (article 30 du RGPD) : finalité, base légale (contrat, obligation légale, intérêt légitime, consentement…), catégories de personnes et de données, destinataires, transferts hors UE, durée de conservation, mesures de sécurité.
3. **Données sensibles** (santé, opinions, etc.) : les signaler à part ; elles demandent des précautions renforcées.
4. **Information des personnes** : mention courte à mettre sur les formulaires et la politique de confidentialité.
5. **Droits** : procédure et modèle de réponse pour les demandes d'accès, de rectification, d'effacement, avec le délai d'un mois.
6. **Revue** : date de mise à jour, responsable.

## Livrable
- Registre en tableur (une ligne par traitement) à partir du modèle de la CNIL, mentions d'information, procédure de réponse.

## Sources
- CNIL, « Le registre des activités de traitement » et modèle de registre simplifié (cnil.fr), consultés le 2026-10-29 ; RGPD (règlement UE 2016/679), article 30.

## Règles
- Outil de mise en conformité documentaire, pas de conseil juridique ; pour un cas complexe, renvoyer au délégué à la protection des données ou à un juriste.
- Ne jamais copier de données personnelles réelles dans le registre : il décrit les traitements, il ne les contient pas.
