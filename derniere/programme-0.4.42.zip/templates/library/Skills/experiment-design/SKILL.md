---
name: experiment-design
description: Concevoir une expérience, un essai ou une étude avant de la lancer — question, hypothèse, variables, groupes, taille d'échantillon, biais, protocole et plan d'analyse fixé à l'avance. À utiliser en recherche, en laboratoire, en enseignement des sciences, pour un test A/B ou un essai terrain.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Concevoir une expérience

## Méthode
1. **Question et hypothèse** : ce qu'on veut savoir, en une phrase ; hypothèse testable et résultat qui la contredirait.
2. **Variables** : ce qu'on fait varier, ce qu'on mesure (avec l'instrument et l'unité), ce qu'on garde constant.
3. **Groupes et témoins** : groupe témoin, répartition au hasard quand c'est possible, insu (aveugle) quand c'est utile.
4. **Taille d'échantillon** : effet attendu, variabilité, niveau de confiance ; calcul de puissance ou justification écrite si l'échantillon est imposé.
5. **Biais et limites** : sélection, mesure, perdus de vue, effets d'ordre, saison ; parade prévue pour chacun.
6. **Protocole** pas à pas, matériel, calendrier, fiche de recueil, critères d'arrêt et de sécurité.
7. **Plan d'analyse** écrit **avant** le recueil : test ou modèle prévu, traitement des valeurs manquantes et aberrantes, ce qui sera exploratoire.

## Livrable
- Protocole (document) et fiche de recueil (tableur) ; plan d'analyse daté.

## Règles
- Toute étude impliquant des personnes demande les autorisations prévues (comité d'éthique, consentement, déclaration des données) : les lister, ne pas décider à la place de l'utilisateur.
- Aucun protocole médical, clinique ou sur l'animal sans encadrement compétent : renvoyer vers lui.
- Ne pas présenter un résultat exploratoire comme une confirmation.
