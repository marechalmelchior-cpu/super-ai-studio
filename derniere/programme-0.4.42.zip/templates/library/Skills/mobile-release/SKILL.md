---
name: mobile-release
description: Préparer la publication d'une application mobile sur l'App Store et Google Play — version et numéro de build, signature, fiche de la boutique, captures, confidentialité et données collectées, tests internes, déploiement progressif, suivi après sortie. À utiliser avant la première soumission ou chaque mise à jour, quel que soit le framework (natif, Flutter, React Native, Expo…).
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Publier une appli mobile

## Méthode
1. **Version** : numéro visible (1.4.0) et numéro de build incrémenté ; notes de version courtes et claires.
2. **Qualité** : tests sur appareils réels (petit écran, ancienne version de système), mode sombre, hors ligne, accessibilité (tailles de texte, lecteur d'écran), pas de journal de débogage ni de clé de test.
3. **Signature** : certificats et clés de signature conservés hors du dépôt, dans un coffre ; procédure de récupération notée.
4. **Fiche boutique** : nom, sous-titre, description, mots-clés, captures aux tailles demandées, icône, catégorie, classification d'âge.
5. **Confidentialité** : politique de confidentialité en ligne, déclaration des données collectées (fiche « confidentialité » de l'App Store, section « sécurité des données » de Google Play), permissions justifiées.
6. **Tests** : TestFlight et piste de test interne ou fermée ; liste de vérification signée avant soumission.
7. **Sortie** : déploiement progressif, surveillance des plantages et des avis, plan de retour arrière (version corrective prête).

## Règles
- Les règles des boutiques changent : relire les guides officiels (developer.apple.com, play.google.com/console) le jour de la soumission.
- Aucune soumission ni publication sans validation de l'utilisateur ; comptes développeur payants (Apple) ou à frais d'inscription (Google) à signaler.
