---
name: ad-campaign-brief
description: Préparer une campagne publicitaire en ligne ou locale — brief, cible, message, budget, déclinaisons d'annonces par format, page d'arrivée, suivi et bilan. À utiliser avant de lancer des annonces sur un moteur de recherche, un réseau social, un site local ou de l'affichage.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Brief de campagne publicitaire

## Méthode
1. **Objectif** : notoriété, visites, contacts, ventes ; indicateur principal et seuil de réussite.
2. **Cible** : qui, où, quand, avec quel problème ; exclusions (clients actuels, zones non desservies).
3. **Message** : promesse, preuve, appel à l'action ; trois angles différents à tester.
4. **Annonces** : déclinaisons par format (texte court, image carrée, verticale 9:16, vidéo de 6 à 15 s), dans la charte graphique ; textes aux longueurs imposées par chaque régie.
5. **Page d'arrivée** : cohérente avec l'annonce, rapide, un seul objectif, formulaire minimal.
6. **Budget et calendrier** : budget total, répartition par canal, durée, date de bilan ; coût par résultat visé.
7. **Suivi** : paramètres de suivi des liens, tableau de bord simple, règles d'arrêt (si le coût par résultat dépasse X après Y jours).

## Livrable
- Brief d'une page, tableau des annonces prêtes à importer, plan de suivi.

## Règles
- Aucune campagne lancée et aucune dépense engagée sans validation de l'utilisateur.
- Pas d'allégation non prouvée, de faux avis, de ciblage discriminant ou visant des mineurs pour des produits interdits.
- Respecter les règles de chaque régie et le consentement aux traceurs (cookies) sur la page d'arrivée.
