---
name: photo-workflow
description: Organiser le flux de travail photo — import, sauvegarde, tri, métadonnées et mots-clés, développement RAW, retouche, export par usage (web, impression, réseaux), livraison au client et archivage. À utiliser après une séance, pour un reportage, un catalogue produit ou pour remettre de l'ordre dans une photothèque.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Flux de travail photo

## Méthode
1. **Import** : renommage `AAAA-MM-JJ_sujet_numéro`, dossier par séance, copie immédiate sur un second support (règle 3-2-1 : 3 copies, 2 supports, 1 hors site).
2. **Tri** : premier passage rapide (rejet des flous, yeux fermés), second passage par étoiles ; garder le meilleur de chaque série.
3. **Métadonnées** : auteur, droits, légende, lieu, mots-clés ; retirer la localisation GPS des images publiées si elle n'est pas utile.
4. **Développement** : balance des blancs, exposition, contraste, recadrage et redressement ; réglages copiés sur la série pour rester cohérent.
5. **Retouche** locale si nécessaire, dans un fichier séparé ; jamais sur l'original.
6. **Export** par usage : web (sRGB, 2048 px côté long, JPEG ou WebP), impression (profil et définition demandés par l'imprimeur, souvent 300 ppp à la taille finale), réseaux (formats 1:1, 4:5, 9:16).
7. **Livraison et archivage** : galerie ou dossier partagé, licence d'utilisation écrite, archive des RAW et des exports.

## Outils utiles
- darktable, RawTherapee, digiKam, GIMP, Krita, ImageMagick (traitements par lot).

## Règles
- Droit à l'image : autorisation des personnes reconnaissables pour une diffusion ; mineurs avec l'accord des parents.
- Ne jamais supprimer d'originaux : déplacer les rejets dans un dossier « rejets ».
