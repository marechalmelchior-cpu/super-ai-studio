---
name: accessible-documents
description: Produire des documents bureautiques et PDF accessibles — styles de titres, ordre de lecture, textes alternatifs, tableaux simples, contrastes, liens explicites, langue, métadonnées, export PDF balisé et vérification. À utiliser pour un rapport, un formulaire, un support de cours, une offre d'emploi ou tout document diffusé au public.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Documents accessibles

## Méthode
1. **Structure** : vrais styles de titres (Titre 1, 2, 3) dans l'ordre, listes automatiques, pas de mise en forme « à la main » (espaces, retours répétés).
2. **Texte** : police lisible, taille suffisante (12 pt minimum pour l'imprimé, souvent plus), texte aligné à gauche, langue du document déclarée.
3. **Couleurs** : contraste d'au moins 4,5:1 pour le texte courant (WCAG 2.2, critère 1.4.3), information jamais transmise par la couleur seule.
4. **Images** : texte alternatif ou marquage décoratif (voir la skill « alt-text »).
5. **Tableaux** : ligne d'en-tête déclarée, pas de cellules fusionnées inutiles, pas de tableau pour la mise en page.
6. **Liens** : intitulé explicite (« Télécharger le règlement (PDF, 200 Ko) » plutôt que « cliquez ici »).
7. **Export PDF** : depuis LibreOffice ou Word avec l'option PDF balisé (et PDF/UA quand elle existe), titre du document renseigné.
8. **Vérification** : vérificateur d'accessibilité du logiciel, outil PAC (PDF Accessibility Checker, gratuit) pour le PDF, lecture rapide avec NVDA.

## Références
- WCAG 2.2 (W3C, 5 octobre 2023) ; norme PDF/UA (ISO 14289) ; consultés le 2026-10-29.

## Règles
- Ne jamais déclarer un document « conforme » sans vérification outillée et manuelle : écrire « vérifié avec… » et les limites.
