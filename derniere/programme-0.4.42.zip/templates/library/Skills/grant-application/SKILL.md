---
name: grant-application
description: Monter une demande de subvention ou un dossier d'appel à projets — lecture du cahier des charges, présentation de la structure, description du projet, objectifs et indicateurs, budget équilibré, calendrier, pièces jointes, compte rendu final. À utiliser pour une association, une petite entreprise, un artiste ou un collectif qui sollicite une collectivité, l'État, une fondation ou un fonds européen.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Demande de subvention

## Méthode
1. **Cahier des charges** : critères d'éligibilité, dépenses éligibles, montant maximum, taux de cofinancement, date limite, pièces demandées ; tableau de conformité critère par critère.
2. **Structure** : identité, numéro SIRET et RNA pour une association, objet, moyens humains, réalisations passées.
3. **Projet** : besoin constaté (avec sources datées), public, objectifs, actions, partenaires, lieu, calendrier.
4. **Indicateurs** : ce qui sera mesuré et comment (participants, heures, résultats), réalistes.
5. **Budget** : charges et produits équilibrés, part de chaque financeur, valorisation du bénévolat si admise, devis à l'appui.
6. **Formulaire** : pour une association en France, le formulaire Cerfa n° 12156 (vérifier la version en vigueur sur service-public.fr) ou le téléservice « Le Compte Asso » (lecompteasso.associations.gouv.fr).
7. **Après** : convention, suivi des dépenses, compte rendu financier et d'activité dans les délais.

## Règles
- Ne jamais gonfler un chiffre, inventer un partenaire ou un résultat : un financeur peut demander des preuves.
- Le dossier est déposé par l'utilisateur lui-même ; aucune connexion à ses comptes en ligne.
