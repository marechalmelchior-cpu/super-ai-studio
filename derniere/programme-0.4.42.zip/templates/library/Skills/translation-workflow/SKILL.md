---
name: translation-workflow
description: Traduire ou localiser un document, un site, une interface ou un jeu avec méthode — analyse du texte, glossaire, guide de style, traduction, relecture bilingue, contrôle qualité, livraison au bon format. À utiliser pour une traduction professionnelle, la relecture d'une traduction automatique ou la localisation d'un produit.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Traduction et localisation

## Méthode
1. **Analyse** : langue source et cible (avec variante : français de France, du Canada…), public, usage, volume, format, délais ; passages à ne pas traduire (noms de marque, code, variables `{nom}`).
2. **Glossaire** : termes clés, traduction retenue, définition, exemples ; termes interdits. Le tenir dans un tableur partagé.
3. **Guide de style** : tutoiement ou vouvoiement, ton, typographie de la langue cible (espaces insécables avant « : ; ! ? » en français de France, guillemets « »), formats de date, de nombre et de monnaie.
4. **Traduction** : par segments, sens avant mot à mot ; noter les doutes en commentaire plutôt que deviner.
5. **Relecture bilingue** : contresens, omissions, ajouts, cohérence avec le glossaire, longueur (interfaces, sous-titres).
6. **Contrôle qualité** : nombres, balises, variables, liens, orthographe ; test dans le produit réel si possible.
7. **Livraison** : même format que la source (DOCX, XLIFF, PO, JSON, SRT), fichier de doutes et glossaire mis à jour.

## Règles
- Une traduction automatique est une **ébauche** : la dire comme telle et la faire relire.
- Confidentialité : ne pas envoyer un document confidentiel à un service en ligne sans accord.
- Ne jamais modifier le sens d'un texte juridique, médical ou technique : signaler et faire valider par un spécialiste.
