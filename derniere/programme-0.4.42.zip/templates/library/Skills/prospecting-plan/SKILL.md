---
name: prospecting-plan
description: Préparer une prospection commerciale respectueuse — cible, liste de comptes construite à partir de sources légitimes, messages personnalisés, séquence de relances, suivi des réponses — dans les règles du RGPD. À utiliser pour trouver de nouveaux clients professionnels, lancer une offre ou relancer d'anciens contacts.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Plan de prospection

## Méthode
1. **Cible** : secteur, taille, zone, problème que l'offre résout, déclencheurs d'achat ; persona de l'acheteur.
2. **Sources** : annuaires publics d'entreprises, salons, réseau de l'utilisateur, demandes entrantes, anciens clients ; noter la source de chaque contact.
3. **Liste** : entreprise, raison de la cibler, contact professionnel, canal, statut (à contacter, contacté, réponse, rendez-vous, refus).
4. **Messages** : premier contact court (contexte, bénéfice concret, question simple), deux relances espacées, message de clôture ; version téléphone avec trame d'appel.
5. **Suivi** : taux de réponse, rendez-vous obtenus, objections entendues ; ajuster cible et message.

## Règles
- **RGPD et prospection par écrit** (CNIL, cnil.fr, consulté le 2026-10-29) : entre professionnels, un message par mail est possible s'il concerne le métier de la personne, avec information et lien de désinscription ; vers un particulier, le consentement préalable est requis par mail ou SMS.
- **Démarchage téléphonique des particuliers** (France, depuis le 11 août 2026) : interdit sauf **consentement préalable** libre, éclairé et donné par un acte positif clair (durée d'un an maximum, sans renouvellement tacite, retrait possible à tout moment, preuve à la charge de l'entreprise), ou **contrat en cours** si l'appel porte sur son objet ; appels seulement du lundi au vendredi, de 10 h à 13 h et de 14 h à 20 h, jamais les samedis, dimanches et jours fériés. La liste Bloctel n'existe plus. Un contrat conclu après un appel irrégulier n'est pas valable. Sources : loi n° 2025-594 du 30 juin 2025, article 13 ; décret n° 2026-662 du 23 juillet 2026 ; service-public.gouv.fr, actualité A19003 mise à jour le 11 août 2026, consultée le 2026-10-29.
- Si le consentement n'est pas prouvé, la trame d'appel vise uniquement des professionnels ou des clients sous contrat ; sinon, proposer un autre canal.
- Refuser l'aspiration de profils, l'achat de fichiers sans consentement vérifiable et l'envoi massif automatisé.
- Ne jamais promettre ce que l'offre ne fait pas ; aucun envoi sans validation de l'utilisateur.
