---
name: spreadsheet-builder
description: Concevoir un tableur clair et fiable — onglets séparés pour les données, les paramètres et les résultats, formules lisibles, listes déroulantes, contrôles, graphiques. À utiliser pour créer un suivi (clients, stock, heures, dépenses), un calculateur ou pour remettre en ordre un classeur existant.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Construire un tableur

## Méthode
1. **Besoin** : quelle question le tableur doit-il résoudre ? Qui le remplit, qui le lit, à quelle fréquence ?
2. **Structure** : un onglet « Données » (une ligne = un enregistrement, une colonne = une information, pas de cellules fusionnées), un onglet « Paramètres » (taux, listes, seuils), un onglet « Synthèse » (totaux, tableaux croisés, graphiques), un onglet « Mode d'emploi ».
3. **Saisie fiable** : listes déroulantes, formats (date, monnaie), validation des valeurs, colonnes calculées protégées.
4. **Formules** : simples et commentées ; plages nommées plutôt que des références obscures ; pas de valeur saisie en dur dans une formule.
5. **Contrôles** : ligne de vérification (totaux qui doivent concorder), mise en forme conditionnelle des anomalies.
6. **Graphiques** : un message par graphique, titre qui dit ce qu'on doit voir.

## Livrable
- Fichier .xlsx ou .ods (LibreOffice Calc, Excel, OnlyOffice) avec un jeu d'exemple, et le même classeur vide prêt à l'emploi.

## Règles
- Ne jamais écraser le fichier de l'utilisateur : produire une nouvelle version et lister les changements.
- Pas de macro sans le dire et sans accord (une macro peut agir sur le PC).
- Vérifier chaque formule sur l'exemple avant de livrer ; annoncer les limites (taille, cas non gérés).
