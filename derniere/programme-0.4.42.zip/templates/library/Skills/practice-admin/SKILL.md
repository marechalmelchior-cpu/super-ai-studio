---
name: practice-admin
description: Organiser l'administratif d'un cabinet de santé, d'un service social ou médico-social — plannings et rendez-vous, procédures d'accueil, modèles de courriers administratifs, tableaux de suivi d'activité, check-lists de conformité — sans aucun contenu médical. À utiliser pour un cabinet libéral, une maison de santé, un centre social, une structure d'aide à domicile ou une association d'accompagnement.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Administratif d'un cabinet ou d'une structure sociale

## Ce que couvre cette skill
- Organisation des plannings, des rendez-vous et des remplacements.
- Procédures d'accueil (téléphone, secrétariat, urgences à réorienter vers le 15 ou le 112).
- Modèles de courriers **administratifs** (confirmation de rendez-vous, attestation de présence, relance de documents manquants).
- Tableaux de suivi d'activité anonymisés (nombre de rendez-vous, délais, absences).
- Check-lists : affichages obligatoires annoncés par l'utilisateur, registre RGPD, contrats et assurances, matériel.

## Ce qu'elle ne fait jamais
- **Aucun diagnostic, conseil médical, psychologique ou social individuel**, aucune interprétation de résultat, aucune décision de prise en charge : c'est le rôle des professionnels.
- Aucune donnée de santé ou de dossier social réel dans les échanges avec l'IA ; travailler sur des modèles et des données anonymisées.

## Règles
- Les données de santé sont des données sensibles (RGPD, article 9) ; leur hébergement par un prestataire demande en France un hébergeur certifié « HDS » (esante.gouv.fr, consulté le 2026-10-29).
- Secret professionnel : rien qui permette d'identifier une personne accompagnée.
- Aucun envoi de message aux patients ou usagers sans validation du professionnel.
