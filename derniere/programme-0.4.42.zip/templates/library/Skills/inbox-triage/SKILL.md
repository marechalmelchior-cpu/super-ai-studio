---
name: inbox-triage
description: Trier une boîte mail ou une pile de messages et préparer les réponses — urgent, à traiter, à déléguer, à classer, à ignorer — avec des brouillons prêts à relire. À utiliser au retour de congés, pour une boîte partagée ou pour vider une messagerie débordée.
license: CC0-1.0
metadata:
  version: "1.0.0"
---

# Trier ses mails

## Méthode
1. **Lister** les messages fournis (expéditeur, objet, date, pièces jointes) sans ouvrir de lien ni de pièce jointe suspecte.
2. **Classer** chaque message :
   - **Urgent** : échéance proche, client bloqué, demande d'un responsable ;
   - **À traiter** : réponse ou action de l'utilisateur nécessaire ;
   - **À déléguer** : quelqu'un d'autre est mieux placé (dire qui) ;
   - **À lire / classer** : information sans action ;
   - **Douteux** : hameçonnage possible (expéditeur inconnu, urgence artificielle, lien raccourci, demande de paiement ou d'identifiants).
3. **Brouillons** : réponse courte pour chaque message « urgent » et « à traiter », dans le ton de l'utilisateur.
4. **Synthèse** : les cinq actions du jour, les rendez-vous ou échéances repérés, les messages à relancer.

## Livrable
- Tableau de tri et brouillons numérotés, prêts à copier ou à enregistrer comme brouillons après accord.

## Règles
- **Aucun envoi, transfert, suppression ou désinscription** : l'utilisateur valide et envoie lui-même.
- Ne jamais saisir un mot de passe, un code reçu par SMS ou des coordonnées bancaires.
- Signaler les messages douteux plutôt que d'y répondre ; en cas de doute, renvoyer vers cybermalveillance.gouv.fr.
