"""Services facultatifs : uniquement sur accord enregistré, arrêt limité aux processus possédés."""
import time


def start_required(studio, required, stop_event=None, timeout=45):
    from . import ai, local_servers
    for engine in dict.fromkeys(row['engine'] for row in required):
        if stop_event and stop_event.is_set():
            raise RuntimeError('Démarrage interrompu par la fermeture du studio.')
        if not engine:
            raise ValueError('Ouvre le moteur local personnalisé sur le PC, puis réessaie.')
        local_servers.start(engine)
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if stop_event and stop_event.is_set():
            raise RuntimeError('Démarrage interrompu par la fermeture du studio.')
        if all(not ai.local_warning(studio.paths.data, row['id']) for row in required):
            return
        time.sleep(.25)
    raise RuntimeError('Le serveur local ne répond pas encore. La tâche reste en attente ; réessaie après vérification sur le PC.')


def start_selected(studio, port, stop_event):
    from . import local_servers, mobile
    if stop_event.is_set():
        return
    cfg = studio.cfg.get('local_server', {})
    if cfg.get('start_at_launch'):
        try:
            local_servers.start(cfg.get('default_engine', ''))
        except (ValueError, OSError) as error:
            from .security import redact
            studio.store.message('supervisor', 'Serveur local au démarrage : ' + redact(str(error)))
        if stop_event.is_set():
            local_servers.stop_owned()
            return
    if studio.cfg.get('interface', {}).get('phone_always_open'):
        result = mobile.start_relay(port, studio.paths.logs)
        if not result.get('ok'):
            studio.store.message('supervisor', 'Accès téléphone au démarrage indisponible. Vérifie Réglages › Téléphone.')
        if stop_event.is_set():
            mobile.stop_relay()
