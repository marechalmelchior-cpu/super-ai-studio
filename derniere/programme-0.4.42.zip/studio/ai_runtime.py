"""Choix explicites, inventaire local et disponibilité du Superviseur."""
from __future__ import annotations

from pathlib import Path
import os
from urllib.parse import urlparse

_inventories = {}


def validate_choice(studio, ident):
    from .agents import connected_sources
    from . import ai
    if not isinstance(ident, str):
        raise ValueError('Choix d’IA invalide.')
    if not ident:
        return
    source = next((s for s in connected_sources(studio) if s['id'] == ident), None)
    if not source or (ai.PROVIDERS.get(source.get('provider'), {}).get('seulement')):
        raise ValueError('L’IA demandée n’est plus connectée. Connecte-la dans Réglages › IA ; aucune autre IA ne sera utilisée.')


def is_local(c):
    from .ai import PROVIDERS
    address = c.get('url') or PROVIDERS.get(c.get('provider'), {}).get('url', '')
    try:
        return urlparse(address).hostname in ('127.0.0.1', 'localhost', '::1')
    except ValueError:
        return False


def offline_models(c, home=None):
    """Les manifestes attestent une installation ; un ancien cache HTTP ne suffit pas."""
    from . import ai
    if c.get('provider') != 'ollama' or ai._base(c) != ai.PROVIDERS['ollama']['url']:
        return None
    home = Path(home) if home is not None else Path.home()
    root = Path(os.environ.get('OLLAMA_MODELS') or home / '.ollama/models') / 'manifests'
    if not root.is_dir():
        return None
    models = []
    for file in root.glob('*/*/*/*'):
        if not file.is_file() or file.is_symlink():
            continue
        parts = file.relative_to(root).parts
        if len(parts) == 4:
            _, namespace, model, tag = parts
            models.append(('' if namespace == 'library' else namespace + '/') + model + ':' + tag)
    return sorted(set(models))


def recommended(studio, entries):
    from .agents import benchmarks, _normalize
    scores = {}
    for item in benchmarks(studio.paths.data).get('models', []):
        if item.get('score') is not None and item.get('category') == 'global':
            for name in (item.get('key', ''), item.get('ollama', '')):
                if name:
                    scores[_normalize(name)] = max(scores.get(_normalize(name), -1), float(item['score']))
    def score(name):
        return max(scores.get(_normalize(name), -1), scores.get(_normalize(name.removesuffix(':latest')), -1))
    best = max(entries, key=score, default='')
    return best if best and score(best) >= 0 else ''


def inventory(studio, c):
    from . import ai
    entries, error, source = [], '', 'server'
    try:
        entries = ai.list_models(c)
        available = True
    except (ai.AIError, OSError, ValueError):
        local = offline_models(c) if is_local(c) else None
        available = local is not None
        entries = local or []
        source = 'disk' if available else 'unavailable'
        error = ('Le serveur local est arrêté. Modèles installés lus sur le disque.' if available else
                 'Liste des modèles indisponible. Démarre l’IA locale puis réessaie.' if is_local(c) else
                 'Liste des modèles indisponible. Vérifie la connexion puis réessaie.')
    current = str(c.get('model') or '')
    missing = bool(is_local(c) and available and current and not model_present(current, entries))
    result = {'models': entries, 'available': available, 'source': source, 'error': error,
            'local': is_local(c), 'missing': missing, 'current': current,
            'recommended': recommended(studio, entries) if is_local(c) else ''}
    key = c.get('id', '')
    previous = _inventories.get(key)
    if source == 'server' and previous and previous.get('source') != 'server':
        from . import ai_effort, local_lifecycle
        local_lifecycle.forget_connection(c)
        for cache_key in list(ai_effort._cache):
            if cache_key[1] == key:
                ai_effort._cache.pop(cache_key, None)
        _inventories.pop(key, None)
    _inventories[key] = result
    return result


def model_present(name, entries):
    return name in entries or (':' not in name and name + ':latest' in entries)


def require_local_model(c):
    """Refuse un modèle supprimé ou non vérifiable, avant tout appel de génération."""
    from . import ai
    if not is_local(c):
        return
    try:
        entries = ai.list_models(c)
    except ai.AIError:
        entries = offline_models(c)
    if entries is None:
        raise ai.LocalServerUnavailable('Serveur local indisponible : clique sur « Lancer le serveur local », puis choisis un modèle installé.')
    if not c.get('model') or not model_present(c['model'], entries):
        raise ai.AIError('Le modèle sélectionné n’est plus installé. Choisis un modèle installé dans Réglages › IA.')


def preflight(studio):
    from . import ai
    actor, c = ai.choice(studio, 'supervisor')
    selected = ai.read_file(studio.paths.data).get('supervisor', '')
    ident = selected or (c or {}).get('id') or actor
    error = ''
    try:
        validate_choice(studio, ident)
        if not actor:
            raise ValueError('Aucune IA connectée pour le Superviseur.')
        if c:
            if is_local(c):
                require_local_model(c)
            ai._request(c, '/models', delay=3)
        else:
            executor = studio.executors.get(actor)
            if executor is None or not executor.available()[0]:
                raise ValueError('L’outil du Superviseur ne répond pas. Vérifie sa connexion.')
    except (ValueError, ai.AIError, OSError) as e:
        from .security import redact
        error = redact(str(e))
    data = ai.read_file(studio.paths.data)
    last = data.get('last_supervisor', '')
    fallback = ''
    last_model = data.get('last_supervisor_model', '')
    if error and last and (last != ident or (c and last_model and last_model != c.get('model'))):
        try:
            validate_choice(studio, last)
            fallback = last
        except ValueError:
            pass
    return {'ok': not error, 'error': error, 'ai': ident, 'fallback': fallback, 'fallback_model': last_model if fallback else '',
            'local_unavailable': bool(error and c and is_local(c))}


def remember_success(studio, info=None):
    from . import ai
    actor, c = ai.choice(studio, 'supervisor')
    with ai._lock:
        d = ai.read_file(studio.paths.data)
        d['last_supervisor'] = ((info or {}).get('connection') or (info or {}).get('actor')
                                or (c or {}).get('id') or actor)
        d['last_supervisor_model'] = (info or {}).get('model') or (c or {}).get('model', '')
        ai._write(studio.paths.data, d)


def model_label(c, name):
    if not c or not name or not is_local(c):
        return name
    entries = offline_models(c)
    cached = _inventories.get(c.get('id', ''), {})
    if entries is None and cached.get('available'):
        entries = cached.get('models')
    return name + (' · plus installé' if entries is not None and not model_present(name, entries) else '')


def start_local(studio, ident):
    from . import ai, local_models
    c = ai.connection(studio.paths.data, ident)
    if not c or not is_local(c):
        raise ValueError('Ce démarrage concerne seulement une IA locale connectée.')
    from .local_servers import start
    if c.get("provider") in ("ollama", "lmstudio") and ai._base(c) == ai.PROVIDERS[c["provider"]]["url"]:
        return start(c["provider"])
    raise ValueError('Ouvre ce moteur sur le PC, puis démarre son serveur local.')
