"""Cycle de la fenêtre native et repli avec le profil persistant du studio."""
from __future__ import annotations

import json
import os
import shlex
import shutil
import subprocess
import sys
import threading
from pathlib import Path

from .connectors.base import NO_WINDOW

WEBVIEW_INSTALL = "https://developer.microsoft.com/microsoft-edge/webview2/"


def geometry(data):
    try:
        values = json.loads((Path(data) / "window.json").read_text(encoding="utf-8"))
    except (OSError, ValueError, TypeError):
        values = {}
    out = {}
    for source, target, lower, upper in (("l", "width", 400, 10000), ("h", "height", 300, 10000),
                                         ("x", "x", -10000, 20000), ("y", "y", -10000, 20000)):
        v = values.get(source)
        if type(v) is int and lower <= v <= upper:
            out[target] = v
    return {"width": 1280, "height": 840, **out, "maximized": bool(values.get("maximized")),
            "fullscreen": bool(values.get("fullscreen"))}


def save_geometry(data, window):
    if data is None:
        return
    values = {"x": int(window.x), "y": int(window.y), "l": int(window.width), "h": int(window.height),
              "maximized": bool(getattr(window, "_studio_maximized", False)), "fullscreen": bool(window.fullscreen)}
    path = Path(data) / "window.json"
    if values["maximized"] or values["fullscreen"]:
        old = geometry(data)
        values.update(x=old.get("x", 0), y=old.get("y", 0), l=old["width"], h=old["height"])
    path.write_text(json.dumps(values), encoding="utf-8")


def default_browser():
    """Executable selected by the OS, never a shell command containing the studio URL."""
    try:
        if sys.platform == "win32":
            import winreg
            key = r"Software\Microsoft\Windows\Shell\Associations\UrlAssociations\https\UserChoice"
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, key) as k:
                prog = winreg.QueryValueEx(k, "ProgId")[0]
            with winreg.OpenKey(winreg.HKEY_CLASSES_ROOT, prog + r"\shell\open\command") as k:
                cmd = winreg.QueryValueEx(k, "")[0]
            return shlex.split(os.path.expandvars(cmd), posix=False)[0].strip('"')
        if sys.platform == "darwin":
            import plistlib
            file = Path.home() / "Library/Preferences/com.apple.LaunchServices/com.apple.launchservices.secure.plist"
            handlers = plistlib.loads(file.read_bytes()).get("LSHandlers", [])
            bundle = next(r["LSHandlerRoleAll"] for r in handlers if r.get("LSHandlerURLScheme") == "https")
            result = subprocess.run(["mdfind", f"kMDItemCFBundleIdentifier == '{bundle}'"], capture_output=True, text=True, errors="replace", timeout=3)
            for app in result.stdout.splitlines():
                info = plistlib.loads((Path(app) / "Contents/Info.plist").read_bytes())
                return str(Path(app) / "Contents/MacOS" / info["CFBundleExecutable"])
        else:
            result = subprocess.run(["xdg-settings", "get", "default-web-browser"], capture_output=True, text=True, errors="replace", timeout=3)
            name = result.stdout.strip()
            for folder in (Path.home() / ".local/share/applications", Path("/usr/share/applications")):
                if name and Path(name).name == name:
                    for line in (folder / name).read_text(encoding="utf-8").splitlines():
                        if line.startswith("Exec="):
                            return shutil.which(shlex.split(line[5:])[0])
    except (OSError, ValueError, KeyError, StopIteration, subprocess.SubprocessError):
        pass
    return None


def browser_candidates():
    selected = default_browser()
    candidates = []
    if selected and any(n in Path(selected).name.lower() for n in ("brave", "chrome", "chromium", "edge", "vivaldi", "opera")):
        candidates.append(selected)
    if sys.platform == "win32":
        for base in (os.environ.get("ProgramFiles(x86)"), os.environ.get("ProgramFiles"), os.environ.get("LOCALAPPDATA")):
            if base:
                edge = Path(base) / "Microsoft/Edge/Application/msedge.exe"
                if edge.is_file():
                    candidates.append(str(edge))
    else:
        from .os_support import browser_app
        other = browser_app()
        if other:
            candidates.append(other)
    return list(dict.fromkeys(candidates))


def focus_process(pid):
    if sys.platform == "darwin":
        result = subprocess.run(["osascript", "-e", 'tell application "System Events" to set frontmost of '
                                 f'first application process whose unix id is {int(pid)} to true'],
                                capture_output=True, timeout=3)
        return result.returncode == 0
    if sys.platform != "win32":
        if shutil.which("wmctrl"):
            result = subprocess.run(["wmctrl", "-lp"], capture_output=True, text=True, errors="replace", timeout=3)
            for line in result.stdout.splitlines():
                fields = line.split(None, 4)
                if len(fields) > 2 and fields[2] == str(pid):
                    return subprocess.run(["wmctrl", "-ia", fields[0]], capture_output=True, timeout=3).returncode == 0
        if shutil.which("xdotool"):
            result = subprocess.run(["xdotool", "search", "--pid", str(pid)], capture_output=True, text=True, errors="replace", timeout=3)
            handle = next((line for line in result.stdout.splitlines() if line.isdigit()), "")
            if handle:
                return subprocess.run(["xdotool", "windowactivate", handle], capture_output=True, timeout=3).returncode == 0
        return False
    import ctypes
    user = ctypes.windll.user32
    found = []
    callback_type = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)
    def visit(handle, _):
        process = ctypes.c_ulong()
        user.GetWindowThreadProcessId(handle, ctypes.byref(process))
        if process.value == pid and user.IsWindowVisible(handle):
            user.ShowWindow(handle, 9)
            user.SetForegroundWindow(handle)
            found.append(handle)
        return True
    user.EnumWindows(callback_type(visit), 0)
    return bool(found)


def close_process(process):
    if process.poll() is not None:
        return
    if sys.platform == "win32":
        subprocess.run(["taskkill", "/PID", str(process.pid), "/T", "/F"], capture_output=True, timeout=10, **NO_WINDOW)
    else:
        import signal
        os.killpg(process.pid, signal.SIGTERM)
    try:
        process.wait(timeout=10)
    except subprocess.TimeoutExpired:
        if sys.platform != "win32":
            import signal
            os.killpg(process.pid, signal.SIGKILL)
        else:
            process.kill()
        process.wait(timeout=5)


def browser_window(url, data, controller):
    from .launcher import window_options
    import time
    if data is None:
        from .first_launch import session_file
        data = session_file().parent / "browser"
    import secrets
    url = url.split("#", 1)[0] + "#studio-hosted=" + secrets.token_hex(12)
    candidates = browser_candidates()
    if sys.platform == "win32":
        from .browser_host import run
        return run(url, data, controller, candidates, window_options(data))
    for exe in candidates:
        process = subprocess.Popen([exe, f"--app={url}", *window_options(data)],
                                   stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                   start_new_session=True)
        try:
            if process.wait(timeout=1) != 0:
                continue
        except subprocess.TimeoutExpired:
            pass
        controller.window_opened()
        controller.focus = lambda: focus_browser(process.pid if process.poll() is None else None, data)
        try:
            while not controller.stop_request.wait(.2):
                if controller.window_close_request.is_set():
                    break
                if controller.left_at is not None and time.monotonic() - controller.left_at >= 10:
                    break
                if controller.absence_delay_s is not None and time.monotonic() - controller.last_seen > controller.absence_delay_s:
                    break
        finally:
            controller.window_closed()
        return
    raise RuntimeError("Aucun navigateur compatible ne peut ouvrir une fenêtre d’application.")


def focus_browser(pid, data):
    if pid is not None and focus_process(pid):
        return True
    if sys.platform != "win32" or data is None:
        return False
    # Le premier processus peut être sorti après délégation au propriétaire du profil.
    import re
    profile = os.path.normcase(os.path.normpath(str(Path(data) / "edge-studio")))
    script = "Get-CimInstance Win32_Process | Select-Object ProcessId,CommandLine | ConvertTo-Json -Compress"
    try:
        result = subprocess.run(["powershell.exe", "-NoProfile", "-NonInteractive", "-Command", script],
                                capture_output=True, text=True, errors="replace", timeout=5, **NO_WINDOW)
        rows = json.loads(result.stdout)
        for row in rows if isinstance(rows, list) else [rows]:
            command = row.get("CommandLine") or ""
            match = re.search(r'(?:"--user-data-dir=([^"]+)"|--user-data-dir="([^"]+)"|--user-data-dir=([^\s"]+))', command)
            value = next((v for v in match.groups() if v is not None), "") if match else ""
            if os.path.normcase(os.path.normpath(value)) == profile:
                if focus_process(int(row["ProcessId"])):
                    return True
    except (OSError, ValueError, TypeError, subprocess.SubprocessError):
        pass
    return False


def open_window(url, data, controller, title, note=lambda text: None, message=lambda text: None, webview=None):
    finished = threading.Event()
    anchor = None
    failed = threading.Event()
    failures = []
    current = [None]
    try:
        if webview is None:
            import webview
        controller.desktop = True

        def create():
            options = geometry(data)
            window = webview.create_window(title, url, min_size=(400, 300), text_select=True, **options)
            current[0] = window
            window._studio_maximized = options["maximized"]
            controller.window_opened()

            def save(*_):
                try:
                    save_geometry(data, window)
                except (OSError, ValueError, TypeError):
                    pass

            def closing(*_):
                save()
                from .window_handoff import waiting
                if controller.stop_request.is_set() and waiting(controller):
                    controller.handoff_cancelled = True
                if failed.is_set() or controller.stop_request.is_set() or controller.window_close_request.is_set():
                    return True
                result = controller.close_window()
                if result.get("needs_choice") or result.get("pausing"):
                    def ask():
                        try:
                            window.evaluate_js("window.requestStudioClose(false)")
                        except Exception:
                            pass  # Le prochain signal de présence redemandera le choix.
                    threading.Thread(target=ask, daemon=True).start()
                    return False
                return True

            def closed(*_):
                if not failed.is_set() and current[0] is window:
                    current[0] = None
                    controller.window_closed()

            def focus():
                window.restore()
                window.show()
                if sys.platform == "win32" and getattr(window, "native", None):
                    window.native.Activate()
                return True

            from .window_handoff import displayed
            if hasattr(window.events, "shown"):
                window.events.shown += lambda *_: displayed(data)
            window.events.moved += save
            window.events.resized += save
            window.events.closing += closing
            window.events.maximized += lambda *_: setattr(window, "_studio_maximized", True)
            window.events.restored += lambda *_: setattr(window, "_studio_maximized", False)
            window.events.closed += closed
            controller.focus = focus
            return window

        create()
        # Cette fenêtre invisible maintient la boucle graphique pour recréer une vraie fenêtre ensuite.
        anchor = webview.create_window(title, html="<html lang='fr'></html>", hidden=True)

        def watch():
            try:
                while not finished.wait(.2):
                    from .window_handoff import waiting
                    if controller.stop_request.is_set() and waiting(controller):
                        if getattr(controller, "handoff_failed", False) and not getattr(controller, "handoff_error_shown", False):
                            controller.handoff_error_shown = True
                            message("La nouvelle fenêtre n’a pas confirmé son ouverture. Ferme ce cadre avec sa croix, puis relance le raccourci.")
                        continue
                    if controller.stop_request.is_set():
                        if current[0] is not None:
                            current[0].destroy()
                        anchor.destroy()
                        return
                    if controller.window_close_request.is_set() and current[0] is not None:
                        current[0].destroy()
                    if controller.open_request.is_set():
                        controller.open_request.clear()
                        if current[0] is None:
                            create()
                        else:
                            controller.focus()
            except Exception as error:
                failures.append(error)
                failed.set()
                if current[0] is not None:
                    current[0].destroy()
                anchor.destroy()
        threading.Thread(target=watch, daemon=True).start()
        icon = Path(__file__).parent / "ui/static/studio.ico"
        webview.start(gui="edgechromium" if sys.platform == "win32" else None,
                      icon=str(icon), private_mode=False, storage_path=str(Path(data) / "native-window") if data else None)
        if failures:
            raise failures[0]
        note("boucle de fenêtre native terminée")
        return
    except Exception as error:
        failed.set()
        note("fenêtre native indisponible : " + type(error).__name__)
        if current[0] is not None:
            try:
                current[0].destroy()
            except Exception:
                pass
        if anchor is not None:
            try:
                anchor.destroy()
            except Exception:
                pass
        if sys.platform == "win32" and not isinstance(error, ImportError):
            message("La fenêtre native n’a pas pu s’ouvrir. Si le moteur web du système manque, installe-le depuis "
                    + WEBVIEW_INSTALL + "\nLe studio va essayer une fenêtre de navigateur.")
    finally:
        finished.set()
        controller.focus = lambda: False
    controller.desktop = False
    browser_window(url, data, controller)


def browser_handles():
    if sys.platform != "win32":
        return {}
    import ctypes
    from ctypes import wintypes
    user = ctypes.windll.user32
    user.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
    found = {}
    callback = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
    def visit(handle, _):
        name = ctypes.create_unicode_buffer(256)
        user.GetClassNameW(wintypes.HWND(handle), name, 256)
        if name.value.startswith("Chrome_WidgetWin") and user.IsWindowVisible(wintypes.HWND(handle)):
            pid = wintypes.DWORD()
            user.GetWindowThreadProcessId(wintypes.HWND(handle), ctypes.byref(pid))
            found[int(handle)] = pid.value
        return True
    user.EnumWindows(callback(visit), 0)
    return found


def owned_browser_handle(before, pid, data):
    after = browser_handles()
    candidates = [(handle, owner) for handle, owner in after.items() if handle not in before]
    owned = [handle for handle, owner in candidates if owner == pid]
    if len(owned) == 1:
        return owned[0]
    # Une délégation ne donne pas le PID final : sa ligne de commande doit attester le profil exact.
    if sys.platform == "win32" and candidates:
        profile = os.path.normcase(os.path.normpath(str(Path(data) / "edge-studio")))
        script = "Get-CimInstance Win32_Process | Select-Object ProcessId,CommandLine | ConvertTo-Json -Compress"
        try:
            result = subprocess.run(["powershell.exe", "-NoProfile", "-NonInteractive", "-Command", script],
                                    capture_output=True, text=True, errors="replace", timeout=5, **NO_WINDOW)
            import re
            rows = json.loads(result.stdout or "[]")
            owners = set()
            for row in rows if isinstance(rows, list) else [rows]:
                match = re.search(r'(?:"--user-data-dir=([^"]+)"|--user-data-dir="([^"]+)"|--user-data-dir=([^\s"]+))', row.get("CommandLine") or "")
                value = next((v for v in match.groups() if v is not None), "") if match else ""
                if os.path.normcase(os.path.normpath(value)) == profile:
                    owners.add(int(row["ProcessId"]))
            owned = [handle for handle, owner in candidates if owner in owners]
        except (OSError, ValueError, TypeError, subprocess.SubprocessError):
            return None
    return owned[0] if len(owned) == 1 else None


def close_browser_handle(handle):
    if sys.platform == "win32":
        import ctypes
        from ctypes import wintypes
        ctypes.windll.user32.PostMessageW(wintypes.HWND(handle), 0x0010, 0, 0)
