"""Extensions: skills, connectors (MCP servers and PC software) and packs, to discover and install.

Rules:
- Curated catalogue (templates/catalog.json, updated with the studio). Anthropic skills come from a pinned commit
  of github.com/anthropics/skills: every file is checked (SHA-256) before being written.
- Nothing is ever overwritten: a skill already present is not replaced. "Remove" moves it to Archives, deletes nothing.
- MCP servers: configuration added to data/mcp.json, used by the agents. Keys are encrypted
  (DPAPI on Windows) in data/mcp-secrets.json and passed to agents through environment variables, never in plain text
  in a file. The server package (npx, uvx) downloads on first use: the studio says so before installing.
- Software: detected on the PC and declared to agents; never installed by the studio (official link and winget
  command to run yourself).
- Imported skill (.zip): checked (paths, size, SKILL.md) and reviewed (scripts, web addresses, suspicious instructions).
"""
from __future__ import annotations

import glob
import hashlib
import io
from .migrations import compatibility as json
import os
import re
import shutil
import time
import urllib.parse
import urllib.request
import zipfile
from .migrations.compatibility import TechnicalPath as Path

from .user_workspace import CODE, TEMPLATES

MAX_IMPORT = 30 * 1024 * 1024
_ID = re.compile(r"^[a-z0-9][a-z0-9-]{0,60}$")
PREREQUISITES = {"node": ("npx", "Node.js", "https://nodejs.org/fr/download"),
             "uv": ("uvx", "uv (Astral)", "https://docs.astral.sh/uv/getting-started/installation/")}


_DATA: dict = {}


def catalog() -> dict:
    """Catalogue shipped with the studio, or the one published since (data/catalogue-maj.json, updated daily) if
    it is newer."""
    try:
        base = json.normalize_catalog(json.loads((TEMPLATES / "catalog.json").read_text(encoding="utf-8")))
    except (OSError, ValueError):
        base = {"categories": {}, "new": [], "elements": []}
    d = _DATA.get("data")
    if d:
        update_info = json.normalize_catalog(_read_json(Path(d) / "catalog-update.json", {}))
        if isinstance(update_info, dict) and isinstance(update_info.get("elements"), list) and str(update_info.get("version", "")) > str(base.get("version", "")):
            return update_info
    return base


def refresh_catalog(data: Path, repository: str, force: bool = False) -> dict:
    """Daily: catalogue published in the studio repository (catalogue/catalogue.json). Nothing is installed."""
    _DATA["data"] = str(data)
    f = Path(data) / "catalog-update.json"
    if not repository or (not force and f.exists() and time.time() - f.stat().st_mtime < 24 * 3600):
        return {"ok": True, "fresh": True}
    try:
        d = json.normalize_catalog(json.loads(_download(f"https://raw.githubusercontent.com/{repository}/main/catalogue/catalogue.json", 20)))
        if not isinstance(d.get("elements"), list):
            raise ValueError("format inattendu")
        _write_json(f, d)
        return {"ok": True}
    except Exception as e:                               # noqa: BLE001 — offline: shipped catalogue kept
        return {"ok": False, "error": type(e).__name__}


def _element(ident: str) -> dict:
    e = next((x for x in catalog()["elements"] if x["id"] == ident), None)
    if not e:
        raise ValueError("Élément inconnu du catalogue.")
    return e


# ------------------------------------------------------------------ state files
def _read_json(f: Path, fallback):
    try:
        return (json.raw_loads if f.name in json.OPAQUE_JSON_FILES else json.loads)(f.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return fallback


def _write_json(f: Path, d) -> None:
    f.parent.mkdir(parents=True, exist_ok=True)
    t = f.with_suffix(f.suffix + ".tmp")
    t.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
    os.replace(t, f)


def mcp_file(data: Path) -> Path:
    return Path(data) / "mcp.json"


def installed_mcp(data: Path) -> dict:
    d = _read_json(mcp_file(data), {})
    return d.get("mcpServers", {}) if isinstance(d, dict) else {}


_VARIABLE = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)\}")


def referenced_variables(servers: dict) -> set[str]:
    """${NAME} variables used by these servers (arguments, address, headers, environment)."""
    return set(_VARIABLE.findall(json.dumps(servers, ensure_ascii=False)))


def env_mcp(data: Path, servers: dict | None = None) -> dict:
    """MCP server variables (decrypted keys) for the agent process, never written anywhere else. ``servers``: only the
    variables those servers use (a task gets the keys of its own servers, not all of them)."""
    from .ai import _decrypt
    wanted = None if servers is None else referenced_variables(servers)
    out = {}
    for k, v in _read_json(Path(data) / "mcp-secrets.json", {}).items():
        if wanted is not None and k not in wanted:
            continue
        try:
            out[k] = _decrypt(v)
        except Exception:                                # noqa: BLE001 — unreadable key: the server will report it missing
            pass
    return out


# ------------------------------------------------------------------ what is installed
def _present_skills(root_dir: Path) -> dict[str, dict]:
    out = {}
    d = Path(root_dir) / "Skills"
    for s in sorted(d.glob("*/SKILL.md")) if d.is_dir() else []:
        if s.parent.name in ("supervisor", "supervisor"):   # Supervisor method: reserved, never listed
            continue
        meta = _read_json(s.parent / ".library.json", {})
        text = s.read_text(encoding="utf-8", errors="replace")
        desc = re.search(r"(?mi)^description:\s*[\"']?(.+?)[\"']?\s*$", text)
        title = re.search(r"(?m)^#\s+(.+?)\s*$", text.split("---", 2)[-1] if text.startswith("---") else text)
        out[s.parent.name] = {"source": meta.get("source", "studio"), "description": desc.group(1)[:200] if desc else "",
                              "title": title.group(1)[:60] if title else "", "core": (TEMPLATES / "workspace" / "Skills" / s.parent.name).is_dir()}
    return out


def detect_software(e: dict) -> str:
    for exe in e.get("executables", []):
        p = shutil.which(exe)
        if p:
            return p
    for pattern in e.get("paths", []):
        candidates = sorted(glob.glob(os.path.expanduser(pattern)))
        if candidates:
            return candidates[-1]
    return ""


def state(studio) -> dict:
    from . import software_connectors
    _DATA["data"] = str(studio.paths.data)
    cat = catalog()
    skills = _present_skills(studio.paths.root)
    mcp = installed_mcp(studio.paths.data)
    software_items = {c["name"].lower(): c for c in software_connectors.list_all(studio)}
    from .user_workspace import packs_state
    local_packs = {p["id"]: p for p in packs_state(studio.paths.root)}
    by_id = {e["id"]: e for e in cat["elements"]}
    elements = []
    for e in cat["elements"]:
        x = {k: v for k, v in e.items() if k not in ("source", "config", "paths", "executables")}
        if e["type"] == "skill":
            x["installed"] = e["id"] in skills
        elif e["type"] == "mcp":
            x["installed"] = e["id"] in mcp
            x["missing"] = [PREREQUISITES[p][1] for p in e.get("prerequisites", []) if not shutil.which(PREREQUISITES[p][0])]
        elif e["type"] == "software":
            declared = e["name"].lower() in software_items
            found = declared or bool(detect_software(e))
            x["installed"] = found                       # found on the PC: the agents know it, nothing to add
            x["found"] = found
            x["auto"] = found and not declared
        elif e["type"] == "pack":
            x["member_states"] = {m: _member_installed(m, skills, mcp, software_items, local_packs, by_id) for m in e["members"]}
            x["installed"] = all(x["member_states"][m] for m in (e.get("base") or e["members"]))
        x["new"] = e["id"] in cat.get("new", [])
        elements.append(x)
    known = {e["id"] for e in cat["elements"]}
    for name, s in skills.items():                         # your skills outside the catalogue (base, personal, imported)
        if name not in known:
            elements.append({"id": name, "type": "skill", "name": s["title"] or name.replace("-", " ").capitalize(), "description": s["description"],
                             "core": s["core"],
                             "author": {"import": "Importée", "studio": "Le studio"}.get(s["source"], "Toi"), "checked": s["source"] == "studio",
                             "category": "custom", "installed": True, "outside_catalog": True})
    for name in mcp:
        if name not in known:
            elements.append({"id": name, "type": "mcp", "name": name, "description": "Serveur MCP ajouté à la main.", "author": "Toi",
                             "checked": False, "category": "custom", "installed": True, "outside_catalog": True})
    category_names = {e["name"].lower() for e in cat["elements"] if e["type"] == "software"}
    for c in software_items.values():
        if c["name"].lower() not in category_names:
            elements.append({"id": c["id"], "type": "software", "name": c["name"], "description": c.get("path_value", ""), "author": "Toi",
                             "checked": False, "category": "custom", "installed": True, "outside_catalog": True, "found": c.get("ok", False)})
    return {"elements": elements, "categories": cat.get("categories", {}), "for_you": for_you(studio, elements)}


def _member_installed(m: str, skills, mcp, software_items, local_packs, by_id=None) -> bool:
    if m.startswith("pack:"):
        return bool(local_packs.get(json.canonical(m[5:]), {}).get("installed"))
    e = by_id.get(m) if by_id is not None else next((x for x in catalog()["elements"] if x["id"] == m), None)
    if not e:
        return True
    return (m in skills if e["type"] == "skill" else m in mcp if e["type"] == "mcp"
            else e["name"].lower() in software_items if e["type"] == "software" else False)


def for_you(studio, elements: list[dict]) -> list[str]:
    """Recommendations based on your projects and your PC (never what is already installed)."""
    desired: list[str] = []
    for t in studio.registry.all():
        if not t.has_path:
            continue
        try:
            p = t.path()
            names = {x.name.lower() for x in p.iterdir()} if p.is_dir() else set()
        except OSError:
            continue
        if any(n.endswith(".uproject") for n in names) or t.extra.get("type") == "unreal" or "project.godot" in names:
            desired += ["video-game-domain", "game-design-document", "level-design"]
        if {"package.json", "index.html", "vite.config.js", "vite.config.ts"} & names:
            desired += ["domain-web", "playwright", "seo-web-content"]
        if any(n.endswith((".blend", ".fbx", ".glb")) for n in names):
            desired += ["domain-3d", "3d-asset-pipeline"]
        if (p / ".git").exists():
            desired += ["git"]
    if studio.cfg.get("tools", {}).get("blender"):
        desired += ["blender-mcp"]
    desired += ["domain-bureau", "context7", "skill-creator", "domain-design", "code-review", "research-digest"]
    installed = {e["id"] for e in elements if e.get("installed")}
    out = []
    for v in desired:
        if v not in installed and v not in out:
            out.append(v)
    return out[:6]


# ------------------------------------------------------------------ install
def _download(url: str, delay: float = 60) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": "SuperAIStudio"})
    with urllib.request.urlopen(req, timeout=delay) as r:
        return r.read()


def install(studio, ident: str, value_map: dict | None = None, download=None) -> dict:
    e = _element(ident)
    value_map = value_map or {}
    if e["type"] == "skill":
        return _install_skill(studio, e, download or _download)
    if e["type"] == "mcp":
        return _install_mcp(studio, e, value_map)
    if e["type"] == "software":
        return _install_software(studio, e, str(value_map.get("path_value", "")))
    if e["type"] == "pack":
        done_items, notes = [], []
        choice = value_map.get("selection")
        members = [m for m in e["members"] if m in choice] if isinstance(choice, list) else list(e.get("base") or e["members"])
        for m in members:
            try:
                if m.startswith("pack:"):
                    from .user_workspace import install_pack, name
                    install_pack(studio.paths.root, m[5:], name())
                    done_items.append(m)
                    continue
                r = install(studio, m, value_map.get(m) if isinstance(value_map.get(m), dict) else {}, download)
                if r.get("ok"):
                    done_items.append(m)
            except ValueError as ex:
                notes.append(f"{_element(m)['name'] if not m.startswith('pack:') else m} : {ex}")
        _reload_roles(studio)
        return {"ok": True, "installed": done_items, "notes": notes,
                "message": f"Pack installé ({len(done_items)} élément(s))" + (" — à compléter : " + " ; ".join(notes) if notes else ".")}
    raise ValueError("Type inconnu.")


def _reload_roles(studio) -> None:
    try:
        from .orchestrator.roles import load_roles
        studio.roles = load_roles(studio.paths.roles)
    except Exception:                                    # noqa: BLE001
        pass


def _install_skill(studio, e: dict, download) -> dict:
    dest = Path(studio.paths.root) / "Skills" / e["id"]
    if (dest / "SKILL.md").exists():
        return {"ok": True, "already": True, "message": f"« {e['name']} » est déjà installée."}
    src = e["source"]
    if src["type"] == "studio":
        from .user_workspace import install_pack, name
        install_pack(studio.paths.root, src["pack"], name())
        _reload_roles(studio)
    elif src["type"] == "studio-skill":
        orig = TEMPLATES / src["folder"]
        if not (orig / "SKILL.md").is_file():
            raise ValueError("Skill absente de cette version du studio : mets le studio à jour.")
        for f in sorted(orig.rglob("*")):
            if f.is_file():
                (dest / f.relative_to(orig)).parent.mkdir(parents=True, exist_ok=True)
                (dest / f.relative_to(orig)).write_bytes(f.read_bytes())
        _write_json(dest / ".library.json", {"source": "catalog", "installed": time.strftime("%Y-%m-%d %H:%M")})
    elif src["type"] == "github":
        contents = {}
        for f in src["files"]:
            if ".." in f["path_value"].split("/") or f["path_value"].startswith("/"):
                raise ValueError("Chemin refusé dans le catalogue.")
            url = (f"https://raw.githubusercontent.com/{src['repository']}/{src['commit']}/"
                   + urllib.parse.quote(f"{src['folder']}/{f['path_value']}"))
            try:
                b = download(url)
            except OSError as ex:
                raise ValueError(f"Téléchargement impossible ({type(ex).__name__}) : vérifie la connexion internet.") from None
            if hashlib.sha256(b).hexdigest() != f["sha256"]:
                raise ValueError(f"Fichier altéré ({f['path_value']}) : rien n'est installé.")
            contents[f["path_value"]] = b
        tmp = dest.with_name(f".{e['id']}.installation")
        if tmp.exists():
            shutil.rmtree(tmp)
        for path_value, b in contents.items():                # everything checked before writing, then folder replaced in one go
            (tmp / path_value).parent.mkdir(parents=True, exist_ok=True)
            (tmp / path_value).write_bytes(b)
        _write_json(tmp / ".library.json", {"source": "catalog", "repository": src["repository"], "commit": src["commit"],
                                                  "installed": time.strftime("%Y-%m-%d %H:%M"), "licence": e.get("licence", "")})
        tmp.rename(dest)
    _synchronize(studio)
    return {"ok": True, "message": f"« {e['name']} » installée : les agents l'utilisent dès maintenant."}


def _synchronize(studio) -> None:
    try:
        from .supervisor import sync_skills
        sync_skills(studio.paths.root)
    except Exception:                                    # noqa: BLE001 — « Synchroniser les skills » is still possible
        pass


def _install_mcp(studio, e: dict, value_map: dict) -> dict:
    needs = [p for p in e.get("prerequisites", []) if not shutil.which(PREREQUISITES[p][0])]
    if needs:
        n, link = PREREQUISITES[needs[0]][1], PREREQUISITES[needs[0]][2]
        raise ValueError(f"Il faut d'abord {n} sur le PC : {link} (installe-le, puis réessaie).")
    from .ai import _encrypt
    secrets_f = Path(studio.paths.data) / "mcp-secrets.json"
    secrets = _read_json(secrets_f, {})
    for v in e.get("variables", []):
        val = str(value_map.get(v["name"], "")).strip()
        if not val and v.get("secret"):
            raise ValueError(f"{v['label']} : obligatoire.")
        if val:
            if "\n" in val or len(val) > 2000:
                raise ValueError(f"{v['label']} : valeur invalide.")
            secrets[v["name"]] = _encrypt(val)
    _write_json(secrets_f, secrets)
    d = _read_json(mcp_file(studio.paths.data), {})
    d = d if isinstance(d, dict) else {}
    d.setdefault("mcpServers", {})[e["id"]] = e["config"]
    _write_json(mcp_file(studio.paths.data), d)
    return {"ok": True, "message": f"« {e['name']} » ajouté : les agents Claude Code l'utilisent dès la prochaine tâche."
                                   + (" Le serveur se télécharge à sa première utilisation." if e.get("prerequisites") else "")}


def _install_software(studio, e: dict, path_value: str) -> dict:
    from . import software_connectors
    path_value = path_value or detect_software(e)
    if not path_value:
        raise ValueError(f"{e['name']} n'est pas trouvé sur le PC. Installe-le depuis {e['site']}"
                         + (f" (ou dans PowerShell : winget install --id {e['winget']} -e)" if e.get("winget") else "")
                         + ", puis réessaie.")
    software_connectors.add_item(studio, e["name"], path_value)
    return {"ok": True, "message": f"{e['name']} déclaré aux agents ({path_value})."}


# ------------------------------------------------------------------ remove (nothing is deleted)
def removed(studio, ident: str, type_: str) -> dict:
    from . import software_connectors
    if not _ID.match(ident or ""):
        raise ValueError("Identifiant invalide.")
    if type_ == "skill":
        src = Path(studio.paths.root) / "Skills" / ident
        if not (src / "SKILL.md").exists():
            raise ValueError("Skill introuvable.")
        if ident == "supervisor" or (TEMPLATES / "workspace" / "Skills" / ident).is_dir():
            raise ValueError("Cette skill fait partie de la méthode du studio : elle reste.")
        archive = studio.paths.archives / "skills-retires" / f"{ident}-{time.strftime('%Y%m%d-%H%M%S')}"
        archive.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(src), str(archive))
        home = Path.home()
        for tool in (".claude", ".codex"):               # copies made by the studio: archived with it
            copy_dir = home / tool / "skills" / f"studio-{ident}"
            if (copy_dir / "SKILL.md").exists() and "genere-par-ai-workspace" in (copy_dir / "SKILL.md").read_text(encoding="utf-8", errors="replace"):
                shutil.move(str(copy_dir), str(archive / f"copy-{tool.strip('.')}"))
        return {"ok": True, "message": f"Skill rangée dans Archives\\skills-retires ({archive.name})."}
    if type_ == "mcp":
        d = _read_json(mcp_file(studio.paths.data), {})
        cfg = (d.get("mcpServers") or {}).pop(ident, None) if isinstance(d, dict) else None
        if cfg is None:
            raise ValueError("Serveur MCP introuvable.")
        _write_json(mcp_file(studio.paths.data), d)
        names = set(re.findall(r"\$\{([A-Z0-9_]+)\}", json.dumps(cfg)))
        others = set(re.findall(r"\$\{([A-Z0-9_]+)\}", json.dumps(d.get("mcpServers", {}))))
        sec_f = Path(studio.paths.data) / "mcp-secrets.json"
        sec = _read_json(sec_f, {})
        _write_json(sec_f, {k: v for k, v in sec.items() if k not in names - others})
        return {"ok": True, "message": "Serveur MCP retiré (les agents ne l'utilisent plus)."}
    if type_ == "software":
        e = next((x for x in catalog()["elements"] if x["id"] == ident), None)
        name = (e or {}).get("name", "").lower()
        c = next((x for x in software_connectors.list_all(studio) if (x["name"].lower() == name if e else x["id"] == ident)), None)
        if not c:
            raise ValueError("Logiciel non déclaré.")
        software_connectors.removed(studio, c["id"])
        return {"ok": True, "message": f"{c['name']} n'est plus déclaré aux agents (rien n'est désinstallé)."}
    raise ValueError("Ce type ne se retire pas d'un bloc : retire ses éléments un par un.")


# ------------------------------------------------------------------ import a skill (.zip)
SUSPECTS = [(r"(?i)ignore (all |the )?(previous|prior) instructions|ignore les instructions", "demande d'ignorer des consignes"),
            (r"(?i)(curl|wget|iwr|invoke-webrequest)[^\n|]*\|\s*(sh|bash|iex|powershell)", "télécharge puis exécute"),
            (r"(?i)(api[_-]?key|token|password|mot de passe)\s*[:=]", "parle de clés ou mots de passe"),
            (r"[A-Za-z0-9+/]{400,}={0,2}", "long bloc encodé")]


def review(task_files: dict[str, bytes]) -> list[str]:
    """Points to check before installing a skill from elsewhere (nothing is executed)."""
    notes = []
    scripts = [c for c in task_files if c.lower().endswith((".py", ".ps1", ".sh", ".bat", ".cmd", ".js", ".exe", ".dll"))]
    if scripts:
        notes.append(f"Contient {len(scripts)} script(s) que les agents pourront lancer : " + ", ".join(scripts[:5]))
    for c, b in task_files.items():
        if not c.lower().endswith((".md", ".txt", ".py", ".ps1", ".sh", ".js", ".json", ".yaml", ".yml", ".toml")):
            continue
        t = b.decode("utf-8", errors="ignore")
        for pattern, reason in SUSPECTS:
            if re.search(pattern, t):
                notes.append(f"{c} : {reason}")
        urls = set(re.findall(r"https?://[^\s)\"'>]+", t))
        if urls:
            notes.append(f"{c} : {len(urls)} adresse(s) web")
    return notes[:12]


def import_skill(studio, archive: bytes, confirm: bool = False, origin: dict | None = None) -> dict:
    if len(archive) > MAX_IMPORT:
        raise ValueError("Archive trop lourde (30 Mo maximum).")
    try:
        z = zipfile.ZipFile(io.BytesIO(archive))
    except zipfile.BadZipFile:
        raise ValueError("Ce n'est pas un fichier .zip.") from None
    names = [i for i in z.infolist() if not i.is_dir()]
    if sum(i.file_size for i in names) > 100 * 1024 * 1024 or len(names) > 2000:
        raise ValueError("Archive trop grosse une fois décompressée.")
    skill_md = sorted((i.filename for i in names if i.filename.replace("\\", "/").split("/")[-1] == "SKILL.md"), key=len)
    if not skill_md:
        raise ValueError("Pas de SKILL.md dans l'archive : ce n'est pas une skill.")
    base = skill_md[0].replace("\\", "/")[: -len("SKILL.md")]
    task_files = {}
    from .project_page import safe_path
    for i in names:
        n = i.filename.replace("\\", "/")
        if not n.startswith(base) or ".." in n.split("/") or n.startswith("/") or ":" in n:
            continue
        relative = n[len(base):]
        # Vérifier aussi le chemin découpé : un séparateur initial réinitialise Path.
        safe_path(Path(studio.paths.root) / "Skills", relative)
        if (i.external_attr >> 16) & 0o170000 == 0o120000:
            raise ValueError("Lien refusé dans l'archive.")
        if relative.casefold() in {name.casefold() for name in task_files}:
            raise ValueError("Fichier en double dans l'archive.")
        task_files[relative] = z.read(i)
    text = task_files["SKILL.md"].decode("utf-8", errors="replace")
    m = re.search(r"(?mi)^name:\s*[\"']?([A-Za-z0-9 _-]+?)[\"']?\s*$", text)
    ident = re.sub(r"[^a-z0-9-]+", "-", (m.group(1) if m else base.strip("/").split("/")[-1] or "skill").lower()).strip("-")[:60] or "skill"
    notes = review(task_files)
    dest = Path(studio.paths.root) / "Skills" / ident
    safe_path(Path(studio.paths.root), "Skills/" + ident + "/SKILL.md")
    for relative in task_files:
        safe_path(dest, relative)
    if (dest / "SKILL.md").exists():
        raise ValueError(f"Une skill « {ident} » existe déjà : rien n'est remplacé (renomme-la dans son SKILL.md).")
    if not confirm:
        return {"ok": True, "preview": True, "id": ident, "files": len(task_files), "notes": notes,
                "excerpt": text[:1500]}
    for c, b in task_files.items():
        (dest / c).parent.mkdir(parents=True, exist_ok=True)
        (dest / c).write_bytes(b)
    _write_json(dest / ".library.json", {"source": "import", "installed": time.strftime("%Y-%m-%d %H:%M"), "review": notes,
                                              **({"origin": origin} if origin else {})})
    _synchronize(studio)
    return {"ok": True, "id": ident, "message": f"Skill « {ident} » importée ({len(task_files)} fichier(s))."}


# ------------------------------------------------------------------ install a skill from any address
_GH = re.compile(r"^https://github\.com/([A-Za-z0-9_.-]+)/([A-Za-z0-9_.-]+?)(?:\.git)?(?:/(tree|blob)/([^/]+)(?:/(.*))?)?/?$")


def _gh_json(path: str, download) -> dict | list:
    return json.raw_loads(download(f"https://api.github.com/{path}").decode("utf-8"))


def fetch_skill(url: str, download=None) -> tuple[bytes, dict]:
    """Any address → (skill as a .zip, origin facts for the review). GitHub folder, repository, SKILL.md page or raw file,
    or a .zip. GitHub content is pinned to the exact commit read; licence, stars and last update are shown before installing."""
    download = download or _download
    url = (url or "").strip()
    if not url.startswith("https://"):
        raise ValueError("Adresse https attendue (dossier GitHub, fichier SKILL.md ou archive .zip).")
    m = _GH.match(url)
    if m:
        owner, repo, kind, ref, path = m.groups()
        path = (path or "").strip("/")
        if kind == "blob" or path.endswith("SKILL.md"):
            path = path.rsplit("/", 1)[0] if "/" in path else ""
        try:
            info = _gh_json(f"repos/{owner}/{repo}", download)
            ref = ref or info.get("default_branch") or "main"
            sha = _gh_json(f"repos/{owner}/{repo}/commits/{urllib.parse.quote(ref, safe='')}", download)["sha"]
            tree = _gh_json(f"repos/{owner}/{repo}/git/trees/{sha}?recursive=1", download)["tree"]
        except (OSError, ValueError, KeyError) as e:
            raise ValueError(f"Dépôt GitHub illisible ({type(e).__name__}) : vérifie l'adresse et la connexion.") from None
        prefix = f"{path}/" if path else ""
        blobs = [t for t in tree if t.get("type") == "blob" and t["path"].startswith(prefix)]
        if not any(t["path"] == f"{prefix}SKILL.md" for t in blobs):
            found = sorted({t["path"][: -len("/SKILL.md")] for t in tree if t.get("type") == "blob" and t["path"].endswith("/SKILL.md")})
            raise ValueError("Pas de SKILL.md à cette adresse." + (f" Skills de ce dépôt : {', '.join(found[:12])}"
                                                                     f"{' …' if len(found) > 12 else ''} (colle l'adresse du dossier voulu)." if found else ""))
        if len(blobs) > 300 or sum(int(t.get("size") or 0) for t in blobs) > MAX_IMPORT:
            raise ValueError("Skill trop grosse (300 fichiers ou 30 Mo maximum).")
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
            for t in blobs:
                rel = t["path"][len(prefix):]
                z.writestr(f"skill/{rel}", download(f"https://raw.githubusercontent.com/{owner}/{repo}/{sha}/"
                                                      + urllib.parse.quote(t["path"])))
        lic = (info.get("license") or {}).get("spdx_id") or ""
        return buf.getvalue(), {"origin": f"github.com/{owner}/{repo}" + (f"/{path}" if path else ""), "commit": sha[:12],
                                "licence": "" if lic in ("NOASSERTION", "") else lic, "stars": info.get("stargazers_count"),
                                "update": str(info.get("pushed_at") or "")[:10], "archive": bool(info.get("archived")),
                                "editor": owner, "url": url}
    data = download(url)
    if len(data) > MAX_IMPORT:
        raise ValueError("Archive trop lourde (30 Mo maximum).")
    if data[:2] == b"PK":
        return data, {"origin": urllib.parse.urlparse(url).netloc, "url": url}
    text = data.decode("utf-8", errors="replace")
    if not text.lstrip("\ufeff").startswith("---") or "name:" not in text.split("---")[1 if text.count("---") >= 2 else 0]:
        raise ValueError("Ce n'est ni une skill (SKILL.md avec un en-tête name/description), ni une archive .zip.")
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        z.writestr("skill/SKILL.md", data)
    return buf.getvalue(), {"origin": urllib.parse.urlparse(url).netloc, "url": url}


def import_skill_url(studio, url: str, confirm: bool = False, download=None) -> dict:
    archive, origin = fetch_skill(url, download)
    r = import_skill(studio, archive, confirm, origin=origin)
    return {**r, "origin": origin}


def export_skill(studio, ident: str) -> bytes:
    """One of your skills as a .zip, to share it."""
    if not _ID.match(ident or ""):
        raise ValueError("Identifiant invalide.")
    d = Path(studio.paths.root) / "Skills" / ident
    if not (d / "SKILL.md").exists():
        raise ValueError("Skill introuvable.")
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for f in sorted(d.rglob("*")):
            if f.is_file() and f.name != ".library.json":
                z.write(f, f"{ident}/{f.relative_to(d).as_posix()}")
    return buf.getvalue()


def add_custom_mcp(studio, name: str, command: str, arguments: str = "", url: str = "", secrets: dict | None = None) -> dict:
    """MCP server added by hand (command or address) — at your own risk: it has not been reviewed by the studio.
    A secret is never accepted in the free arguments or the address: it goes to ``secrets`` (encrypted on this PC) and
    the arguments say ${NAME}."""
    from .security import ENV_NAME, contains_secret
    ident = re.sub(r"[^a-z0-9-]+", "-", (name or "").lower()).strip("-")[:40]
    if not ident:
        raise ValueError("Donne un nom au serveur.")
    if contains_secret(arguments or "") or contains_secret(url or "") or contains_secret(command or ""):
        raise ValueError("Ce qui ressemble à un secret (clé, jeton, mot de passe) est refusé dans la commande, les arguments "
                         "ou l'adresse : mets-le dans « Variables secrètes » (chiffrées sur ce PC) et écris ${NOM} à sa place.")
    secrets = secrets or {}
    if not isinstance(secrets, dict) or len(secrets) > 20:
        raise ValueError("Variables secrètes invalides.")
    for k, v in secrets.items():
        if not ENV_NAME.fullmatch(str(k)) or not isinstance(v, str) or not v.strip() or "\n" in v or len(v) > 2000:
            raise ValueError(f"Variable secrète « {str(k)[:40]} » invalide (NOM en majuscules, valeur sur une ligne).")
    if url:
        if not re.match(r"^https://|^http://(127\.0\.0\.1|localhost)(:\d+)?/", url):
            raise ValueError("Adresse https (ou http://127.0.0.1 pour un serveur local) attendue.")
        cfg = {"type": "http", "url": url}
    else:
        command = (command or "").strip()
        if not command or any(c in command for c in "|&;<>`\n"):
            raise ValueError("Commande simple attendue (ex. npx).")
        import shlex
        cfg = {"command": command, "args": shlex.split(arguments or "", posix=os.name != "nt")}
    d = _read_json(mcp_file(studio.paths.data), {})
    d = d if isinstance(d, dict) else {}
    if ident in d.get("mcpServers", {}):
        raise ValueError("Un serveur porte déjà ce nom.")
    unused = sorted(set(secrets) - referenced_variables({ident: cfg}))
    if unused:
        raise ValueError("Variables secrètes non utilisées : écris ${" + unused[0] + "} dans les arguments ou l'adresse.")
    if secrets:
        from .ai import _encrypt
        secrets_f = Path(studio.paths.data) / "mcp-secrets.json"
        stored = _read_json(secrets_f, {})
        taken = sorted(k for k in secrets if k in stored)
        if taken:
            raise ValueError(f"La variable {taken[0]} existe déjà (autre serveur) : choisis un autre nom.")
        stored.update({k: _encrypt(v.strip()) for k, v in secrets.items()})
        _write_json(secrets_f, stored)
    d.setdefault("mcpServers", {})[ident] = cfg
    _write_json(mcp_file(studio.paths.data), d)
    return {"ok": True, "message": f"Serveur « {ident} » ajouté pour les agents."
                                   + (f" {len(secrets)} variable(s) secrète(s) chiffrée(s) sur ce PC." if secrets else "")}
