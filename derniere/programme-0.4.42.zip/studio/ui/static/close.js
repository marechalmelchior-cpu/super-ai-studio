"use strict";
(() => {
  let status = {}, pending = false;
  const style = document.createElement("style");
  style.textContent = "#close-dialog{max-width:min(600px,92vw);color:var(--ink);background:var(--card);border:1px solid var(--line);border-radius:16px;padding:26px}#close-dialog::backdrop{background:#0009}#close-dialog h2{margin-top:0}#close-dialog .actions{display:grid;gap:12px}#close-dialog .btn{text-align:left}";
  document.head.appendChild(style);
  const dialog = document.createElement("dialog");
  dialog.id = "close-dialog";
  dialog.setAttribute("aria-labelledby", "close-title");
  dialog.innerHTML = `<h2 id="close-title">Des tâches sont en cours</h2>
    <p>Choisis ce que le studio doit faire avant de fermer cette fenêtre.</p>
    <div class="actions"><button type="button" class="btn main" data-close="background" autofocus>Laisser tourner en arrière-plan</button>
    <button type="button" class="btn" data-close="pause">Mettre en pause et fermer</button>
    <button type="button" class="btn subtle" data-close="cancel">Annuler</button></div><p role="alert" id="close-error" hidden></p>`;
  document.body.appendChild(dialog);

  async function send(action, explicit) {
    const response = await fetch("/api/desktop/close", { method: "POST", headers: { "X-Studio": "1", "Content-Type": "application/json" }, body: JSON.stringify({ action, explicit }) });
    const result = await response.json();
    if (!response.ok && !result.needs_choice) throw Error(result.error || "Fermeture impossible.");
    return result;
  }

  function choose() {
    return new Promise((resolve) => {
      dialog.oncancel = (event) => { event.preventDefault(); resolve("cancel"); };
      dialog.querySelectorAll("[data-close]").forEach((button) => { button.onclick = () => resolve(button.dataset.close); });
      dialog.showModal();
      dialog.querySelector('[data-close="background"]').focus();
    });
  }

  window.requestStudioClose = async (explicit = false) => {
    if (pending || status.distant || window.studioWindowClosing) return;
    pending = true;
    const opener = document.activeElement;
    try {
      let result = await send("", explicit);
      if (result.needs_choice) {
        dialog.querySelector("p").textContent = result.scheduled
          ? "Des tâches sont programmées pour cette nuit. En arrière-plan, le studio attend leur exécution puis s’arrête. La pause conserve leur programmation pour le prochain lancement."
          : "Choisis ce que le studio doit faire avant de fermer cette fenêtre.";
        const action = await choose();
        if (action === "pause") {
          dialog.querySelector("p").textContent = "Mise en pause… Arrêt des appels et enregistrement de l’état avant fermeture.";
          dialog.querySelectorAll("button").forEach(button => button.disabled = true);
        }
        result = await send(action, explicit);
        if (!result.pausing) dialog.close();
        dialog.querySelectorAll("button").forEach(button => button.disabled = false);
        if (action === "cancel") { opener?.focus(); return; }
      }
      while (result.pausing) {
        if (!dialog.open) dialog.showModal();
        dialog.querySelector("p").textContent = "Mise en pause… La fenêtre reste ouverte jusqu’à l’arrêt du travail.";
        dialog.querySelectorAll("button").forEach(button => button.disabled = true);
        await new Promise(resolve => setTimeout(resolve, 250));
        result = await send("", explicit);
      }
      dialog.close();
      window.studioWindowClosing = true;
      window.close();
      // Certains navigateurs refusent close() sur une page ouverte par leur ligne de commande.
      if (!status.desktop) {
        const panel = document.createElement("div");
        panel.className = "card";
        panel.id = "window-closed";
        panel.style.cssText = "position:fixed;inset:0;z-index:10000;margin:0;display:grid;place-content:center;text-align:center";
        const title = document.createElement("h1");
        title.textContent = result.background ? "Le studio continue en arrière-plan" : "Le studio se ferme";
        const text = document.createElement("p");
        text.textContent = "Tu peux fermer cette fenêtre. Le raccourci permet de la rouvrir.";
        panel.append(title, text);
        document.body.appendChild(panel);
      }
    } catch (error) {
      const message = dialog.querySelector("#close-error");
      message.textContent = error.message;
      message.hidden = false;
      dialog.querySelectorAll("button").forEach(button => button.disabled = false);
      if (!dialog.open) alert(error.message);
    } finally {
      pending = false;
    }
  };

  window.studioClosePresence = (value) => {
    status = { ...status, ...value };
    const button = document.querySelector("#close-window");
    if (button) button.hidden = !!status.desktop || !!status.distant;
    if (status.close_pending) window.requestStudioClose(false);
  };
  document.querySelector("#close-window").onclick = () => window.requestStudioClose(false);
  fetch("/api/session").then((r) => r.json()).then(window.studioClosePresence).catch(() => {});
  addEventListener("beforeunload", (event) => {
    if (status.desktop || status.distant || window.studioWindowClosing || location.hash.startsWith("#studio-hosted=")) return;
    if (!window.studioBrowserControlled && !status.jobs && !status.scheduled) return;
    // Si le navigateur permet d'annuler la croix, la page propose ensuite les trois choix.
    setTimeout(() => window.requestStudioClose(false), 0);
    event.preventDefault();
    event.returnValue = "";
  });
})();
