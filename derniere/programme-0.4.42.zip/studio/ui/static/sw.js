/* Page de dépannage hors ligne : aucun lancement de VPN, aucun rechargement automatique. */
const WAITING = `<!doctype html><html lang="fr"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="theme-color" content="#030810"><title>Studio injoignable</title>
<body style="margin:0;min-height:100vh;display:grid;place-content:center;background:#030810;color:#e8eaed;font:16px system-ui;padding:24px;box-sizing:border-box">
<main style="max-width:560px"><h1>Le studio ne répond pas</h1>
<p id="network-note">Ce téléphone ne peut pas déterminer à distance quel service est coupé. Vérifie dans cet ordre :</p>
<ol style="line-height:1.6;padding-left:24px">
<li><b>Tailscale sur le téléphone :</b> ouvre Tailscale et connecte-toi. Conseil : VPN permanent sur Android, « VPN à la demande » sur iPhone.</li>
<li><b>Studio sur le PC :</b> ouvre-le avec son raccourci.</li>
<li><b>Accès téléphone :</b> sur le PC, Accueil › Réglages › Téléphone › Accès téléphone. À réactiver après le lancement, sauf si « Accès téléphone toujours ouvert » est activé.</li>
<li><b>PC :</b> réveille-le et vérifie sa connexion au réseau.</li></ol>
<p>L’application ne peut pas ouvrir Tailscale à ta place.</p>
<p>Si le studio répond mais refuse ce téléphone : sur le PC, ouvre le studio → Accueil › Réglages › Téléphone → « Accès téléphone » → « Associer un téléphone ». Tape le code à 6 chiffres, valable 10 minutes.</p>
<p><a href="/pair" style="color:#8ab4f8">Ouvrir la page du code</a></p>
<button type="button" onclick="location.reload()" style="padding:12px 24px;border-radius:8px">Réessayer</button>
<script>if(navigator.onLine===false)document.getElementById('network-note').textContent='Le téléphone se déclare hors ligne. Reconnecte-le au réseau, puis vérifie Tailscale.';</script>
</main></body></html>`;
self.addEventListener("install", () => self.skipWaiting());
self.addEventListener("activate", (e) => e.waitUntil(self.clients.claim()));
self.addEventListener("fetch", (e) => {
  if (e.request.mode !== "navigate") return;
  if (e.request.method !== "GET") {
    // Le formulaire d'association conserve sa méthode, son code et ses cookies.
    e.respondWith((async () => {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 3000);
      try { return await fetch(e.request, {signal:controller.signal}); }
      catch { return waiting(); }
      finally { clearTimeout(timer); }
    })());
    return;
  }
  // La page s'affiche immédiatement ; sa requête est bornée à trois secondes.
  const connecting = WAITING.replace('<main style=', '<p id="connecting">Connexion au studio…</p><main id="help" hidden style=')
    .replace('</main></body>', `</main><script>
      (async () => {
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), 3000);
        try {
          const response = await fetch(location.href, {credentials:'include', cache:'no-store', signal:controller.signal});
          if (response.ok && (response.headers.get('content-type') || '').includes('text/html')) {
            const text = await response.text();
            clearTimeout(timer); document.open(); document.write(text); document.close(); return;
          }
          if (response.status === 403) document.querySelector('h1').textContent = 'Ce téléphone doit être associé';
        } catch {}
        clearTimeout(timer);
        document.getElementById('connecting').remove(); document.getElementById('help').hidden = false;
      })();
    <\/script></body>`);
  e.respondWith(new Response(connecting, {status:200, headers:{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store'}}));
});
function waiting() {
  return new Response(WAITING, { status: 503, headers: { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store" } });
}

/* Notifications (Web Push without content): the studio wakes the phone; we come here to read what is waiting.
   « Valider » only appears for a task reviewed without defects; it validates exactly the result shown (hash). */
self.addEventListener("push", (e) => {
  e.waitUntil((async () => {
    let entries = [];
    try { const r = await fetch("/api/push/pending", { credentials: "include", cache: "no-store" }); if (r.ok) entries = await r.json(); } catch {}
    if (!entries.length) return self.registration.showNotification("Studio", { body: "Une tâche t'attend.", tag: "studio", icon: "/icon-192.png" });
    for (const t of entries.slice(0, 4)) {
      await self.registration.showNotification(`${t.state[0].toUpperCase()}${t.state.slice(1)} : ${t.title}`, {
        body: (t.target || "").replace(/^(project|topic):/, ""), tag: t.tid, renotify: false, icon: "/icon-192.png", badge: "/icon-192.png",
        data: { tid: t.tid, fingerprint: t.fingerprint || "" },
        actions: t.fingerprint ? [{ action: "validate", title: "Valider" }, { action: "open", title: "Ouvrir" }] : [{ action: "open", title: "Ouvrir" }],
      });
    }
  })());
});
self.addEventListener("notificationclick", (e) => {
  const { tid, fingerprint: fingerprint } = e.notification.data || {};
  e.notification.close();
  e.waitUntil((async () => {
    if (e.action === "validate" && tid && fingerprint) {
      try {
        const r = await fetch(`/api/tasks/${encodeURIComponent(tid)}/decision`, { method: "POST", credentials: "include",
          headers: { "Content-Type": "application/json", "X-Studio": "1" }, body: JSON.stringify({ decision: "approve", fingerprint: fingerprint }) });
        return self.registration.showNotification(r.ok ? "Validée" : "Pas validée : ouvre la tâche", { tag: tid, icon: "/icon-192.png", data: { tid } });
      } catch { return self.registration.showNotification("Studio injoignable : rien n'est validé", { tag: tid, data: { tid } }); }
    }
    const windows = await self.clients.matchAll({ type: "window", includeUncontrolled: true });
    if (windows.length) { windows[0].postMessage({ openTask: tid }); return windows[0].focus(); }
    return self.clients.openWindow(tid ? `/?task=${encodeURIComponent(tid)}` : "/");
  })());
});
