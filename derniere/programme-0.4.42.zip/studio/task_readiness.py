"""Prévol commun des tâches : toutes les étapes et leurs relectures, sans lancement implicite."""
from __future__ import annotations

import re
from urllib.parse import urlparse


def inspect(studio, target, request, options=None, stages=None):
    from . import ai, ai_runtime, local_discovery
    from .orchestrator.roles import select_producer
    from .teams import project_roles
    options = options or {}
    try:
        item = studio.registry.get(target)
        exists = True
        kind = item.type if item.kind == 'project' else 'topic'
        target = f'{item.kind}:{item.id}'
    except (KeyError, ValueError):
        exists = False
        kind = 'topic'
    connections = {}
    for stage in stages or [{'request': request, 'role': options.get('role', '')}]:
        candidates = studio.roles if stage.get('role') else project_roles(studio.roles, studio.paths.data, target)
        producer = select_producer(candidates, kind, stage.get('request') or request, stage.get('role', ''))
        tool, executor, ident = studio.resolve_execution(producer, options, target)
        if options.get('mode') != 'fast' and studio.cfg.get('audit', {}).get('model_reviewer') and studio.auditors:
            auditor, review_id = studio._choose_reviewer({'target_ref': target if exists else '', 'request': request,
                'execution': {'executor': tool, 'connection': ident}})
            if auditor and getattr(auditor, 'name', '') == 'api' and review_id:
                connection = ai.connection(studio.paths.data, review_id)
                if connection and ai_runtime.is_local(connection):
                    connections[review_id] = connection
        connection = ai.connection(studio.paths.data, ident) if tool == 'api' and ident else None
        if connection and ai_runtime.is_local(connection):
            connections[ident] = connection
    required = []
    for ident, connection in connections.items():
        address = connection.get('url') or ai.PROVIDERS.get(connection.get('provider'), {}).get('url', '')
        port = urlparse(address).port
        engine = connection.get('provider') if connection.get('provider') in ('ollama', 'lmstudio') else ''
        if not engine:
            matches = [row[0] for row in local_discovery.ENGINES if row[2] == port and row[0] in local_discovery.installed()]
            engine = matches[0] if len(matches) == 1 else ''
        required.append({'id': ident, 'name': connection.get('name') or ident, 'engine': engine,
                         'offline': bool(ai.local_warning(studio.paths.data, ident))})
    return required


def defaults(studio, target, request, options=None):
    from .orchestrator.roles import select_producer
    from .teams import project_roles
    opts = options or {}
    item = studio.registry.get(target)
    key = f'{item.kind}:{item.id}'
    candidates = studio.roles if opts.get('role') else project_roles(studio.roles, studio.paths.data, key)
    role = select_producer(candidates, item.type if item.kind == 'project' else 'topic', request, opts.get('role', ''))
    tool, executor, connection = studio.resolve_execution(role, opts, key)
    return {'ai': connection if tool == 'api' else tool, 'role': role.id,
            'model': studio.execution_model(role, opts, key, tool=tool, connection=connection),
            'effort': studio._level(role, opts, key)}


def request_plan(studio, path, body):
    """Lecture seulement : le refus précède création, checkpoint et changement d'état."""
    match = re.fullmatch(r'/api/conversation/(\d+)/(launch|night)', path)
    if match:
        msg = next((m for m in studio.store.messages(500) if m['id'] == int(match[1])), None)
        if not msg or not msg.get('proposal'):
            return None
        proposal = msg['proposal']
        opts = {'ai': body.get('ai') or proposal.get('ai', ''), 'role': proposal.get('role', ''),
                'mode': body.get('mode', '') if body.get('mode') in ('fast', 'max') else ''}
        return inspect(studio, body.get('target') or proposal.get('target', ''),
                       body.get('request') or proposal.get('request', ''), opts, proposal.get('stages'))
    match = re.fullmatch(r'/api/tasks/([^/]+)/(resume|decision)', path)
    if match and (match[2] == 'resume' or body.get('decision') == 'correct'):
        task = studio.store.get(match[1])
        opts = task['options']
        stages = None
        if opts.get('chain'):
            chain = studio.store.chain(opts['chain'])
            stages = chain['stages'][chain['current']:]
        return inspect(studio, task['target'], task['request'], opts, stages)
    match = re.fullmatch(r'/api/chains/([^/]+)/(resume|continue)', path)
    if match:
        chain = studio.store.chain(match[1])
        start = chain['current'] + (match[2] == 'continue')
        return inspect(studio, chain['target'], '', chain['options'], chain['stages'][start:]) if start < len(chain['stages']) else []
    if path in ('/api/chains', '/api/tasks'):
        return inspect(studio, body.get('target', ''), body.get('request', ''), body, body.get('stages'))
    return None
