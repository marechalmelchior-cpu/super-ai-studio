"""Actions launched with one click from the interface: merge, build, tests, installing reader modules,
cleaning up workspaces. Nothing runs without the user's click; each action checks its conditions before
writing and stops cleanly otherwise. Long jobs run in the background (only one of each kind at a time).
"""
from __future__ import annotations

from .migrations import compatibility as json
import re
import os
import subprocess
import sys
import threading
import time
from datetime import datetime, timezone
from .migrations.compatibility import TechnicalPath as Path

from .connectors import workspace as ws
from .connectors.base import NO_WINDOW, sha256_file
from .orchestrator.store import TERMINAL
from .security import redact


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


class Jobs:
    """Background jobs shown in the interface (state, duration, tail of the output)."""

    def __init__(self, controller=None):
        self._t: dict[str, dict] = {}
        self._guard_lock = threading.Lock()
        self.controller = controller

    def state(self) -> dict:
        with self._guard_lock:
            return {k: dict(v) for k, v in self._t.items()}

    def launch(self, name: str, title: str, cmd: list[str], cwd: Path, timeout_s: float = 3600,
               after=None) -> dict:
        with self._guard_lock:
            if self._t.get(name, {}).get("state") == "running":
                raise RuntimeError(f"« {title} » tourne déjà.")
            self._t[name] = {"title": title, "state": "running", "begin": _now(), "end": "", "code": None,
                            "output": "", "command": redact(" ".join(str(c) for c in cmd))[:300]}
        if self.controller:
            self.controller.begin()

        def run():
            output, code = "", None
            try:
                r = subprocess.run([str(c) for c in cmd], cwd=str(cwd), capture_output=True, text=True, encoding="utf-8",
                                   errors="replace", stdin=subprocess.DEVNULL, timeout=timeout_s, **NO_WINDOW)
                output, code = (r.stdout or "") + (r.stderr or ""), r.returncode
            except subprocess.TimeoutExpired:
                output, code = "Délai dépassé : arrêté.", -1
            except OSError as e:
                output, code = f"Impossible de lancer : {e}", -1
            finally:
                with self._guard_lock:
                    self._t[name].update(state="ok" if code == 0 else "failed", end=_now(), code=code,
                                        output=redact(output)[-20000:])
                if after:
                    try:
                        after(code, output)
                    except Exception:            # noqa: BLE001 — a callback never breaks the job
                        pass
                if self.controller:
                    self.controller.finish()
        threading.Thread(target=run, daemon=True).start()
        return self.state()[name]


# ------------------------------------------------------------------ merge
def _task_worktree(studio, tid: str):
    t = studio.store.get(tid)
    target = studio.registry.get(t["target"])
    base = studio.details_dir(tid) / "base.json"
    info = json.loads(base.read_text(encoding="utf-8")) if base.exists() else {}
    if "_worktree" not in info:
        raise ValueError("Cette tâche n'a pas été faite dans un worktree : rien à fusionner.")
    return t, target, info


OPERATIONS = ("MERGE_HEAD", "CHERRY_PICK_HEAD", "REVERT_HEAD", "rebase-merge", "rebase-apply", "sequencer", "BISECT_LOG")


def _operation_in_progress(git: str, repository: Path) -> str:
    """Merge, rebase, cherry-pick… already started by the user in the repository (never touched by the studio)."""
    for name in OPERATIONS:
        p = Path(ws._git(git, repository, "rev-parse", "--path-format=absolute", "--git-path", name).strip())
        if p.exists():
            return name
    return ""


REPORTS = re.compile(r"(^|/)RESULTAT[^/]*\.md$", re.I)


REPORT_CHOICES = {"task": "la version de la tâche", "project": "la version du projet"}


class ReportConflict(ValueError):
    """Merge stopped on report files only (RESULTAT*.md): nothing is removed because of a name; the user picks a version."""
    def __init__(self, files: list[str]):
        super().__init__("Conflit sur " + ", ".join(files[:5]) + " : fusion annulée, ton dépôt est comme avant. "
                         "Choisis la version à garder (tâche ou projet), puis relance la fusion.")
        self.files = files


def report_conflicts(git: str, repository: Path) -> list[str]:
    """Conflicted files if ALL of them are reports (RESULTAT*.md); otherwise [] (a real conflict)."""
    conflicts = [l for l in ws._git(git, repository, "diff", "--name-only", "--diff-filter=U").splitlines() if l.strip()]
    return conflicts if conflicts and all(REPORTS.search(c) for c in conflicts) else []


def _configure_reports(git: str, repository: Path, choice: str = "") -> bool:
    """Merge stopped on reports only: keeps, for each file, the version the user chose — « task » (the task branch,
    its deletion included) or « project » (the current branch). Without a choice nothing is touched (False)."""
    conflicts = report_conflicts(git, repository)
    if not conflicts or choice not in REPORT_CHOICES:
        return False
    stage = "3" if choice == "task" else "2"            # merge stages: 2 = current branch (project), 3 = merged branch (task)
    for f in conflicts:
        present = {line.split()[2] for line in ws._git(git, repository, "ls-files", "-u", "--", f).splitlines() if line.strip()}
        if stage in present:
            ws._git(git, repository, "checkout", "--theirs" if choice == "task" else "--ours", "--", f)
            ws._git(git, repository, "add", "--", f)
        else:                                            # the chosen side deleted it: the deletion is kept, by choice
            ws._git(git, repository, "rm", "-q", "--", f)
    return not ws._git(git, repository, "diff", "--name-only", "--diff-filter=U").strip()


def _complete_chain_messages(studio, tid: str) -> None:
    """Ferme toutes les annonces de fusion de cette tâche, quel que soit le bouton utilisé."""
    for message in studio.store.chain_merge_messages(tid):
        studio.store.update_message(message["id"], proposal={**message["proposal"], "state": "chain_done"})



def _worktree_changes(git: str, workspace: Path) -> bool:
    """Compare le contenu au commit ; une conversion CRLF/LF seule ne compte pas."""
    if not ws._succeeds(git, workspace, "diff", "--quiet", "--ignore-cr-at-eol", "HEAD", "--"):
        return True
    untracked = ws._git(git, workspace, "ls-files", "--others", "-z")
    return any(name and not ws._skipped(name, []) and not name.startswith(".agents/skills/")
               for name in untracked.split("\0"))


def cleanup_merged_worktree(studio, tid: str) -> str:
    """Retire seulement la copie de cette tâche fusionnée ; conserve sa branche et son résultat."""
    git = studio.cfg["tools"].get("git", "git")
    task = studio.store.get(tid)
    target = studio.registry.get(task["target"])
    root = studio.run_dir(tid, create_new=False).resolve()
    workspace = root / ws.WORKSPACE
    if not (workspace / ".git").is_file():
        return ""
    branch = f"studio/{tid}"
    try:
        if not workspace.resolve().is_relative_to(studio.paths.runs.resolve()):
            raise ValueError("Copie hors du dossier des tâches : retrait refusé.")
        # Le dépôt lui-même et une copie appartenant à une autre branche sont exclus.
        actual = ws._git(git, workspace, "symbolic-ref", "--short", "HEAD").strip()
        if actual != branch or not ws._succeeds(git, target.path(), "merge-base", "--is-ancestor", branch, "HEAD"):
            raise ValueError("La copie ne correspond pas à la branche fusionnée.")
        if _worktree_changes(git, workspace):
            raise ValueError("Des modifications réelles restent dans la copie.")
        ws._git(git, target.path(), "worktree", "remove", "--force", str(workspace), timeout=600)
        (root / ws.READY_MARKER).unlink(missing_ok=True)
        studio.store.event(tid, "Copie de travail propre retirée après fusion ; branche conservée.")
        return ""
    except (ValueError, ws.WorktreeError):
        message = ("Fusion conservée ; copie de travail encore présente. Ouvre la copie depuis la tâche, "
                   "sauvegarde ses changements hors de la copie ou commite-les, puis réessaie le retrait depuis Gestion › Branches.")
        studio.store.event(tid, message)
        return message


def _mark_merged(studio, tid: str, selected: str, sha: str, how: str) -> None:
    d = studio.details_dir(tid)
    if not (d / "merge.json").exists():
        (d / "merge.json").write_text(json.dumps({"branch": selected, "commit": sha, "at": _now(), "comment": how}),
                                       encoding="utf-8")
        studio.store.event(tid, f"Fusionnée dans {selected} ({sha}) : {how}")
    _complete_chain_messages(studio, tid)
    cleanup_merged_worktree(studio, tid)


def _stacked_merged(studio, tid: str, git: str, repository, selected: str, sha: str) -> None:
    """Chain step started from an earlier step's branch (branch on branch): merging it also brought those steps."""
    seen = {tid}
    cur = tid
    while True:
        options = studio.store.get(cur).get("options") or {}
        prev = str(options.get("start_task") or options.get("start_task") or "")
        if not prev or prev in seen:
            return
        seen.add(prev)
        try:
            commit = json.loads((studio.details_dir(prev) / "branch.json").read_text(encoding="utf-8")).get("commit", "")
            if commit and ws._succeeds(git, repository, "merge-base", "--is-ancestor", commit, "HEAD"):
                _mark_merged(studio, prev, selected, sha, f"apportée par la fusion de {tid}")
        except (OSError, ValueError, KeyError):
            return
        cur = prev


def merge(studio, tid: str, report_choice: str = "") -> dict:
    """Merges the studio/<task> branch into the starting branch, with --no-ff and a prefilled message.
    Refuses if: the task is not approved; the branch no longer matches the approved commit; the repository is not on
    the starting branch (detached HEAD included); a merge, rebase… is already in progress; tracked files are
    modified (your work in progress is never mixed in). On conflict, only OUR merge is aborted. A conflict on reports
    only (RESULTAT*.md) stays visible: ReportConflict, then ``report_choice`` (« task » or « project ») on the next try."""
    from .orchestrator.runner import commit_title
    git = studio.cfg["tools"].get("git", "git")
    t, target, info = _task_worktree(studio, tid)
    if t["status"] not in ("approved", "applied"):
        raise ValueError("Valide d'abord la tâche : seule une tâche validée peut être fusionnée.")
    repository, branch = target.path(), f"studio/{tid}"
    bj = studio.details_dir(tid) / "branch.json"
    valid = json.loads(bj.read_text(encoding="utf-8")) if bj.exists() else {}
    if not ws._git(git, repository, "branch", "--list", branch).strip():
        raise ValueError(f"Branche {branch} introuvable.")
    tip = ws._git(git, repository, "rev-parse", branch).strip()
    if not valid.get("commit") or tip != valid["commit"]:
        raise ValueError(f"La branche {branch} ne correspond pas au commit validé : rien n'est fusionné.")
    base = valid.get("base") or info.get("_worktree", "")
    if base and ws._git(git, repository, "rev-list", "--count", f"{base}..{branch}").strip() == "0":
        return {"state": "empty", "message": "Aucun changement validé sur cette branche : rien à fusionner."}
    expected = info.get("branch", "")
    if not expected or expected == "HEAD":
        raise ValueError("La tâche est partie d'un HEAD détaché : fusionne-la toi-même (voir BRANCHE.md).")
    if not ws._succeeds(git, repository, "symbolic-ref", "-q", "HEAD"):
        raise ValueError("Le dépôt est en HEAD détaché : repasse sur ta branche puis réessaie.")
    selected = ws._git(git, repository, "rev-parse", "--abbrev-ref", "HEAD").strip()
    if selected != expected:
        raise ValueError(f"Le dépôt est sur « {selected} », la tâche est partie de « {expected} » : rien n'est fait.")
    op = _operation_in_progress(git, repository)
    if op:
        raise ValueError(f"Une opération git est déjà en cours dans le dépôt ({op}) : termine-la, puis réessaie.")
    if ws._succeeds(git, repository, "merge-base", "--is-ancestor", branch, "HEAD"):
        sha = ws._git(git, repository, "rev-parse", "--short", "HEAD").strip()
        _mark_merged(studio, tid, selected, sha, "déjà dans la branche")
        _stacked_merged(studio, tid, git, repository, selected, sha)
        warning = cleanup_merged_worktree(studio, tid)
        return {"warning": warning, "state": "already", "message": f"{branch} est déjà fusionnée dans {selected}."}
    dirty = ws._git(git, repository, "status", "--porcelain", "--untracked-files=no").strip()
    if dirty:
        raise ValueError("Le dépôt a des modifications non commitées ; commite-les ou mets-les de côté, puis réessaie : "
                         + ", ".join(l[3:] for l in dirty.splitlines()[:5]))
    message = f"Fusion studio {tid} : {commit_title(t.get('request') or '', 60)}"
    try:
        ws._git(git, repository, "merge", "--no-ff", "--no-verify", branch, "-m", message, timeout=900)
    except ws.WorktreeError as e:
        mh = Path(ws._git(git, repository, "rev-parse", "--path-format=absolute", "--git-path", "MERGE_HEAD").strip())
        our = mh.exists() and mh.read_text(encoding="utf-8").split()[:1] == [tip]
        rule = False
        reports = report_conflicts(git, repository) if our else []
        if reports and _configure_reports(git, repository, report_choice):     # reports only, version chosen by the user
            try:
                ws._git(git, repository, "commit", "--no-verify", "--no-edit", timeout=300)
                rule = not mh.exists()
            except ws.WorktreeError:
                rule = False
        if not rule:
            if our:
                try:
                    ws._git(git, repository, "merge", "--abort")      # our merge only
                except ws.WorktreeError:
                    pass
                if reports:
                    studio.store.event(tid, "Conflit sur " + ", ".join(reports[:5]) + " : fusion annulée, choix de la version demandé")
                    raise ReportConflict(reports) from None
                raise ValueError(f"Fusion impossible (conflit) : annulée, ton dépôt est comme avant. {e}") from None
            raise ValueError(f"Fusion refusée par git, rien n'a été fusionné : {e}") from None
        studio.store.event(tid, f"Conflit sur {', '.join(reports[:5])} : {REPORT_CHOICES[report_choice]} gardée (ton choix), "
                                "fusion terminée")
    sha = ws._git(git, repository, "rev-parse", "--short", "HEAD").strip()
    studio.store.event(tid, f"Fusionnée dans {selected} ({sha})")
    (studio.details_dir(tid) / "merge.json").write_text(json.dumps({"branch": selected, "commit": sha, "at": _now()}),
                                                      encoding="utf-8")
    _complete_chain_messages(studio, tid)
    _stacked_merged(studio, tid, git, repository, selected, sha)
    warning = cleanup_merged_worktree(studio, tid)
    return {"warning": warning, "state": "ok", "message": f"Fusionnée dans {selected} : commit {sha}. Rien n'est poussé vers GitHub.", "commit": sha}


# ------------------------------------------------------------------ undo a task already applied or merged
def cancellable(studio, tid: str) -> dict:
    """What « Annuler ce qui a été appliqué » would do for this task (nothing is done here)."""
    t = studio.store.get(tid)
    d = studio.details_dir(tid, create_new=False)
    if (d / "cancellation.json").exists():
        return {"possible": False, "mode": "", "text": "Déjà annulée."}
    if (d / "merge.json").exists():
        return {"possible": True, "mode": "merge",
                "text": "Un commit inverse (git revert) annule la fusion. L'historique est gardé, rien n'est poussé vers GitHub."}
    if t["status"] == "applied" and (d / "application.json").exists():
        return {"possible": True, "mode": "application",
                "text": "Les fichiers du projet reviennent comme avant la tâche. Ce que la tâche avait ajouté ou changé est "
                         "mis de côté dans le dossier de la tâche (rien n'est effacé)."}
    return {"possible": False, "mode": "", "text": ""}


def cancel_apply(studio, tid: str) -> dict:
    """Undoes an applied (copy) or merged (worktree) task. Checks everything before writing; refuses if the project
    has changed since on those files (your work is never overwritten)."""
    import shutil
    a = cancellable(studio, tid)
    if not a["possible"]:
        raise ValueError(a["text"] or "Rien à annuler pour cette tâche : elle n'a rien appliqué à ton projet.")
    d = studio.details_dir(tid)
    t = studio.store.get(tid)
    if a["mode"] == "merge":
        git = studio.cfg["tools"].get("git", "git")
        target = studio.registry.get(t["target"])
        repository = target.path()
        fj = json.loads((d / "merge.json").read_text(encoding="utf-8"))
        op = _operation_in_progress(git, repository)
        if op:
            raise ValueError(f"Une opération git est déjà en cours dans le dépôt ({op}) : termine-la, puis réessaie.")
        selected = ws._git(git, repository, "rev-parse", "--abbrev-ref", "HEAD").strip()
        if fj.get("branch") and selected != fj["branch"]:
            raise ValueError(f"Le dépôt est sur « {selected} », la fusion a été faite sur « {fj['branch']} » : rien n'est fait.")
        if ws._git(git, repository, "status", "--porcelain", "--untracked-files=no").strip():
            raise ValueError("Le dépôt a des modifications non commitées : commite-les ou mets-les de côté, puis réessaie.")
        sha = ws._git(git, repository, "rev-parse", fj["commit"]).strip()
        parents = ws._git(git, repository, "rev-list", "--parents", "-n", "1", sha).split()
        try:
            if len(parents) > 2:
                ws._git(git, repository, "revert", "--no-edit", "-m", "1", sha, timeout=600)
            else:
                ws._git(git, repository, "revert", "--no-edit", sha, timeout=600)
        except ws.WorktreeError as e:
            try:
                ws._git(git, repository, "revert", "--abort")
            except ws.WorktreeError:
                pass
            raise ValueError(f"Annulation impossible (conflit avec des changements faits depuis) : rien n'est modifié. {e}") from None
        new_name = ws._git(git, repository, "rev-parse", "--short", "HEAD").strip()
        info = {"mode": "merge", "commit_inverse": new_name, "merge": fj["commit"], "at": _now()}
        message = f"Fusion annulée par un commit inverse ({new_name}) sur {selected}. Rien n'est poussé vers GitHub."
    else:
        m = json.loads((d / "application.json").read_text(encoding="utf-8"))
        root_dir, before = Path(m["target"]), Path(m.get("backup") or d / "before-application")
        change = [rel for rel, h in m["files"].items()
                  if not (root_dir / rel).is_file() or sha256_file(root_dir / rel) != h]
        if change:
            raise ValueError("Ces fichiers ont changé dans ton projet depuis la tâche : rien n'est modifié. "
                             + ", ".join(change[:8]) + (f" (+{len(change) - 8})" if len(change) > 8 else ""))
        guard = d / "cancellation"
        for rel in m["files"]:                        # the task's version is kept, never deleted
            (guard / rel).parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(root_dir / rel, guard / rel)
        restored, removed = [], []
        for rel in m["files"]:
            target_f = root_dir / rel
            if (before / rel).is_file():
                tmp = target_f.with_name(f".studio-tmp-{target_f.name}")
                shutil.copy2(before / rel, tmp)
                os.replace(tmp, target_f)
                restored.append(rel)
            else:
                target_f.unlink()                             # its copy is already in annulation/
                removed.append(rel)
        info = {"mode": "application", "remis": restored, "removed": removed, "gardes": str(guard), "at": _now()}
        message = (f"{len(restored)} fichier(s) remis comme avant" + (f", {len(removed)} ajouté(s) par la tâche mis de côté" if removed else "")
                   + f". Version de la tâche gardée dans {guard}.")
    (d / "cancellation.json").write_text(json.dumps(info, ensure_ascii=False, indent=1), encoding="utf-8")
    studio.store.event(tid, "Annulée après coup : " + message)
    studio.store.set_status(tid, "cancelled", "Annulée après application — " + message)
    return {"ok": True, "message": message}


# ------------------------------------------------------------------ build
def editor_open() -> bool:
    if sys.platform != "win32":
        return False
    try:
        r = subprocess.run(["tasklist", "/FI", "IMAGENAME eq UnrealEditor.exe", "/NH"], capture_output=True, text=True, errors="replace",
                           timeout=15, **NO_WINDOW)
        return "UnrealEditor.exe" in (r.stdout or "")
    except (OSError, subprocess.TimeoutExpired):
        return False


def run_compile(studio, jobs: Jobs, key: str) -> dict:
    from .orchestrator.runner import Studio
    target = studio.registry.get(key)
    cmd = Studio._build_command(target, target.path()) if target.has_path else None
    if not cmd:
        raise ValueError("Pas de commande de compilation pour ce projet (« build » dans project.toml).")
    from . import project_page
    project_page.assert_commands_approved(studio, target)
    from . import unreal
    up = unreal.unreal_project(target.path()) or next(iter(sorted(target.path().glob("*.uproject"))), None)
    if up and target.extra.get("type") == "unreal":
        # Unreal: the studio tool closes the editor cleanly (never forcibly), builds, then reopens it
        cmd = [python_console(), str(studio.paths.code / "scripts" / "tools" / "unreal_compile.py"),
               "--uproject", str(up), "--rouvrir", str(up)]
    elif editor_open():
        raise ValueError("Unreal Editor est ouvert : ferme-le (en enregistrant) puis relance la compilation.")
    return jobs.launch(f"compile:{target.kind}:{target.id}", f"Compilation de {target.name}", cmd, target.path(), 3600)


# ------------------------------------------------------------------ tests and installation
def python_console() -> str:
    """The studio runs under pythonw.exe (no console): pip and pytest go through the python.exe next to it."""
    exe = Path(sys.executable)
    if exe.name.lower() == "pythonw.exe" and (exe.parent / "python.exe").exists():
        return str(exe.parent / "python.exe")
    return sys.executable


def run_tests(studio, jobs: Jobs) -> dict:
    return jobs.launch("tests", "Tests du studio", [python_console(), "-X", "utf8", "-m", "pytest", "-q", "tests"],
                          studio.paths.code, 1800)


PACKAGES = {"read": ("Lecture des PDF et des images (~140 Mo)", ("PyMuPDF", "pillow")),
           "speech": ("Lecture des sons et vidéos (~550 Mo, + modèle ~480 Mo à la 1re pièce sonore)", ("faster-whisper", "av")),
           "retro": ("Outils de rétro-ingénierie (~25 Mo)", ("pefile", "capstone", "lief", "kaitaistruct"))}
LOCKS = {"retro": "requirements-retro.lock.txt"}          # otherwise requirements-attachments.lock.txt
# Nom livré par les mises à jour 0.4.39 : l'updater 0.4.38 refuse tout autre fichier racine.
LEGACY_ATTACHMENTS_LOCK = "requirements-pieces.lock.txt"
MODULES = {"read": (("pymupdf", "fitz"), ("PIL",)), "speech": (("faster_whisper",), ("av",)),
           "retro": (("pefile",), ("capstone",), ("lief",), ("kaitaistruct",))}      # each group: any one of the names is enough


def installed() -> dict:
    """Optional modules already present (without importing them): an install button already used disappears."""
    import importlib
    import importlib.util
    importlib.invalidate_caches()                        # also sees what was just installed, without restarting
    return {what: all(any(importlib.util.find_spec(n) for n in group) for group in groups)
            for what, groups in MODULES.items()}


def install(studio, jobs: Jobs, what: str) -> dict:
    if what not in PACKAGES:
        raise ValueError("Installation inconnue.")
    if installed().get(what):
        raise ValueError("Déjà installé : rien à faire.")
    title, names = PACKAGES[what]
    lock = studio.paths.code / LOCKS.get(what, "requirements-attachments.lock.txt")
    if not lock.is_file() and what not in LOCKS:
        lock = studio.paths.code / LEGACY_ATTACHMENTS_LOCK
    pinned = [l.strip() for l in lock.read_text(encoding="utf-8").splitlines() if l.strip() and not l.startswith("#")]
    packages = [l for l in pinned if l.split("==")[0].lower() in {n.lower() for n in names}]
    if what == "speech":
        packages = [l for l in pinned if l.split("==")[0].lower() in {"pymupdf", "pillow"}] + packages   # audio frames
    return jobs.launch(f"install:{what}", title, [python_console(), "-m", "pip", "install", "--disable-pip-version-check",
                                                        *packages], studio.paths.code, 1800)


# ------------------------------------------------------------------ workspace cleanup
def _size(d: Path) -> int:
    total = 0
    for root_dir, _, task_files in os.walk(d):
        for f in task_files:
            try:
                total += os.path.getsize(os.path.join(root_dir, f))
            except OSError:
                pass
    return total


def _base(studio, tid: str) -> str:
    try:
        return json.loads((studio.details_dir(tid) / "base.json").read_text(encoding="utf-8")).get("_worktree", "")
    except (OSError, ValueError):
        return ""


def workspaces(studio) -> list[dict]:
    """Task workspaces (worktrees), with size, task state and merge state."""
    git = studio.cfg["tools"].get("git", "git")
    runs = studio.paths.runs.resolve()
    out = []
    for target in studio.registry.all():
        if target.kind != "project" or target.extra.get("isolation") != "worktree" or not target.has_path or not target.path().is_dir():
            continue
        try:
            entries = ws._git(git, target.path(), "worktree", "list", "--porcelain")
        except ws.WorktreeError:
            continue
        for block in entries.strip().split("\n\n"):
            field_values = dict(l.split(" ", 1) for l in block.splitlines() if " " in l)
            path_value = Path(field_values.get("worktree", ""))
            try:
                rel = path_value.resolve().relative_to(runs)
            except (ValueError, OSError):
                continue                             # not a studio workspace (your folder, or another tool's)
            tid = studio.task_from_folder(rel.parts[0]) if rel.parts else ""
            try:
                task_status = studio.store.get(tid)["status"]
            except KeyError:
                task_status = "unknown"
            if any(o["path_value"] == str(path_value) for o in out):
                continue                             # two targets on the same repository: a single row
            branch = f"studio/{tid}"
            base = _base(studio, tid)
            has_content = bool(base) and ws._succeeds(git, target.path(), "rev-parse", "--verify", "-q", branch) and \
                ws._git(git, target.path(), "rev-list", "--count", f"{base}..{branch}").strip() != "0"
            merged = has_content and ws._succeeds(git, target.path(), "merge-base", "--is-ancestor", branch, "HEAD")
            copies = [p for p in studio.details_dir(tid, create_new=False).glob("review-*") if p.is_dir()] if tid else []
            out.append({"task": tid, "project": target.name, "path_value": str(path_value), "status": task_status, "merged": merged,
                        "empty": not has_content,
                        "bytes": (_size(path_value) if path_value.is_dir() else 0) + sum(_size(p) for p in copies),
                        "removable": task_status in TERMINAL})
    return out


def remove_workspace(studio, tid: str) -> dict:
    """Removes the workspace of a finished task (after the user's click). The approved work is already in its
    branch; the branch is deleted only if it is merged (git branch -d, never -D). The Taches\\<task> folder
    (result, diff, log) is kept."""
    git = studio.cfg["tools"].get("git", "git")
    t = studio.store.get(tid)
    if t["status"] not in TERMINAL:
        raise ValueError("La tâche n'est pas terminée : son espace reste.")
    target = studio.registry.get(t["target"])
    user_workspace = studio.run_dir(tid) / ws.WORKSPACE
    if not (user_workspace / ".git").is_file():
        raise ValueError("Pas d'espace de travail git pour cette tâche.")
    if t["status"] in ("approved", "applied"):
        if _worktree_changes(git, user_workspace):
            raise ValueError("L'espace contient des modifications réelles : sauvegarde-les ou commite-les, puis réessaie.")
        bj = studio.details_dir(tid) / "branch.json"
        valid = json.loads(bj.read_text(encoding="utf-8")).get("commit", "") if bj.exists() else ""
        if valid and not ws._succeeds(git, target.path(), "merge-base", "--is-ancestor", valid, f"studio/{tid}"):
            raise ValueError("Le commit validé n'est plus sur la branche de la tâche : rien n'est retiré.")
    ws._git(git, target.path(), "worktree", "remove", "--force", str(user_workspace), timeout=600)
    import shutil
    for copy_dir in studio.details_dir(tid).glob("review-*"):
        if copy_dir.is_dir():
            shutil.rmtree(copy_dir, ignore_errors=True)     # the auditor's disposable copies, can be recreated
    (studio.run_dir(tid) / ws.READY_MARKER).unlink(missing_ok=True)
    msg = "Espace retiré."
    base = _base(studio, tid)
    content = bool(base) and ws._git(git, target.path(), "rev-list", "--count", f"{base}..studio/{tid}").strip() != "0"
    merged = content and ws._succeeds(git, target.path(), "merge-base", "--is-ancestor", f"studio/{tid}", "HEAD")
    if merged or not content:
        try:
            ws._git(git, target.path(), "branch", "-d", f"studio/{tid}")
            msg += f" Branche studio/{tid} supprimée ({'déjà fusionnée' if merged else 'empty'})."
        except ws.WorktreeError:
            msg += f" Branche studio/{tid} conservée."
    else:
        msg += f" Branche studio/{tid} conservée (pas fusionnée)."
    studio.store.event(tid, msg + " (par l'utilisateur depuis l'interface)")
    return {"state": "ok", "message": msg}


# ------------------------------------------------------------------ versions of the subscription tools, update
NPM_PACKAGES = {"claude": "@anthropic-ai/claude-code", "codex": "@openai/codex"}
_latest: dict[str, tuple[float, str]] = {}


def latest_version(tool: str) -> str:
    """Latest published version (npm registry, public read, nothing is sent); cached for an hour; empty when offline."""
    import json as _json
    import urllib.request
    package = NPM_PACKAGES[tool]
    t, v = _latest.get(tool, (0.0, ""))
    if time.time() - t < 3600:
        return v
    v = ""
    for _ in range(2):                             # a transient failure does not leave « inconnue » for an hour
        try:
            req = urllib.request.Request(f"https://registry.npmjs.org/{package}/latest", headers={"User-Agent": "SuperAIStudio"})
            with urllib.request.urlopen(req, timeout=12) as r:
                v = str(_json.loads(r.read().decode("utf-8")).get("version", ""))
            break
        except Exception:                          # noqa: BLE001 — offline or registry unavailable: no info
            v = ""
    if v:
        _latest[tool] = (time.time(), v)
    return v


def local_runner_version() -> dict:
    """Local model runner: installed version (local API, otherwise the command) and latest published (GitHub). Read-only."""
    import json as _json
    import shutil
    import urllib.request
    from .local_models import LOCAL_RUNNER, local_runner_executable
    inst = ""
    try:
        with urllib.request.urlopen(LOCAL_RUNNER + "/api/version", timeout=2) as r:
            inst = str(_json.loads(r.read()).get("version", ""))
    except Exception:                              # noqa: BLE001 — not running: read the version from the command
        exe = local_runner_executable()
        if exe:
            try:
                out = subprocess.run([exe, "--version"], capture_output=True, text=True, errors="replace", timeout=20, stdin=subprocess.DEVNULL, **NO_WINDOW)
                m = re.search(r"(\d+\.\d+\.\d+)", out.stdout + out.stderr)
                inst = m.group(1) if m else ""
            except (OSError, subprocess.TimeoutExpired):
                pass
    t, latest = _latest.get("ollama", (0.0, ""))
    if time.time() - t > 3600:
        try:
            req = urllib.request.Request("https://api.github.com/repos/ollama/ollama/releases/latest", headers={"User-Agent": "SuperAIStudio"})
            with urllib.request.urlopen(req, timeout=12) as r:
                latest = str(_json.loads(r.read()).get("tag_name", "")).lstrip("v")
            if latest:
                _latest["ollama"] = (time.time(), latest)
        except Exception:                          # noqa: BLE001
            latest = ""
    up_to_date = None
    if inst and latest:
        up_to_date = tuple(int(x) for x in re.findall(r"\d+", inst)[:3]) >= tuple(int(x) for x in re.findall(r"\d+", latest)[:3])
    winget = shutil.which("winget")
    return {"name": "Ollama (modèles locaux)", "path_value": local_runner_executable() or "", "installed": inst, "latest": latest, "up_to_date": up_to_date,
            "method": "Ollama se met à jour seul (icône Ollama › Restart to update)" + (" ou : winget upgrade --id Ollama.Ollama -e" if winget else ""),
            "possible": False}


def _installed_version(exe: str | None) -> str:
    from .connectors.primary_cli import parse_version
    if not exe:
        return ""
    try:
        out = subprocess.run([exe, "--version"], capture_output=True, text=True, timeout=30, encoding="utf-8",
                             errors="replace", stdin=subprocess.DEVNULL, **NO_WINDOW)
        return ".".join(map(str, parse_version(out.stdout or out.stderr)))
    except (OSError, subprocess.TimeoutExpired):
        return ""


def _update_command(tool: str, exe: str | None) -> tuple[list[str] | None, str]:
    """How to update the tool as it is installed on this PC (never guessing at random)."""
    import shutil
    if not exe:
        return None, "missing"
    bottom = exe.replace("\\", "/").lower()
    if tool == "claude":
        return [exe, "update"], "claude update"
    if "/openai/codex/bin/" in bottom:
        return None, "mis à jour par l'application Codex (ouvre-la : elle se met à jour seule)"
    npm = shutil.which("npm")
    if npm and ("/npm/" in bottom or bottom.endswith(".cmd")):
        return [npm, "install", "-g", f"{NPM_PACKAGES['codex']}@latest"], "npm install -g @openai/codex@latest"
    return None, "installation non reconnue : mets Codex à jour comme tu l'as installé"


def versions(studio) -> dict:
    from .connectors.base import find_exe
    from .connectors.primary_cli import WIN_CANDIDATES as CC
    from .connectors.secondary_cli import WIN_CANDIDATES as CX
    out = {}
    for tool, cand, name in (("claude", CC, "Claude Code"), ("codex", CX, "Codex")):
        exe = find_exe(studio.cfg["tools"].get(json.TOOL_KEYS.get(tool, tool), tool), cand)
        inst, latest = _installed_version(exe), latest_version(tool)
        cmd, rpc_method = _update_command(tool, exe)
        up_to_date = None
        if inst and latest:
            up_to_date = tuple(int(x) for x in inst.split(".")) >= tuple(int(x) for x in re.findall(r"\d+", latest)[:3])
        out[tool] = {"name": name, "path_value": exe or "", "installed": inst, "latest": latest, "up_to_date": up_to_date,
                      "method": rpc_method, "possible": bool(cmd)}
    o = local_runner_version()
    if o["installed"] or o["path_value"]:                 # shown only if the local model runner is on the PC
        out["ollama"] = o
    return out


def apply_update(studio, jobs: Jobs, tool: str) -> dict:
    """Updates a subscription tool in the background. Refused while a task is running (the tool would be replaced
    mid-work). Model aliases (opus, sonnet, haiku) automatically follow new models."""
    from .connectors.base import find_exe
    from .connectors.primary_cli import WIN_CANDIDATES as CC
    from .connectors.secondary_cli import WIN_CANDIDATES as CX
    if tool not in NPM_PACKAGES:
        raise ValueError("Outil inconnu.")
    with studio.store.db() as c:                  # busy slots = agents actually working (fixes included)
        from .orchestrator.store import pid_alive         # a slot left by a vanished process does not block
        busy_count = sum(1 for r in c.execute("SELECT pid FROM slots WHERE task_id IS NOT NULL") if pid_alive(r[0]))
    active_tasks = [t for t in studio.store.list(200) if t["status"] in ("created", "running", "awaiting_slot")]
    if busy_count or active_tasks:
        raise RuntimeError(f"{max(busy_count, len(active_tasks))} tâche(s) en cours : attends qu'elles finissent avant de mettre à jour.")
    exe = find_exe(studio.cfg["tools"].get(json.TOOL_KEYS.get(tool, tool), tool), CC if tool == "claude" else CX)
    cmd, rpc_method = _update_command(tool, exe)
    if not cmd:
        raise ValueError(f"Mise à jour automatique impossible : {rpc_method}.")

    def after(code, output):                       # the new version is read again on the next call
        for ex in list(getattr(studio, "executors", {}).values()) + list(getattr(studio, "auditors", {}).values()):
            for attr in ("_version", "_effort"):
                if hasattr(ex, attr):
                    setattr(ex, attr, None)
        _latest.pop(tool, None)
    name = "Claude Code" if tool == "claude" else "Codex"
    return jobs.launch(f"update:{tool}", f"Mise à jour de {name}", cmd, studio.paths.code, 900, after=after)
