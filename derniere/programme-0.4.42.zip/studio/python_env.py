"""Environnement Python versionné pour les mises à jour qui apportent de nouveaux composants (wheels/).

Avant : pip installait dans l'environnement en service ; un échec à mi-chemin le laissait modifié, et le retour arrière
du programme ne le réparait pas. Maintenant :

1. un NOUVEL environnement est préparé à côté (``.venvs/<version>``), l'ancien n'est jamais touché ;
2. il est vérifié (``pip check`` et import des modules du studio) ;
3. l’interface propose un redémarrage ; seul ce clic désigne le résultat dans ``.venvs/active.json`` ;
4. au démarrage suivant, le studio se relance avec cet interpréteur (``relaunch_if_needed``).

La préparation facultative démarre après l’interface, en arrière-plan. Son échec est affiché et journalisé ; une
empreinte de verrou n’est essayée automatiquement qu’une fois. Aucun installateur n’est lancé depuis ``__main__``.

Retour arrière : ``python -m studio python-env-rollback`` (l'ancien environnement est conservé). Un environnement dont
la préparation a échoué est gardé sous ``<version>.failed-<date>`` pour diagnostic, jamais activé.
"""
from __future__ import annotations

import json
import hashlib
import os
import subprocess
import sys
import time
from contextlib import contextmanager
from pathlib import Path

ENVS = ".venvs"
POINTER = "active.json"
SWITCHED = "STUDIO_PYTHON_ENV_SWITCHED"
VERIFY = "import studio.config, studio.orchestrator.runner, studio.ui.server; import webview"


def python_in(env: Path, windowed: bool = False) -> Path:
    if sys.platform == "win32":
        return Path(env) / "Scripts" / ("pythonw.exe" if windowed else "python.exe")
    return Path(env) / "bin" / "python"


def _run(cmd: list, cwd: Path, timeout: float = 900) -> subprocess.CompletedProcess:
    from .connectors.base import NO_WINDOW
    return subprocess.run([str(c) for c in cmd], cwd=str(cwd), capture_output=True, text=True, encoding="utf-8",
                          errors="replace", timeout=timeout, stdin=subprocess.DEVNULL, **NO_WINDOW)


def prepare(code: Path, version: str, run=_run, progress=None) -> Path:
    """Creates and checks a new environment for ``version``; raises RuntimeError (nothing activated) on failure."""
    code = Path(code)
    stamp = time.strftime("%Y%m%d-%H%M%S")
    new = code / ENVS / f"{version}-{stamp}-{time.time_ns() % 1_000_000_000:09d}"
    new.parent.mkdir(parents=True, exist_ok=True)
    base = getattr(sys, "_base_executable", "") or sys.executable
    py = python_in(new)
    bundled = code / "installeur/python-wheels"
    if not bundled.is_dir():
        bundled = code / "wheels"
    source = ["--no-index", "--find-links", str(bundled)] if sys.platform == "win32" else []
    steps = [("création", [base, "-m", "venv", str(new)]),
             ("composants", [py, "-m", "pip", "install", "--disable-pip-version-check", *source, "-r", str(code / "requirements.lock.txt")]),
             ("cohérence", [py, "-m", "pip", "check"]),
             ("démarrage", [py, "-c", VERIFY])]
    for number, (name, cmd) in enumerate(steps):
        if progress:
            progress(name, number, len(steps))
        r = run(cmd, code)
        if r.returncode:
            failed = new.with_name(f"{new.name}.failed")
            try:
                if new.exists():
                    new.rename(failed)               # kept for diagnosis, never activated
            except OSError:
                pass
            raise RuntimeError(f"nouvel environnement Python non prêt (étape {name}) : "
                               + ((r.stderr or "") + (r.stdout or ""))[-300:] + " — l'environnement actuel n'a pas changé")
    if progress:
        progress("prêt", len(steps), len(steps))
    return new


def pointer(code: Path) -> dict:
    try:
        d = json.loads((Path(code) / ENVS / POINTER).read_text(encoding="utf-8"))
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def _write_pointer(code: Path, d: dict) -> None:
    f = Path(code) / ENVS / POINTER
    f.parent.mkdir(parents=True, exist_ok=True)
    tmp = f.with_name(f.name + ".tmp")
    tmp.write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, f)


FAILED_KEEP_DAYS = 7


def activate(code: Path, new: Path, current: Path | None = None) -> dict:
    """Points the studio at ``new`` for its next start; the environment in service becomes the rollback target.
    Then only those two are kept in .venvs (plus recent failed ones, for diagnosis)."""
    current = Path(current or sys.prefix)
    d = {"current": str(Path(new)), "previous": str(current), "at": time.strftime("%Y-%m-%dT%H:%M:%S")}
    lock = Path(code) / "requirements.lock.txt"
    if lock.is_file():
        d["lock_sha256"] = hashlib.sha256(lock.read_bytes()).hexdigest()
    _write_pointer(code, d)
    prune(code)
    return d


def prune(code: Path, now: float | None = None) -> list[str]:
    """Removes, inside .venvs only, the environments that are neither the active one nor the previous one, and failed
    ones older than 7 days. The original .venv (outside .venvs) is never touched. Returns the removed names."""
    import shutil
    d = pointer(code)
    keep = set()
    for k in ("current", "previous"):
        if d.get(k):
            try:
                keep.add(Path(d[k]).resolve())
            except OSError:
                pass
    folder = Path(code) / ENVS
    if not d.get("current") or not folder.is_dir():
        return []
    now = time.time() if now is None else now
    removed = []
    for p in sorted(folder.iterdir()):
        if not p.is_dir() or p.is_symlink() or p.resolve() in keep:
            continue
        if p.name.endswith(".failed") and now - p.stat().st_mtime < FAILED_KEEP_DAYS * 86400:
            continue
        shutil.rmtree(p, ignore_errors=True)
        removed.append(p.name)
    return removed


def rollback(code: Path) -> dict:
    d = pointer(code)
    if not d.get("previous") or not python_in(Path(d["previous"])).exists():
        raise ValueError("Pas d'environnement précédent disponible.")
    d = {"current": d["previous"], "previous": d["current"], "at": time.strftime("%Y-%m-%dT%H:%M:%S"), "rollback": True}
    lock = Path(code) / "requirements.lock.txt"
    if lock.is_file():
        d["rollback_lock_sha256"] = hashlib.sha256(lock.read_bytes()).hexdigest()
    _write_pointer(code, d)
    return d


def target(code: Path) -> Path | None:
    """Interpreter the studio should run with, if it is not the current one (and exists)."""
    d = pointer(code)
    env = Path(d["current"]) if d.get("current") else None
    if env is None or not python_in(env).exists():
        return None
    try:
        if env.resolve() == Path(sys.prefix).resolve():
            return None
    except OSError:
        return None
    return python_in(env, windowed=Path(sys.executable).name.lower() == "pythonw.exe")


def relaunch_if_needed(code: Path, argv: list[str]) -> int | None:
    """Started from the old environment after an update: runs the same command with the new interpreter.
    Returns its exit code, or None when nothing is to be done (already the right one, or already relaunched)."""
    if os.environ.get(SWITCHED):
        return None
    py = target(code)
    if py is None:
        return None
    if argv and argv[0] in ("launcher", "lanceur"):
        subprocess.Popen([str(py), "-m", "studio", *argv], cwd=str(code),
                         env={**os.environ, SWITCHED: "1"}, stdin=subprocess.DEVNULL,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, close_fds=True,
                         **({"creationflags": 0x00000008 | 0x00000200 | 0x08000000} if sys.platform == "win32"
                            else {"start_new_session": True}))
        return 0
    return subprocess.call([str(py), "-m", "studio", *argv], cwd=str(code), env={**os.environ, SWITCHED: "1"})


class EnvironmentBusy(RuntimeError):
    pass


@contextmanager
def environment_lock(code, blocking=True):
    """Two desktop launches must not prepare or activate the same environment concurrently."""
    folder = Path(code) / ENVS
    folder.mkdir(parents=True, exist_ok=True)
    with (folder / "prepare.lock").open("a+b") as stream:
        if stream.tell() == 0:
            stream.write(b"0")
            stream.flush()
        stream.seek(0)
        if sys.platform == "win32":
            import msvcrt
            started = time.monotonic()
            while True:
                try:
                    msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
                    break
                except OSError:
                    if not blocking:
                        raise EnvironmentBusy("Une préparation des composants est déjà en cours.") from None
                    if time.monotonic() - started > 1800:
                        raise RuntimeError("Un environnement Python est encore en préparation.") from None
                    time.sleep(.2)
        else:
            import fcntl
            try:
                fcntl.flock(stream, fcntl.LOCK_EX | (0 if blocking else fcntl.LOCK_NB))
            except BlockingIOError:
                raise EnvironmentBusy("Une préparation des composants est déjà en cours.") from None
        try:
            yield
        finally:
            stream.seek(0)
            if sys.platform == "win32":
                msvcrt.locking(stream.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(stream, fcntl.LOCK_UN)


def ensure_bundled_environment(code: Path, **options) -> dict:
    """Optional preparation starts only after the interface is listening, never from __main__."""
    from .window_components import ensure
    return ensure(code, **options)
