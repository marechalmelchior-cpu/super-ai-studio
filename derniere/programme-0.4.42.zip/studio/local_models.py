"""Models on your PC (Gestion › Benchmarks › « Installer »): downloaded by the local model runner, with progress.

- Only local models from the benchmarks catalogue install here (name checked), on the user's click.
- The runner must be installed: the studio never installs it itself (download link otherwise).
- Le lancement exige un clic sur « Serveur local », jamais un simple envoi de travail.
  Les lectures et l'installation d'un modèle n'ouvrent jamais le logiciel à sa place.
- The download goes through the runner's local API (127.0.0.1:11434); nothing else is launched.
"""
from __future__ import annotations

from .migrations import compatibility as json
import re
import threading
import urllib.error
import urllib.request

LOCAL_RUNNER = "http://127.0.0.1:11434"
DOWNLOAD_LOCAL_RUNNER = "https://ollama.com/download"
_NAME = re.compile(r"^[a-z0-9][a-z0-9._-]{0,80}(:[a-z0-9._-]{1,40})?$")
_in_progress: dict[str, dict] = {}
_lock = threading.Lock()


def _get(path_value: str, delay: float = 2):
    with urllib.request.urlopen(LOCAL_RUNNER + path_value, timeout=delay) as r:
        return json.loads(r.read() or b"{}")


def local_runner_executable() -> str:
    """Runner installed on this PC (even closed): path of the command, else empty."""
    import glob
    import os
    import shutil
    p = shutil.which("ollama")
    if p:
        return p
    for pattern in ("~/AppData/Local/Programs/Ollama/ollama.exe", "C:/Program Files/Ollama/ollama.exe",
                  "/Applications/Ollama.app/Contents/Resources/ollama", "/usr/local/bin/ollama", "/opt/homebrew/bin/ollama"):
        t = glob.glob(os.path.expanduser(pattern))
        if t:
            return t[0]
    return ""


def startup() -> dict:
    """Démarrage uniquement à la suite d'un clic explicite."""
    from .local_servers import start
    return start("ollama")


def ensure() -> bool:
    """Vérifie seulement la disponibilité ; aucun lancement automatique."""
    if installed() is not None:
        return True
    return False


def details() -> list[dict]:
    """Installed models with size and date (Gestion › Outils: local model updates)."""
    try:
        return [{"name": m.get("name", ""), "size_go": round((m.get("size") or 0) / 1e9, 1), "modified": str(m.get("modified_at", ""))[:10]}
                for m in _get("/api/tags").get("models", []) if m.get("name")]
    except (OSError, ValueError):
        return []


def installed() -> list[str] | None:
    """Models already present in the runner; None if the runner does not answer."""
    try:
        return sorted(m.get("name", "") for m in _get("/api/tags").get("models", []) if m.get("name"))
    except (OSError, ValueError):
        return None


def local_runner_name(m: dict) -> str:
    """Name to download: the « ollama » field, else the key only when it already looks like a runner name (name:tag);
    a repository id (« meta-llama/… ») is not installable as such."""
    import re
    if m.get("ollama"):
        return str(m["ollama"])
    key = str(m.get("key") or "")
    return key if re.fullmatch(r"[a-z0-9][a-z0-9._-]*(:[a-z0-9._-]+)?", key) and "/" not in key else ""


def present(name: str, entries: list[str]) -> bool:
    """« qwen3.6 » is present if « qwen3.6:latest » or « qwen3.6:27b » is."""
    base = name if ":" in name else name + ":"
    return any(x == name or x.startswith(base) for x in entries)


def state(catalog: list[dict]) -> dict:
    entries = installed()
    with _lock:
        in_progress = {k: dict(v) for k, v in _in_progress.items()}
    model_list = {}
    for m in catalog:
        n = local_runner_name(m)
        if m.get("local") and n:
            model_list[n] = {"installed": bool(entries) and present(n, entries), **({"progress": in_progress[n]} if n in in_progress else {})}
    return {"ollama": entries is not None, "installed": entries is not None or bool(local_runner_executable()),
            "download": DOWNLOAD_LOCAL_RUNNER, "models": model_list}


def error_message(e: Exception) -> str:
    """Runner error in plain words, with what to do (most common: runner too old for a recent model)."""
    t = str(e)
    if isinstance(e, urllib.error.HTTPError):
        try:
            t = f"{e.code} {json.loads(e.read() or b'{}').get('error', '')}"
        except (OSError, ValueError):
            t = str(e.code)
    bottom = t.lower()
    if "412" in bottom or "newer version" in bottom:
        return "Ollama est trop ancien pour ce modèle : mets-le à jour (ollama.com/download ou l'icône Ollama › Update), puis réessaie."
    if "file does not exist" in bottom or "not found" in bottom or "404" in bottom:
        return "Ce modèle n'existe pas (ou plus) sous ce nom chez Ollama."
    if "no space" in bottom or "disk" in bottom:
        return "Plus assez de place sur le disque pour ce modèle."
    return f"Échec : {t[:200]}"


def uninstall(name: str) -> dict:
    """Removes a model from the runner (on click, after confirmation): only actually installed models are accepted."""
    name = (name or "").strip()
    entries = installed()
    if entries is None:
        raise ValueError("Ollama ne répond pas : ouvre-le, puis réessaie.")
    if name not in entries:
        raise ValueError("Ce modèle n'est pas installé.")
    req = urllib.request.Request(LOCAL_RUNNER + "/api/delete", data=json.dumps({"model": name}).encode(), method="DELETE",
                                 headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=60):
            pass
    except (OSError, urllib.error.HTTPError) as e:
        raise ValueError(error_message(e)) from None
    with _lock:
        _in_progress.pop(name, None)
    return {"ok": True, "message": f"{name} désinstallé."}


def install(name: str, catalog: list[dict], note=lambda m: None, open_: bool = False) -> dict:
    name = (name or "").strip().lower()
    if not _NAME.match(name) or name not in {local_runner_name(m) for m in catalog if m.get("local")} | set(installed() or []):
        raise ValueError("Modèle inconnu du catalogue : rien n'est installé.")
    # Le paramètre historique reste accepté ; une installation ne lance plus le logiciel.
    if installed() is None:
        raise ValueError(f"Ollama ne répond pas sur le PC. Installe-le ({DOWNLOAD_LOCAL_RUNNER}) s'il ne l'est pas, puis réessaie."
                         if not local_runner_executable() else "Ollama ne répond pas : ouvre-le sur le PC, puis réessaie.")
    with _lock:
        if name in _in_progress and _in_progress[name].get("state") == 'downloading':
            return {"ok": True, "already": True}
        _in_progress[name] = {"state": 'downloading', "pct": 0, "message": "Démarrage…"}

    def pull():
        try:
            req = urllib.request.Request(LOCAL_RUNNER + "/api/pull", data=json.dumps({"model": name, "stream": True}).encode(),
                                         headers={"Content-Type": "application/json"})
            with urllib.request.urlopen(req, timeout=300) as r:
                for line in r:
                    try:
                        d = json.loads(line)
                    except ValueError:
                        continue
                    if d.get("error"):
                        raise RuntimeError(str(d["error"])[:300])
                    with _lock:
                        p = _in_progress[name]
                        if d.get("total"):
                            p["pct"] = int(100 * (d.get("completed") or 0) / d["total"])
                        p["message"] = str(d.get("status", ""))[:80]
            with _lock:
                _in_progress[name] = {"state": "finished", "pct": 100, "message": "Installé."}
            note(f"modèle local installé : {name}")
        except Exception as e:                             # noqa: BLE001 — shown next to the model
            with _lock:
                _in_progress[name] = {"state": "error", "pct": 0, "message": error_message(e)}
    threading.Thread(target=pull, daemon=True).start()
    return {"ok": True}
