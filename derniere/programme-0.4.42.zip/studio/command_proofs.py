"""Attributed command evidence from tool events, never from an agent's prose."""
from __future__ import annotations

import json
import threading
from datetime import datetime, timezone
from pathlib import Path

from .security import redact

_lock = threading.Lock()


def append(path, *, actor, command, decision="executed", exit_code=None, source="studio", event_id=""):
    row = {"at": datetime.now(timezone.utc).isoformat(), "actor": actor, "command": redact(command),
           "decision": decision, "exit_code": exit_code, "source": source, "event_id": event_id}
    with _lock:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(row, ensure_ascii=False) + "\n")


def secondary_events(jsonl):
    out = []
    seen = set()
    for line in jsonl.splitlines():
        try:
            event = json.loads(line)
        except (ValueError, TypeError):
            continue
        if not isinstance(event, dict) or event.get("type") != "item.completed":
            continue
        item = event.get("item") or {}
        if item.get("type") != "command_execution" or not isinstance(item.get("command"), str):
            continue
        key = item.get("id") or str(len(out))
        if key in seen:
            continue
        seen.add(key)
        out.append({"command": item["command"], "exit_code": item.get("exit_code"), "event_id": key})
    return out


def agent_commands(path):
    try:
        lines = Path(path).read_text(encoding="utf-8").splitlines()
    except OSError:
        return []
    out = []
    for line in lines:
        try:
            row = json.loads(line)
        except ValueError:
            if "relecture" in line.lower() or "reviewer" in line.lower():
                continue
            # Old logs have no trustworthy attribution: keep them as historical, never as new agent proof.
            out.append("historique · acteur non enregistré · " + line[:1000])
            continue
        if not isinstance(row, dict) or row.get("actor") != "agent":
            continue
        label = "exécutée par l’agent (bac à sable de l’outil)" if row.get("source") == "tool_sandbox" else "agent"
        out.append(f"{label} · {row.get('decision')} · code {row.get('exit_code')} · `{row.get('command', '')}`")
    return out[-100:]
