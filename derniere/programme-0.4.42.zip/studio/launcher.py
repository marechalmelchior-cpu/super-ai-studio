"""Launcher for the « Super AI Agent Pro Station Max 2000 » shortcut (desktop): one click opens the UI in its own window.

- Local only (127.0.0.1), nothing is exposed on the network or the Internet.
- Random session key at each start, exchanged for an HttpOnly cookie: another application or a
  website open in the browser cannot drive the studio.
- No permanent service: the server stops by itself ~1 min after the last window closes, but
  never during a task started from the UI (it waits for the end). « Fermer le studio » button too.
- Second click while the studio is open: new window on the same session.
Log without secrets: Studio/data/journaux/interface.log.
"""
from __future__ import annotations

from .migrations import compatibility as json
import os
import secrets
import threading
import shutil
import subprocess
import sys
import urllib.error
import urllib.request
import webbrowser
from datetime import datetime
from .migrations.compatibility import TechnicalPath as Path

from .config import load_config
from .paths import default_paths

ABSENCE_S = 600         # stop 10 min after the last sign of the window (a window in the background is slowed down by the
                        # browser: 1 min was taken for « closed »); closing the window says so at once (stop ~10 s later)


def _message(text: str) -> None:
    if sys.platform == "win32":
        import ctypes
        ctypes.windll.user32.MessageBoxW(0, text, "Super AI Agent Pro Station Max 2000", 0x40)
        return
    print(text)
    try:                                               # Mac / Linux launched without a terminal: message box too
        if sys.platform == "darwin":
            subprocess.run(["osascript", "-e", "on run argv", "-e", 'display dialog (item 1 of argv) buttons {"OK"} with title "Super AI Studio"',
                            "-e", "end run", text], timeout=300, capture_output=True)
        elif shutil.which("zenity"):
            subprocess.run(["zenity", "--info", "--title=Super AI Studio", f"--text={text}"], timeout=300, capture_output=True)
    except (OSError, subprocess.SubprocessError):
        pass


def _ping(host: str, port: int) -> bool | None:
    """True = a studio responds; False = port free; None = port used by something else."""
    try:
        with urllib.request.urlopen(f"http://{host}:{port}/api/ping", timeout=2) as r:
            payload = json.loads(r.read())
            return payload.get("studio") is True or payload.get("first") is True
    except urllib.error.HTTPError:
        return None
    except (OSError, ValueError):
        return False


def _edge() -> str | None:
    """Edge on Windows; otherwise Chrome, Chromium or Brave (Mac, Linux): app window without an address bar."""
    from .os_support import browser_app
    return browser_app()


def window_options(data: Path | None) -> list[str]:
    """Window size and position at the last close (data/fenetre.json, recorded by the page):
    fullscreen, maximized, or exact position and size. Studio-specific Edge profile: the options are always
    applied, even if Edge is already open elsewhere."""
    if data is None:
        return []
    opts = [f"--user-data-dir={Path(data) / 'edge-studio'}", "--no-first-run", "--no-default-browser-check",
            "--disk-cache-size=104857600"]                               # window cache: 100 MB at most
    try:
        e = json.loads((Path(data) / "window.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return opts
    if e.get("fullscreen"):
        return opts + ["--start-fullscreen"]
    if e.get("maximized"):
        return opts + ["--start-maximized"]
    try:
        x, y, w, h = (int(e[k]) for k in ("x", "y", "l", "h"))
    except (KeyError, TypeError, ValueError):
        return opts
    if 400 <= w <= 10000 and 300 <= h <= 10000 and -10000 < x < 20000 and -10000 < y < 20000:
        opts += [f"--window-position={x},{y}", f"--window-size={w},{h}"]
    return opts


def open_window(url: str, data: Path | None = None, controller=None) -> None:
    from .desktop import open_window as native_window
    from .ui.server import Control
    import re
    from .user_workspace import custom
    source = (Path(__file__).parent / "ui/static/index.html").read_text(encoding="utf-8")
    title = custom(re.search(r"<title>(.*?)</title>", source).group(1))
    ctl = controller or Control()
    config = load_config(Path(data).parent / "studio.config.toml") if data else {}
    if os.environ.pop("STUDIO_FORCE_BROWSER", "") == "1":
        from .desktop import browser_window
        ctl.desktop = False
        browser_window(url, data, ctl)
    else:
        native_window(url, data, ctl, title, message=_message)


def daily_backup(paths, note=lambda m: None):
    """One studio backup per day, at the first launch of the day (nothing is deleted: older ones remain)."""
    from datetime import timezone
    day = datetime.now(timezone.utc).strftime("%Y%m%d")
    if any(p for p in paths.backups.glob(f"studio-{day}T*") if not p.name.endswith(".partiel")):
        return None
    try:
        from .backup import create_backup
        f = create_backup(paths)
        note(f"sauvegarde du jour : {f.name}")
        from .cleanup import cleanup_enabled, rotate_backups
        if cleanup_enabled(paths.config_file):
            n = rotate_backups(paths.backups)         # 7 days + 4 weeks kept
            if n:
                note(f"anciennes sauvegardes retirées : {n}")
        return f
    except Exception as e:                       # noqa: BLE001 — the backup never blocks opening
        note(f"sauvegarde du jour impossible : {type(e).__name__}")
        return None


def session_key(data: Path) -> str:
    """Session key stable across launches: a window or tab reopened on this PC stays signed in
    (cookie kept one year). Local file, never displayed or logged."""
    f = Path(data) / "interface-key.json"
    try:
        key = json.loads(f.read_text(encoding="utf-8"))["key"]
        if isinstance(key, str) and len(key) >= 32:
            return key
    except (OSError, ValueError, KeyError, TypeError):
        pass
    key = secrets.token_urlsafe(32)
    t = f.with_suffix(".partiel")
    t.write_text(json.dumps({"key": key}), encoding="utf-8")
    t.replace(f)
    return key


PORT_ASSISTANT = 8765      # port of the first-launch assistant (= studio's default port)


def first_launch() -> bool | None:
    """Studio installed without a workspace: first-launch assistant. True = workspace ready (window already open),
    None = nothing to do (workspace already set up), False = assistant closed before the end."""
    from .user_workspace import configured_root
    if configured_root() is not None:
        return None
    from .paths import StudioPaths
    from .first_launch import serve
    port = PORT_ASSISTANT
    if _ping("127.0.0.1", port) is True:
        from .first_launch import focus_existing
        if focus_existing(port):
            return False
    if _ping("127.0.0.1", port) is not False:
        _message(f"Le port {port} est déjà utilisé : ferme l'autre application (ou l'autre studio) puis relance.")
        return False

    def after(root_dir: Path) -> str:
        return f"/?t={session_key(StudioPaths(root_dir).ensure().data)}"
    from .ui.server import Control
    ctl = Control()
    return bool(serve(port, lambda url: open_window(url, None, controller=ctl), after, controller=ctl))


def main() -> int:
    from .os_support import complete_path
    complete_path()                                   # Mac / Linux: tools installed outside the desktop PATH
    try:                                              # files renamed by an update: old copies removed from the program
        from .cleanup import remove_obsolete_files, remove_obsolete_template_files
        from .paths import StudioPaths
        remove_obsolete_files(StudioPaths(Path(".")).code)
        remove_obsolete_template_files(StudioPaths(Path(".")).code)
    except Exception:                                 # noqa: BLE001 — never blocks the launch
        pass
    already = first_launch()
    if already is False:
        return 0
    paths = default_paths()
    from .migrations import MigrationError, migrate
    try:
        migrate(paths.root)
    except MigrationError as error:
        _message(str(error))
        return 1
    paths = paths.ensure()
    log = open(paths.logs / "interface.log", "a", encoding="utf-8", buffering=1)
    if sys.stdout is None or sys.executable.lower().endswith("pythonw.exe"):
        sys.stdout = sys.stderr = log                  # pythonw: no console

    def note(msg: str):
        log.write(f"{datetime.now().isoformat(timespec='seconds')}  {msg}\n")

    try:                                              # skills and shared rules: English names (one-time, nothing deleted)
        from .renames import migrate_workspace
        for line in migrate_workspace(paths.root):
            note(f"renommé : {line}")
    except Exception:                                 # noqa: BLE001 — never blocks the launch
        pass

    cfg = load_config(paths.config_file)
    host, port = cfg["interface"]["host"], int(cfg["interface"]["port"])
    session = paths.data / "interface-session.json"

    state = _ping(host, port)
    if state:
        try:
            token = json.loads(session.read_text(encoding="utf-8"))["token"]
        except (OSError, ValueError, KeyError):
            _message("Un studio est déjà ouvert mais sa session est introuvable. Ferme-le (bouton « Fermer le studio ») "
                     "puis relance le raccourci.")
            return 1
        note("instance déjà ouverte : remise au premier plan")
        req = urllib.request.Request(f"http://{host}:{port}/api/desktop/focus", data=b"{}", method="POST",
                                     headers={"X-Studio": "1", "Content-Type": "application/json",
                                              "Cookie": f"studio_session={token}"})
        try:
            with urllib.request.urlopen(req, timeout=3) as response:
                if not json.loads(response.read()).get("ok"):
                    _message("La fenêtre est en cours d’ouverture. Reviens à sa fenêtre depuis la barre des tâches.")
        except OSError:
            _message("La fenêtre ne répond pas encore. Reviens à sa fenêtre depuis la barre des tâches.")
        return 0
    if state is None:
        _message(f"Le port {port} est utilisé par une autre application. Change « port » dans "
                 f"Studio\\studio.config.toml (section [interface]) puis relance.")
        return 1

    token = session_key(paths.data)
    from .ui.server import Control, serve
    ctl = Control(absence_delay_s=ABSENCE_S)
    note(f"démarrage (pid {os.getpid()})")
    try:                                               # window not open yet: its cache can be cleared if it has grown too much
        from .cleanup import window_cache, cleanup_enabled
        if cleanup_enabled(paths.config_file):
            freed = window_cache(paths.data)
            if freed:
                note(f"cache de la fenêtre vidé : {freed // 2**20} Mo")
    except Exception:                                  # noqa: BLE001
        pass
    # does not prevent closing the studio: an interrupted backup stays a ".partiel" file, ignored and redone at the next launch
    threading.Thread(target=daily_backup, args=(paths, note), daemon=True).start()
    ready = threading.Event()
    ended = threading.Event()
    failures = []
    def on_ready(h, p):
        session.write_text(json.dumps({"token": token, "pid": os.getpid()}), encoding="utf-8")
        ready.set()
    def server():
        try:
            serve(token=token, controller=ctl, on_ready=on_ready)
        except Exception as error:
            failures.append(error)
        finally:
            ended.set()
            ctl.stop_request.set()
            ready.set()
    worker = threading.Thread(target=server, name="studio-server")
    worker.start()
    try:
        ready.wait()
        if failures:
            raise failures[0]
        ctl.open_request.set()
        while not ended.is_set():
            if ctl.open_request.wait(.2):
                ctl.open_request.clear()
                if not ctl.stop_request.is_set():
                    open_window(f"http://{host}:{port}/?t={token}", paths.data, controller=ctl)
        worker.join()
        if failures:
            raise failures[0]
    except (OSError, RuntimeError) as e:
        note(f"échec : {type(e).__name__}")
        _message(f"Impossible d'ouvrir le studio : {e}")
        return 1
    finally:
        ctl.stop_request.set()
        worker.join()
        try:
            if json.loads(session.read_text(encoding="utf-8")).get("pid") == os.getpid():
                session.unlink()
        except (OSError, ValueError):
            pass
        note("arrêt")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
