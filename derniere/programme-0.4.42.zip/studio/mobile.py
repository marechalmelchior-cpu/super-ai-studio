"""Access to the studio from the phone, through Tailscale (encrypted private network between the user's devices).

- The studio still only listens on 127.0.0.1: nothing is opened on the local network or the Internet.
- When the user enables « Accès depuis le téléphone » (Gestion › Réglages), the launcher asks Tailscale to relay
  https://<nom-du-pc>.<réseau>.ts.net to the studio (``tailscale serve``, in the foreground: the relay stops with the
  studio, no permanent configuration is left). Only the devices of the user's Tailscale account can reach it.
- A phone pairs once (Superviseur › Réglages › Téléphone: 6-digit code to type on the phone): it
  receives a device key (cookie),
  kept only as a hash in data/appareils.json, revocable at any time.
"""
from __future__ import annotations

import hashlib
import hmac
from .migrations import compatibility as json
import secrets
import shutil
import subprocess
import sys
import threading
from datetime import datetime, timezone
from .migrations.compatibility import TechnicalPath as Path

def address_history(data, address):
    """Historique local des adresses publiques du relais, sans clé d'appareil."""
    file = Path(data) / "phone-address.json"
    with _lock:
        try:
            state = json.loads(file.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            state = {}
        if address and address != state.get("current"):
            state = {"current": address, "previous": state.get("current", "") or state.get("previous", "")}
            file.parent.mkdir(parents=True, exist_ok=True)
            temp = file.with_suffix(".tmp")
            temp.write_text(json.dumps(state), encoding="utf-8")
            temp.replace(file)
    return {"previous_address": state.get("previous", ""), "address_changed": bool(state.get("previous") and address and state["previous"] != address)}


DEVICE_COOKIE = "studio_device"
_hosts: set[str] = set()                  # names allowed besides 127.0.0.1 (Tailscale relay active)
_lock = threading.Lock()


def tailscale_exe() -> str | None:
    p = Path(r"C:\Program Files\Tailscale\tailscale.exe")
    return str(p) if p.is_file() else shutil.which("tailscale")


def tailscale_state(exe: str | None = None) -> dict:
    """Read-only: Tailscale connected? PC name on the network? HTTPS certificates enabled?"""
    exe = exe or tailscale_exe()
    if not exe:
        return {"ok": False, "info": "Tailscale n'est pas installé sur ce PC."}
    from .connectors.base import NO_WINDOW
    try:
        r = subprocess.run([exe, "status", "--json"], capture_output=True, text=True, encoding="utf-8", errors="replace",
                           timeout=20, stdin=subprocess.DEVNULL, **NO_WINDOW)
        d = json.loads(r.stdout or "{}")
    except (OSError, subprocess.TimeoutExpired, ValueError):
        return {"ok": False, "info": "Tailscale ne répond pas."}
    dns = str((d.get("Self") or {}).get("DNSName") or "").rstrip(".")
    if d.get("BackendState") != "Running" or not dns:
        return {"ok": False, "info": "Tailscale n'est pas connecté : clique sur son icône près de l'horloge, puis Log in."}
    if not d.get("CertDomains"):
        return {"ok": False, "dns": dns, "info": "Active « HTTPS Certificates » sur login.tailscale.com/admin/dns."}
    return {"ok": True, "dns": dns, "info": f"https://{dns}"}


def allow_host(dns: str) -> None:
    with _lock:
        _hosts.update({dns, f"{dns}:443"})


def host_allowed(host: str) -> bool:
    with _lock:
        return host in _hosts


def remote_host() -> str:
    with _lock:
        return next((h for h in _hosts if ":" not in h), "")


_relay: dict = {"p": None, "log": None}


def _app_running(name: str) -> bool:
    if sys.platform != "win32":
        return False
    from .connectors.base import NO_WINDOW
    try:
        r = subprocess.run(["tasklist", "/FI", f"IMAGENAME eq {name}", "/NH"], capture_output=True, text=True, timeout=10,
                           stdin=subprocess.DEVNULL, errors="replace", **NO_WINDOW)
        return name.lower() in r.stdout.lower()
    except (OSError, subprocess.TimeoutExpired):
        return False


def connect_tailscale(note=lambda m: None, wait_s: float = 30.0) -> dict:
    """When the studio opens: opens the Tailscale app if it is closed and reconnects the PC to the network
    (``tailscale up``, as the user did by hand). No Tailscale setting is changed. Returns the state."""
    import time
    e = tailscale_state()
    exe = tailscale_exe()
    if e["ok"] or not exe:
        return e
    from .connectors.base import NO_WINDOW
    ipn = Path(exe).with_name("tailscale-ipn.exe")
    if sys.platform == "win32" and ipn.is_file() and not _app_running(ipn.name):
        try:
            subprocess.Popen([str(ipn)], stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                             close_fds=True, creationflags=getattr(subprocess, "DETACHED_PROCESS", 0x8))
            note("accès téléphone : application Tailscale ouverte")
            time.sleep(3)
        except OSError:
            pass
    try:
        r = subprocess.run([exe, "up", "--timeout=25s"], capture_output=True, text=True, encoding="utf-8", errors="replace",
                           timeout=40, stdin=subprocess.DEVNULL, **NO_WINDOW)
        output = (r.stdout or "") + (r.stderr or "")
    except (OSError, subprocess.TimeoutExpired):
        output = ""
    if "login.tailscale.com" in output or "NeedsLogin" in output:
        return {"ok": False, "info": "Tailscale demande de te reconnecter : clique sur son icône près de l'horloge, puis Log in."}
    finish = time.monotonic() + wait_s
    while time.monotonic() < finish:
        e = tailscale_state()
        if e["ok"] or e.get("dns"):
            return e
        time.sleep(2)
    if "requires mentioning all" in output:
        e["info"] = "Tailscale refuse la reconnexion automatique : clique sur son icône près de l'horloge, puis Connect."
    return e


def start_relay(port: int, logs: Path | None = None, note=lambda m: None) -> dict:
    """``tailscale serve`` in the foreground to the studio (stops with it, nothing permanent). Tailscale closed or
    disconnected: it is reopened and reconnected first. Returns the state (ok, info, dns)."""
    e = connect_tailscale(note)
    if not e["ok"]:
        note(f"accès téléphone : {e['info']}")
        return e
    with _lock:
        p = _relay["p"]
        if p is not None and p.poll() is None:
            return e
    from .connectors.base import NO_WINDOW
    log = Path(logs) / "tailscale-serve.log" if logs else None
    try:
        output = open(log, "w", encoding="utf-8") if log else subprocess.DEVNULL
        p = subprocess.Popen([tailscale_exe(), "serve", "--https=443", f"http://127.0.0.1:{port}"], stdin=subprocess.DEVNULL,
                             stdout=output, stderr=subprocess.STDOUT, **NO_WINDOW)
    except OSError as x:
        note(f"accès téléphone : relais impossible ({type(x).__name__})")
        return {"ok": False, "info": "Le relais Tailscale n'a pas pu démarrer."}
    with _lock:
        _relay.update(p=p, log=log)
    allow_host(e["dns"])
    note(f"accès téléphone : https://{e['dns']}")
    return e


def relay_active() -> bool:
    with _lock:
        p = _relay["p"]
    return p is not None and p.poll() is None


def stop_relay() -> None:
    with _lock:
        p, _relay["p"] = _relay["p"], None
        _hosts.clear()
    if p is not None and p.poll() is None:
        p.terminate()
        try:
            p.wait(timeout=5)
        except subprocess.TimeoutExpired:
            p.kill()


def relay_state() -> dict:
    """active? and, if Tailscale asks to allow "Serve" on the network, the link it gives."""
    import re
    with _lock:
        p, log = _relay["p"], _relay["log"]
    active = p is not None and p.poll() is None
    link, text = "", ""
    if log:
        try:
            text = Path(log).read_text(encoding="utf-8", errors="replace")[-4000:]
        except OSError:
            text = ""
        m = re.search(r"https://login\.tailscale\.com/\S+", text)
        link = m.group(0) if m else ""
    return {"active": active, "allow": link, "error": "" if active or not text else text.strip().splitlines()[-1][:200]}


# ---------------------------------------------------------------- pairing code (6 digits, 10 min, 5 attempts)
_code: dict = {}


def new_code(name: str = "") -> dict:
    import time
    c = f"{secrets.randbelow(1_000_000):06d}"
    with _lock:
        _code.clear()
        _code.update(code=c, name=(name or "Téléphone").strip()[:40], end=time.time() + 600, attempts=0)
    return {"code": c, "minutes": 10}


def use_code(data: Path, entered: str) -> str | None:
    """Device key if the code is right (it only works once); None otherwise (5 errors: the code is cancelled)."""
    import time
    entered = "".join(ch for ch in str(entered) if ch.isdigit())
    with _lock:
        if not _code or time.time() > _code["end"]:
            _code.clear()
            return None
        if not hmac.compare_digest(entered, _code["code"]):
            _code["attempts"] += 1
            if _code["attempts"] >= 5:
                _code.clear()
            return None
        name = _code["name"]
        _code.clear()
    return pair(data, name)


def code_in_progress() -> bool:
    import time
    with _lock:
        return bool(_code) and time.time() <= _code["end"]


# ---------------------------------------------------------------- paired devices
def _file(data: Path) -> Path:
    return Path(data) / "devices.json"


def _fingerprint(key: str) -> str:
    return hashlib.sha256(key.encode()).hexdigest()


def devices(data: Path) -> list[dict]:
    try:
        l = json.loads(_file(data).read_text(encoding="utf-8"))
        return [a for a in l if isinstance(a, dict) and a.get("id") and a.get("fingerprint")]
    except (OSError, ValueError):
        return []


def _write(data: Path, l: list[dict]) -> None:
    f = _file(data)
    f.with_suffix(".partiel").write_text(json.dumps(l, ensure_ascii=False, indent=1), encoding="utf-8")
    f.with_suffix(".partiel").replace(f)


def pair(data: Path, name: str) -> str:
    """New device key (shown only once, in the link); only its hash is kept."""
    key = secrets.token_urlsafe(32)
    with _lock:
        l = devices(data)
        l.append({"id": secrets.token_hex(4), "name": (name or "Téléphone").strip()[:40], "fingerprint": _fingerprint(key),
                  "created": datetime.now(timezone.utc).isoformat(timespec="seconds"), "seen": ""})
        _write(data, l)
    return key


def check(data: Path, key: str) -> bool:
    if not key:
        return False
    e = _fingerprint(key)
    with _lock:
        l = devices(data)
        for a in l:
            if hmac.compare_digest(a["fingerprint"], e):
                current_time = datetime.now(timezone.utc).isoformat(timespec="minutes")
                if a.get("seen") != current_time:
                    a["seen"] = current_time
                    _write(data, l)
                return True
    return False


def revoke(data: Path, ident: str) -> None:
    with _lock:
        _write(data, [a for a in devices(data) if a["id"] != ident])


def public(data: Path) -> list[dict]:
    return [{k: a.get(k, "") for k in ("id", "name", "created", "seen")} for a in devices(data)]
