"""Optional window components: persistent attempts, background progress and explicit restart."""
from __future__ import annotations

import hashlib
import json
import os
import threading
from datetime import datetime
from pathlib import Path

from . import python_env
from .security import redact

STATE = "window-components.json"
_guard = threading.RLock()
_workers = {}
_volatile = {}


def _key(code):
    return str(Path(code).resolve())


def _spec(code):
    code = Path(code)
    if not any((code / p).is_dir() for p in ("installeur/python-wheels", "wheels")):
        return None
    return hashlib.sha256((code / "requirements.lock.txt").read_bytes()).hexdigest(), (code / "VERSION").read_text(encoding="utf-8").strip()


def _read(code):
    try:
        value = json.loads((Path(code) / python_env.ENVS / STATE).read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else {}
    except (OSError, ValueError):
        return {}


def _write(code, digest, row):
    with _guard:
        data = _read(code)
        data[digest] = row
        file = Path(code) / python_env.ENVS / STATE
        file.parent.mkdir(parents=True, exist_ok=True)
        temporary = file.with_name(f"{file.name}.{os.getpid()}.{threading.get_ident()}.tmp")
        try:
            temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
            os.replace(temporary, file)
            _volatile.pop((_key(code), digest), None)
        finally:
            temporary.unlink(missing_ok=True)


def _note(code, text, log_path=None):
    try:
        file = Path(log_path) if log_path else Path(code) / "data/logs/interface.log"
        file.parent.mkdir(parents=True, exist_ok=True)
        with file.open("a", encoding="utf-8") as stream:
            stream.write(f"{datetime.now().isoformat(timespec='seconds')}  composants de la fenêtre : {redact(text)}\n")
    except OSError:
        pass  # An optional component, including its log, must never prevent the interface from opening.


def _candidate(code, row):
    value = row.get("candidate")
    if not isinstance(value, str):
        return None
    folder = Path(value)
    root = (Path(code) / python_env.ENVS).resolve()
    if (folder.is_symlink() or getattr(folder, "is_junction", lambda: False)()
            or not folder.resolve().is_relative_to(root) or folder.resolve() == root):
        return None
    return folder if python_env.python_in(folder).is_file() else None


def status(code):
    """Read-only, bounded public state: no interpreter paths, command lines or process IDs."""
    try:
        spec = _spec(code)
        if spec is None:
            return {"phase": "unavailable"}
        digest, version = spec
        active = python_env.pointer(code)
        if active.get("rollback") and active.get("rollback_lock_sha256") == digest:
            return {"phase": "rollback", "lock_sha256": digest}
        if (active.get("lock_sha256") == digest and active.get("current")
                and python_env.python_in(Path(active["current"])).is_file()):
            return {"phase": "active", "lock_sha256": digest}
        with _guard:
            row = _volatile.get((_key(code), digest)) or _read(code).get(digest) or {}
            worker = _workers.get(_key(code))
        row = row if isinstance(row, dict) else {}
        phase = row.get("phase", "pending")
        if phase == "ready" and _candidate(code, row) is None:
            phase = "failed"
            row = {**row, "reason": "L’environnement préparé n’est plus disponible."}
        if worker and phase == "pending":
            phase = "preparing"
        return {"phase": phase, "version": version, "lock_sha256": digest,
                "reason": redact(str(row.get("reason", "")))[:700], "step": str(row.get("step", ""))[:100],
                "completed": max(0, min(4, int(row.get("completed", 0)))), "total": 4,
                "attempts": int(row.get("attempts", 0)), "can_retry": phase == "failed",
                "can_restart": phase == "ready" and not worker}
    except Exception as error:
        return {"phase": "failed", "reason": redact(str(error))[:700], "can_retry": True,
                "can_restart": False, "completed": 0, "total": 4}


def begin(studio, controller, retry=False):
    return python_env.ensure_bundled_environment(studio.paths.code, retry=retry, store=studio.store,
                                                stop_event=controller.stop_request,
                                                log_path=studio.paths.logs / "interface.log")


def _failure(code, digest, row, error, log_path):
    reason = redact(str(error) or type(error).__name__)[:700]
    row = {**row, "phase": "failed", "reason": reason}
    with _guard:
        _volatile[(_key(code), digest)] = row
    try:
        _write(code, digest, row)
    except Exception:
        pass
    _note(code, "Composants de la fenêtre non installés : " + reason + " — Réessayer", log_path)


def queue_update(code):
    """An updater only queues components; it never prepares or activates an interpreter in its live session."""
    try:
        spec = _spec(code)
        if spec:
            digest, version = spec
            with python_env.environment_lock(code, blocking=False):
                if not _read(code).get(digest):
                    _write(code, digest, {"phase": "pending", "version": version, "attempts": 0})
    except python_env.EnvironmentBusy:
        pass
    except Exception as error:
        _note(code, "Préparation différée : " + redact(str(error)))


def ensure(code, *, retry=False, log_path=None, stop_event=None, store=None):
    """Return immediately. One automatic attempt per lock digest; retries require a user click."""
    code = Path(code)
    try:
        spec = _spec(code)
        if spec is None:
            return {"phase": "unavailable"}
        digest, version = spec
        current = status(code)
        if current["phase"] in ("active", "rollback", "ready") or (current["phase"] == "failed" and not retry):
            return current
        key = _key(code)
        with _guard:
            if key in _workers:
                return status(code)
            control = {"stop": stop_event or threading.Event()}
            worker = threading.Thread(target=_prepare, args=(code, digest, version, retry, log_path, control, store),
                                      name="window-components", daemon=True)
            control["thread"] = worker
            _workers[key] = control
            worker.start()
        return status(code)
    except Exception as error:
        if 'key' in locals():
            with _guard:
                _workers.pop(key, None)
        if 'digest' in locals():
            _failure(code, digest, {}, error, log_path)
        else:
            _note(code, "Composants de la fenêtre non installés : " + redact(str(error)), log_path)
        return {"phase": "failed", "reason": redact(str(error))[:700], "can_retry": True}


def _prepare(code, digest, version, retry, log_path, control, store):
    row = {}
    try:
        with python_env.environment_lock(code, blocking=False):
            saved = _read(code).get(digest)
            row = saved if isinstance(saved, dict) else {}
            if row.get("phase") in ("failed", "ready") and not retry:
                return
            if row.get("phase") == "preparing" and not retry:
                raise RuntimeError("La préparation précédente a été interrompue. Clique sur Réessayer.")
            # Persist the attempt BEFORE invoking any preparation, so a crash cannot cause an automatic loop.
            row = {"phase": "preparing", "version": version, "attempts": int(row.get("attempts", 0)) + 1,
                   "completed": 0, "step": "Démarrage", "pid": os.getpid()}
            _write(code, digest, row)
            _note(code, "préparation en arrière-plan ; l’environnement en service reste utilisé", log_path)
            def progress(step, completed, total):
                row.update(step=step, completed=completed)
                _write(code, digest, row)
                _note(code, f"{step} ({completed}/{total})", log_path)
            def run(command, cwd):
                if control["stop"].is_set():
                    raise RuntimeError("Préparation interrompue par l’arrêt du studio.")
                if store is None:
                    return python_env._run(command, cwd)
                from .orchestrator.processes import run_process
                class PreparationStore:
                    def db(self):
                        return store.db()
                    def cancel_requested(self, task_id):
                        return control["stop"].is_set()
                result = run_process(PreparationStore(), "window-components", [str(c) for c in command], Path(cwd), 900)
                if result.status != "completed":
                    raise RuntimeError("Préparation interrompue : " + result.status)
                import subprocess
                return subprocess.CompletedProcess(command, result.returncode, result.stdout, result.stderr)
            new = python_env.prepare(code, version, run=run, progress=progress)
            if control["stop"].is_set():
                raise RuntimeError("Préparation interrompue par l’arrêt du studio.")
            if _spec(code)[0] != digest:
                raise RuntimeError("Le verrou des composants a changé pendant la préparation.")
            row.update(phase="ready", candidate=str(new), completed=4, step="prêt", reason="")
            _write(code, digest, row)
            _note(code, "composants prêts — Redémarrer pour passer à la fenêtre native", log_path)
    except python_env.EnvironmentBusy:
        pass  # Another instance owns preparation; do not wait or overwrite its state.
    except Exception as error:
        _failure(code, digest, row, error, log_path)
    finally:
        with _guard:
            _workers.pop(_key(code), None)


def activate_ready(code):
    """Only the explicit restart action may change active.json; no preparation is run here."""
    code = Path(code)
    with python_env.environment_lock(code, blocking=False):
        digest, _ = _spec(code)
        row = _read(code).get(digest) or {}
        candidate = _candidate(code, row)
        if row.get("phase") != "ready" or candidate is None:
            raise ValueError("Les composants ne sont pas prêts. Réessaie quand la préparation est terminée.")
        active = python_env.pointer(code)
        previous = Path(active["current"]) if active.get("current") and python_env.python_in(Path(active["current"])).is_file() else Path(os.sys.prefix)
        return python_env.activate(code, candidate, current=previous)


def stop_background(code):
    """Cancel only owned preparation processes before the studio closes its task store."""
    with _guard:
        control = _workers.get(_key(code))
    if control:
        control["stop"].set()
        control["thread"].join(timeout=15)
