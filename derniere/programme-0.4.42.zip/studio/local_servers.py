"""Serveurs locaux lancés sur clic ; seuls nos processus peuvent être arrêtés."""
import shutil
import subprocess
import sys
import threading
from pathlib import Path

from . import local_discovery
from .connectors.base import NO_WINDOW

_lock = threading.RLock()
_owned = {}


def executable(engine):
    if engine == "ollama":
        from .local_models import local_runner_executable
        return local_runner_executable()
    row = next((r for r in local_discovery.ENGINES if r[0] == engine), None)
    return next((p for name in row[4] if (p := shutil.which(name))), "") if row else ""


def online(engine):
    row = next((r for r in local_discovery.ENGINES if r[0] == engine), None)
    return bool(row and local_discovery._probe(row[2]))


def state():
    detected = local_discovery.installed()
    with _lock:
        return {"engines": [{"id": key, "name": name, "launchable": bool(executable(key)),
                             "online": online(key), "owned": key in _owned and _owned[key].poll() is None}
                            for key, name, *_ in local_discovery.ENGINES if key in detected or key in _owned]}


def start(engine):
    with _lock:
        if engine not in {r[0] for r in local_discovery.ENGINES}:
            raise ValueError("Choisis un moteur détecté sur ce PC.")
        if online(engine):
            return {"ok": True, "message": "Serveur déjà actif ; il reste sous le contrôle de son propriétaire."}
        if engine in _owned and _owned[engine].poll() is None:
            return {"ok": True, "message": "Le serveur local est en cours de démarrage."}
        exe = executable(engine)
        if not exe:
            raise ValueError("Commande de lancement introuvable. Ouvre ce moteur sur le PC et active son serveur local.")
        args = [exe, "serve"] if engine == "ollama" else [exe, "server", "start"] if engine == "lmstudio" else [exe]
        options = {"creationflags": 0x08000000} if sys.platform == "win32" else {"start_new_session": True}
        process = subprocess.Popen(args, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                                   stderr=subprocess.DEVNULL, close_fds=True, **options)
        if engine == "lmstudio":
            try:
                if process.wait(timeout=20) != 0:
                    raise ValueError("Le serveur LM Studio n'a pas démarré. Vérifie son application sur le PC.")
            except subprocess.TimeoutExpired:
                process.terminate()
                raise ValueError("LM Studio ne confirme pas le démarrage de son serveur.") from None
        if process.poll() is None:
            _owned[engine] = process
        with local_discovery._lock:
            local_discovery._cache.clear()
        return {"ok": True, "message": "Démarrage demandé. Attends que le serveur réponde, puis reprends ton travail."}


def stop(engine):
    with _lock:
        process = _owned.pop(engine, None)
    if process is None:
        raise ValueError("Ce serveur n'a pas été lancé par le studio.")
    if process.poll() is None:
        from .desktop import close_process
        close_process(process)
    return {"ok": True, "message": "Serveur lancé par le studio arrêté."}


def stop_owned():
    for engine in list(_owned):
        try:
            stop(engine)
        except (OSError, ValueError, subprocess.SubprocessError):
            pass
