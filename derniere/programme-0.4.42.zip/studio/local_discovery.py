"""Passive, loopback-only local engine discovery; connections require a separate click."""
from __future__ import annotations

import concurrent.futures
import json
import os
import re
import secrets
import shutil
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
from pathlib import Path
from urllib.parse import urlparse

ENGINES = (
    ("ollama", "Ollama", 11434, ("Ollama", ".ollama"), ("ollama",)),
    ("lmstudio", "LM Studio", 1234, ("LM Studio", ".lmstudio"), ("lms",)),
    ("llamacpp", "llama.cpp", 8080, ("llama.cpp",), ("llama-server",)),
    ("jan", "Jan", 1337, ("Jan", "jan"), ("jan",)),
    ("gpt4all", "GPT4All", 4891, ("GPT4All", "nomic.ai/GPT4All"), ("gpt4all",)),
    ("localai", "LocalAI", 8080, ("LocalAI", "localai"), ("local-ai",)),
    ("koboldcpp", "KoboldCpp", 5001, ("KoboldCpp", "koboldcpp"), ("koboldcpp",)),
    ("tabbyapi", "TabbyAPI", 5000, ("TabbyAPI", "tabbyAPI"), ("tabbyAPI",)),
    ("vllm", "vLLM", 8000, ("vllm",), ("vllm",)),
    ("lemonade", "Lemonade", 8000, ("Lemonade", "lemonade_server"), ("lemonade-server",)),
    ("foundry", "Foundry Local", 5272, ("Microsoft/FoundryLocal", ".foundry", "FoundryLocal"), ("foundry",)),
)
_cache = {}
_lock = threading.Lock()


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise urllib.error.URLError("Redirection refusée pendant la détection locale.")


def local_url(url):
    try:
        parsed = urlparse(url)
        return (parsed.scheme == "http" and parsed.hostname == "127.0.0.1" and parsed.username is None
                and parsed.password is None and parsed.port is not None and not parsed.query and not parsed.fragment)
    except ValueError:
        return False


def request(url):
    if not local_url(url):
        raise ValueError("Adresse de détection locale refusée.")
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect())
    with opener.open(url, timeout=.35) as response:
        raw = response.read(1024 * 1024 + 1)
        if len(raw) > 1024 * 1024:
            raise ValueError("Inventaire local trop volumineux.")
        data = json.loads(raw)
        return data, str(response.headers.get("Server", ""))


def installed(home=None):
    home = Path(home or Path.home())
    roots = [home, home / ".local/share", Path("/Applications"), home / "Applications", Path("/opt")]
    for key in ("LOCALAPPDATA", "APPDATA", "ProgramFiles", "ProgramFiles(x86)"):
        if os.environ.get(key):
            base = Path(os.environ[key])
            roots.extend((base, base / "Programs"))
    result = set()
    for key, name, port, folders, executables in ENGINES:
        if any(shutil.which(exe) for exe in executables) or any(
                (root / folder).is_dir() or (root / (folder + ".app")).is_dir() for root in roots for folder in folders):
            result.add(key)
    return result


def listening_ports():
    """Read local listener metadata, never start an engine or scan another interface."""
    try:
        if sys.platform == "linux":
            lines = Path("/proc/net/tcp").read_text().splitlines()[1:]
            return {int(p[1].split(":")[1], 16) for line in lines if len(p := line.split()) > 3
                    and p[1].startswith("0100007F:") and p[3] == "0A"}
        from .connectors.base import NO_WINDOW
        command = ["netstat", "-an", "-p", "TCP"] if sys.platform == "win32" else ["lsof", "-nP", "-iTCP@127.0.0.1", "-sTCP:LISTEN"]
        result = subprocess.run(command, capture_output=True, timeout=2, **NO_WINDOW)
        output = (result.stdout or b"").decode("oem" if sys.platform == "win32" else "utf-8", errors="replace")
        return {int(p) for p in re.findall(r"127\.0\.0\.1:(\d+)\s+", output)
                if 1024 <= int(p) <= 65535}
    except (OSError, ValueError, subprocess.SubprocessError):
        return set()


def _probe(port):
    base = f"http://127.0.0.1:{port}"
    for suffix in ("/v1/models", "/api/v1/models"):
        try:
            payload, server = request(base + suffix)
            if not isinstance(payload, dict) or not isinstance(payload.get("data", payload.get("models")), list):
                continue
            rows = payload.get("data", payload.get("models", []))
            models = [r.get("id") or r.get("key") or r.get("name") for r in rows if isinstance(r, dict)]
            evidence = (server + " " + str(payload.get("provider", "")) + " "
                        + " ".join(str(r.get("owned_by", "")) for r in rows if isinstance(r, dict))).lower()
            key = next((key for key, name, _, _, _ in ENGINES if key in evidence or name.lower() in evidence), "")
            if port == 11434:
                try:
                    version, _ = request(base + "/api/version")
                    if isinstance(version, dict) and isinstance(version.get("version"), str):
                        key = "ollama"
                except (OSError, ValueError):
                    pass
            if port == 1234 and not key:
                try:
                    info, _ = request(base + "/api/v1/models")
                    if isinstance(info, dict) and isinstance(info.get("models"), list):
                        key = "lmstudio"
                except (OSError, ValueError):
                    pass
            # An ambiguous OpenAI endpoint is shown honestly, rather than guessing an engine from its port.
            name = next((name for ident, name, *_ in ENGINES if ident == key), "Serveur compatible OpenAI")
            return {"id": f"{key or 'compatible'}:{port}", "engine": key, "name": name, "state": "running",
                    "url": base + suffix.removesuffix("/models"), "models": sorted({m for m in models if isinstance(m, str)}),
                    "provider": key if key in ("ollama", "lmstudio") else "other"}
        except (OSError, ValueError):
            pass
    return None


def scan(data, force=False):
    key = str(data)
    with _lock:
        old = _cache.get(key)
        if old and not force and time.monotonic() - old[0] < 60:
            return old[1]
    found = installed()
    ports = {r[2] for r in ENGINES} | set(sorted(listening_ports())[:128])
    with concurrent.futures.ThreadPoolExecutor(max_workers=12) as pool:
        running = [row for row in pool.map(_probe, sorted(ports)) if row]
    for row in running:
        if not row["engine"]:
            port = urlparse(row["url"]).port
            matches = [r for r in ENGINES if r[0] in found and r[2] == port]
            if len(matches) == 1:
                ident, name, *_ = matches[0]
                row.update(engine=ident, name=name, provider=ident if ident in ("ollama", "lmstudio") else "other")
    identified = {r["engine"] for r in running}
    for ident, name, port, *_ in ENGINES:
        if ident in found and ident not in identified:
            running.append({"id": ident + ":installed", "engine": ident, "name": name, "state": "stopped",
                            "url": f"http://127.0.0.1:{port}/v1", "models": [],
                            "provider": ident if ident in ("ollama", "lmstudio") else "other"})
    with _lock:
        _cache[key] = (time.monotonic(), running)
    return running


def connect(data, ident):
    """Only a row offered by discovery may be connected; no probing or automatic launch here."""
    from . import ai
    row = next((r for r in scan(data) if r["id"] == ident), None)
    if not row or not local_url(row["url"]):
        raise ValueError("Résultat de détection expiré : relance la recherche locale.")
    with ai._lock:
        document = ai.read_file(data)
        existing = next((c for c in document["connections"] if ai._base(c) == row["url"]), None)
        if existing:
            return {"id": existing["id"]}
        connection = {"id": row["provider"] + "-" + secrets.token_hex(3), "provider": row["provider"],
                      "url": row["url"], "model": next(iter(row["models"]), ""), "key": ""}
        document["connections"].append(connection)
        ai._write(data, document)
    return {"id": connection["id"]}
