"""Codex connector — ``codex exec`` (official non-interactive mode).

Choices (docs: https://learn.chatgpt.com/docs/non-interactive-mode):
- ``codex exec --json``: JSON Lines events (``thread.started``,
  ``turn.completed`` with ``usage``, ``turn.failed``, ``item.completed``, ``error``);
- ``--sandbox workspace-write`` (``--full-auto`` is no longer supported);
- ``-o <file>``: last message; ``--skip-git-repo-check`` for a non-Git workspace;
- the working folder is set by the process (no unverified option);
- authentication: the one already saved by Codex (ChatGPT subscription);
  no API key is injected by the studio.
- resume: Codex picks the conversation id itself; the studio finds it in
  ``~/.codex/sessions/…/rollout-*.jsonl`` (``session_meta``: id, folder, time) and, after Stop then Reprendre, reruns
  ``codex exec … resume <id> "<instruction>"``. Resume failure → normal fresh start.
``codex mcp-server`` was removed by OpenAI: it is not used.
The ``openai-codex`` Python SDK (app-server) remains a documented option (ADR-0005).
"""
from __future__ import annotations

from ..migrations import compatibility as json
import os
import re
import subprocess
import time
from ..migrations.compatibility import TechnicalPath as Path

from ..orchestrator.processes import run_process
from .base import SUMMARY_MAX, RESUME_INSTRUCTION, NO_WINDOW, ExecResult, Mission, conversation_sheet, find_exe, effective_level, jot, live_limits

WIN_CANDIDATES = [str(Path.home() / "AppData/Local/OpenAI/Codex/bin/*/codex.exe"),
                  str(Path.home() / "AppData/Roaming/npm/codex.cmd")]



def _agent_env(runner) -> dict:
    """The PC's environment without its secrets (names kept on request: [tools] agent_env_keep)."""
    from ..security import agent_env
    return agent_env(runner.cfg["tools"].get("agent_env_keep", ()) if hasattr(runner, "cfg") else ())


class SecondaryCliExecutor:
    name = "codex"

    def __init__(self, exe: str = "codex", sandbox: str = "workspace-write", timeout_s: float = 900,
                 ephemeral: bool = False, output_schema: Path | None = None):
        if sandbox == "danger-full-access":
            raise ValueError("Le studio n'utilise pas danger-full-access.")
        self.exe = find_exe(exe, WIN_CANDIDATES)
        self.sandbox, self.timeout_s, self.ephemeral, self.output_schema = sandbox, timeout_s, ephemeral, output_schema

    def available(self) -> tuple[bool, str]:
        if not self.exe:
            return False, "Codex CLI introuvable."
        try:
            out = subprocess.run([self.exe, "--version"], capture_output=True, text=True, errors="replace", timeout=30, **NO_WINDOW)
            return out.returncode == 0, f"{(out.stdout or out.stderr).strip()[:80]} ({self.exe})"
        except (OSError, subprocess.TimeoutExpired) as e:
            return False, f"Codex ne répond pas : {type(e).__name__}"

    # Codex: minimal | low | medium | high | xhigh (depending on the model). « max » doesn't exist in Codex: we request
    # [choix] codex_effort_max (default « high », the highest level accepted by all Codex models).
    effort_max = "high"

    def secondary_cli_level(self, level: str, model: str = "") -> str:
        from ..ai_effort import capabilities
        if model and level in {v for v, _ in capabilities("codex", model)["options"]}:
            return level
        return {"none": "none", "minimal": "minimal", "low": "low", "medium": "medium", "high": "high", "xhigh": "xhigh", "max": self.effort_max}.get(level, "")

    def knows_resume(self) -> bool:
        """``codex exec resume``: only if the installed version's help mentions it."""
        if getattr(self, "_resume", None) is None:
            try:
                help_text = subprocess.run([self.exe, "exec", "--help"], capture_output=True, text=True, timeout=30,
                                      encoding="utf-8", errors="replace", **NO_WINDOW).stdout if self.exe else ""
            except (OSError, subprocess.TimeoutExpired):
                help_text = ""
            self._resume = bool(re.search(r"^\s+resume\b", help_text, re.M))
        return self._resume

    @staticmethod
    def models(home: Path | None = None) -> list[str]:
        """Models offered by Codex for this account: its own cache (~/.codex/models_cache.json), plus the one set in
        its config.toml. Empty = only « Auto » (Codex picks its default model)."""
        base = Path(os.environ.get("CODEX_HOME") or Path(home or Path.home()) / ".codex")
        out: list[str] = []
        try:
            data = json.raw_loads((base / "models_cache.json").read_text(encoding="utf-8"))
            items = data.get("models") if isinstance(data, dict) else data
            for m in items or []:
                slug = m.get("slug") or m.get("id") or m.get("model") if isinstance(m, dict) else m
                hidden = isinstance(m, dict) and str(m.get("visibility", "")).lower() in ("hide", "hidden", "none")
                if isinstance(slug, str) and re.fullmatch(r"[\w.:-]{2,60}", slug) and not hidden and slug not in out:
                    out.append(slug)
        except (OSError, ValueError, AttributeError):
            pass
        try:
            m = re.search(r'(?m)^\s*model\s*=\s*"([\w.:-]{2,60})"', (base / "config.toml").read_text(encoding="utf-8"))
            if m and m.group(1) not in out:
                out.insert(0, m.group(1))
        except OSError:
            pass
        return out

    @staticmethod
    def default_model(home: Path | None = None) -> str:
        """The model set in Codex's own config.toml (what « Auto » uses), or "" if Codex chooses."""
        base = Path(os.environ.get("CODEX_HOME") or Path(home or Path.home()) / ".codex")
        try:
            m = re.search(r'(?m)^\s*model\s*=\s*"([\w.:-]{2,60})"', (base / "config.toml").read_text(encoding="utf-8"))
            return m.group(1) if m else ""
        except OSError:
            return ""

    @staticmethod
    def sessions(home: Path | None = None) -> Path:
        return Path(os.environ.get("CODEX_HOME") or Path(home or Path.home()) / ".codex") / "sessions"

    @classmethod
    def find_session(cls, folder: Path, since: float, home: Path | None = None) -> str:
        """Codex conversation started in ``dossier`` since ``depuis`` (the oldest: that is the mission's)."""
        target = os.path.normcase(os.path.abspath(str(folder)))
        matches = []
        for f in cls.sessions(home).glob("*/*/*/rollout-*.jsonl"):
            try:
                if f.stat().st_mtime < since - 60:
                    continue
                with f.open(encoding="utf-8", errors="replace") as h:
                    meta = (json.raw_loads(h.readline() or "{}").get("payload") or {})
            except (OSError, ValueError, AttributeError):
                continue
            sid, cwd = str(meta.get("id") or ""), str(meta.get("cwd") or "")
            if not sid or os.path.normcase(os.path.abspath(cwd)) != target:
                continue
            try:
                from datetime import datetime
                t = datetime.fromisoformat(str(meta.get("timestamp", "")).replace("Z", "+00:00")).timestamp()
            except ValueError:
                t = f.stat().st_mtime
            if t >= since - 5:
                matches.append((t, sid))
        return min(matches)[1] if matches else ""

    def build_command(self, last_msg: Path, model: str = "", effort: str = "", level: str = "", resumption: str = "",
                      folders: list[str] | None = None, mcp: list[str] | None = None) -> list[str]:
        cmd = [self.exe or "codex", "exec", "--json", "--sandbox", self.sandbox, "--skip-git-repo-check",
               "-o", str(last_msg)] + list(mcp or [])
        for d in folders or []:                  # e.g. Taches\<tâche>\captures: the agent can save its evidence there
            cmd += ["--add-dir", d]
        if model:
            cmd += ["--model", model]
        n = self.secondary_cli_level(effective_level(level, effort), model)
        if level and level != "auto":
            from ..ai_effort import capabilities
            if level not in {v for v, _ in capabilities("codex", model)["options"]}:
                raise ValueError("Effort indisponible pour ce modèle : choisis un niveau proposé ou Auto.")
            n = level
        if n:                                     # Codex reasoning depth
            cmd += ["-c", f'model_reasoning_effort="{n}"']
        if self.ephemeral:
            cmd.append("--ephemeral")
        if self.output_schema:
            cmd += ["--output-schema", str(self.output_schema)]
        if resumption:              # same conversation: the mission is already in its history
            return cmd + ["resume", resumption, RESUME_INSTRUCTION.format(ref="")]
        cmd.append("-")          # the mission is read from standard input
        return cmd

    def execute(self, mission: Mission, workdir: Path, runner) -> ExecResult:
        ok, info = self.available()
        if not ok:
            return ExecResult(False, info, self.name, error=info)
        dd = getattr(runner, "details_dir", None)
        last = (dd(mission.task_id) if dd and mission.task_id else workdir.parent) / f"secondary-last-message-{mission.try_count}.txt"
        sheet = None if self.ephemeral else conversation_sheet(runner, mission, "secondary", "json")
        resumption, info = "", {}
        mcp, env = self._mcp(mission, runner)
        activity, hard = live_limits(runner, mission, "codex", "", workdir)
        if sheet is not None and sheet.exists():          # the mission had been stopped: find its conversation
            try:
                info = json.loads(sheet.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                info = {}
            if info.get("begin") and self.knows_resume():
                resumption = info.get("id") or self.find_session(workdir, float(info["begin"]))
        if resumption:
            sheet.write_text(json.dumps({**info, "id": resumption}), encoding="utf-8")
            jot(runner, mission.task_id, f"{mission.role} reprend sa conversation Codex là où il s'était arrêté")
            res = run_process(runner.store, mission.task_id, self.build_command(last, mission.model, mission.effort,
                              mission.level, resumption, mission.folders, mcp), workdir, self.timeout_s, activity=activity, hard_s=hard, env=env or _agent_env(runner))
            if res.status == "completed" and '"thread.started"' not in (res.stdout or ""):
                jot(runner, mission.task_id, "Reprise Codex impossible : nouveau départ de la mission")
                resumption = ""                                 # conversation not found: normal start
        if not resumption:
            if sheet is not None:
                sheet.write_text(json.dumps({"begin": time.time()}), encoding="utf-8")
            res = run_process(runner.store, mission.task_id, self.build_command(last, mission.model, mission.effort,
                              mission.level, folders=mission.folders, mcp=mcp), workdir, self.timeout_s, stdin_text=mission.prompt(),
                              activity=activity, hard_s=hard, env=env or _agent_env(runner))
            if mcp and res.status == "completed" and res.returncode not in (0, None) and re.search(r"mcp_servers|project_doc_fallback|unknown (field|key)", (res.stderr or "") + (res.stdout or "")[:2000]):
                jot(runner, mission.task_id, "Codex refuse les réglages de lancement (version ancienne ?) : relance sans eux")
                res = run_process(runner.store, mission.task_id, self.build_command(last, mission.model, mission.effort,
                                  mission.level, folders=mission.folders), workdir, self.timeout_s, stdin_text=mission.prompt(),
                                  activity=activity, hard_s=hard, env=_agent_env(runner))   # no MCP here: no MCP key
        if sheet is not None and res.status == "completed":    # conversation run to completion: nothing left to resume
            sheet.unlink(missing_ok=True)
        final = last.read_text(encoding="utf-8", errors="replace") if last.exists() else ""
        from ..command_proofs import append, secondary_events
        if hasattr(runner, "details_dir"):
            for command in secondary_events(res.stdout or ""):
                append(runner.details_dir(mission.task_id) / "commands.log", actor=mission.execution_actor,
                       source="tool_sandbox", **command)
        return self.parse(res.stdout, final, res.returncode, res.status)

    @staticmethod
    def _mcp(mission: Mission, runner) -> tuple[list[str], dict | None]:
        """Project MCP servers (Extensions) + read-only shared memory, for this run only."""
        try:
            import os
            from ..library import env_mcp, installed_mcp
            from ..mcp_client import options_secondary_cli, memory_server
            data = runner.paths.data
            all_items = installed_mcp(data)
            chosen = {n: all_items[n] for n in all_items if mission.mcp is None or n in mission.mcp}
            opts, _ = options_secondary_cli(chosen, memory_server())
            # project without AGENTS.md: Codex reads its CLAUDE.md (a single instructions file for all models)
            return ['-c', 'project_doc_fallback_filenames=["CLAUDE.md"]'] + opts, {**_agent_env(runner), **env_mcp(data, chosen)}
        except Exception:                             # noqa: BLE001 — outside the studio (tests): nothing added
            return [], None

    def parse(self, jsonl: str, final: str, code: int | None, status: str) -> ExecResult:
        if status != "completed":
            return ExecResult(False, f"Codex : {status}", self.name, error=status)
        thread, usage, errors, messages = "", {}, [], []
        for line in jsonl.splitlines():
            try:
                ev = json.raw_loads(line)
            except json.JSONDecodeError:
                continue
            t = ev.get("type", "")
            if t == "thread.started":
                thread = ev.get("thread_id", "")
            elif t == "turn.completed":
                usage = ev.get("usage", {}) or {}
            elif t in ("turn.failed", "error"):
                errors.append(json.dumps(ev.get("error", ev), ensure_ascii=False)[:500])
            elif t == "item.completed":
                item = ev.get("item", {}) or {}
                if item.get("type") in ("agent_message", "assistant_message") and item.get("text"):
                    messages.append(item["text"])
        ok = code == 0 and not errors
        return ExecResult(ok=ok, summary=(final or (messages[-1] if messages else ""))[:SUMMARY_MAX], executor=self.name,
                          session_id=thread, raw={"usage": usage}, error="; ".join(errors)[:2000])
