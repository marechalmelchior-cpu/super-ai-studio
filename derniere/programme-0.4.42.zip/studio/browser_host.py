"""Repli Windows : simple fenêtre d'application, sans cadre ni changement de parent."""
import ctypes
from ctypes import wintypes
import subprocess
import time


def run(url, data, controller, candidates, options):
    from . import desktop, window_handoff
    before = desktop.browser_handles()
    for exe in candidates:
        try:
            process = subprocess.Popen([exe, f'--app={url}', *options], stdin=subprocess.DEVNULL,
                                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, **desktop.NO_WINDOW)
            break
        except OSError:
            continue
    else:
        raise RuntimeError('Aucun navigateur compatible ne peut ouvrir la fenêtre du studio.')
    user = ctypes.windll.user32
    user.IsWindow.argtypes = [wintypes.HWND]
    user.PostMessageW.argtypes = [wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
    controller.browser_hosted = True
    controller.window_opened()
    controller.focus = lambda: desktop.focus_browser(process.pid if process.poll() is None else None, data)
    handle = None
    deadline = time.monotonic() + 15
    try:
        while True:
            if not handle and time.monotonic() < deadline:
                handle = desktop.owned_browser_handle(before, process.pid, data)
            stopping = controller.stop_request.is_set() or controller.window_close_request.is_set()
            waiting = window_handoff.waiting(controller) if stopping else False
            if waiting and getattr(controller, 'handoff_failed', False) and not getattr(controller, 'handoff_error_shown', False):
                controller.handoff_error_shown = True
                from .launcher import _message
                _message('La fenêtre native n’a pas confirmé son affichage après 60 secondes. Le repli reste ouvert. Ferme-le puis relance le raccourci.')
            if stopping and not waiting:
                if handle and user.IsWindow(wintypes.HWND(handle)):
                    user.PostMessageW(wintypes.HWND(handle), 0x0010, 0, 0)
                break
            if handle and not user.IsWindow(wintypes.HWND(handle)):
                controller.leave()
                for _ in range(50):
                    if controller.stop_request.is_set():
                        break
                    time.sleep(.2)
                controller.stop_when_idle = True
                break
            if not handle and controller.left_at is not None and time.monotonic() - controller.left_at >= 10:
                controller.stop_when_idle = True
                break
            if not handle and controller.absence_delay_s is not None and time.monotonic() - controller.last_seen > controller.absence_delay_s:
                break
            time.sleep(.1)
    finally:
        controller.browser_hosted = False
        controller.window_closed()
