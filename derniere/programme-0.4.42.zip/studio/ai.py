"""Connections to AIs: subscription tools, API key (cloud providers) or local AI (e.g. Ollama, LM Studio).

All key-based or local AIs go through the same "chat completions" interface (OpenAI format, which all these
providers accept). Keys are encrypted by Windows (DPAPI, current account) in data/connexions.json, never
displayed, never written to a log or a prompt. Nothing is sent anywhere but to the chosen provider.
"""
from __future__ import annotations

import base64
from .migrations import compatibility as json
import re
import secrets
import sys
import threading
import urllib.error
import urllib.request
from .migrations.compatibility import TechnicalPath as Path

PROVIDERS: dict[str, dict] = {
    "openai": {"name": "OpenAI (GPT, par clé API)", "url": "https://api.openai.com/v1", "key": True, "advice": "gpt-4.1"},
    "anthropic": {"name": "Anthropic (Claude)", "url": "https://api.anthropic.com/v1", "key": True, "advice": "claude-sonnet"},
    "gemini": {"name": "Google Gemini", "url": "https://generativelanguage.googleapis.com/v1beta/openai", "key": True, "advice": "gemini-2.5-flash"},
    "mistral": {"name": "Mistral", "url": "https://api.mistral.ai/v1", "key": True, "advice": "mistral-large-latest"},
    "openrouter": {"name": "OpenRouter (beaucoup de modèles, une clé)", "url": "https://openrouter.ai/api/v1", "key": True, "advice": ""},
    "deepseek": {"name": "DeepSeek", "url": "https://api.deepseek.com/v1", "key": True, "advice": "deepseek-chat"},
    "groq": {"name": "Groq", "url": "https://api.groq.com/openai/v1", "key": True, "advice": ""},
    "xai": {"name": "xAI (Grok)", "url": "https://api.x.ai/v1", "key": True, "advice": "grok"},
    "moonshot": {"name": "Moonshot (Kimi)", "url": "https://api.moonshot.ai/v1", "key": True, "advice": "kimi"},
    "other": {"name": "Autre IA (compatible OpenAI : adresse + clé)", "url": "", "key": False, "advice": ""},
    "elevenlabs": {"name": "ElevenLabs (voix)", "url": "https://api.elevenlabs.io/v1", "key": True, "advice": "", "seulement": "voice"},
    "ollama": {"name": "Ollama (IA locale)", "url": "http://127.0.0.1:11434/v1", "key": False, "advice": "qwen2.5-coder"},
    "lmstudio": {"name": "LM Studio (IA locale)", "url": "http://127.0.0.1:1234/v1", "key": False, "advice": ""},
}
_lock = threading.Lock()


class AIError(RuntimeError):
    pass


class LocalServerUnavailable(AIError):
    """Le serveur local exige une action explicite de l'utilisateur."""


# ------------------------------------------------------------------ storage (encrypted keys)
def _file(data: Path) -> Path:
    return Path(data) / "connections.json"


def _encrypt(key: str) -> str:
    from .vault import encrypt
    return encrypt(key)


def _decrypt(v: str) -> str:
    from .vault import decrypt
    return decrypt(v)


def read_file(data: Path) -> dict:
    try:
        d = json.loads(_file(data).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        d = {}
    d.setdefault("connections", [])
    d.setdefault("supervisor", "")
    d.setdefault("agents", "")
    return d


def _write(data: Path, d: dict) -> None:
    f = _file(data)
    f.parent.mkdir(parents=True, exist_ok=True)
    t = f.with_suffix(".partiel")
    t.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
    t.replace(f)


def public(data: Path) -> dict:
    """For the UI: never the key, only « clé enregistrée »."""
    d = read_file(data)
    from .security import redact
    return {"connections": [{"id": c["id"], "provider": c["provider"], "name": PROVIDERS.get(c["provider"], {}).get("name", c["provider"]),
                            "model": c.get("model", ""), "url": redact(c.get("url", "")), "key": bool(c.get("key"))} for c in d["connections"]],
            "supervisor": d["supervisor"], "agents": d["agents"],
            "providers": [{"id": k, **{x: v[x] for x in ("name", "key", "advice")}} for k, v in PROVIDERS.items()]}


def safe_address(url: str) -> bool:
    """https to any host, or http only to this PC (127.0.0.1, localhost, ::1)."""
    from urllib.parse import urlparse
    try:
        u = urlparse(url)
    except ValueError:
        return False
    from .security import contains_secret
    if u.username or u.password or contains_secret(url):
        return False
    if u.scheme == "https" and u.hostname:
        return True
    return u.scheme == "http" and u.hostname in ("127.0.0.1", "localhost", "::1")


def add_item(data: Path, provider: str, key: str = "", model: str = "", url: str = "") -> dict:
    if provider not in PROVIDERS:
        raise ValueError("Fournisseur inconnu.")
    f = PROVIDERS[provider]
    key = (key or "").strip()
    if f["key"] and not key:
        raise ValueError("Colle ta clé API.")
    if provider == "other" and not (url or "").strip():
        raise ValueError("Indique l'adresse de l'IA (ex. https://api.exemple.com/v1).")
    if url and not safe_address(url):
        raise ValueError("Adresse refusée : https, ou une IA locale sur 127.0.0.1.")
    c = {"id": f"{provider}-{secrets.token_hex(3)}", "provider": provider, "model": model.strip(),
         "url": url.strip(), "key": _encrypt(key) if key else ""}
    model_list = list_models(c)                         # check the key before saving (clear error otherwise)
    if not c["model"] and model_list:
        c["model"] = choose_advice(provider, model_list)
    with _lock:
        d = read_file(data)
        d["connections"].append(c)
        if not f.get("seulement"):                          # a voice-only AI never becomes the Supervisor
            d["supervisor"] = d["supervisor"] or c["id"]
            d["agents"] = d["agents"] or c["id"]
        _write(data, d)
    return {"id": c["id"], "models": model_list, "model": c["model"]}


def modify(data: Path, ident: str, **field_values) -> None:
    with _lock:
        d = read_file(data)
        for k in ("supervisor", "agents"):
            if k in field_values:
                v = str(field_values[k] or "")
                if v and v not in ("claude-code", "codex") and v not in {c["id"] for c in d["connections"]}:
                    raise ValueError("Connexion inconnue.")
                d[k] = v
        if ident and "model" in field_values:
            for c in d["connections"]:
                if c["id"] == ident:
                    c["model"] = str(field_values["model"] or "")
        _write(data, d)


def removed(data: Path, ident: str) -> None:
    with _lock:
        d = read_file(data)
        d["connections"] = [c for c in d["connections"] if c["id"] != ident]
        for k in ("supervisor", "agents"):
            if d[k] == ident:
                d[k] = d["connections"][0]["id"] if d["connections"] else ""
        _write(data, d)


def connection(data: Path, ident: str) -> dict | None:
    return next((c for c in read_file(data)["connections"] if c["id"] == ident), None)


# ------------------------------------------------------------------ HTTP calls (chat completions format)
def _base(c: dict) -> str:
    return (c.get("url") or PROVIDERS[c["provider"]]["url"]).rstrip("/")


def _headers(c: dict) -> dict:
    h = {"Content-Type": "application/json", "User-Agent": "SuperAIStudio"}
    key = _decrypt(c.get("key", ""))
    if key:
        h["Authorization"] = f"Bearer {key}"
        if c["provider"] == "anthropic":
            h["x-api-key"] = key
            h["anthropic-version"] = "2023-06-01"
        elif c["provider"] == "elevenlabs":
            h["xi-api-key"] = key
    if c["provider"] == "anthropic":
        h["anthropic-version"] = "2023-06-01"
        h.pop("Authorization", None)
    return h


def _local_runner_closed(c: dict, e: Exception) -> bool:
    """Reconnaît un refus du serveur Ollama local ; aucun lancement ni nouvel essai implicite."""
    from urllib.parse import urlparse
    reason = getattr(e, "reason", e)
    return (c.get("provider") == "ollama" and isinstance(reason, ConnectionRefusedError)
            and (urlparse(_base(c)).hostname or "") in ("127.0.0.1", "localhost", "::1"))


def _protect_request(request):
    """Envoie les justificatifs au destinataire initial, jamais à une redirection."""
    names = {"authorization", "proxy-authorization", "x-api-key", "xi-api-key", "cookie"}
    for name, value in list(request.header_items()):
        if name.lower() in names:
            request.remove_header(name)
            request.add_unredirected_header(name, value)
    return request


def _request(c: dict, path_value: str, content_body: dict | None = None, delay: float = 300, _retry: bool = False) -> dict:
    req = urllib.request.Request(_base(c) + path_value, headers=_headers(c), method="POST" if content_body is not None else "GET",
                                 data=json.dumps(content_body).encode() if content_body is not None else None)
    try:
        from .ai_runtime import is_local
        from .interrupts import open_local
        opener = open_local if is_local(c) else urllib.request.urlopen
        try:
            with opener(_protect_request(req), timeout=delay) as r:
                raw_text = r.read() or b"{}"
        finally:
            from .interrupts import check
            check()
        from .interrupts import check
        check()
        try:
            d = json.raw_loads(raw_text)
        except ValueError:
            raise AIError(f"{PROVIDERS[c['provider']]['name']} : réponse illisible") from None
        return d if isinstance(d, dict) else {"data": d}
    except urllib.error.HTTPError as e:
        try:
            detail = json.raw_loads(e.read() or b"{}")
            if isinstance(detail, list):                     # Gemini: [{"error": {...}}]
                detail = detail[0] if detail and isinstance(detail[0], dict) else {}
            err = detail.get("error") if isinstance(detail, dict) else None
            msg = err.get("message") if isinstance(err, dict) else (err or "")
        except (ValueError, AttributeError):
            msg = ""
        from .security import redact
        text = {401: "clé refusée", 403: "accès refusé", 404: "adresse ou modèle introuvable", 429: "limite atteinte (quota)"}.get(e.code, f"erreur {e.code}")
        raise AIError(f"{PROVIDERS[c['provider']]['name']} : {text}" + (f" — {redact(str(msg))[:200]}" if msg else "")) from None
    except (urllib.error.URLError, OSError, TimeoutError) as e:
        from .interrupts import check
        check()
        if _local_runner_closed(c, e):
            raise LocalServerUnavailable("Ollama est fermé : clique sur « Lancer le serveur local » dans Accueil › Réglages › IA.") from None
        from .ai_runtime import is_local
        if is_local(c):
            raise LocalServerUnavailable("Serveur local indisponible : clique sur « Lancer le serveur local » dans Accueil › Réglages › IA.") from None
        local = not PROVIDERS[c["provider"]]["key"]
        raise AIError(f"{PROVIDERS[c['provider']]['name']} ne répond pas"
                       + (" : lance-le sur ce PC." if local else f" ({type(e).__name__}).")) from None


def local_warning(data: Path, ident: str, start: bool = False) -> str:
    """An AI running on this PC (Ollama…) chosen while it does not answer: a clear warning right away, rather than a
    silent failure at the first message or task. "" when it answers, or for a cloud AI."""
    c = next((x for x in read_file(data)["connections"] if x["id"] == ident), None)
    if not c or PROVIDERS.get(c["provider"], {}).get("key", True):
        return ""
    try:
        _request(c, "/models", delay=3, _retry=start)       # Le paramètre historique ne déclenche aucun lancement.
        return ""
    except AIError:
        name = PROVIDERS[c["provider"]]["name"]
        return (f"{name} ne répond pas sur ce PC : ouvre-le (Réglages › IA › « Lancer »), sinon le Superviseur et les agents "
                "qui l'utilisent ne pourront pas travailler.")


def list_models(c: dict) -> list[str]:
    d = _request(c, "/models", delay=3 if c.get("provider") in ("ollama", "lmstudio") else 20)
    ids = [str(m.get("id") or m.get("model_id") or "") for m in (d.get("data") or d.get("models") or []) if isinstance(m, dict)]
    return sorted({i.removeprefix("models/") for i in ids if i})


def choose_advice(provider: str, model_list: list[str]) -> str:
    advice = PROVIDERS[provider]["advice"]
    return next((m for m in model_list if advice and m.startswith(advice)), model_list[0] if model_list else "")


FAMILIES = {"openai": "OpenAI (clé API)", "anthropic": "Anthropic (clé API)", "gemini": "Gemini", "mistral": "Mistral",
            "openrouter": "OpenRouter", "deepseek": "DeepSeek", "groq": "Groq", "xai": "xAI (Grok)", "moonshot": "Moonshot (Kimi)",
            "ollama": "Ollama (local)", "lmstudio": "LM Studio (local)"}


def family(c: dict) -> str:
    """AI name in Gestion › Usage (the subscription tools keep their own names)."""
    if c.get("provider") == "other":                 # custom AI: named after its address; local = free
        from urllib.parse import urlparse
        host = urlparse(c.get("url", "")).hostname or "IA"
        return f"{host} (local)" if host in ("127.0.0.1", "localhost", "::1") else host
    return FAMILIES.get(c.get("provider", ""), c.get("provider", "") or "IA connectée")


# ------------------------------------------------------------------ Ollama: native API (context size set)
_contexts: dict[str, int] = {}


def _local_runner_host(c: dict) -> str:
    b = _base(c)
    return b[:-3] if b.endswith("/v1") else b


def max_context(c: dict) -> int:
    """Maximum context of the local model (read once per model from Ollama); 0 if unknown."""
    m = c.get("model", "")
    if m in _contexts:
        return _contexts[m]
    n = 0
    if c.get("provider") == "ollama":
        try:
            req = urllib.request.Request(_local_runner_host(c) + "/api/show", data=json.dumps({"model": m}).encode(),
                                         headers={"Content-Type": "application/json"}, method="POST")
            with urllib.request.urlopen(req, timeout=10) as r:
                info = json.raw_loads(r.read() or b"{}").get("model_info") or {}
            n = max((int(v) for k, v in info.items() if k.endswith(".context_length") and isinstance(v, (int, float))), default=0)
        except (OSError, ValueError):
            n = 0
    if n:                                               # Ollama closed: ask again next time
        _contexts[m] = n
    return n


def _chat_local_runner(c: dict, messages: list[dict], allowed_tools: list[dict] | None, delay: float, context: int, effort: str = "") -> dict:
    """Ollama's native API (/api/chat): the only way to choose the context size (num_ctx). Without this setting,
    Ollama keeps its small default context and cuts the start of the mission WITHOUT WARNING. Same return format
    as "chat completions"."""
    names = {}
    natives = []
    for m in messages:
        m = dict(m)
        if m.get("role") == "assistant" and m.get("tool_calls"):
            api_calls = []
            for a in m["tool_calls"]:
                f = a.get("function") or {}
                args = f.get("arguments")
                if isinstance(args, str):
                    try:
                        args = json.raw_loads(args or "{}")
                    except ValueError:
                        args = {}
                names[a.get("id", "")] = f.get("name", "")
                api_calls.append({"function": {"name": f.get("name", ""), "arguments": args or {}}})
            m["tool_calls"] = api_calls
        elif m.get("role") == "tool":
            m = {"role": "tool", "content": m.get("content", ""), "tool_name": names.get(m.get("tool_call_id", ""), "")}
        natives.append(m)
    content_body = {"model": c["model"], "messages": natives, "stream": False, "keep_alive": "10m"}
    if allowed_tools:
        content_body["tools"] = allowed_tools
    from .ai_effort import parameters
    content_body.update(parameters(c, effort))
    if context:
        content_body["options"] = {"num_ctx": int(context)}
    host = {**c, "url": _local_runner_host(c)}
    d = _request(host, "/api/chat", content_body, delay, _retry=True)
    msg = d.get("message") or {}
    api_calls = [{"id": f"call_{i}", "type": "function", "function": {"name": (a.get("function") or {}).get("name", ""),
                                                                   "arguments": json.dumps((a.get("function") or {}).get("arguments") or {}, ensure_ascii=False)}}
              for i, a in enumerate(msg.get("tool_calls") or [])]
    return {"model": d.get("model") or c.get("model", ""), "message": {"role": "assistant", "content": msg.get("content") or "", **({"tool_calls": api_calls} if api_calls else {})},
            "usage": {"prompt_tokens": int(d.get("prompt_eval_count") or 0), "completion_tokens": int(d.get("eval_count") or 0)},
            "end": d.get("done_reason", "")}


from .ai_effort import AI_EFFORTS, capabilities as effort_capabilities


def efforts_for(actor: str, model: str = "", c: dict | None = None) -> list[tuple[str, str]]:
    if model or c:
        return [tuple(x) for x in effort_capabilities(actor, model, c, refresh=False)["options"]]
    return AI_EFFORTS.get(actor, [])


_powerful: dict[str, tuple[float, str]] = {}


def strongest_model(c: dict) -> str:
    """Max / Performance mode: among this AI's models, the best ranked one (« global » ranking); empty if unknown."""
    import time as _t
    k = c.get("id", "")
    if k in _powerful and _t.time() - _powerful[k][0] < 3600:
        return _powerful[k][1]
    try:
        from .agents import _normalize, benchmarks
        scores: dict[str, float] = {}
        for m in benchmarks()["models"]:
            if m.get("category") == "global" and m.get("score") is not None:
                for name in {m.get("key", ""), m.get("ollama", "")} - {""}:
                    scores[_normalize(name)] = max(scores.get(_normalize(name), 0), float(m["score"]))
        jot = lambda x: scores.get(_normalize(x.split("/")[-1].removesuffix(":free")), -1)   # noqa: E731
        best = max(list_models(c), key=jot, default="")
        choice = best if best and jot(best) >= 0 else ""
    except Exception:                                   # noqa: BLE001 — no list or ranking: the connection's model
        choice = ""
    _powerful[k] = (_t.time(), choice)
    return choice


def discuss(c: dict, messages: list[dict], allowed_tools: list[dict] | None = None, delay: float = 300, context: int = 0,
             effort: str = "") -> dict:
    """Send an exact model-supported control; Auto sends no reasoning parameter."""
    try:
        from .ai_effort import effective_provider
        c = {**c, "provider": effective_provider(c)}
        from . import local_lifecycle
        initial = local_lifecycle.before(c)
        try:
            return _chat(c, messages, allowed_tools, delay, context, effort)
        finally:
            # Un appel interrompu peut déjà avoir chargé le modèle, y compris un bilan.
            from .interrupts import suspended
            with suspended():
                local_lifecycle.after(c, initial)
    except ValueError as error:
        raise AIError(str(error)) from None


def _chat(c: dict, messages: list[dict], allowed_tools: list[dict] | None, delay: float, context: int, effort: str) -> dict:
    if not c.get("model"):
        raise AIError("Aucun modèle choisi pour cette connexion (Accueil › Réglages › IA).")
    if c.get("provider") == "anthropic":
        from .ai_protocols import anthropic_chat
        return anthropic_chat(c, messages, allowed_tools, delay, effort)
    if c.get("provider") == "openai" and ("codex" in c["model"] or re.match(r"gpt-(?:6|5\.[6-9])", c["model"])):
        from .ai_protocols import responses_chat
        return responses_chat(c, messages, allowed_tools, delay, effort)
    if c.get("provider") == "ollama":
        if not context:                                # Supervisor, one-off calls: just what is needed, in steps
            size = sum(len(str(m.get("content") or "")) for m in messages) + len(json.dumps(allowed_tools or []))
            context = min(max_context(c) or 32768, 32768, max(8192, -(-(size // 3 + 4096) // 4096) * 4096))
        return _chat_local_runner(c, messages, allowed_tools, delay, context, effort)
    content_body: dict = {"model": c["model"], "messages": messages}
    if allowed_tools:
        content_body["tools"] = allowed_tools
    from .ai_effort import parameters
    content_body.update(parameters(c, effort))
    if c.get("provider") == "openrouter":            # OpenRouter then returns the actual cost of the call (usage.cost)
        content_body["usage"] = {"include": True}
    d = _request(c, "/chat/completions", content_body, delay, _retry=True)
    choice = (d.get("choices") or [{}])[0]
    message = choice.get("message") or {}
    if isinstance(message.get("content"), list):
        message = {**message, "content": "".join(b.get("text", "") for b in message["content"] if b.get("type") == "text")}
    return {"model": d.get("model") or c.get("model", ""), "message": message, "usage": d.get("usage") or {}, "end": choice.get("finish_reason", "")}


def _raw(c: dict, path_value: str, content_body: dict, delay: float = 300) -> bytes:
    req = urllib.request.Request(_base(c) + path_value, headers=_headers(c), method="POST", data=json.dumps(content_body).encode())
    try:
        from .ai_runtime import is_local
        from .interrupts import open_local, check
        opener = open_local if is_local(c) else urllib.request.urlopen
        try:
            with opener(_protect_request(req), timeout=delay) as r:
                return r.read()
        finally:
            check()
    except urllib.error.HTTPError as e:
        raise AIError(f"{PROVIDERS[c['provider']]['name']} : erreur {e.code} ({path_value})") from None
    except (urllib.error.URLError, OSError, TimeoutError) as e:
        raise AIError(f"{PROVIDERS[c['provider']]['name']} ne répond pas ({type(e).__name__}).") from None


# ------------------------------------------------------------------ images and voice: any AI that can do it
CAPABLE_PROVIDERS = {"image": ("openai", "gemini", "xai", "openrouter", "other"),
            "voice": ("openai", "elevenlabs", "groq", "other")}
_NAME_PATTERNS = {"image": ("gpt-image", "imagen", "flash-image", "image", "dall-e", "stream", "sdxl", "stable-diffusion"),
           "voice": ("tts", "speech", "eleven", "voice", "kokoro")}


def _model_for(c: dict, category_kind: str) -> str:
    if c.get(f"model_{category_kind}"):
        return c[f"model_{category_kind}"]
    try:
        names = list_models(c)
    except AIError:
        names = []
    for pattern in _NAME_PATTERNS[category_kind]:
        found = sorted((m for m in names if pattern in m.lower()), reverse=True)
        if found:
            return found[0]
    return {("openai", "image"): "gpt-image-1", ("gemini", "image"): "imagen-4.0-generate-001", ("xai", "image"): "grok-2-image",
            ("openrouter", "image"): "google/gemini-2.5-flash-image", ("openai", "voice"): "gpt-4o-mini-tts",
            ("elevenlabs", "voice"): "eleven_multilingual_v2"}.get((c.get("provider"), category_kind), "")


def image_model(c: dict) -> str:
    return _model_for(c, "image")


def connection_for(data: Path, category_kind: str, preferred: dict | None = None) -> dict | None:
    """Connection able to produce this kind (« image » or « voix »): the agent's if it can, otherwise the
    first connected one that can. As permissive as possible: any OpenAI-compatible AI (cloud or local) is tried."""
    if preferred and preferred.get("provider") in CAPABLE_PROVIDERS[category_kind]:
        return preferred
    return next((c for c in read_file(data)["connections"] if c["provider"] in CAPABLE_PROVIDERS[category_kind]), None)


def _image_bytes(item: dict) -> bytes:
    if item.get("b64_json"):
        return base64.b64decode(item["b64_json"])
    url = str(item.get("url") or (item.get("image_url") or {}).get("url") or "")
    if url.startswith("data:image") and "," in url:
        return base64.b64decode(url.split(",", 1)[1])
    if url.startswith("https://"):
        with urllib.request.urlopen(url, timeout=120) as r:
            return r.read()
    raise AIError("Aucune image renvoyée.")


def generate_image(c: dict, prompt: str, size: str = "1024x1024") -> bytes:
    """PNG image generated by the connected AI: OpenAI, Gemini, xAI, OpenRouter (image models through chat), or
    any OpenAI-compatible AI (/images/generations, e.g. LocalAI on the PC). Nothing is published."""
    model = image_model(c)
    if c.get("provider") == "openrouter":            # OpenRouter: image models through chat
        d = _request(c, "/chat/completions", {"model": model, "messages": [{"role": "user", "content": prompt[:4000]}],
                                              "modalities": ["image", "text"]}, 300)
        images = ((d.get("choices") or [{}])[0].get("message") or {}).get("images") or []
        if not images:
            raise AIError("Ce modèle n'a pas renvoyé d'image : choisis un modèle d'image (OpenRouter).")
        return _image_bytes(images[0])
    content_body = {"model": model, "prompt": prompt[:4000], "n": 1}
    if c.get("provider") != "xai":
        content_body["size"] = size
    if not str(model).startswith("gpt-image"):
        content_body["response_format"] = "b64_json"
    d = json.raw_loads(_raw(c, "/images/generations", content_body) or b"{}")
    return _image_bytes((d.get("data") or [{}])[0])


def generate_voice(c: dict, text: str, voice: str = "") -> bytes:
    """Text-to-speech MP3 file: OpenAI, Groq, ElevenLabs, or any OpenAI-compatible AI (/audio/speech,
    e.g. a local voice server)."""
    if c.get("provider") == "elevenlabs":
        if not voice:
            voice = (_request(c, "/voices", delay=20).get("voices") or [{}])[0].get("voice_id", "")
        if not voice:
            raise AIError("ElevenLabs : aucune voix disponible sur ce compte.")
        return _raw(c, f"/text-to-speech/{voice}", {"text": text[:5000], "model_id": _model_for(c, "voice")})
    return _raw(c, "/audio/speech", {"model": _model_for(c, "voice"), "voice": voice or "alloy", "input": text[:4000],
                                      "response_format": "mp3"})


def detect_local_models() -> list[str]:
    """Local AIs answering right now (nothing is started or installed)."""
    out = []
    for k in ("ollama", "lmstudio"):
        try:
            with urllib.request.urlopen(PROVIDERS[k]["url"] + "/models", timeout=1):
                out.append(k)
        except OSError:
            pass
    return out


# ------------------------------------------------------------------ who answers: Supervisor and agents
def choice(studio, audience: str) -> tuple[str, dict | None]:
    """("claude-code" | "codex" | "api" | "", connection) for « superviseur » or « agents ».
    Explicit setting first; otherwise the subscription tool (claude-code) if installed; otherwise the first connection."""
    d = read_file(studio.paths.data)
    v = d.get(audience, "")
    if v in ("claude-code", "codex"):
        return v, None
    if v:
        c = next((x for x in d["connections"] if x["id"] == v), None)
        if c:
            return "api", c
    from .connectors.primary_cli import WIN_CANDIDATES
    from .connectors.base import find_exe
    if find_exe(studio.cfg["tools"].get("primary_cli", "claude"), WIN_CANDIDATES):
        return "claude-code", None
    if d["connections"]:
        return "api", d["connections"][0]
    return "", None


def call_supervisor(studio, c: dict, instruction: str, message: str, effort: str = "") -> tuple[bool, str, dict]:
    from .user_workspace import custom
    try:
        from .ai_runtime import require_local_model
        require_local_model(c)
        r = discuss(c, [{"role": "system", "content": custom(instruction)}, {"role": "user", "content": custom(message)}],
                     delay=float(studio.cfg.get("supervisor", {}).get("timeout_s", 300)), effort=effort)
    except AIError as e:
        return False, str(e), {"local_unavailable": isinstance(e, LocalServerUnavailable)}
    text = r["message"].get("content") or ""
    if isinstance(text, list):                         # some providers return blocks
        text = "".join(b.get("text", "") for b in text if isinstance(b, dict))
    return bool(text.strip()), text or "Réponse vide.", {'tokens': r["usage"], "call": True, "model": r.get("model") or c["model"],
                                                           "actor": "api", "connection": c.get("id", ""),
                                                           "family": family(c), "cost_usd": (r["usage"] or {}).get("cost")}
