"""Unload only models first loaded by this process; the local server is never stopped."""
from __future__ import annotations

import threading

_lock = threading.RLock()
_owned = {}


def forget_connection(c):
    """A server seen offline may have restarted; an old ownership claim is no longer safe."""
    from . import ai
    endpoint = ai._base(c)
    with _lock:
        for key in list(_owned):
            if key[0] == endpoint:
                _owned.pop(key, None)


def loaded(c):
    from . import ai
    if c.get("provider") == "ollama":
        host = {**c, "url": ai._local_runner_host(c)}
        rows = ai._request(host, "/api/ps", delay=2).get("models", [])
        return {r.get("name") or r.get("model"): r.get("name") or r.get("model") for r in rows}
    if c.get("provider") == "lmstudio":
        host = {**c, "url": ai._base(c).removesuffix("/v1")}
        rows = ai._request(host, "/api/v1/models", delay=2).get("models", [])
        return {r.get("key"): i["id"] for r in rows for i in r.get("loaded_instances", []) if i.get("id")}
    return {}


def before(c):
    from .ai_runtime import is_local
    if not is_local(c) or c.get("provider") not in ("ollama", "lmstudio"):
        return None
    try:
        return loaded(c)
    except Exception:  # no ownership claim when the initial state cannot be established
        return None


def after(c, initial):
    from .ai_runtime import model_present
    if initial is None or model_present(c.get("model", ""), initial):
        return
    from . import ai
    try:
        current = loaded(c)
        model = c.get("model")
        token = current.get(model) or current.get(model + ":latest")
        if token:
            with _lock:
                _owned[(ai._base(c), model)] = (dict(c), token)
    except Exception:
        pass


def unload(note=lambda text: None):
    from . import ai
    with _lock:
        items = list(_owned.values())
        _owned.clear()
    for c, token in items:
        try:
            if token not in loaded(c).values():
                continue
            host = {**c, "url": ai._base(c).removesuffix("/v1")}
            if c["provider"] == "ollama":
                ai._request(host, "/api/generate", {"model": token, "keep_alive": 0}, delay=3)
            else:
                ai._request(host, "/api/v1/models/unload", {"instance_id": token}, delay=3)
            note("modèle local déchargé")
        except Exception:
            note("déchargement local indisponible ; serveur laissé en service")
