import sys
from pathlib import Path

from .python_env import relaunch_if_needed

# Only an already selected environment may be used here. Optional preparation starts after the UI is listening.
code = relaunch_if_needed(Path(__file__).resolve().parents[1], sys.argv[1:])
if code is not None:
    sys.exit(code)

from .cli import main  # noqa: E402

sys.exit(main())
