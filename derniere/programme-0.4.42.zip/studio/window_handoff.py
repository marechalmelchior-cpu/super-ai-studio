"""Acquittement d'affichage entre deux lanceurs, sans service permanent."""
import os
import secrets
import time
from pathlib import Path

ENV = "STUDIO_WINDOW_HANDOFF"


def prepare(data):
    return Path(data) / ("window-handoff-" + secrets.token_hex(12) + ".ready")


def displayed(data):
    value = os.environ.get(ENV)
    if not value or data is None:
        return
    path = Path(value)
    if path.parent.resolve() == Path(data).resolve() and path.name.startswith("window-handoff-") and path.suffix == ".ready":
        try:
            with path.open("x", encoding="utf-8") as stream:
                stream.write("Fenêtre affichée\n")
        except FileExistsError:
            pass


def waiting(controller):
    path = getattr(controller, "handoff_path", None)
    if path is None or getattr(controller, "handoff_cancelled", False) or path.is_file():
        return False
    if not hasattr(controller, "handoff_started"):
        controller.handoff_started = time.monotonic()
    if time.monotonic() - controller.handoff_started > 60:
        controller.handoff_failed = True
    return True
