"""Interruption coopérative des appels locaux, y compris avant les en-têtes HTTP."""
from contextlib import contextmanager
import http.client
import socket
import threading
import urllib.request

from .orchestrator.processes import Cancelled

_local = threading.local()


@contextmanager
def scope(cancelled):
    previous = getattr(_local, "scope", None)
    current = Scope(cancelled)
    _local.scope = current
    try:
        current.check()
        yield current
    finally:
        current.done.set()
        current.worker.join(1)
        _local.scope = previous


@contextmanager
def suspended():
    previous = getattr(_local, "scope", None)
    _local.scope = None
    try:
        yield
    finally:
        _local.scope = previous


class Scope:
    def __init__(self, cancelled):
        self.cancelled = cancelled
        self.done = threading.Event()
        self.stopped = threading.Event()
        self.sockets = set()
        self.lock = threading.Lock()
        self.worker = threading.Thread(target=self.watch, daemon=True)
        self.worker.start()

    def check(self):
        if self.stopped.is_set() or self.cancelled():
            raise Cancelled("Appel interrompu — reprise possible.")

    def attach(self, connection):
        with self.lock:
            self.sockets.add(connection)
        if self.stopped.is_set():
            self.disconnect(connection)
        self.check()

    @staticmethod
    def disconnect(connection):
        try:
            connection.shutdown(socket.SHUT_RDWR)
        except OSError:
            pass

    def watch(self):
        while not self.done.wait(.1):
            if self.cancelled():
                self.stopped.set()
                with self.lock:
                    for connection in self.sockets:
                        self.disconnect(connection)
                return


def open_local(request, timeout):
    current = getattr(_local, "scope", None)
    if current is None:
        return urllib.request.urlopen(request, timeout=timeout)
    current.check()

    class Connection(http.client.HTTPConnection):
        def connect(self):
            delay = self.timeout
            self.timeout = min(delay, 3)
            super().connect()
            self.sock.settimeout(delay)
            current.attach(self.sock)

    class SecureConnection(http.client.HTTPSConnection):
        def connect(self):
            delay = self.timeout
            self.timeout = min(delay, 3)
            super().connect()
            self.sock.settimeout(delay)
            current.attach(self.sock)

    class SecureHandler(urllib.request.HTTPSHandler):
        def https_open(self, req):
            return self.do_open(SecureConnection, req)

    class Handler(urllib.request.HTTPHandler):
        def http_open(self, req):
            return self.do_open(Connection, req)

    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, *args):
            raise OSError("Redirection refusée pour un appel local interruptible.")

    return urllib.request.build_opener(urllib.request.ProxyHandler({}), Handler(), SecureHandler(), NoRedirect()).open(request, timeout=timeout)


def check():
    current = getattr(_local, "scope", None)
    if current is not None:
        current.check()
