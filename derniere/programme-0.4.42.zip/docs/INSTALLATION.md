# Installer le studio IA

**Super AI Agent Pro Station Max 2000** est une plateforme IA tout-en-un : toutes tes IA (Claude, ChatGPT, Gemini, Grok, modèles gratuits sur ton PC…) réunies dans une seule application, avec une équipe d'agents, une mémoire et des compétences partagées par toutes. Fini les tutos et les réglages compliqués : tu installes en deux clics, tu connectes ton IA, et tu demandes ce que tu veux.

Il te faut : Windows 10 ou 11, un Mac ou un PC Linux, et une IA (abonnement, clé API ou IA gratuite sur ton PC).

## 1. Installer

**Windows**
1. Double-clique sur `Super AI Agent Pro Station Max 2000 - Installation.exe`.
2. Message « Windows a protégé votre ordinateur » ? Clique **Informations complémentaires**, puis **Exécuter quand même**.
3. Clique **Installer**. Attends 2 à 5 minutes.

**Mac et Linux** : ouvre un Terminal et colle cette ligne, puis Entrée :

`curl -fsSL https://raw.githubusercontent.com/marechalmelchior-cpu/super-ai-studio/main/derniere/installer.sh | bash`

Il faut Python 3.11 ou plus (le Terminal te dit comment l'installer s'il manque). Raccourci créé : sur le Bureau (Mac) ou dans le menu des applications (Linux).

Rien de ce que tu as déjà n'est modifié.

## 2. Premier lancement
1. Ouvre **Super AI Agent Pro Station Max 2000**.
2. Tape ton prénom (facultatif) et clique **Créer mon studio**.
3. Connecte une IA en un clic, avec son logo :
   - **abonnement** Claude ou ChatGPT : le studio installe l'outil puis ouvre la connexion ;
   - **clé API** (OpenRouter, OpenAI, Gemini, Mistral…) : colle ta clé ;
   - **gratuit sur ton PC** : installe Ollama, choisis un modèle adapté à ton PC (le studio te le conseille).
4. GitHub (facultatif) : installe Git et connecte ton compte pour sauvegarder tes projets en ligne.
5. Suis la visite guidée (1 minute). Bouton **Guide**, en haut, pour la revoir.

## 3. Travailler
- Écris ta demande au Superviseur, à droite. Il propose une tâche : clique **Lancer**, puis **Valider** le résultat.
- Ajoute un projet avec le bouton **+** : pars d'un modèle (site web, jeu vidéo, application, document, images) ou d'un projet vide.
- Gestion › Usage › **Tes résultats** : quel modèle réussit le mieux chaque travail, d'après tes propres tâches.
- Langue anglaise : Accueil › Réglages › **Langue · Language** › en.

## 4. Téléphone (facultatif)
1. Installe **Tailscale** sur le PC et le téléphone (même compte).
2. Studio : Accueil › Réglages › Téléphone › **Accès téléphone** › **Associer un téléphone**.
   L’accès est coupé au lancement sauf si tu actives « Accès téléphone toujours ouvert », désactivé par défaut.
3. Sur le téléphone : ouvre l'adresse affichée et tape le code.

## Bon à savoir
- Tout reste sur ton PC.
- Rien n'est installé, supprimé ni publié sans ton clic.
- Fermer : bouton **Fermer**, en haut à droite.
- Désinstaller (Windows) : menu Démarrer › Super AI Agent Pro Station Max 2000 › Désinstaller. Mac et Linux : supprime le dossier « Super AI Studio » de ton dossier personnel. Ton dossier de travail est gardé.

## Fenêtre et configuration de base (0.4.42)
Les composants de la fenêtre native sont préparés et vérifiés pendant l’installation. Si la fenêtre native échoue, le repli est une simple fenêtre d’application du navigateur. Dans le Superviseur, choisis Local ou Cloud ; Réglages › Configuration de base permet de choisir le mode initial et ton moteur local. « Lancer le serveur local au démarrage du studio » est désactivé par défaut.

Si l’adresse Tailscale change : ouvre la nouvelle adresse affichée sur le PC, associe le téléphone, réinstalle l’application puis supprime l’ancienne icône. Une ancienne application hors ligne ne peut pas découvrir cette adresse toute seule. Voir [le guide des fenêtres et du téléphone](desktop-window.md).
