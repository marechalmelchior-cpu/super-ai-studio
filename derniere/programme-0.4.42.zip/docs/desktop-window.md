# Fenêtre, Superviseur, serveurs et téléphone — 0.4.42

## Fenêtre native et repli automatique

Le studio essaie toujours sa fenêtre native. L'installation prépare ses composants hors ligne et vérifie leur import avant la première ouverture. Si le moteur web du système manque ou échoue, une simple fenêtre d'application du navigateur sert de repli. Elle garde le profil `data/edge-studio`, sans cadre supplémentaire. Les réglages ne proposent plus de mode navigateur. Pour un diagnostic ponctuel seulement : lancer avec `STUDIO_FORCE_BROWSER=1`, puis retirer cette variable.

La croix de la fenêtre native et le bouton « Fermer le studio » proposent les mêmes choix s'il y a du travail ou une nuit programmée : « Laisser tourner en arrière-plan », « Mettre en pause et fermer », « Annuler ». Sans travail, ils arrêtent réellement le studio et son accès téléphone. La pause conserve les points de reprise et attend la fin effective des appels ; les appels cloud déjà envoyés peuvent prendre du temps.

Dans le repli, la croix du navigateur ferme sa fenêtre. Le travail continue en arrière-plan ; sans travail ni nuit programmée, le studio s'arrête après un court délai. Le bouton « Fermer le studio » garde la question à trois choix. Lors du passage vers le natif, le repli attend l'acquittement d'affichage natif avant de fermer sa propre fenêtre. Après 60 secondes sans acquittement, il affiche un échec et reste ouvert.

## Local ou Cloud et configuration de base

À l'ouverture du Superviseur, choisis Local ou Cloud. Le mode au lancement est surligné selon Accueil › Réglages › Configuration de base. Le clic affiche l'IA, le modèle et l'effort du mode choisi ; tu peux changer de mode à tout moment. Aucun fournisseur n'est imposé.

Choisis aussi le moteur local par défaut parmi ceux détectés (Ollama, LM Studio ou autre). Le bouton « Lancer le serveur local » est directement près des menus en mode Local si ce moteur est arrêté. Les réglages IA rafraîchissent l'état des moteurs. Un moteur personnalisé sans commande attestée doit être ouvert dans son application.

« Lancer le serveur local au démarrage du studio » est désactivé par défaut. Si tu l'actives, seul le moteur choisi est lancé au démarrage. Le studio arrête à sa fermeture réelle les processus qu'il a lancés et possède encore. Un moteur qui délègue à un daemon indépendant, notamment LM Studio, reste sous le contrôle de son application : le studio n'arrête pas un processus dont il ne peut attester la propriété. Les modèles déjà chargés par un autre programme restent conservés.

## Tâches et nuit

Les cartes n'ont pas de boutons Local/Cloud. Leurs IA, modèle et effort viennent de l'équipe du projet ; tu peux les modifier avant de lancer. Lancer et Reprendre vérifient toutes les étapes de la chaîne et leurs relectures avant de changer l'état de la tâche. Si un serveur local manque, une seule fenêtre propose « Lancer le serveur local » ; dès qu'il répond, la tâche part ou reprend automatiquement. Un délai dépassé conserve le travail en attente et demande un nouvel essai.

« Cette nuit » demande au moment de la programmation : « Lancer le serveur local à l'heure de la tâche ? ». L'accord vaut uniquement pour cette programmation. Sans accord et si le serveur est arrêté à l'heure prévue, la tâche reste dans la file ; le rapport du matin explique l'attente. Aucun serveur ne démarre silencieusement.

## Téléphone et changement d'adresse

Par défaut, l'accès téléphone reste coupé au lancement. Pour l'ouvrir : studio sur le PC → Accueil › Réglages › Téléphone → « Accès téléphone » → « Associer un téléphone ». Sur le téléphone, ouvre l'adresse affichée et tape le code à 6 chiffres, valable 10 minutes et une seule fois. Une page refusée ou le dépannage propose « Ouvrir la page du code ».

L'option « Accès téléphone toujours ouvert » est désactivée par défaut. Si tu l'actives, le studio rouvre son relais au lancement. La croix et « Fermer le studio » arrêtent l'accès quand aucun travail ne tourne ; fermer le PC ou le mettre en veille le rend également inaccessible.

Le studio mémorise la dernière adresse Tailscale observée et signale un changement dans Réglages › Téléphone. Sur le téléphone : ouvrir la nouvelle adresse, associer de nouveau le téléphone, réinstaller l'application depuis cette adresse puis supprimer l'ancienne icône. Une ancienne application qui ne joint plus du tout son ancien PC ne peut pas découvrir la nouvelle adresse : lis-la sur le PC. Au premier enregistrement, le studio ne connaît pas encore les adresses antérieures.

L'application affiche immédiatement « Connexion au studio… ». Sans réponse après environ trois secondes, elle affiche quatre vérifications : Tailscale sur le téléphone, studio ouvert sur le PC, accès téléphone activé, PC éveillé et connecté. « Réessayer » effectue un nouvel essai, sans boucle automatique. Une application déjà installée doit joindre au moins une fois le studio mis à jour pour recevoir ce nouveau fonctionnement.
