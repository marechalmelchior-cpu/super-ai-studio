"""Guard for unreal-mcp tools in studio tasks (PreToolUse hook of the agent CLI).

"All" mode (default, user's choice of 24/10): agents use unreal-mcp as in an interactive session; each
action is recorded in the task log (read / write) so it shows up in the report.
"Read" mode (Superviseur › Réglages): only read actions go through, as described below.

unreal-mcp routes ALL its actions through a single tool, ``call_tool``: reading the level and deleting an actor use the
same tool, so a "tool by tool" permission is not enough. This guard looks at the requested action and:

- allows ``list_toolsets`` and ``describe_toolset`` (they only describe);
- allows ``call_tool`` only for a READ action: its name starts with a read verb
  (get, find, list, describe, search, query, read, count, has, is, snapshot, inspect, dump) AND contains no
  write word (set, create, delete, spawn, save, compile, press, run…);
- refuses everything else, with the reason (the agent sees it and reports it).

Safe by default: ``call_tool`` is NOT among the roles' allowed tools; only this guard can open it, case by
case. If the guard fails to start, the CLI refuses the call (no approval window in a task).
Every decision is recorded in ``Studio/data/garde-unreal-mcp.log`` (action and decision, never the arguments).

Shell commands (Bash, PowerShell) in tasks: allowed as in a normal session (launching the editor, project
scripts, tests, git status…), recorded in the task log; only destructive or publishing commands
are refused (push, reset --hard, clean, recursive deletion, formatting, Windows shutdown, global
taskkill…). The review ("read" mode) has no shell.

Launched by the CLI with the call's JSON on standard input; replies with JSON on standard output.
"""
from __future__ import annotations

import json
import re
import sys
from datetime import datetime
from pathlib import Path

PREFIX = "mcp__unreal-mcp__"
DESCRIPTION = {"list_toolsets", "describe_toolset"}
READ_VERBS = ("get", "find", "list", "describe", "search", "query", "read", "count", "has", "is", "snapshot",
                  "inspect", "dump")
WRITE_WORDS = ("set", "create", "delete", "remove", "destroy", "spawn", "add", "save", "compile", "build", "move",
                 "rename", "import", "export", "execute", "exec", "run", "start", "stop", "press", "click", "type",
                 "focus", "open", "close", "load", "unload", "apply", "modify", "write", "edit", "update", "change",
                 "duplicate", "copy", "paste", "attach", "detach", "select", "play", "simulate", "restart", "quit",
                 "reset", "clear", "replace", "assign", "bind", "register", "enable", "disable", "toggle", "fix",
                 "generate", "bake", "migrate", "commit", "submit", "send", "post", "invoke", "call")


def words(nom: str) -> list[str]:
    """« get_current_level », « GetCurrentLevel », « SceneTools.find_actors » → lowercase words."""
    nom = nom.split(".")[-1]
    nom = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", nom)
    return [m for m in re.split(r"[^A-Za-z0-9]+", nom.lower()) if m]


def decision(entry: dict) -> tuple[str, str]:
    outil = str(entry.get("tool_name") or "")
    if not outil.startswith(PREFIX):
        return "", ""                                   # not an unreal-mcp tool: the guard stays silent
    short = outil[len(PREFIX):]
    if short in DESCRIPTION:
        return "allow", f"{short} : description des outils, lecture seule"
    if short != "call_tool":
        return "deny", f"{short} : outil unreal-mcp non prévu pour les tâches du studio"
    ti = entry.get("tool_input") or {}
    action = str(ti.get("tool_name") or ti.get("tool") or ti.get("name") or "")
    if not action:
        return "deny", "call_tool sans nom d'action : refusé"
    m = words(action)
    if not m or m[0] not in READ_VERBS:
        return "deny", f"action « {action} » refusée : les tâches du studio n'ont que les actions de lecture (get, find, list…)"
    writes = [x for x in m if x in WRITE_WORDS]
    if writes:
        return "deny", f"action « {action} » refusée : contient « {writes[0]} » (écriture possible)"
    return "allow", f"action « {action} » en lecture seule"


SHELL = {"Bash", "PowerShell"}
EDIT_TOOLS = {"Edit", "Write", "MultiEdit", "NotebookEdit"}     # only recorded (live activity); the permission does not change
FORBIDDEN = [
    (r"\bgit\s+push\b", "git push : la publication passe par Gestion › Branches"),
    (r"\bgit\s+reset\s+--hard\b", "git reset --hard"),
    (r"\bgit\s+clean\b", "git clean"),
    (r"\bgit\s+(checkout|restore)\s+(--\s+)?\.(\s|$)", "annulation de tous les fichiers"),
    (r"\bgit\s+branch\s+-D\b", "suppression forcée de branche"),
    (r"\bgit\s+(rebase|filter-branch|filter-repo)\b", "réécriture d'historique"),
    (r"\bgit\s+stash\s+(drop|clear)\b", "suppression de remises"),
    (r"\brm\s+(-[a-zA-Z]*[rR][a-zA-Z]*|--recursive)\b", "suppression récursive"),
    (r"\b(remove-item|ri|rm|del|erase|rd|rmdir)\b[^|;&]*\s-(r|recurse)\b", "suppression récursive"),
    (r"\b(rd|rmdir|del|erase)\b[^|;&]*\s/s\b", "suppression récursive"),
    # DISK formatting only (« format D: »): never -Format, Format-List or .format( in Python
    (r"(^|[;&|(]|\bcmd(\.exe)?\s+/[ck])\s*format(\.com)?\s+[a-z]:", "formatage de disque"),
    (r"\b(diskpart|bcdedit|vssadmin\s+delete|cipher\s+/w)\b", "commande système destructrice"),
    (r"\b(shutdown|restart-computer|stop-computer|logoff)\b", "arrêt de Windows"),
    (r"\btaskkill\b[^|;&]*/im\b", "taskkill global (cibler un processus précis)"),
    (r"\bstop-process\b[^|;&]*-name\b", "arrêt de processus par nom (cibler un PID)"),
    (r"\b(reg\s+delete|remove-itemproperty|set-executionpolicy|netsh|sc(\.exe)?\s+delete)\b", "réglage système"),
    (r"(iwr|irm|invoke-webrequest|invoke-restmethod|curl|wget)[^|]*\|\s*(iex|invoke-expression|sh|bash|powershell)\b",
     "télécharger puis exécuter"),
]


def decision_shell(command: str) -> tuple[str, str]:
    c = (command or "").lower()
    for pattern, reason in FORBIDDEN:
        if re.search(pattern, c):
            return "deny", f"commande refusée par le studio ({reason}). Dis-le dans ton compte rendu, sans contourner."
    return "allow", "commande autorisée et notée par le studio"


def is_read(entry: dict) -> bool:
    return decision(entry)[0] == "allow"


def jot(action: str, dec: str, genre: str) -> None:
    """Global log (data/garde-unreal-mcp.log) and task log (STUDIO_ACTIONS_UNREAL), without the arguments."""
    import os
    line = f"{datetime.now().isoformat(timespec='seconds')}  {dec:5}  {genre:8}  {action}\n"
    for f in (Path(__file__).resolve().parents[1] / "data" / "garde-unreal-mcp.log", os.environ.get("STUDIO_ACTIONS_UNREAL")):
        if not f:
            continue
        try:
            f = Path(f); f.parent.mkdir(parents=True, exist_ok=True)
            with f.open("a", encoding="utf-8") as h:
                h.write(line)
        except OSError:
            pass


def main() -> int:
    try:
        raw_text = sys.stdin.buffer.read() if hasattr(sys.stdin, "buffer") else sys.stdin.read().encode("utf-8")
        entry = json.loads(raw_text.decode("utf-8", errors="replace") or "{}")     # the CLI sends UTF-8 (accented paths)
    except ValueError:
        entry = {}
    import os
    entry = entry if isinstance(entry, dict) else {}
    outil = str(entry.get("tool_name") or "")
    ti0 = entry.get("tool_input") or {}
    if outil in EDIT_TOOLS:                                # recorded for live activity, NO decision: the role's rule applies
        chemin = str(ti0.get("file_path") or ti0.get("notebook_path") or "")
        tache = os.environ.get("STUDIO_TACHE_DOSSIER", "")
        if tache and chemin:
            norm_path = lambda x: x.replace("\\", "/").rstrip("/").lower()
            c, t = norm_path(chemin), norm_path(tache)
            if c.startswith(t + "/") and not any(c.startswith(f"{t}/{d}/") for d in ("copie-de-travail", "captures")):
                log_activity("refus", f"écrire {Path(chemin).name} dans le dossier de la tâche")
                return reply("deny", "Fichier du studio (compte rendu, journaux) : le studio l'écrit lui-même. Mets ton "
                                        "compte rendu dans ta réponse finale et tes preuves dans captures/.")
        log_activity("fichier", f"{'crée' if outil == 'Write' else 'modifie'}  {_mask(chemin)[:300]}")
        return 0
    if outil in SHELL:
        cmd = str((entry.get("tool_input") or {}).get("command") or "")
        if os.environ.get("STUDIO_MCP_UNREAL", "tout") == "lecture":
            dec, reason = "deny", "relecture : pas de commande shell"
        else:
            dec, reason = decision_shell(cmd)
        log_command(f"{dec:5}  {outil:10}  {_mask(' '.join(cmd.split()))[:300]}")
        log_activity("commande" if dec == "allow" else "refus", _mask(' '.join(cmd.split()))[:300])
        return reply(dec, reason)
    dec, reason = decision(entry)
    if not dec:
        return 0
    reading = dec == "allow"
    if os.environ.get("STUDIO_MCP_UNREAL", "tout") != "lecture":
        dec, reason = "allow", "unreal-mcp : accès complet (réglage du studio)"
    ti = entry.get("tool_input") or {}
    short = str(entry.get("tool_name", ""))[len(PREFIX):]
    action = f"{ti.get('toolset_name', '')}.{ti.get('tool_name', '')}".strip(".") if short == "call_tool" else short
    jot(action, dec, "lecture" if reading else "écriture")
    log_activity("unreal", f"{'lecture' if reading else 'écriture'}  {action}")
    return reply(dec, reason)


def _mask(texte: str) -> str:
    """No secrets in the log: studio redaction, or a simple mask if the package cannot be imported."""
    try:
        sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
        from studio.security import redact
        return redact(texte)
    except Exception:                                   # noqa: BLE001
        return re.sub(r"(?i)(token|key|secret|password|passwd|pwd|bearer)\S*\s*[=:]?\s*\S+", r"\1=***", texte)


def log_command(line: str) -> None:
    import os
    f = os.environ.get("STUDIO_COMMANDES")
    if not f:
        return
    try:
        f = Path(f); f.parent.mkdir(parents=True, exist_ok=True)
        with f.open("a", encoding="utf-8") as h:
            h.write(f"{datetime.now().isoformat(timespec='seconds')}  {line}\n")
    except OSError:
        pass


def log_activity(genre: str, texte: str) -> None:
    """Task activity feed (STUDIO_ACTIVITE): what the agent is doing, shown live to the user, never a secret."""
    import os
    f = os.environ.get("STUDIO_ACTIVITE")
    if not f:
        return
    try:
        f = Path(f); f.parent.mkdir(parents=True, exist_ok=True)
        with f.open("a", encoding="utf-8") as h:
            h.write(f"{datetime.now().isoformat(timespec='seconds')}\t{genre}\t{texte}\n")
    except OSError:
        pass


def reply(dec: str, reason: str) -> int:
    output = json.dumps({"hookSpecificOutput": {"hookEventName": "PreToolUse", "permissionDecision": dec,
                                                "permissionDecisionReason": reason}}, ensure_ascii=False)
    flux = sys.stdout if sys.stdout is not None else open(1, "w", encoding="utf-8", closefd=False)
    flux.write(output)
    flux.flush()
    return 0


if __name__ == "__main__":
    sys.exit(main())
